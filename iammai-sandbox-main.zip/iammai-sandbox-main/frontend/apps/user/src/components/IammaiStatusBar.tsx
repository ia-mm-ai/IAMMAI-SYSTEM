/**
 * IammaiStatusBar — Derivative surface showing IAMMAI constitutional state.
 *
 * Displays the current phase, state family, containment status, and resolution
 * for the user's session. All data is fetched from the derivative /iammai-status
 * endpoint and updated via WebSocket IAMMAI_* events.
 *
 * This is NOT a canonical surface — display does not define state.
 */

import React, { useEffect, useState } from 'react';
import type { IammaiStatus } from '@iammai-sandbox/shared';

interface IammaiStatusBarProps {
  sessionId: string;
  iammaiEvent?: { type: string; payload: Record<string, unknown> } | null;
}

const API_BASE = process.env['NEXT_PUBLIC_API_URL'] ?? 'http://localhost:3001/api/v1';

const PHASE_LABELS: Record<string, string> = {
  signal: 'SIG',
  acceptance: 'ACC',
  scope: 'SCP',
  presence: 'PRS',
  threshold: 'THR',
  truth: 'TRU',
  continuity: 'CON',
  decision: 'DEC',
  consequence: 'CSQ',
};

export function IammaiStatusBar({ sessionId, iammaiEvent }: IammaiStatusBarProps) {
  const [status, setStatus] = useState<IammaiStatus | null>(null);

  useEffect(() => {
    fetch(`${API_BASE}/sessions/${sessionId}/iammai-status`)
      .then(r => r.ok ? r.json() as Promise<IammaiStatus> : null)
      .then(data => { if (data) setStatus(data); })
      .catch(() => {}); // Fail silently — status bar is informational
  }, [sessionId]);

  // Update from WebSocket events
  useEffect(() => {
    if (!iammaiEvent || !status?.tracked) return;

    if (iammaiEvent.type === 'IAMMAI_PHASE_CHANGE') {
      setStatus(prev => prev ? {
        ...prev,
        phase: iammaiEvent.payload['phase'] as string,
        family: iammaiEvent.payload['family'] as 'preparation' | 'standing',
      } : prev);
    } else if (iammaiEvent.type === 'IAMMAI_HELD') {
      setStatus(prev => prev ? { ...prev, isHeld: true } : prev);
    } else if (iammaiEvent.type === 'IAMMAI_RELEASED') {
      setStatus(prev => prev ? { ...prev, isHeld: false } : prev);
    } else if (iammaiEvent.type === 'IAMMAI_RESOLVED') {
      setStatus(prev => prev ? {
        ...prev,
        isResolved: true,
        resolutionType: iammaiEvent.payload['resolutionType'] as 'FINALIZE' | 'INVALIDATE' | 'EVOLVE',
      } : prev);
    }
  }, [iammaiEvent, status?.tracked]);

  if (!status?.tracked || !status.phase) return null;

  const phaseLabel = PHASE_LABELS[status.phase] ?? status.phase.toUpperCase();
  const isStanding = status.family === 'standing';

  return (
    <div
      className="flex items-center gap-2 px-4 py-1.5 bg-dark-surface2 border-b border-dark-border font-mono text-xs"
      data-testid="iammai-status-bar"
      role="status"
      aria-label="IAMMAI constitutional state"
    >
      {/* Phase badge */}
      <span className="text-text-muted">IAMMAI</span>
      <span className="text-dark-border">·</span>

      <span
        className={`px-2 py-0.5 rounded font-mono text-xs font-semibold tracking-wider ${
          isStanding
            ? 'bg-accent-cyan/10 text-accent-cyan border border-accent-cyan/30'
            : 'bg-dark-surface3 text-text-secondary border border-dark-border'
        } ${status.isHeld ? 'border-accent-magenta/50 text-accent-magenta' : ''}`}
        title={`Phase: ${status.phase}`}
      >
        {phaseLabel}
      </span>

      <span className={`text-xs ${isStanding ? 'text-accent-cyan/60' : 'text-text-muted'}`}>
        {isStanding ? 'STANDING' : 'PREPARATION'}
      </span>

      {/* HELD indicator */}
      {status.isHeld && (
        <span
          className="px-2 py-0.5 rounded text-xs font-semibold text-accent-magenta border border-accent-magenta/40 animate-pulse"
          title="Matter is held — messaging frozen"
        >
          HELD
        </span>
      )}

      {/* Resolution badge */}
      {status.isResolved && status.resolutionType && (
        <span
          className={`px-2 py-0.5 rounded text-xs font-semibold border ${
            status.resolutionType === 'FINALIZE'
              ? 'text-success border-success/40'
              : status.resolutionType === 'INVALIDATE'
              ? 'text-error border-error/40'
              : 'text-accent-blue border-accent-blue/40'
          }`}
          title={`Resolution: ${status.resolutionType}`}
        >
          {status.resolutionType}
        </span>
      )}
    </div>
  );
}
