/**
 * Dissolution overlay component
 * @see specs/001-ephemeral-kernel/tasks.md#T087
 * @see specs/001-ephemeral-kernel/spec.md#FR-017, FR-018
 *
 * Displays when kernel is dissolved, informing user their conversation is gone
 */

'use client';

import { useEffect, useState } from 'react';
import { HoverGlow } from '@iammai-sandbox/shared';

export interface DissolutionOverlayProps {
  sessionName?: string;
}

export function DissolutionOverlay({ sessionName }: DissolutionOverlayProps) {
  const [visible, setVisible] = useState(false);

  useEffect(() => {
    // Trigger fade-in animation after mount
    const timer = setTimeout(() => setVisible(true), 50);
    return () => clearTimeout(timer);
  }, []);

  return (
    <div
      className={`fixed inset-0 z-[10000] flex items-center justify-center bg-dark-base transition-opacity duration-500 ${
        visible ? 'bg-opacity-95' : 'bg-opacity-0'
      }`}
      role="alert"
      aria-live="assertive"
      aria-atomic="true"
    >
      <div
        className={`max-w-md rounded-lg border border-error bg-error-bg p-8 text-center shadow-glow-error-bright transition-all duration-500 ${
          visible ? 'scale-100 opacity-100' : 'scale-95 opacity-0'
        }`}
      >
        {/* Dissolution icon */}
        <div className="mb-6 flex justify-center">
          <div className="rounded-full bg-error/20 p-4 shadow-glow-error-medium">
            <svg
              className="h-16 w-16 text-error animate-pulse"
              fill="none"
              stroke="currentColor"
              viewBox="0 0 24 24"
              aria-hidden="true"
            >
              <path
                strokeLinecap="round"
                strokeLinejoin="round"
                strokeWidth={2}
                d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-3L13.732 4c-.77-1.333-2.694-1.333-3.464 0L3.34 16c-.77 1.333.192 3 1.732 3z"
              />
            </svg>
          </div>
        </div>

        {/* Heading */}
        <h1 className="mb-4 text-3xl font-bold text-error-text font-display tracking-tight">Kernel Dissolved</h1>

        {/* Message */}
        <p className="mb-6 text-lg text-error-text">
          Your conversation is gone
          {sessionName && (
            <span className="mt-2 block text-sm text-text-secondary">
              Session &ldquo;{sessionName}&rdquo; has ended
            </span>
          )}
        </p>

        {/* Explanation */}
        <div className="mb-6 rounded-md border border-error/20 bg-dark-surface2 p-4 text-left text-sm text-text-secondary">
          <p className="mb-2">
            The session has been ended by an administrator. All conversations and data have been
            permanently destroyed.
          </p>
          <p className="text-text-muted">
            This is part of our privacy guarantee - no conversation history is retained.
          </p>
        </div>

        {/* Action button */}
        <HoverGlow color="cyan" className="inline-block rounded-md">
          <button
            onClick={() => {
              window.location.href = '/';
            }}
            className="rounded-md bg-accent-cyan px-6 py-3 font-semibold text-dark-base transition-colors duration-hover hover:bg-accent-cyan-hover focus:outline-none focus:ring-2 focus:ring-accent-cyan focus:ring-offset-2 focus:ring-offset-error-bg"
          >
            Return to Sessions
          </button>
        </HoverGlow>

        {/* Privacy indicator */}
        <div className="mt-6 flex items-center justify-center gap-2 text-xs text-text-muted">
          <svg
            className="h-4 w-4"
            fill="none"
            stroke="currentColor"
            viewBox="0 0 24 24"
            aria-hidden="true"
          >
            <path
              strokeLinecap="round"
              strokeLinejoin="round"
              strokeWidth={2}
              d="M12 15v2m-6 4h12a2 2 0 002-2v-6a2 2 0 00-2-2H6a2 2 0 00-2 2v6a2 2 0 002 2zm10-10V7a4 4 0 00-8 0v4h8z"
            />
          </svg>
          <span>Privacy protected: All data destroyed</span>
        </div>
      </div>
    </div>
  );
}
