/**
 * ChatMessage component - displays a single chat message
 * @see specs/001-ephemeral-kernel/tasks.md#T076
 */

import React from 'react';

export interface ChatMessageProps {
  role: 'user' | 'assistant';
  content: string;
  timestamp?: Date;
  isStreaming?: boolean;
}

export function ChatMessage({ role, content, timestamp, isStreaming }: ChatMessageProps) {
  const isUser = role === 'user';

  return (
    <div
      className={`flex ${isUser ? 'justify-end' : 'justify-start'} space-y-4`}
      data-testid="chat-message"
      data-role={role}
    >
      <div
        className={`max-w-[70%] rounded-lg p-4 border-l-2 transition-shadow duration-hover ${
          isUser
            ? 'bg-accent-magenta/[0.03] border-accent-magenta shadow-glow-magenta-subtle hover:shadow-glow-magenta-medium'
            : 'bg-accent-cyan/[0.03] border-accent-cyan shadow-glow-cyan-subtle hover:shadow-glow-cyan-medium'
        }`}
      >
        <div className="flex items-center gap-2 mb-1">
          <span className={`text-xs font-semibold uppercase tracking-wider ${
            isUser ? 'text-accent-magenta/60' : 'text-accent-cyan/60'
          }`}>
            {isUser ? 'You' : 'AI'}
          </span>
        </div>
        <div className="text-base font-normal leading-normal whitespace-pre-wrap break-words text-text-primary">
          {content}
          {isStreaming && (
            <span className="inline-block ml-1 animate-pulse text-accent-cyan">▊</span>
          )}
        </div>
        {timestamp && !isStreaming && (
          <div className={`text-xs font-normal leading-tight mt-2 ${
            isUser ? 'text-accent-magenta/50' : 'text-accent-cyan/50'
          }`}>
            {formatTimestamp(timestamp)}
          </div>
        )}
      </div>
    </div>
  );
}

/**
 * Format timestamp for display
 */
function formatTimestamp(date: Date): string {
  const now = new Date();
  const diff = now.getTime() - date.getTime();
  const seconds = Math.floor(diff / 1000);
  const minutes = Math.floor(seconds / 60);
  const hours = Math.floor(minutes / 60);

  if (seconds < 60) {
    return 'just now';
  } else if (minutes < 60) {
    return `${minutes}m ago`;
  } else if (hours < 24) {
    return `${hours}h ago`;
  } else {
    return date.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
  }
}
