/**
 * PresenceIndicator component - shows other users in the session
 * @see specs/001-ephemeral-kernel/tasks.md#T078
 */

import React from 'react';

export interface PresenceIndicatorProps {
  presenceHash: string;
  userCount: number;
}

export function PresenceIndicator({ presenceHash, userCount }: PresenceIndicatorProps) {
  // Generate color from presence hash
  const getColorFromHash = (hash: string): { bg: string; glow: string } => {
    const colors = [
      { bg: 'bg-accent-cyan', glow: 'shadow-glow-cyan-medium' },
      { bg: 'bg-accent-blue', glow: 'shadow-glow-blue-medium' },
      { bg: 'bg-accent-magenta', glow: 'shadow-glow-magenta-medium' },
      { bg: 'bg-success', glow: 'shadow-glow-success-medium' },
    ];

    // Use first 8 chars of hash for color selection
    const hashValue = parseInt(hash.substring(0, 8), 16);
    return colors[hashValue % colors.length]!;
  };

  const colorConfig = getColorFromHash(presenceHash);
  const otherUsersCount = Math.max(0, userCount - 1);
  const shortHash = `#${presenceHash.substring(0, 6)}`;

  return (
    <div className="inline-flex items-center gap-2" data-testid="presence-indicator">
      <div className={`w-2.5 h-2.5 rounded-full ${colorConfig.bg} ${colorConfig.glow} animate-pulse`} />
      <span
        className="text-sm text-text-secondary cursor-help"
        title={presenceHash}
      >
        {shortHash}
        {otherUsersCount > 0 && ` + ${otherUsersCount} other${otherUsersCount === 1 ? '' : 's'}`}
      </span>
    </div>
  );
}
