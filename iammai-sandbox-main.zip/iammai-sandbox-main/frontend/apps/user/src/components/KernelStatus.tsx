/**
 * KernelStatus component - shows kernel/session status
 * @see specs/001-ephemeral-kernel/tasks.md#T077
 */

import React from 'react';
import { GlowPulse } from '@iammai-sandbox/shared';

export type KernelState = 'ACTIVE' | 'DISSOLVED' | 'DISCONNECTED';

export interface KernelStatusProps {
  state: KernelState;
  message?: string;
}

export function KernelStatus({ state, message }: KernelStatusProps) {
  const getStatusConfig = () => {
    switch (state) {
      case 'ACTIVE':
        return {
          color: 'text-success',
          bgColor: 'bg-success-bg border border-success',
          glowColor: 'success' as const,
          icon: '●',
          text: 'Kernel Active',
          pulse: true,
        };
      case 'DISSOLVED':
        return {
          color: 'text-error',
          bgColor: 'bg-error-bg border border-error shadow-glow-error-medium',
          glowColor: 'error' as const,
          icon: '○',
          text: 'Kernel Dissolved',
          pulse: false,
        };
      case 'DISCONNECTED':
        return {
          color: 'text-warning',
          bgColor: 'bg-warning-bg border border-warning',
          glowColor: 'cyan' as const,
          icon: '◐',
          text: 'Disconnected',
          pulse: false,
        };
    }
  };

  const config = getStatusConfig();

  const badge = (
    <div
      className={`inline-flex items-center gap-2 px-3 py-1.5 rounded-full transition-all duration-hover ${config.bgColor}`}
      data-testid="kernel-status"
      data-state={state}
    >
      <span className={`text-sm ${config.color}`}>{config.icon}</span>
      <span className={`text-sm font-medium ${config.color}`}>
        {config.text}
      </span>
      {message && state === 'DISSOLVED' && (
        <span className={`text-xs ${config.color}`}>— {message}</span>
      )}
    </div>
  );

  if (config.pulse) {
    return (
      <GlowPulse color={config.glowColor} active={true} className="inline-flex rounded-full">
        {badge}
      </GlowPulse>
    );
  }

  return badge;
}
