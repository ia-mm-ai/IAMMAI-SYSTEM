/**
 * SessionList component
 * @see specs/001-ephemeral-kernel/tasks.md#T061
 *
 * Displays a list of public sessions with claim/join actions based on state
 */

import { useCallback } from 'react';
import { clsx } from 'clsx';
import type { PublicSession } from '@iammai-sandbox/shared';
import { StatusBadge, SessionCardSkeleton } from '@iammai-sandbox/shared';

export interface SessionListProps {
  sessions: PublicSession[];
  loading?: boolean;
  error?: string | null;
  onClaim: (sessionId: string) => Promise<void>;
  onJoin: (sessionId: string) => Promise<void>;
  claimingSessionId?: string | null;
  joiningSessionId?: string | null;
  claimedSessionIds?: string[];
}

export function SessionList({
  sessions,
  loading = false,
  error = null,
  onClaim,
  onJoin,
  claimingSessionId,
  joiningSessionId,
  claimedSessionIds = [],
}: SessionListProps): JSX.Element {
  if (loading) {
    return (
      <div className="space-y-4" role="status" aria-label="Loading sessions">
        <SessionCardSkeleton />
        <SessionCardSkeleton />
        <SessionCardSkeleton />
      </div>
    );
  }

  if (error) {
    return (
      <div
        className="p-4 bg-error/10 border border-error/20 rounded-lg text-error"
        role="alert"
      >
        <p className="font-medium">Failed to load sessions</p>
        <p className="text-sm">{error}</p>
      </div>
    );
  }

  if (sessions.length === 0) {
    return (
      <div className="p-8 text-center text-text-secondary bg-dark-surface1 rounded-lg border border-dark-border">
        <p className="text-lg font-medium">No sessions available</p>
        <p className="text-sm mt-1">Check back later for new sessions</p>
      </div>
    );
  }

  return (
    <div className="space-y-4" role="list" aria-label="Available sessions">
      {sessions.map((session) => (
        <SessionCard
          key={session.id}
          session={session}
          onClaim={onClaim}
          onJoin={onJoin}
          isClaiming={claimingSessionId === session.id}
          isJoining={joiningSessionId === session.id}
          hasClaimed={claimedSessionIds.includes(session.id)}
        />
      ))}
    </div>
  );
}

interface SessionCardProps {
  session: PublicSession;
  onClaim: (sessionId: string) => Promise<void>;
  onJoin: (sessionId: string) => Promise<void>;
  isClaiming: boolean;
  isJoining: boolean;
  hasClaimed: boolean;
}

function SessionCard({
  session,
  onClaim,
  onJoin,
  isClaiming,
  isJoining,
  hasClaimed,
}: SessionCardProps): JSX.Element {
  const handleClaim = useCallback(async () => {
    await onClaim(session.id);
  }, [onClaim, session.id]);

  const handleJoin = useCallback(async () => {
    await onJoin(session.id);
  }, [onJoin, session.id]);

  return (
    <div
      className="p-6 bg-dark-surface1 border border-accent-cyan/20 rounded-lg shadow-glow-cyan-subtle hover:border-accent-cyan/40 hover:shadow-glow-cyan-medium transition-all duration-hover my-4"
      role="listitem"
      aria-labelledby={`session-name-${session.id}`}
    >
      <div className="flex justify-between items-start mb-4">
        <div>
          <h3
            id={`session-name-${session.id}`}
            className="text-lg font-semibold text-text-primary"
          >
            {session.name}
          </h3>
          <p className="text-sm text-text-secondary mt-2">
            Session ID: {session.id.substring(0, 8)}...
          </p>
        </div>
        <StatusBadge state={session.state} size="sm" />
      </div>

      <div className="flex gap-4 mt-4">
        {session.canClaim && !hasClaimed && (
          <button
            onClick={handleClaim}
            disabled={isClaiming}
            className={clsx(
              'px-4 py-2 rounded-md font-medium text-sm transition-all duration-hover',
              'bg-accent-cyan text-dark-base hover:bg-accent-cyan-hover',
              'shadow-glow-cyan-medium hover:shadow-glow-cyan-bright',
              'disabled:opacity-50 disabled:cursor-not-allowed disabled:shadow-none',
              'focus:outline-none focus:ring-2 focus:ring-accent-cyan focus:ring-offset-2 focus:ring-offset-dark-surface1'
            )}
            aria-describedby={`claim-desc-${session.id}`}
          >
            {isClaiming ? (
              <span className="flex items-center">
                <LoadingSpinner className="w-4 h-4 mr-2" />
                Claiming...
              </span>
            ) : (
              'Claim Token'
            )}
          </button>
        )}

        {session.canClaim && hasClaimed && (
          <div className="flex items-center text-sm text-text-secondary">
            <CheckIcon className="w-5 h-5 text-success mr-2" />
            <span>Token claimed - waiting for session to start</span>
          </div>
        )}

        {session.canJoin && hasClaimed && (
          <button
            onClick={handleJoin}
            disabled={isJoining}
            className={clsx(
              'px-4 py-2 rounded-md font-medium text-sm transition-all duration-hover',
              'bg-success text-dark-base hover:bg-success/90',
              'shadow-glow-success-medium hover:shadow-glow-success-bright',
              'disabled:opacity-50 disabled:cursor-not-allowed disabled:shadow-none',
              'focus:outline-none focus:ring-2 focus:ring-success focus:ring-offset-2 focus:ring-offset-dark-surface1'
            )}
          >
            {isJoining ? (
              <span className="flex items-center">
                <LoadingSpinner className="w-4 h-4 mr-2" />
                Joining...
              </span>
            ) : (
              'Join Session'
            )}
          </button>
        )}

        {session.canJoin && !hasClaimed && (
          <p className="text-sm text-text-secondary italic">
            You need a token to join this session
          </p>
        )}
      </div>

      {session.canClaim && (
        <p
          id={`claim-desc-${session.id}`}
          className="text-xs text-text-muted mt-2"
        >
          Claim a free token to join when the session starts
        </p>
      )}
    </div>
  );
}

// Simple icons
function LoadingSpinner({ className }: { className?: string }): JSX.Element {
  return (
    <svg
      className={clsx('animate-spin', className)}
      xmlns="http://www.w3.org/2000/svg"
      fill="none"
      viewBox="0 0 24 24"
      aria-hidden="true"
    >
      <circle
        className="opacity-25"
        cx="12"
        cy="12"
        r="10"
        stroke="currentColor"
        strokeWidth="4"
      />
      <path
        className="opacity-75"
        fill="currentColor"
        d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4z"
      />
    </svg>
  );
}

function CheckIcon({ className }: { className?: string }): JSX.Element {
  return (
    <svg
      className={className}
      xmlns="http://www.w3.org/2000/svg"
      viewBox="0 0 20 20"
      fill="currentColor"
      aria-hidden="true"
    >
      <path
        fillRule="evenodd"
        d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z"
        clipRule="evenodd"
      />
    </svg>
  );
}
