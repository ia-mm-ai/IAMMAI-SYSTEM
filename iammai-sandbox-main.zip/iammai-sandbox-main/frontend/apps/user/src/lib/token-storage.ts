/**
 * Token storage utility
 * @see specs/001-ephemeral-kernel/tasks.md#T062
 *
 * Manages token storage in localStorage with sessionId -> token mapping
 */

const STORAGE_KEY = 'iammai-sandbox-tokens';

interface TokenStore {
  [sessionId: string]: {
    token: string;
    claimedAt: string;
  };
}

/**
 * Get all stored tokens
 */
function getStore(): TokenStore {
  if (typeof window === 'undefined') {
    return {};
  }

  try {
    const data = localStorage.getItem(STORAGE_KEY);
    return data ? (JSON.parse(data) as TokenStore) : {};
  } catch {
    return {};
  }
}

/**
 * Save store to localStorage
 */
function saveStore(store: TokenStore): void {
  if (typeof window === 'undefined') {
    return;
  }

  try {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(store));
  } catch {
    console.error('Failed to save tokens to localStorage');
  }
}

/**
 * Store a token for a session
 */
export function storeToken(sessionId: string, token: string): void {
  const store = getStore();
  store[sessionId] = {
    token,
    claimedAt: new Date().toISOString(),
  };
  saveStore(store);
}

/**
 * Get token for a session
 */
export function getToken(sessionId: string): string | null {
  const store = getStore();
  return store[sessionId]?.token ?? null;
}

/**
 * Check if user has a token for a session
 */
export function hasToken(sessionId: string): boolean {
  return getToken(sessionId) !== null;
}

/**
 * Remove token for a session
 */
export function removeToken(sessionId: string): void {
  const store = getStore();
  delete store[sessionId];
  saveStore(store);
}

/**
 * Clear all tokens (for logout or dissolution)
 */
export function clearAllTokens(): void {
  if (typeof window === 'undefined') {
    return;
  }

  try {
    localStorage.removeItem(STORAGE_KEY);
  } catch {
    console.error('Failed to clear tokens from localStorage');
  }
}

/**
 * Get all session IDs with stored tokens
 */
export function getStoredSessionIds(): string[] {
  const store = getStore();
  return Object.keys(store);
}
