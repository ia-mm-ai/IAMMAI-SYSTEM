/**
 * User home page - session browser
 * @see specs/001-ephemeral-kernel/tasks.md#T060
 * @see specs/001-ephemeral-kernel/spec.md#User Story 2
 */

import { useState, useEffect, useCallback } from 'react';
import { useRouter } from 'next/router';
import Head from 'next/head';
import type { PublicSession, TokenClaim, JoinResponse, ApiError } from '@iammai-sandbox/shared';
import { useToast } from '@iammai-sandbox/shared';
import { FadeUp } from '@iammai-sandbox/shared';
import { SessionList } from '../components/SessionList';
import { storeToken, getToken, getStoredSessionIds } from '../lib/token-storage';

const API_BASE_URL = process.env['NEXT_PUBLIC_API_URL'] || 'http://localhost:3001/api/v1';

export default function UserHome(): JSX.Element {
  const router = useRouter();
  const { showError } = useToast();
  const [sessions, setSessions] = useState<PublicSession[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [claimingSessionId, setClaimingSessionId] = useState<string | null>(null);
  const [joiningSessionId, setJoiningSessionId] = useState<string | null>(null);
  const [claimedSessionIds, setClaimedSessionIds] = useState<string[]>([]);

  // Load stored tokens on mount
  useEffect(() => {
    const storedIds = getStoredSessionIds();
    setClaimedSessionIds(storedIds);
  }, []);

  // Fetch sessions on mount and periodically
  useEffect(() => {
    fetchSessions();

    // Poll for updates every 10 seconds
    const interval = setInterval(fetchSessions, 10000);

    return () => clearInterval(interval);
  }, []);

  const fetchSessions = useCallback(async () => {
    try {
      const response = await fetch(`${API_BASE_URL}/sessions`);

      if (!response.ok) {
        const errorData: ApiError = await response.json();
        throw new Error(errorData.message || 'Failed to fetch sessions');
      }

      const data: { sessions: PublicSession[] } = await response.json();
      setSessions(data.sessions);
      setError(null);
    } catch (err) {
      const message = err instanceof Error ? err.message : 'Failed to load sessions';
      setError(message);
    } finally {
      setLoading(false);
    }
  }, []);

  const handleClaim = useCallback(async (sessionId: string): Promise<void> => {
    setClaimingSessionId(sessionId);

    try {
      const response = await fetch(`${API_BASE_URL}/sessions/${sessionId}/claim`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
      });

      if (!response.ok) {
        const errorData: ApiError = await response.json();
        throw new Error(errorData.message || 'Failed to claim token');
      }

      const data: TokenClaim = await response.json();

      // Store the token locally
      storeToken(sessionId, data.token);

      // Update UI state
      setClaimedSessionIds((prev) => [...prev, sessionId]);

      // Refresh sessions to get latest state
      await fetchSessions();
    } catch (err) {
      const message = err instanceof Error ? err.message : 'Failed to claim token';
      showError(message);
    } finally {
      setClaimingSessionId(null);
    }
  }, [fetchSessions, showError]);

  const handleJoin = useCallback(async (sessionId: string): Promise<void> => {
    const token = getToken(sessionId);

    if (!token) {
      showError('No token found for this session. Please claim a token first.');
      return;
    }

    setJoiningSessionId(sessionId);

    try {
      const response = await fetch(`${API_BASE_URL}/sessions/${sessionId}/join`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ token }),
      });

      if (!response.ok) {
        const errorData: ApiError = await response.json();
        throw new Error(errorData.message || 'Failed to join session');
      }

      const data: JoinResponse = await response.json();

      // Store presence hash for use in chat page
      sessionStorage.setItem(`presence-${sessionId}`, data.presenceHash);
      sessionStorage.setItem(`ws-url-${sessionId}`, data.websocketUrl);

      // Navigate to chat page
      router.push(`/chat/${sessionId}`);
    } catch (err) {
      const message = err instanceof Error ? err.message : 'Failed to join session';
      showError(message);
    } finally {
      setJoiningSessionId(null);
    }
  }, [router, showError]);

  return (
    <>
      <Head>
        <title>IAMMAI Sandbox - Sessions</title>
        <meta name="description" content="Browse and join chat sessions" />
      </Head>

      <main className="min-h-screen bg-dark-base scan-lines">
        <div className="max-w-4xl mx-auto py-16 px-6">
          <FadeUp>
            <header className="mb-12">
              <h1 className="text-4xl font-bold leading-tight text-text-primary font-display tracking-tight text-glow-cyan-medium">
                Available Sessions
              </h1>
              <p className="mt-4 text-base font-normal leading-normal text-text-secondary">
                Browse sessions and claim a token to join
              </p>
            </header>
          </FadeUp>

          <div className="mb-8 flex items-center justify-between">
            <div className="flex items-center gap-4">
              <span className="text-sm font-normal leading-normal text-accent-cyan/60">
                {sessions.length} session{sessions.length !== 1 ? 's' : ''} available
              </span>
              {claimedSessionIds.length > 0 && (
                <span className="text-sm font-normal leading-normal text-success-text">
                  {claimedSessionIds.length} token{claimedSessionIds.length !== 1 ? 's' : ''} claimed
                </span>
              )}
            </div>
            <button
              onClick={fetchSessions}
              disabled={loading}
              className="text-sm font-semibold text-accent-magenta hover:text-accent-magenta-hover disabled:opacity-50 transition-colors duration-hover"
            >
              Refresh
            </button>
          </div>

          <FadeUp delay={0.1}>
            <SessionList
              sessions={sessions}
              loading={loading}
              error={error}
              onClaim={handleClaim}
              onJoin={handleJoin}
              claimingSessionId={claimingSessionId}
              joiningSessionId={joiningSessionId}
              claimedSessionIds={claimedSessionIds}
            />
          </FadeUp>

          <FadeUp delay={0.2}>
            <footer className="mt-16 pt-8 border-t border-accent-magenta/20">
            <div className="text-center text-sm font-normal leading-normal text-text-muted">
              <p className="mb-4">
                <strong className="font-semibold text-accent-magenta font-display tracking-wide text-glow-magenta-subtle">How it works:</strong>
              </p>
              <ol className="list-decimal list-inside space-y-2 text-left max-w-md mx-auto">
                <li>Find a session in <span className="text-accent-blue font-medium">Created</span> state</li>
                <li>Claim a free token to reserve your spot</li>
                <li>Wait for the admin to start the session</li>
                <li>When the session becomes <span className="text-success-text font-medium">Active</span>, click <span className="text-accent-cyan font-medium">Join</span></li>
                <li>Chat privately with the AI - your conversation is <span className="text-accent-magenta/70 font-medium">ephemeral</span></li>
              </ol>
            </div>
            </footer>
          </FadeUp>
        </div>
      </main>
    </>
  );
}
