/**
 * Chat page - main chat interface with AI streaming
 * @see specs/001-ephemeral-kernel/tasks.md#T075, T079, T080
 */

import React, { useState, useEffect, useRef, useCallback } from 'react';
import { useRouter } from 'next/router';
import { motion, AnimatePresence } from 'framer-motion';
import { useWebSocket, WebSocketMessage } from '@shared/hooks/useWebSocket';
import { ChatMessage } from '../../components/ChatMessage';
import { KernelStatus, KernelState } from '../../components/KernelStatus';
import { PresenceIndicator } from '../../components/PresenceIndicator';
import { DissolutionOverlay } from '../../components/DissolutionOverlay';
import { IammaiStatusBar } from '../../components/IammaiStatusBar';
import { useReducedMotion, HoverGlow } from '@iammai-sandbox/shared';
import { getToken, removeToken } from '../../lib/token-storage';

interface Message {
  id: string;
  role: 'user' | 'assistant';
  content: string;
  timestamp: Date;
  isStreaming?: boolean;
}

interface SessionData {
  sessionId: string;
  token: string;
  presenceHash?: string;
  userCount?: number;
}

export default function ChatPage() {
  const router = useRouter();
  const { id: sessionId } = router.query;
  const { isReady } = router;
  const reducedMotion = useReducedMotion();

  const [messages, setMessages] = useState<Message[]>([]);
  const [inputValue, setInputValue] = useState('');
  const [kernelState, setKernelState] = useState<KernelState>('ACTIVE');
  const [dissolutionMessage, setDissolutionMessage] = useState<string>();
  const [sessionData, setSessionData] = useState<SessionData | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [isReconnecting, setIsReconnecting] = useState(false);
  const [iammaiEvent, setIammaiEvent] = useState<{ type: string; payload: Record<string, unknown> } | null>(null);
  const [isIammaiHeld, setIsIammaiHeld] = useState(false);

  const messagesEndRef = useRef<HTMLDivElement>(null);
  const inputRef = useRef<HTMLTextAreaElement>(null);

  // Streaming message state
  const streamingMessageRef = useRef<{
    id: string;
    content: string;
  } | null>(null);

  // Load session data from localStorage
  useEffect(() => {
    if (!isReady) {
      return;
    }

    if (!sessionId || typeof sessionId !== 'string') {
      return;
    }

    const token = getToken(sessionId);

    if (!token) {
      router.push('/');
      return;
    }

    setSessionData({
      sessionId,
      token,
    });
    setIsLoading(false);
  }, [isReady, sessionId, router]);

  // Handle WebSocket messages
  const handleWebSocketMessage = useCallback((message: WebSocketMessage) => {
    switch (message.type) {
      case 'CONNECTION_ACK':
        setSessionData((prev) => ({
          ...prev!,
          presenceHash: message.payload?.presenceHash as string,
          userCount: 1, // Will be updated by presence service
        }));
        setKernelState('ACTIVE');
        break;

      case 'MESSAGE_CHUNK':
        const chunkPayload = message.payload as {
          messageId: string;
          content: string;
        };

        if (!streamingMessageRef.current) {
          // Start new streaming message
          streamingMessageRef.current = {
            id: chunkPayload.messageId,
            content: chunkPayload.content,
          };

          setMessages((prev) => [
            ...prev,
            {
              id: chunkPayload.messageId,
              role: 'assistant',
              content: chunkPayload.content,
              timestamp: new Date(),
              isStreaming: true,
            },
          ]);
        } else {
          // Append to existing streaming message
          streamingMessageRef.current.content += chunkPayload.content;

          setMessages((prev) =>
            prev.map((msg) =>
              msg.id === streamingMessageRef.current!.id
                ? { ...msg, content: streamingMessageRef.current!.content }
                : msg
            )
          );
        }
        break;

      case 'MESSAGE_COMPLETE':
        const completePayload = message.payload as {
          messageId: string;
          content: string;
        };

        setMessages((prev) =>
          prev.map((msg) =>
            msg.id === completePayload.messageId
              ? { ...msg, content: completePayload.content, isStreaming: false }
              : msg
          )
        );

        streamingMessageRef.current = null;
        break;

      case 'MESSAGE_ERROR':
        const errorPayload = message.payload as {
          messageId: string;
          message: string;
        };

        setMessages((prev) => [
          ...prev,
          {
            id: crypto.randomUUID(),
            role: 'assistant',
            content: `Error: ${errorPayload.message}`,
            timestamp: new Date(),
          },
        ]);

        streamingMessageRef.current = null;
        break;

      case 'KERNEL_DISSOLVED':
        const dissolvedPayload = message.payload as {
          message: string;
        };

        setKernelState('DISSOLVED');
        setDissolutionMessage(dissolvedPayload.message);

        // Clear token and message cache
        removeToken(sessionId as string);
        break;

      case 'IAMMAI_PHASE_CHANGE':
      case 'IAMMAI_HELD':
      case 'IAMMAI_RELEASED':
      case 'IAMMAI_RESOLVED':
        // Propagate to IammaiStatusBar via shared event state
        setIammaiEvent({ type: message.type, payload: (message.payload ?? {}) as Record<string, unknown> });
        if (message.type === 'IAMMAI_HELD') setIsIammaiHeld(true);
        if (message.type === 'IAMMAI_RELEASED') setIsIammaiHeld(false);
        break;
    }
  }, []);

  const handleConnectionChange = useCallback((connected: boolean) => {
    if (!connected) {
      setIsReconnecting(true);
      setKernelState('DISCONNECTED');
    } else {
      setIsReconnecting(false);
      setKernelState('ACTIVE');
    }
  }, []);

  // Handle conversation history restoration on reconnect (FR-021)
  const handleConversationHistory = useCallback((history: Array<{
    id: string;
    role: 'user' | 'assistant';
    content: string;
    timestamp: string;
  }>) => {
    if (history.length > 0) {
      // Restore messages from server
      const restoredMessages: Message[] = history.map((msg) => ({
        id: msg.id,
        role: msg.role,
        content: msg.content,
        timestamp: new Date(msg.timestamp),
        isStreaming: false,
      }));

      setMessages(restoredMessages);
      setIsReconnecting(false);
    }
  }, []);

  // WebSocket connection - only connect when sessionData is ready
  const WS_URL = process.env['NEXT_PUBLIC_WS_URL'] || 'ws://localhost:3001';

  const { connected, dissolved, sendMessage } = useWebSocket(
    sessionData
      ? {
          sessionId: sessionData.sessionId,
          token: sessionData.token,
          wsUrl: WS_URL,
          onMessage: handleWebSocketMessage,
          onConnectionChange: handleConnectionChange,
          onConversationHistory: handleConversationHistory,
        }
      : {
          sessionId: '',
          token: '',
          wsUrl: WS_URL,
          onMessage: handleWebSocketMessage,
          onConnectionChange: handleConnectionChange,
          onConversationHistory: handleConversationHistory,
        }
  );

  // Auto-scroll to bottom when messages change
  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages]);

  // Handle send message
  const handleSend = useCallback(async () => {
    const trimmed = inputValue.trim();
    if (!trimmed || !sessionData) return;

    const messageId = crypto.randomUUID();

    // Optimistic update
    const userMessage: Message = {
      id: messageId,
      role: 'user',
      content: trimmed,
      timestamp: new Date(),
    };

    setMessages((prev) => [...prev, userMessage]);
    setInputValue('');

    // Send via WebSocket
    sendMessage(trimmed, messageId);

    // Focus back on input
    inputRef.current?.focus();
  }, [inputValue, sessionData, sendMessage]);

  // Handle Enter key
  const handleKeyDown = useCallback(
    (e: React.KeyboardEvent<HTMLTextAreaElement>) => {
      if (e.key === 'Enter' && !e.shiftKey) {
        e.preventDefault();
        handleSend();
      }
    },
    [handleSend]
  );

  if (isLoading) {
    return (
      <div className="flex items-center justify-center h-screen">
        <div className="text-text-secondary">Loading...</div>
      </div>
    );
  }

  if (!sessionData) {
    return null;
  }

  const isDisabled = kernelState === 'DISSOLVED' || !connected || isIammaiHeld;

  return (
    <div className="flex flex-col h-screen bg-dark-base scan-lines">
      {/* Dissolution Overlay */}
      {dissolved && <DissolutionOverlay sessionName={sessionId as string} />}

      {/* Header */}
      <div className="flex items-center justify-between px-6 py-4 bg-dark-surface1 border-b border-dark-border">
        <div className="flex items-center gap-4">
          <h1 className="text-4xl font-bold leading-tight text-text-primary font-display tracking-tight text-glow-cyan-medium">
            {sessionId}
          </h1>
          <KernelStatus state={kernelState} message={dissolutionMessage} />
        </div>
        {sessionData.presenceHash && sessionData.userCount && (
          <PresenceIndicator
            presenceHash={sessionData.presenceHash}
            userCount={sessionData.userCount}
          />
        )}
      </div>

      {/* IAMMAI Status Bar — derivative surface showing constitutional state */}
      {sessionData?.sessionId && (
        <IammaiStatusBar
          sessionId={sessionData.sessionId}
          iammaiEvent={iammaiEvent}
        />
      )}

      {/* Messages */}
      <div className="flex-1 overflow-y-auto px-6 py-4">
        {/* Reconnecting indicator */}
        {isReconnecting && messages.length > 0 && (
          <div className="mb-4 p-4 bg-warning-bg border border-warning rounded-lg">
            <p className="text-sm font-normal leading-normal text-warning-text text-center">
              Reconnecting... Your conversation history will be restored.
            </p>
          </div>
        )}

        {messages.length === 0 && !isReconnecting && (
          <div className="flex items-center justify-center h-full">
            <div className="text-center text-text-secondary">
              <p className="text-lg font-semibold leading-normal mb-2 text-accent-cyan font-display tracking-wide text-glow-cyan-subtle">Welcome to Ephemeral Chat</p>
              <p className="text-sm font-normal leading-normal text-accent-magenta/50">Your messages will disappear when the session ends</p>
            </div>
          </div>
        )}

        <div className="space-y-4">
          <AnimatePresence mode="popLayout">
            {messages.map((message) => (
              <motion.div
                key={message.id}
                initial={{ opacity: 0, y: reducedMotion ? 0 : 20 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0 }}
                transition={{ duration: reducedMotion ? 0 : 0.3, ease: [0.22, 1, 0.36, 1] }}
              >
                <ChatMessage
                  role={message.role}
                  content={message.content}
                  timestamp={message.timestamp}
                  isStreaming={message.isStreaming}
                />
              </motion.div>
            ))}
          </AnimatePresence>
        </div>

        <div ref={messagesEndRef} />
      </div>

      {/* Dissolution warning */}
      {kernelState === 'DISSOLVED' && (
        <div className="px-6 py-4 bg-error-bg border-t border-error">
          <p className="text-sm font-normal leading-normal text-error-text text-center">
            {dissolutionMessage || 'This session has ended. All messages are now deleted.'}
          </p>
        </div>
      )}

      {/* IAMMAI HELD frost overlay — recoverable (unlike dissolution) */}
      {isIammaiHeld && (
        <div className="px-6 py-3 bg-dark-surface2 border-t border-accent-magenta/40 flex items-center gap-3">
          <span className="text-accent-magenta text-sm animate-pulse">⬡</span>
          <p className="text-sm font-mono text-accent-magenta">
            MATTER HELD — Session frozen by IAMMAI containment. Messaging suspended until released.
          </p>
        </div>
      )}

      {/* Input */}
      <div className="px-6 py-4 bg-dark-surface1 border-t border-dark-border">
        <div className="flex gap-4">
          <textarea
            ref={inputRef}
            value={inputValue}
            onChange={(e) => setInputValue(e.target.value)}
            onKeyDown={handleKeyDown}
            disabled={isDisabled}
            placeholder={
              isDisabled
                ? 'Chat is not available'
                : 'Type a message... (Enter to send, Shift+Enter for new line)'
            }
            className="flex-1 px-4 py-4 border border-dark-border rounded-lg
                     focus:outline-none focus:ring-2 focus:ring-accent-cyan focus:border-accent-cyan/50 focus:shadow-glow-cyan-subtle
                     bg-dark-surface2 text-text-primary
                     placeholder-text-muted
                     disabled:bg-dark-surface3 disabled:cursor-not-allowed disabled:shadow-none
                     transition-all duration-hover resize-none"
            rows={1}
            maxLength={10000}
          />
          <HoverGlow color="cyan" disabled={isDisabled || !inputValue.trim()} className="rounded-lg">
            <button
              onClick={handleSend}
              disabled={isDisabled || !inputValue.trim()}
              className="px-6 py-4 bg-accent-cyan text-dark-base rounded-lg font-semibold
                       hover:bg-accent-cyan-hover focus:outline-none focus:ring-2 focus:ring-accent-cyan
                       disabled:bg-dark-surface3 disabled:text-text-muted disabled:cursor-not-allowed
                       transition-colors duration-hover"
            >
              Send
            </button>
          </HoverGlow>
        </div>
        <div className="mt-2 text-xs font-normal leading-tight text-text-secondary">
          {inputValue.length}/10,000 characters
        </div>
      </div>
    </div>
  );
}
