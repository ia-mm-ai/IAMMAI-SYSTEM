/** @type {import('tailwindcss').Config} */
const sharedConfig = require('../../packages/shared/tailwind.config.base');

module.exports = {
  ...sharedConfig,
  content: [
    './src/**/*.{js,ts,jsx,tsx,mdx}',
    '../../packages/shared/src/**/*.{js,ts,jsx,tsx,mdx}',
  ],
};
