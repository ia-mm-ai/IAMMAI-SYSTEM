/**
 * Session card component with state, user count, and action buttons
 * @see specs/001-ephemeral-kernel/tasks.md#T047
 */

import { StatusBadge } from '@iammai-sandbox/shared';
import type { SessionState } from '@iammai-sandbox/shared';

interface SessionCardProps {
  id: string;
  name: string;
  state: SessionState;
  tokenCount: number;
  userCount: number;
  createdAt: string;
  startedAt: string | null;
  endedAt: string | null;
  onStart?: () => void;
  onEnd?: () => void;
  onClick?: () => void;
  isLoading?: boolean;
}

export function SessionCard({
  id,
  name,
  state,
  tokenCount,
  userCount,
  createdAt,
  startedAt,
  endedAt,
  onStart,
  onEnd,
  onClick,
  isLoading,
}: SessionCardProps): JSX.Element {
  const formatDate = (dateStr: string): string => {
    return new Date(dateStr).toLocaleString();
  };

  return (
    <div
      className={`bg-dark-surface1 border border-accent-cyan/20 rounded-lg p-6 my-4 transition-all duration-hover shadow-glow-cyan-subtle ${
        onClick ? 'cursor-pointer hover:border-accent-cyan/40 hover:shadow-glow-cyan-medium' : ''
      }`}
      onClick={onClick}
    >
      <div className="flex items-start justify-between">
        <div className="flex-1">
          <div className="flex items-center space-x-4">
            <h3 className="text-lg font-medium text-text-primary">{name}</h3>
            <StatusBadge state={state} size="sm" />
          </div>

          <p className="mt-2 text-sm text-text-secondary">ID: {id}</p>
        </div>
      </div>

      {/* Stats */}
      <div className="mt-6 grid grid-cols-2 gap-4">
        <div>
          <p className="text-sm text-text-secondary">Tokens Claimed</p>
          <p className="text-lg font-semibold text-text-primary">{tokenCount}</p>
        </div>
        <div>
          <p className="text-sm text-text-secondary">Users Joined</p>
          <p className="text-lg font-semibold text-text-primary">{userCount}</p>
        </div>
      </div>

      {/* Timestamps */}
      <div className="mt-4 space-y-1 text-sm text-text-secondary">
        <p>Created: {formatDate(createdAt)}</p>
        {startedAt && <p>Started: {formatDate(startedAt)}</p>}
        {endedAt && <p>Ended: {formatDate(endedAt)}</p>}
      </div>

      {/* Actions */}
      {(onStart || onEnd) && (
        <div className="mt-4 flex space-x-2" onClick={(e) => e.stopPropagation()}>
          {state === 'CREATED' && onStart && (
            <button
              onClick={onStart}
              disabled={isLoading}
              className="flex-1 px-4 py-2 bg-accent-cyan text-dark-base rounded-md hover:bg-accent-cyan-hover disabled:opacity-50 disabled:cursor-not-allowed text-sm font-medium transition-all duration-hover shadow-glow-cyan-medium hover:shadow-glow-cyan-bright disabled:shadow-none"
            >
              {isLoading ? 'Starting...' : 'Start Session'}
            </button>
          )}
          {state === 'ACTIVE' && onEnd && (
            <button
              onClick={onEnd}
              disabled={isLoading}
              className="flex-1 px-4 py-2 bg-error text-dark-base rounded-md hover:bg-error/90 disabled:opacity-50 disabled:cursor-not-allowed text-sm font-medium transition-all duration-hover shadow-glow-error-medium hover:shadow-glow-error-bright disabled:shadow-none"
            >
              {isLoading ? 'Ending...' : 'End Session'}
            </button>
          )}
        </div>
      )}
    </div>
  );
}
