/**
 * Containment (HOLD/RELEASE) status card.
 * Shows current containment state and history.
 * Provides HOLD/RELEASE governance action buttons.
 */

import { useState } from 'react';
import { GovernanceActionDialog } from './GovernanceActionDialog';

interface ContainmentRecord {
  containment_id: string;
  target_state_ref: string;
  action: 'HOLD' | 'RELEASE';
  actor_ref: string;
  reason: string;
  recorded_at: string;
}

interface ContainmentStatusCardProps {
  records: ContainmentRecord[];
  isHeld: boolean;
  matterRef: string;
  onActionComplete?: () => void;
  className?: string;
}

function extractId(ref: string): string {
  const parts = ref.split(':');
  return parts[parts.length - 1]?.slice(0, 8) ?? ref;
}

export function ContainmentStatusCard({
  records,
  isHeld,
  matterRef,
  onActionComplete,
  className = '',
}: ContainmentStatusCardProps): JSX.Element {
  const [dialogType, setDialogType] = useState<'hold' | 'release' | null>(null);

  const handleDialogComplete = (success: boolean) => {
    setDialogType(null);
    if (success && onActionComplete) onActionComplete();
  };

  return (
    <>
      <div className={`rounded-lg border bg-dark-surface1 p-4 ${
        isHeld ? 'border-accent-magenta/30' : 'border-dark-border'
      } ${className}`}>
        <h3 className="text-sm font-semibold text-text-primary mb-3">Containment</h3>

        {/* Status indicator */}
        <div className="flex items-center justify-between mb-4">
          <div className="flex items-center gap-3">
            <div className={`w-3 h-3 rounded-full ${
              isHeld
                ? 'bg-accent-magenta shadow-glow-magenta-medium animate-pulse'
                : 'bg-success/50'
            }`} />
            <span className={`text-sm font-mono font-semibold ${
              isHeld ? 'text-accent-magenta' : 'text-success/70'
            }`}>
              {isHeld ? 'HELD' : 'FREE'}
            </span>
          </div>

          {/* Governance action buttons */}
          <div className="flex gap-2">
            {!isHeld ? (
              <button
                onClick={() => setDialogType('hold')}
                className="px-3 py-1 text-xs font-mono font-semibold text-accent-magenta border border-accent-magenta/30
                         rounded hover:bg-accent-magenta/10 transition-colors"
              >
                HOLD
              </button>
            ) : (
              <button
                onClick={() => setDialogType('release')}
                className="px-3 py-1 text-xs font-mono font-semibold text-accent-blue border border-accent-blue/30
                         rounded hover:bg-accent-blue/10 transition-colors"
              >
                RELEASE
              </button>
            )}
          </div>
        </div>

        {/* History */}
        {records.length > 0 ? (
          <div className="space-y-2 max-h-48 overflow-y-auto">
            {[...records].reverse().map(record => (
              <div key={record.containment_id} className="flex items-start gap-2 text-xs border-b border-dark-border pb-2 last:border-b-0">
                <span className={`shrink-0 px-1 py-0.5 text-[10px] font-mono font-bold rounded ${
                  record.action === 'HOLD'
                    ? 'text-accent-magenta border border-accent-magenta/30'
                    : 'text-accent-blue border border-accent-blue/30'
                }`}>
                  {record.action}
                </span>
                <div className="flex-1 min-w-0">
                  <span className="font-mono text-text-primary">{extractId(record.actor_ref)}</span>
                  <p className="text-text-muted truncate">{record.reason}</p>
                </div>
                <span className="text-text-muted text-[10px] font-mono shrink-0">
                  {new Date(record.recorded_at).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                </span>
              </div>
            ))}
          </div>
        ) : (
          <p className="text-xs text-text-muted">No containment history.</p>
        )}
      </div>

      {/* Governance dialog */}
      {dialogType && (
        <GovernanceActionDialog
          type={dialogType}
          matterRef={matterRef}
          onComplete={handleDialogComplete}
          onCancel={() => setDialogType(null)}
        />
      )}
    </>
  );
}
