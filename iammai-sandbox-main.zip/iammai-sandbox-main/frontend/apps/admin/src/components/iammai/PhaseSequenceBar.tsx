/**
 * 9-phase canonical sequence visualizer.
 * Shows the IAMMAI phase chain with preparation/standing boundary.
 */

import { motion } from 'framer-motion';

const PHASES = [
  'signal', 'acceptance', 'scope', 'presence', 'threshold',
  'truth', 'continuity', 'decision', 'consequence',
] as const;

const PHASE_LABELS: Record<string, string> = {
  signal: 'SIG',
  acceptance: 'ACC',
  scope: 'SCP',
  presence: 'PRS',
  threshold: 'THR',
  truth: 'TRU',
  continuity: 'CON',
  decision: 'DEC',
  consequence: 'CSQ',
};

const PHASE_ORDINAL: Record<string, number> = {
  signal: 1, acceptance: 2, scope: 3, presence: 4, threshold: 5,
  truth: 6, continuity: 7, decision: 8, consequence: 9,
};

interface PhaseSequenceBarProps {
  currentPhase: string | null;
  isHeld: boolean;
  completedPhases?: string[];
  className?: string;
}

export function PhaseSequenceBar({
  currentPhase,
  isHeld,
  completedPhases,
  className = '',
}: PhaseSequenceBarProps): JSX.Element {
  const currentOrdinal = currentPhase ? PHASE_ORDINAL[currentPhase] ?? 0 : 0;

  const completed = completedPhases
    ? new Set(completedPhases)
    : new Set(PHASES.filter((_, i) => i + 1 < currentOrdinal));

  return (
    <div className={`rounded-lg border border-dark-border bg-dark-surface1 p-6 ${className}`}>
      {/* Regime labels */}
      <div className="flex items-center mb-4">
        <div className="flex-1 text-center">
          <span className="text-[10px] font-mono font-medium tracking-widest text-text-muted uppercase">
            Preparation
          </span>
        </div>
        <div className="w-px" />
        <div className="flex-1 text-center">
          <span className="text-[10px] font-mono font-medium tracking-widest text-text-muted uppercase">
            Standing
          </span>
        </div>
      </div>

      {/* Phase nodes */}
      <div className="flex items-center gap-0">
        {PHASES.map((phase, index) => {
          const ordinal = index + 1;
          const isCurrent = phase === currentPhase;
          const isCompleted = completed.has(phase);
          const isFuture = !isCurrent && !isCompleted;
          const isThresholdBoundary = index === 4; // between threshold and truth

          return (
            <div key={phase} className="flex items-center flex-1">
              {/* Node */}
              <motion.div
                initial={{ scale: 0, opacity: 0 }}
                animate={{ scale: 1, opacity: 1 }}
                transition={{ delay: index * 0.06, duration: 0.3 }}
                className="flex flex-col items-center flex-1"
              >
                <div className="relative">
                  {/* Glow ring for current */}
                  {isCurrent && (
                    <motion.div
                      animate={{ opacity: [0.4, 1, 0.4] }}
                      transition={{ duration: 2, repeat: Infinity }}
                      className={`absolute -inset-1.5 rounded-full ${
                        isHeld
                          ? 'bg-accent-magenta/20 shadow-glow-magenta-subtle'
                          : 'bg-accent-cyan/20 shadow-glow-cyan-subtle'
                      }`}
                    />
                  )}

                  {/* Node circle */}
                  <div
                    className={`relative w-8 h-8 rounded-full border-2 flex items-center justify-center transition-all ${
                      isCurrent
                        ? isHeld
                          ? 'bg-accent-magenta border-accent-magenta shadow-glow-magenta-medium'
                          : 'bg-accent-cyan border-accent-cyan shadow-glow-cyan-medium'
                        : isCompleted
                        ? 'bg-accent-cyan/80 border-accent-cyan/60'
                        : 'bg-dark-surface2 border-dark-border'
                    }`}
                  >
                    <span
                      className={`text-[9px] font-mono font-bold ${
                        isCurrent || isCompleted ? 'text-dark-base' : 'text-text-muted'
                      }`}
                    >
                      {ordinal}
                    </span>
                  </div>
                </div>

                {/* Phase label */}
                <span
                  className={`mt-2 text-[10px] font-mono ${
                    isCurrent
                      ? isHeld
                        ? 'text-accent-magenta font-bold'
                        : 'text-accent-cyan font-bold'
                      : isCompleted
                      ? 'text-text-secondary'
                      : 'text-text-muted'
                  }`}
                >
                  {PHASE_LABELS[phase]}
                </span>
              </motion.div>

              {/* Connector line (not after last node) */}
              {index < PHASES.length - 1 && (
                <div className="relative flex items-center" style={{ width: '2px', minWidth: '2px' }}>
                  {/* Preparation/Standing boundary */}
                  {isThresholdBoundary && (
                    <div className="absolute -top-8 bottom-6 w-px bg-accent-magenta/40 left-0" />
                  )}
                  <div
                    className={`h-0.5 w-full ${
                      isCompleted || (isCurrent && index < PHASES.length - 1)
                        ? 'bg-accent-cyan/50'
                        : 'bg-dark-border'
                    }`}
                  />
                </div>
              )}
            </div>
          );
        })}
      </div>

      {/* Phase full name below */}
      {currentPhase && (
        <div className="mt-4 text-center">
          <span className={`text-sm font-mono font-medium ${isHeld ? 'text-accent-magenta' : 'text-accent-cyan'}`}>
            {currentPhase.toUpperCase()}
          </span>
          {isHeld && (
            <span className="ml-2 px-1.5 py-0.5 text-[10px] font-mono font-bold text-accent-magenta border border-accent-magenta/40 rounded bg-accent-magenta/10">
              HELD
            </span>
          )}
        </div>
      )}
    </div>
  );
}
