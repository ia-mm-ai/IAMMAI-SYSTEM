/**
 * 10-category IAMMAI conformance assessment grid.
 * Expandable category cards showing pass/fail/na with findings.
 */

import { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';

interface CategoryAssessment {
  category: string;
  result: 'PASS' | 'FAIL' | 'NOT_APPLICABLE';
  details: string;
  findings: string[];
}

interface ConformanceReport {
  matter_ref: string;
  overall: 'CONFORMANT' | 'NON_CONFORMANT' | 'PARTIAL';
  assessed_at: string;
  categories: CategoryAssessment[];
  pass_count: number;
  fail_count: number;
  na_count: number;
}

interface ConformanceGridProps {
  report: ConformanceReport;
  className?: string;
}

const OVERALL_STYLES: Record<ConformanceReport['overall'], string> = {
  CONFORMANT: 'text-success bg-success/10 border-success/30 shadow-glow-cyan-subtle',
  PARTIAL: 'text-warning bg-warning/10 border-warning/30',
  NON_CONFORMANT: 'text-error bg-error/10 border-error/30',
};

const CATEGORY_LABELS: Record<string, string> = {
  PHASE_INTEGRITY: 'Phase Integrity',
  STATE_FAMILY: 'State Family',
  LINEAGE_PRESERVATION: 'Lineage Preservation',
  RESOLUTION_LEGALITY: 'Resolution Legality',
  CONTAINMENT_ORTHOGONALITY: 'Containment Orthogonality',
  GOVERNANCE_ATTRIBUTION: 'Governance Attribution',
  WITNESS_COVERAGE: 'Witness Coverage',
  VALIDATION_COVERAGE: 'Validation Coverage',
  CONTRIBUTION_COMPLETENESS: 'Contribution Completeness',
  AUDIT_ANSWERABILITY: 'Audit Answerability',
};

function CategoryCard({ assessment }: { assessment: CategoryAssessment }): JSX.Element {
  const [expanded, setExpanded] = useState(assessment.result === 'FAIL');
  const hasFindings = assessment.findings.length > 0;

  const resultColor =
    assessment.result === 'PASS'
      ? 'text-success bg-success/10'
      : assessment.result === 'FAIL'
      ? 'text-error bg-error/10'
      : 'text-text-muted bg-dark-surface3';

  const dotColor =
    assessment.result === 'PASS'
      ? 'bg-success'
      : assessment.result === 'FAIL'
      ? 'bg-error animate-pulse'
      : 'bg-text-muted';

  return (
    <div
      className={`rounded-lg border bg-dark-surface1 transition-colors duration-hover ${
        assessment.result === 'FAIL'
          ? 'border-error/30 hover:border-error/50'
          : 'border-dark-border hover:border-accent-cyan/20'
      }`}
    >
      <button
        onClick={() => hasFindings && setExpanded(prev => !prev)}
        disabled={!hasFindings}
        className="w-full flex items-center justify-between px-4 py-3 text-left disabled:cursor-default"
      >
        <div className="flex items-center gap-3">
          <span className={`w-2 h-2 rounded-full shrink-0 ${dotColor}`} />
          <span className="text-sm font-medium text-text-primary">
            {CATEGORY_LABELS[assessment.category] ?? assessment.category}
          </span>
        </div>

        <div className="flex items-center gap-3">
          <span className={`px-2 py-0.5 text-xs font-mono font-semibold rounded ${resultColor}`}>
            {assessment.result === 'NOT_APPLICABLE' ? 'N/A' : assessment.result}
          </span>
          {hasFindings && (
            <motion.svg
              animate={{ rotate: expanded ? 180 : 0 }}
              transition={{ duration: 0.2 }}
              className="w-4 h-4 text-text-muted shrink-0"
              fill="none"
              stroke="currentColor"
              viewBox="0 0 24 24"
            >
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 9l-7 7-7-7" />
            </motion.svg>
          )}
        </div>
      </button>

      <AnimatePresence initial={false}>
        {expanded && hasFindings && (
          <motion.div
            key="findings"
            initial={{ height: 0, opacity: 0 }}
            animate={{ height: 'auto', opacity: 1 }}
            exit={{ height: 0, opacity: 0 }}
            transition={{ duration: 0.25, ease: [0.22, 1, 0.36, 1] }}
            className="overflow-hidden"
          >
            <div className="px-4 pb-3 border-t border-dark-border">
              <p className="pt-2 pb-1 text-xs text-text-secondary">{assessment.details}</p>
              <ul className="space-y-1">
                {assessment.findings.map((finding, i) => (
                  <li key={i} className="flex items-start gap-2 text-xs text-text-secondary">
                    <span className="text-error mt-0.5 shrink-0">-</span>
                    <span className="font-mono">{finding}</span>
                  </li>
                ))}
              </ul>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}

export function ConformanceGrid({ report, className = '' }: ConformanceGridProps): JSX.Element {
  return (
    <div className={className}>
      {/* Overall status */}
      <div className="flex items-center gap-4 mb-4">
        <div
          className={`inline-flex items-center gap-2 px-4 py-2 rounded-lg border text-sm font-semibold font-mono ${OVERALL_STYLES[report.overall]}`}
        >
          <span
            className={`w-2 h-2 rounded-full ${
              report.overall === 'CONFORMANT'
                ? 'bg-success'
                : report.overall === 'PARTIAL'
                ? 'bg-warning animate-pulse'
                : 'bg-error animate-pulse'
            }`}
          />
          {report.overall}
        </div>
        <span className="text-xs text-text-muted font-mono">
          {report.pass_count} pass | {report.fail_count} fail | {report.na_count} n/a
        </span>
      </div>

      {/* Category cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-2">
        {report.categories.map(cat => (
          <CategoryCard key={cat.category} assessment={cat} />
        ))}
      </div>
    </div>
  );
}
