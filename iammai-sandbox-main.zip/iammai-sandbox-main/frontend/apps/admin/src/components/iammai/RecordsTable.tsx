/**
 * Tabbed records table for witnesses, validations, and contributions.
 */

import { useState } from 'react';

interface WitnessArtifact {
  witness_id: string;
  witness_type: string;
  target_ref: string;
  observed_at: string;
  claims: string[];
  non_claims: Record<string, boolean> | null;
  actor_ref: string | null;
}

interface ValidationArtifact {
  validation_id: string;
  validation_type: string;
  target_ref: string;
  outcome: string;
  checked_at: string;
  actor_ref: string | null;
}

interface ContributionRecord {
  contribution_id: string;
  actor_ref: string;
  role: string;
  recorded_at: string;
}

interface RecordsTableProps {
  witnesses: WitnessArtifact[];
  validations: ValidationArtifact[];
  contributions: ContributionRecord[];
  className?: string;
}

type Tab = 'witnesses' | 'validations' | 'contributions';

const OUTCOME_COLORS: Record<string, string> = {
  pass: 'text-success bg-success/10',
  fail: 'text-error bg-error/10',
  blocked: 'text-accent-magenta bg-accent-magenta/10',
  indeterminate: 'text-warning bg-warning/10',
};

function extractId(ref: string): string {
  const parts = ref.split(':');
  return parts[parts.length - 1]?.slice(0, 8) ?? ref;
}

function NonClaimsCheck({ nonClaims }: { nonClaims: Record<string, boolean> | null }): JSX.Element {
  const required = [
    'not_authorship', 'not_semantic_source', 'not_final_authority',
    'not_automatic_truth_creation', 'not_governance_force',
  ];
  const allPresent = nonClaims && required.every(k => nonClaims[k] === true);

  return (
    <span className={`text-[10px] font-mono ${allPresent ? 'text-success' : 'text-error'}`}>
      {allPresent ? '5/5' : 'MISSING'}
    </span>
  );
}

export function RecordsTable({ witnesses, validations, contributions, className = '' }: RecordsTableProps): JSX.Element {
  const [tab, setTab] = useState<Tab>('witnesses');

  const tabs: { key: Tab; label: string; count: number }[] = [
    { key: 'witnesses', label: 'Witnesses', count: witnesses.length },
    { key: 'validations', label: 'Validations', count: validations.length },
    { key: 'contributions', label: 'Contributions', count: contributions.length },
  ];

  return (
    <div className={`rounded-lg border border-dark-border bg-dark-surface1 ${className}`}>
      {/* Tab bar */}
      <div className="flex border-b border-dark-border">
        {tabs.map(t => (
          <button
            key={t.key}
            onClick={() => setTab(t.key)}
            className={`flex-1 px-4 py-2.5 text-xs font-medium transition-colors ${
              tab === t.key
                ? 'text-accent-cyan border-b-2 border-accent-cyan bg-dark-surface2'
                : 'text-text-secondary hover:text-text-primary'
            }`}
          >
            {t.label} <span className="ml-1 font-mono text-text-muted">({t.count})</span>
          </button>
        ))}
      </div>

      {/* Content */}
      <div className="max-h-80 overflow-y-auto">
        {tab === 'witnesses' && (
          witnesses.length === 0 ? (
            <p className="p-4 text-xs text-text-muted text-center">No witness artifacts.</p>
          ) : (
            <table className="w-full text-xs">
              <thead>
                <tr className="border-b border-dark-border text-text-muted">
                  <th className="text-left px-3 py-2 font-medium">Type</th>
                  <th className="text-left px-3 py-2 font-medium">Actor</th>
                  <th className="text-left px-3 py-2 font-medium">Non-Claims</th>
                  <th className="text-left px-3 py-2 font-medium">Time</th>
                </tr>
              </thead>
              <tbody>
                {witnesses.map(w => (
                  <tr key={w.witness_id} className="border-b border-dark-border last:border-b-0">
                    <td className="px-3 py-2 font-mono text-accent-cyan">{w.witness_type}</td>
                    <td className="px-3 py-2 font-mono text-text-primary">{w.actor_ref ? extractId(w.actor_ref) : '-'}</td>
                    <td className="px-3 py-2"><NonClaimsCheck nonClaims={w.non_claims} /></td>
                    <td className="px-3 py-2 text-text-muted font-mono">
                      {new Date(w.observed_at).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          )
        )}

        {tab === 'validations' && (
          validations.length === 0 ? (
            <p className="p-4 text-xs text-text-muted text-center">No validation artifacts.</p>
          ) : (
            <table className="w-full text-xs">
              <thead>
                <tr className="border-b border-dark-border text-text-muted">
                  <th className="text-left px-3 py-2 font-medium">Type</th>
                  <th className="text-left px-3 py-2 font-medium">Outcome</th>
                  <th className="text-left px-3 py-2 font-medium">Actor</th>
                  <th className="text-left px-3 py-2 font-medium">Time</th>
                </tr>
              </thead>
              <tbody>
                {validations.map(v => (
                  <tr key={v.validation_id} className="border-b border-dark-border last:border-b-0">
                    <td className="px-3 py-2 font-mono text-text-primary">{v.validation_type}</td>
                    <td className="px-3 py-2">
                      <span className={`px-1.5 py-0.5 text-[10px] font-mono font-semibold rounded ${OUTCOME_COLORS[v.outcome] ?? ''}`}>
                        {v.outcome.toUpperCase()}
                      </span>
                    </td>
                    <td className="px-3 py-2 font-mono text-text-primary">{v.actor_ref ? extractId(v.actor_ref) : '-'}</td>
                    <td className="px-3 py-2 text-text-muted font-mono">
                      {new Date(v.checked_at).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          )
        )}

        {tab === 'contributions' && (
          contributions.length === 0 ? (
            <p className="p-4 text-xs text-text-muted text-center">No contribution records.</p>
          ) : (
            <table className="w-full text-xs">
              <thead>
                <tr className="border-b border-dark-border text-text-muted">
                  <th className="text-left px-3 py-2 font-medium">Actor</th>
                  <th className="text-left px-3 py-2 font-medium">Role</th>
                  <th className="text-left px-3 py-2 font-medium">Time</th>
                </tr>
              </thead>
              <tbody>
                {contributions.map(c => (
                  <tr key={c.contribution_id} className="border-b border-dark-border last:border-b-0">
                    <td className="px-3 py-2 font-mono text-text-primary">{extractId(c.actor_ref)}</td>
                    <td className="px-3 py-2">
                      <span className="px-1.5 py-0.5 text-[10px] font-mono font-semibold text-accent-cyan border border-accent-cyan/30 rounded">
                        {c.role}
                      </span>
                    </td>
                    <td className="px-3 py-2 text-text-muted font-mono">
                      {new Date(c.recorded_at).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          )
        )}
      </div>
    </div>
  );
}
