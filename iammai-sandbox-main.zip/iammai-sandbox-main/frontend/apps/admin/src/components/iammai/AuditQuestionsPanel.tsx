/**
 * IAMMAI 8 Audit Questions accordion panel.
 * Expandable answers with type-specific renderers.
 */

import { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';

interface AuditAnswer {
  question: string;
  [key: string]: unknown;
}

interface AuditQuestionsPanelProps {
  answers: AuditAnswer[];
  className?: string;
}

const QUESTION_TEXT: Record<string, string> = {
  Q1_CURRENT_PHASE: 'What phase is this matter in?',
  Q2_ADMISSIBILITY: 'What made it admissible?',
  Q3_STANDING: 'What stands (current standing-state)?',
  Q4_RESOLUTION: 'What changed and how was it resolved?',
  Q5_LINEAGE: 'What is the predecessor/successor lineage?',
  Q6_ATTRIBUTION: 'Who acted, with what authority, and on what basis?',
  Q7_CONTRIBUTIONS: 'What contribution roles exist?',
  Q8_PRESERVATION: 'What record preserves it?',
};

function summarize(answer: AuditAnswer): string {
  switch (answer.question) {
    case 'Q1_CURRENT_PHASE':
      return answer.phase
        ? `${(answer.phase as string).toUpperCase()} (${answer.family}, ordinal ${answer.ordinal})${answer.isHeld ? ' — HELD' : ''}`
        : 'No phase recorded';
    case 'Q2_ADMISSIBILITY':
      return answer.admissible ? 'Admissible — signal state exists' : 'Not admissible';
    case 'Q3_STANDING':
      return answer.hasStanding
        ? `Standing at ${(answer.currentStandingPhase as string)?.toUpperCase() ?? 'unknown'} (${(answer.standingStates as unknown[])?.length ?? 0} standing states)`
        : 'No standing state';
    case 'Q4_RESOLUTION':
      return answer.resolved ? `Resolved via ${answer.resolutionType}` : 'Unresolved';
    case 'Q5_LINEAGE':
      return `${answer.stateCount} state(s) in chain${answer.hasExternalPredecessor ? ' (external predecessor)' : ''}`;
    case 'Q6_ATTRIBUTION': {
      const actions = answer.actions as unknown[];
      const actors = answer.uniqueActors as string[];
      return `${actions?.length ?? 0} action(s) by ${actors?.length ?? 0} actor(s)`;
    }
    case 'Q7_CONTRIBUTIONS': {
      const contribs = answer.contributions as unknown[];
      return `${contribs?.length ?? 0} contribution(s)`;
    }
    case 'Q8_PRESERVATION':
      return `${answer.totalRecords} total records preserved`;
    default:
      return 'Unknown';
  }
}

function renderDetail(answer: AuditAnswer): JSX.Element {
  const entries = Object.entries(answer).filter(([k]) => k !== 'question');

  // For Q8, show record counts in a compact grid
  if (answer.question === 'Q8_PRESERVATION') {
    const countKeys = entries.filter(([k]) => k.endsWith('Count'));
    return (
      <div className="grid grid-cols-2 gap-x-4 gap-y-1">
        {countKeys.map(([key, value]) => (
          <div key={key} className="flex justify-between text-xs">
            <span className="text-text-muted">{key.replace('Count', '').replace(/([A-Z])/g, ' $1').trim()}</span>
            <span className="font-mono text-text-primary">{String(value)}</span>
          </div>
        ))}
      </div>
    );
  }

  // For Q6, show actions table
  if (answer.question === 'Q6_ATTRIBUTION' && Array.isArray(answer.actions)) {
    return (
      <div className="space-y-2">
        {(answer.actions as Array<Record<string, unknown>>).map((action, i) => (
          <div key={i} className="px-2 py-1.5 rounded bg-dark-base border border-dark-border text-xs font-mono">
            <span className="text-accent-cyan">{String(action.action_type)}</span>
            <span className="text-text-muted"> by </span>
            <span className="text-text-primary">{String(action.actor_ref)}</span>
            <span className="text-text-muted"> ({String(action.authority_class)})</span>
          </div>
        ))}
      </div>
    );
  }

  // For Q7, show contributions by actor
  if (answer.question === 'Q7_CONTRIBUTIONS' && answer.rolesByActor) {
    const rolesByActor = answer.rolesByActor as Record<string, string[]>;
    return (
      <div className="space-y-1">
        {Object.entries(rolesByActor).map(([actor, roles]) => (
          <div key={actor} className="flex items-center gap-2 text-xs">
            <span className="font-mono text-text-primary">{actor}</span>
            <div className="flex gap-1">
              {roles.map(role => (
                <span key={role} className="px-1 py-0.5 text-[10px] font-mono border border-accent-cyan/30 rounded text-accent-cyan">
                  {role}
                </span>
              ))}
            </div>
          </div>
        ))}
      </div>
    );
  }

  // Generic fallback
  return (
    <pre className="text-xs font-mono text-text-secondary bg-dark-base rounded border border-dark-border p-2 overflow-x-auto max-h-48">
      {JSON.stringify(
        Object.fromEntries(entries),
        null,
        2
      )}
    </pre>
  );
}

function QuestionCard({ answer, index }: { answer: AuditAnswer; index: number }): JSX.Element {
  const [expanded, setExpanded] = useState(false);
  const qNum = `Q${index + 1}`;

  return (
    <div className="rounded-lg border border-dark-border bg-dark-surface1">
      <button
        onClick={() => setExpanded(prev => !prev)}
        className="w-full flex items-start gap-3 px-4 py-3 text-left"
      >
        <span className="shrink-0 text-xs font-mono font-bold text-accent-cyan mt-0.5">{qNum}</span>
        <div className="flex-1 min-w-0">
          <p className="text-sm font-medium text-text-primary">
            {QUESTION_TEXT[answer.question] ?? answer.question}
          </p>
          <p className="mt-0.5 text-xs text-text-secondary truncate">
            {summarize(answer)}
          </p>
        </div>
        <motion.svg
          animate={{ rotate: expanded ? 180 : 0 }}
          transition={{ duration: 0.2 }}
          className="w-4 h-4 text-text-muted shrink-0 mt-1"
          fill="none"
          stroke="currentColor"
          viewBox="0 0 24 24"
        >
          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 9l-7 7-7-7" />
        </motion.svg>
      </button>

      <AnimatePresence initial={false}>
        {expanded && (
          <motion.div
            key="detail"
            initial={{ height: 0, opacity: 0 }}
            animate={{ height: 'auto', opacity: 1 }}
            exit={{ height: 0, opacity: 0 }}
            transition={{ duration: 0.25, ease: [0.22, 1, 0.36, 1] }}
            className="overflow-hidden"
          >
            <div className="px-4 pb-3 border-t border-dark-border pt-3">
              {renderDetail(answer)}
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}

export function AuditQuestionsPanel({ answers, className = '' }: AuditQuestionsPanelProps): JSX.Element {
  return (
    <div className={className}>
      <h3 className="text-sm font-semibold text-text-primary mb-3">
        8 Audit Questions
      </h3>
      <div className="space-y-2">
        {answers.map((answer, i) => (
          <QuestionCard key={answer.question} answer={answer} index={i} />
        ))}
      </div>
    </div>
  );
}
