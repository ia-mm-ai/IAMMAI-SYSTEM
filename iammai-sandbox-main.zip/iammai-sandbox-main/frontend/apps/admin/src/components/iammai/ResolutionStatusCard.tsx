/**
 * Resolution status card.
 * Shows FINALIZE/INVALIDATE/EVOLVE or PENDING status.
 * Provides INVALIDATE/EVOLVE governance action buttons when matter is PENDING.
 */

import { useState } from 'react';
import Link from 'next/link';
import { GovernanceActionDialog } from './GovernanceActionDialog';

interface ResolutionStatusCardProps {
  resolved: boolean;
  resolutionType: string | null;
  resolvingActorRef: string | null;
  resolvingAuthorityClass: string | null;
  successorMatterRef: string | null;
  matterRef: string;
  onActionComplete?: () => void;
  className?: string;
}

const RESOLUTION_STYLES: Record<string, string> = {
  FINALIZE: 'text-success border-success/30 bg-success/10',
  INVALIDATE: 'text-error border-error/30 bg-error/10',
  EVOLVE: 'text-accent-blue border-accent-blue/30 bg-accent-blue/10',
};

function extractId(ref: string): string {
  const parts = ref.split(':');
  return parts[parts.length - 1]?.slice(0, 8) ?? ref;
}

export function ResolutionStatusCard({
  resolved,
  resolutionType,
  resolvingActorRef,
  resolvingAuthorityClass,
  successorMatterRef,
  matterRef,
  onActionComplete,
  className = '',
}: ResolutionStatusCardProps): JSX.Element {
  const [dialogType, setDialogType] = useState<'invalidate' | 'evolve' | null>(null);
  const style = resolutionType ? RESOLUTION_STYLES[resolutionType] ?? '' : '';

  const handleDialogComplete = (success: boolean) => {
    setDialogType(null);
    if (success && onActionComplete) onActionComplete();
  };

  return (
    <>
      <div className={`rounded-lg border bg-dark-surface1 p-4 ${
        resolved ? 'border-dark-border' : 'border-dark-border'
      } ${className}`}>
        <h3 className="text-sm font-semibold text-text-primary mb-3">Resolution</h3>

        {resolved && resolutionType ? (
          <div>
            <div className="flex items-center gap-3 mb-3">
              <span className={`px-2 py-1 text-xs font-mono font-bold rounded border ${style}`}>
                {resolutionType}
              </span>
            </div>

            {resolvingActorRef && (
              <div className="text-xs text-text-secondary mb-1">
                <span className="text-text-muted">by </span>
                <span className="font-mono text-text-primary">{extractId(resolvingActorRef)}</span>
                {resolvingAuthorityClass && (
                  <span className="text-text-muted"> ({resolvingAuthorityClass})</span>
                )}
              </div>
            )}

            {resolutionType === 'EVOLVE' && successorMatterRef && (
              <div className="mt-3 pt-3 border-t border-dark-border">
                <span className="text-xs text-text-muted">Successor: </span>
                <Link
                  href={`/iammai/${encodeURIComponent(successorMatterRef)}`}
                  className="text-xs font-mono text-accent-blue hover:text-accent-blue/80 underline"
                >
                  {extractId(successorMatterRef)}
                </Link>
              </div>
            )}
          </div>
        ) : (
          <div>
            <div className="flex items-center justify-between mb-3">
              <div className="flex items-center gap-3">
                <div className="w-3 h-3 rounded-full bg-text-muted/30" />
                <span className="text-sm font-mono text-text-muted">PENDING</span>
              </div>
            </div>

            {/* Governance action buttons — only when PENDING */}
            <div className="flex gap-2 mt-2">
              <button
                onClick={() => setDialogType('invalidate')}
                className="px-3 py-1 text-xs font-mono font-semibold text-error border border-error/30
                         rounded hover:bg-error/10 transition-colors"
                title="Remove standing without erasing trace"
              >
                INVALIDATE
              </button>
              <button
                onClick={() => setDialogType('evolve')}
                className="px-3 py-1 text-xs font-mono font-semibold text-accent-blue border border-accent-blue/30
                         rounded hover:bg-accent-blue/10 transition-colors"
                title="Create lawful successor matter"
              >
                EVOLVE
              </button>
            </div>
          </div>
        )}
      </div>

      {/* Governance dialog */}
      {dialogType && (
        <GovernanceActionDialog
          type={dialogType}
          matterRef={matterRef}
          onComplete={handleDialogComplete}
          onCancel={() => setDialogType(null)}
        />
      )}
    </>
  );
}
