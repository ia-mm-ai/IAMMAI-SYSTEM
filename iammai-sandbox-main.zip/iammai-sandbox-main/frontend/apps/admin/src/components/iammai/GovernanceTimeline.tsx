/**
 * Real-time governance action timeline.
 * Color-coded by action type with attribution details.
 */

import { motion } from 'framer-motion';

interface GovernanceAction {
  governance_action_id: string;
  action_type: string;
  authority_class: string;
  actor_ref: string;
  legitimacy_basis_ref: string;
  matter_ref: string;
  acted_at: string;
}

interface GovernanceTimelineProps {
  actions: GovernanceAction[];
  className?: string;
}

const ACTION_COLORS: Record<string, string> = {
  authorize: 'bg-accent-cyan border-accent-cyan/40 text-accent-cyan',
  deny: 'bg-error border-error/40 text-error',
  hold: 'bg-accent-magenta border-accent-magenta/40 text-accent-magenta',
  release: 'bg-accent-blue border-accent-blue/40 text-accent-blue',
  finalize: 'bg-success border-success/40 text-success',
  invalidate: 'bg-error border-error/40 text-error',
  evolve: 'bg-accent-blue border-accent-blue/40 text-accent-blue',
};

const DOT_COLORS: Record<string, string> = {
  authorize: 'bg-accent-cyan shadow-glow-cyan-subtle',
  deny: 'bg-error',
  hold: 'bg-accent-magenta shadow-glow-magenta-subtle',
  release: 'bg-accent-blue',
  finalize: 'bg-success',
  invalidate: 'bg-error',
  evolve: 'bg-accent-blue shadow-glow-blue-subtle',
};

function formatTime(dateStr: string): string {
  try {
    return new Date(dateStr).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit' });
  } catch {
    return dateStr;
  }
}

function extractId(ref: string): string {
  const parts = ref.split(':');
  return parts[parts.length - 1]?.slice(0, 8) ?? ref;
}

export function GovernanceTimeline({ actions, className = '' }: GovernanceTimelineProps): JSX.Element {
  const sorted = [...actions].sort((a, b) =>
    new Date(b.acted_at).getTime() - new Date(a.acted_at).getTime()
  );

  return (
    <div className={className}>
      <h3 className="text-sm font-semibold text-text-primary mb-3">
        Governance Actions
      </h3>

      {sorted.length === 0 ? (
        <div className="rounded-lg border border-dark-border bg-dark-surface1 px-4 py-6 text-center">
          <p className="text-xs text-text-muted">No governance actions recorded.</p>
        </div>
      ) : (
        <div className="relative max-h-96 overflow-y-auto rounded-lg border border-dark-border bg-dark-surface1 p-4">
          {/* Timeline line */}
          <div className="absolute left-7 top-4 bottom-4 w-px bg-dark-border" />

          <div className="space-y-4">
            {sorted.map((action, i) => {
              const colorClass = ACTION_COLORS[action.action_type] ?? 'bg-dark-surface3 border-dark-border text-text-secondary';
              const dotClass = DOT_COLORS[action.action_type] ?? 'bg-text-muted';

              return (
                <motion.div
                  key={action.governance_action_id}
                  initial={i === 0 ? { opacity: 0, y: -10 } : false}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ duration: 0.2 }}
                  className="relative pl-8"
                >
                  {/* Timeline dot */}
                  <div className={`absolute left-2.5 top-2 w-2.5 h-2.5 rounded-full ${dotClass}`} />

                  <div className="flex items-start gap-3">
                    {/* Action type badge */}
                    <span
                      className={`shrink-0 px-1.5 py-0.5 text-[10px] font-mono font-bold tracking-wide border rounded bg-opacity-10 ${colorClass}`}
                      style={{ backgroundColor: 'transparent' }}
                    >
                      {action.action_type.toUpperCase()}
                    </span>

                    <div className="flex-1 min-w-0">
                      <div className="flex items-center gap-2 text-xs">
                        <span className="font-mono text-text-primary">{extractId(action.actor_ref)}</span>
                        <span className="text-text-muted">{action.authority_class}</span>
                      </div>
                      <p className="mt-0.5 text-[10px] text-text-muted font-mono truncate">
                        basis: {extractId(action.legitimacy_basis_ref)}
                      </p>
                    </div>

                    <span className="shrink-0 text-[10px] text-text-muted font-mono">
                      {formatTime(action.acted_at)}
                    </span>
                  </div>
                </motion.div>
              );
            })}
          </div>
        </div>
      )}
    </div>
  );
}
