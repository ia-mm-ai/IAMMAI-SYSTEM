/**
 * IAMMAI derivative surface disclaimer banner.
 * Non-dismissable — always visible on IAMMAI dashboard pages.
 */

export function DerivativeBanner(): JSX.Element {
  return (
    <div className="mb-6 px-4 py-2.5 rounded-lg border border-accent-magenta/30 bg-accent-magenta/5 flex items-center gap-3">
      <span className="shrink-0 px-1.5 py-0.5 text-[10px] font-mono font-bold tracking-widest border border-accent-magenta/40 rounded text-accent-magenta bg-accent-magenta/10">
        DERIVATIVE
      </span>
      <p className="text-xs text-accent-magenta/80">
        This dashboard displays data derived from IAMMAI canonical records.
        It is not a source of truth. For authoritative records, query the canonical registry directly.
      </p>
    </div>
  );
}
