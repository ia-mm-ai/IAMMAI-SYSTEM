/**
 * GovernanceActionDialog — Modal for IAMMAI governance operations.
 *
 * Handles HOLD, RELEASE, INVALIDATE, EVOLVE, DENY actions.
 * All inputs are passed to the authoritative governance API.
 * This is a mixed surface: form is authoritative input, not canonical state.
 */

import { useState } from 'react';

type GovernanceActionType = 'hold' | 'release' | 'invalidate' | 'evolve' | 'deny';

interface GovernanceActionDialogProps {
  type: GovernanceActionType;
  matterRef: string;
  onComplete: (success: boolean, result?: Record<string, unknown>) => void;
  onCancel: () => void;
}

const API_URL = process.env['NEXT_PUBLIC_API_URL'] || 'http://localhost:3001';

function getAuthHeaders(): HeadersInit {
  if (typeof window === 'undefined') return {};
  const token = localStorage.getItem('auth_token');
  return token
    ? { Authorization: `Bearer ${token}`, 'Content-Type': 'application/json' }
    : { 'Content-Type': 'application/json' };
}

const ACTION_CONFIG: Record<GovernanceActionType, {
  label: string;
  description: string;
  accentClass: string;
  borderClass: string;
  fields: Array<'reason' | 'legitimacy_basis_ref' | 'successor_session_name' | 'target_action'>;
}> = {
  hold: {
    label: 'Apply HOLD',
    description: 'Freeze this matter. Prevents phase transitions and resolution. Messaging will be suspended.',
    accentClass: 'text-accent-magenta',
    borderClass: 'border-accent-magenta/40',
    fields: ['reason', 'legitimacy_basis_ref'],
  },
  release: {
    label: 'Release HOLD',
    description: 'Restore permissibility. Does NOT create standing state — matter returns to its current phase.',
    accentClass: 'text-accent-blue',
    borderClass: 'border-accent-blue/40',
    fields: ['reason', 'legitimacy_basis_ref'],
  },
  invalidate: {
    label: 'INVALIDATE',
    description: 'Remove standing without erasing trace. This is irreversible. The matter record is preserved.',
    accentClass: 'text-error',
    borderClass: 'border-error/40',
    fields: ['legitimacy_basis_ref'],
  },
  evolve: {
    label: 'EVOLVE',
    description: 'Create a lawful successor matter with explicit predecessor relation. Original trace is preserved.',
    accentClass: 'text-accent-blue',
    borderClass: 'border-accent-blue/40',
    fields: ['successor_session_name', 'legitimacy_basis_ref'],
  },
  deny: {
    label: 'Record DENY',
    description: 'Record a typed governance denial. Denial is not absence — it is a visible, attributed act.',
    accentClass: 'text-warning',
    borderClass: 'border-warning/40',
    fields: ['target_action', 'reason', 'legitimacy_basis_ref'],
  },
};

export function GovernanceActionDialog({
  type,
  matterRef,
  onComplete,
  onCancel,
}: GovernanceActionDialogProps): JSX.Element {
  const [reason, setReason] = useState('');
  const [legitimacyBasisRef, setLegitimacyBasisRef] = useState('');
  const [successorSessionName, setSuccessorSessionName] = useState('');
  const [targetAction, setTargetAction] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const config = ACTION_CONFIG[type];
  const encoded = encodeURIComponent(matterRef);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsLoading(true);
    setError(null);

    const body: Record<string, string> = {
      legitimacy_basis_ref: legitimacyBasisRef,
    };
    if (config.fields.includes('reason')) body['reason'] = reason;
    if (config.fields.includes('successor_session_name')) body['successor_session_name'] = successorSessionName;
    if (config.fields.includes('target_action')) body['target_action'] = targetAction;

    try {
      const resp = await fetch(`${API_URL}/api/v1/admin/iammai/matters/${encoded}/${type}`, {
        method: 'POST',
        credentials: 'include',
        headers: getAuthHeaders(),
        body: JSON.stringify(body),
      });

      const json = await resp.json() as Record<string, unknown>;

      if (!resp.ok) {
        const errMsg = (json['error'] as string) ?? `HTTP ${resp.status}`;
        setError(errMsg);
        return;
      }

      onComplete(true, json);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Request failed');
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-dark-base/80 backdrop-blur-sm">
      <div className={`w-full max-w-md rounded-xl border bg-dark-surface1 p-6 shadow-xl ${config.borderClass}`}>
        {/* Header */}
        <div className="mb-4">
          <h2 className={`text-base font-bold font-mono ${config.accentClass}`}>
            {config.label}
          </h2>
          <p className="text-xs text-text-secondary mt-1 leading-relaxed">
            {config.description}
          </p>
          <div className="mt-2 text-[10px] font-mono text-text-muted truncate">
            {matterRef}
          </div>
        </div>

        {/* Error */}
        {error && (
          <div className="mb-4 px-3 py-2 rounded border border-error/30 bg-error/5 text-xs text-error">
            {error}
          </div>
        )}

        <form onSubmit={handleSubmit} className="space-y-4">
          {/* target_action field (DENY only) */}
          {config.fields.includes('target_action') && (
            <div>
              <label className="block text-xs font-mono text-text-secondary mb-1">
                Target Action *
              </label>
              <input
                type="text"
                value={targetAction}
                onChange={e => setTargetAction(e.target.value)}
                placeholder="e.g. transition, resolution, message_exchange"
                required
                className="w-full px-3 py-2 text-sm bg-dark-surface2 border border-dark-border rounded-lg
                         text-text-primary placeholder-text-muted
                         focus:outline-none focus:ring-1 focus:ring-accent-cyan/50 focus:border-accent-cyan/50"
              />
            </div>
          )}

          {/* reason field */}
          {config.fields.includes('reason') && (
            <div>
              <label className="block text-xs font-mono text-text-secondary mb-1">
                Reason *
              </label>
              <textarea
                value={reason}
                onChange={e => setReason(e.target.value)}
                placeholder="Describe the reason for this governance action..."
                required
                rows={2}
                className="w-full px-3 py-2 text-sm bg-dark-surface2 border border-dark-border rounded-lg
                         text-text-primary placeholder-text-muted resize-none
                         focus:outline-none focus:ring-1 focus:ring-accent-cyan/50 focus:border-accent-cyan/50"
              />
            </div>
          )}

          {/* successor_session_name field (EVOLVE only) */}
          {config.fields.includes('successor_session_name') && (
            <div>
              <label className="block text-xs font-mono text-text-secondary mb-1">
                Successor Session Name *
              </label>
              <input
                type="text"
                value={successorSessionName}
                onChange={e => setSuccessorSessionName(e.target.value)}
                placeholder="Name for the successor session..."
                required
                className="w-full px-3 py-2 text-sm bg-dark-surface2 border border-dark-border rounded-lg
                         text-text-primary placeholder-text-muted
                         focus:outline-none focus:ring-1 focus:ring-accent-cyan/50 focus:border-accent-cyan/50"
              />
            </div>
          )}

          {/* legitimacy_basis_ref field */}
          <div>
            <label className="block text-xs font-mono text-text-secondary mb-1">
              Legitimacy Basis Reference *
            </label>
            <input
              type="text"
              value={legitimacyBasisRef}
              onChange={e => setLegitimacyBasisRef(e.target.value)}
              placeholder="e.g. admin_decision, protocol_violation, session_end"
              required
              className="w-full px-3 py-2 text-sm bg-dark-surface2 border border-dark-border rounded-lg
                       text-text-primary placeholder-text-muted
                       focus:outline-none focus:ring-1 focus:ring-accent-cyan/50 focus:border-accent-cyan/50"
            />
          </div>

          {/* Actions */}
          <div className="flex gap-3 pt-2">
            <button
              type="button"
              onClick={onCancel}
              disabled={isLoading}
              className="flex-1 px-4 py-2 text-sm font-mono text-text-secondary border border-dark-border rounded-lg
                       hover:border-text-secondary/50 transition-colors disabled:opacity-50"
            >
              Cancel
            </button>
            <button
              type="submit"
              disabled={isLoading}
              className={`flex-1 px-4 py-2 text-sm font-mono font-semibold border rounded-lg transition-colors disabled:opacity-50
                       ${config.accentClass} ${config.borderClass} hover:bg-white/5`}
            >
              {isLoading ? 'Processing...' : config.label}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}
