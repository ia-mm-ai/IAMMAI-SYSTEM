/**
 * Matter summary card for the overview list.
 * Shows matter_ref, current phase, family, conformance status.
 */

import Link from 'next/link';
import { motion } from 'framer-motion';

interface MatterSummary {
  matter_ref: string;
  latest_phase: string;
  state_family: string;
  state_count: number;
  latest_recorded_at: string;
  conformance?: 'CONFORMANT' | 'NON_CONFORMANT' | 'PARTIAL' | null;
  isHeld?: boolean;
}

interface MatterCardProps {
  matter: MatterSummary;
  index: number;
}

const CONFORMANCE_BADGE: Record<string, string> = {
  CONFORMANT: 'text-success bg-success/10 border-success/30',
  PARTIAL: 'text-warning bg-warning/10 border-warning/30',
  NON_CONFORMANT: 'text-error bg-error/10 border-error/30',
};

function extractSessionId(matterRef: string): string {
  // bnk:session:<uuid> -> first 8 chars of uuid
  const parts = matterRef.split(':');
  return parts[parts.length - 1]?.slice(0, 8) ?? matterRef;
}

export function MatterCard({ matter, index }: MatterCardProps): JSX.Element {
  return (
    <motion.div
      initial={{ opacity: 0, y: 10 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ delay: index * 0.05, duration: 0.3 }}
    >
      <Link
        href={`/iammai/${encodeURIComponent(matter.matter_ref)}`}
        className="block rounded-lg border border-dark-border bg-dark-surface1 p-4 hover:border-accent-cyan/30 transition-colors duration-hover"
      >
        <div className="flex items-start justify-between mb-3">
          {/* Matter ref */}
          <div>
            <span className="text-xs text-text-muted font-mono">bnk:session:</span>
            <span className="text-sm font-mono font-medium text-text-primary">
              {extractSessionId(matter.matter_ref)}
            </span>
          </div>

          {/* Conformance badge */}
          {matter.conformance && (
            <span className={`px-1.5 py-0.5 text-[10px] font-mono font-semibold rounded border ${CONFORMANCE_BADGE[matter.conformance] ?? ''}`}>
              {matter.conformance === 'NON_CONFORMANT' ? 'NON-CONF' : matter.conformance.slice(0, 4)}
            </span>
          )}
        </div>

        <div className="flex items-center gap-3">
          {/* Current phase */}
          <div className="flex items-center gap-2">
            <div className={`w-2 h-2 rounded-full ${
              matter.isHeld
                ? 'bg-accent-magenta animate-pulse'
                : 'bg-accent-cyan'
            }`} />
            <span className="text-xs font-mono text-accent-cyan">
              {matter.latest_phase.toUpperCase()}
            </span>
          </div>

          {/* State family badge */}
          <span className={`px-1.5 py-0.5 text-[10px] font-mono rounded border ${
            matter.state_family === 'standing'
              ? 'text-accent-cyan border-accent-cyan/30'
              : 'text-text-secondary border-dark-border'
          }`}>
            {matter.state_family.toUpperCase()}
          </span>

          {/* HELD indicator */}
          {matter.isHeld && (
            <span className="px-1.5 py-0.5 text-[10px] font-mono font-bold text-accent-magenta border border-accent-magenta/30 rounded">
              HELD
            </span>
          )}
        </div>

        <div className="mt-2 flex items-center justify-between text-[10px] text-text-muted">
          <span className="font-mono">{matter.state_count} states</span>
          <span>{new Date(matter.latest_recorded_at).toLocaleString()}</span>
        </div>
      </Link>
    </motion.div>
  );
}
