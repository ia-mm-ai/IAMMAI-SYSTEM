/**
 * Expandable compliance condition result card
 * @see specs/009-compliance-test/tasks.md#T023
 */

import { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';

export type EvidenceType =
  | 'SESSION_REFERENCE'
  | 'LEDGER_ENTRY'
  | 'PRESENCE_RECORD'
  | 'WITNESS_ARTIFACT'
  | 'SUPPRESSION_RECORD'
  | 'PROTOCOL_RESULT'
  | 'SCHEMA_CHECK'
  | 'HASH_CHAIN'
  | 'STATE_TRANSITION'
  | 'ADMIN_ACTION';

export interface EvidenceItem {
  type: EvidenceType;
  description: string;
  sessionId?: string;
  details?: Record<string, unknown>;
}

export interface ConditionEvaluation {
  condition: string;
  label: string;
  result: 'PASS' | 'FAIL';
  evidence: EvidenceItem[];
}

interface ConditionCardProps {
  evaluation: ConditionEvaluation;
}

const EVIDENCE_TYPE_COLORS: Record<EvidenceType, string> = {
  SESSION_REFERENCE: 'text-accent-cyan border-accent-cyan/30',
  LEDGER_ENTRY: 'text-accent-blue border-accent-blue/30',
  PRESENCE_RECORD: 'text-accent-magenta border-accent-magenta/30',
  WITNESS_ARTIFACT: 'text-text-secondary border-dark-border',
  SUPPRESSION_RECORD: 'text-warning border-warning/30',
  PROTOCOL_RESULT: 'text-accent-cyan border-accent-cyan/30',
  SCHEMA_CHECK: 'text-accent-blue border-accent-blue/30',
  HASH_CHAIN: 'text-accent-magenta border-accent-magenta/30',
  STATE_TRANSITION: 'text-text-secondary border-dark-border',
  ADMIN_ACTION: 'text-warning border-warning/30',
};

function EvidenceItemRow({ item }: { item: EvidenceItem }): JSX.Element {
  const colorClass = EVIDENCE_TYPE_COLORS[item.type] ?? 'text-text-secondary border-dark-border';

  return (
    <div className="py-3 border-b border-dark-border last:border-b-0">
      <div className="flex items-start gap-3">
        <span
          className={`shrink-0 mt-0.5 px-1.5 py-0.5 text-[10px] font-mono font-medium tracking-wide border rounded ${colorClass}`}
        >
          {item.type.replace(/_/g, ' ')}
        </span>
        <div className="min-w-0 flex-1">
          <p className="text-sm text-text-primary">{item.description}</p>
          {item.sessionId && (
            <p className="mt-0.5 text-xs font-mono text-text-muted">
              session: {item.sessionId}
            </p>
          )}
          {item.details && Object.keys(item.details).length > 0 && (
            <pre className="mt-1.5 px-2 py-1.5 text-xs font-mono text-text-secondary bg-dark-base rounded border border-dark-border overflow-x-auto">
              {JSON.stringify(item.details, null, 2)}
            </pre>
          )}
        </div>
      </div>
    </div>
  );
}

export function ConditionCard({ evaluation }: ConditionCardProps): JSX.Element {
  const [isExpanded, setIsExpanded] = useState(evaluation.result === 'FAIL');
  const isPassing = evaluation.result === 'PASS';
  const hasEvidence = evaluation.evidence.length > 0;

  return (
    <div
      className={`rounded-lg border bg-dark-surface1 transition-colors duration-hover ${
        isPassing
          ? 'border-dark-border hover:border-accent-cyan/20'
          : 'border-error/30 hover:border-error/50'
      }`}
    >
      {/* Card Header */}
      <button
        onClick={() => setIsExpanded((prev) => !prev)}
        disabled={!hasEvidence}
        className="w-full flex items-center justify-between px-4 py-4 text-left disabled:cursor-default"
        aria-expanded={isExpanded}
      >
        <div className="flex items-center gap-3">
          {/* Pass/Fail indicator dot */}
          <span
            className={`w-2 h-2 rounded-full shrink-0 ${
              isPassing ? 'bg-success' : 'bg-error animate-pulse'
            }`}
          />
          <span className="text-sm font-medium text-text-primary">
            {evaluation.label}
          </span>
        </div>

        <div className="flex items-center gap-3">
          {/* Status badge */}
          <span
            className={`px-2 py-0.5 text-xs font-mono font-semibold rounded ${
              isPassing
                ? 'text-success bg-success/10'
                : 'text-error bg-error/10'
            }`}
          >
            {evaluation.result}
          </span>

          {/* Expand chevron */}
          {hasEvidence && (
            <motion.svg
              animate={{ rotate: isExpanded ? 180 : 0 }}
              transition={{ duration: 0.2 }}
              className="w-4 h-4 text-text-muted shrink-0"
              fill="none"
              stroke="currentColor"
              viewBox="0 0 24 24"
            >
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 9l-7 7-7-7" />
            </motion.svg>
          )}
        </div>
      </button>

      {/* Evidence Section */}
      <AnimatePresence initial={false}>
        {isExpanded && hasEvidence && (
          <motion.div
            key="evidence"
            initial={{ height: 0, opacity: 0 }}
            animate={{ height: 'auto', opacity: 1 }}
            exit={{ height: 0, opacity: 0 }}
            transition={{ duration: 0.25, ease: [0.22, 1, 0.36, 1] }}
            className="overflow-hidden"
          >
            <div className="px-4 pb-4 border-t border-dark-border">
              <p className="pt-3 pb-1 text-xs font-medium text-text-muted uppercase tracking-wider">
                Evidence ({evaluation.evidence.length})
              </p>
              <div>
                {evaluation.evidence.map((item, idx) => (
                  <EvidenceItemRow key={idx} item={item} />
                ))}
              </div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* No evidence note for PASS with no evidence */}
      {isExpanded && !hasEvidence && (
        <div className="px-4 pb-4 border-t border-dark-border">
          <p className="pt-3 text-xs text-text-muted italic">No evidence items recorded.</p>
        </div>
      )}
    </div>
  );
}
