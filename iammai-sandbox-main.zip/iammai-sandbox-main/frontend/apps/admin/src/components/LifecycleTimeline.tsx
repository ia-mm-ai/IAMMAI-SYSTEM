/**
 * Lifecycle timeline component showing created/started/ended timestamps
 * @see specs/001-ephemeral-kernel/tasks.md#T050
 * @see specs/001-ephemeral-kernel/spec.md#FR-026
 */

interface LifecycleEvent {
  event: 'CREATED' | 'STARTED' | 'ENDED';
  timestamp: string;
}

interface LifecycleTimelineProps {
  events: LifecycleEvent[];
}

const eventConfig: Record<
  LifecycleEvent['event'],
  { label: string; color: string; glowClass: string; textColor: string; icon: string }
> = {
  CREATED: {
    label: 'Session Created',
    color: 'bg-accent-blue',
    glowClass: 'shadow-glow-blue-medium',
    textColor: 'text-accent-blue',
    icon: '+',
  },
  STARTED: {
    label: 'Session Started (Kernel Active)',
    color: 'bg-accent-cyan',
    glowClass: 'shadow-glow-cyan-medium',
    textColor: 'text-accent-cyan',
    icon: '▶',
  },
  ENDED: {
    label: 'Session Ended (Kernel Dissolved)',
    color: 'bg-accent-magenta',
    glowClass: 'shadow-glow-magenta-medium',
    textColor: 'text-accent-magenta',
    icon: '■',
  },
};

export function LifecycleTimeline({
  events,
}: LifecycleTimelineProps): JSX.Element {
  const formatTimestamp = (timestamp: string): string => {
    const date = new Date(timestamp);
    return date.toLocaleString();
  };

  return (
    <div className="flow-root">
      <ul className="-mb-8">
        {events.map((event, idx) => {
          const config = eventConfig[event.event];
          const isLast = idx === events.length - 1;

          return (
            <li key={`${event.event}-${event.timestamp}`}>
              <div className="relative pb-8">
                {!isLast && (
                  <span
                    className="absolute left-4 top-4 -ml-px h-full w-0.5 bg-dark-border"
                    aria-hidden="true"
                  />
                )}
                <div className="relative flex space-x-3">
                  <div>
                    <span
                      className={`h-8 w-8 rounded-full ${config.color} ${config.glowClass} flex items-center justify-center text-dark-base text-sm font-bold`}
                    >
                      {config.icon}
                    </span>
                  </div>
                  <div className="flex min-w-0 flex-1 justify-between space-x-4 pt-1.5">
                    <div>
                      <p className={`text-sm font-medium ${config.textColor}`}>{config.label}</p>
                    </div>
                    <div className="whitespace-nowrap text-right text-sm text-text-secondary">
                      {formatTimestamp(event.timestamp)}
                    </div>
                  </div>
                </div>
              </div>
            </li>
          );
        })}
      </ul>
    </div>
  );
}
