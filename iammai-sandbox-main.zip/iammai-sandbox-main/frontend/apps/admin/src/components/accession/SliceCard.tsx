/**
 * SliceCard — Summary card for an accession slice.
 *
 * DERIVATIVE SURFACE — display only.
 */

import { motion } from 'framer-motion';

interface SliceCardProps {
  sliceName: string;
  sourceName: string;
  currentStage: string | null;
  isSelected: boolean;
  onClick: () => void;
}

const STAGE_COLORS: Record<string, string> = {
  contact: 'text-text-secondary border-dark-border',
  eligibility: 'text-accent-cyan border-accent-cyan/30',
  shadow: 'text-accent-blue border-accent-blue/30',
  proof: 'text-warning-text border-warning/30',
  admission: 'text-accent-magenta border-accent-magenta/30',
  bound_vessel: 'text-success-text border-success/30',
  revoked: 'text-error border-error/30',
};

export function SliceCard({ sliceName, sourceName, currentStage, isSelected, onClick }: SliceCardProps): JSX.Element {
  const stageStyle = STAGE_COLORS[currentStage ?? ''] ?? STAGE_COLORS['contact'];

  return (
    <motion.button
      onClick={onClick}
      className={`w-full text-left rounded-lg border p-3 transition-colors duration-hover ${isSelected ? 'border-accent-magenta/50 bg-dark-surface2' : 'border-dark-border bg-dark-surface1 hover:border-accent-cyan/30'}`}
      whileHover={{ scale: 1.01 }}
    >
      <div className="flex items-center justify-between mb-1">
        <span className="text-xs font-mono text-text-bright truncate">{sourceName}</span>
        {currentStage && (
          <span className={`px-1.5 py-0.5 text-[9px] font-mono font-bold rounded border ${stageStyle}`}>
            {currentStage.toUpperCase().replace('_', ' ')}
          </span>
        )}
      </div>
      <div className="text-[10px] text-text-secondary font-mono truncate">{sliceName}</div>
    </motion.button>
  );
}
