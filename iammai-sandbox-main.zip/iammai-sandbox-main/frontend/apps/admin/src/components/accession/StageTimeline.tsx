/**
 * StageTimeline — Horizontal timeline showing all 7 accession stages.
 * Current stage highlighted, completed stages show outcome.
 *
 * DERIVATIVE SURFACE — display only.
 */

import { motion } from 'framer-motion';

const STAGES = ['contact', 'eligibility', 'shadow', 'proof', 'admission', 'bound_vessel', 'revoked'] as const;

const STAGE_LABELS: Record<string, string> = {
  contact: 'Contact',
  eligibility: 'Eligibility',
  shadow: 'Shadow',
  proof: 'Proof',
  admission: 'Admission',
  bound_vessel: 'Bound Vessel',
  revoked: 'Revoked',
};

interface StageTimelineProps {
  currentStage: string | null;
  completedStages: string[];
  onStageClick: (stage: string) => void;
  selectedStage: string | null;
}

export function StageTimeline({ currentStage, completedStages, onStageClick, selectedStage }: StageTimelineProps): JSX.Element {
  const currentIdx = currentStage ? STAGES.indexOf(currentStage as typeof STAGES[number]) : -1;

  return (
    <div className="flex items-center gap-1 overflow-x-auto pb-2">
      {STAGES.filter(s => s !== 'revoked').map((stage, idx) => {
        const isCompleted = completedStages.includes(stage);
        const isCurrent = stage === currentStage;
        const isSelected = stage === selectedStage;
        const isPast = idx < currentIdx;
        const isRevoked = currentStage === 'revoked';

        let bgClass = 'bg-dark-surface2 border-dark-border text-text-secondary';
        if (isCompleted || isPast) bgClass = 'bg-accent-cyan/10 border-accent-cyan/30 text-accent-cyan';
        if (isCurrent && !isRevoked) bgClass = 'bg-accent-cyan/20 border-accent-cyan text-accent-cyan shadow-glow-cyan-subtle';
        if (isRevoked && isCurrent) bgClass = 'bg-error/20 border-error text-error shadow-glow-error-subtle';
        if (isSelected) bgClass += ' ring-1 ring-accent-magenta';

        return (
          <div key={stage} className="flex items-center">
            <motion.button
              onClick={() => isCompleted || isCurrent ? onStageClick(stage) : undefined}
              className={`px-3 py-1.5 text-[10px] font-mono font-bold rounded border transition-colors duration-hover whitespace-nowrap ${bgClass} ${isCompleted || isCurrent ? 'cursor-pointer hover:border-accent-magenta/50' : 'cursor-default opacity-50'}`}
              whileHover={isCompleted || isCurrent ? { scale: 1.05 } : undefined}
            >
              {STAGE_LABELS[stage]}
            </motion.button>
            {idx < 5 && (
              <div className={`w-4 h-px mx-0.5 ${isPast || (isCompleted && idx < currentIdx) ? 'bg-accent-cyan/50' : 'bg-dark-border'}`} />
            )}
          </div>
        );
      })}
      {currentStage === 'revoked' && (
        <div className="flex items-center ml-2">
          <div className="w-4 h-px mx-0.5 bg-error/50" />
          <span className="px-3 py-1.5 text-[10px] font-mono font-bold rounded border bg-error/20 border-error text-error shadow-glow-error-subtle">
            REVOKED
          </span>
        </div>
      )}
    </div>
  );
}
