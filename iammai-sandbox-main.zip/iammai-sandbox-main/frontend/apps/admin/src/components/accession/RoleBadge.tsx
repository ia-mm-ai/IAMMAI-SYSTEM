/**
 * RoleBadge — Labels a chunk of data with its IAMMAI role
 * (source / exported / derived / display).
 *
 * Shared across accession UI components so the role vocabulary stays
 * consistent wherever payload data is surfaced.
 */

interface RoleBadgeProps {
  role: string;
}

const ROLE_COLORS: Record<string, string> = {
  source: 'text-warning-text bg-warning/10 border-warning/30',
  exported: 'text-accent-cyan bg-accent-cyan/10 border-accent-cyan/30',
  derived: 'text-accent-magenta bg-accent-magenta/10 border-accent-magenta/30',
  display: 'text-text-secondary bg-dark-surface2 border-dark-border',
};

export function RoleBadge({ role }: RoleBadgeProps): JSX.Element {
  const className = ROLE_COLORS[role] ?? ROLE_COLORS['display'];
  return (
    <span className={`px-1 py-0.5 text-[8px] font-mono font-bold rounded border ${className}`}>
      {role.toUpperCase()}
    </span>
  );
}
