/**
 * StageDetail — Shows records produced at a specific accession stage.
 *
 * DERIVATIVE SURFACE — all data labeled with its role.
 */

import { RoleBadge } from './RoleBadge';

interface StageDetailProps {
  stageState: {
    accession_stage: string;
    stage_outcome: Record<string, unknown>;
    recorded_at: string;
    related_governance_ref: string | null;
    related_witness_ref: string | null;
  } | null;
  shadows: Array<{
    shadow_id: string;
    shadow_data: Record<string, unknown>;
    discrepancies: Array<Record<string, unknown>>;
    data_role: string;
  }>;
  proofs: Array<{
    proof_id: string;
    test_name: string;
    test_result: string;
    test_details: Record<string, unknown>;
  }>;
}

function ProofBadge({ result }: { result: string }): JSX.Element {
  const colors: Record<string, string> = {
    pass: 'text-success-text bg-success/10 border-success/30',
    fail: 'text-error bg-error/10 border-error/30',
    blocked: 'text-warning-text bg-warning/10 border-warning/30',
    indeterminate: 'text-text-secondary bg-dark-surface2 border-dark-border',
  };
  return (
    <span className={`px-1.5 py-0.5 text-[9px] font-mono font-bold rounded border ${colors[result] ?? colors['indeterminate']}`}>
      {result.toUpperCase()}
    </span>
  );
}

export function StageDetail({ stageState, shadows, proofs }: StageDetailProps): JSX.Element {
  if (!stageState) {
    return <div className="text-text-muted text-xs font-mono p-4">Select a completed stage to inspect</div>;
  }

  const outcome = stageState.stage_outcome;
  const stage = stageState.accession_stage;

  return (
    <div className="space-y-4">
      {/* Stage Header */}
      <div className="flex items-center justify-between">
        <h3 className="text-sm font-mono text-text-bright uppercase tracking-wider">
          {stage.replace('_', ' ')}
        </h3>
        <RoleBadge role="display" />
      </div>

      {/* Outcome */}
      <div className="rounded border border-dark-border bg-dark-surface2 p-3">
        <div className="text-[10px] font-mono text-text-muted mb-2">STAGE OUTCOME</div>
        <pre className="text-[10px] font-mono text-text-primary whitespace-pre-wrap">
          {JSON.stringify(outcome, null, 2)}
        </pre>
      </div>

      {/* Shadow (if present) */}
      {shadows.length > 0 && stage === 'shadow' && (
        <div className="rounded border border-dark-border bg-dark-surface2 p-3">
          <div className="flex items-center gap-2 mb-2">
            <span className="text-[10px] font-mono text-text-muted">SHADOW MIRROR</span>
            <RoleBadge role={shadows[0]!.data_role} />
          </div>
          {shadows[0]!.discrepancies.length > 0 ? (
            <div className="space-y-1">
              {shadows[0]!.discrepancies.map((d, i) => (
                <div key={i} className="flex items-center gap-2 text-[10px] font-mono">
                  <span className="text-warning-text">{String(d['type'])}</span>
                  <span className="text-text-secondary">{String(d['field'])}</span>
                  <span className="text-text-muted">expected: {String(d['expected'])}</span>
                  <span className="text-error">actual: {JSON.stringify(d['actual'])}</span>
                </div>
              ))}
            </div>
          ) : (
            <div className="text-[10px] font-mono text-success-text">No discrepancies</div>
          )}
        </div>
      )}

      {/* Proof Tests (if present) */}
      {proofs.length > 0 && stage === 'proof' && (
        <div className="rounded border border-dark-border bg-dark-surface2 p-3">
          <div className="text-[10px] font-mono text-text-muted mb-2">PROOF TESTS</div>
          <div className="space-y-2">
            {proofs.map((p) => (
              <div key={p.proof_id} className="flex items-center justify-between">
                <span className="text-[10px] font-mono text-text-primary">{p.test_name}</span>
                <ProofBadge result={p.test_result} />
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Governance + Witness refs */}
      <div className="flex gap-4 text-[9px] font-mono text-text-muted">
        {stageState.related_governance_ref && (
          <span>gov: {stageState.related_governance_ref.slice(0, 8)}...</span>
        )}
        {stageState.related_witness_ref && (
          <span>wit: {stageState.related_witness_ref.slice(0, 8)}...</span>
        )}
      </div>
    </div>
  );
}
