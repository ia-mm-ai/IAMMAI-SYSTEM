/**
 * SliceContextPanel — Shows the exported slice payload and the canonical
 * source-system payload for the selected slice.
 *
 * DERIVATIVE SURFACE — read-only. Each section is labeled with its
 * IAMMAI data role so the source → exported boundary stays visible.
 */

import { RoleBadge } from './RoleBadge';

interface SliceContextPanelProps {
  sliceName: string;
  sliceData: Record<string, unknown> | null;
  sourceName: string | null;
  sourceSystemRef?: string | null;
  sourceData: Record<string, unknown> | null;
}

function JsonBlock({ value }: { value: Record<string, unknown> | null }): JSX.Element {
  if (!value) {
    return (
      <div className="text-[10px] font-mono text-text-muted italic">Not loaded</div>
    );
  }
  return (
    <pre className="text-[10px] font-mono text-text-primary whitespace-pre-wrap break-words max-h-80 overflow-auto">
      {JSON.stringify(value, null, 2)}
    </pre>
  );
}

export function SliceContextPanel({
  sliceName,
  sliceData,
  sourceName,
  sourceSystemRef,
  sourceData,
}: SliceContextPanelProps): JSX.Element {
  return (
    <div className="space-y-3">
      {/* Panel header */}
      <div className="flex items-center justify-between">
        <h3 className="text-sm font-mono text-text-bright uppercase tracking-wider">
          Slice Context
        </h3>
        <div className="flex items-center gap-1">
          <RoleBadge role="exported" />
          <RoleBadge role="source" />
        </div>
      </div>

      {/* Exported Slice — default expanded */}
      <details open className="rounded border border-dark-border bg-dark-surface2">
        <summary className="cursor-pointer select-none px-3 py-2 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <span className="text-[10px] font-mono text-text-muted uppercase tracking-wider">
              Exported Slice
            </span>
            <span className="text-[10px] font-mono text-text-secondary truncate">
              {sliceName}
            </span>
          </div>
          <RoleBadge role="exported" />
        </summary>
        <div className="px-3 pb-3">
          <JsonBlock value={sliceData} />
        </div>
      </details>

      {/* Source Data — default collapsed (payloads can be large) */}
      <details className="rounded border border-dark-border bg-dark-surface2">
        <summary className="cursor-pointer select-none px-3 py-2 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <span className="text-[10px] font-mono text-text-muted uppercase tracking-wider">
              Source Data
            </span>
            {sourceName && (
              <span className="text-[10px] font-mono text-text-secondary truncate">
                {sourceName}
                {sourceSystemRef ? (
                  <span className="text-text-muted"> · {sourceSystemRef}</span>
                ) : null}
              </span>
            )}
          </div>
          <RoleBadge role="source" />
        </summary>
        <div className="px-3 pb-3">
          <JsonBlock value={sourceData} />
        </div>
      </details>
    </div>
  );
}
