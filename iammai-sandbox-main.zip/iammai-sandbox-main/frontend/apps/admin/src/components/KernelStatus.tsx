/**
 * Kernel status component showing NOT_CREATED/ACTIVE/DISSOLVED with icons
 * @see specs/001-ephemeral-kernel/tasks.md#T049
 */

import type { KernelStatus as KernelStatusType } from '@iammai-sandbox/shared';

interface KernelStatusProps {
  status: KernelStatusType;
  size?: 'sm' | 'md' | 'lg';
}

const statusConfig: Record<
  KernelStatusType,
  { label: string; bgColor: string; textColor: string; borderColor: string; glowClass: string; icon: string }
> = {
  NOT_CREATED: {
    label: 'Not Created',
    bgColor: 'bg-warning-bg',
    textColor: 'text-warning',
    borderColor: 'border-warning',
    glowClass: '',
    icon: '○',
  },
  ACTIVE: {
    label: 'Active',
    bgColor: 'bg-success-bg',
    textColor: 'text-success',
    borderColor: 'border-success',
    glowClass: 'shadow-glow-success-medium',
    icon: '●',
  },
  DISSOLVED: {
    label: 'Dissolved',
    bgColor: 'bg-error-bg',
    textColor: 'text-error',
    borderColor: 'border-error',
    glowClass: 'shadow-glow-error-medium',
    icon: '×',
  },
};

const sizeClasses = {
  sm: 'px-2 py-1 text-xs',
  md: 'px-3 py-1.5 text-sm',
  lg: 'px-4 py-2 text-base',
};

export function KernelStatus({
  status,
  size = 'md',
}: KernelStatusProps): JSX.Element {
  const config = statusConfig[status];

  return (
    <div
      className={`inline-flex items-center gap-2 rounded-full border ${config.bgColor} ${config.textColor} ${config.borderColor} ${config.glowClass} ${sizeClasses[size]} font-medium transition-all duration-hover`}
    >
      <span className={status === 'ACTIVE' ? 'animate-pulse' : ''}>
        {config.icon}
      </span>
      <span>Kernel: {config.label}</span>
    </div>
  );
}
