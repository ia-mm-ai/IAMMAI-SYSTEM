/**
 * Admin layout with auth state and navigation
 * @see specs/001-ephemeral-kernel/tasks.md#T045
 */

import { ReactNode, useEffect, useState } from 'react';
import { useRouter } from 'next/router';
import Link from 'next/link';

const API_URL = process.env['NEXT_PUBLIC_API_URL'] || 'http://localhost:3001';

/**
 * Get auth headers for API requests
 * Uses localStorage token for iOS/mobile compatibility
 */
function getAuthHeaders(): HeadersInit {
  if (typeof window === 'undefined') return {};
  const token = localStorage.getItem('auth_token');
  return token ? { Authorization: `Bearer ${token}` } : {};
}

interface AdminProfile {
  id: string;
  email: string;
  lastLoginAt: string | null;
}

interface AdminLayoutProps {
  children: ReactNode;
}

export function AdminLayout({ children }: AdminLayoutProps): JSX.Element {
  const router = useRouter();
  const [admin, setAdmin] = useState<AdminProfile | null>(null);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    checkAuth();
  }, []);

  const checkAuth = async (): Promise<void> => {
    try {
      const response = await fetch(`${API_URL}/api/v1/auth/me`, {
        credentials: 'include',
        headers: getAuthHeaders(),
      });

      if (!response.ok) {
        localStorage.removeItem('auth_token');
        router.replace('/login');
        return;
      }

      const data = await response.json();
      setAdmin(data);
    } catch {
      localStorage.removeItem('auth_token');
      router.replace('/login');
    } finally {
      setIsLoading(false);
    }
  };

  const handleLogout = async (): Promise<void> => {
    try {
      await fetch(`${API_URL}/api/v1/auth/logout`, {
        method: 'POST',
        credentials: 'include',
        headers: getAuthHeaders(),
      });
    } finally {
      localStorage.removeItem('auth_token');
      router.replace('/login');
    }
  };

  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-dark-base">
        <div className="text-text-secondary">Loading...</div>
      </div>
    );
  }

  if (!admin) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-dark-base">
        <div className="text-text-secondary">Redirecting to login...</div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-dark-base scan-lines">
      {/* Navigation Header */}
      <nav className="bg-dark-surface1 border-b border-dark-border">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between h-16">
            <div className="flex items-center">
              <Link href="/sessions" className="flex items-center">
                <span className="text-xl font-bold text-text-primary font-display tracking-tight">
                  IAMMAI Sandbox
                </span>
                <span className="ml-2 text-sm text-text-secondary">Admin</span>
              </Link>

              <div className="ml-10 flex items-center space-x-4">
                <Link
                  href="/sessions"
                  className={`px-3 py-2 rounded-md text-sm font-medium transition-colors duration-hover ${
                    router.pathname.startsWith('/sessions')
                      ? 'bg-dark-surface3 text-accent-cyan'
                      : 'text-text-secondary hover:text-text-primary'
                  }`}
                >
                  Sessions
                </Link>
                <Link
                  href="/compliance"
                  className={`px-3 py-2 rounded-md text-sm font-medium transition-colors duration-hover ${
                    router.pathname.startsWith('/compliance')
                      ? 'bg-dark-surface3 text-accent-cyan'
                      : 'text-text-secondary hover:text-text-primary'
                  }`}
                >
                  Compliance
                </Link>
                <Link
                  href="/iammai"
                  className={`px-3 py-2 rounded-md text-sm font-medium transition-colors duration-hover ${
                    router.pathname.startsWith('/iammai')
                      ? 'bg-dark-surface3 text-accent-cyan'
                      : 'text-text-secondary hover:text-text-primary'
                  }`}
                >
                  IAMMAI
                </Link>
                <Link
                  href="/accession"
                  className={`px-3 py-2 rounded-md text-sm font-medium transition-colors duration-hover ${
                    router.pathname.startsWith('/accession')
                      ? 'bg-dark-surface3 text-accent-cyan'
                      : 'text-text-secondary hover:text-text-primary'
                  }`}
                >
                  Accession
                </Link>
              </div>
            </div>

            <div className="flex items-center space-x-4">
              <span className="text-sm text-text-secondary">{admin.email}</span>
              <button
                onClick={handleLogout}
                className="px-3 py-2 rounded-md text-sm font-medium text-text-secondary hover:text-text-primary"
              >
                Logout
              </button>
            </div>
          </div>
        </div>
      </nav>

      {/* Main Content */}
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {children}
      </main>
    </div>
  );
}
