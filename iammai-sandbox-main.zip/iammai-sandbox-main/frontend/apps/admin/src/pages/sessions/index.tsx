/**
 * Session list page showing all sessions with state badges
 * @see specs/001-ephemeral-kernel/tasks.md#T046
 */

import { useState, useEffect, useCallback } from 'react';
import { useRouter } from 'next/router';
import { AdminLayout } from '../../components/AdminLayout';
import { SessionCard } from '../../components/SessionCard';
import { SessionCardSkeleton } from '@iammai-sandbox/shared';
import { FadeUp, StaggerGrid, HoverGlow } from '@iammai-sandbox/shared';
import { useToast } from '@iammai-sandbox/shared';
import type { Session, SessionState } from '@iammai-sandbox/shared';

const API_URL = process.env['NEXT_PUBLIC_API_URL'] || 'http://localhost:3001';

function getAuthHeaders(): HeadersInit {
  if (typeof window === 'undefined') return {};
  const token = localStorage.getItem('auth_token');
  return token ? { Authorization: `Bearer ${token}` } : {};
}

interface SessionListResponse {
  sessions: Session[];
  total: number;
  limit: number;
  offset: number;
}

export default function SessionListPage(): JSX.Element {
  const router = useRouter();
  const { showError } = useToast();
  const [sessions, setSessions] = useState<Session[]>([]);
  const [total, setTotal] = useState(0);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [filter, setFilter] = useState<SessionState | ''>('');
  const [actionLoading, setActionLoading] = useState<string | null>(null);
  const [showCreateModal, setShowCreateModal] = useState(false);
  const [newSessionName, setNewSessionName] = useState('');
  const [newSessionTopic, setNewSessionTopic] = useState('');
  const [newSessionMaxParticipants, setNewSessionMaxParticipants] = useState('10');
  const [createLoading, setCreateLoading] = useState(false);
  const [newSessionIammaiTracked, setNewSessionIammaiTracked] = useState(true);
  const [confirmTruthLoading, setConfirmTruthLoading] = useState<string | null>(null);
  const [sessionIammaiPhases, setSessionIammaiPhases] = useState<Record<string, string>>({});

  const fetchSessions = useCallback(async () => {
    try {
      const params = new URLSearchParams();
      if (filter) params.set('state', filter);

      const response = await fetch(
        `${API_URL}/api/v1/admin/sessions?${params.toString()}`,
        { credentials: 'include', headers: getAuthHeaders() }
      );

      if (!response.ok) {
        throw new Error('Failed to fetch sessions');
      }

      const data: SessionListResponse = await response.json();
      setSessions(data.sessions);
      setTotal(data.total);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'An error occurred');
    } finally {
      setIsLoading(false);
    }
  }, [filter]);

  useEffect(() => {
    fetchSessions();

    // Set up polling for real-time updates (every 5 seconds)
    const intervalId = setInterval(() => {
      fetchSessions();
    }, 5000);

    // Clean up interval on unmount
    return () => {
      clearInterval(intervalId);
    };
  }, [fetchSessions]);

  const handleStart = async (sessionId: string): Promise<void> => {
    setActionLoading(sessionId);
    try {
      const response = await fetch(
        `${API_URL}/api/v1/admin/sessions/${sessionId}/start`,
        {
          method: 'POST',
          credentials: 'include',
          headers: getAuthHeaders(),
        }
      );

      if (!response.ok) {
        const data = await response.json();
        throw new Error(data.message || 'Failed to start session');
      }

      // Refresh the list
      await fetchSessions();
    } catch (err) {
      showError(err instanceof Error ? err.message : 'Failed to start session');
    } finally {
      setActionLoading(null);
    }
  };

  const handleEnd = async (sessionId: string): Promise<void> => {
    if (!confirm('Are you sure you want to end this session? All conversations will be destroyed.')) {
      return;
    }

    setActionLoading(sessionId);
    try {
      const response = await fetch(
        `${API_URL}/api/v1/admin/sessions/${sessionId}/end`,
        {
          method: 'POST',
          credentials: 'include',
          headers: getAuthHeaders(),
        }
      );

      if (!response.ok) {
        const data = await response.json();
        throw new Error(data.message || 'Failed to end session');
      }

      // Refresh the list
      await fetchSessions();
    } catch (err) {
      showError(err instanceof Error ? err.message : 'Failed to end session');
    } finally {
      setActionLoading(null);
    }
  };

  const handleCreate = async (): Promise<void> => {
    if (!newSessionName.trim() || !newSessionTopic.trim()) return;

    const maxParticipants = parseInt(newSessionMaxParticipants, 10);
    if (isNaN(maxParticipants) || maxParticipants < 1 || maxParticipants > 1000) return;

    setCreateLoading(true);
    try {
      const response = await fetch(`${API_URL}/api/v1/admin/sessions`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', ...getAuthHeaders() },
        credentials: 'include',
        body: JSON.stringify({
          name: newSessionName.trim(),
          context_descriptor: { topic: newSessionTopic.trim() },
          environmental_constraints: { max_participants: maxParticipants },
          iammai_tracked: newSessionIammaiTracked,
        }),
      });

      if (!response.ok) {
        const data = await response.json();
        throw new Error(data.message || 'Failed to create session');
      }

      setShowCreateModal(false);
      setNewSessionName('');
      setNewSessionTopic('');
      setNewSessionMaxParticipants('10');
      setNewSessionIammaiTracked(true);
      await fetchSessions();
    } catch (err) {
      showError(err instanceof Error ? err.message : 'Failed to create session');
    } finally {
      setCreateLoading(false);
    }
  };

  const handleConfirmTruth = async (sessionId: string): Promise<void> => {
    setConfirmTruthLoading(sessionId);
    try {
      const response = await fetch(
        `${API_URL}/api/v1/admin/sessions/${sessionId}/confirm-truth`,
        {
          method: 'POST',
          headers: { 'Content-Type': 'application/json', ...getAuthHeaders() },
          credentials: 'include',
          body: JSON.stringify({ legitimacy_basis_ref: 'admin_truth_confirmation' }),
        }
      );

      if (!response.ok) {
        const data = await response.json();
        throw new Error(data.message || 'Failed to confirm truth formation');
      }

      // Update local phase cache
      setSessionIammaiPhases(prev => ({ ...prev, [sessionId]: 'truth' }));
    } catch (err) {
      showError(err instanceof Error ? err.message : 'Failed to confirm truth');
    } finally {
      setConfirmTruthLoading(null);
    }
  };

  // Fetch IAMMAI phase for active sessions to show confirm-truth button
  useEffect(() => {
    const activeSessionIds = sessions.filter(s => s.state === 'ACTIVE').map(s => s.id);
    activeSessionIds.forEach(async (id) => {
      if (sessionIammaiPhases[id]) return; // Already cached
      try {
        const resp = await fetch(`${API_URL}/api/v1/sessions/${id}/iammai-status`, {
          credentials: 'include',
        });
        if (resp.ok) {
          const data = await resp.json() as { tracked?: boolean; phase?: string };
          if (data.tracked && data.phase) {
            setSessionIammaiPhases(prev => ({ ...prev, [id]: data.phase! }));
          }
        }
      } catch {
        // Ignore fetch errors for phase check
      }
    });
  }, [sessions, sessionIammaiPhases]);

  return (
    <AdminLayout>
      <div className="space-y-8">
        {/* Header */}
        <FadeUp>
          <div className="flex items-center justify-between mb-12">
            <div>
              <h1 className="text-4xl font-bold leading-tight text-text-primary font-display tracking-tight text-glow-cyan-medium">Sessions</h1>
              <p className="mt-4 text-base font-normal leading-normal text-text-secondary">
                {total} session{total !== 1 ? 's' : ''} total
              </p>
            </div>

            <HoverGlow color="cyan" className="rounded-md">
              <button
                onClick={() => setShowCreateModal(true)}
                className="px-6 py-3 bg-accent-cyan text-dark-base rounded-md hover:bg-accent-cyan-hover font-semibold transition-colors duration-hover"
              >
                Create Session
              </button>
            </HoverGlow>
          </div>
        </FadeUp>

        {/* Filters */}
        <div className="flex items-center space-x-4">
          <label className="text-sm font-medium text-text-primary">Filter by state:</label>
          <select
            value={filter}
            onChange={(e) => setFilter(e.target.value as SessionState | '')}
            className="border border-dark-border bg-dark-surface1 text-text-primary rounded-md px-3 py-1.5 text-sm focus:outline-none focus:ring-2 focus:ring-accent-cyan/50 focus:border-accent-cyan transition-colors"
          >
            <option value="">All</option>
            <option value="CREATED">Created</option>
            <option value="ACTIVE">Active</option>
            <option value="ENDED">Ended</option>
          </select>
        </div>

        {/* Error */}
        {error && (
          <div className="rounded-md bg-error-bg border border-error p-4">
            <p className="text-sm font-normal leading-normal text-error-text">{error}</p>
          </div>
        )}

        {/* Session Grid */}
        {isLoading ? (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {[1, 2, 3].map((i) => (
              <SessionCardSkeleton key={i} />
            ))}
          </div>
        ) : sessions.length === 0 ? (
          <div className="text-center py-16">
            <p className="text-base font-normal leading-normal text-text-secondary">No sessions found</p>
          </div>
        ) : (
          <StaggerGrid className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {sessions.map((session) => {
              const iammaiPhase = sessionIammaiPhases[session.id];
              const needsTruthConfirmation = session.state === 'ACTIVE' && iammaiPhase === 'threshold';
              return (
                <div key={session.id} className="flex flex-col gap-2">
                  <SessionCard
                    {...session}
                    onStart={() => handleStart(session.id)}
                    onEnd={() => handleEnd(session.id)}
                    onClick={() => router.push(`/sessions/${session.id}`)}
                    isLoading={actionLoading === session.id}
                  />
                  {/* Confirm Truth Formation button — visible when matter is at threshold */}
                  {needsTruthConfirmation && (
                    <button
                      onClick={() => handleConfirmTruth(session.id)}
                      disabled={confirmTruthLoading === session.id}
                      className="w-full px-4 py-2 text-xs font-mono font-semibold text-accent-cyan border border-accent-cyan/40
                               rounded-lg hover:bg-accent-cyan/10 transition-colors disabled:opacity-50"
                      title="Session matter is at threshold (preparation). Confirm to advance to truth (standing-state). Required before messaging."
                    >
                      {confirmTruthLoading === session.id
                        ? 'Confirming...'
                        : '⬡ Confirm Truth Formation (threshold → truth)'}
                    </button>
                  )}
                </div>
              );
            })}
          </StaggerGrid>
        )}
      </div>

      {/* Create Session Modal */}
      {showCreateModal && (
        <div className="fixed inset-0 bg-black/70 backdrop-blur-sm flex items-center justify-center z-[10000]">
          <div className="bg-dark-surface1 border border-dark-border rounded-lg shadow-xl shadow-glow-cyan-subtle p-8 w-full max-w-md">
            <h2 className="text-3xl font-bold leading-tight text-text-primary font-display tracking-tight text-glow-cyan-subtle mb-6">
              Create New Session
            </h2>

            <div className="mb-4">
              <label className="block text-sm font-medium text-text-primary mb-2">
                Session Name
              </label>
              <input
                type="text"
                value={newSessionName}
                onChange={(e) => setNewSessionName(e.target.value)}
                className="w-full px-4 py-3 bg-dark-surface2 border border-dark-border text-text-primary rounded-md focus:outline-none focus:ring-2 focus:ring-accent-cyan/50 focus:border-accent-cyan placeholder-text-muted transition-colors"
                placeholder="Enter session name"
                maxLength={255}
              />
            </div>

            <div className="mb-4">
              <label className="block text-sm font-medium text-text-primary mb-2">
                Topic
              </label>
              <input
                type="text"
                value={newSessionTopic}
                onChange={(e) => setNewSessionTopic(e.target.value)}
                className="w-full px-4 py-3 bg-dark-surface2 border border-dark-border text-text-primary rounded-md focus:outline-none focus:ring-2 focus:ring-accent-cyan/50 focus:border-accent-cyan placeholder-text-muted transition-colors"
                placeholder="What is this session about?"
                maxLength={500}
              />
            </div>

            <div className="mb-6">
              <label className="block text-sm font-medium text-text-primary mb-2">
                Max Participants
              </label>
              <input
                type="number"
                value={newSessionMaxParticipants}
                onChange={(e) => setNewSessionMaxParticipants(e.target.value)}
                className="w-full px-4 py-3 bg-dark-surface2 border border-dark-border text-text-primary rounded-md focus:outline-none focus:ring-2 focus:ring-accent-cyan/50 focus:border-accent-cyan placeholder-text-muted transition-colors"
                min={1}
                max={1000}
              />
            </div>

            {/* IAMMAI Tracking Toggle */}
            <div className="mb-6 p-4 rounded-lg border border-dark-border bg-dark-surface2">
              <div className="flex items-center justify-between">
                <div>
                  <label className="text-sm font-semibold text-text-primary font-mono">
                    IAMMAI Governance
                  </label>
                  <p className="text-xs text-text-muted mt-0.5">
                    Track this session under the IAMMAI constitutional protocol
                  </p>
                </div>
                <button
                  type="button"
                  onClick={() => setNewSessionIammaiTracked(prev => !prev)}
                  className={`relative inline-flex h-6 w-11 items-center rounded-full transition-colors ${
                    newSessionIammaiTracked ? 'bg-accent-cyan' : 'bg-dark-border'
                  }`}
                >
                  <span
                    className={`inline-block h-4 w-4 transform rounded-full bg-dark-base transition-transform ${
                      newSessionIammaiTracked ? 'translate-x-6' : 'translate-x-1'
                    }`}
                  />
                </button>
              </div>
              {newSessionIammaiTracked && (
                <p className="mt-2 text-xs text-accent-cyan/70 font-mono">
                  This session will be governed by the IAMMAI constitutional protocol.
                </p>
              )}
            </div>

            <div className="flex space-x-4">
              <button
                onClick={() => setShowCreateModal(false)}
                disabled={createLoading}
                className="flex-1 px-6 py-3 border border-dark-border bg-dark-surface2 rounded-md text-text-primary hover:bg-dark-surface3 disabled:opacity-50 font-semibold transition-colors duration-hover"
              >
                Cancel
              </button>
              <HoverGlow color="cyan" disabled={createLoading || !newSessionName.trim() || !newSessionTopic.trim()} className="flex-1 rounded-md">
                <button
                  onClick={handleCreate}
                  disabled={createLoading || !newSessionName.trim() || !newSessionTopic.trim()}
                  className="w-full px-6 py-3 bg-accent-cyan text-dark-base rounded-md hover:bg-accent-cyan-hover disabled:opacity-50 font-semibold transition-colors duration-hover"
                >
                  {createLoading ? 'Creating...' : 'Create'}
                </button>
              </HoverGlow>
            </div>
          </div>
        </div>
      )}
    </AdminLayout>
  );
}
