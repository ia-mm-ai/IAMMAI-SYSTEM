/**
 * Session detail page with full session info and lifecycle timeline
 * @see specs/001-ephemeral-kernel/tasks.md#T048
 */

import { useState, useEffect, useCallback } from 'react';
import { useRouter } from 'next/router';
import Link from 'next/link';
import { AdminLayout } from '../../components/AdminLayout';
import { KernelStatus } from '../../components/KernelStatus';
import { LifecycleTimeline } from '../../components/LifecycleTimeline';
import { StatusBadge, FadeUp } from '@iammai-sandbox/shared';
import { useToast } from '@iammai-sandbox/shared';
import type { SessionDetails } from '@iammai-sandbox/shared';

const API_URL = process.env['NEXT_PUBLIC_API_URL'] || 'http://localhost:3001';

function getAuthHeaders(): HeadersInit {
  if (typeof window === 'undefined') return {};
  const token = localStorage.getItem('auth_token');
  return token ? { Authorization: `Bearer ${token}` } : {};
}

interface LifecycleEvent {
  event: 'CREATED' | 'STARTED' | 'ENDED';
  timestamp: string;
}

interface SessionDetailsResponse extends Omit<SessionDetails, 'lifecycle'> {
  lifecycle: LifecycleEvent[];
}

export default function SessionDetailPage(): JSX.Element {
  const router = useRouter();
  const { id } = router.query;
  const { showError } = useToast();

  const [session, setSession] = useState<SessionDetailsResponse | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [actionLoading, setActionLoading] = useState(false);
  const [lastUpdated, setLastUpdated] = useState<Date | null>(null);

  const fetchSession = useCallback(async () => {
    if (!id || typeof id !== 'string') return;

    try {
      const response = await fetch(
        `${API_URL}/api/v1/admin/sessions/${id}`,
        { credentials: 'include', headers: getAuthHeaders() }
      );

      if (response.status === 404) {
        setError('Session not found');
        return;
      }

      if (!response.ok) {
        throw new Error('Failed to fetch session');
      }

      const data = await response.json();
      setSession(data);
      setLastUpdated(new Date());
    } catch (err) {
      setError(err instanceof Error ? err.message : 'An error occurred');
    } finally {
      setIsLoading(false);
    }
  }, [id]);

  useEffect(() => {
    fetchSession();

    // Set up polling for real-time updates (every 5 seconds)
    const intervalId = setInterval(() => {
      fetchSession();
    }, 5000);

    // Clean up interval on unmount
    return () => {
      clearInterval(intervalId);
    };
  }, [fetchSession]);

  const handleStart = async (): Promise<void> => {
    if (!session) return;

    setActionLoading(true);
    try {
      const response = await fetch(
        `${API_URL}/api/v1/admin/sessions/${session.id}/start`,
        {
          method: 'POST',
          credentials: 'include',
          headers: getAuthHeaders(),
        }
      );

      if (!response.ok) {
        const data = await response.json();
        throw new Error(data.message || 'Failed to start session');
      }

      await fetchSession();
    } catch (err) {
      showError(err instanceof Error ? err.message : 'Failed to start session');
    } finally {
      setActionLoading(false);
    }
  };

  const handleEnd = async (): Promise<void> => {
    if (!session) return;

    if (!confirm('Are you sure you want to end this session? All conversations will be destroyed.')) {
      return;
    }

    setActionLoading(true);
    try {
      const response = await fetch(
        `${API_URL}/api/v1/admin/sessions/${session.id}/end`,
        {
          method: 'POST',
          credentials: 'include',
          headers: getAuthHeaders(),
        }
      );

      if (!response.ok) {
        const data = await response.json();
        throw new Error(data.message || 'Failed to end session');
      }

      await fetchSession();
    } catch (err) {
      showError(err instanceof Error ? err.message : 'Failed to end session');
    } finally {
      setActionLoading(false);
    }
  };

  if (isLoading) {
    return (
      <AdminLayout>
        <div className="text-center py-12">
          <p className="text-text-secondary">Loading session...</p>
        </div>
      </AdminLayout>
    );
  }

  if (error || !session) {
    return (
      <AdminLayout>
        <div className="text-center py-12">
          <p className="text-error-text mb-4">{error || 'Session not found'}</p>
          <Link href="/sessions" className="text-accent-cyan hover:underline">
            Back to sessions
          </Link>
        </div>
      </AdminLayout>
    );
  }

  return (
    <AdminLayout>
      <div className="space-y-6">
        {/* Breadcrumb */}
        <nav className="flex items-center space-x-2 text-sm">
          <Link href="/sessions" className="text-accent-cyan hover:underline">
            Sessions
          </Link>
          <span className="text-text-secondary">/</span>
          <span className="text-text-primary">{session.name}</span>
        </nav>

        {/* Header */}
        <FadeUp>
        <div className="bg-dark-surface1 rounded-lg border border-dark-border p-6">
          <div className="flex items-start justify-between">
            <div>
              <div className="flex items-center space-x-4">
                <h1 className="text-4xl font-bold leading-tight text-text-primary font-display tracking-tight text-glow-cyan-medium">{session.name}</h1>
                <StatusBadge state={session.state} size="lg" />
              </div>
              <p className="mt-2 text-sm text-text-secondary">ID: {session.id}</p>
              {lastUpdated && (
                <p className="mt-1 text-xs text-text-muted">
                  Last updated: {lastUpdated.toLocaleTimeString()}
                </p>
              )}
            </div>

            <div className="flex items-center space-x-3">
              {session.state === 'CREATED' && (
                <button
                  onClick={handleStart}
                  disabled={actionLoading}
                  className="px-4 py-2 bg-accent-cyan text-dark-base rounded-md hover:bg-accent-cyan-hover disabled:opacity-50 text-sm font-medium shadow-glow-cyan-medium hover:shadow-glow-cyan-bright disabled:shadow-none transition-all duration-hover"
                >
                  {actionLoading ? 'Starting...' : 'Start Session'}
                </button>
              )}
              {session.state === 'ACTIVE' && (
                <button
                  onClick={handleEnd}
                  disabled={actionLoading}
                  className="px-4 py-2 bg-error text-dark-base rounded-md hover:bg-error/90 disabled:opacity-50 text-sm font-medium shadow-glow-error-medium hover:shadow-glow-error-bright disabled:shadow-none transition-all duration-hover"
                >
                  {actionLoading ? 'Ending...' : 'End Session'}
                </button>
              )}
            </div>
          </div>

          {/* Kernel Status */}
          <div className="mt-6">
            <KernelStatus status={session.kernelStatus} size="lg" />
          </div>
        </div>
        </FadeUp>

        {/* Stats Grid */}
        <FadeUp delay={0.1}>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {/* Token & User Counts */}
          <div className="bg-dark-surface1 rounded-lg border border-dark-border p-6">
            <h2 className="text-3xl font-bold leading-tight text-text-primary font-display tracking-tight text-glow-cyan-subtle mb-4">Statistics</h2>
            <div className="grid grid-cols-2 gap-4">
              <div>
                <p className="text-sm text-text-secondary">Tokens Claimed</p>
                <p className="text-3xl font-bold text-text-primary">{session.tokenCount}</p>
              </div>
              <div>
                <p className="text-sm text-text-secondary">Users Joined</p>
                <p className="text-3xl font-bold text-text-primary">{session.userCount}</p>
              </div>
            </div>

            {/* Privacy Note */}
            <div className="mt-6 p-3 bg-dark-surface2 rounded-md border border-dark-border">
              <p className="text-xs text-text-muted">
                <strong>Privacy Note:</strong> Conversation content is never stored or
                accessible. Only aggregate counts are available.
              </p>
            </div>
          </div>

          {/* Lifecycle Timeline */}
          <div className="bg-dark-surface1 rounded-lg border border-dark-border p-6">
            <h2 className="text-3xl font-bold leading-tight text-text-primary font-display tracking-tight text-glow-cyan-subtle mb-4">Lifecycle</h2>
            <LifecycleTimeline events={session.lifecycle} />
          </div>
        </div>
        </FadeUp>

        {/* Session Info */}
        <FadeUp delay={0.2}>
        <div className="bg-dark-surface1 rounded-lg border border-dark-border p-6">
          <h2 className="text-lg font-medium text-text-primary mb-4">Session Details</h2>
          <dl className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <dt className="text-sm text-text-secondary">Created At</dt>
              <dd className="text-sm text-text-primary">
                {new Date(session.createdAt).toLocaleString()}
              </dd>
            </div>
            {session.startedAt && (
              <div>
                <dt className="text-sm text-text-secondary">Started At</dt>
                <dd className="text-sm text-text-primary">
                  {new Date(session.startedAt).toLocaleString()}
                </dd>
              </div>
            )}
            {session.endedAt && (
              <div>
                <dt className="text-sm text-text-secondary">Ended At</dt>
                <dd className="text-sm text-text-primary">
                  {new Date(session.endedAt).toLocaleString()}
                </dd>
              </div>
            )}
          </dl>
        </div>
        </FadeUp>
      </div>
    </AdminLayout>
  );
}
