/**
 * Compliance dashboard page — on-demand §11 condition check
 * @see specs/009-compliance-test/tasks.md#T024
 */

import { useState, useCallback } from 'react';
import { AdminLayout } from '../../components/AdminLayout';
import { ConditionCard } from '../../components/ConditionCard';
import type { ConditionEvaluation } from '../../components/ConditionCard';
import { FadeUp, HoverGlow } from '@iammai-sandbox/shared';

const API_URL = process.env['NEXT_PUBLIC_API_URL'] || 'http://localhost:3001';

function getAuthHeaders(): HeadersInit {
  if (typeof window === 'undefined') return {};
  const token = localStorage.getItem('auth_token');
  return token ? { Authorization: `Bearer ${token}` } : {};
}

interface ComplianceResult {
  overall: 'COMPLIANT' | 'NON_COMPLIANT' | 'ERROR';
  conditions: ConditionEvaluation[];
  executedAt: string;
  systemVersion: string;
  sessionsEvaluated: number;
  error?: string;
}

const OVERALL_STYLES: Record<ComplianceResult['overall'], string> = {
  COMPLIANT: 'text-accent-cyan bg-accent-cyan/10 border-accent-cyan/30',
  NON_COMPLIANT: 'text-error bg-error/10 border-error/30',
  ERROR: 'text-warning bg-warning/10 border-warning/30',
};

const SKELETON_LABELS = [
  'Truth Finalization',
  'Deterministic Witnessed Verification',
  'Mandatory Suppression',
  'History Non-Regression',
  'Authority Non-Assertion',
];

function ConditionSkeleton({ label }: { label: string }): JSX.Element {
  return (
    <div className="rounded-lg border border-dark-border bg-dark-surface1 px-4 py-4 animate-pulse">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-3">
          <div className="w-2 h-2 rounded-full bg-dark-surface3" />
          <div className="h-4 rounded bg-dark-surface3" style={{ width: `${label.length * 7}px` }} />
        </div>
        <div className="w-12 h-5 rounded bg-dark-surface3" />
      </div>
    </div>
  );
}

export default function CompliancePage(): JSX.Element {
  const [result, setResult] = useState<ComplianceResult | null>(null);
  const [isLoading, setIsLoading] = useState(false);
  const [fetchError, setFetchError] = useState<string | null>(null);

  const runCheck = useCallback(async () => {
    setIsLoading(true);
    setFetchError(null);
    setResult(null);

    try {
      const response = await fetch(`${API_URL}/api/v1/admin/compliance`, {
        credentials: 'include',
        headers: getAuthHeaders(),
      });

      if (!response.ok) {
        const body = await response.json().catch(() => ({}));
        throw new Error(
          (body as { error?: string }).error ?? `HTTP ${response.status}`
        );
      }

      const data: ComplianceResult = await response.json();
      setResult(data);
    } catch (err) {
      setFetchError(err instanceof Error ? err.message : 'Failed to run compliance check');
    } finally {
      setIsLoading(false);
    }
  }, []);

  return (
    <AdminLayout>
      <FadeUp>
        {/* Page header */}
        <div className="mb-8 flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
          <div>
            <h1 className="text-2xl font-bold text-text-primary font-display tracking-tight">
              Compliance Check
            </h1>
            <p className="mt-1 text-sm text-text-secondary">
              Evaluate the five MM-MODEL §11 conditions against the integrity layer.
            </p>
          </div>

          <HoverGlow color="cyan" intensity="subtle" hoverIntensity="medium">
            <button
              onClick={runCheck}
              disabled={isLoading}
              className="px-4 py-2 rounded-lg text-sm font-medium bg-dark-surface2 border border-accent-cyan/30 text-accent-cyan hover:bg-dark-surface3 hover:border-accent-cyan/60 transition-colors duration-hover disabled:opacity-50 disabled:cursor-not-allowed"
            >
              {isLoading ? 'Running…' : 'Run Compliance Check'}
            </button>
          </HoverGlow>
        </div>

        {/* Fetch error */}
        {fetchError && (
          <div className="mb-6 px-4 py-3 rounded-lg border border-error/30 bg-error/5 text-sm text-error">
            {fetchError}
          </div>
        )}

        {/* Overall status — shown only after a result */}
        {result && (
          <div className="mb-6 flex items-center gap-4">
            <div
              className={`inline-flex items-center gap-2 px-4 py-2 rounded-lg border text-sm font-semibold font-mono ${OVERALL_STYLES[result.overall]}`}
            >
              <span
                className={`w-2 h-2 rounded-full ${
                  result.overall === 'COMPLIANT'
                    ? 'bg-accent-cyan'
                    : result.overall === 'NON_COMPLIANT'
                    ? 'bg-error animate-pulse'
                    : 'bg-warning animate-pulse'
                }`}
              />
              {result.overall}
            </div>
            <div className="text-xs text-text-muted">
              <span>{result.sessionsEvaluated} sessions evaluated</span>
              <span className="mx-2">·</span>
              <span>{new Date(result.executedAt).toLocaleString()}</span>
              <span className="mx-2">·</span>
              <span className="font-mono">v{result.systemVersion}</span>
            </div>
          </div>
        )}

        {/* Error detail from compliance check itself */}
        {result?.error && (
          <div className="mb-6 px-4 py-3 rounded-lg border border-warning/30 bg-warning/5 text-sm text-warning">
            Infrastructure error: {result.error}
          </div>
        )}

        {/* Condition cards — skeleton while loading, real cards when done */}
        <div className="space-y-3">
          {isLoading
            ? SKELETON_LABELS.map((label) => (
                <ConditionSkeleton key={label} label={label} />
              ))
            : result?.conditions.map((evaluation) => (
                <ConditionCard key={evaluation.condition} evaluation={evaluation} />
              ))}

          {/* Empty state — before first check */}
          {!isLoading && !result && !fetchError && (
            <div className="rounded-lg border border-dark-border bg-dark-surface1 px-6 py-12 text-center">
              <p className="text-text-secondary text-sm">
                Click{' '}
                <span className="text-accent-cyan font-medium">Run Compliance Check</span>{' '}
                to evaluate the §11 conditions.
              </p>
            </div>
          )}
        </div>
      </FadeUp>
    </AdminLayout>
  );
}
