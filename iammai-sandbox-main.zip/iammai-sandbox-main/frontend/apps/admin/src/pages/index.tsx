/**
 * Admin home page - redirects to sessions or login
 */

import { useEffect } from 'react';
import { useRouter } from 'next/router';

export default function AdminHome(): JSX.Element {
  const router = useRouter();

  useEffect(() => {
    // Redirect to sessions page (auth check happens there)
    router.replace('/sessions');
  }, [router]);

  return (
    <div className="min-h-screen flex items-center justify-center bg-dark-base scan-lines">
      <div className="text-text-secondary">Loading...</div>
    </div>
  );
}
