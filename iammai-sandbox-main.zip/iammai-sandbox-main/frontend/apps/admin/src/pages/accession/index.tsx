/**
 * Accession Layer — Admin Step-Through UI
 *
 * DERIVATIVE SURFACE — Displays data derived from canonical accession records.
 * Not a source of truth. All data labeled with its role.
 */

import { useState, useEffect, useCallback } from 'react';
import { AdminLayout } from '../../components/AdminLayout';
import { DerivativeBanner } from '../../components/iammai/DerivativeBanner';
import { StageTimeline } from '../../components/accession/StageTimeline';
import { SliceCard } from '../../components/accession/SliceCard';
import { StageDetail } from '../../components/accession/StageDetail';
import { SliceContextPanel } from '../../components/accession/SliceContextPanel';
import { FadeUp } from '@iammai-sandbox/shared';

const API_URL = process.env['NEXT_PUBLIC_API_URL'] || 'http://localhost:3001';
const BASE = `${API_URL}/api/v1/admin/iammai/accession`;

function getAuthHeaders(): HeadersInit {
  if (typeof window === 'undefined') return {};
  const token = localStorage.getItem('auth_token');
  return token ? { Authorization: `Bearer ${token}`, 'Content-Type': 'application/json' } : { 'Content-Type': 'application/json' };
}

interface SliceSummary {
  slice_id: string;
  slice_name: string;
  source_name: string;
  current_stage: string | null;
  slice_data: Record<string, unknown>;
}

interface AccessionState {
  state_id: string;
  accession_stage: string;
  stage_outcome: Record<string, unknown>;
  recorded_at: string;
  related_governance_ref: string | null;
  related_witness_ref: string | null;
}

interface ExternalSourceSummary {
  source_id: string;
  source_name: string;
  source_system_ref: string;
  source_data: Record<string, unknown>;
}

export default function AccessionPage(): JSX.Element {
  const [slices, setSlices] = useState<SliceSummary[]>([]);
  const [selectedSliceId, setSelectedSliceId] = useState<string | null>(null);
  const [selectedStage, setSelectedStage] = useState<string | null>(null);
  const [states, setStates] = useState<AccessionState[]>([]);
  const [shadows, setShadows] = useState<Array<Record<string, unknown>>>([]);
  const [proofs, setProofs] = useState<Array<Record<string, unknown>>>([]);
  const [currentSource, setCurrentSource] = useState<ExternalSourceSummary | null>(null);
  const [isLoading, setIsLoading] = useState(false);
  const [isAdvancing, setIsAdvancing] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const fetchSlices = useCallback(async (): Promise<SliceSummary[]> => {
    try {
      const resp = await fetch(`${BASE}/slices`, { credentials: 'include', headers: getAuthHeaders() });
      if (!resp.ok) throw new Error(`HTTP ${resp.status}`);
      const json = await resp.json();
      const result = json.data?.slices ?? [];
      setSlices(result);
      return result;
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to fetch slices');
      return [];
    }
  }, []);

  const fetchSliceContext = useCallback(async (sliceId: string) => {
    try {
      const resp = await fetch(`${BASE}/slices/${sliceId}`, { credentials: 'include', headers: getAuthHeaders() });
      if (!resp.ok) throw new Error(`HTTP ${resp.status}`);
      const json = await resp.json();
      const ctx = json.data;
      setStates(ctx?.states ?? []);
      setShadows(ctx?.shadows ?? []);
      setProofs(ctx?.proofs ?? []);
      setCurrentSource(ctx?.source ?? null);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to fetch context');
    }
  }, []);

  useEffect(() => { if (selectedSliceId) fetchSliceContext(selectedSliceId); }, [selectedSliceId, fetchSliceContext]);

  const handleSeed = async () => {
    setIsLoading(true);
    setError(null);
    try {
      const resp = await fetch(`${BASE}/seed`, { method: 'POST', credentials: 'include', headers: getAuthHeaders() });
      if (!resp.ok) throw new Error(`HTTP ${resp.status}`);
      await fetchSlices();
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to seed');
    } finally {
      setIsLoading(false);
    }
  };

  const handleReset = async () => {
    setIsLoading(true);
    setError(null);
    try {
      const resp = await fetch(`${BASE}/reset`, { method: 'POST', credentials: 'include', headers: getAuthHeaders(), body: JSON.stringify({ reseed: false }) });
      if (!resp.ok) throw new Error(`HTTP ${resp.status}`);
      setSelectedSliceId(null);
      setSelectedStage(null);
      setStates([]);
      setShadows([]);
      setProofs([]);
      setCurrentSource(null);
      setSlices([]);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to reset');
    } finally {
      setIsLoading(false);
    }
  };

  const handleAdvance = async () => {
    if (!selectedSliceId) return;
    setIsAdvancing(true);
    setError(null);
    try {
      const resp = await fetch(`${BASE}/slices/${selectedSliceId}/advance`, { method: 'POST', credentials: 'include', headers: getAuthHeaders() });
      if (!resp.ok) {
        const body = await resp.json().catch(() => ({}));
        throw new Error(body.error?.message ?? body.message ?? `HTTP ${resp.status}`);
      }
      await fetchSliceContext(selectedSliceId);
      const updatedSlices = await fetchSlices();
      // Auto-select the newly completed stage so the user sees its properties immediately
      const advancedSlice = updatedSlices?.find((s: SliceSummary) => s.slice_id === selectedSliceId);
      if (advancedSlice?.current_stage) {
        setSelectedStage(advancedSlice.current_stage);
      }
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to advance');
    } finally {
      setIsAdvancing(false);
    }
  };

  const currentSlice = slices.find(s => s.slice_id === selectedSliceId);
  const currentStage = currentSlice?.current_stage ?? null;
  const completedStages = states.map(s => s.accession_stage);
  const selectedStateRecord = states.find(s => s.accession_stage === selectedStage) ?? null;
  const isTerminal = currentStage === 'bound_vessel' || currentStage === 'revoked';
  const admissionState = states.find(s => s.accession_stage === 'admission');
  const admissionDecision = (admissionState?.stage_outcome as Record<string, unknown>)?.['decision'];
  const isRefused = admissionDecision === 'refused';
  const canAdvance = selectedSliceId && !isTerminal && !isRefused && !isAdvancing;

  return (
    <AdminLayout>
      <div className="space-y-4">
        {/* Top bar */}
        <FadeUp>
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <span className="text-[10px] font-mono text-text-muted">Admin &gt; IAMMAI &gt;</span>
              <h1 className="text-sm font-mono text-text-bright tracking-wider">ACCESSION</h1>
            </div>
            <div className="flex gap-2">
              <button
                onClick={handleSeed}
                disabled={isLoading}
                className="px-3 py-1 text-xs font-mono text-accent-cyan border border-accent-cyan/30 rounded hover:bg-accent-cyan/10 transition-colors disabled:opacity-50"
              >
                {isLoading ? 'Loading...' : 'Load Seeds'}
              </button>
              <button
                onClick={handleReset}
                disabled={isLoading}
                className="px-3 py-1 text-xs font-mono text-accent-magenta border border-accent-magenta/30 rounded hover:bg-accent-magenta/10 transition-colors disabled:opacity-50"
              >
                Reset
              </button>
            </div>
          </div>
        </FadeUp>

        <DerivativeBanner />

        {error && (
          <div className="rounded border border-error/30 bg-error/10 p-3 text-xs font-mono text-error">
            {error}
          </div>
        )}

        <div className="grid grid-cols-1 lg:grid-cols-4 gap-4">
          {/* Left panel: Slice list */}
          <div className="lg:col-span-1 space-y-2">
            <div className="text-[10px] font-mono text-text-muted uppercase tracking-wider mb-2">Slices</div>
            {slices.length === 0 ? (
              <div className="text-xs font-mono text-text-muted p-3 rounded border border-dark-border bg-dark-surface1">
                No slices loaded. Click &quot;Load Seeds&quot; to begin.
              </div>
            ) : (
              slices.map((s) => (
                <SliceCard
                  key={s.slice_id}
                  sliceName={s.slice_name}
                  sourceName={s.source_name}
                  currentStage={s.current_stage}
                  isSelected={s.slice_id === selectedSliceId}
                  onClick={() => { setSelectedSliceId(s.slice_id); setSelectedStage(null); }}
                />
              ))
            )}
          </div>

          {/* Main panel: Timeline + Inspector */}
          <div className="lg:col-span-3 space-y-4">
            {selectedSliceId ? (
              <>
                {/* Slice Context — exported slice + source payloads */}
                <FadeUp>
                  <div className="rounded-lg border border-dark-border bg-dark-surface1 p-4">
                    <SliceContextPanel
                      sliceName={currentSlice?.slice_name ?? ''}
                      sliceData={currentSlice?.slice_data ?? null}
                      sourceName={currentSource?.source_name ?? currentSlice?.source_name ?? null}
                      sourceSystemRef={currentSource?.source_system_ref ?? null}
                      sourceData={currentSource?.source_data ?? null}
                    />
                  </div>
                </FadeUp>

                {/* Stage Timeline */}
                <FadeUp>
                  <div className="rounded-lg border border-dark-border bg-dark-surface1 p-4">
                    <StageTimeline
                      currentStage={currentStage}
                      completedStages={completedStages}
                      onStageClick={(stage) => setSelectedStage(stage)}
                      selectedStage={selectedStage}
                    />
                    <div className="flex items-center justify-between mt-3 pt-3 border-t border-dark-border">
                      <div className="text-[10px] font-mono text-text-muted">
                        Current: <span className="text-text-primary">{currentStage?.toUpperCase().replace('_', ' ') ?? 'N/A'}</span>
                        {isRefused && <span className="text-error ml-2">(REFUSED)</span>}
                      </div>
                      <button
                        onClick={handleAdvance}
                        disabled={!canAdvance}
                        className="px-4 py-1.5 text-xs font-mono font-bold text-dark-base bg-accent-cyan rounded hover:bg-accent-cyan/80 transition-colors disabled:opacity-30 disabled:cursor-not-allowed"
                      >
                        {isAdvancing ? 'Advancing...' : 'ADVANCE'}
                      </button>
                    </div>
                  </div>
                </FadeUp>

                {/* Stage Detail Inspector */}
                <FadeUp>
                  <div className="rounded-lg border border-dark-border bg-dark-surface1 p-4">
                    <StageDetail
                      stageState={selectedStateRecord}
                      shadows={shadows as any}
                      proofs={proofs as any}
                    />
                  </div>
                </FadeUp>
              </>
            ) : (
              <div className="rounded-lg border border-dark-border bg-dark-surface1 p-8 text-center">
                <div className="text-xs font-mono text-text-muted">
                  Select a slice to inspect its accession progression
                </div>
              </div>
            )}
          </div>
        </div>
      </div>
    </AdminLayout>
  );
}
