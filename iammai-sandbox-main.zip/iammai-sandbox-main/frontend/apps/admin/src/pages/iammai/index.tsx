/**
 * IAMMAI Compliance Dashboard — Overview page
 *
 * DERIVATIVE SURFACE — Displays data derived from canonical IAMMAI records.
 * Not a source of truth.
 */

import { useState, useEffect, useCallback } from 'react';
import { AdminLayout } from '../../components/AdminLayout';
import { DerivativeBanner } from '../../components/iammai/DerivativeBanner';
import { MatterCard } from '../../components/iammai/MatterCard';
import { GovernanceTimeline } from '../../components/iammai/GovernanceTimeline';
import { FadeUp, useSSE } from '@iammai-sandbox/shared';

const API_URL = process.env['NEXT_PUBLIC_API_URL'] || 'http://localhost:3001';

function getAuthHeaders(): HeadersInit {
  if (typeof window === 'undefined') return {};
  const token = localStorage.getItem('auth_token');
  return token ? { Authorization: `Bearer ${token}` } : {};
}

interface MatterSummary {
  matter_ref: string;
  latest_phase: string;
  state_family: string;
  state_count: number;
  latest_recorded_at: string;
  conformance?: 'CONFORMANT' | 'NON_CONFORMANT' | 'PARTIAL' | null;
  isHeld?: boolean;
}

interface GovernanceAction {
  governance_action_id: string;
  action_type: string;
  authority_class: string;
  actor_ref: string;
  legitimacy_basis_ref: string;
  matter_ref: string;
  acted_at: string;
}

export default function IammaiDashboard(): JSX.Element {
  const [matters, setMatters] = useState<MatterSummary[]>([]);
  const [recentActions, setRecentActions] = useState<GovernanceAction[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [lastUpdated, setLastUpdated] = useState<Date | null>(null);
  const [orphans, setOrphans] = useState<Array<{
    matter_ref: string;
    latest_phase: string;
    session_id: string;
    session_name: string;
    ended_at: string | null;
  }>>([]);

  const fetchOrphans = useCallback(async () => {
    try {
      const resp = await fetch(`${API_URL}/api/v1/admin/iammai/matters/orphans`, {
        credentials: 'include',
        headers: getAuthHeaders(),
      });
      if (resp.ok) {
        const json = await resp.json();
        setOrphans(json.data?.orphans ?? []);
      }
    } catch { /* ignore */ }
  }, []);

  const fetchMatters = useCallback(async () => {
    try {
      const resp = await fetch(`${API_URL}/api/v1/admin/iammai/matters`, {
        credentials: 'include',
        headers: getAuthHeaders(),
      });
      if (!resp.ok) throw new Error(`HTTP ${resp.status}`);
      const json = await resp.json();
      const matterList: MatterSummary[] = json.data?.matters ?? [];

      // Fetch conformance for each matter (in parallel, max 10)
      const withConformance = await Promise.all(
        matterList.map(async (m) => {
          try {
            const cResp = await fetch(
              `${API_URL}/api/v1/admin/iammai/matters/${encodeURIComponent(m.matter_ref)}/conformance`,
              { credentials: 'include', headers: getAuthHeaders() }
            );
            if (cResp.ok) {
              const cJson = await cResp.json();
              return { ...m, conformance: cJson.data?.overall ?? null };
            }
          } catch { /* ignore per-matter errors */ }
          return { ...m, conformance: null };
        })
      );

      setMatters(withConformance);
      setLastUpdated(new Date());
      setError(null);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to load matters');
    } finally {
      setIsLoading(false);
    }
  }, []);

  useEffect(() => {
    fetchMatters();
    fetchOrphans();
  }, [fetchMatters, fetchOrphans]);

  // SSE for real-time updates
  const { events: sseEvents } = useSSE({
    url: `${API_URL}/api/v1/admin/iammai/stream`,
    enabled: true,
    onEvent: (event) => {
      // Collect governance actions for the feed
      if (event.type === 'governance_action') {
        setRecentActions(prev => {
          const next = [event.data as GovernanceAction, ...prev];
          return next.slice(0, 50);
        });
      }
      // Re-fetch matters on any change
      fetchMatters();
    },
  });

  // Summary stats
  const conformantCount = matters.filter(m => m.conformance === 'CONFORMANT').length;
  const partialCount = matters.filter(m => m.conformance === 'PARTIAL').length;
  const nonConformantCount = matters.filter(m => m.conformance === 'NON_CONFORMANT').length;
  const preparationCount = matters.filter(m => m.state_family === 'preparation').length;
  const standingCount = matters.filter(m => m.state_family === 'standing').length;

  return (
    <AdminLayout>
      <DerivativeBanner />

      <FadeUp>
        {/* Header */}
        <div className="mb-6 flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
          <div>
            <h1 className="text-2xl font-bold text-text-primary font-display tracking-tight">
              IAMMAI Compliance
            </h1>
            <p className="mt-1 text-sm text-text-secondary">
              Real-time constitutional protocol conformance monitoring.
            </p>
          </div>
          {lastUpdated && (
            <span className="text-xs text-text-muted font-mono">
              Updated {lastUpdated.toLocaleTimeString()}
            </span>
          )}
        </div>

        {/* Error */}
        {error && (
          <div className="mb-6 px-4 py-3 rounded-lg border border-error/30 bg-error/5 text-sm text-error">
            {error}
          </div>
        )}

        {/* Orphan Matters Warning — sessions ended without IAMMAI resolution */}
        {orphans.length > 0 && (
          <div className="mb-6 rounded-lg border border-accent-magenta/40 bg-dark-surface1 p-4">
            <h3 className="text-sm font-semibold text-accent-magenta font-mono mb-2">
              ⚠ Orphan Matters ({orphans.length})
            </h3>
            <p className="text-xs text-text-secondary mb-3">
              Sessions ended without IAMMAI resolution. Each matter requires manual FINALIZE or INVALIDATE.
            </p>
            <div className="space-y-2">
              {orphans.map(orphan => (
                <div key={orphan.matter_ref} className="flex items-center justify-between gap-4 text-xs border-b border-dark-border pb-2 last:border-0">
                  <div className="min-w-0">
                    <span className="font-mono text-text-primary truncate block">{orphan.session_name}</span>
                    <span className="font-mono text-text-muted text-[10px]">
                      Last phase: {orphan.latest_phase.toUpperCase()}
                    </span>
                  </div>
                  <a
                    href={`/iammai/${encodeURIComponent(orphan.matter_ref)}`}
                    className="shrink-0 px-3 py-1 text-xs font-mono text-accent-magenta border border-accent-magenta/30 rounded hover:bg-accent-magenta/10 transition-colors"
                  >
                    Resolve →
                  </a>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* Summary stats */}
        <div className="mb-6 grid grid-cols-2 sm:grid-cols-5 gap-3">
          <StatCard label="Total Matters" value={matters.length} />
          <StatCard label="Conformant" value={conformantCount} color="text-success" />
          <StatCard label="Partial" value={partialCount} color="text-warning" />
          <StatCard label="Non-Conformant" value={nonConformantCount} color="text-error" />
          <StatCard label="Preparation / Standing" value={`${preparationCount} / ${standingCount}`} />
        </div>

        {/* Loading skeleton */}
        {isLoading && (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3">
            {[0, 1, 2].map(i => (
              <div key={i} className="rounded-lg border border-dark-border bg-dark-surface1 p-4 animate-pulse h-28" />
            ))}
          </div>
        )}

        {/* Matters grid */}
        {!isLoading && matters.length > 0 && (
          <div className="mb-8 grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3">
            {matters.map((matter, i) => (
              <MatterCard key={matter.matter_ref} matter={matter} index={i} />
            ))}
          </div>
        )}

        {/* Empty state */}
        {!isLoading && matters.length === 0 && !error && (
          <div className="mb-8 rounded-lg border border-dark-border bg-dark-surface1 px-6 py-12 text-center">
            <p className="text-text-secondary text-sm">
              No IAMMAI-tracked matters found. Sessions with{' '}
              <span className="font-mono text-accent-cyan">iammai_tracked = true</span>{' '}
              will appear here.
            </p>
          </div>
        )}

        {/* Real-time governance feed */}
        {recentActions.length > 0 && (
          <GovernanceTimeline actions={recentActions} className="mt-4" />
        )}
      </FadeUp>
    </AdminLayout>
  );
}

function StatCard({ label, value, color }: { label: string; value: string | number; color?: string }): JSX.Element {
  return (
    <div className="rounded-lg border border-dark-border bg-dark-surface1 px-4 py-3">
      <p className="text-[10px] text-text-muted uppercase tracking-wider font-mono">{label}</p>
      <p className={`text-lg font-bold font-mono mt-1 ${color ?? 'text-text-primary'}`}>{value}</p>
    </div>
  );
}
