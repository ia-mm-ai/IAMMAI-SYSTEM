/**
 * IAMMAI Matter Detail page
 *
 * DERIVATIVE SURFACE — Shows full conformance, audit, governance,
 * containment, resolution, and records for a single matter.
 */

import { useState, useEffect, useCallback } from 'react';
import { useRouter } from 'next/router';
import Link from 'next/link';
import { AdminLayout } from '../../components/AdminLayout';
import { DerivativeBanner } from '../../components/iammai/DerivativeBanner';
import { PhaseSequenceBar } from '../../components/iammai/PhaseSequenceBar';
import { ConformanceGrid } from '../../components/iammai/ConformanceGrid';
import { AuditQuestionsPanel } from '../../components/iammai/AuditQuestionsPanel';
import { GovernanceTimeline } from '../../components/iammai/GovernanceTimeline';
import { ContainmentStatusCard } from '../../components/iammai/ContainmentStatusCard';
import { ResolutionStatusCard } from '../../components/iammai/ResolutionStatusCard';
import { RecordsTable } from '../../components/iammai/RecordsTable';
import { FadeUp, useSSE } from '@iammai-sandbox/shared';

const API_URL = process.env['NEXT_PUBLIC_API_URL'] || 'http://localhost:3001';

function getAuthHeaders(): HeadersInit {
  if (typeof window === 'undefined') return {};
  const token = localStorage.getItem('auth_token');
  return token ? { Authorization: `Bearer ${token}` } : {};
}

async function fetchJson(path: string) {
  const resp = await fetch(`${API_URL}${path}`, {
    credentials: 'include',
    headers: getAuthHeaders(),
  });
  if (!resp.ok) throw new Error(`HTTP ${resp.status}`);
  return resp.json();
}

function extractSessionId(matterRef: string): string {
  const parts = matterRef.split(':');
  return parts[parts.length - 1]?.slice(0, 12) ?? matterRef;
}

export default function MatterDetailPage(): JSX.Element {
  const router = useRouter();
  const matterRef = typeof router.query['matterRef'] === 'string'
    ? decodeURIComponent(router.query['matterRef'])
    : null;

  const [context, setContext] = useState<Record<string, unknown> | null>(null);
  const [conformance, setConformance] = useState<Record<string, unknown> | null>(null);
  const [audit, setAudit] = useState<Record<string, unknown>[] | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  const loadData = useCallback(async () => {
    if (!matterRef) return;
    const encoded = encodeURIComponent(matterRef);

    try {
      const [ctxJson, confJson, auditJson] = await Promise.all([
        fetchJson(`/api/v1/admin/iammai/matters/${encoded}/context`),
        fetchJson(`/api/v1/admin/iammai/matters/${encoded}/conformance`),
        fetchJson(`/api/v1/admin/iammai/matters/${encoded}/audit`),
      ]);

      setContext(ctxJson.data);
      setConformance(confJson.data);
      setAudit(auditJson.data?.answers ?? []);
      setError(null);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to load matter data');
    } finally {
      setIsLoading(false);
    }
  }, [matterRef]);

  useEffect(() => {
    loadData();
  }, [loadData]);

  // SSE for live updates on this matter
  useSSE({
    url: `${API_URL}/api/v1/admin/iammai/stream`,
    enabled: !!matterRef,
    onEvent: (event) => {
      const data = event.data as Record<string, unknown>;
      if (data.matter_ref === matterRef) {
        loadData();
      }
    },
  });

  // Extract data from context
  const stateRecords = (context?.stateRecords ?? []) as Array<Record<string, unknown>>;
  const governanceActions = (context?.governanceActions ?? []) as Array<Record<string, unknown>>;
  const containmentRecords = (context?.containmentRecords ?? []) as Array<Record<string, unknown>>;
  const witnessArtifacts = (context?.witnessArtifacts ?? []) as Array<Record<string, unknown>>;
  const validationArtifacts = (context?.validationArtifacts ?? []) as Array<Record<string, unknown>>;
  const contributionRecords = (context?.contributionRecords ?? []) as Array<Record<string, unknown>>;
  const transitionRecords = (context?.transitionRecords ?? []) as Array<Record<string, unknown>>;

  // Current phase
  const lastState = stateRecords.length > 0 ? stateRecords[stateRecords.length - 1] : null;
  const currentPhase = lastState?.state_type as string | null;
  const currentFamily = lastState?.state_family as string | null;

  // Containment status
  const latestContainment = containmentRecords.length > 0
    ? containmentRecords[containmentRecords.length - 1]
    : null;
  const isHeld = latestContainment?.action === 'HOLD';

  // Resolution from audit Q4
  const q4 = audit?.find(a => a.question === 'Q4_RESOLUTION');
  const resolved = q4?.resolved as boolean ?? false;
  const resolutionType = q4?.resolutionType as string | null ?? null;
  const resolvingAction = q4?.resolvingAction as Record<string, unknown> | null;

  // Completed phases
  const completedPhases = stateRecords
    .slice(0, -1)
    .map(r => r.state_type as string);

  if (!matterRef) {
    return (
      <AdminLayout>
        <div className="text-center py-12 text-text-muted">Loading...</div>
      </AdminLayout>
    );
  }

  return (
    <AdminLayout>
      <DerivativeBanner />

      <FadeUp>
        {/* Breadcrumb */}
        <div className="mb-4 flex items-center gap-2 text-xs text-text-muted">
          <Link href="/iammai" className="hover:text-accent-cyan transition-colors">
            IAMMAI
          </Link>
          <span>/</span>
          <span className="font-mono text-text-secondary">{extractSessionId(matterRef)}</span>
        </div>

        {/* Header */}
        <div className="mb-6">
          <h1 className="text-xl font-bold text-text-primary font-display tracking-tight">
            <span className="text-text-muted font-normal">bnk:session:</span>
            {extractSessionId(matterRef)}
          </h1>
          <div className="mt-2 flex items-center gap-3">
            {currentPhase && (
              <span className="text-sm font-mono text-accent-cyan">{currentPhase.toUpperCase()}</span>
            )}
            {currentFamily && (
              <span className={`px-1.5 py-0.5 text-[10px] font-mono rounded border ${
                currentFamily === 'standing'
                  ? 'text-accent-cyan border-accent-cyan/30'
                  : 'text-text-secondary border-dark-border'
              }`}>
                {currentFamily.toUpperCase()}
              </span>
            )}
            {isHeld && (
              <span className="px-1.5 py-0.5 text-[10px] font-mono font-bold text-accent-magenta border border-accent-magenta/30 rounded animate-pulse">
                HELD
              </span>
            )}
            {resolved && (
              <span className={`px-1.5 py-0.5 text-[10px] font-mono font-bold rounded border ${
                resolutionType === 'FINALIZE' ? 'text-success border-success/30'
                : resolutionType === 'INVALIDATE' ? 'text-error border-error/30'
                : 'text-accent-blue border-accent-blue/30'
              }`}>
                {resolutionType}
              </span>
            )}
          </div>
        </div>

        {/* Error */}
        {error && (
          <div className="mb-6 px-4 py-3 rounded-lg border border-error/30 bg-error/5 text-sm text-error">
            {error}
          </div>
        )}

        {/* Loading */}
        {isLoading && (
          <div className="space-y-4">
            <div className="h-32 rounded-lg border border-dark-border bg-dark-surface1 animate-pulse" />
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
              <div className="h-64 rounded-lg border border-dark-border bg-dark-surface1 animate-pulse" />
              <div className="h-64 rounded-lg border border-dark-border bg-dark-surface1 animate-pulse" />
            </div>
          </div>
        )}

        {!isLoading && context && (
          <>
            {/* Phase Sequence Bar */}
            <PhaseSequenceBar
              currentPhase={currentPhase}
              isHeld={isHeld}
              completedPhases={completedPhases}
              className="mb-6"
            />

            {/* Conformance + Audit Questions */}
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-6">
              {conformance && (
                <ConformanceGrid
                  report={conformance as any}
                />
              )}
              {audit && (
                <AuditQuestionsPanel
                  answers={audit as any}
                />
              )}
            </div>

            {/* Governance Timeline */}
            <div className="mb-6">
              <GovernanceTimeline actions={governanceActions as any} />
            </div>

            {/* Containment + Resolution */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-6">
              <ContainmentStatusCard
                records={containmentRecords as any}
                isHeld={isHeld}
                matterRef={matterRef}
                onActionComplete={loadData}
              />
              <ResolutionStatusCard
                resolved={resolved}
                resolutionType={resolutionType}
                resolvingActorRef={resolvingAction?.actor_ref as string ?? null}
                resolvingAuthorityClass={resolvingAction?.authority_class as string ?? null}
                successorMatterRef={null}
                matterRef={matterRef}
                onActionComplete={loadData}
              />
            </div>

            {/* IAMMAI Errors — failed/blocked validation artifacts */}
            {(() => {
              const failures = validationArtifacts.filter(
                v => v['outcome'] === 'fail' || v['outcome'] === 'blocked'
              );
              if (failures.length === 0) return null;
              return (
                <div className="mb-6 rounded-lg border border-error/30 bg-error/5 p-4">
                  <h3 className="text-sm font-semibold text-error mb-3 font-mono">
                    ⚠ IAMMAI Validation Failures ({failures.length})
                  </h3>
                  <div className="space-y-2 max-h-48 overflow-y-auto">
                    {failures.map(v => (
                      <div key={v['validation_id'] as string} className="flex items-start gap-3 text-xs border-b border-error/10 pb-2 last:border-0">
                        <span className={`shrink-0 px-1 py-0.5 text-[10px] font-mono font-bold rounded border ${
                          v['outcome'] === 'blocked'
                            ? 'text-accent-magenta border-accent-magenta/30'
                            : 'text-error border-error/30'
                        }`}>
                          {String(v['outcome']).toUpperCase()}
                        </span>
                        <div className="flex-1 min-w-0">
                          <span className="font-mono text-text-secondary">{v['validation_type'] as string}</span>
                          <p className="text-text-muted font-mono text-[10px] truncate">{v['condition_set_ref'] as string}</p>
                          {!!(v['reason_refs'] && Array.isArray(v['reason_refs'])) && (
                            <p className="text-error/70 text-[10px]">{(v['reason_refs'] as string[]).join('; ')}</p>
                          )}
                        </div>
                        <span className="shrink-0 text-text-muted text-[10px] font-mono">
                          {new Date(v['checked_at'] as string).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                        </span>
                      </div>
                    ))}
                  </div>
                </div>
              );
            })()}

            {/* Records Table */}
            <RecordsTable
              witnesses={witnessArtifacts as any}
              validations={validationArtifacts as any}
              contributions={contributionRecords as any}
              className="mb-6"
            />
          </>
        )}
      </FadeUp>
    </AdminLayout>
  );
}
