/**
 * Admin login page
 * @see specs/001-ephemeral-kernel/tasks.md#T044
 */

import { useState, FormEvent } from 'react';
import { useRouter } from 'next/router';
import { HoverGlow } from '@iammai-sandbox/shared';

const API_URL = process.env['NEXT_PUBLIC_API_URL'] || 'http://localhost:3001';

export default function LoginPage(): JSX.Element {
  const router = useRouter();
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState<string | null>(null);
  const [isLoading, setIsLoading] = useState(false);

  const handleSubmit = async (e: FormEvent): Promise<void> => {
    e.preventDefault();
    setError(null);
    setIsLoading(true);

    try {
      const response = await fetch(`${API_URL}/api/v1/auth/login`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        credentials: 'include',
        body: JSON.stringify({ email, password }),
      });

      if (!response.ok) {
        const data = await response.json();
        throw new Error(data.message || 'Login failed');
      }

      const data = await response.json();

      // Store token in localStorage for iOS/mobile compatibility
      if (data.token) {
        localStorage.setItem('auth_token', data.token);
      }

      // Redirect to sessions page on success
      router.push('/sessions');
    } catch (err) {
      setError(err instanceof Error ? err.message : 'An error occurred');
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="min-h-screen flex items-center justify-center bg-dark-base scan-lines">
      <div className="max-w-md w-full space-y-8 p-8 bg-dark-surface1 rounded-lg shadow-lg border border-dark-border shadow-glow-cyan-subtle">
        <div>
          <h1 className="text-center text-4xl font-bold leading-tight text-text-primary font-display tracking-tight text-glow-cyan-medium">
            Admin Login
          </h1>
          <p className="mt-2 text-center text-base font-normal leading-normal text-text-secondary">
            IAMMAI Sandbox
          </p>
        </div>

        <form className="mt-8 space-y-6" onSubmit={handleSubmit}>
          {error && (
            <div className="rounded-md bg-error-bg border border-error p-4">
              <p className="text-sm font-normal leading-normal text-error-text">{error}</p>
            </div>
          )}

          <div className="space-y-4">
            <div>
              <label htmlFor="email" className="block text-sm font-medium text-text-primary mb-2">
                Email address
              </label>
              <input
                id="email"
                name="email"
                type="email"
                autoComplete="email"
                required
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                className="block w-full px-4 py-3 bg-dark-surface2 border border-dark-border rounded-md shadow-sm placeholder-text-muted text-text-primary focus:outline-none focus:ring-2 focus:ring-accent-cyan focus:border-accent-cyan transition-colors"
                placeholder="admin@example.com"
              />
            </div>

            <div>
              <label htmlFor="password" className="block text-sm font-medium text-text-primary mb-2">
                Password
              </label>
              <input
                id="password"
                name="password"
                type="password"
                autoComplete="current-password"
                required
                minLength={8}
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                className="block w-full px-4 py-3 bg-dark-surface2 border border-dark-border rounded-md shadow-sm placeholder-text-muted text-text-primary focus:outline-none focus:ring-2 focus:ring-accent-cyan focus:border-accent-cyan transition-colors"
                placeholder="Enter your password"
              />
            </div>
          </div>

          <HoverGlow color="cyan" disabled={isLoading} className="rounded-md">
            <button
              type="submit"
              disabled={isLoading}
              className="w-full flex justify-center py-3 px-4 border border-transparent rounded-md font-semibold text-dark-base bg-accent-cyan hover:bg-accent-cyan-hover focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-offset-dark-surface1 focus:ring-accent-cyan disabled:opacity-50 disabled:cursor-not-allowed transition-colors duration-hover"
            >
              {isLoading ? 'Signing in...' : 'Sign in'}
            </button>
          </HoverGlow>
        </form>
      </div>
    </div>
  );
}
