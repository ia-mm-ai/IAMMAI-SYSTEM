import type { AppProps } from 'next/app';
import { Inter, Space_Grotesk } from 'next/font/google';
import { ToastProvider } from '@iammai-sandbox/shared';
import '../styles/globals.css';

const inter = Inter({
  subsets: ['latin'],
  display: 'swap',
  variable: '--font-inter',
  weight: ['400', '500', '600', '700'],
});

const spaceGrotesk = Space_Grotesk({
  subsets: ['latin'],
  display: 'swap',
  variable: '--font-display',
  weight: ['500', '600', '700'],
});

export default function App({ Component, pageProps }: AppProps): JSX.Element {
  return (
    <div className={`${inter.variable} ${spaceGrotesk.variable} font-sans`}>
      <ToastProvider>
        <Component {...pageProps} />
      </ToastProvider>
    </div>
  );
}
