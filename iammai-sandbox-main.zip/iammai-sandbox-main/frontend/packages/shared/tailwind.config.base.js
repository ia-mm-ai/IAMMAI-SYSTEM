/**
 * Shared Tailwind CSS Configuration Base
 * Feature: 003-dark-futuristic-ui
 *
 * This configuration is extended by both user and admin apps.
 * Defines the complete design system: colors, typography, spacing, animations.
 *
 * Phase 1: Ultra-dark palette with neon accents and glow utilities.
 */

const plugin = require('tailwindcss/plugin');

module.exports = {
  theme: {
    extend: {
      colors: {
        // Ultra-dark backgrounds
        dark: {
          base: '#050505',      // Primary page background
          surface1: '#080808',  // Cards, panels
          surface2: '#0a0a0a',  // Elevated elements
          surface3: '#0d0d0d',  // Hover states
          border: '#1a1a1a',    // Subtle borders
          // Legacy values for backwards compatibility
          950: '#0a0a0a',
          900: '#0d1117',
          850: '#121212',
          800: '#161b22',
          750: '#1c2128',
        },
        // Text colors (low-contrast futuristic aesthetic)
        text: {
          primary: '#a0a0a0',   // ~3.5:1 contrast
          secondary: '#707070', // ~2.5:1 contrast
          muted: '#505050',     // ~1.8:1 contrast
          bright: '#e0e0e0',    // For emphasis
          // Legacy values
          tertiary: '#6e7681',
        },
        // Neon accent colors
        accent: {
          cyan: {
            DEFAULT: '#00ffff',  // Pure cyan (neon)
            hover: '#00e6e6',
            subtle: '#0a2626',
            glow: 'rgba(0, 255, 255, 0.5)',
          },
          magenta: {
            DEFAULT: '#ff00ff',  // Pure magenta (neon)
            hover: '#e600e6',
            subtle: '#260a26',
            glow: 'rgba(255, 0, 255, 0.5)',
          },
          blue: {
            DEFAULT: '#00ccff',  // Neon blue
            hover: '#00b8e6',
            subtle: '#0a1f26',
            glow: 'rgba(0, 204, 255, 0.5)',
          },
          // Legacy values
          purple: {
            DEFAULT: '#bc8cff',
            hover: '#a870e8',
            subtle: '#2e1f47',
          },
          pink: {
            DEFAULT: '#ff00ff',
            hover: '#e600e6',
            subtle: '#3d1a3d',
          },
        },
        // Semantic colors with neon variants
        success: {
          DEFAULT: '#00ff88',
          glow: 'rgba(0, 255, 136, 0.5)',
          text: '#7ee787',
          bg: '#033a16',
        },
        warning: {
          DEFAULT: '#ffaa00',
          glow: 'rgba(255, 170, 0, 0.5)',
          text: '#f0c674',
          bg: '#3d2e00',
        },
        error: {
          DEFAULT: '#ff3366',
          glow: 'rgba(255, 51, 102, 0.5)',
          text: '#ff7b72',
          bg: '#3d0f0e',
        },
        info: {
          DEFAULT: '#58a6ff',
          glow: 'rgba(88, 166, 255, 0.5)',
          text: '#79c0ff',
          bg: '#0d2d4e',
        },
      },
      fontFamily: {
        display: ['var(--font-display)', '"Space Grotesk"', 'var(--font-inter)', 'sans-serif'],
        sans: ['var(--font-inter)', '"Space Grotesk"', 'ui-sans-serif', '-apple-system', 'BlinkMacSystemFont', '"Segoe UI"', 'Roboto', '"Helvetica Neue"', 'Arial', 'sans-serif'],
        mono: ['"SF Mono"', '"Fira Code"', '"Cascadia Code"', 'Consolas', 'monospace'],
      },
      letterSpacing: {
        tightest: '-0.05em',
        tighter: '-0.025em',
        tight: '-0.015em',
        normal: '0',
        wide: '0.025em',
        wider: '0.05em',
        widest: '0.1em',
        'ultra-wide': '0.2em',
      },
      fontSize: {
        xs: ['0.75rem', { lineHeight: '1.25' }],     // 12px
        sm: ['0.875rem', { lineHeight: '1.5' }],     // 14px
        base: ['1rem', { lineHeight: '1.5' }],       // 16px
        lg: ['1.125rem', { lineHeight: '1.5' }],     // 18px
        xl: ['1.25rem', { lineHeight: '1.375' }],    // 20px
        '2xl': ['1.5rem', { lineHeight: '1.375' }],  // 24px
        '3xl': ['1.875rem', { lineHeight: '1.25' }], // 30px
        '4xl': ['2.25rem', { lineHeight: '1.25' }],  // 36px
        '5xl': ['3rem', { lineHeight: '1.25' }],     // 48px
        '6xl': ['3.75rem', { lineHeight: '1.25' }],  // 60px
      },
      fontWeight: {
        normal: '400',
        medium: '500',
        semibold: '600',
        bold: '700',
      },
      spacing: {
        // 8px primary grid + 4px sub-grid
        0: '0px',
        1: '0.25rem',   // 4px
        2: '0.5rem',    // 8px
        3: '0.75rem',   // 12px
        4: '1rem',      // 16px
        6: '1.5rem',    // 24px
        8: '2rem',      // 32px
        10: '2.5rem',   // 40px
        12: '3rem',     // 48px
        16: '4rem',     // 64px
        20: '5rem',     // 80px
        24: '6rem',     // 96px
      },
      // Glow box-shadow utilities
      boxShadow: {
        // Cyan glow (3 intensities)
        'glow-cyan-subtle': '0 0 2px rgba(0,255,255,0.15), 0 0 6px rgba(0,255,255,0.1), 0 0 12px rgba(0,255,255,0.05)',
        'glow-cyan-medium': '0 0 4px rgba(0,255,255,0.3), 0 0 12px rgba(0,255,255,0.2), 0 0 24px rgba(0,255,255,0.1)',
        'glow-cyan-bright': '0 0 6px rgba(0,255,255,0.5), 0 0 18px rgba(0,255,255,0.35), 0 0 36px rgba(0,255,255,0.2)',
        // Magenta glow (3 intensities)
        'glow-magenta-subtle': '0 0 2px rgba(255,0,255,0.15), 0 0 6px rgba(255,0,255,0.1), 0 0 12px rgba(255,0,255,0.05)',
        'glow-magenta-medium': '0 0 4px rgba(255,0,255,0.3), 0 0 12px rgba(255,0,255,0.2), 0 0 24px rgba(255,0,255,0.1)',
        'glow-magenta-bright': '0 0 6px rgba(255,0,255,0.5), 0 0 18px rgba(255,0,255,0.35), 0 0 36px rgba(255,0,255,0.2)',
        // Blue glow (3 intensities)
        'glow-blue-subtle': '0 0 2px rgba(0,204,255,0.15), 0 0 6px rgba(0,204,255,0.1), 0 0 12px rgba(0,204,255,0.05)',
        'glow-blue-medium': '0 0 4px rgba(0,204,255,0.3), 0 0 12px rgba(0,204,255,0.2), 0 0 24px rgba(0,204,255,0.1)',
        'glow-blue-bright': '0 0 6px rgba(0,204,255,0.5), 0 0 18px rgba(0,204,255,0.35), 0 0 36px rgba(0,204,255,0.2)',
        // Error glow (3 intensities)
        'glow-error-subtle': '0 0 2px rgba(255,51,102,0.15), 0 0 6px rgba(255,51,102,0.1), 0 0 12px rgba(255,51,102,0.05)',
        'glow-error-medium': '0 0 4px rgba(255,51,102,0.3), 0 0 12px rgba(255,51,102,0.2), 0 0 24px rgba(255,51,102,0.1)',
        'glow-error-bright': '0 0 6px rgba(255,51,102,0.5), 0 0 18px rgba(255,51,102,0.35), 0 0 36px rgba(255,51,102,0.2)',
        // Success glow (3 intensities)
        'glow-success-subtle': '0 0 2px rgba(0,255,136,0.15), 0 0 6px rgba(0,255,136,0.1), 0 0 12px rgba(0,255,136,0.05)',
        'glow-success-medium': '0 0 4px rgba(0,255,136,0.3), 0 0 12px rgba(0,255,136,0.2), 0 0 24px rgba(0,255,136,0.1)',
        'glow-success-bright': '0 0 6px rgba(0,255,136,0.5), 0 0 18px rgba(0,255,136,0.35), 0 0 36px rgba(0,255,136,0.2)',
      },
      transitionDuration: {
        instant: '0ms',
        fast: '150ms',
        hover: '250ms',   // Hover transitions
        medium: '300ms',
        slow: '500ms',
        reveal: '600ms',
        pulse: '2500ms',  // Slow pulsing effects
      },
      transitionTimingFunction: {
        'out': 'cubic-bezier(0, 0, 0.2, 1)',
        'in': 'cubic-bezier(0.4, 0, 1, 1)',
        'in-out': 'cubic-bezier(0.4, 0, 0.2, 1)',
        'reveal': 'cubic-bezier(0.22, 1, 0.36, 1)',
      },
    },
  },
  plugins: [
    // Text shadow plugin for heading glow effects
    plugin(function({ addUtilities }) {
      addUtilities({
        // Cyan text glow
        '.text-glow-cyan-subtle': {
          textShadow: '0 0 2px rgba(0,255,255,0.3), 0 0 6px rgba(0,255,255,0.15)',
        },
        '.text-glow-cyan-medium': {
          textShadow: '0 0 4px rgba(0,255,255,0.5), 0 0 12px rgba(0,255,255,0.25)',
        },
        '.text-glow-cyan-bright': {
          textShadow: '0 0 6px rgba(0,255,255,0.7), 0 0 18px rgba(0,255,255,0.4), 0 0 30px rgba(0,255,255,0.2)',
        },
        // Magenta text glow
        '.text-glow-magenta-subtle': {
          textShadow: '0 0 2px rgba(255,0,255,0.3), 0 0 6px rgba(255,0,255,0.15)',
        },
        '.text-glow-magenta-medium': {
          textShadow: '0 0 4px rgba(255,0,255,0.5), 0 0 12px rgba(255,0,255,0.25)',
        },
        '.text-glow-magenta-bright': {
          textShadow: '0 0 6px rgba(255,0,255,0.7), 0 0 18px rgba(255,0,255,0.4), 0 0 30px rgba(255,0,255,0.2)',
        },
        // Blue text glow
        '.text-glow-blue-subtle': {
          textShadow: '0 0 2px rgba(0,204,255,0.3), 0 0 6px rgba(0,204,255,0.15)',
        },
        '.text-glow-blue-medium': {
          textShadow: '0 0 4px rgba(0,204,255,0.5), 0 0 12px rgba(0,204,255,0.25)',
        },
        '.text-glow-blue-bright': {
          textShadow: '0 0 6px rgba(0,204,255,0.7), 0 0 18px rgba(0,204,255,0.4), 0 0 30px rgba(0,204,255,0.2)',
        },
      });
    }),
  ],
};
