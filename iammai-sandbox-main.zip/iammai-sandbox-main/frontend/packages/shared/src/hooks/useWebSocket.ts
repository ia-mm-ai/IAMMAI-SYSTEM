/**
 * WebSocket hook for real-time chat communication
 * @see specs/001-ephemeral-kernel/tasks.md#T074
 * @see specs/001-ephemeral-kernel/contracts/websocket.md
 */

import { useEffect, useRef, useState, useCallback } from 'react';

export interface WebSocketMessage {
  type: string;
  payload?: Record<string, unknown>;
  timestamp: string;
}

export interface Message {
  id: string;
  role: 'user' | 'assistant';
  content: string;
  timestamp: string;
}

export type UseWebSocketOptions = {
  sessionId: string;
  token: string;
  wsUrl?: string; // Optional WebSocket base URL
  onMessage?: (message: WebSocketMessage) => void;
  onConnectionChange?: (connected: boolean) => void;
  onError?: (error: Error) => void;
  onConversationHistory?: (history: Message[]) => void;
};

export interface UseWebSocketReturn {
  connected: boolean;
  dissolved: boolean;
  sendMessage: (content: string, messageId?: string) => void;
  disconnect: () => void;
  reconnect: () => void;
}

const WS_HOST = process.env['NEXT_PUBLIC_WS_URL'] || 'ws://localhost:3001';
const MAX_RECONNECT_ATTEMPTS = 5;
const BASE_RECONNECT_DELAY = 1000;
const MAX_RECONNECT_DELAY = 30000;

/**
 * WebSocket hook for chat communication
 */
export function useWebSocket(options: UseWebSocketOptions): UseWebSocketReturn {
  const { sessionId, token, wsUrl, onMessage, onConnectionChange, onError, onConversationHistory } = options;

  const [connected, setConnected] = useState(false);
  const [dissolved, setDissolved] = useState(false);
  const wsRef = useRef<WebSocket | null>(null);
  const reconnectAttemptsRef = useRef(0);
  const reconnectTimeoutRef = useRef<NodeJS.Timeout | null>(null);
  const shouldReconnectRef = useRef(true);
  const kernelDissolvedRef = useRef(false);

  // Store wsUrl in ref to avoid stale closures
  const wsUrlRef = useRef(wsUrl || WS_HOST);

  // Store callbacks in refs to avoid recreation
  const onMessageRef = useRef(onMessage);
  const onConnectionChangeRef = useRef(onConnectionChange);
  const onErrorRef = useRef(onError);
  const onConversationHistoryRef = useRef(onConversationHistory);

  useEffect(() => {
    wsUrlRef.current = wsUrl || WS_HOST;
    onMessageRef.current = onMessage;
    onConnectionChangeRef.current = onConnectionChange;
    onErrorRef.current = onError;
    onConversationHistoryRef.current = onConversationHistory;
  });

  /**
   * Calculate backoff delay for reconnection
   */
  const getReconnectDelay = useCallback(() => {
    const delay = Math.min(
      BASE_RECONNECT_DELAY * Math.pow(2, reconnectAttemptsRef.current),
      MAX_RECONNECT_DELAY
    );
    return delay;
  }, []);

  /**
   * Connect to WebSocket server
   */
  const connect = useCallback(() => {
    // Don't connect if sessionId or token is missing, empty, or sentinel value
    if (!sessionId || !token) {
      return;
    }

    if (sessionId.trim() === '' || token.trim() === '') {
      return;
    }

    // Don't reconnect if kernel was dissolved
    if (kernelDissolvedRef.current) {
      return;
    }

    // Don't reconnect if we've exceeded max attempts
    if (reconnectAttemptsRef.current >= MAX_RECONNECT_ATTEMPTS) {
      onErrorRef.current?.(new Error('Max reconnection attempts exceeded'));
      return;
    }

    const wsConnectUrl = `${wsUrlRef.current}/ws/sessions/${sessionId}?token=${encodeURIComponent(token)}`;
    const ws = new WebSocket(wsConnectUrl);

    ws.onopen = () => {
      setConnected(true);
      onConnectionChangeRef.current?.(true);
      reconnectAttemptsRef.current = 0;
    };

    ws.onmessage = (event: MessageEvent) => {
      try {
        const message: WebSocketMessage = JSON.parse(event.data);

        // Handle CONNECTION_ACK with conversation history (FR-021)
        if (message.type === 'CONNECTION_ACK' && message.payload?.['conversationHistory']) {
          onConversationHistoryRef.current?.(message.payload['conversationHistory'] as Message[]);
        }

        // Handle kernel dissolution
        if (message.type === 'KERNEL_DISSOLVED') {
          kernelDissolvedRef.current = true;
          shouldReconnectRef.current = false;
          setDissolved(true);
          ws.close();
        }

        onMessageRef.current?.(message);
      } catch (error) {
        onErrorRef.current?.(error as Error);
      }
    };

    ws.onerror = (_error) => {
      onErrorRef.current?.(new Error('WebSocket connection error'));
    };

    ws.onclose = (event: CloseEvent) => {
      setConnected(false);
      onConnectionChangeRef.current?.(false);

      // Don't reconnect on certain close codes
      if (event.code === 1008 || kernelDissolvedRef.current) {
        // 1008 = policy violation (invalid token)
        shouldReconnectRef.current = false;
        return;
      }

      // Attempt reconnection if appropriate
      if (shouldReconnectRef.current && event.code !== 1000) {
        reconnectAttemptsRef.current++;
        const delay = getReconnectDelay();

        reconnectTimeoutRef.current = setTimeout(() => {
          connect();
        }, delay);
      }
    };

    wsRef.current = ws;
  }, [sessionId, token, getReconnectDelay]);

  /**
   * Send a user message
   */
  const sendMessage = useCallback((content: string, messageId?: string) => {
    if (!wsRef.current || wsRef.current.readyState !== WebSocket.OPEN) {
      onErrorRef.current?.(new Error('WebSocket is not connected'));
      return;
    }

    const message: WebSocketMessage = {
      type: 'USER_MESSAGE',
      payload: {
        messageId: messageId || crypto.randomUUID(),
        content,
      },
      timestamp: new Date().toISOString(),
    };

    wsRef.current.send(JSON.stringify(message));
  }, []);

  /**
   * Disconnect from WebSocket
   */
  const disconnect = useCallback(() => {
    shouldReconnectRef.current = false;

    if (reconnectTimeoutRef.current) {
      clearTimeout(reconnectTimeoutRef.current);
      reconnectTimeoutRef.current = null;
    }

    if (wsRef.current) {
      wsRef.current.close(1000);
      wsRef.current = null;
    }
  }, []);

  /**
   * Manually trigger reconnection
   */
  const reconnect = useCallback(() => {
    disconnect();
    shouldReconnectRef.current = true;
    reconnectAttemptsRef.current = 0;
    kernelDissolvedRef.current = false;
    connect();
  }, [connect, disconnect]);

  // Connect when connect function changes (which happens when sessionId/token/wsUrl change)
  useEffect(() => {
    connect();

    // Cleanup on unmount or when connection params change
    return () => {
      disconnect();
    };
  }, [connect, disconnect]);

  return {
    connected,
    dissolved,
    sendMessage,
    disconnect,
    reconnect,
  };
}
