/**
 * SSE hook for real-time event streaming
 * Used by IAMMAI compliance dashboard for live updates.
 */

import { useEffect, useRef, useState, useCallback } from 'react';

export interface SSEEvent {
  type: string;
  data: unknown;
  timestamp: string;
}

export interface UseSSEOptions {
  url: string;
  events?: string[];
  onEvent?: (event: SSEEvent) => void;
  enabled?: boolean;
}

export interface UseSSEReturn {
  connected: boolean;
  lastEvent: SSEEvent | null;
  events: SSEEvent[];
  error: Error | null;
}

const MAX_EVENTS = 100;
const MAX_RECONNECT_ATTEMPTS = 5;
const BASE_RECONNECT_DELAY = 1000;
const MAX_RECONNECT_DELAY = 30000;

/**
 * SSE hook for real-time event streaming.
 * Uses native EventSource API with cookie-based auth.
 */
export function useSSE(options: UseSSEOptions): UseSSEReturn {
  const { url, events, onEvent, enabled = true } = options;

  const [connected, setConnected] = useState(false);
  const [lastEvent, setLastEvent] = useState<SSEEvent | null>(null);
  const [sseEvents, setSseEvents] = useState<SSEEvent[]>([]);
  const [error, setError] = useState<Error | null>(null);

  const sourceRef = useRef<EventSource | null>(null);
  const reconnectAttemptsRef = useRef(0);
  const reconnectTimeoutRef = useRef<ReturnType<typeof setTimeout> | null>(null);
  const onEventRef = useRef(onEvent);

  useEffect(() => {
    onEventRef.current = onEvent;
  });

  const addEvent = useCallback((evt: SSEEvent) => {
    setLastEvent(evt);
    setSseEvents(prev => {
      const next = [evt, ...prev];
      return next.length > MAX_EVENTS ? next.slice(0, MAX_EVENTS) : next;
    });
    onEventRef.current?.(evt);
  }, []);

  const connect = useCallback(() => {
    if (!enabled || !url) return;

    if (reconnectAttemptsRef.current >= MAX_RECONNECT_ATTEMPTS) {
      setError(new Error('Max SSE reconnection attempts exceeded'));
      return;
    }

    const source = new EventSource(url, { withCredentials: true });
    sourceRef.current = source;

    source.addEventListener('connected', () => {
      setConnected(true);
      setError(null);
      reconnectAttemptsRef.current = 0;
    });

    source.onerror = () => {
      setConnected(false);
      source.close();
      sourceRef.current = null;

      reconnectAttemptsRef.current++;
      const delay = Math.min(
        BASE_RECONNECT_DELAY * Math.pow(2, reconnectAttemptsRef.current),
        MAX_RECONNECT_DELAY
      );
      reconnectTimeoutRef.current = setTimeout(connect, delay);
    };

    // Listen for specific event types or default set
    const eventTypes = events ?? [
      'phase_change',
      'governance_action',
      'containment_change',
      'witness_emitted',
      'validation_completed',
      'transition_occurred',
      'contribution_recorded',
    ];

    for (const eventType of eventTypes) {
      source.addEventListener(eventType, (e: Event) => {
        const messageEvent = e as MessageEvent;
        try {
          const data = JSON.parse(messageEvent.data);
          addEvent({
            type: eventType,
            data,
            timestamp: new Date().toISOString(),
          });
        } catch {
          // Ignore parse errors
        }
      });
    }

    source.addEventListener('heartbeat', () => {
      // Keep-alive, no action needed
    });
  }, [url, enabled, events, addEvent]);

  useEffect(() => {
    connect();

    return () => {
      if (reconnectTimeoutRef.current) {
        clearTimeout(reconnectTimeoutRef.current);
      }
      if (sourceRef.current) {
        sourceRef.current.close();
        sourceRef.current = null;
      }
      setConnected(false);
    };
  }, [connect]);

  return { connected, lastEvent, events: sseEvents, error };
}
