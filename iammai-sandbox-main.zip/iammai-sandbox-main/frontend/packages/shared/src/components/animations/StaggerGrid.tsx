/**
 * StaggerGrid Animation Component
 * Feature: 002-dark-futuristic-ui
 *
 * Grid container that staggers animation of child elements.
 * Each child fades in with a slight delay for a cascading effect.
 */

import { motion } from 'framer-motion';
import { useReducedMotion } from '../../hooks/useReducedMotion';

interface StaggerGridProps {
  children: React.ReactNode;
  className?: string;
  staggerDelay?: number;
}

const container = {
  hidden: { opacity: 0 },
  show: {
    opacity: 1,
    transition: {
      staggerChildren: 0.1,
    },
  },
};

const item = {
  hidden: { opacity: 0, y: 20 },
  show: {
    opacity: 1,
    y: 0,
    transition: {
      duration: 0.6,
      ease: [0.22, 1, 0.36, 1] as [number, number, number, number],
    },
  },
};

export function StaggerGrid({
  children,
  className,
  staggerDelay = 0.1,
}: StaggerGridProps): JSX.Element {
  const reducedMotion = useReducedMotion();

  // If reduced motion is preferred, render without animations
  if (reducedMotion) {
    return <div className={className}>{children}</div>;
  }

  const containerVariants = {
    ...container,
    show: {
      ...container.show,
      transition: {
        staggerChildren: staggerDelay,
      },
    },
  };

  return (
    <motion.div
      variants={containerVariants}
      initial="hidden"
      whileInView="show"
      viewport={{ once: true, margin: '-100px' }}
      className={className}
    >
      {Array.isArray(children)
        ? children.map((child, index) => (
            <motion.div key={index} variants={item}>
              {child}
            </motion.div>
          ))
        : <motion.div variants={item}>{children}</motion.div>}
    </motion.div>
  );
}
