/**
 * HoverGlow Animation Component
 * Feature: 003-dark-futuristic-ui
 *
 * Wraps children with an interactive hover glow effect.
 * Transitions from subtle to bright glow intensity on hover.
 * Respects prefers-reduced-motion preference.
 */

import { motion } from 'framer-motion';
import { useReducedMotion } from '../../hooks/useReducedMotion';

type GlowColor = 'cyan' | 'magenta' | 'blue' | 'error' | 'success';
type GlowIntensity = 'subtle' | 'medium' | 'bright';

interface HoverGlowProps {
  children: React.ReactNode;
  color?: GlowColor;
  intensity?: GlowIntensity;
  hoverIntensity?: GlowIntensity;
  disabled?: boolean;
  className?: string;
}

// Glow shadow values matching tailwind.config.base.js
const glowShadows: Record<GlowColor, Record<GlowIntensity, string>> = {
  cyan: {
    subtle: '0 0 2px rgba(0,255,255,0.15), 0 0 6px rgba(0,255,255,0.1), 0 0 12px rgba(0,255,255,0.05)',
    medium: '0 0 4px rgba(0,255,255,0.3), 0 0 12px rgba(0,255,255,0.2), 0 0 24px rgba(0,255,255,0.1)',
    bright: '0 0 6px rgba(0,255,255,0.5), 0 0 18px rgba(0,255,255,0.35), 0 0 36px rgba(0,255,255,0.2)',
  },
  magenta: {
    subtle: '0 0 2px rgba(255,0,255,0.15), 0 0 6px rgba(255,0,255,0.1), 0 0 12px rgba(255,0,255,0.05)',
    medium: '0 0 4px rgba(255,0,255,0.3), 0 0 12px rgba(255,0,255,0.2), 0 0 24px rgba(255,0,255,0.1)',
    bright: '0 0 6px rgba(255,0,255,0.5), 0 0 18px rgba(255,0,255,0.35), 0 0 36px rgba(255,0,255,0.2)',
  },
  blue: {
    subtle: '0 0 2px rgba(0,204,255,0.15), 0 0 6px rgba(0,204,255,0.1), 0 0 12px rgba(0,204,255,0.05)',
    medium: '0 0 4px rgba(0,204,255,0.3), 0 0 12px rgba(0,204,255,0.2), 0 0 24px rgba(0,204,255,0.1)',
    bright: '0 0 6px rgba(0,204,255,0.5), 0 0 18px rgba(0,204,255,0.35), 0 0 36px rgba(0,204,255,0.2)',
  },
  error: {
    subtle: '0 0 2px rgba(255,51,102,0.15), 0 0 6px rgba(255,51,102,0.1), 0 0 12px rgba(255,51,102,0.05)',
    medium: '0 0 4px rgba(255,51,102,0.3), 0 0 12px rgba(255,51,102,0.2), 0 0 24px rgba(255,51,102,0.1)',
    bright: '0 0 6px rgba(255,51,102,0.5), 0 0 18px rgba(255,51,102,0.35), 0 0 36px rgba(255,51,102,0.2)',
  },
  success: {
    subtle: '0 0 2px rgba(0,255,136,0.15), 0 0 6px rgba(0,255,136,0.1), 0 0 12px rgba(0,255,136,0.05)',
    medium: '0 0 4px rgba(0,255,136,0.3), 0 0 12px rgba(0,255,136,0.2), 0 0 24px rgba(0,255,136,0.1)',
    bright: '0 0 6px rgba(0,255,136,0.5), 0 0 18px rgba(0,255,136,0.35), 0 0 36px rgba(0,255,136,0.2)',
  },
};

export function HoverGlow({
  children,
  color = 'cyan',
  intensity = 'medium',
  hoverIntensity = 'bright',
  disabled = false,
  className,
}: HoverGlowProps): JSX.Element {
  const reducedMotion = useReducedMotion();

  // If disabled or reduced motion, render without animation
  if (disabled || reducedMotion) {
    return <div className={className}>{children}</div>;
  }

  const baseShadow = glowShadows[color][intensity];
  const hoverShadow = glowShadows[color][hoverIntensity];

  return (
    <motion.div
      initial={{ boxShadow: baseShadow }}
      whileHover={{ boxShadow: hoverShadow }}
      transition={{
        duration: 0.25, // 250ms hover duration from design tokens
        ease: [0, 0, 0.2, 1], // ease-out from design tokens
      }}
      className={className}
    >
      {children}
    </motion.div>
  );
}
