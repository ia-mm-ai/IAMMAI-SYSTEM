/**
 * FadeUp Animation Component
 * Feature: 002-dark-futuristic-ui
 *
 * Scroll-reveal animation that fades in and slides up when element enters viewport.
 * Kentra.com-inspired with 600ms duration and custom cubic-bezier easing.
 */

import { motion } from 'framer-motion';
import { useReducedMotion } from '../../hooks/useReducedMotion';

interface FadeUpProps {
  children: React.ReactNode;
  delay?: number;
  className?: string;
}

export function FadeUp({ children, delay = 0, className }: FadeUpProps): JSX.Element {
  const reducedMotion = useReducedMotion();

  return (
    <motion.div
      initial={{
        opacity: 0,
        y: reducedMotion ? 0 : 40,
      }}
      whileInView={{
        opacity: 1,
        y: 0,
      }}
      viewport={{
        once: true,
        margin: '-100px',
      }}
      transition={{
        duration: reducedMotion ? 0 : 0.6,
        delay: reducedMotion ? 0 : delay,
        ease: [0.22, 1, 0.36, 1] as [number, number, number, number], // Custom cubic-bezier (Kentra-inspired)
      }}
      className={className}
    >
      {children}
    </motion.div>
  );
}
