/**
 * GlowPulse Animation Component
 * Feature: 003-dark-futuristic-ui
 *
 * Creates a pulsing glow effect for status indicators and loading states.
 * Uses 2500ms pulse cycle from design tokens for ambient effect.
 * Respects prefers-reduced-motion preference.
 */

import { motion } from 'framer-motion';
import { useReducedMotion } from '../../hooks/useReducedMotion';

type GlowColor = 'cyan' | 'magenta' | 'blue' | 'error' | 'success';

interface GlowPulseProps {
  children: React.ReactNode;
  color?: GlowColor;
  active?: boolean;
  className?: string;
}

// Glow shadow values for pulse animation (subtle to medium)
const glowShadows: Record<GlowColor, { min: string; max: string }> = {
  cyan: {
    min: '0 0 2px rgba(0,255,255,0.15), 0 0 6px rgba(0,255,255,0.1), 0 0 12px rgba(0,255,255,0.05)',
    max: '0 0 4px rgba(0,255,255,0.3), 0 0 12px rgba(0,255,255,0.2), 0 0 24px rgba(0,255,255,0.1)',
  },
  magenta: {
    min: '0 0 2px rgba(255,0,255,0.15), 0 0 6px rgba(255,0,255,0.1), 0 0 12px rgba(255,0,255,0.05)',
    max: '0 0 4px rgba(255,0,255,0.3), 0 0 12px rgba(255,0,255,0.2), 0 0 24px rgba(255,0,255,0.1)',
  },
  blue: {
    min: '0 0 2px rgba(0,204,255,0.15), 0 0 6px rgba(0,204,255,0.1), 0 0 12px rgba(0,204,255,0.05)',
    max: '0 0 4px rgba(0,204,255,0.3), 0 0 12px rgba(0,204,255,0.2), 0 0 24px rgba(0,204,255,0.1)',
  },
  error: {
    min: '0 0 2px rgba(255,51,102,0.15), 0 0 6px rgba(255,51,102,0.1), 0 0 12px rgba(255,51,102,0.05)',
    max: '0 0 4px rgba(255,51,102,0.3), 0 0 12px rgba(255,51,102,0.2), 0 0 24px rgba(255,51,102,0.1)',
  },
  success: {
    min: '0 0 2px rgba(0,255,136,0.15), 0 0 6px rgba(0,255,136,0.1), 0 0 12px rgba(0,255,136,0.05)',
    max: '0 0 4px rgba(0,255,136,0.3), 0 0 12px rgba(0,255,136,0.2), 0 0 24px rgba(0,255,136,0.1)',
  },
};

export function GlowPulse({
  children,
  color = 'cyan',
  active = true,
  className,
}: GlowPulseProps): JSX.Element {
  const reducedMotion = useReducedMotion();

  // If not active or reduced motion, render without animation
  if (!active || reducedMotion) {
    return <div className={className}>{children}</div>;
  }

  const { min, max } = glowShadows[color];

  return (
    <motion.div
      animate={{
        boxShadow: [min, max, min],
      }}
      transition={{
        duration: 2.5, // 2500ms pulse from design tokens
        ease: 'easeInOut',
        repeat: Infinity,
      }}
      className={className}
    >
      {children}
    </motion.div>
  );
}
