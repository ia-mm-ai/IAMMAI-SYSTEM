/**
 * StatusBadge component
 * @see specs/001-ephemeral-kernel/spec.md#FR-016
 *
 * Displays session state with color-coded badge:
 * - CREATED: gray
 * - ACTIVE: green
 * - ENDED: red
 */

import { clsx } from 'clsx';

export type SessionState = 'CREATED' | 'ACTIVE' | 'ENDED';

export interface StatusBadgeProps {
  state: SessionState;
  size?: 'sm' | 'md' | 'lg';
  className?: string;
}

const stateColors: Record<SessionState, string> = {
  CREATED: 'bg-dark-surface2 text-text-secondary border-dark-border',
  ACTIVE: 'bg-success-bg text-success border-success shadow-glow-success-subtle',
  ENDED: 'bg-error-bg text-error border-error shadow-glow-error-subtle',
};

const stateLabels: Record<SessionState, string> = {
  CREATED: 'Created',
  ACTIVE: 'Active',
  ENDED: 'Ended',
};

const sizeClasses: Record<'sm' | 'md' | 'lg', string> = {
  sm: 'px-2 py-0.5 text-xs',
  md: 'px-2.5 py-1 text-sm',
  lg: 'px-3 py-1.5 text-base',
};

export function StatusBadge({
  state,
  size = 'md',
  className,
}: StatusBadgeProps): JSX.Element {
  return (
    <span
      className={clsx(
        'inline-flex items-center font-medium rounded-full border',
        stateColors[state],
        sizeClasses[size],
        className
      )}
      role="status"
      aria-label={`Session status: ${stateLabels[state]}`}
    >
      <span
        className={clsx(
          'w-2 h-2 rounded-full mr-1.5',
          state === 'CREATED' && 'bg-text-muted',
          state === 'ACTIVE' && 'bg-success animate-pulse',
          state === 'ENDED' && 'bg-error'
        )}
        aria-hidden="true"
      />
      {stateLabels[state]}
    </span>
  );
}
