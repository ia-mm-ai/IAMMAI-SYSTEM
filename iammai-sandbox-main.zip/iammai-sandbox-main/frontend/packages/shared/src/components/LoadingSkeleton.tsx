/**
 * LoadingSkeleton component
 * Provides consistent loading states across the application
 */

import { clsx } from 'clsx';
import { GlowPulse } from './animations/GlowPulse';

export interface LoadingSkeletonProps {
  variant?: 'text' | 'rect' | 'circle';
  width?: string | number;
  height?: string | number;
  className?: string;
  count?: number;
}

export function LoadingSkeleton({
  variant = 'text',
  width,
  height,
  className,
  count = 1,
}: LoadingSkeletonProps): JSX.Element {
  const baseClasses = 'animate-pulse bg-dark-surface2 rounded border border-dark-border/30';

  const variantClasses = {
    text: 'h-4 rounded',
    rect: 'rounded-md',
    circle: 'rounded-full',
  };

  const style: React.CSSProperties = {};
  if (width) style.width = typeof width === 'number' ? `${width}px` : width;
  if (height) style.height = typeof height === 'number' ? `${height}px` : height;

  if (count === 1) {
    return (
      <div
        className={clsx(baseClasses, variantClasses[variant], className)}
        style={style}
        role="status"
        aria-label="Loading..."
      />
    );
  }

  return (
    <div className="space-y-2" role="status" aria-label="Loading...">
      {Array.from({ length: count }, (_, i) => (
        <div
          key={i}
          className={clsx(baseClasses, variantClasses[variant], className)}
          style={style}
        />
      ))}
    </div>
  );
}

/**
 * Pre-built skeleton for session cards
 */
export function SessionCardSkeleton(): JSX.Element {
  return (
    <GlowPulse color="cyan" className="rounded-lg">
      <div className="p-4 border border-accent-cyan/10 bg-dark-surface1 rounded-lg space-y-3">
        <div className="flex justify-between items-start">
          <div className="h-4 bg-dark-surface3 rounded w-[60%] animate-pulse" />
          <div className="h-6 w-20 bg-dark-surface3 rounded-md animate-pulse" />
        </div>
        <div className="h-4 bg-dark-surface3 rounded w-[40%] animate-pulse" />
        <div className="flex gap-2 mt-4">
          <div className="h-9 w-20 bg-accent-cyan/5 rounded-md border border-accent-cyan/10 animate-pulse" />
          <div className="h-9 w-20 bg-accent-cyan/5 rounded-md border border-accent-cyan/10 animate-pulse" />
        </div>
      </div>
    </GlowPulse>
  );
}

/**
 * Pre-built skeleton for chat messages
 */
export function ChatMessageSkeleton({
  isAssistant = false,
}: {
  isAssistant?: boolean;
}): JSX.Element {
  const accentClass = isAssistant ? 'border-accent-cyan/10' : 'border-accent-magenta/10';
  const glowClass = isAssistant ? 'shadow-glow-cyan-subtle' : 'shadow-glow-magenta-subtle';

  return (
    <div
      className={clsx(
        'flex gap-3 p-3',
        isAssistant ? 'justify-start' : 'justify-end'
      )}
    >
      <div className={clsx(
        'space-y-2 max-w-[70%] p-4 rounded-lg border-l-2 animate-pulse',
        accentClass,
        glowClass,
        isAssistant ? 'bg-accent-cyan/[0.02]' : 'bg-accent-magenta/[0.02]'
      )}>
        <div className="h-4 bg-dark-surface3 rounded w-[200px]" />
        <div className="h-4 bg-dark-surface3 rounded w-[150px]" />
      </div>
    </div>
  );
}
