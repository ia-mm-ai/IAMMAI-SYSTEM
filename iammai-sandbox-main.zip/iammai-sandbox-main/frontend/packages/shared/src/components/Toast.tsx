/**
 * Toast notification component and context
 * Provides a simple toast system for displaying notifications
 */

'use client';

import {
  createContext,
  useContext,
  useState,
  useCallback,
  useEffect,
  type ReactNode,
} from 'react';

type ToastType = 'success' | 'error' | 'info' | 'warning';

interface Toast {
  id: string;
  message: string;
  type: ToastType;
}

interface ToastContextValue {
  showToast: (message: string, type?: ToastType) => void;
  showError: (message: string) => void;
  showSuccess: (message: string) => void;
}

const ToastContext = createContext<ToastContextValue | null>(null);

const TOAST_DURATION = 5000;

/**
 * Toast provider component - wrap your app with this
 */
export function ToastProvider({ children }: { children: ReactNode }): JSX.Element {
  const [toasts, setToasts] = useState<Toast[]>([]);

  const removeToast = useCallback((id: string) => {
    setToasts((prev) => prev.filter((t) => t.id !== id));
  }, []);

  const showToast = useCallback((message: string, type: ToastType = 'info') => {
    const id = `${Date.now()}-${Math.random().toString(36).slice(2, 9)}`;
    setToasts((prev) => [...prev, { id, message, type }]);

    setTimeout(() => removeToast(id), TOAST_DURATION);
  }, [removeToast]);

  const showError = useCallback((message: string) => {
    showToast(message, 'error');
  }, [showToast]);

  const showSuccess = useCallback((message: string) => {
    showToast(message, 'success');
  }, [showToast]);

  return (
    <ToastContext.Provider value={{ showToast, showError, showSuccess }}>
      {children}
      <ToastContainer toasts={toasts} onDismiss={removeToast} />
    </ToastContext.Provider>
  );
}

/**
 * Hook to access toast functions
 */
export function useToast(): ToastContextValue {
  const context = useContext(ToastContext);
  if (!context) {
    throw new Error('useToast must be used within a ToastProvider');
  }
  return context;
}

/**
 * Toast container - renders all active toasts
 */
function ToastContainer({
  toasts,
  onDismiss,
}: {
  toasts: Toast[];
  onDismiss: (id: string) => void;
}): JSX.Element | null {
  if (toasts.length === 0) {
    return null;
  }

  return (
    <div className="fixed bottom-4 right-4 z-50 flex flex-col gap-2">
      {toasts.map((toast) => (
        <ToastItem key={toast.id} toast={toast} onDismiss={onDismiss} />
      ))}
    </div>
  );
}

/**
 * Individual toast item
 */
function ToastItem({
  toast,
  onDismiss,
}: {
  toast: Toast;
  onDismiss: (id: string) => void;
}): JSX.Element {
  const [isExiting, setIsExiting] = useState(false);

  useEffect(() => {
    const exitTimer = setTimeout(() => {
      setIsExiting(true);
    }, TOAST_DURATION - 300);

    return () => clearTimeout(exitTimer);
  }, []);

  const baseStyles = 'px-4 py-3 rounded-lg flex items-center gap-3 min-w-[300px] max-w-md bg-dark-surface1';
  const animationStyles = isExiting
    ? 'opacity-0 translate-x-2 transition-all duration-300'
    : 'opacity-100 translate-x-0 transition-all duration-300';

  const typeStyles: Record<ToastType, string> = {
    success: 'bg-success-bg border border-success text-success shadow-glow-success-medium',
    error: 'bg-error-bg border border-error text-error shadow-glow-error-medium',
    warning: 'bg-warning-bg border border-warning text-warning',
    info: 'bg-info-bg border border-info text-info shadow-glow-blue-medium',
  };

  const icons: Record<ToastType, string> = {
    success: '\u2713',
    error: '\u2717',
    warning: '\u26A0',
    info: '\u2139',
  };

  return (
    <div className={`${baseStyles} ${typeStyles[toast.type]} ${animationStyles}`}>
      <span className="text-lg">{icons[toast.type]}</span>
      <span className="flex-1 text-sm font-normal leading-normal">{toast.message}</span>
      <button
        onClick={() => onDismiss(toast.id)}
        className="text-current opacity-60 hover:opacity-100 transition-opacity font-semibold"
        aria-label="Dismiss"
      >
        \u00D7
      </button>
    </div>
  );
}
