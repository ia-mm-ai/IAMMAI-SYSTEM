/**
 * Design Tokens for Dark Futuristic UI
 * Feature: 003-dark-futuristic-ui
 *
 * Central source of truth for colors, typography, spacing, and animation values.
 * All tokens are also defined in Tailwind config for CSS usage.
 *
 * Phase 1: Ultra-dark palette with neon accents and glow effects.
 */

export const designTokens = {
  colors: {
    dark: {
      base: '#050505',      // Primary page background (extreme dark)
      surface1: '#080808',  // Cards, panels
      surface2: '#0a0a0a',  // Elevated elements
      surface3: '#0d0d0d',  // Hover states
      border: '#1a1a1a',    // Subtle borders
      // Legacy values for backwards compatibility
      950: '#0a0a0a',
      900: '#0d1117',
      850: '#121212',
      800: '#161b22',
      750: '#1c2128',
    },
    text: {
      primary: '#a0a0a0',   // ~3.5:1 contrast (low-contrast aesthetic)
      secondary: '#707070', // ~2.5:1 contrast
      muted: '#505050',     // ~1.8:1 contrast
      bright: '#e0e0e0',    // For emphasis/highlights
      // Legacy values
      tertiary: '#6e7681',
    },
    accent: {
      cyan: '#00ffff',      // Pure cyan (neon)
      cyanHover: '#00e6e6',
      cyanSubtle: '#0a2626',
      cyanGlow: 'rgba(0, 255, 255, 0.5)',
      magenta: '#ff00ff',   // Pure magenta (neon)
      magentaHover: '#e600e6',
      magentaSubtle: '#260a26',
      magentaGlow: 'rgba(255, 0, 255, 0.5)',
      blue: '#00ccff',      // Neon blue
      blueHover: '#00b8e6',
      blueSubtle: '#0a1f26',
      blueGlow: 'rgba(0, 204, 255, 0.5)',
      // Legacy values
      purple: '#bc8cff',
      purpleHover: '#a870e8',
      purpleSubtle: '#2e1f47',
      pink: '#ff00ff',
      pinkHover: '#e600e6',
      pinkSubtle: '#3d1a3d',
    },
    semantic: {
      success: '#00ff88',
      successGlow: 'rgba(0, 255, 136, 0.5)',
      successText: '#7ee787',
      successBg: '#033a16',
      warning: '#ffaa00',
      warningGlow: 'rgba(255, 170, 0, 0.5)',
      warningText: '#f0c674',
      warningBg: '#3d2e00',
      error: '#ff3366',
      errorGlow: 'rgba(255, 51, 102, 0.5)',
      errorText: '#ff7b72',
      errorBg: '#3d0f0e',
      info: '#58a6ff',
      infoGlow: 'rgba(88, 166, 255, 0.5)',
      infoText: '#79c0ff',
      infoBg: '#0d2d4e',
    },
    glow: {
      cyan: {
        subtle: '0 0 2px rgba(0,255,255,0.15), 0 0 6px rgba(0,255,255,0.1), 0 0 12px rgba(0,255,255,0.05)',
        medium: '0 0 4px rgba(0,255,255,0.3), 0 0 12px rgba(0,255,255,0.2), 0 0 24px rgba(0,255,255,0.1)',
        bright: '0 0 6px rgba(0,255,255,0.5), 0 0 18px rgba(0,255,255,0.35), 0 0 36px rgba(0,255,255,0.2)',
      },
      magenta: {
        subtle: '0 0 2px rgba(255,0,255,0.15), 0 0 6px rgba(255,0,255,0.1), 0 0 12px rgba(255,0,255,0.05)',
        medium: '0 0 4px rgba(255,0,255,0.3), 0 0 12px rgba(255,0,255,0.2), 0 0 24px rgba(255,0,255,0.1)',
        bright: '0 0 6px rgba(255,0,255,0.5), 0 0 18px rgba(255,0,255,0.35), 0 0 36px rgba(255,0,255,0.2)',
      },
      blue: {
        subtle: '0 0 2px rgba(0,204,255,0.15), 0 0 6px rgba(0,204,255,0.1), 0 0 12px rgba(0,204,255,0.05)',
        medium: '0 0 4px rgba(0,204,255,0.3), 0 0 12px rgba(0,204,255,0.2), 0 0 24px rgba(0,204,255,0.1)',
        bright: '0 0 6px rgba(0,204,255,0.5), 0 0 18px rgba(0,204,255,0.35), 0 0 36px rgba(0,204,255,0.2)',
      },
      error: {
        subtle: '0 0 2px rgba(255,51,102,0.15), 0 0 6px rgba(255,51,102,0.1), 0 0 12px rgba(255,51,102,0.05)',
        medium: '0 0 4px rgba(255,51,102,0.3), 0 0 12px rgba(255,51,102,0.2), 0 0 24px rgba(255,51,102,0.1)',
        bright: '0 0 6px rgba(255,51,102,0.5), 0 0 18px rgba(255,51,102,0.35), 0 0 36px rgba(255,51,102,0.2)',
      },
      success: {
        subtle: '0 0 2px rgba(0,255,136,0.15), 0 0 6px rgba(0,255,136,0.1), 0 0 12px rgba(0,255,136,0.05)',
        medium: '0 0 4px rgba(0,255,136,0.3), 0 0 12px rgba(0,255,136,0.2), 0 0 24px rgba(0,255,136,0.1)',
        bright: '0 0 6px rgba(0,255,136,0.5), 0 0 18px rgba(0,255,136,0.35), 0 0 36px rgba(0,255,136,0.2)',
      },
    },
  },
  typography: {
    fontFamily: {
      display: 'var(--font-display), "Space Grotesk", var(--font-inter), sans-serif',
      sans: 'var(--font-inter), "Space Grotesk", ui-sans-serif, -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, "Helvetica Neue", Arial, sans-serif',
      mono: '"SF Mono", "Fira Code", "Cascadia Code", Consolas, monospace',
    },
    fontSize: {
      xs: '0.75rem',    // 12px
      sm: '0.875rem',   // 14px
      base: '1rem',     // 16px
      lg: '1.125rem',   // 18px
      xl: '1.25rem',    // 20px
      '2xl': '1.5rem',  // 24px
      '3xl': '1.875rem', // 30px
      '4xl': '2.25rem',  // 36px
      '5xl': '3rem',     // 48px
      '6xl': '3.75rem',  // 60px
    },
    fontWeight: {
      normal: 400,
      medium: 500,
      semibold: 600,
      bold: 700,
    },
    lineHeight: {
      tight: 1.25,
      snug: 1.375,
      normal: 1.5,
      relaxed: 1.625,
      loose: 2,
    },
  },
  spacing: {
    0: '0px',
    1: '0.25rem',  // 4px
    2: '0.5rem',   // 8px
    3: '0.75rem',  // 12px
    4: '1rem',     // 16px
    6: '1.5rem',   // 24px
    8: '2rem',     // 32px
    10: '2.5rem',  // 40px
    12: '3rem',    // 48px
    16: '4rem',    // 64px
    20: '5rem',    // 80px
    24: '6rem',    // 96px
  },
  animation: {
    duration: {
      instant: '0ms',
      fast: '150ms',
      hover: '250ms',   // Hover transitions
      medium: '300ms',
      slow: '500ms',
      reveal: '600ms',
      pulse: '2500ms',  // Slow pulsing effects
    },
    easing: {
      linear: 'linear',
      out: 'cubic-bezier(0, 0, 0.2, 1)',
      in: 'cubic-bezier(0.4, 0, 1, 1)',
      inOut: 'cubic-bezier(0.4, 0, 0.2, 1)',
      reveal: 'cubic-bezier(0.22, 1, 0.36, 1)',
    },
  },
} as const;

export type DesignTokens = typeof designTokens;
