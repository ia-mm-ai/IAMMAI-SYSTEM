/**
 * Shared package exports
 */

// Components
export { StatusBadge } from './components/StatusBadge';
export { LoadingSkeleton, SessionCardSkeleton, ChatMessageSkeleton } from './components/LoadingSkeleton';
export { ToastProvider, useToast } from './components/Toast';
export { FadeUp, StaggerGrid, HoverGlow, GlowPulse } from './components/animations';

// Hooks
export { useWebSocket } from './hooks/useWebSocket';
export { useReducedMotion } from './hooks/useReducedMotion';
export { useSSE } from './hooks/useSSE';
export type { SSEEvent, UseSSEOptions, UseSSEReturn } from './hooks/useSSE';

// Types
export * from './types/api';
