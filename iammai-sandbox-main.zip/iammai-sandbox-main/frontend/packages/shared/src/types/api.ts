/**
 * API client types
 * @see specs/001-ephemeral-kernel/contracts/api.yaml
 *
 * These types are derived from the OpenAPI specification
 */

// ============================================================================
// Session Types
// ============================================================================

export type SessionState = 'CREATED' | 'ACTIVE' | 'ENDED';

export type KernelStatus = 'NOT_CREATED' | 'ACTIVE' | 'DISSOLVED';

export interface Session {
  id: string;
  name: string;
  state: SessionState;
  createdAt: string;
  startedAt: string | null;
  endedAt: string | null;
  tokenCount: number;
  userCount: number;
}

export interface LifecycleEvent {
  event: 'CREATED' | 'STARTED' | 'ENDED';
  timestamp: string;
}

export interface SessionDetails extends Session {
  kernelStatus: KernelStatus;
  lifecycle: LifecycleEvent[];
}

export interface PublicSession {
  id: string;
  name: string;
  state: SessionState;
  canClaim: boolean;
  canJoin: boolean;
}

export interface SessionList {
  sessions: Session[];
  total: number;
  limit: number;
  offset: number;
}

export interface PublicSessionList {
  sessions: PublicSession[];
}

// ============================================================================
// Auth Types
// ============================================================================

export interface LoginRequest {
  email: string;
  password: string;
}

export interface AdminProfile {
  id: string;
  email: string;
  lastLoginAt: string | null;
}

// ============================================================================
// Token Types
// ============================================================================

export interface TokenClaim {
  token: string;
  sessionId: string;
  claimedAt: string;
}

export interface JoinRequest {
  token: string;
}

export interface JoinResponse {
  presenceHash: string;
  kernelStatus: 'ACTIVE';
  websocketUrl: string;
}

// ============================================================================
// Chat Types
// ============================================================================

export interface SendMessageRequest {
  content: string;
  messageId?: string;
}

export interface MessageAccepted {
  messageId: string;
  status: 'ACCEPTED';
}

// ============================================================================
// Request Types
// ============================================================================

export interface CreateSessionRequest {
  name: string;
}

// ============================================================================
// Error Types
// ============================================================================

export interface ApiError {
  code: string;
  message: string;
  details?: Record<string, unknown>;
}

// ============================================================================
// WebSocket Message Types
// ============================================================================

export interface WsConnectionAck {
  type: 'CONNECTION_ACK';
  payload: {
    presenceHash: string;
    kernelStatus: KernelStatus;
    sessionId: string;
  };
  timestamp: string;
}

export interface WsMessageChunk {
  type: 'MESSAGE_CHUNK';
  payload: {
    messageId: string;
    content: string;
    isComplete: boolean;
  };
  timestamp: string;
}

export interface WsMessageComplete {
  type: 'MESSAGE_COMPLETE';
  payload: {
    messageId: string;
    content: string;
    role: 'assistant';
  };
  timestamp: string;
}

export interface WsMessageError {
  type: 'MESSAGE_ERROR';
  payload: {
    messageId: string;
    code: string;
    message: string;
  };
  timestamp: string;
}

export interface WsKernelDissolved {
  type: 'KERNEL_DISSOLVED';
  payload: {
    sessionId: string;
    message: string;
  };
  timestamp: string;
}

export interface WsHeartbeat {
  type: 'HEARTBEAT';
  timestamp: string;
}

export interface WsUserMessage {
  type: 'USER_MESSAGE';
  payload: {
    messageId: string;
    content: string;
  };
  timestamp: string;
}

export interface WsHeartbeatAck {
  type: 'HEARTBEAT_ACK';
  timestamp: string;
}

// ============================================================================
// IAMMAI WebSocket Event Types (derivative notifications — not canonical state)
// ============================================================================

export interface WsIammaiPhaseChange {
  type: 'IAMMAI_PHASE_CHANGE';
  payload: {
    phase: string;
    family: 'preparation' | 'standing';
  };
  timestamp: string;
}

export interface WsIammaiHeld {
  type: 'IAMMAI_HELD';
  payload: {
    reason: string;
  };
  timestamp: string;
}

export interface WsIammaiReleased {
  type: 'IAMMAI_RELEASED';
  payload: Record<string, never>;
  timestamp: string;
}

export interface WsIammaiResolved {
  type: 'IAMMAI_RESOLVED';
  payload: {
    resolutionType: 'FINALIZE' | 'INVALIDATE' | 'EVOLVE';
  };
  timestamp: string;
}

export type WsServerMessage =
  | WsConnectionAck
  | WsMessageChunk
  | WsMessageComplete
  | WsMessageError
  | WsKernelDissolved
  | WsHeartbeat
  | WsIammaiPhaseChange
  | WsIammaiHeld
  | WsIammaiReleased
  | WsIammaiResolved;

export type WsClientMessage = WsUserMessage | WsHeartbeatAck;

// ============================================================================
// IAMMAI Status Types (public derivative surface)
// ============================================================================

export interface IammaiStatus {
  tracked: boolean;
  phase: string | null;
  family: 'preparation' | 'standing' | null;
  isHeld: boolean;
  isResolved: boolean;
  resolutionType: 'FINALIZE' | 'INVALIDATE' | 'EVOLVE' | null;
  contributionRoles: string[];
}
