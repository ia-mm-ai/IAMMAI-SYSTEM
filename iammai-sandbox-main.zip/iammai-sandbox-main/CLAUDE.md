# iammai-sandbox Development Guidelines

Auto-generated from all feature plans. Last updated: 2026-01-24

## Active Technologies
- TypeScript 5.x on Node.js 20 LTS + Next.js 14, React 18, Tailwind CSS 3.4, pnpm workspace (002-dark-futuristic-ui)
- N/A (styling only, no data layer changes) (002-dark-futuristic-ui)
- TypeScript 5.3+ on Node.js 20 LTS + Next.js 14, React 18, Tailwind CSS 3.4, Framer Motion 12.x, pnpm workspace (003-dark-futuristic-ui)
- TypeScript 5.3+ on Node.js 20 LTS + Express 4.18, pg 8.11 (PostgreSQL client), uuid 9.0 (existing), Node.js crypto (SHA-256, built-in) (005-structural-foundation)
- PostgreSQL (existing database — new `integrity_ledger` table + `session_boundaries` columns on sessions table) (005-structural-foundation)
- TypeScript 5.3+ on Node.js 20 LTS + Express 4.18, pg 8.11 (PostgreSQL client), uuid 9.0, Node.js crypto (SHA-256, built-in) (007-presence-suppression)
- PostgreSQL (existing database — new `presence_records` table + `SUPPRESSION_EVENT` enum value) (007-presence-suppression)
- PostgreSQL (existing database — new `ACEDIA_WARNING`, `ACEDIA_DETECTION`, `ACEDIA_CANCELLED`, `ACEDIA_FORCE_RELEASE` enum values on `integrity_event_type`) (008-governance-protocols)
- TypeScript 5.3+ on Node.js 20 LTS + Express 4.18, pg 8.11 (PostgreSQL client), vitest (testing) (009-compliance-test)
- PostgreSQL (read-only access to existing tables: `sessions`, `integrity_ledger`, `presence_records`, `pg_trigger`) (009-compliance-test)
- TypeScript 5.3+ on Node.js 20 LTS + Express 4.18, pg 8.11 (backend); Next.js 14, React 18, Tailwind CSS 3.4, Framer Motion 12.x (frontend) (009-compliance-test)

- TypeScript 5.x on Node.js 20 LTS + Next.js 14 (frontend), Express/Fastify (backend), native WebSocke (001-iammai-sandbox)

## Project Structure

```text
src/
tests/
```

## Commands

npm test && npm run lint

## Code Style

TypeScript 5.x on Node.js 20 LTS: Follow standard conventions

## Recent Changes
- 009-compliance-test: Added TypeScript 5.3+ on Node.js 20 LTS + Express 4.18, pg 8.11 (backend); Next.js 14, React 18, Tailwind CSS 3.4, Framer Motion 12.x (frontend)
- 009-compliance-test: Added TypeScript 5.3+ on Node.js 20 LTS + Express 4.18, pg 8.11 (PostgreSQL client), vitest (testing)
- 008-governance-protocols: Added TypeScript 5.3+ on Node.js 20 LTS + Express 4.18, pg 8.11 (PostgreSQL client), uuid 9.0, Node.js crypto (SHA-256, built-in)


<!-- MANUAL ADDITIONS START -->
<!-- MANUAL ADDITIONS END -->
