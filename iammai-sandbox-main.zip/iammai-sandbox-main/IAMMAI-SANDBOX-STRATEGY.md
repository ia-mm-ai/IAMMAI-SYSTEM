# IAMMAI Sandbox PoC: Applying the mm.limited Framework

> Goal: Prototype, test, and iterate on the mm.limited framework by applying it
> to a real product — the IAMMAI Sandbox Chatbot.
> Status: STRATEGY (pre-implementation)

---

## 1. Why This Product Is the Right PoC

The IAMMAI Sandbox Chatbot is an almost adversarial test case for the framework — and
that's exactly why it's the right one.

The framework demands: permanent records, immutable ledgers, witness artifacts,
non-erasure. The chatbot is designed for: complete data ephemerality, privacy
through destruction, anonymous participation.

These are not contradictory. They operate on **different layers of the Reality
Stack**:

```
CONTENT LAYER (ephemeral)          INTEGRITY LAYER (permanent)
─────────────────────────          ──────────────────────────
Chat messages → destroyed          Session boundary → witnessed
User input → not stored            Presence attestation → recorded
AI responses → purged              Verification decision → ledger
                                   Co-agency record → immutable
```

The framework doesn't care WHAT was said. It cares:
- That the session had boundaries (I.02)
- That presence was real (I.01)
- That the session ledger is intact (I.04)
- That the AI operated within co-agency constraints (I.09)
- That history moves forward only (I.03)

**If the framework works on a system designed for data destruction, it works
anywhere.** This is the strongest possible PoC.

---

## 2. Domain Mapping: IAMMAI Sandbox Chatbot → Framework Concepts

### 2.1 What Is an EVENT?

A chatbot **session** is an EVENT.

| MM-MODEL Field          | IAMMAI Sandbox Chatbot Equivalent               |
|-------------------------|--------------------------------------------------|
| event_id                | session_id (unique per session)                  |
| t_open                  | session creation timestamp (UTC)                 |
| t_close                 | session termination timestamp (UTC)              |
| context_descriptor      | session topic/purpose declared by admin          |
| environmental_constraints| session rules (max users, time limit, AI model)  |
| status                  | OPEN (active session) / CLOSED (terminated)      |

Key rule from MM-MODEL §2.1: "No truth finalization may reference an OPEN event."
→ In IAMMAI Sandbox terms: no witness artifact or verification record is emitted until the
session is closed. While a session is live, nothing is finalized.

### 2.2 What Is PRESENCE?

| Actor         | Presence Mechanism                                    |
|---------------|-------------------------------------------------------|
| Admin         | Authenticated session creation = presence attestation |
| Anonymous user| Joining an active session = presence (role: PARTICIPANT)|
| AI agent      | Activated within session boundary = presence (role: AGENT)|

Critical insight: **anonymous users have valid presence.** The framework
explicitly separates presence from identity (I.06). You don't need to know
WHO — only that someone WAS THERE, attested by role, within the event boundary.

Presence is boolean per MM-MODEL §2.2:
- `true` = actor was in the session during its bounded lifetime
- `false` = actor was not (default; not "unknown")

### 2.3 What Is a SIGNAL?

Every message in the chatbot is a SIGNAL.

| Signal Type         | source       | target    | domain    | intent          |
|---------------------|--------------|-----------|-----------|-----------------|
| User message        | participant  | AI agent  | session   | query/instruct  |
| AI response         | AI agent     | session   | session   | respond         |
| Admin command        | admin        | system    | control   | manage          |
| System notification | system       | session   | control   | inform          |

Signal Coherence (I.08) applies: every message must have singular meaning in
context. The system rejects ambiguous commands (e.g., conflicting admin
instructions to both extend and terminate a session).

### 2.4 Reality Stack Mapping

| Layer | Name          | IAMMAI Sandbox Chatbot Component                     |
|-------|---------------|-------------------------------------------------------|
| 0     | Substrate     | Server infrastructure, hosting                        |
| 1     | Signal        | WebSocket/HTTP messages between client and server     |
| 2     | Awareness     | Message parsing, intent recognition                   |
| 3     | Intent        | User's purpose in sending a message                   |
| 4     | Event         | The chatbot session (bounded, with open/close)        |
| 5     | Presence      | Admin auth + user join + AI activation                |
| 6     | Demand        | User questions requiring AI response                  |
| 7     | Verification  | Protocol checks before session actions proceed        |
| 8     | Resolution    | Session outcomes (completed, terminated, released)    |
| 9     | Continuity    | Session state can only move forward                   |
| 10    | Ledger        | Append-only record of session metadata + witnesses    |
| 11    | Identity      | Admin identity (accumulated); users have none (valid) |
| 12    | Co-Agency     | Human-AI balance within the session                   |
| 13    | Civilization  | (Out of scope for PoC)                                |

---

## 3. Protocol-by-Protocol Implementation Plan

### Priority Tiers

**Tier 1 — Structural (implement first, mechanically enforceable):**
- I.02 Event Boundary — session lifecycle
- I.04 Ledger Non-Erasure — append-only session log
- I.03 Continuity Non-Regression — forward-only state

**Tier 2 — Operational (implement second, requires verification logic):**
- I.01 Presence Truth — presence attestation within sessions
- I.05 Protocol Supremacy — rules override admin preferences
- I.08 Signal Coherence — message validation

**Tier 3 — Governance (implement third, requires judgment framework):**
- I.07 Anti-Acedia — detect stalled sessions
- I.09 Co-Agency Balance — human/AI action constraints
- I.10 Future Interpretability — AI reasoning transparency
- I.06 Presence-Derived Identity — admin identity accumulation

### 3.1 I.02 — Event Boundary Protocol

**What to build:**
- Session MUST have explicit `created_at` (t_open) and `terminated_at` (t_close)
- Session status: `OPEN` → `CLOSED` (no other transitions; no reopening)
- No downstream operations (witness emission, verification finalization) while
  session is OPEN
- Session must declare: topic, constraints (max users, time limit, AI model config)

**Pass condition:** Session has explicit open/close, bounded context, declared constraints.
**Fail triggers:** Missing timestamps, undefined context, session reopened after close.

**PoC test:** Create a session. Close it. Attempt to reopen. System MUST reject.

### 3.2 I.04 — Ledger Non-Erasure Protocol

**What to build:**
- Append-only session ledger (NOT the chat content — the session metadata)
- Each entry: session_id, t_open, t_close, participant_count, admin_id,
  verification_result, witness_hash
- No DELETE, UPDATE, HIDE, or REDACT operations on the ledger
- Ledger entries are time-ordered and hash-chained

**Critical distinction:** The chat messages are ephemeral (privacy feature).
The session ledger is permanent (integrity feature). These are different layers.
The framework governs the ledger, not the content.

**PoC test:** Write session records. Attempt to delete one. System MUST reject
and log the attempt.

### 3.3 I.03 — Continuity Non-Regression Protocol

**What to build:**
- Session state machine: `CREATED → ACTIVE → CLOSED`
- State transitions are one-way. `Sₙ₊₁ ⊃ Sₙ` — each state is a superset
  of the previous (new information is added, nothing removed)
- Closing a session adds close metadata; it doesn't erase open metadata
- The ledger state only grows

**PoC test:** Advance session through states. Attempt rollback to CREATED.
System MUST reject.

### 3.4 I.01 — Presence Truth Protocol

**What to build:**
- Admin presence: attested by authentication event within session boundary
- User presence: attested by session join event (anonymous, role-based)
- AI presence: attested by activation within session boundary
- Presence scoped to exactly one CLOSED event (finalized only after session closes)
- Presence is boolean, not probabilistic

**PoC test:** Close a session. Verify presence records exist for all participants.
Attempt to add a participant to a closed session. System MUST reject.

### 3.5 I.05 — Protocol Supremacy Protocol

**What to build:**
- Admin commands are subject to protocol validation before execution
- An admin cannot: override time limits if protocol forbids, reopen closed
  sessions, delete session records, bypass verification
- System rules take precedence over admin preferences in ALL cases

**PoC test:** Admin attempts to delete a session record. System MUST suppress
the action and record the attempt.

### 3.6 I.08 — Signal Coherence Protocol

**What to build:**
- Validate that system commands have singular meaning
- Reject contradictory admin instructions (e.g., "extend session" + "close session"
  in same request)
- AI responses are signals — they must be coherent with the session context
- Messages that could trigger state changes must be unambiguous

**PoC test:** Send contradictory commands simultaneously. System MUST reject
with coherence failure.

### 3.7 I.07 — Anti-Acedia Protocol

**What to build:**
- Detect sessions in CREATED state that never transition to ACTIVE
- Detect sessions in ACTIVE state with no participant activity for a defined threshold
- On detection: force routing to either DEMAND (activate/resume) or RELEASE (close)
- Sessions cannot sit in HOLD indefinitely

**Implementation decision needed:** The MM-MODEL does not define acedia
thresholds. For the PoC, define:
- CREATED → no activity for 15 minutes → acedia warning
- ACTIVE → no messages for 30 minutes → acedia detection
- On acedia: system notifies admin, sets 10-minute countdown to forced RELEASE

**PoC test:** Create a session. Do nothing. After threshold, system MUST force
resolution.

### 3.8 I.09 — Co-Agency Balance Protocol

**What to build:**
- AI agent cannot: terminate sessions unilaterally, override admin settings,
  make irreversible changes without human authorization
- Admin cannot: bypass AI safety filters, override verification results,
  disable suppression
- Both act within their role boundaries

**Implementation decision needed:** The MM-MODEL does not define "balance"
metrics. For the PoC, define balance as: no single agent type (human or machine)
may execute more than 2 consecutive irreversible actions without the other
agent type's involvement.

**PoC test:** AI attempts to close a session without admin authorization.
System MUST suppress.

### 3.9 I.10 — Future Interpretability Protocol

**What to build:**
- AI responses include reasoning metadata (not shown to users, stored in witness)
- Session decisions include decision logic documentation
- All witness artifacts are self-describing (a future system can read them
  without insider knowledge)

**PoC test:** Read a witness artifact from a closed session. Without any
external documentation, determine: what happened, who was present, what was
decided, what protocols were checked.

### 3.10 I.06 — Presence-Derived Identity Protocol

**What to build:**
- Admin identity = the set of sessions where admin presence = true
- `admin_identity = {session_k | presence(admin, session_k) = true}`
- Anonymous users have NO identity (valid — identity gaps are allowed)
- No credential-based identity assertions

**Note:** The MM-MODEL formula `ID = Σ presence(event_k)` is mathematically
incoherent (see MM-MODEL-REVIEW.md §6). For the PoC, implement identity as
**set construction**, not summation.

**PoC test:** Query admin identity. System returns list of sessions with
verified presence, not a credential or profile.

---

## 4. What to Build (Architecture)

```
IAMMAI SANDBOX (existing)
│
├── Chat Engine (ephemeral — NOT governed by framework)
│   ├── WebSocket messaging
│   ├── AI response generation
│   └── Content destruction on session close
│
└── Integrity Layer (permanent — governed by framework)   ← NEW
    │
    ├── Event Manager
    │   ├── Session lifecycle (CREATED → ACTIVE → CLOSED)
    │   ├── Boundary enforcement (t_open, t_close)
    │   └── State machine (forward-only)
    │
    ├── Presence Tracker
    │   ├── Admin presence attestation
    │   ├── Participant presence attestation (anonymous, role-based)
    │   └── AI agent presence attestation
    │
    ├── Verification Engine
    │   ├── V(event, presence, protocol_set) → PASS | FAIL
    │   ├── Protocol evaluators (one per I.01–I.10)
    │   └── Deterministic, reproducible, binary
    │
    ├── Witness Emitter
    │   ├── Emits witness artifact on session close
    │   ├── Fields: event_id, t_open, t_close, presence, protocols_evaluated,
    │   │   pass_fail, suppression_triggered, timestamp_utc, protocol_versions
    │   └── Absence of witness → verification invalid
    │
    ├── Suppression Engine
    │   ├── Halt execution on FAIL
    │   ├── Prevent state mutation
    │   ├── Block downstream protocols
    │   └── Record suppression event
    │
    ├── Ledger (append-only)
    │   ├── Session metadata records
    │   ├── Witness artifacts
    │   ├── Suppression records
    │   ├── Hash-chained, time-ordered
    │   └── No DELETE/UPDATE/HIDE/REDACT
    │
    └── Acedia Monitor
        ├── Detects stalled sessions
        ├── Forces DEMAND or RELEASE
        └── Configurable thresholds
```

### The Key Architectural Insight

The integrity layer sits **beside** the chat engine, not inside it. The chat
engine does what it already does — ephemeral messaging. The integrity layer
observes, verifies, witnesses, and records. It does not touch the chat content.

This mirrors the framework's own architecture: **the framework is a witness
system. It observes and records. It does not participate.**

---

## 5. Files to Import Into the IAMMAI Sandbox Project

### Must Import (implementation targets)

| File | Purpose | Where to Place |
|------|---------|----------------|
| `MM-MODEL.txt` | The enforcement specification — this is what you're implementing against | `docs/framework/MM-MODEL.txt` |
| `FRAMEWORK_REFERENCE.md` | Implementation patterns, interface schemas, protocol summaries | `docs/framework/FRAMEWORK_REFERENCE.md` |
| `MM-MODEL-REVIEW.md` | Identifies gaps in MM-MODEL — critical for knowing where you must make implementation decisions | `docs/framework/MM-MODEL-REVIEW.md` |
| `MM-MODEL-REVISED-SECTION0.txt` | The honest scope of MM-MODEL — what it covers and what it delegates | `docs/framework/MM-MODEL-REVISED-SECTION0.txt` |

### Must Import (protocol specifications)

| File | Purpose |
|------|---------|
| `docs/event.limited/pdfs/I.01_PRESENCE_TRUTH_PROTOCOL.md` | Pass/fail conditions for presence verification |
| `docs/event.limited/pdfs/I.02_EVENT_BOUNDARY_PROTOCOL.md` | Pass/fail conditions for event boundaries |
| `docs/event.limited/pdfs/I.03_CONTINUITY_NON-REGRESSION_PROTOCOL.md` | Pass/fail conditions for continuity |
| `docs/event.limited/pdfs/I.04_LEDGER_NON-ERASURE_PROTOCOL.md` | Pass/fail conditions for ledger integrity |
| `docs/event.limited/pdfs/I.05_PROTOCOL_SUPREMACY_PROTOCOL.md` | Pass/fail conditions for protocol authority |
| `docs/event.limited/pdfs/I.06_PRESENCE-DERIVED_IDENTITY_PROTOCOL.md` | Pass/fail conditions for identity derivation |
| `docs/event.limited/pdfs/I.07_ANTI-ACEDIA_PROTOCOL.md` | Pass/fail conditions for acedia detection |
| `docs/event.limited/pdfs/I.08_SIGNAL_COHERENCE_PROTOCOL.md` | Pass/fail conditions for signal validity |
| `docs/event.limited/pdfs/I.09_CO-AGENCY_BALANCE_PROTOCOL.md` | Pass/fail conditions for agency balance |
| `docs/event.limited/pdfs/I.10_FUTURE_INTERPRETABILITY_PROTOCOL.md` | Pass/fail conditions for interpretability |

Place all under: `docs/framework/protocols/`

### Do NOT Import (not needed for implementation)

| File | Reason |
|------|--------|
| `PRODUCT_STRATEGY.md` | Commercial strategy, not technical spec |
| `MM_LIMITED_EXPLAINED.md` | Educational doc — useful for onboarding developers, but not an implementation target |
| `mm-model-witness-and-seal.presence.json.txt` | Framework's own artifact, not relevant to IAMMAI Sandbox |
| `mm-model-recognition.json` | Framework's own artifact |
| `docs/*/index.md` | Navigation files |
| `docs/mm.limited/reality_declaration.md` | Framework infrastructure |
| `docs/event.limited/anchor.md` | Framework infrastructure |
| `docs/event.limited/manifest.md` | Framework infrastructure |
| `docs/22.limited/decision.md` | Framework infrastructure |

---

## 6. Implementation Phases

### Phase 0: Preparation (before writing code)

1. Import framework files into IAMMAI Sandbox project
2. Read MM-MODEL-REVIEW.md to understand the gaps
3. For each gap, make an explicit implementation decision and document it
4. Create a `FRAMEWORK_DECISIONS.md` in the IAMMAI Sandbox project recording:
   - Acedia thresholds chosen
   - Co-agency balance metric defined
   - Field types for all interfaces
   - Identity formula (set construction, not summation)
   - Signal coherence evaluation criteria for the chatbot domain

This document becomes the IAMMAI Sandbox-specific **protocol_set supplement** — filling
the gaps MM-MODEL intentionally (or accidentally) delegates.

### Phase 1: Structural Foundation

Build the forward-only state machine and append-only ledger.

- Session lifecycle: CREATED → ACTIVE → CLOSED (no rollback)
- Ledger: append-only store for session metadata
- State transition enforcement: `Sₙ₊₁ ⊃ Sₙ`
- **Protocols tested:** I.02, I.03, I.04

Deliverable: A session can be created, activated, and closed. The ledger
records it. Rollback is impossible. Deletion is impossible.

### Phase 2: Verification + Witness

Build the verification engine and witness emitter.

- `V(event, presence, protocol_set) → PASS | FAIL`
- Start with structural checks: Is the event bounded? Is the ledger intact?
  Is state monotonic?
- Emit witness artifacts on every verification
- Store witnesses in the ledger

Deliverable: Every session close triggers verification. A witness artifact
is produced. The artifact is self-describing.

### Phase 3: Presence + Suppression

Build presence tracking and suppression enforcement.

- Track admin, user, and AI presence within session boundaries
- Presence finalized only on session close
- Suppression: when verification fails, halt + prevent mutation + block
  downstream + record
- Admin commands subject to protocol checks before execution

Deliverable: Invalid actions are suppressed. Suppression is recorded.
Presence is tracked and witnessed.

### Phase 4: Governance Protocols

Build acedia detection, co-agency constraints, and interpretability.

- Acedia monitor for stalled sessions
- Co-agency rules: AI cannot act unilaterally on irreversible operations
- AI reasoning metadata stored in witness artifacts
- Protocol supremacy enforced on all admin commands

Deliverable: The system actively detects dysfunction (acedia), prevents
imbalance (co-agency), and produces interpretable records.

### Phase 5: Compliance Test

Run the MM-MODEL §11 compliance test:

| Condition | Test |
|-----------|------|
| Truth finalizes only via presence in closed events | Close a session → verify presence records finalize → verify no finalization during OPEN |
| Verification is deterministic and witnessed | Run same verification twice → same result. Check witness artifact exists. |
| Suppression is mandatory and enforced | Trigger FAIL → verify halt, mutation prevention, downstream block, recording |
| History never regresses | Attempt rollback → verify rejection. Attempt ledger deletion → verify rejection. |
| Authority is never asserted | Admin attempts protocol override → verify suppression |

Deliverable: Binary compliance result. COMPLIANT or NON-COMPLIANT, with
specific protocol-level results.

---

## 7. What This PoC Proves (or Disproves)

### If it works:

1. The framework applies to systems with fundamentally different data lifecycle
   assumptions (ephemeral vs. permanent)
2. The integrity layer can be added to an existing product without modifying
   its core functionality
3. The protocol-by-protocol approach enables incremental adoption (Tier 1
   first, Tier 3 last)
4. The Kentra Verification API product concept is viable — V(event, presence,
   protocol_set) → PASS | FAIL works as an API contract

### If it doesn't work:

1. We'll know exactly WHERE it breaks — which protocol, which mapping, which
   assumption
2. The gaps in MM-MODEL identified in the review become concrete blockers
   rather than theoretical concerns
3. The framework may need domain-specific protocol supplements (a legitimate
   evolution path per §8.2)

### What we'll learn regardless:

1. How much implementation effort the framework actually requires
2. Whether the gaps in MM-MODEL are manageable or fatal
3. Whether "implementation-agnostic" holds in practice or is aspirational
4. Whether the verification function can be made truly deterministic for a
   real-world domain
5. How the framework's "observe, don't participate" posture maps to a system
   where the integrity layer must actively enforce (suppression = action)

---

## 8. Success Criteria for the PoC

| Criterion | Measurement |
|-----------|-------------|
| Framework maps cleanly to the domain | All 10 protocols have concrete IAMMAI Sandbox equivalents |
| Integrity layer doesn't break the product | Ephemeral chat still works; integrity sits beside it |
| Verification is deterministic | Same inputs → same PASS/FAIL, every time |
| Witness artifacts are self-describing | A naive reader can interpret them without documentation |
| Suppression works | Invalid operations are provably blocked |
| Ledger is intact | No deletions possible; hash chain validates |
| Compliance test passes | §11 binary test = COMPLIANT |
| Gaps are documented | Every implementation decision beyond MM-MODEL is recorded |
