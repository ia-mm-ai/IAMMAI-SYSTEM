# Developer Quickstart: Dark Futuristic UI (Extreme Edition)

**Feature**: 003-dark-futuristic-ui
**Date**: 2026-01-25

## Local Development Setup

### Prerequisites

- Node.js 20+
- pnpm 8+

### Getting Started

```bash
# Clone and checkout feature branch
git checkout 003-dark-futuristic-ui

# Install dependencies
pnpm install

# Start development servers
pnpm dev

# Or start individual apps
pnpm dev:user   # http://localhost:3002
pnpm dev:admin  # http://localhost:3001
```

## Design Token Usage

### Importing Tokens

```typescript
// TypeScript/JavaScript
import { designTokens } from '@iammai-sandbox/shared/styles/design-tokens';

// Access colors
const bgColor = designTokens.colors.dark.base;        // #050505
const accentCyan = designTokens.colors.accent.cyan;   // #00ffff
```

### Tailwind Classes

```tsx
// Background colors
<div className="bg-dark-base">         {/* #050505 */}
<div className="bg-dark-surface1">     {/* #080808 */}
<div className="bg-dark-surface2">     {/* #0a0a0a */}

// Text colors
<p className="text-text-primary">      {/* #a0a0a0 */}
<p className="text-text-secondary">    {/* #707070 */}
<p className="text-text-bright">       {/* #e0e0e0 - for emphasis */}

// Accent colors
<span className="text-accent-cyan">    {/* #00ffff */}
<span className="text-accent-magenta"> {/* #ff00ff */}

// Semantic colors
<span className="text-semantic-error"> {/* #ff6666 */}
```

## Glow Effects

### Utility Classes

```tsx
// Apply glow to any element
<button className="glow-cyan-medium">
  Primary Action
</button>

<button className="glow-magenta-medium hover:glow-magenta-bright">
  CTA Button
</button>

<div className="glow-blue-subtle">
  Information Card
</div>
```

### Custom Glow with Tailwind

```tsx
// Using arbitrary values
<div className="shadow-[0_0_4px_rgba(0,255,255,0.3),0_0_12px_rgba(0,255,255,0.2)]">
  Custom glow
</div>
```

### Glow React Component

```tsx
import { HoverGlow } from '@iammai-sandbox/shared/components/animations';

// Wraps child with hover glow effect
<HoverGlow color="cyan" intensity="medium">
  <button>Glowing Button</button>
</HoverGlow>

// Props:
// - color: 'cyan' | 'magenta' | 'blue' | 'error' | 'success'
// - intensity: 'subtle' | 'medium' | 'bright'
// - disabled: boolean (respects prefers-reduced-motion)
```

## Animations

### Scroll Reveal

```tsx
import { FadeUp } from '@iammai-sandbox/shared/components/animations';

<FadeUp delay={0.1}>
  <p>This content fades up when scrolled into view</p>
</FadeUp>

// Props:
// - delay: number (seconds)
// - duration: number (seconds, default 0.6)
// - distance: number (pixels to travel, default 20)
```

### Pulse Animation

```tsx
import { GlowPulse } from '@iammai-sandbox/shared/components/animations';

// For status indicators
<GlowPulse color="cyan" active={isConnected}>
  <div className="w-3 h-3 rounded-full bg-accent-cyan" />
</GlowPulse>
```

### Respecting Reduced Motion

```tsx
import { useReducedMotion } from '@iammai-sandbox/shared/hooks';

function AnimatedComponent() {
  const prefersReducedMotion = useReducedMotion();

  return (
    <motion.div
      animate={{ opacity: 1 }}
      transition={{
        duration: prefersReducedMotion ? 0 : 0.3
      }}
    >
      Content
    </motion.div>
  );
}
```

## Scan-Line Overlay

The scan-line texture is applied globally via CSS. To enable:

```tsx
// In _app.tsx or layout
<body className="scan-lines">
  {children}
</body>
```

To disable for specific areas (e.g., modals):

```tsx
<div className="relative z-[10000]">
  {/* Content above scan-lines */}
</div>
```

## Component Styling Examples

### Button with Glow

```tsx
<button
  className="
    bg-dark-surface1
    text-accent-cyan
    border border-accent-cyan/30
    px-4 py-2
    rounded-md
    glow-cyan-medium
    hover:glow-cyan-bright
    hover:bg-dark-surface2
    transition-all duration-hover
  "
>
  Action Button
</button>
```

### Card with Neon Border

```tsx
<div
  className="
    bg-dark-surface1
    border border-accent-cyan/20
    rounded-lg
    p-6
    glow-cyan-subtle
    hover:border-accent-cyan/40
    transition-colors duration-medium
  "
>
  Card content
</div>
```

### Chat Message (User)

```tsx
<div
  className="
    bg-dark-surface2
    border-l-2 border-accent-magenta
    text-text-primary
    p-4
    rounded-r-lg
    glow-magenta-subtle
  "
>
  User message content
</div>
```

### Chat Message (Assistant)

```tsx
<div
  className="
    bg-dark-surface1
    border-l-2 border-accent-cyan
    text-text-primary
    p-4
    rounded-r-lg
    glow-cyan-subtle
  "
>
  Assistant message content
</div>
```

## Testing Visual Changes

### Manual Verification Checklist

1. [ ] Backgrounds are near-black (#050505 range)
2. [ ] Neon accents are vibrant and distinguishable
3. [ ] Glow effects visible but not overwhelming
4. [ ] Scan-lines visible on close inspection
5. [ ] Text readable (acknowledge reduced contrast)
6. [ ] Hover states clearly indicate interactivity
7. [ ] Animations smooth at 60fps
8. [ ] Reduced-motion preference respected
9. [ ] Responsive from 320px to 4K

### Browser DevTools Tips

```javascript
// Check computed colors
getComputedStyle(element).backgroundColor

// Test reduced motion
// Chrome: Rendering > Emulate CSS media feature > prefers-reduced-motion: reduce

// Performance profiling
// Chrome: Performance tab > Record while interacting
// Target: No frames > 16.67ms (60fps)
```

### Lighthouse Audit

Focus on Performance score. Accessibility score will be lower than usual (expected due to contrast choices).

```bash
# Run Lighthouse from CLI
npx lighthouse http://localhost:3002 --view
```

## File Locations

| File | Purpose |
|------|---------|
| `frontend/packages/shared/src/styles/design-tokens.ts` | Token values |
| `frontend/packages/shared/tailwind.config.base.js` | Tailwind theme |
| `frontend/packages/shared/src/styles/scan-lines.css` | Texture overlay |
| `frontend/packages/shared/src/components/animations/` | Animation components |
| `frontend/apps/user/src/styles/globals.css` | User app global styles |
| `frontend/apps/admin/src/styles/globals.css` | Admin app global styles |

## Troubleshooting

### Glow not visible
- Check z-index of element (may be clipped by overflow)
- Verify box-shadow is not overridden
- Ensure parent doesn't have `overflow: hidden`

### Animations janky
- Check for layout-triggering properties in animation
- Use `transform` and `opacity` only
- Add `will-change: transform` before animation

### Scan-lines too visible/invisible
- Adjust opacity in `scan-lines.css` (default: 0.03)
- Check `prefers-reduced-motion` isn't reducing opacity further

### Colors look washed out
- Check color profile of monitor
- Verify hex values match design tokens
- Test on different displays/browsers
