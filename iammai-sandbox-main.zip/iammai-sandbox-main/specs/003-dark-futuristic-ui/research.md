# Research: Dark Futuristic UI (Extreme Edition)

**Feature**: 003-dark-futuristic-ui
**Date**: 2026-01-25
**Status**: Complete

## Research Topics

### 1. CSS Glow Effect Techniques

**Decision**: Use `box-shadow` for glow effects, with `filter: drop-shadow()` for irregular shapes

**Rationale**:
- `box-shadow` is GPU-accelerated and performs well at 60fps
- Multiple layered shadows create realistic glow depth
- Can animate shadow spread/blur without layout thrashing
- `filter: drop-shadow()` better for non-rectangular elements (icons, SVGs)

**Alternatives Considered**:
- `filter: blur()` on pseudo-elements: Higher memory usage, more complex markup
- CSS `background: radial-gradient()`: Less controllable glow shape, harder to animate
- Canvas/WebGL: Overkill for UI glow effects, poor accessibility

**Implementation Pattern**:
```css
/* Medium-intensity glow (spec requirement) */
.glow-cyan {
  box-shadow:
    0 0 4px rgba(0, 255, 255, 0.3),    /* inner glow */
    0 0 12px rgba(0, 255, 255, 0.2),   /* medium spread */
    0 0 24px rgba(0, 255, 255, 0.1);   /* outer halo */
}

/* Hover intensification */
.glow-cyan:hover {
  box-shadow:
    0 0 6px rgba(0, 255, 255, 0.5),
    0 0 18px rgba(0, 255, 255, 0.35),
    0 0 36px rgba(0, 255, 255, 0.2);
}
```

### 2. Scan-Line Overlay Implementation

**Decision**: CSS pseudo-element with repeating linear gradient

**Rationale**:
- Pure CSS, no additional assets to load
- Minimal performance impact (single composited layer)
- Easily adjustable opacity and line spacing
- Can be disabled for reduced-motion preference

**Alternatives Considered**:
- SVG pattern: More markup, similar performance
- PNG texture: Extra HTTP request, scaling issues on high-DPI
- Canvas rendering: Unnecessary complexity for static effect

**Implementation Pattern**:
```css
.scan-lines::after {
  content: '';
  position: fixed;
  inset: 0;
  pointer-events: none;
  background: repeating-linear-gradient(
    0deg,
    transparent,
    transparent 2px,
    rgba(0, 0, 0, 0.03) 2px,
    rgba(0, 0, 0, 0.03) 4px
  );
  z-index: 9999;
}

@media (prefers-reduced-motion: reduce) {
  .scan-lines::after {
    opacity: 0.5; /* Reduce visual noise */
  }
}
```

### 3. Performance Optimization for 60fps Animations

**Decision**: Use CSS transforms and opacity for animations; leverage `will-change` sparingly

**Rationale**:
- `transform` and `opacity` are compositor-only properties (no layout/paint)
- Framer Motion already optimizes for GPU acceleration
- `will-change` should be applied just before animation, removed after

**Best Practices**:
1. Animate only `transform`, `opacity`, and `filter`
2. Use `contain: layout style paint` on animated containers
3. Batch DOM reads before writes (Framer Motion handles this)
4. Test on mid-range devices (throttle to 4x CPU slowdown)

**Animation Timing**:
- Hover glow: 200-400ms with ease-out (spec: FR-011)
- Scroll reveal: 300-500ms with custom cubic-bezier
- Pulse: 2-3s infinite with ease-in-out

### 4. Neon Color Palette for Dark UIs

**Decision**: Electric cyan (#00ffff) as primary, magenta (#ff00ff) and blue (#00ccff) as secondary

**Rationale**:
- Cyan has highest perceived brightness on dark backgrounds
- Magenta provides strong contrast for CTAs and highlights
- Blue offers versatility for information/secondary actions
- All three are distinguishable from each other even at low saturation

**Color System**:
| Color | Hex | Use Case |
|-------|-----|----------|
| Cyan | #00ffff | Primary actions, key highlights, focus states |
| Magenta | #ff00ff | CTAs, active states, important indicators |
| Blue | #00ccff | Secondary actions, links, informational |
| Red (neon) | #ff3366 | Errors, destructive actions |
| Green (neon) | #00ff88 | Success, positive states |

**Glow Opacity Scale**:
- Subtle: 10-20% opacity
- Medium: 20-35% opacity (spec default)
- Bright: 40-60% opacity (hover/active states)

### 5. Ultra-Dark Background Strategy

**Decision**: Near-black base (#050505) with subtle gradient variations

**Rationale**:
- Pure black (#000000) can cause "black smearing" on OLED displays
- #050505 is perceptibly black while avoiding artifacts
- Subtle gradients add depth without compromising darkness
- Layered surfaces use #080808 to #0a0a0a for hierarchy

**Background Hierarchy**:
| Layer | Color | Use |
|-------|-------|-----|
| Base | #050505 | Page background, body |
| Surface 1 | #080808 | Cards, panels, modals |
| Surface 2 | #0a0a0a | Elevated elements, dropdowns |
| Surface 3 | #0d0d0d | Hover states on surfaces |
| Border | #1a1a1a | Subtle borders (before neon glow) |

### 6. Text Color Strategy (Low Contrast)

**Decision**: Gray text colors at reduced contrast for aesthetic effect

**Rationale**:
- User explicitly requested sacrificing accessibility for aesthetics
- Primary text at ~60% contrast instead of WCAG 4.5:1
- Critical information (errors, warnings) maintains higher contrast
- Interactive elements use neon colors for visibility

**Text Hierarchy**:
| Level | Color | Approx Contrast | Use |
|-------|-------|-----------------|-----|
| Primary | #a0a0a0 | ~3.5:1 | Main content, headings |
| Secondary | #707070 | ~2.5:1 | Supporting text, labels |
| Muted | #505050 | ~1.8:1 | Placeholders, hints |
| Error | #ff6666 | ~5.5:1 | Error messages (maintained) |
| Success | #66ff99 | ~6.0:1 | Success messages (maintained) |

## Dependencies

No new external dependencies required. Leveraging existing stack:
- Tailwind CSS 3.4 (custom theme extension)
- Framer Motion 12.x (existing animation library)
- CSS custom properties for runtime theming

## Risk Assessment

| Risk | Likelihood | Impact | Mitigation |
|------|------------|--------|------------|
| Animation jank on low-end devices | Medium | Medium | Respect prefers-reduced-motion, test on throttled CPU |
| Scan-lines cause visual fatigue | Low | Low | Very subtle opacity (3%), can be toggled if needed |
| Neon colors too intense | Low | Medium | Medium glow intensity per clarification, not maximum |
| Text unreadable in bright light | High | Medium | Accepted trade-off per spec assumptions |
