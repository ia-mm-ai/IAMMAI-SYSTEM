# Tasks: Dark Futuristic UI (Extreme Edition)

**Input**: Design documents from `/specs/003-dark-futuristic-ui/`
**Prerequisites**: plan.md, spec.md, research.md, data-model.md, quickstart.md

**Tests**: Not explicitly requested in spec. Visual verification via manual testing per quickstart.md.

**Organization**: Tasks grouped by user story for independent implementation.

## Format: `[ID] [P?] [Story] Description`

- **[P]**: Can run in parallel (different files, no dependencies)
- **[Story]**: Which user story this task belongs to (e.g., US1, US2)
- Paths use monorepo structure from plan.md

---

## Phase 1: Setup (Design Token Foundation)

**Purpose**: Update shared design token system with extreme dark palette

- [x] T001 Update design tokens with ultra-dark color palette in frontend/packages/shared/src/styles/design-tokens.ts
- [x] T002 Update Tailwind config with new dark colors and glow utilities in frontend/packages/shared/tailwind.config.base.js
- [x] T003 [P] Create scan-line CSS overlay in frontend/packages/shared/src/styles/scan-lines.css
- [x] T004 [P] Add glow utility classes to Tailwind config in frontend/packages/shared/tailwind.config.base.js

---

## Phase 2: Foundational (Animation Components)

**Purpose**: Create reusable animation components that multiple user stories depend on

**⚠️ CRITICAL**: Animation components must be complete before applying effects in user stories

- [x] T005 Create HoverGlow wrapper component in frontend/packages/shared/src/components/animations/HoverGlow.tsx
- [x] T006 [P] Create GlowPulse animation component in frontend/packages/shared/src/components/animations/GlowPulse.tsx
- [x] T007 [P] Update animation index exports in frontend/packages/shared/src/components/animations/index.ts
- [x] T008 Verify useReducedMotion hook integration in frontend/packages/shared/src/hooks/useReducedMotion.ts

**Checkpoint**: Foundation ready - animation components available for use in user stories

---

## Phase 3: User Story 1 - Immersive Dark Visual Experience (Priority: P1) 🎯 MVP

**Goal**: Ultra-dark backgrounds (#050505-#0a0a0a) with vibrant neon accents across all pages

**Independent Test**: Load any page and verify near-black backgrounds with neon accent colors visible

### Implementation for User Story 1

- [x] T009 [P] [US1] Update user app global styles with ultra-dark base in frontend/apps/user/src/styles/globals.css
- [x] T010 [P] [US1] Update admin app global styles with ultra-dark base in frontend/apps/admin/src/styles/globals.css
- [x] T011 [US1] Update user app page backgrounds to use dark-base in frontend/apps/user/src/pages/index.tsx
- [x] T012 [US1] Update user app chat page backgrounds in frontend/apps/user/src/pages/chat/[id].tsx
- [x] T013 [P] [US1] Update admin app page backgrounds to use dark-base in frontend/apps/admin/src/pages/index.tsx
- [x] T014 [US1] Update text colors to low-contrast gray palette in frontend/packages/shared/src/styles/design-tokens.ts
- [x] T015 [US1] Apply neon accent colors to interactive elements in user app components

**Checkpoint**: User Story 1 complete - ultra-dark backgrounds visible on all pages

---

## Phase 4: User Story 2 - Cyberpunk Visual Elements (Priority: P1)

**Goal**: Glow effects on interactive elements, neon borders on containers, scan-line overlay

**Independent Test**: Examine buttons/inputs for glow effects, cards for neon borders, backgrounds for scan-lines

### Implementation for User Story 2

- [x] T016 [P] [US2] Apply scan-line overlay to user app body in frontend/apps/user/src/styles/globals.css
- [x] T017 [P] [US2] Apply scan-line overlay to admin app body in frontend/apps/admin/src/styles/globals.css
- [x] T018 [US2] Add glow effects to ChatMessage component in frontend/apps/user/src/components/ChatMessage.tsx
- [x] T019 [P] [US2] Add neon border styling to SessionList component in frontend/apps/user/src/components/SessionList.tsx
- [x] T020 [P] [US2] Add neon border styling to SessionCard admin component in frontend/apps/admin/src/components/SessionCard.tsx
- [x] T021 [US2] Update KernelStatus user component with glow effects in frontend/apps/user/src/components/KernelStatus.tsx
- [x] T022 [P] [US2] Update KernelStatus admin component with glow effects in frontend/apps/admin/src/components/KernelStatus.tsx
- [x] T023 [US2] Add glow to PresenceIndicator component in frontend/apps/user/src/components/PresenceIndicator.tsx
- [x] T024 [US2] Update DissolutionOverlay with neon styling in frontend/apps/user/src/components/DissolutionOverlay.tsx

**Checkpoint**: User Story 2 complete - glow effects and scan-lines visible throughout UI

---

## Phase 5: User Story 3 - Neon Accent Color System (Priority: P2)

**Goal**: Cohesive neon palette (cyan, magenta, blue) applied consistently across buttons, links, status indicators

**Independent Test**: Verify accent colors are consistent and distinguishable across all interactive elements

### Implementation for User Story 3

- [x] T025 [P] [US3] Update StatusBadge with neon semantic colors in frontend/packages/shared/src/components/StatusBadge.tsx
- [x] T026 [P] [US3] Update Toast component with neon accent styling in frontend/packages/shared/src/components/Toast.tsx
- [x] T027 [US3] Apply cyan accent to primary actions (send button, CTAs) in user app components
- [x] T028 [US3] Apply magenta accent to secondary actions and highlights in user app components
- [x] T029 [US3] Differentiate user vs assistant chat messages with complementary accents in frontend/apps/user/src/components/ChatMessage.tsx
- [x] T030 [US3] Update LifecycleTimeline admin component with neon accents in frontend/apps/admin/src/components/LifecycleTimeline.tsx

**Checkpoint**: User Story 3 complete - consistent neon accent system across all apps

---

## Phase 6: User Story 4 - Futuristic Typography (Priority: P2)

**Goal**: Geometric sans-serif fonts with dramatic hierarchy and optional text glow effects

**Independent Test**: Verify font choices, size scale, and heading treatments across pages

### Implementation for User Story 4

- [x] T031 [P] [US4] Add Space Grotesk or Orbitron font import to user app in frontend/apps/user/src/pages/_app.tsx
- [x] T032 [P] [US4] Add Space Grotesk or Orbitron font import to admin app in frontend/apps/admin/src/pages/_app.tsx
- [x] T033 [US4] Update typography tokens with new font families in frontend/packages/shared/src/styles/design-tokens.ts
- [x] T034 [US4] Apply dramatic heading styles with optional text-glow in user app pages
- [x] T035 [US4] Apply tighter letter-spacing to body text via Tailwind config
- [x] T036 [US4] Update LoadingSkeleton with futuristic styling in frontend/packages/shared/src/components/LoadingSkeleton.tsx

**Checkpoint**: User Story 4 complete - futuristic typography visible across all pages

---

## Phase 7: User Story 5 - Ambient Animations & Effects (Priority: P3)

**Goal**: Smooth hover glows, scroll reveal animations, pulsing status indicators

**Independent Test**: Interact with elements and observe smooth 60fps animations; check prefers-reduced-motion behavior

### Implementation for User Story 5

- [x] T037 [US5] Apply HoverGlow component to buttons in user app
- [x] T038 [P] [US5] Apply HoverGlow component to buttons in admin app
- [x] T039 [US5] Wrap scroll content with FadeUp animations in user app pages
- [x] T040 [P] [US5] Wrap scroll content with FadeUp animations in admin app pages
- [x] T041 [US5] Apply GlowPulse to connection status indicators in frontend/apps/user/src/components/KernelStatus.tsx
- [x] T042 [US5] Apply GlowPulse to loading states in frontend/packages/shared/src/components/LoadingSkeleton.tsx
- [x] T043 [US5] Add smooth glow intensification transitions (200-400ms) to interactive elements
- [x] T044 [US5] Verify prefers-reduced-motion reduces animation intensity across all components

**Checkpoint**: User Story 5 complete - ambient animations enhance futuristic feel

---

## Phase 8: Polish & Cross-Cutting Concerns

**Purpose**: Final validation and consistency checks across both apps

- [x] T045 [P] Run visual consistency check across user app (all pages, viewports)
- [x] T046 [P] Run visual consistency check across admin app (all pages, viewports)
- [x] T047 Test responsive design from 320px to 4K resolution
- [x] T048 Run Lighthouse performance audit (target 60fps animations)
- [x] T049 Verify all glow effects use medium intensity per spec clarification
- [x] T050 Verify scan-line opacity at 3% per research.md
- [x] T051 Manual verification using quickstart.md checklist
- [x] T052 Code cleanup - remove any unused 002 tokens superseded by 003

---

## Dependencies & Execution Order

### Phase Dependencies

- **Setup (Phase 1)**: No dependencies - can start immediately
- **Foundational (Phase 2)**: Depends on Setup (T001-T004) - creates animation components
- **User Stories (Phase 3-7)**: All depend on Foundational phase completion
  - US1 and US2 are both P1 - can be worked in parallel after foundational
  - US3 and US4 are both P2 - can start after foundational, parallel with each other
  - US5 is P3 - can start after foundational, best after US1-US2 for glow components
- **Polish (Phase 8)**: Depends on all user stories being complete

### User Story Dependencies

- **User Story 1 (P1)**: Can start after Phase 2 - No dependencies on other stories
- **User Story 2 (P1)**: Can start after Phase 2 - Uses glow components from Phase 2
- **User Story 3 (P2)**: Can start after Phase 2 - No dependencies on US1/US2
- **User Story 4 (P2)**: Can start after Phase 2 - No dependencies on US1-US3
- **User Story 5 (P3)**: Can start after Phase 2 - Best after US1/US2 styles are in place

### Parallel Opportunities

**Phase 1 (Setup)**:
- T003 and T004 can run in parallel

**Phase 2 (Foundational)**:
- T006 and T007 can run in parallel after T005

**Phase 3 (US1)**:
- T009 and T010 can run in parallel (different apps)
- T011 and T013 can run in parallel (different apps)

**Phase 4 (US2)**:
- T016 and T017 can run in parallel (different apps)
- T019 and T020 can run in parallel (different apps)
- T021 and T022 can run in parallel (different apps)

**Phase 5 (US3)**:
- T025 and T026 can run in parallel (different components)

**Phase 6 (US4)**:
- T031 and T032 can run in parallel (different apps)

**Phase 7 (US5)**:
- T037 and T038 can run in parallel (different apps)
- T039 and T040 can run in parallel (different apps)

---

## Parallel Example: Phase 4 (User Story 2)

```bash
# Launch scan-line overlay tasks together:
Task: "Apply scan-line overlay to user app body"
Task: "Apply scan-line overlay to admin app body"

# Launch KernelStatus updates together:
Task: "Update KernelStatus user component with glow effects"
Task: "Update KernelStatus admin component with glow effects"
```

---

## Implementation Strategy

### MVP First (User Stories 1 + 2 Only)

1. Complete Phase 1: Setup (design tokens)
2. Complete Phase 2: Foundational (animation components)
3. Complete Phase 3: User Story 1 (dark backgrounds)
4. Complete Phase 4: User Story 2 (glow effects + scan-lines)
5. **STOP and VALIDATE**: Core futuristic look is complete
6. Demo/review before continuing to accent colors and animations

### Incremental Delivery

1. Setup + Foundational → Token system ready
2. Add User Story 1 → Dark backgrounds visible → Demo
3. Add User Story 2 → Glow effects + scan-lines → Demo (MVP!)
4. Add User Story 3 → Consistent accent colors → Demo
5. Add User Story 4 → Futuristic typography → Demo
6. Add User Story 5 → Animations → Demo (Full feature)

### Recommended Sequence (Single Developer)

1. Phase 1 (Setup): T001 → T002 → T003, T004
2. Phase 2 (Foundational): T005 → T006, T007 → T008
3. Phase 3 (US1): T009, T010 → T011, T013 → T012 → T014 → T015
4. Phase 4 (US2): T016, T017 → T018-T024
5. Phase 5 (US3): T025, T026 → T027-T030
6. Phase 6 (US4): T031, T032 → T033 → T034-T036
7. Phase 7 (US5): T037, T038 → T039-T044
8. Phase 8 (Polish): T045-T052

---

## Notes

- [P] tasks = different files/apps, no dependencies
- [Story] label maps task to specific user story
- US1 and US2 are both P1 priority - complete both for MVP
- Verify reduced-motion preference throughout
- Commit after each task or logical group
- Test each checkpoint before proceeding
