# Data Model: Dark Futuristic UI Design Tokens

**Feature**: 003-dark-futuristic-ui
**Date**: 2026-01-25
**Type**: Design Token Schema

## Overview

This document defines the design token schema for the extreme dark futuristic UI. These tokens update the existing `design-tokens.ts` and `tailwind.config.base.js` from feature 002.

## Token Schema

### Colors

#### Background Colors (Ultra-Dark)

| Token | Value | Description |
|-------|-------|-------------|
| `dark.base` | `#050505` | Primary page background |
| `dark.surface1` | `#080808` | Cards, panels, modals |
| `dark.surface2` | `#0a0a0a` | Elevated elements |
| `dark.surface3` | `#0d0d0d` | Hover states on surfaces |
| `dark.border` | `#1a1a1a` | Subtle borders |

#### Neon Accent Colors

| Token | Value | Glow Color (30% opacity) | Description |
|-------|-------|--------------------------|-------------|
| `accent.cyan` | `#00ffff` | `rgba(0, 255, 255, 0.3)` | Primary accent |
| `accent.cyanHover` | `#33ffff` | `rgba(51, 255, 255, 0.4)` | Cyan hover state |
| `accent.magenta` | `#ff00ff` | `rgba(255, 0, 255, 0.3)` | Secondary accent |
| `accent.magentaHover` | `#ff33ff` | `rgba(255, 51, 255, 0.4)` | Magenta hover |
| `accent.blue` | `#00ccff` | `rgba(0, 204, 255, 0.3)` | Tertiary accent |
| `accent.blueHover` | `#33d6ff` | `rgba(51, 214, 255, 0.4)` | Blue hover |

#### Text Colors (Low Contrast)

| Token | Value | Contrast Ratio | Description |
|-------|-------|----------------|-------------|
| `text.primary` | `#a0a0a0` | ~3.5:1 | Main content |
| `text.secondary` | `#707070` | ~2.5:1 | Supporting text |
| `text.muted` | `#505050` | ~1.8:1 | Placeholders |
| `text.bright` | `#e0e0e0` | ~5.5:1 | Emphasized text |

#### Semantic Colors (Neon, High Visibility)

| Token | Value | Glow Color | Description |
|-------|-------|------------|-------------|
| `semantic.error` | `#ff3366` | `rgba(255, 51, 102, 0.35)` | Errors |
| `semantic.errorText` | `#ff6666` | - | Error message text |
| `semantic.errorBg` | `#1a0a0d` | - | Error background |
| `semantic.success` | `#00ff88` | `rgba(0, 255, 136, 0.35)` | Success |
| `semantic.successText` | `#66ff99` | - | Success message text |
| `semantic.successBg` | `#0a1a10` | - | Success background |
| `semantic.warning` | `#ffaa00` | `rgba(255, 170, 0, 0.35)` | Warnings |
| `semantic.warningText` | `#ffcc66` | - | Warning message text |
| `semantic.warningBg` | `#1a150a` | - | Warning background |
| `semantic.info` | `#00ccff` | `rgba(0, 204, 255, 0.35)` | Information |

### Glow System

#### Glow Intensity Levels

| Level | Inner | Medium | Outer | Use Case |
|-------|-------|--------|-------|----------|
| `subtle` | `0 0 2px 0.15` | `0 0 6px 0.1` | `0 0 12px 0.05` | Borders, inactive states |
| `medium` | `0 0 4px 0.3` | `0 0 12px 0.2` | `0 0 24px 0.1` | Default interactive elements |
| `bright` | `0 0 6px 0.5` | `0 0 18px 0.35` | `0 0 36px 0.2` | Hover, active, focus states |

Note: Values are `blur opacity` format. Apply as multi-layer box-shadow with accent color.

#### Glow Utility Classes

```text
.glow-cyan-subtle
.glow-cyan-medium (default)
.glow-cyan-bright

.glow-magenta-subtle
.glow-magenta-medium
.glow-magenta-bright

.glow-blue-subtle
.glow-blue-medium
.glow-blue-bright
```

### Typography

#### Font Families

| Token | Value | Description |
|-------|-------|-------------|
| `fontFamily.display` | `'Orbitron', 'Space Grotesk', var(--font-inter), sans-serif` | Hero headings (optional) |
| `fontFamily.sans` | `var(--font-inter), 'Space Grotesk', ui-sans-serif, system-ui, sans-serif` | Body text |
| `fontFamily.mono` | `'SF Mono', 'Fira Code', 'Cascadia Code', Consolas, monospace` | Code blocks |

#### Font Sizes (unchanged from 002)

Maintains existing scale: xs (12px) through 6xl (60px)

#### Text Glow (Optional)

| Token | Value | Description |
|-------|-------|-------------|
| `textGlow.heading` | `0 0 20px rgba(0, 255, 255, 0.3)` | Hero heading glow |
| `textGlow.subtle` | `0 0 10px rgba(0, 255, 255, 0.15)` | Subtle text emphasis |

### Animation Tokens

#### Timing

| Token | Value | Description |
|-------|-------|-------------|
| `duration.instant` | `0ms` | Immediate feedback |
| `duration.fast` | `150ms` | Micro-interactions |
| `duration.hover` | `250ms` | Hover transitions |
| `duration.medium` | `350ms` | Standard transitions |
| `duration.slow` | `500ms` | Emphasis transitions |
| `duration.reveal` | `600ms` | Scroll-triggered reveals |
| `duration.pulse` | `2500ms` | Ambient pulse cycle |

#### Easing Functions

| Token | Value | Description |
|-------|-------|-------------|
| `easing.linear` | `linear` | Constant speed |
| `easing.out` | `cubic-bezier(0, 0, 0.2, 1)` | Deceleration |
| `easing.in` | `cubic-bezier(0.4, 0, 1, 1)` | Acceleration |
| `easing.inOut` | `cubic-bezier(0.4, 0, 0.2, 1)` | Symmetric |
| `easing.reveal` | `cubic-bezier(0.22, 1, 0.36, 1)` | Smooth reveal |
| `easing.bounce` | `cubic-bezier(0.34, 1.56, 0.64, 1)` | Playful overshoot |

### Scan-Line Texture

| Property | Value | Description |
|----------|-------|-------------|
| `lineSpacing` | `4px` | Distance between lines |
| `lineHeight` | `2px` | Thickness of each line |
| `opacity` | `0.03` | Very subtle visibility |
| `color` | `#000000` | Pure black lines |
| `zIndex` | `9999` | Above all content |

### Spacing (unchanged)

Maintains existing 4px/8px grid system from feature 002.

## Entity Relationships

```text
┌─────────────────────────────────────────────────────────────┐
│                     Design Token System                      │
├─────────────────────────────────────────────────────────────┤
│                                                              │
│  ┌─────────────┐     ┌─────────────┐     ┌─────────────┐    │
│  │   Colors    │────▶│    Glow     │────▶│ Components  │    │
│  │  (palette)  │     │  (effects)  │     │  (styles)   │    │
│  └─────────────┘     └─────────────┘     └─────────────┘    │
│         │                   │                   │            │
│         ▼                   ▼                   ▼            │
│  ┌─────────────┐     ┌─────────────┐     ┌─────────────┐    │
│  │ Typography  │     │  Animation  │     │   Layout    │    │
│  │   (fonts)   │     │  (timing)   │     │  (spacing)  │    │
│  └─────────────┘     └─────────────┘     └─────────────┘    │
│                                                              │
│  ┌──────────────────────────────────────────────────────┐   │
│  │                   Scan-Line Texture                   │   │
│  │              (global overlay, fixed z-index)          │   │
│  └──────────────────────────────────────────────────────┘   │
│                                                              │
└─────────────────────────────────────────────────────────────┘
```

## Migration from 002-dark-futuristic-ui

| Old Token (002) | New Token (003) | Change |
|-----------------|-----------------|--------|
| `dark.950` (#0a0a0a) | `dark.base` (#050505) | Darker base |
| `dark.900` (#0d1117) | `dark.surface1` (#080808) | Darker surface |
| `text.primary` (#e6edf3) | `text.primary` (#a0a0a0) | Lower contrast |
| `accent.cyan` (#00ffc3) | `accent.cyan` (#00ffff) | Pure cyan |
| N/A | `glow.*` tokens | New glow system |
| N/A | `scanLine.*` tokens | New texture |

## Validation Rules

1. All background colors MUST be in range #050505 to #0d0d0d
2. All accent colors MUST be at full saturation (vibrant neon)
3. Glow colors MUST derive from accent colors with specified opacity
4. Text colors MAY fall below WCAG AA (explicitly accepted)
5. Semantic error/success colors MUST maintain minimum 5:1 contrast
6. Animation durations MUST not exceed 600ms for interactive feedback
