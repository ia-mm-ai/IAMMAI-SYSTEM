# Implementation Plan: Dark Futuristic UI (Extreme Edition)

**Branch**: `003-dark-futuristic-ui` | **Date**: 2026-01-25 | **Spec**: [spec.md](./spec.md)
**Input**: Feature specification from `/specs/003-dark-futuristic-ui/spec.md`

## Summary

Transform the existing dark theme into an ultra-dark, cyberpunk-inspired visual experience featuring near-black backgrounds (#050505-#0a0a0a), neon accent colors (cyan, magenta, blue), medium-intensity glow effects, scan-line texture overlays, and ambient animations. This builds on the existing design token system from feature 002-dark-futuristic-ui, pushing the aesthetic to an extreme while explicitly sacrificing WCAG accessibility compliance per user request.

## Technical Context

**Language/Version**: TypeScript 5.3+ on Node.js 20 LTS
**Primary Dependencies**: Next.js 14, React 18, Tailwind CSS 3.4, Framer Motion 12.x, pnpm workspace
**Storage**: N/A (styling only, no data layer changes)
**Testing**: Visual regression testing, manual verification, Lighthouse performance audit
**Target Platform**: Modern browsers (Chrome 100+, Firefox 100+, Safari 16+, Edge 100+)
**Project Type**: Web (monorepo with frontend apps + shared package)
**Performance Goals**: 60fps animations, <100ms interaction feedback
**Constraints**: Must maintain responsive design (320px to 4K), must respect prefers-reduced-motion
**Scale/Scope**: 2 frontend apps (user, admin), 1 shared package, ~15 components affected

## Constitution Check

*GATE: Must pass before Phase 0 research. Re-check after Phase 1 design.*

| Principle | Status | Notes |
|-----------|--------|-------|
| I. Code Quality First | ✅ PASS | TypeScript strict mode, modular CSS architecture, documented design tokens |
| II. Testing Standards | ✅ PASS | Visual regression tests, component storybook verification possible |
| III. User Experience Consistency | ⚠️ OVERRIDE | **Accessibility clause explicitly overridden** - spec FR-003 permits lower contrast ratios; user accepted trade-off |
| IV. Performance Requirements | ✅ PASS | 60fps animation target, <100ms feedback aligns with constitution |
| V. Privacy & Ephemerality | ✅ PASS | Styling-only changes, no data handling modifications |

### Constitution Override Justification

**Principle III - Accessibility (WCAG 2.1 AA) Override**:
- **User Directive**: Explicit user instruction: "If needed, sacrifice accessibility"
- **Documented**: Spec Assumptions section records user acceptance of reduced readability
- **Mitigation**: Semantic colors for errors/success maintain visibility; prefers-reduced-motion respected
- **Scope**: Override applies only to contrast ratios and color differentiation, not keyboard accessibility or responsive design

## Project Structure

### Documentation (this feature)

```text
specs/003-dark-futuristic-ui/
├── plan.md              # This file
├── research.md          # Phase 0 output
├── data-model.md        # Phase 1 output (design token schema)
├── quickstart.md        # Phase 1 output (developer setup)
├── contracts/           # N/A for styling feature
└── tasks.md             # Phase 2 output (/speckit.tasks command)
```

### Source Code (repository root)

```text
frontend/
├── packages/
│   └── shared/
│       ├── src/
│       │   ├── styles/
│       │   │   ├── design-tokens.ts      # Update: extreme dark palette
│       │   │   └── scan-lines.css        # New: CRT texture overlay
│       │   ├── components/
│       │   │   ├── animations/
│       │   │   │   ├── GlowPulse.tsx     # New: pulsing glow animation
│       │   │   │   └── HoverGlow.tsx     # New: hover glow wrapper
│       │   │   └── ...existing components (update styles)
│       │   └── hooks/
│       │       └── useReducedMotion.ts   # Existing: ensure integration
│       └── tailwind.config.base.js       # Update: extreme dark colors, glow utilities
├── apps/
│   ├── user/
│   │   ├── src/
│   │   │   ├── styles/
│   │   │   │   └── globals.css           # Update: scan-line overlay, base styles
│   │   │   ├── components/               # Update: apply glow effects
│   │   │   └── pages/                    # Update: apply new theme
│   │   └── tailwind.config.js            # Extends shared config
│   └── admin/
│       ├── src/
│       │   ├── styles/
│       │   │   └── globals.css           # Update: scan-line overlay, base styles
│       │   └── components/               # Update: apply glow effects
│       └── tailwind.config.js            # Extends shared config
```

**Structure Decision**: Leverages existing monorepo structure. Shared design tokens in `packages/shared` ensure consistency across both apps. New glow components and scan-line CSS added to shared package for reuse.

## Complexity Tracking

| Violation | Why Needed | Simpler Alternative Rejected Because |
|-----------|------------|-------------------------------------|
| WCAG AA Override | User explicitly requested aesthetic over accessibility | Cannot achieve "extreme dark futuristic" look while maintaining AA contrast ratios |

## Phase 0: Research Summary

See [research.md](./research.md) for detailed findings on:
- CSS glow effect techniques (box-shadow vs filter)
- Scan-line overlay implementation patterns
- Performance optimization for 60fps animations
- Neon color palette best practices for dark UIs

## Phase 1: Design Artifacts

### Design Token Schema

See [data-model.md](./data-model.md) for complete token definitions including:
- Ultra-dark color palette (#050505-#0a0a0a base)
- Neon accent colors (cyan #00ffff, magenta #ff00ff, blue #00ccff)
- Glow intensity system (subtle, medium, bright)
- Animation timing presets
- Scan-line texture specifications

### Developer Quickstart

See [quickstart.md](./quickstart.md) for:
- Local development setup
- Design token usage examples
- Glow effect utility classes
- Animation component usage
- Testing visual changes
