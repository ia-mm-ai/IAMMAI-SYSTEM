# Feature Specification: Structural Foundation (Integrity Layer)

**Feature Branch**: `005-structural-foundation`
**Created**: 2026-02-14
**Status**: Draft
**Input**: Build the Integrity Layer's structural foundation — forward-only state machine, append-only ledger, and event boundary enforcement implementing MM-MODEL protocols I.02, I.03, and I.04.

## User Scenarios & Testing *(mandatory)*

### User Story 1 - Forward-Only Session State Machine (Priority: P1) MVP

The system enforces a strict, forward-only session lifecycle where sessions progress through CREATED → ACTIVE → CLOSED and can never regress. When an admin creates a session, it enters CREATED state with mandatory boundary declarations (topic, constraints). When the session is started, it transitions to ACTIVE. When ended, it transitions to CLOSED. Each state transition adds information (timestamps, metadata) without removing anything from the previous state — closing a session adds close metadata but never erases open metadata. No transition can move backward. No session can be reopened after closing.

This maps the existing IAMMAI Sandbox session states (CREATED/ACTIVE/ENDED) to the MM-MODEL's OPEN/CLOSED model per Framework Decision 2: CREATED and ACTIVE both map to OPEN; ENDED maps to CLOSED. The integrity layer observes and records these transitions without modifying the existing chat engine behavior.

**Why this priority**: The state machine is the foundation everything else depends on. Without forward-only transitions, the ledger cannot be trusted, boundaries cannot be enforced, and no downstream protocol (verification, witness, suppression) can function. This is the minimum viable integrity guarantee.

**Independent Test**: Create a session, transition it through all states, and verify that every backward transition attempt is rejected. Verify that state data is additive (each transition adds metadata, none is removed).

**Acceptance Scenarios**:

1. **Given** a new session request with a declared topic and constraints, **When** the session is created, **Then** the session enters CREATED state with event_id (UUID v4), t_open (ISO 8601 UTC), context_descriptor, environmental_constraints, and status = OPEN recorded
2. **Given** a session in CREATED state, **When** the session is started, **Then** the session transitions to ACTIVE with a started_at timestamp added (t_open preserved, not overwritten)
3. **Given** a session in ACTIVE state, **When** the session is ended, **Then** the session transitions to CLOSED with t_close timestamp added, and all prior metadata (t_open, context_descriptor, started_at) preserved intact
4. **Given** a session in CLOSED state, **When** any attempt is made to transition it to ACTIVE or CREATED, **Then** the system rejects the transition and records the rejected attempt
5. **Given** a session in ACTIVE state, **When** an attempt is made to transition it back to CREATED, **Then** the system rejects the transition
6. **Given** a session in any state, **When** its state data is inspected, **Then** the data from all prior states is present and unmodified (state is a superset of all previous states)

---

### User Story 2 - Append-Only Integrity Ledger (Priority: P1)

The system maintains an append-only ledger that records session lifecycle metadata — not chat content. Each ledger entry captures session boundary events (creation, activation, closure), and entries are time-ordered and hash-chained so that any tampering or deletion is detectable. The ledger supports no DELETE, UPDATE, HIDE, or REDACT operations. Once an entry is written, it is permanent.

The ledger records only metadata (session_id, timestamps, participant_count, admin_id) and never records message content, user input, or AI responses, per Framework Decision 10 (Privacy Boundary) and the Reality Stack layer separation.

**Why this priority**: The ledger is the integrity guarantee. Without it, state transitions are unwitnessed and unverifiable. The ledger and state machine together form the minimum structural foundation required by the framework.

**Independent Test**: Write several ledger entries, verify they are hash-chained and time-ordered, then attempt to delete or modify an entry and verify the system rejects the operation. Verify the hash chain detects any tampering.

**Acceptance Scenarios**:

1. **Given** a session state transition occurs, **When** the transition completes, **Then** a new ledger entry is appended with: session_id, event type, timestamp (ISO 8601 UTC), and a hash linking to the previous entry
2. **Given** a ledger with existing entries, **When** a new entry is appended, **Then** the new entry's hash incorporates the previous entry's hash (hash-chain integrity)
3. **Given** any ledger entry, **When** an attempt is made to delete it, **Then** the system rejects the operation
4. **Given** any ledger entry, **When** an attempt is made to modify it, **Then** the system rejects the operation
5. **Given** a ledger with N entries, **When** the hash chain is validated, **Then** validation confirms all entries are intact and sequential with no gaps
6. **Given** a session that has been created, activated, and closed, **When** the ledger is inspected, **Then** it contains exactly 3 entries (one per transition) in chronological order, and none contain message content or user data

---

### User Story 3 - Event Boundary Enforcement (Priority: P2)

The system enforces that every session (event) has explicit, declared boundaries: a mandatory opening time, a mandatory closing time (set when closed), a declared context (topic/purpose), and declared constraints (max participants, time limit, AI model). No truth finalization (witness emission, verification record) may reference an OPEN event — all finalization happens only after a session is CLOSED.

Per Framework Decision 1, boundaries use UUID v4 for event_id, ISO 8601 UTC for timestamps, and JSON schemas for context_descriptor and environmental_constraints.

**Why this priority**: Event boundaries are required by I.02 but are partially enforced by the existing IAMMAI Sandbox session model already (sessions have created_at and ended_at). This story formalizes the boundary declarations and adds the constraint that finalization references only closed events. It builds on US1's state machine.

**Independent Test**: Create a session with boundary declarations, verify all required fields are present, then attempt to finalize (emit a witness artifact reference) while the session is still OPEN and verify the system rejects it. Close the session and verify finalization is now permitted.

**Acceptance Scenarios**:

1. **Given** a session creation request, **When** the request omits context_descriptor or environmental_constraints, **Then** the system rejects the creation with a clear error
2. **Given** a session in OPEN state (CREATED or ACTIVE), **When** any operation attempts to reference it for truth finalization, **Then** the system rejects the operation
3. **Given** a session in CLOSED state with valid t_open and t_close, **When** a downstream operation references it for finalization, **Then** the system permits the reference
4. **Given** a closed session, **When** its boundary data is inspected, **Then** t_open < t_close, both are valid ISO 8601 UTC timestamps, and context_descriptor and environmental_constraints are present and non-empty

---

### Edge Cases

- What happens when two state transitions are attempted simultaneously on the same session? The system must handle concurrent transitions safely, applying only one and rejecting the other.
- What happens when the system crashes mid-transition before the ledger entry is written? The transition and ledger entry must be atomic — either both succeed or neither does.
- What happens when the ledger's hash chain is broken (e.g., database corruption)? The system must detect the break during validation and report which entries are affected.
- What happens when a session is created with an event_id that already exists? The system must reject the duplicate.
- What happens when environmental_constraints contain invalid values (e.g., negative max_participants)? The system must validate constraints at creation time.

## Requirements *(mandatory)*

### Functional Requirements

- **FR-001**: System MUST enforce forward-only state transitions: CREATED → ACTIVE → CLOSED with no backward transitions permitted
- **FR-002**: System MUST record each state transition as an append-only ledger entry with session_id, event type, ISO 8601 UTC timestamp, and hash-chain link to the previous entry
- **FR-003**: System MUST reject any attempt to delete, update, hide, or redact a ledger entry
- **FR-004**: System MUST require context_descriptor (topic/purpose) and environmental_constraints (max_participants, time_limit_minutes, ai_model) at session creation
- **FR-005**: System MUST use UUID v4 for event_id and ISO 8601 UTC for all timestamps per Framework Decision 1
- **FR-006**: System MUST preserve all metadata from prior states when transitioning (state data is additive, never destructive)
- **FR-007**: System MUST reject any truth finalization operation that references a session in OPEN state (CREATED or ACTIVE)
- **FR-008**: System MUST validate the hash chain integrity of the ledger on demand, detecting any gaps or tampering
- **FR-009**: System MUST ensure atomicity between state transitions and their corresponding ledger entries — both succeed or neither does
- **FR-010**: System MUST record rejected transition attempts in the ledger as suppression events
- **FR-011**: System MUST never record message content, user input, or AI responses in the ledger — only session metadata per Framework Decision 10
- **FR-012**: The integrity layer MUST operate beside the existing chat engine without modifying its behavior — the chat engine remains ephemeral, the integrity layer records metadata

### Key Entities

- **IntegrityEvent**: A session lifecycle event recorded in the ledger — captures event_id (UUID v4), event_type (SESSION_CREATED, SESSION_ACTIVATED, SESSION_CLOSED, TRANSITION_REJECTED), timestamp (ISO 8601 UTC), session metadata snapshot, and hash-chain link
- **SessionBoundary**: The declared boundaries of a session — t_open, t_close, context_descriptor, environmental_constraints, and framework status (OPEN/CLOSED mapped from IAMMAI Sandbox states per Decision 2)
- **LedgerEntry**: An immutable, hash-chained record in the append-only ledger — contains the IntegrityEvent data plus a cryptographic hash incorporating the previous entry's hash
- **HashChain**: The ordered sequence of ledger entries linked by cryptographic hashes — validates integrity of the complete ledger history

## Success Criteria *(mandatory)*

### Measurable Outcomes

- **SC-001**: Every session state transition attempt (valid or invalid) is recorded in the ledger within the same operation, with zero data loss
- **SC-002**: 100% of backward state transition attempts are rejected — no session can ever regress from CLOSED to ACTIVE, ACTIVE to CREATED, or CLOSED to CREATED
- **SC-003**: The ledger hash chain validates correctly across all entries, and any single tampered entry is detectable
- **SC-004**: No message content, user input, or AI response data appears in any ledger entry — verified by inspection of all ledger entries after a complete session lifecycle
- **SC-005**: Session creation fails if context_descriptor or environmental_constraints are missing or invalid
- **SC-006**: No truth finalization operation succeeds against an OPEN session — 100% rejection rate for premature finalization attempts
- **SC-007**: The integrity layer introduces no observable change to existing chat engine behavior — ephemeral messaging, token management, and WebSocket communication continue unchanged

## Assumptions

- The existing PostgreSQL database is available and can host the new ledger table alongside existing tables
- SHA-256 is sufficient for the hash-chain algorithm (consistent with existing token hashing in the codebase)
- The existing session model (models/session.ts) already enforces CREATED → ACTIVE → ENDED transitions at the database level; the integrity layer adds the ledger recording and enhanced boundary enforcement on top of this
- The integrity layer will be implemented as new modules under a dedicated directory (e.g., `backend/src/integrity/`) to maintain separation from the existing chat engine
- Framework Decision 2's state mapping (CREATED+ACTIVE=OPEN, ENDED=CLOSED) is a conceptual mapping for the integrity layer; the existing IAMMAI Sandbox session states are not renamed

## Dependencies

- Feature 004 (Framework Decisions) must be merged — provides the decision document referenced throughout this spec
- Existing IAMMAI Sandbox backend session infrastructure (models/session.ts, session routes, kernel manager) must be stable
- PostgreSQL database with migration support for adding the ledger table
