# Tasks: Structural Foundation (Integrity Layer)

**Input**: Design documents from `/specs/005-structural-foundation/`
**Prerequisites**: plan.md (required), spec.md (required for user stories), research.md, data-model.md, contracts/

**Tests**: Test tasks are included — the constitution mandates unit, integration, and privacy tests (Principle II).

**Organization**: Tasks are grouped by user story to enable independent implementation and testing of each story.

## Format: `[ID] [P?] [Story] Description`

- **[P]**: Can run in parallel (different files, no dependencies)
- **[Story]**: Which user story this task belongs to (e.g., US1, US2, US3)
- Include exact file paths in descriptions

## Path Conventions

- **Web app (backend extension)**: `backend/src/`, `backend/tests/`, `backend/migrations/`
- Integrity layer lives in `backend/src/integrity/`
- Existing code modified: `backend/src/models/session.ts`, `backend/src/api/routes/sessions.ts`, `backend/src/lib/types.ts`

---

## Phase 1: Setup

**Purpose**: Create the integrity layer module structure and shared infrastructure

- [x] T001 Create directory structure: `backend/src/integrity/`, `backend/tests/unit/integrity/`, `backend/tests/integration/integrity/`
- [x] T002 Define integrity-specific TypeScript types in `backend/src/integrity/types.ts`: IntegrityEventType enum (SESSION_CREATED, SESSION_ACTIVATED, SESSION_CLOSED, TRANSITION_REJECTED), LedgerEntry interface, MetadataSnapshot interface, SessionBoundary interfaces (ContextDescriptor, EnvironmentalConstraints), HashChainValidationResult interface, and frameworkStatus() utility function mapping IAMMAI Sandbox states to OPEN/CLOSED per Framework Decision 2
- [x] T003 Extend shared types in `backend/src/lib/types.ts`: add ContextDescriptor and EnvironmentalConstraints to CreateSessionRequest, extend Session interface with contextDescriptor and environmentalConstraints fields

---

## Phase 2: Foundational (Blocking Prerequisites)

**Purpose**: Database migration and hash utilities that ALL user stories depend on

**CRITICAL**: No user story work can begin until this phase is complete

- [x] T004 Create database migration `backend/migrations/002_integrity_ledger.sql`: (1) Add `context_descriptor JSONB NOT NULL DEFAULT '{"topic": "unspecified"}'::jsonb` and `environmental_constraints JSONB NOT NULL DEFAULT '{"max_participants": 10}'::jsonb` columns to `sessions` table, (2) Create `integrity_event_type` enum (SESSION_CREATED, SESSION_ACTIVATED, SESSION_CLOSED, TRANSITION_REJECTED), (3) Create `integrity_ledger` table with columns: id (UUID PK), sequence_number (BIGSERIAL UNIQUE), session_id (UUID FK to sessions), event_type (integrity_event_type), timestamp (TIMESTAMPTZ DEFAULT NOW()), from_state (session_state NULL), to_state (VARCHAR(10) NOT NULL), metadata_snapshot (JSONB NOT NULL), previous_hash (VARCHAR(64) NULL), entry_hash (VARCHAR(64) NOT NULL UNIQUE), (4) Add BEFORE UPDATE trigger on integrity_ledger that raises exception 'Ledger entries cannot be updated', (5) Add BEFORE DELETE trigger on integrity_ledger that raises exception 'Ledger entries cannot be deleted', (6) Add indexes on session_id, sequence_number, entry_hash, (7) Record migration in migrations table
- [x] T005 Implement hash chain utilities in `backend/src/integrity/hash.ts`: (1) `computeEntryHash(previousHash: string | null, sequenceNumber: number, sessionId: string, eventType: string, timestamp: string, metadataSnapshot: object): string` — concatenates fields with `|` separator, computes SHA-256, returns lowercase 64-char hex string, (2) `validateHashChain(entries: LedgerEntry[]): HashChainValidationResult` — iterates entries in sequence order, recomputes each hash, returns validation result with first broken entry if any
- [x] T006 [P] Write unit tests for hash chain utilities in `backend/tests/unit/integrity/hash.test.ts`: test deterministic hash output, test genesis entry (null previous_hash), test chain linkage across multiple entries, test tamper detection (modify one entry and verify chain breaks), test empty chain validation

**Checkpoint**: Database schema ready, hash utilities available — user story implementation can begin

---

## Phase 3: User Story 1 - Forward-Only Session State Machine (Priority: P1) MVP

**Goal**: State transitions are forward-only (CREATED → ACTIVE → ENDED), each transition is observed by the integrity layer, and rejected transitions are recorded

**Independent Test**: Create a session, transition through all states, verify backward transitions are rejected, verify state data is additive (metadata from prior states preserved)

### Tests for User Story 1

- [x] T007 [P] [US1] Write unit tests for state observer in `backend/tests/unit/integrity/state-observer.test.ts`: test observeTransition records SESSION_CREATED/SESSION_ACTIVATED/SESSION_CLOSED events with correct metadata snapshot, test TRANSITION_REJECTED recorded for invalid transitions (ENDED→ACTIVE, ACTIVE→CREATED, ENDED→CREATED), test metadata snapshot preserves all prior state data (additive), test frameworkStatus mapping (CREATED/ACTIVE→OPEN, ENDED→CLOSED)
- [x] T008 [P] [US1] Write integration test for full session lifecycle with ledger verification in `backend/tests/integration/integrity/lifecycle.test.ts`: create session → start → end, verify 3 ledger entries exist in order (SESSION_CREATED, SESSION_ACTIVATED, SESSION_CLOSED), verify hash chain is valid, attempt backward transition → verify TRANSITION_REJECTED entry appended, verify all entries contain metadata snapshots with no message content

### Implementation for User Story 1

- [x] T009 [US1] Implement state observer in `backend/src/integrity/state-observer.ts`: (1) `observeTransition(client: PoolClient, session: Session, fromState: SessionState | null, toState: SessionState, eventType: IntegrityEventType): Promise<LedgerEntry>` — builds metadata snapshot from session, calls ledger.appendEntry within the provided transaction client, (2) `buildMetadataSnapshot(session: Session): MetadataSnapshot` — extracts metadata-only fields (session_id, name, state, framework_status, admin_id, token_count, user_count, timestamps, context_descriptor, environmental_constraints), never includes message content
- [x] T010 [US1] Implement append-only ledger service in `backend/src/integrity/ledger.ts`: (1) `appendEntry(client: PoolClient, sessionId: string, eventType: IntegrityEventType, fromState: SessionState | null, toState: string, metadataSnapshot: MetadataSnapshot): Promise<LedgerEntry>` — fetches the last entry's hash (SELECT entry_hash FROM integrity_ledger ORDER BY sequence_number DESC LIMIT 1 FOR UPDATE), computes new entry hash using hash.ts, INSERTs new row, returns the created entry, (2) `getEntriesBySession(sessionId: string): Promise<LedgerEntry[]>` — returns all entries for a session ordered by sequence_number, (3) `validateChain(): Promise<HashChainValidationResult>` — fetches all entries ordered by sequence_number and delegates to hash.validateHashChain
- [x] T011 [US1] Integrate state observer into session route handlers in `backend/src/api/routes/sessions.ts`: (1) In POST /admin/sessions (create): after sessionModel.create, call observeTransition with SESSION_CREATED event within a transaction, (2) In POST /admin/sessions/:id/start: modify transitionState to accept a transaction client, call observeTransition with SESSION_ACTIVATED within the same transaction, (3) In POST /admin/sessions/:id/end: same pattern with SESSION_CLOSED, (4) For rejected transitions: before returning the error response, call observeTransition with TRANSITION_REJECTED event (this can be a separate non-transactional append since the session state didn't change)
- [x] T012 [US1] Modify `backend/src/models/session.ts` transitionState to support external transaction client: add an optional `client` parameter so the session route can pass in a shared transaction client, allowing the state UPDATE and ledger INSERT to be atomic. If no client is passed, use the existing internal transaction (backward compatible)

**Checkpoint**: Session state transitions are observed, ledger entries are appended atomically, backward transitions are rejected and recorded

---

## Phase 4: User Story 2 - Append-Only Integrity Ledger (Priority: P1)

**Goal**: Ledger is provably append-only — no delete, no update, hash chain validates integrity, tampering is detectable

**Independent Test**: Write ledger entries, verify hash chain integrity, attempt delete/update via application and verify rejection, verify hash chain detects tampered entries

### Tests for User Story 2

- [x] T013 [P] [US2] Write unit tests for ledger service in `backend/tests/unit/integrity/ledger.test.ts`: test appendEntry creates sequential entries with correct hash chain, test getEntriesBySession returns entries in order, test validateChain returns valid for intact chain, test validateChain detects broken chain (mock tampered entry)
- [x] T014 [P] [US2] Write integration test for ledger immutability in `backend/tests/integration/integrity/ledger-immutability.test.ts`: test direct SQL UPDATE on integrity_ledger raises exception (trigger enforcement), test direct SQL DELETE on integrity_ledger raises exception (trigger enforcement), test application-level ledger service exposes no update/delete methods (TypeScript interface check)
- [x] T015 [P] [US2] Write privacy test in `backend/tests/privacy/ledger-privacy.test.ts`: create a session, join with a user, send messages via kernel, end session, inspect ALL ledger entries and verify none contain message content, token values, presence hashes, or any ephemeral data — only session metadata (session_id, name, state, admin_id, counts, timestamps, context_descriptor, environmental_constraints)

### Implementation for User Story 2

- [x] T016 [US2] Add hash chain validation endpoint (internal/admin) in `backend/src/api/routes/sessions.ts`: add GET `/admin/integrity/validate` route (requires admin auth) that calls ledger.validateChain() and returns the HashChainValidationResult — reports total entries, validated count, and first broken entry if any
- [x] T017 [US2] Add ledger query endpoint (internal/admin) in `backend/src/api/routes/sessions.ts`: add GET `/admin/sessions/:id/ledger` route (requires admin auth) that calls ledger.getEntriesBySession(id) and returns the ledger entries for that session — used for debugging and audit

**Checkpoint**: Ledger is provably immutable at database level, hash chain validates integrity, privacy test confirms no content leakage

---

## Phase 5: User Story 3 - Event Boundary Enforcement (Priority: P2)

**Goal**: Sessions require boundary declarations (context_descriptor, environmental_constraints) at creation, and no truth finalization may reference an OPEN session

**Independent Test**: Create a session with and without boundary declarations, verify rejection without them, verify finalization guard rejects OPEN sessions and permits CLOSED sessions

### Tests for User Story 3

- [x] T018 [P] [US3] Write unit tests for boundary validation in `backend/tests/unit/integrity/boundary.test.ts`: test validateContextDescriptor accepts valid {topic: "string"} and {topic: "string", purpose: "string"}, rejects missing topic, empty topic, topic > 500 chars; test validateEnvironmentalConstraints accepts valid {max_participants: 10}, rejects missing max_participants, zero/negative max_participants, max_participants > 1000, negative time_limit_minutes; test isFinalizationPermitted returns false for CREATED/ACTIVE sessions and true for ENDED sessions

### Implementation for User Story 3

- [x] T019 [US3] Implement boundary validation in `backend/src/integrity/boundary.ts`: (1) `validateContextDescriptor(input: unknown): Result<ContextDescriptor>` — validates topic (required, non-empty, max 500 chars) and purpose (optional, max 1000 chars), returns typed Result, (2) `validateEnvironmentalConstraints(input: unknown): Result<EnvironmentalConstraints>` — validates max_participants (required, positive integer, 1-1000), time_limit_minutes (optional, positive integer, 1-1440), ai_model (optional, non-empty string), returns typed Result, (3) `isFinalizationPermitted(session: Session): boolean` — returns true only if session.state === 'ENDED' (framework_status === CLOSED per Decision 2)
- [x] T020 [US3] Integrate boundary validation into session creation route in `backend/src/api/routes/sessions.ts`: modify POST /admin/sessions to (1) require context_descriptor and environmental_constraints in the request body, (2) validate both using boundary.ts functions, (3) return 400 with specific error if validation fails, (4) pass validated boundary data to sessionModel.create, (5) include boundary data in the SESSION_CREATED ledger entry metadata snapshot
- [x] T021 [US3] Modify `backend/src/models/session.ts` create function to accept and store context_descriptor and environmental_constraints: update the INSERT query to include the two new JSONB columns, update rowToSession to include the new fields
- [x] T022 [US3] Export `isFinalizationPermitted` as a guard function from `backend/src/integrity/boundary.ts` for use by future features (006-verification-witness): this function will be called before any witness emission or verification finalization to ensure the session is CLOSED. For now, add a comment documenting its intended use and ensure it's properly exported and tested

**Checkpoint**: Sessions require boundary declarations, boundary data flows into the ledger, finalization guard is available for downstream features

---

## Phase 6: Polish & Cross-Cutting Concerns

**Purpose**: Final validation, documentation, and cleanup

- [x] T023 Run all tests (unit, integration, privacy) and verify 100% pass rate: `cd backend && pnpm vitest run`
- [x] T024 Verify the quickstart.md scenario works end-to-end: create a session with boundary declarations, start it, end it, inspect ledger entries, validate hash chain
- [x] T025 Verify existing chat engine is unaffected: claim a token, join a session, send messages via WebSocket, end session — all existing behavior works unchanged
- [x] T026 Review all ledger entries from the end-to-end test and confirm zero message content, token values, or presence hashes (manual privacy audit)

---

## Dependencies & Execution Order

### Phase Dependencies

- **Setup (Phase 1)**: No dependencies — can start immediately
- **Foundational (Phase 2)**: Depends on Setup (T001-T003) — types must exist before migration and hash utils
- **US1 (Phase 3)**: Depends on Foundational (T004-T006) — needs DB schema and hash utils
- **US2 (Phase 4)**: Depends on US1 (T009-T012) — needs ledger service and state observer to exist before testing immutability and adding admin endpoints
- **US3 (Phase 5)**: Depends on Foundational (T004) — needs the session boundary columns. Can run in parallel with US1 after Foundational completes, but integration (T020) needs US1's state observer
- **Polish (Phase 6)**: Depends on all user stories complete

### User Story Dependencies

- **User Story 1 (P1)**: Depends only on Foundational (Phase 2). No dependencies on other stories. This is the MVP.
- **User Story 2 (P1)**: Depends on US1's ledger service implementation (T010). Adds immutability verification and admin endpoints on top.
- **User Story 3 (P2)**: Boundary validation (T019) can start after Foundational. Route integration (T020) depends on US1's observer pattern being in place.

### Within Each User Story

- Tests written first (TDD approach per constitution)
- Types/utilities before services
- Services before route integration
- Route integration is the final step per story

### Parallel Opportunities

- T006 (hash tests) can run in parallel with T004 (migration) — different files
- T007 and T008 (US1 tests) can run in parallel — different test files
- T013, T014, T015 (US2 tests) can all run in parallel — different test files
- T018 (US3 tests) can run in parallel with US2 implementation if US1 is complete
- US3 boundary validation (T019) can start in parallel with US2 if US1's core is done

---

## Parallel Example: User Story 1

```bash
# Write tests in parallel (different files):
Task: "Unit tests for state observer in backend/tests/unit/integrity/state-observer.test.ts"
Task: "Integration test for lifecycle in backend/tests/integration/integrity/lifecycle.test.ts"

# After tests, implement in dependency order:
Task: "State observer in backend/src/integrity/state-observer.ts"
Task: "Ledger service in backend/src/integrity/ledger.ts"
# Then integrate:
Task: "Integrate observer into session routes"
Task: "Modify session model for shared transaction"
```

---

## Implementation Strategy

### MVP First (User Story 1 Only)

1. Complete Phase 1: Setup (T001-T003)
2. Complete Phase 2: Foundational (T004-T006)
3. Complete Phase 3: User Story 1 (T007-T012)
4. **STOP and VALIDATE**: Create a session, start, end — verify 3 ledger entries with valid hash chain
5. This gives: forward-only state machine + append-only ledger recording — the minimum structural foundation

### Incremental Delivery

1. Setup + Foundational → Types, migration, hash utils ready
2. Add US1 → State transitions observed and recorded with hash chain (MVP!)
3. Add US2 → Ledger immutability proven, admin inspection endpoints, privacy verified
4. Add US3 → Boundary declarations required, finalization guard available
5. Polish → End-to-end validation, privacy audit

---

## Notes

- [P] tasks = different files, no dependencies
- [Story] label maps task to specific user story for traceability
- Constitution Principle II mandates tests — they are included in each story phase
- Constitution Principle V governs the privacy test (T015) — ledger must never contain content
- All ledger operations use the existing `transaction()` infrastructure from `backend/src/lib/db.ts`
- The state observer pattern is designed for extensibility — features 006-009 will add new event types
- Commit after each phase for clean git history
