# Implementation Plan: Structural Foundation (Integrity Layer)

**Branch**: `005-structural-foundation` | **Date**: 2026-02-14 | **Spec**: [spec.md](./spec.md)
**Input**: Feature specification from `/specs/005-structural-foundation/spec.md`

## Summary

Build the Integrity Layer's structural foundation alongside the existing IAMMAI Sandbox chat engine. This adds a forward-only session state machine observer, an append-only hash-chained ledger for session lifecycle metadata, and event boundary enforcement — implementing MM-MODEL protocols I.02 (Event Boundary), I.03 (Continuity Non-Regression), and I.04 (Ledger Non-Erasure). The integrity layer sits beside the chat engine, recording metadata without touching ephemeral content.

## Technical Context

**Language/Version**: TypeScript 5.3+ on Node.js 20 LTS
**Primary Dependencies**: Express 4.18, pg 8.11 (PostgreSQL client), uuid 9.0 (existing), Node.js crypto (SHA-256, built-in)
**Storage**: PostgreSQL (existing database — new `integrity_ledger` table + `session_boundaries` columns on sessions table)
**Testing**: Vitest (existing test runner)
**Target Platform**: Linux server (same as existing backend)
**Project Type**: Web application (backend extension)
**Performance Goals**: Ledger append < 10ms overhead per state transition; hash chain validation < 100ms for 10,000 entries
**Constraints**: Zero impact on existing chat engine latency; atomic state transition + ledger write; no message content in ledger
**Scale/Scope**: Same scale as existing IAMMAI Sandbox backend (hundreds of sessions, not millions); ledger grows linearly with session count × 3 entries per session

## Constitution Check

*GATE: Must pass before Phase 0 research. Re-check after Phase 1 design.*

| Principle | Status | Notes |
|-----------|--------|-------|
| I. Code Quality First | PASS | New modules under `backend/src/integrity/` follow single responsibility; strict TypeScript; no `any` types |
| II. Testing Standards | PASS | Unit tests for state machine and ledger; integration tests for atomic transitions; privacy tests to verify no content in ledger |
| III. User Experience Consistency | PASS | No user-facing UI changes; integrity layer is backend-only |
| IV. Performance Requirements | PASS | Ledger append is a single INSERT within the existing transaction; no new network hops |
| V. Privacy & Ephemerality Enforcement | PASS | Ledger records ONLY metadata (session_id, timestamps, participant_count). Never message content, tokens, or presence hashes. Framework Decision 10 enforced. |

**Technical Decision Framework check**:
1. Privacy Preservation: Ledger records only metadata — privacy strengthened by explicit boundary
2. User Trust: Integrity records prove sessions existed with proper boundaries
3. Simplicity: Single PostgreSQL table, SHA-256 hash chain, no external dependencies
4. Testability: Hash chain is deterministically verifiable; state machine has finite states
5. Performance: Single INSERT per transition within existing DB transaction
6. Maintainability: Isolated `integrity/` module with clear interfaces

No gate violations. No complexity justifications needed.

## Project Structure

### Documentation (this feature)

```text
specs/005-structural-foundation/
├── plan.md              # This file
├── research.md          # Phase 0 output
├── spec.md              # Feature specification
├── data-model.md        # Phase 1 output
├── quickstart.md        # Phase 1 output
├── contracts/           # Phase 1 output
│   └── integrity-api.yaml
├── checklists/
│   └── requirements.md
└── tasks.md             # Phase 2 output (created by /speckit.tasks)
```

### Source Code (repository root)

```text
backend/
├── src/
│   ├── integrity/                    # NEW — Integrity Layer module
│   │   ├── types.ts                  # Integrity-specific types (IntegrityEvent, LedgerEntry, SessionBoundary)
│   │   ├── ledger.ts                 # Append-only ledger service (append, validate hash chain)
│   │   ├── state-observer.ts         # State transition observer (hooks into session transitions)
│   │   ├── boundary.ts               # Event boundary enforcement (context_descriptor, constraints validation)
│   │   └── hash.ts                   # Hash chain utilities (SHA-256 chain computation and verification)
│   ├── models/
│   │   └── session.ts                # MODIFIED — add context_descriptor, environmental_constraints fields
│   ├── api/
│   │   └── routes/
│   │       └── sessions.ts           # MODIFIED — integrate integrity observer on state transitions
│   └── lib/
│       └── types.ts                  # MODIFIED — add integrity types, extend CreateSessionRequest
├── migrations/
│   └── 002_integrity_ledger.sql      # NEW — ledger table + session boundary columns
└── tests/
    ├── unit/
    │   ├── integrity/
    │   │   ├── ledger.test.ts        # Ledger append, hash chain, rejection tests
    │   │   ├── state-observer.test.ts # Forward-only transition tests
    │   │   ├── boundary.test.ts      # Boundary validation tests
    │   │   └── hash.test.ts          # Hash chain computation tests
    │   └── ...
    ├── integration/
    │   └── integrity/
    │       └── lifecycle.test.ts     # Full session lifecycle with ledger verification
    └── privacy/
        └── ledger-privacy.test.ts    # Verify no content in ledger entries
```

**Structure Decision**: New `integrity/` module within existing `backend/src/` follows the architectural principle that the integrity layer sits beside the chat engine. No existing files are restructured — only extended at integration points (session routes, session model, types).
