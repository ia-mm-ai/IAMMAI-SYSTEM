# Data Model: Structural Foundation (Integrity Layer)

**Feature**: 005-structural-foundation
**Date**: 2026-02-14

## Entities

### IntegrityLedgerEntry

The core append-only ledger record. Each entry is immutable and hash-chained to the previous entry.

| Field | Type | Constraints | Description |
|-------|------|-------------|-------------|
| id | UUID v4 | PRIMARY KEY, auto-generated | Unique entry identifier |
| sequence_number | BIGINT | NOT NULL, auto-increment, UNIQUE | Monotonically increasing sequence for ordering |
| session_id | UUID | NOT NULL, REFERENCES sessions(id) | The session this event relates to |
| event_type | ENUM | NOT NULL | One of: SESSION_CREATED, SESSION_ACTIVATED, SESSION_CLOSED, TRANSITION_REJECTED |
| timestamp | TIMESTAMP WITH TIME ZONE | NOT NULL, DEFAULT NOW() | When this event occurred (ISO 8601 UTC) |
| from_state | VARCHAR(10) | NULL | Previous session state (NULL for SESSION_CREATED) |
| to_state | VARCHAR(10) | NOT NULL | Target session state |
| metadata_snapshot | JSONB | NOT NULL | Session metadata at time of event (see below) |
| previous_hash | VARCHAR(64) | NULL | SHA-256 hash of the previous entry (NULL for genesis entry) |
| entry_hash | VARCHAR(64) | NOT NULL, UNIQUE | SHA-256 hash of this entry (computed from: previous_hash + sequence_number + session_id + event_type + timestamp + metadata_snapshot) |

**Immutability enforcement**:
- No UPDATE or DELETE operations exposed in the application model
- PostgreSQL triggers prevent UPDATE and DELETE at the database level
- Hash chain provides detective control for any direct database manipulation

### metadata_snapshot Structure

The JSONB metadata captured with each ledger entry. Contains ONLY session metadata, never message content.

```json
{
  "session_id": "uuid",
  "session_name": "string",
  "state": "CREATED | ACTIVE | ENDED",
  "framework_status": "OPEN | CLOSED",
  "admin_id": "uuid",
  "token_count": 0,
  "user_count": 0,
  "created_at": "ISO 8601 UTC",
  "started_at": "ISO 8601 UTC | null",
  "ended_at": "ISO 8601 UTC | null",
  "context_descriptor": {
    "topic": "string",
    "purpose": "string | undefined"
  },
  "environmental_constraints": {
    "max_participants": "number",
    "time_limit_minutes": "number | undefined",
    "ai_model": "string | undefined"
  }
}
```

**Privacy boundary**: No fields for message content, token values, presence hashes, or any ephemeral data.

### SessionBoundary (extension to existing Session)

New columns added to the existing `sessions` table via migration.

| Field | Type | Constraints | Description |
|-------|------|-------------|-------------|
| context_descriptor | JSONB | NOT NULL | Session context: `{ topic: string, purpose?: string }` |
| environmental_constraints | JSONB | NOT NULL | Session constraints: `{ max_participants: number, time_limit_minutes?: number, ai_model?: string }` |

**Validation rules** (application-level):
- `context_descriptor.topic`: Required, non-empty string, max 500 chars
- `context_descriptor.purpose`: Optional string, max 1000 chars
- `environmental_constraints.max_participants`: Required, positive integer, min 1, max 1000
- `environmental_constraints.time_limit_minutes`: Optional, positive integer, min 1, max 1440 (24 hours)
- `environmental_constraints.ai_model`: Optional, non-empty string

### IntegrityEventType (Enum)

| Value | When Recorded | Payload Notes |
|-------|---------------|---------------|
| SESSION_CREATED | Session enters CREATED state | from_state = NULL, to_state = CREATED |
| SESSION_ACTIVATED | Session transitions CREATED → ACTIVE | from_state = CREATED, to_state = ACTIVE |
| SESSION_CLOSED | Session transitions ACTIVE → ENDED | from_state = ACTIVE, to_state = ENDED |
| TRANSITION_REJECTED | Invalid transition attempted | from_state = current state, to_state = attempted state |

## Relationships

```
sessions (existing) ──1:N──> integrity_ledger (new)
  A session has 0-N ledger entries (typically 3: created, activated, closed)

integrity_ledger ──chain──> integrity_ledger
  Each entry references the previous entry via previous_hash (hash chain)
```

## State Transitions

### Session State Machine (existing, observed by integrity layer)

```
CREATED ──start──> ACTIVE ──end──> ENDED
   │                  │               │
   │                  │               └── (terminal, no transitions out)
   │                  │
   │                  └── ✗ back to CREATED (REJECTED)
   │
   └── ✗ direct to ENDED (REJECTED)
```

### Framework Status Mapping (computed, not stored)

```
IAMMAI Sandbox State → Framework Status
────────────────       ────────────────
CREATED              → OPEN
ACTIVE               → OPEN
ENDED                → CLOSED
```

### Ledger Entry Lifecycle

```
Genesis entry (first ever):
  previous_hash = NULL
  entry_hash = SHA-256(NULL + sequence + session_id + event_type + timestamp + metadata)

Subsequent entries:
  previous_hash = prior entry's entry_hash
  entry_hash = SHA-256(previous_hash + sequence + session_id + event_type + timestamp + metadata)
```

## Hash Chain Algorithm

```
Input: previous_hash (or empty string if genesis), sequence_number, session_id, event_type, timestamp, metadata_snapshot
Process:
  1. Serialize: concatenate(previous_hash || "", "|", sequence_number, "|", session_id, "|", event_type, "|", timestamp_iso, "|", JSON.stringify(metadata_snapshot))
  2. Hash: SHA-256(serialized_string)
  3. Output: lowercase hex string (64 chars)
```

## Migration: 002_integrity_ledger.sql

### New table: integrity_ledger

- Append-only (enforced by triggers)
- Hash-chained (application-computed, DB-stored)
- Indexed on session_id and sequence_number

### Modified table: sessions

- Add `context_descriptor JSONB` (NOT NULL with DEFAULT for migration)
- Add `environmental_constraints JSONB` (NOT NULL with DEFAULT for migration)

### Triggers

- `BEFORE UPDATE ON integrity_ledger`: RAISE EXCEPTION (no updates allowed)
- `BEFORE DELETE ON integrity_ledger`: RAISE EXCEPTION (no deletes allowed)
