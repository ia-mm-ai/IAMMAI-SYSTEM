# Research: Structural Foundation (Integrity Layer)

**Feature**: 005-structural-foundation
**Date**: 2026-02-14

## Research Topics

### 1. Hash Chain Implementation in PostgreSQL

**Decision**: SHA-256 hash chain using Node.js `crypto` module, computed at application level, stored in PostgreSQL `VARCHAR(64)` column.

**Rationale**:
- SHA-256 is already used in the codebase for token hashing (`backend/src/services/token.ts`)
- Application-level hash computation keeps the database layer simple (no pgcrypto dependency needed)
- `VARCHAR(64)` matches the existing `token_hash` column pattern (64 hex chars for SHA-256)
- Hash chain: each entry's hash = SHA-256(previous_hash + entry_data), producing a tamper-evident chain

**Alternatives considered**:
- PostgreSQL `pgcrypto` extension: Adds database dependency, harder to test; rejected for simplicity
- HMAC-SHA-256 with a secret key: Unnecessary — the threat model is tamper detection, not authentication; a secret key adds key management complexity without benefit
- SHA-512: Overkill for this use case; SHA-256 provides 256-bit collision resistance which is more than sufficient
- Merkle tree: More complex, better for partial verification; rejected because linear chain is simpler and ledger is always verified sequentially

### 2. Append-Only Enforcement Strategy

**Decision**: Enforce append-only at three levels: (1) application-level API with no delete/update methods, (2) PostgreSQL row-level security or triggers to prevent UPDATE/DELETE, (3) hash-chain integrity validation as a detective control.

**Rationale**:
- Defense in depth: even if application code has a bug, the database prevents mutation
- PostgreSQL `BEFORE DELETE` and `BEFORE UPDATE` triggers on the ledger table raise exceptions, making mutation impossible even via direct SQL
- Hash chain validation is the final detective control — if somehow a row is mutated (e.g., by a DBA), the chain breaks and the system detects it
- The application-level model simply never exposes delete/update functions, following the existing codebase pattern where models only expose the operations they support

**Alternatives considered**:
- Application-only enforcement (no DB triggers): Single point of failure; a direct SQL update bypasses the application
- Blockchain/distributed ledger: Massive overkill for a single-server PoC; adds infrastructure complexity
- Write-ahead log parsing: Too low-level, fragile, and PostgreSQL-specific

### 3. Atomic State Transition + Ledger Entry

**Decision**: Use the existing PostgreSQL transaction infrastructure (`backend/src/lib/db.ts` `transaction()`) to wrap state transition UPDATE and ledger INSERT in a single transaction.

**Rationale**:
- The existing `transitionState()` in `models/session.ts` already uses `transaction()` with row-level locking (`FOR UPDATE`)
- Extending this transaction to include the ledger INSERT ensures atomicity — either both the state change and the ledger entry succeed, or neither does
- No new infrastructure needed; this is a straightforward extension of existing patterns

**Alternatives considered**:
- Event sourcing (state derived from ledger): More architecturally pure but requires rewriting the session model; rejected for this phase — can be considered for future evolution
- Separate async ledger write (eventual consistency): Risks missed entries if the process crashes between state change and ledger write; rejected for integrity guarantees

### 4. Session Boundary Extension (context_descriptor, environmental_constraints)

**Decision**: Add `context_descriptor` (JSONB) and `environmental_constraints` (JSONB) columns to the existing `sessions` table via a new migration. Validate structure at the application level.

**Rationale**:
- The existing `sessions` table already holds session metadata; adding two JSONB columns keeps the data model cohesive
- JSONB in PostgreSQL supports efficient querying and indexing if needed later
- Application-level validation (in `boundary.ts`) checks required fields: `context_descriptor` must have `topic` (string); `environmental_constraints` must have `max_participants` (positive integer)
- Optional fields: `context_descriptor.purpose`, `environmental_constraints.time_limit_minutes`, `environmental_constraints.ai_model`
- This aligns with Framework Decision 1's type specifications

**Alternatives considered**:
- Separate `session_boundaries` table: Adds a join for every session query; rejected for simplicity
- Store boundaries only in the ledger: Makes querying current session boundaries expensive; rejected
- Strict JSON Schema validation in PostgreSQL: Requires `pg_jsonschema` extension; application-level validation is simpler and more testable

### 5. Framework Status Mapping (OPEN/CLOSED)

**Decision**: Implement as a computed property in the integrity layer types, not as a stored column. `frameworkStatus(session) => session.state === 'ENDED' ? 'CLOSED' : 'OPEN'`.

**Rationale**:
- Per Framework Decision 2, CREATED and ACTIVE both map to OPEN; ENDED maps to CLOSED
- This is a pure function of the existing `state` column — no need to store redundant data
- The mapping lives in `integrity/types.ts` as a utility function
- Existing IAMMAI Sandbox code continues to use CREATED/ACTIVE/ENDED; only the integrity layer uses OPEN/CLOSED terminology

**Alternatives considered**:
- Add a `framework_status` column to sessions: Redundant data that could get out of sync; rejected
- Rename IAMMAI Sandbox states to match MM-MODEL: Would break existing frontend and API contracts; rejected

### 6. Integrity Ledger Entry Event Types

**Decision**: Define four event types for the initial ledger: `SESSION_CREATED`, `SESSION_ACTIVATED`, `SESSION_CLOSED`, `TRANSITION_REJECTED`.

**Rationale**:
- Maps directly to the three valid state transitions plus the rejection case
- `TRANSITION_REJECTED` records suppression events (FR-010) — when an invalid transition is attempted
- Each event type carries a consistent payload: session_id, timestamp, from_state, to_state (for transitions), and a metadata snapshot
- The event type enum is extensible — future features (006-009) can add `VERIFICATION_PASSED`, `WITNESS_EMITTED`, etc.

**Alternatives considered**:
- Generic event type with freeform data: Harder to query and validate; rejected
- Separate tables per event type: Over-normalized for the PoC scale; rejected

### 7. Ledger Entry Metadata Snapshot

**Decision**: Each ledger entry includes a JSON metadata snapshot of the session state at the time of the event. This snapshot contains only: session_id, session_name, state, admin_id, token_count, user_count, context_descriptor, environmental_constraints, and relevant timestamps.

**Rationale**:
- The snapshot makes each ledger entry self-describing (aligns with I.10 Future Interpretability)
- A future reader can reconstruct session state at any point without querying external tables
- Metadata-only — no message content, no token hashes, no presence hashes (Framework Decision 10)
- Stored as JSONB for flexibility

**Alternatives considered**:
- Reference-only (just session_id, look up current state): Loses historical state; if session data is modified after the fact, the ledger becomes inaccurate
- Full event sourcing: Too complex for Phase 1; this snapshot approach gives most of the benefit

### 8. Integration Pattern with Existing Session Routes

**Decision**: Add an integrity observer function that is called within the existing session route handlers after successful state transitions. The observer appends the ledger entry within the same database transaction.

**Rationale**:
- Minimal changes to existing code — add a single function call in each route handler
- The integrity observer is a pure service function, not middleware — it's called explicitly, making the flow clear and testable
- The observer takes the transaction client as a parameter, ensuring atomicity
- For rejected transitions, the observer is called in the error path before the error response is sent

**Alternatives considered**:
- Express middleware: Can't easily participate in the database transaction; rejected
- PostgreSQL triggers on session state changes: Would work for valid transitions but can't capture application-level context (who attempted the transition, why it was rejected); rejected for this use case
- Event emitter pattern: Async and non-transactional; rejected for atomicity requirements
