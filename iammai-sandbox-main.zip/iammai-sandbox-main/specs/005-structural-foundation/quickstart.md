# Quickstart: Structural Foundation (Integrity Layer)

**Feature**: 005-structural-foundation
**Prerequisites**: PostgreSQL running, existing IAMMAI Sandbox backend set up

## What This Feature Adds

An integrity layer that sits beside the existing chat engine and records session lifecycle metadata in an append-only, hash-chained ledger. The chat engine remains unchanged — messages are still ephemeral. The integrity layer observes state transitions and enforces event boundaries.

## Setup

### 1. Run the migration

```bash
cd backend
pnpm run migrate
# This applies 002_integrity_ledger.sql:
# - Adds integrity_ledger table (append-only, with triggers)
# - Adds context_descriptor and environmental_constraints columns to sessions
```

### 2. Verify the migration

```bash
# Connect to your database and check:
psql $DATABASE_URL -c "SELECT column_name FROM information_schema.columns WHERE table_name = 'integrity_ledger';"
psql $DATABASE_URL -c "SELECT column_name FROM information_schema.columns WHERE table_name = 'sessions' AND column_name IN ('context_descriptor', 'environmental_constraints');"
```

## Usage

### Creating a session (now requires boundary declarations)

```bash
# Before (001-ephemeral-kernel):
curl -X POST http://localhost:3001/api/v1/admin/sessions \
  -H "Authorization: Bearer $TOKEN" \
  -H "Content-Type: application/json" \
  -d '{"name": "My Session"}'

# After (005-structural-foundation):
curl -X POST http://localhost:3001/api/v1/admin/sessions \
  -H "Authorization: Bearer $TOKEN" \
  -H "Content-Type: application/json" \
  -d '{
    "name": "My Session",
    "context_descriptor": {
      "topic": "Team standup discussion",
      "purpose": "Daily sync on project progress"
    },
    "environmental_constraints": {
      "max_participants": 10,
      "time_limit_minutes": 30,
      "ai_model": "gpt-4o-mini"
    }
  }'
```

### Starting and ending sessions (unchanged API, integrity recorded automatically)

```bash
# Start session — ledger records SESSION_ACTIVATED
curl -X POST http://localhost:3001/api/v1/admin/sessions/$SESSION_ID/start \
  -H "Authorization: Bearer $TOKEN"

# End session — ledger records SESSION_CLOSED
curl -X POST http://localhost:3001/api/v1/admin/sessions/$SESSION_ID/end \
  -H "Authorization: Bearer $TOKEN"
```

### What gets recorded in the ledger

After a full session lifecycle (create → start → end), the ledger contains exactly 3 entries:

| # | Event Type | From State | To State | Hash Chain |
|---|-----------|------------|----------|------------|
| 1 | SESSION_CREATED | (none) | CREATED | genesis hash |
| 2 | SESSION_ACTIVATED | CREATED | ACTIVE | links to #1 |
| 3 | SESSION_CLOSED | ACTIVE | ENDED | links to #2 |

Each entry includes a metadata snapshot of the session at that moment. **No message content is ever recorded.**

### Invalid transitions are recorded too

```bash
# Try to start an already-active session — gets rejected and logged
curl -X POST http://localhost:3001/api/v1/admin/sessions/$SESSION_ID/start \
  -H "Authorization: Bearer $TOKEN"
# Response: 400 Bad Request
# Ledger: TRANSITION_REJECTED entry appended
```

## Running Tests

```bash
cd backend

# Unit tests for integrity layer
pnpm vitest run tests/unit/integrity/

# Integration tests (requires PostgreSQL)
pnpm vitest run tests/integration/integrity/

# Privacy tests (verify no content in ledger)
pnpm vitest run tests/privacy/ledger-privacy.test.ts

# All tests
pnpm test
```

## Architecture Overview

```
Existing Chat Engine (unchanged)     Integrity Layer (new)
┌──────────────────────────┐         ┌──────────────────────────┐
│ Express routes           │────────>│ State Observer            │
│ WebSocket hub            │         │   observeTransition()     │
│ Kernel manager           │         │                           │
│ AI service               │         │ Boundary Validator        │
│                          │         │   validateBoundary()      │
│ Sessions table ─────────────────>  │                           │
│ (state, timestamps)      │         │ Ledger Service            │
│                          │         │   appendEntry()           │
│ Tokens table             │         │   validateChain()         │
│                          │         │                           │
│ In-memory kernels        │         │ integrity_ledger table    │
│ (ephemeral, destroyed)   │         │ (append-only, permanent)  │
└──────────────────────────┘         └──────────────────────────┘
         EPHEMERAL                           PERMANENT
     (content layer)                    (integrity layer)
```

## Key Constraints

- **Privacy**: The ledger NEVER contains message content, user input, or AI responses
- **Immutability**: Ledger entries cannot be updated or deleted (enforced by DB triggers)
- **Atomicity**: State transitions and ledger entries are in the same DB transaction
- **Forward-only**: Sessions can only move forward (CREATED → ACTIVE → ENDED)
- **Hash chain**: Every entry is cryptographically linked to the previous one
