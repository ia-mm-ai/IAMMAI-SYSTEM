# Implementation Plan: Dark Futuristic UI Redesign

**Branch**: `002-dark-futuristic-ui` | **Date**: 2026-01-24 | **Spec**: [spec.md](./spec.md)
**Input**: Feature specification from `/specs/002-dark-futuristic-ui/spec.md`

## Summary

Transform the chatbot application's visual design to a dark, futuristic aesthetic inspired by kentra.com. This involves updating the color scheme, typography, spacing, and animations across both user and admin interfaces while maintaining WCAG AA accessibility standards (AAA for error states). The redesign is purely visual - no functional changes to the IAMMAI Sandbox system, WebSocket communication, or business logic.

**Technical Approach**: Update Tailwind CSS configuration with custom dark theme palette, typography scale, and spacing system. Implement scroll-based animations using Intersection Observer API or lightweight animation library. Update all React components to use new design tokens while preserving existing functionality.

## Technical Context

**Language/Version**: TypeScript 5.x on Node.js 20 LTS
**Primary Dependencies**: Next.js 14, React 18, Tailwind CSS 3.4, pnpm workspace
**Storage**: N/A (styling only, no data layer changes)
**Testing**: Jest/React Testing Library for component tests, visual regression testing
**Target Platform**: Web browsers (modern Chrome, Firefox, Safari, Edge)
**Project Type**: Web application (monorepo: frontend/backend separation)
**Performance Goals**: 60fps animations, <100ms interaction feedback, maintain existing page load times
**Constraints**: WCAG AA contrast (4.5:1 normal text, 3:1 large text), WCAG AAA for errors/warnings (7:1), 320px to 4K viewport support
**Scale/Scope**: 2 frontend apps (user, admin), 1 shared component package, ~20 React components to update

## Constitution Check

*GATE: Must pass before Phase 0 research. Re-check after Phase 1 design.*

### Principle I: Code Quality First
- **Type Safety**: ✅ TypeScript strict mode already enabled, no `any` types will be introduced
- **Code Organization**: ✅ Styling changes confined to CSS/Tailwind config and component styling props
- **Naming Conventions**: ✅ Design tokens will follow descriptive naming (colors.dark.background vs colors.bg)
- **Error Handling**: ✅ No error handling changes (visual only)
- **Documentation**: ✅ Will document color palette, typography scale, spacing system in quickstart.md
- **Dependencies**: ⚠️ **MAY REQUIRE JUSTIFICATION**: Considering animation library (AOS, Framer Motion, or react-spring)

### Principle II: Testing Standards
- **Unit Tests**: ✅ Component rendering tests will verify new class names applied
- **Integration Tests**: ✅ No API/service changes, existing integration tests remain valid
- **Contract Tests**: ✅ No contract changes
- **Privacy Tests**: ✅ No privacy-related changes
- **Test Organization**: ✅ Tests co-located with components
- **Test Naming**: ✅ Existing naming conventions maintained

### Principle III: User Experience Consistency
- **State Visibility**: ✅ Kernel status visibility enhanced through better contrast (FR-012, FR-019)
- **Feedback Immediacy**: ✅ Maintained with improved visual states (FR-007, SC-005)
- **Error Clarity**: ✅ Error messages more visible with WCAG AAA contrast (FR-019)
- **Dissolution Experience**: ✅ Enhanced with dark theme styling, maintains unmistakable transition
- **Loading States**: ✅ Skeleton screens updated to dark theme (FR-017)
- **Accessibility**: ⚠️ **REQUIRES VALIDATION**: WCAG AA compliance must be verified with contrast checking tools
- **Responsive Design**: ✅ 320px to 4K support maintained (FR-016, SC-009)

### Principle IV: Performance Requirements
- **API Response Time**: ✅ No API changes
- **WebSocket Latency**: ✅ No WebSocket changes
- **Time to Interactive**: ⚠️ **REQUIRES VALIDATION**: Additional CSS/animations must not exceed 3s TTI budget
- **Memory Efficiency**: ✅ No memory-intensive changes
- **Dissolution Speed**: ✅ No changes to dissolution logic
- **Startup Time**: ✅ No backend changes

### Principle V: Privacy & Ephemerality Enforcement
- **Memory-Only Storage**: ✅ No storage changes
- **No Logging of Content**: ✅ No logging changes
- **Dissolution Verification**: ✅ No dissolution changes
- **Token Opacity**: ✅ No token changes
- **Session Isolation**: ✅ No session isolation changes
- **No Analytics on Content**: ✅ No analytics changes

### Gates Summary

**⚠️ Requires Attention**:
1. **Animation Library Dependency** (Principle I): If adding new dependency, must justify vs. CSS-only animations
2. **WCAG Compliance Validation** (Principle III): Must verify all color combinations with automated tools
3. **Performance Budget** (Principle IV): Must verify TTI and animation frame rates

**✅ All other gates pass**: This is a visual-only feature with no privacy, security, or functional changes.

## Project Structure

### Documentation (this feature)

```text
specs/002-dark-futuristic-ui/
├── plan.md              # This file
├── research.md          # Phase 0: Animation library comparison, dark theme palette research
├── data-model.md        # Phase 1: Design system tokens (colors, typography, spacing, animations)
├── quickstart.md        # Phase 1: Developer guide for using new design system
├── contracts/           # N/A for styling-only feature
└── tasks.md             # Phase 2: Created by /speckit.tasks command
```

### Source Code (repository root)

```text
frontend/
├── apps/
│   ├── admin/
│   │   ├── src/
│   │   │   ├── components/       # AdminLayout, KernelStatus, SessionCard, etc.
│   │   │   ├── pages/            # index, login, sessions/*, etc.
│   │   │   └── styles/
│   │   │       └── globals.css   # Dark theme base styles
│   │   └── tailwind.config.js    # Admin-specific Tailwind config (extends shared)
│   │
│   └── user/
│       ├── src/
│       │   ├── components/       # ChatMessage, KernelStatus, SessionList, etc.
│       │   ├── pages/            # index, chat/[id], etc.
│       │   └── styles/
│       │       └── globals.css   # Dark theme base styles
│       └── tailwind.config.js    # User-specific Tailwind config (extends shared)
│
└── packages/
    └── shared/
        ├── src/
        │   ├── components/       # LoadingSkeleton, StatusBadge, Toast, etc.
        │   └── styles/
        │       └── design-tokens.ts  # NEW: Centralized design system tokens
        └── tailwind.config.base.js   # NEW: Shared Tailwind configuration

backend/                          # No changes required
tests/                            # Add visual regression tests for key pages
```

**Structure Decision**: Web application monorepo structure with frontend/backend separation. Styling changes isolated to frontend workspace. Shared design tokens will be centralized in `@iammai-sandbox/shared` package to ensure consistency between user and admin apps.

## Complexity Tracking

> **No violations to justify** - This feature aligns with all constitution principles. The only areas requiring validation (WCAG compliance, performance budget) are standard quality checks, not principle violations.

## Phase 0: Research & Technical Decisions

**Objectives**:
1. Select animation approach (CSS-only vs. library)
2. Define dark theme color palette with validated WCAG compliance
3. Establish typography scale and spacing system
4. Research scroll-reveal animation patterns

**Research Tasks** (see [research.md](./research.md)):
- R1: Animation approach comparison (CSS vs. AOS vs. Framer Motion vs. react-spring)
- R2: Dark theme color palette with WCAG AA/AAA compliance validation
- R3: Sans-serif font selection for modern tech aesthetic
- R4: Spacing scale system (4px vs. 8px base unit)
- R5: Scroll-reveal animation patterns and performance considerations
- R6: Syntax highlighting themes for dark code blocks

**Outputs**:
- research.md with justified technical decisions
- Color palette with contrast ratio calculations
- Animation approach recommendation

## Phase 1: Design Artifacts

**Prerequisites**: research.md complete with all decisions finalized

### 1.1 Data Model (Design System Tokens)

**File**: [data-model.md](./data-model.md)

**Entities** (from spec):
- Color Palette (primary, secondary, text, semantic colors)
- Typography Scale (font sizes, weights, line heights)
- Spacing System (margin/padding scale)
- Animation Timings (duration, easing functions)
- Component Styles (buttons, inputs, cards, badges, overlays)

**Structure**:
```typescript
// Conceptual shape (actual tokens in data-model.md)
interface DesignTokens {
  colors: {
    dark: { background: string; surface: string; elevated: string; }
    text: { primary: string; secondary: string; tertiary: string; }
    accent: { primary: string; secondary: string; }
    semantic: {
      success: string;
      warning: string; // WCAG AAA 7:1
      error: string;   // WCAG AAA 7:1
      info: string;
    }
  }
  typography: {
    fontFamily: { sans: string[]; mono: string[]; }
    fontSize: { xs: string; sm: string; base: string; lg: string; xl: string; /* ... */ }
    fontWeight: { normal: number; medium: number; semibold: number; bold: number; }
    lineHeight: { tight: number; normal: number; relaxed: number; }
  }
  spacing: {
    0: string; 1: string; 2: string; 3: string; 4: string; 6: string; 8: string; 12: string; 16: string; 24: string; 32: string; 48: string; 64: string;
  }
  animation: {
    duration: { fast: string; medium: string; slow: string; }
    easing: { easeOut: string; easeInOut: string; }
  }
}
```

### 1.2 Contracts

**N/A** - This is a visual-only feature with no API changes.

### 1.3 Developer Quickstart

**File**: [quickstart.md](./quickstart.md)

**Contents**:
- Overview of dark futuristic design system
- How to use design tokens in components
- Color palette reference with contrast ratios
- Typography usage examples
- Spacing guidelines
- Animation usage patterns
- Component styling examples (before/after)
- Accessibility checklist for new components

### 1.4 Agent Context Update

**File**: `CLAUDE.md` (updated via update-agent-context.sh)

**Additions**:
- Design system tokens location: `frontend/packages/shared/src/styles/design-tokens.ts`
- Tailwind config inheritance pattern
- Animation library choice (if applicable)
- WCAG contrast requirements for this project

## Phase 2: Task Generation

**Command**: `/speckit.tasks` (separate command, not executed by /speckit.plan)

**Anticipated Task Breakdown** (30-40 tasks estimated):

1. **Foundation** (5 tasks)
   - Define color palette tokens with WCAG validation
   - Define typography scale
   - Define spacing system
   - Define animation timings
   - Create shared Tailwind config base

2. **Shared Components** (8 tasks)
   - Update LoadingSkeleton to dark theme
   - Update StatusBadge to dark theme with WCAG AAA for errors
   - Update Toast to dark theme
   - Add scroll-reveal animation wrapper (if needed)
   - Create syntax highlighting theme for code blocks
   - Update shared component tests
   - Visual regression tests for shared components
   - Accessibility audit for shared components

3. **User App** (10 tasks)
   - Update globals.css with dark theme base
   - Update tailwind.config.js to extend shared config
   - Update ChatMessage component styling
   - Update KernelStatus component styling
   - Update DissolutionOverlay styling
   - Update PresenceIndicator styling
   - Update SessionList styling
   - Update chat page layout and spacing
   - Update index page styling
   - User app visual regression tests

4. **Admin App** (10 tasks)
   - Update globals.css with dark theme base
   - Update tailwind.config.js to extend shared config
   - Update AdminLayout styling
   - Update KernelStatus component styling
   - Update SessionCard styling
   - Update LifecycleTimeline styling
   - Update login page styling
   - Update sessions list and detail pages
   - Update index page styling
   - Admin app visual regression tests

5. **Animations** (3 tasks)
   - Implement scroll-reveal animations
   - Add transition animations to interactive elements
   - Add message appear animations

6. **Quality Assurance** (6 tasks)
   - WCAG contrast validation across all pages
   - Cross-browser testing (Chrome, Firefox, Safari, Edge)
   - Responsive design testing (320px, tablet, desktop, 4K)
   - Performance validation (60fps animations, TTI budget)
   - Accessibility audit (keyboard navigation, screen readers)
   - Final visual consistency review

## Implementation Notes

### Constitution Compliance

**Re-evaluation after Phase 1 Design**:

1. **Animation Library Decision** (Principle I - Dependencies):
   - If CSS-only: ✅ No new dependency
   - If library added: Must document in research.md why CSS insufficient for scroll-reveal patterns

2. **WCAG Compliance** (Principle III - Accessibility):
   - All color combinations documented in data-model.md with contrast ratios
   - Automated testing with tools like axe-core or Pa11y
   - Manual validation with browser DevTools contrast checker

3. **Performance** (Principle IV):
   - Lighthouse performance audit before/after
   - Animation frame rate profiling
   - CSS bundle size monitoring

### Risk Mitigation

1. **Scope Creep**: Strictly visual changes only - no functional modifications
2. **Accessibility Regression**: Automated WCAG testing in CI/CD pipeline
3. **Performance Degradation**: Performance budget enforcement, animation optimization
4. **Inconsistency**: Centralized design tokens prevent drift between apps

### Success Validation

Aligns with Success Criteria from spec:
- **SC-001**: User feedback on modern/professional feel (qualitative)
- **SC-002**: Automated contrast ratio validation (4.5:1 minimum)
- **SC-003**: Manual UX review of visual hierarchy
- **SC-004**: Chrome DevTools performance profiling (60fps target)
- **SC-005**: Interaction timing validation (<100ms)
- **SC-006**: Accessibility audit (state differentiation beyond color)
- **SC-007**: Extended usage testing (no eye strain reports)
- **SC-008**: Visual regression testing (consistency)
- **SC-009**: Responsive design testing (320px - 4K)
- **SC-010**: Functional testing (no friction introduced)

## Next Steps

1. **Phase 0**: Execute research tasks → produce research.md
2. **Phase 1**: Generate data-model.md, quickstart.md based on research
3. **Phase 1**: Update CLAUDE.md with new design system context
4. **Phase 2**: Run `/speckit.tasks` to generate detailed task breakdown
5. **Implementation**: Execute tasks according to task dependencies
