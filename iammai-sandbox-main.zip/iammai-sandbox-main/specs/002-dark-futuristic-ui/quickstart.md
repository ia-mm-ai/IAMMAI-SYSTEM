# Developer Quickstart: Dark Futuristic UI Design System

**Feature**: 002-dark-futuristic-ui
**Date**: 2026-01-24
**Audience**: Frontend developers implementing the new design system

## Overview

This guide shows you how to use the dark futuristic design system in your components. All design tokens are centralized in Tailwind CSS configuration and shared TypeScript constants.

**Key Principles**:
- Use design tokens instead of hardcoded values
- Follow 8px spacing grid (4px for fine-tuning)
- Maintain WCAG AA/AAA accessibility standards
- Respect `prefers-reduced-motion` for animations

---

## Quick Reference

### Installation

```bash
# Dependencies already installed in /frontend/apps/user and /frontend/apps/admin
# If adding to a new package:
cd /Users/sariomaric/workspace/iammai-sandbox/frontend/apps/[your-app]
pnpm add framer-motion shiki
```

### Import Design Tokens

```typescript
// Use Tailwind classes (recommended)
<div className="bg-dark-900 text-text-primary p-4">

// Or import TypeScript tokens for JavaScript logic
import { designTokens } from '@iammai-sandbox/shared/styles/design-tokens';
const bgColor = designTokens.colors.dark[900]; // '#0d1117'
```

---

## Color Usage

### Backgrounds

```tsx
// Main background (most common)
<div className="bg-dark-900">

// Elevated surface (cards, panels)
<div className="bg-dark-800 border border-dark-750">

// Hover state
<div className="bg-dark-800 hover:bg-dark-750 transition-colors duration-fast">
```

**Contrast Validation**: All backgrounds paired with text must meet WCAG AA (4.5:1).

### Text Colors

```tsx
// Primary body text (highest contrast)
<p className="text-text-primary">Main content</p>

// Secondary text (supporting information)
<p className="text-text-secondary">Caption or metadata</p>

// Tertiary text (muted, placeholders)
<input placeholder="Enter text..." className="placeholder-text-tertiary" />

// Muted (UI elements only, not body text)
<span className="text-text-muted">Decorative text</span>
```

**Hierarchy**: Use `text-primary` for content, `text-secondary` for captions, `text-tertiary` for placeholders.

### Accent Colors

```tsx
// Primary brand (cyan)
<button className="bg-accent-cyan hover:bg-accent-cyan-hover text-dark-900">
  Primary Action
</button>

// Secondary actions (blue)
<a href="#" className="text-accent-blue hover:text-accent-blue-hover">
  Learn More
</a>

// Tertiary elements (purple)
<span className="bg-accent-purple-subtle text-accent-purple px-2 py-1 rounded">
  Badge
</span>

// Highlights (pink)
<mark className="bg-accent-pink-subtle text-accent-pink">
  Highlighted text
</mark>
```

**Usage**: Cyan for primary actions, blue for links/info, purple for badges, pink for highlights.

### Semantic Colors (Status Indicators)

```tsx
// Success state
<div className="bg-success-bg border border-success text-success-text">
  ✓ Operation successful
</div>

// Warning state (WCAG AAA contrast)
<div className="bg-warning-bg border border-warning text-warning-text">
  ⚠ Warning message
</div>

// Error state (WCAG AAA contrast)
<div className="bg-error-bg border border-error text-error-text">
  ✕ Error occurred
</div>

// Info state
<div className="bg-info-bg border border-info text-info-text">
  ℹ Information
</div>
```

**Critical**: Warning and error text must use `-text` variant (WCAG AAA 7:1 contrast per FR-019).

---

## Typography

### Font Families

```tsx
// Sans-serif (default, Inter Variable)
<p className="font-sans">
  Body text using Inter Variable
</p>

// Monospace (code, technical content)
<code className="font-mono">
  const code = 'example';
</code>
```

### Headings

```tsx
// H1 - Page title
<h1 className="text-4xl font-bold leading-tight text-text-primary">
  Page Title
</h1>

// H2 - Section heading
<h2 className="text-3xl font-bold leading-tight text-text-primary">
  Section Heading
</h2>

// H3 - Subsection
<h3 className="text-2xl font-semibold leading-snug text-text-primary">
  Subsection
</h3>

// H4 - Minor heading
<h4 className="text-xl font-semibold leading-snug text-text-primary">
  Minor Heading
</h4>
```

**Hierarchy**: Use size + weight to establish importance. Maintain `text-primary` for readability.

### Body Text

```tsx
// Normal body text (16px)
<p className="text-base font-normal leading-normal text-text-primary">
  Standard paragraph text with comfortable line height.
</p>

// Large body text (18px)
<p className="text-lg font-normal leading-normal text-text-primary">
  Larger text for emphasis or readability.
</p>

// Small text (14px)
<p className="text-sm font-normal leading-normal text-text-secondary">
  Small text for captions or secondary information.
</p>

// Micro text (12px)
<p className="text-xs font-normal leading-tight text-text-tertiary">
  Timestamps, metadata, or fine print.
</p>
```

### Emphasis

```tsx
// Medium weight (labels, emphasized text)
<span className="font-medium">Important label</span>

// Semibold (subheadings, buttons)
<span className="font-semibold">Subheading text</span>

// Bold (headings, strong emphasis)
<strong className="font-bold">Strong emphasis</strong>
```

---

## Spacing

### Component Padding

```tsx
// Tight spacing (8px)
<div className="p-2">Compact content</div>

// Default spacing (16px)
<div className="p-4">Standard content</div>

// Comfortable spacing (24px)
<div className="p-6">Spacious content</div>

// Card padding (24px)
<div className="p-6 bg-dark-800 rounded-lg">
  Card content
</div>
```

**Guideline**: Use `p-4` (16px) as default, `p-2` (8px) for compact UI, `p-6` (24px) for cards.

### Margins & Gaps

```tsx
// Gaps between elements (8px, 16px, 24px)
<div className="space-y-4">
  <div>Item 1</div>
  <div>Item 2</div>
</div>

// Section spacing (48px)
<section className="my-12">
  Section content
</section>

// Container padding (96px)
<div className="px-24 max-w-7xl mx-auto">
  Main content container
</div>
```

**8px Grid**: Use multiples of 8px (`spacing-2`, `spacing-4`, `spacing-6`, `spacing-8`, `spacing-12`, `spacing-16`).

### Fine-Tuning (4px Sub-Grid)

```tsx
// Icon alignment (4px)
<button className="flex items-center gap-1">
  <Icon size={16} />
  <span>Button text</span>
</button>

// Border offsets (4px)
<div className="border-2 p-1">
  Dense UI element
</div>
```

**When to Use**: Icon gaps, fine adjustments, dense interfaces.

---

## Animations

### Scroll-Reveal Animations

```tsx
import { FadeUp } from '@iammai-sandbox/shared/components/animations';

// Simple fade-up reveal
<FadeUp>
  <div>Content that fades in when scrolled into view</div>
</FadeUp>

// Custom animation with Framer Motion
import { motion } from 'framer-motion';

<motion.div
  initial={{ opacity: 0, y: 40 }}
  whileInView={{ opacity: 1, y: 0 }}
  viewport={{ once: true, margin: "-100px" }}
  transition={{ duration: 0.6, ease: [0.22, 1, 0.36, 1] }}
>
  Custom animated content
</motion.div>
```

**Performance**: `viewport={{ once: true }}` ensures animation only runs once (better performance).

### Hover & Focus States

```tsx
// Button hover with transition
<button className="bg-accent-cyan hover:bg-accent-cyan-hover
                   transition-colors duration-fast">
  Hover me
</button>

// Focus state with outline (accessibility)
<input className="focus:outline-none focus:ring-2 focus:ring-accent-blue
                  focus:ring-offset-2 focus:ring-offset-dark-900" />
```

**Timing**: Use `duration-fast` (150ms) for micro-interactions, `duration-medium` (300ms) for modals.

### Reduced Motion Support

```tsx
import { useReducedMotion } from '@iammai-sandbox/shared/hooks/useReducedMotion';

function MyComponent() {
  const reducedMotion = useReducedMotion();

  return (
    <motion.div
      initial={{ opacity: 0, y: reducedMotion ? 0 : 40 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: reducedMotion ? 0 : 0.6 }}
    >
      Content
    </motion.div>
  );
}
```

**Accessibility**: Always respect `prefers-reduced-motion` user preference.

---

## Component Examples

### Button Component

```tsx
// Primary button
<button className="bg-accent-cyan hover:bg-accent-cyan-hover text-dark-900
                   font-semibold px-6 py-3 rounded-lg
                   transition-colors duration-fast
                   focus:outline-none focus:ring-2 focus:ring-accent-blue focus:ring-offset-2">
  Primary Action
</button>

// Secondary button
<button className="bg-dark-800 hover:bg-dark-750 text-text-primary
                   font-semibold px-6 py-3 rounded-lg border border-dark-750
                   transition-colors duration-fast
                   focus:outline-none focus:ring-2 focus:ring-accent-blue focus:ring-offset-2">
  Secondary Action
</button>

// Ghost button
<button className="bg-transparent hover:bg-dark-800 text-text-primary
                   font-semibold px-6 py-3 rounded-lg
                   transition-colors duration-fast
                   focus:outline-none focus:ring-2 focus:ring-accent-blue focus:ring-offset-2">
  Ghost Action
</button>

// Disabled button
<button disabled className="bg-dark-800 text-text-muted
                            font-semibold px-6 py-3 rounded-lg
                            opacity-50 cursor-not-allowed">
  Disabled
</button>
```

### Input Field

```tsx
<div>
  <label htmlFor="email" className="block text-sm font-medium text-text-primary mb-2">
    Email Address
  </label>
  <input
    id="email"
    type="email"
    placeholder="you@example.com"
    className="w-full px-4 py-3 bg-dark-850 border border-dark-750 rounded-lg
               text-text-primary placeholder-text-tertiary
               focus:outline-none focus:ring-2 focus:ring-accent-blue
               transition-all duration-fast"
  />
</div>

// Error state
<input
  type="text"
  className="w-full px-4 py-3 bg-dark-850 border-2 border-error rounded-lg
             text-text-primary placeholder-text-tertiary
             focus:outline-none focus:ring-2 focus:ring-error"
/>
<p className="mt-2 text-sm text-error-text">
  ✕ Error message with WCAG AAA contrast
</p>
```

### Card Component

```tsx
<div className="bg-dark-800 border border-dark-750 rounded-lg p-6
                hover:bg-dark-750 transition-colors duration-fast">
  <h3 className="text-xl font-semibold text-text-primary mb-2">
    Card Title
  </h3>
  <p className="text-base text-text-secondary">
    Card content with comfortable spacing and readable contrast.
  </p>
</div>
```

### Status Badge

```tsx
// Success badge
<span className="inline-flex items-center gap-1 px-3 py-1 rounded-full
                 bg-success-bg text-success-text border border-success
                 text-sm font-medium">
  ✓ Active
</span>

// Warning badge (WCAG AAA)
<span className="inline-flex items-center gap-1 px-3 py-1 rounded-full
                 bg-warning-bg text-warning-text border border-warning
                 text-sm font-medium">
  ⚠ Warning
</span>

// Error badge (WCAG AAA)
<span className="inline-flex items-center gap-1 px-3 py-1 rounded-full
                 bg-error-bg text-error-text border border-error
                 text-sm font-medium">
  ✕ Error
</span>
```

### Code Block

```tsx
import { CodeBlock } from '@iammai-sandbox/shared/components/CodeBlock';

<CodeBlock
  code={`const greet = (name: string) => {
  console.log(\`Hello, \${name}!\`);
};`}
  language="typescript"
/>

// Inline code
<p className="text-base text-text-primary">
  Use the <code className="px-2 py-1 bg-dark-800 border border-dark-750
                            rounded text-sm text-accent-cyan">useState</code> hook.
</p>
```

### Loading Skeleton

```tsx
import { LoadingSkeleton } from '@iammai-sandbox/shared/components/LoadingSkeleton';

// Skeleton for text
<LoadingSkeleton className="h-4 w-full mb-2" />
<LoadingSkeleton className="h-4 w-3/4" />

// Skeleton for card
<div className="bg-dark-800 border border-dark-750 rounded-lg p-6">
  <LoadingSkeleton className="h-6 w-1/2 mb-4" />
  <LoadingSkeleton className="h-4 w-full mb-2" />
  <LoadingSkeleton className="h-4 w-4/5" />
</div>
```

---

## Accessibility Checklist

### Color Contrast

- [ ] **Body text**: ≥4.5:1 contrast ratio (WCAG AA)
  - Use `text-text-primary` (14.8:1) or `text-text-secondary` (6.8:1)
- [ ] **Large text** (≥18px): ≥3:1 contrast ratio (WCAG AA)
  - All text colors meet this requirement
- [ ] **Warning/error text**: ≥7:1 contrast ratio (WCAG AAA)
  - Use `text-warning-text` (8.5:1) or `text-error-text` (8.1:1)

**Validation Tool**: [WebAIM Contrast Checker](https://webaim.org/resources/contrastchecker/)

### Keyboard Navigation

- [ ] All interactive elements have visible **focus states**
  - Use `focus:ring-2 focus:ring-accent-blue focus:ring-offset-2`
- [ ] Focus indicators **don't rely on color alone**
  - Ring + offset provides shape + color distinction
- [ ] Tab order is **logical and sequential**
  - Use semantic HTML, avoid `tabindex` > 0

### Screen Readers

- [ ] Use **semantic HTML** (`<button>`, `<nav>`, `<main>`, etc.)
- [ ] Add **aria-label** for icon-only buttons
  ```tsx
  <button aria-label="Close dialog">
    <XIcon size={16} />
  </button>
  ```
- [ ] Provide **alt text** for images
  ```tsx
  <img src="logo.png" alt="Company logo" />
  ```

### Motion Sensitivity

- [ ] **Respect `prefers-reduced-motion`**
  - Use `useReducedMotion` hook for animations
  - Set duration to 0ms when reduced motion is preferred
- [ ] **No auto-playing videos** or distracting animations

---

## Common Patterns

### Responsive Spacing

```tsx
// Responsive padding (mobile to desktop)
<div className="p-4 md:p-6 lg:p-8">
  Content with responsive spacing
</div>

// Responsive text (mobile to desktop)
<h1 className="text-3xl md:text-4xl lg:text-5xl font-bold">
  Responsive heading
</h1>
```

### Dark Theme Only (No Light Mode Toggle)

```tsx
// Force dark theme (per clarification: always dark, ignore system preferences)
<html className="dark">
  <body className="bg-dark-900 text-text-primary">
    {children}
  </body>
</html>
```

**Decision**: Dark theme is enforced for all users (no light mode toggle per spec clarification).

### Centered Layout

```tsx
// Kentra.com-style centered, vertical layout
<main className="min-h-screen bg-dark-900">
  <div className="max-w-4xl mx-auto px-6 py-12">
    <h1 className="text-4xl font-bold text-text-primary mb-8 text-center">
      Page Title
    </h1>
    <FadeUp>
      <section className="bg-dark-800 rounded-lg p-8 mb-12">
        Section content
      </section>
    </FadeUp>
  </div>
</main>
```

### Staggered Grid

```tsx
import { StaggerGrid } from '@iammai-sandbox/shared/components/animations';

<StaggerGrid>
  <div className="bg-dark-800 p-6 rounded-lg">Item 1</div>
  <div className="bg-dark-800 p-6 rounded-lg">Item 2</div>
  <div className="bg-dark-800 p-6 rounded-lg">Item 3</div>
</StaggerGrid>
```

---

## Performance Tips

### Font Loading

```tsx
// In app/layout.tsx (Next.js)
import { Inter } from 'next/font/google';

const inter = Inter({
  subsets: ['latin'],
  display: 'swap',              // Prevent FOIT
  variable: '--font-inter',     // CSS variable
  weight: ['400', '500', '600', '700'],
});

export default function RootLayout({ children }) {
  return (
    <html className={inter.variable}>
      <body className="font-sans">
        {children}
      </body>
    </html>
  );
}
```

### Animation Optimization

```tsx
// Use `will-change` sparingly (only for elements that WILL animate)
<motion.div
  className="will-change-transform"
  animate={{ y: 0 }}
>
  Animated content
</motion.div>

// Prefer transform over top/left (GPU-accelerated)
// ✅ Good
<motion.div animate={{ y: 100 }} />

// ❌ Avoid
<motion.div animate={{ top: '100px' }} />
```

### Tree-Shaking Framer Motion

```tsx
// Import only what you need
import { motion } from 'framer-motion';

// ❌ Don't import entire library
import * as framerMotion from 'framer-motion';
```

---

## Testing

### Visual Regression Tests

```tsx
// Example using Playwright
import { test, expect } from '@playwright/test';

test('homepage renders with dark theme', async ({ page }) => {
  await page.goto('/');

  // Check background color
  const bgColor = await page.locator('body').evaluate(
    (el) => getComputedStyle(el).backgroundColor
  );
  expect(bgColor).toBe('rgb(13, 17, 23)'); // dark-900

  // Screenshot comparison
  await expect(page).toHaveScreenshot('homepage-dark.png');
});
```

### Contrast Testing

```tsx
// Example using axe-core
import { axe } from 'jest-axe';

test('button has sufficient contrast', async () => {
  const { container } = render(
    <button className="bg-accent-cyan text-dark-900">
      Primary Action
    </button>
  );

  const results = await axe(container);
  expect(results).toHaveNoViolations();
});
```

---

## Troubleshooting

### Issue: Colors not applying

**Solution**: Ensure Tailwind config extends shared config:

```javascript
// tailwind.config.js
const sharedConfig = require('../../../packages/shared/tailwind.config.base');

module.exports = {
  ...sharedConfig,
  content: [
    './src/**/*.{js,ts,jsx,tsx,mdx}',
    '../../packages/shared/src/**/*.{js,ts,jsx,tsx,mdx}',
  ],
};
```

### Issue: Animations not working

**Solution**: Check Framer Motion is installed and viewport settings:

```tsx
// Ensure viewport is configured
<motion.div
  whileInView={{ opacity: 1 }}
  viewport={{ once: true, margin: "-100px" }}  // Required!
>
```

### Issue: Font not loading

**Solution**: Verify Next.js font configuration and CSS variable:

```tsx
// layout.tsx
const inter = Inter({ variable: '--font-inter' });

// globals.css
body {
  font-family: var(--font-inter), sans-serif;
}
```

---

## Resources

- **Design Tokens**: [data-model.md](./data-model.md)
- **Research Decisions**: [research.md](./research.md)
- **Implementation Plan**: [plan.md](./plan.md)
- **Contrast Checker**: https://webaim.org/resources/contrastchecker/
- **Framer Motion Docs**: https://www.framer.com/motion/
- **Tailwind CSS Docs**: https://tailwindcss.com/docs

---

## Support

For questions or issues with the design system:
1. Check [data-model.md](./data-model.md) for token definitions
2. Check [research.md](./research.md) for rationale behind decisions
3. Refer to component examples above for common patterns
4. Validate accessibility with automated tools (axe-core, Pa11y)

**Remember**: Always prioritize accessibility (WCAG AA/AAA) and performance (60fps animations) per project constitution.
