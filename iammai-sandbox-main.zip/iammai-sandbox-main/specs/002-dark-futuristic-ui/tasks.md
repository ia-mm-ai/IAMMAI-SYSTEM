# Tasks: Dark Futuristic UI Redesign

**Input**: Design documents from `/specs/002-dark-futuristic-ui/`
**Prerequisites**: plan.md, spec.md, research.md, data-model.md, quickstart.md

**Tests**: This feature does NOT require extensive test generation. Tests are limited to accessibility validation and visual regression checks as specified in the implementation plan.

**Organization**: Tasks are grouped by user story to enable independent implementation and testing of each visual enhancement.

## Format: `[ID] [P?] [Story] Description`

- **[P]**: Can run in parallel (different files, no dependencies)
- **[Story]**: Which user story this task belongs to (US1, US2, US3, US4)
- Include exact file paths in descriptions

## Path Conventions

- **Monorepo structure**: `frontend/apps/user/`, `frontend/apps/admin/`, `frontend/packages/shared/`
- **Source**: `src/` within each app/package
- **Config**: Root of each app/package

---

## Phase 1: Setup (Shared Infrastructure)

**Purpose**: Install dependencies and create foundational design system structure

- [X] T001 Install Framer Motion in frontend/apps/user via `cd frontend/apps/user && pnpm add framer-motion`
- [X] T002 Install Framer Motion in frontend/apps/admin via `cd frontend/apps/admin && pnpm add framer-motion`
- [X] T003 Install Shiki for syntax highlighting in frontend/apps/user via `cd frontend/apps/user && pnpm add shiki`
- [X] T004 Install Shiki for syntax highlighting in frontend/apps/admin via `cd frontend/apps/admin && pnpm add shiki`
- [X] T005 [P] Create design tokens file at frontend/packages/shared/src/styles/design-tokens.ts
- [X] T006 [P] Create shared Tailwind config base at frontend/packages/shared/tailwind.config.base.js
- [X] T007 [P] Create animation hooks directory at frontend/packages/shared/src/hooks/

---

## Phase 2: Foundational (Blocking Prerequisites)

**Purpose**: Core design system that MUST be complete before ANY user story styling can be implemented

**⚠️ CRITICAL**: No user story work can begin until this phase is complete

- [X] T008 Define complete color palette in frontend/packages/shared/tailwind.config.base.js (colors: dark, text, accent, semantic per data-model.md)
- [X] T009 [P] Configure Inter Variable font in frontend/apps/user/src/pages/_app.tsx with font-display swap
- [X] T010 [P] Configure Inter Variable font in frontend/apps/admin/src/pages/_app.tsx with font-display swap
- [X] T011 Define typography scale in frontend/packages/shared/tailwind.config.base.js (fontSize, fontWeight, lineHeight per data-model.md)
- [X] T012 Define spacing system in frontend/packages/shared/tailwind.config.base.js (8px grid + 4px sub-grid per data-model.md)
- [X] T013 Define animation timings in frontend/packages/shared/tailwind.config.base.js (duration, easing per data-model.md)
- [X] T014 [P] Create useReducedMotion hook at frontend/packages/shared/src/hooks/useReducedMotion.ts
- [X] T015 [P] Create FadeUp animation component at frontend/packages/shared/src/components/animations/FadeUp.tsx
- [X] T016 [P] Create StaggerGrid animation component at frontend/packages/shared/src/components/animations/StaggerGrid.tsx
- [X] T017 Update frontend/apps/user/tailwind.config.js to extend shared base config
- [X] T018 Update frontend/apps/admin/tailwind.config.js to extend shared base config
- [X] T019 Update frontend/apps/user/src/styles/globals.css with dark theme base styles and CSS custom properties
- [X] T020 Update frontend/apps/admin/src/styles/globals.css with dark theme base styles and CSS custom properties

**Checkpoint**: Foundation ready - design tokens available, fonts configured, animations ready, Tailwind extended. User story styling can now begin in parallel.

---

## Phase 3: User Story 1 - First Visual Impression (Priority: P1) 🎯 MVP

**Goal**: Users immediately experience a modern, dark-themed interface with consistent colors, proper contrast, and professional aesthetic across all pages.

**Independent Test**: Load any page (user chat, admin dashboard, login) and verify dark background (#0d1117), text contrast (WCAG AA minimum), and visual consistency across pages.

### Implementation for User Story 1

- [X] T021 [P] [US1] Update LoadingSkeleton component styling in frontend/packages/shared/src/components/LoadingSkeleton.tsx (dark-800 background, pulse animation)
- [X] T022 [P] [US1] Update StatusBadge component styling in frontend/packages/shared/src/components/StatusBadge.tsx (semantic colors, WCAG AAA for errors/warnings)
- [X] T023 [P] [US1] Update Toast component styling in frontend/packages/shared/src/components/Toast.tsx (dark-800 background, semantic colors)
- [X] T024 [P] [US1] Update user app chat page in frontend/apps/user/src/pages/chat/[id].tsx (bg-dark-900, text-text-primary, consistent theme)
- [X] T025 [P] [US1] Update user app index page in frontend/apps/user/src/pages/index.tsx (bg-dark-900, hero styling with dark theme)
- [X] T026 [P] [US1] Update ChatMessage component in frontend/apps/user/src/components/ChatMessage.tsx (message bubble styling, role differentiation)
- [X] T027 [P] [US1] Update KernelStatus component (user) in frontend/apps/user/src/components/KernelStatus.tsx (status colors, contrast)
- [X] T028 [P] [US1] Update DissolutionOverlay component in frontend/apps/user/src/components/DissolutionOverlay.tsx (dark theme overlay, error color)
- [X] T029 [P] [US1] Update PresenceIndicator component in frontend/apps/user/src/components/PresenceIndicator.tsx (accent colors, dark background)
- [X] T030 [P] [US1] Update SessionList component in frontend/apps/user/src/components/SessionList.tsx (card styling, dark-800 backgrounds)
- [X] T031 [P] [US1] Update admin app index page in frontend/apps/admin/src/pages/index.tsx (dashboard dark theme)
- [X] T032 [P] [US1] Update admin login page in frontend/apps/admin/src/pages/login.tsx (form styling, dark theme)
- [X] T033 [P] [US1] Update admin sessions index in frontend/apps/admin/src/pages/sessions/index.tsx (table/list styling)
- [X] T034 [P] [US1] Update admin session detail in frontend/apps/admin/src/pages/sessions/[id].tsx (detail view styling)
- [X] T035 [P] [US1] Update AdminLayout component in frontend/apps/admin/src/components/AdminLayout.tsx (navigation, sidebar, dark theme)
- [X] T036 [P] [US1] Update KernelStatus component (admin) in frontend/apps/admin/src/components/KernelStatus.tsx (consistent with user app)
- [X] T037 [P] [US1] Update SessionCard component in frontend/apps/admin/src/components/SessionCard.tsx (card styling, spacing)
- [X] T038 [P] [US1] Update LifecycleTimeline component in frontend/apps/admin/src/components/LifecycleTimeline.tsx (timeline styling, accent colors)
- [ ] T039 [US1] Run WCAG contrast validation on all pages using axe-core or Pa11y (verify 4.5:1 for normal text, 7:1 for warnings/errors)
- [ ] T040 [US1] Test visual consistency across user and admin apps (same colors, spacing, typography)

**Checkpoint**: At this point, the entire application has a consistent dark theme with proper contrast. This is the MVP - all pages are visually cohesive and accessible.

---

## Phase 4: User Story 2 - Enhanced Typography & Hierarchy (Priority: P2)

**Goal**: Clear visual hierarchy through modern sans-serif typography with distinct heading sizes, weights, and spacing that guide user attention.

**Independent Test**: Review all pages and verify headings are visually distinct (size + weight), body text is readable, and hierarchy is clear without relying on color.

### Implementation for User Story 2

- [X] T041 [P] [US2] Update heading styles in user app pages (apply text-4xl font-bold for H1, text-3xl font-bold for H2, etc.)
- [X] T042 [P] [US2] Update heading styles in admin app pages (consistent with user app hierarchy)
- [X] T043 [P] [US2] Update ChatMessage typography in frontend/apps/user/src/components/ChatMessage.tsx (font-base leading-normal for messages)
- [X] T044 [P] [US2] Update form label typography across both apps (text-sm font-medium)
- [X] T045 [P] [US2] Update button typography in shared components (font-semibold)
- [X] T046 [P] [US2] Update caption/metadata typography (text-sm text-text-secondary)
- [X] T047 [US2] Verify typography hierarchy across all components (manual review of font sizes, weights, line heights)
- [X] T048 [US2] Test role differentiation in chat messages (user vs assistant messages distinguishable by typography, not just color)

**Checkpoint**: At this point, typography creates clear information hierarchy. Users can scan content easily and distinguish importance levels.

---

## Phase 5: User Story 4 - Generous Spacing & Clean Layout (Priority: P2)

**Goal**: Clean, uncluttered interface with generous whitespace following 8px spacing grid, making content easier to process and reducing cognitive load.

**Independent Test**: Measure spacing between elements, verify 8px grid adherence, check that layouts feel balanced on all screen sizes (320px to 4K).

### Implementation for User Story 4

- [X] T049 [P] [US4] Update ChatMessage spacing in frontend/apps/user/src/components/ChatMessage.tsx (p-4 message padding, space-y-4 between messages)
- [X] T050 [P] [US4] Update card spacing across apps (p-6 card padding, my-4 card margins)
- [X] T051 [P] [US4] Update form element spacing (space-y-4 between form fields, p-4 input padding)
- [X] T052 [P] [US4] Update page container spacing (px-6 page padding, max-w-4xl centered layouts per Kentra style)
- [X] T053 [P] [US4] Update section spacing on landing pages (my-12 section margins, py-16 hero padding)
- [X] T054 [P] [US4] Update grid/list spacing (gap-4 for grids, space-y-2 for dense lists)
- [ ] T055 [US4] Test responsive spacing on mobile (320px viewport - verify spacing scales down without cramping)
- [ ] T056 [US4] Test responsive spacing on tablet (768px viewport - verify comfortable spacing)
- [ ] T057 [US4] Test responsive spacing on desktop (1920px and 4K - verify max-width containers and generous spacing)

**Checkpoint**: At this point, the interface feels spacious and uncluttered. Spacing follows 8px grid consistently across all screen sizes.

---

## Phase 6: User Story 3 - Smooth Animations & Interactions (Priority: P3)

**Goal**: Subtle, smooth animations during scrolling and interactions that enhance futuristic feel without being distracting (60fps, reduced motion support).

**Independent Test**: Scroll through pages, click buttons, send messages - verify animations are present, smooth, and non-disruptive. Test with prefers-reduced-motion enabled.

### Implementation for User Story 3

- [X] T058 [P] [US3] Add scroll-reveal animations to user app landing page using FadeUp component (hero section, feature sections)
- [X] T059 [P] [US3] Add scroll-reveal animations to admin dashboard using FadeUp component (stat cards, charts)
- [X] T060 [P] [US3] Add message appear animation in frontend/apps/user/src/pages/chat/[id].tsx (Framer Motion fadeIn when message sent)
- [X] T061 [P] [US3] Add hover transitions to all buttons (transition-colors duration-fast)
- [X] T062 [P] [US3] Add hover transitions to all cards (hover:bg-dark-750 transition-colors duration-fast)
- [X] T063 [P] [US3] Add focus ring animations to all inputs (focus:ring-2 focus:ring-accent-blue transition-all duration-fast)
- [X] T064 [P] [US3] Add staggered grid animations to session lists using StaggerGrid component
- [X] T065 [US3] Test animation performance with Chrome DevTools (verify 60fps during scroll reveals and transitions)
- [X] T066 [US3] Test reduced motion support (enable prefers-reduced-motion and verify animations duration set to 0ms)
- [X] T067 [US3] Test animation timing (verify scroll reveals at 600ms, hover transitions at 150ms)

**Checkpoint**: At this point, all animations are implemented and performant. The interface feels modern and polished with smooth, subtle motion.

---

## Phase 7: Polish & Cross-Cutting Concerns

**Purpose**: Final validation, accessibility audit, performance optimization, and documentation

- [ ] T068 [P] Create syntax highlighting theme for code blocks at frontend/packages/shared/src/lib/custom-syntax-theme.ts (neon accent colors)
- [ ] T069 [P] Implement CodeBlock component at frontend/packages/shared/src/components/CodeBlock.tsx using Shiki
- [ ] T070 Update quickstart.md examples with actual component code snippets showing dark theme usage
- [ ] T071 Run comprehensive WCAG AAA validation on all error/warning states (verify 7:1 contrast minimum)
- [ ] T072 Run cross-browser testing on Chrome, Firefox, Safari, Edge (verify dark theme renders correctly)
- [ ] T073 Run responsive design testing on physical devices (iPhone SE 320px, iPad, desktop 1920px, 4K display)
- [ ] T074 Run Lighthouse performance audit (verify >90 score, TTI <3s, no CLS from animations)
- [ ] T075 Run axe-core accessibility audit (verify 0 critical issues, focus states visible, keyboard navigation works)
- [ ] T076 Verify Inter Variable font loading (check font-display swap, preload link, 0 FOIT)
- [ ] T077 Verify Framer Motion tree-shaking (check bundle size, ensure <32KB for animations)
- [ ] T078 Final visual consistency review (compare user and admin apps side-by-side for color/spacing/typography consistency)
- [ ] T079 Update CLAUDE.md with design system usage notes (color palette location, animation patterns, accessibility requirements)
- [ ] T080 Create visual regression baseline screenshots for CI/CD (homepage, chat page, admin dashboard, login)

---

## Dependencies & Execution Order

### Phase Dependencies

- **Setup (Phase 1)**: No dependencies - can start immediately
- **Foundational (Phase 2)**: Depends on Setup (Phase 1) completion - BLOCKS all user stories
- **User Stories (Phase 3-6)**: All depend on Foundational (Phase 2) completion
  - **US1 (Phase 3)**: Can start after Foundational - NO dependencies on other stories
  - **US2 (Phase 4)**: Can start after Foundational - NO dependencies on other stories (but naturally builds on US1 visuals)
  - **US4 (Phase 5)**: Can start after Foundational - NO dependencies on other stories (but refines US1 layouts)
  - **US3 (Phase 6)**: Can start after Foundational - NO dependencies on other stories (adds polish to US1/US2/US4)
- **Polish (Phase 7)**: Depends on all desired user stories being complete

### User Story Dependencies

- **User Story 1 (P1) - First Visual Impression**: Independently completable after Foundational phase. Sets the visual foundation (colors, contrast, consistency).
- **User Story 2 (P2) - Typography & Hierarchy**: Independently completable after Foundational phase. Enhances US1 with clear hierarchy but doesn't depend on it technically.
- **User Story 4 (P2) - Spacing & Layout**: Independently completable after Foundational phase. Refines US1 layouts with generous spacing but doesn't depend on it technically.
- **User Story 3 (P3) - Animations**: Independently completable after Foundational phase. Adds polish to existing visuals but works standalone.

### Within Each User Story

**User Story 1 (First Visual Impression)**:
- All component styling tasks (T021-T038) can run in parallel - different files, no dependencies
- WCAG validation (T039) depends on all styling tasks completing
- Visual consistency test (T040) depends on all styling tasks completing

**User Story 2 (Typography & Hierarchy)**:
- All typography update tasks (T041-T046) can run in parallel - different files
- Verification tasks (T047-T048) depend on typography updates completing

**User Story 4 (Spacing & Layout)**:
- All spacing update tasks (T049-T054) can run in parallel - different files
- Responsive testing tasks (T055-T057) depend on spacing updates completing

**User Story 3 (Animations)**:
- All animation tasks (T058-T064) can run in parallel - different files
- Performance testing tasks (T065-T067) depend on animations being implemented

**Polish Phase**:
- Code block tasks (T068-T069) can run in parallel
- All testing tasks (T071-T078) can run in parallel after implementations
- Documentation tasks (T070, T079-T080) can run in parallel

### Parallel Opportunities

- **Phase 1 Setup**: All 7 tasks can run in parallel (T001-T007)
- **Phase 2 Foundational**: Tasks T009-T010, T014-T016, T017-T020 can run in parallel
- **Phase 3 US1**: All component styling tasks (T021-T038) - 18 tasks in parallel!
- **Phase 4 US2**: All typography tasks (T041-T046) - 6 tasks in parallel
- **Phase 5 US4**: All spacing tasks (T049-T054) - 6 tasks in parallel
- **Phase 6 US3**: All animation tasks (T058-T064) - 7 tasks in parallel
- **Phase 7 Polish**: Most tasks (T068-T069, T071-T078) - 11 tasks in parallel

---

## Parallel Example: User Story 1 (First Visual Impression)

```bash
# Launch all component styling tasks for US1 together (18 parallel tasks):
Task T021: "Update LoadingSkeleton component in frontend/packages/shared/src/components/LoadingSkeleton.tsx"
Task T022: "Update StatusBadge component in frontend/packages/shared/src/components/StatusBadge.tsx"
Task T023: "Update Toast component in frontend/packages/shared/src/components/Toast.tsx"
Task T024: "Update user chat page in frontend/apps/user/src/pages/chat/[id].tsx"
Task T025: "Update user index page in frontend/apps/user/src/pages/index.tsx"
Task T026: "Update ChatMessage component in frontend/apps/user/src/components/ChatMessage.tsx"
Task T027: "Update KernelStatus (user) in frontend/apps/user/src/components/KernelStatus.tsx"
Task T028: "Update DissolutionOverlay in frontend/apps/user/src/components/DissolutionOverlay.tsx"
Task T029: "Update PresenceIndicator in frontend/apps/user/src/components/PresenceIndicator.tsx"
Task T030: "Update SessionList in frontend/apps/user/src/components/SessionList.tsx"
Task T031: "Update admin index in frontend/apps/admin/src/pages/index.tsx"
Task T032: "Update admin login in frontend/apps/admin/src/pages/login.tsx"
Task T033: "Update admin sessions index in frontend/apps/admin/src/pages/sessions/index.tsx"
Task T034: "Update admin session detail in frontend/apps/admin/src/pages/sessions/[id].tsx"
Task T035: "Update AdminLayout in frontend/apps/admin/src/components/AdminLayout.tsx"
Task T036: "Update KernelStatus (admin) in frontend/apps/admin/src/components/KernelStatus.tsx"
Task T037: "Update SessionCard in frontend/apps/admin/src/components/SessionCard.tsx"
Task T038: "Update LifecycleTimeline in frontend/apps/admin/src/components/LifecycleTimeline.tsx"

# Then run validation tasks sequentially:
Task T039: "WCAG contrast validation"
Task T040: "Visual consistency testing"
```

---

## Parallel Example: Foundational Phase

```bash
# After sequential color/typography/spacing/animation config (T008, T011-T013):

# Launch font configuration in parallel:
Task T009: "Configure Inter Variable in user app layout"
Task T010: "Configure Inter Variable in admin app layout"

# Launch animation components in parallel:
Task T014: "Create useReducedMotion hook"
Task T015: "Create FadeUp component"
Task T016: "Create StaggerGrid component"

# Launch Tailwind config updates in parallel:
Task T017: "Update user app Tailwind config"
Task T018: "Update admin app Tailwind config"
Task T019: "Update user globals.css"
Task T020: "Update admin globals.css"
```

---

## Implementation Strategy

### MVP First (User Story 1 Only) 🎯

1. Complete Phase 1: Setup (install deps, create design tokens) - 7 tasks
2. Complete Phase 2: Foundational (configure Tailwind, fonts, animations) - 13 tasks
3. Complete Phase 3: User Story 1 (apply dark theme everywhere) - 20 tasks
4. **STOP and VALIDATE**: Test User Story 1 independently
   - Load all pages, verify dark theme
   - Check WCAG contrast ratios
   - Verify visual consistency
5. Deploy/demo if ready - **Users now have full dark theme!**

**Total MVP**: 40 tasks (Phases 1-3)

### Incremental Delivery (Recommended)

1. **Sprint 1**: Setup + Foundational + US1 → Dark theme everywhere (MVP!)
2. **Sprint 2**: US2 → Enhanced typography and hierarchy
3. **Sprint 3**: US4 → Generous spacing and clean layouts
4. **Sprint 4**: US3 → Smooth animations and polish
5. **Sprint 5**: Polish phase → Final validation and optimization

Each sprint delivers visible value without breaking previous work.

### Parallel Team Strategy

With multiple developers:

1. **Week 1**: Team completes Setup + Foundational together (20 tasks)
2. **Week 2** (after Foundational done):
   - Developer A: US1 tasks T021-T030 (user app components)
   - Developer B: US1 tasks T031-T038 (admin app components)
   - Developer C: US2 typography updates (can start early if US1 colors done)
3. **Week 3**:
   - Developer A: US4 spacing refinements
   - Developer B: US3 animations
   - Developer C: Polish and testing
4. Stories complete and integrate independently

---

## Task Summary

**Total Tasks**: 80

**Breakdown by Phase**:
- Phase 1 (Setup): 7 tasks
- Phase 2 (Foundational): 13 tasks
- Phase 3 (US1 - First Visual Impression): 20 tasks
- Phase 4 (US2 - Typography & Hierarchy): 8 tasks
- Phase 5 (US4 - Spacing & Layout): 9 tasks
- Phase 6 (US3 - Animations): 10 tasks
- Phase 7 (Polish): 13 tasks

**Parallelizable Tasks**: 62 tasks marked [P] can run in parallel within their phase

**MVP Scope**: 40 tasks (Phases 1-3) deliver complete dark theme

**Independent Test Criteria**:
- **US1**: Load pages, verify dark theme, check contrast ratios
- **US2**: Review hierarchy, verify headings distinct, check role differentiation
- **US4**: Measure spacing, check 8px grid, test responsiveness
- **US3**: Test animations, verify 60fps, check reduced motion

---

## Notes

- **[P] tasks** = different files, no dependencies within phase - run in parallel
- **[Story] label** maps task to specific user story for traceability
- Each user story is independently completable and testable
- No extensive test generation - validation tasks integrated into user story phases
- Focus on visual regression and accessibility validation, not unit tests
- Commit after each task or logical group
- Stop at any checkpoint to validate story independently
- Priority order for sequential execution: US1 (P1) → US2 (P2) → US4 (P2) → US3 (P3)
- Avoid: vague tasks, same file conflicts, cross-story dependencies that break independence
