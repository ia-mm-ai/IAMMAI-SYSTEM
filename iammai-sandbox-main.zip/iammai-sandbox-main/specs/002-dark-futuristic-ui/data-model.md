# Design System Data Model

**Feature**: 002-dark-futuristic-ui
**Date**: 2026-01-24
**Purpose**: Define design tokens (colors, typography, spacing, animations) as centralized constants

## Overview

This document defines the design system tokens that will be implemented as TypeScript constants and Tailwind CSS configuration. All tokens are derived from [research.md](./research.md) findings.

---

## Entity: Color Palette

**Description**: Complete color system optimized for dark theme with WCAG AA/AAA compliance

### Dark Backgrounds

Base backgrounds using GitHub Dark color science (avoids pure black for reduced eye strain):

| Token | Hex | Usage | Notes |
|-------|-----|-------|-------|
| dark-950 | `#0a0a0a` | Base canvas | Deepest background |
| dark-900 | `#0d1117` | Main background | Primary surface (GitHub dark base) |
| dark-850 | `#121212` | Alternative surface | Material Design dark |
| dark-800 | `#161b22` | Elevated surface | Cards, modals, panels |
| dark-750 | `#1c2128` | Hover states | Interactive feedback |

**Rationale**: Softer than pure black (#000000) to prevent OLED halation and reduce eye strain.

### Text Colors (WCAG Compliant)

All contrast ratios measured against dark-900 (#0d1117):

| Token | Hex | Contrast | WCAG | Usage |
|-------|-----|----------|------|-------|
| text-primary | `#e6edf3` | 14.8:1 | AAA | Body text, headings |
| text-secondary | `#8d96a0` | 6.8:1 | AA | Supporting text, captions |
| text-tertiary | `#6e7681` | 4.7:1 | AA | Muted text, placeholders |
| text-muted | `#484f58` | 3.2:1 | — | UI elements only (not body text) |

**Accessibility**: All text colors meet or exceed WCAG AA requirements (4.5:1 for normal text, 3:1 for large text ≥18px).

### Accent Colors (Futuristic Palette)

Vibrant colors for brand identity and interactive elements:

| Token | Hex | Contrast | Usage |
|-------|-----|----------|-------|
| accent-cyan | `#00ffc3` | 12.3:1 | Primary brand, links, highlights |
| accent-cyan-hover | `#00e6af` | 10.8:1 | Hover state |
| accent-cyan-subtle | `#1a4d3e` | — | Muted backgrounds |
| accent-blue | `#58a6ff` | 8.2:1 | Secondary actions, info states |
| accent-blue-hover | `#4493e8` | 7.1:1 | Hover state |
| accent-blue-subtle | `#1c3651` | — | Muted backgrounds |
| accent-purple | `#bc8cff` | 7.9:1 | Tertiary, badges, tags |
| accent-purple-hover | `#a870e8` | 6.8:1 | Hover state |
| accent-purple-subtle | `#2e1f47` | — | Muted backgrounds |
| accent-pink | `#ff00ff` | 5.8:1 | Highlights, special states |
| accent-pink-hover | `#e600e6` | 5.2:1 | Hover state |
| accent-pink-subtle | `#3d1a3d` | — | Muted backgrounds |

**Design Note**: Neon accent colors create futuristic aesthetic while maintaining sufficient contrast for accessibility.

### Semantic Colors (WCAG AAA for Warnings/Errors)

Status indicators with enhanced contrast per FR-019:

| Status | Token | Hex | Contrast | WCAG | Notes |
|--------|-------|-----|----------|------|-------|
| Success | success | `#3fb950` | 5.8:1 | AA | Default success color |
| | success-text | `#7ee787` | 9.2:1 | AAA | Success text/icons |
| | success-bg | `#033a16` | — | — | Success backgrounds |
| Warning | warning | `#d29922` | 7.0:1 | **AAA ✓** | Default warning color |
| | warning-text | `#f0c674` | 8.5:1 | **AAA ✓** | Warning text/icons |
| | warning-bg | `#3d2e00` | — | — | Warning backgrounds |
| Error | error | `#f85149` | 7.2:1 | **AAA ✓** | Default error color |
| | error-text | `#ff7b72` | 8.1:1 | **AAA ✓** | Error text/icons |
| | error-bg | `#3d0f0e` | — | Warning backgrounds |
| Info | info | `#58a6ff` | 8.2:1 | AAA | Default info color |
| | info-text | `#79c0ff` | 9.8:1 | AAA | Info text/icons |
| | info-bg | `#0d2d4e` | — | — | Info backgrounds |

**Critical Requirement**: Warning and error colors meet WCAG AAA contrast ratio (7:1 minimum) per clarification decision and FR-019.

### Color Relationships

```text
Background Hierarchy (light to dark):
dark-750 (hover) → dark-800 (elevated) → dark-900 (base) → dark-950 (canvas)

Text Hierarchy (high to low prominence):
text-primary (14.8:1) → text-secondary (6.8:1) → text-tertiary (4.7:1) → text-muted (3.2:1)

Accent Priority:
1. Cyan (primary brand, 12.3:1)
2. Blue (secondary actions, 8.2:1)
3. Purple (tertiary, 7.9:1)
4. Pink (highlights, 5.8:1)
```

### Validation Requirements

- **WCAG AA**: All body text colors ≥4.5:1 contrast
- **WCAG AAA**: Warning/error colors ≥7:1 contrast
- **Large Text**: Headers ≥18px require ≥3:1 contrast
- **Tools**: WebAIM Contrast Checker, axe DevTools

---

## Entity: Typography Scale

**Description**: Font family, sizes, weights, and line heights for consistent hierarchy

### Font Family

| Token | Value | Fallback | Usage |
|-------|-------|----------|-------|
| font-sans | Inter Variable | ui-sans-serif, -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif | Primary UI font |
| font-mono | SF Mono | Monaco, Cascadia Code, Consolas, monospace | Code blocks, technical text |

**Performance**:
- Inter Variable: 328KB (all weights in one file)
- `font-display: swap` prevents FOIT (Flash of Invisible Text)
- System font fallback renders instantly (0ms delay)

### Font Sizes

Type scale following 1.2 (minor third) ratio:

| Token | rem | px (at 16px root) | Usage |
|-------|-----|-------------------|-------|
| text-xs | 0.75rem | 12px | Micro text, timestamps |
| text-sm | 0.875rem | 14px | Small text, captions |
| text-base | 1rem | 16px | Body text (default) |
| text-lg | 1.125rem | 18px | Large body text |
| text-xl | 1.25rem | 20px | Subheadings |
| text-2xl | 1.5rem | 24px | H3 headings |
| text-3xl | 1.875rem | 30px | H2 headings |
| text-4xl | 2.25rem | 36px | H1 headings |
| text-5xl | 3rem | 48px | Display headings |
| text-6xl | 3.75rem | 60px | Hero text |

**Accessibility**: Using `rem` units respects user browser font size preferences.

### Font Weights

| Token | Value | Usage |
|-------|-------|-------|
| font-normal | 400 | Body text |
| font-medium | 500 | Emphasis, labels |
| font-semibold | 600 | Subheadings, buttons |
| font-bold | 700 | Headings, strong emphasis |

**Note**: Inter Variable provides entire weight range (100-900) but we limit to 400/500/600/700 for consistency.

### Line Heights

| Token | Value | Usage |
|-------|-------|-------|
| leading-tight | 1.25 | Headings, compact UI |
| leading-snug | 1.375 | Subheadings |
| leading-normal | 1.5 | Body text (default) |
| leading-relaxed | 1.625 | Long-form content |
| leading-loose | 2 | Poetry, special formatting |

**Rationale**: 1.5 (normal) balances readability and density for UI text.

### Typography Hierarchy

```text
H1: text-4xl (36px) / font-bold (700) / leading-tight (1.25)
H2: text-3xl (30px) / font-bold (700) / leading-tight (1.25)
H3: text-2xl (24px) / font-semibold (600) / leading-snug (1.375)
H4: text-xl (20px) / font-semibold (600) / leading-snug (1.375)
H5: text-lg (18px) / font-medium (500) / leading-normal (1.5)
H6: text-base (16px) / font-medium (500) / leading-normal (1.5)

Body: text-base (16px) / font-normal (400) / leading-normal (1.5)
Small: text-sm (14px) / font-normal (400) / leading-normal (1.5)
Caption: text-xs (12px) / font-normal (400) / leading-tight (1.25)
```

---

## Entity: Spacing System

**Description**: Consistent spacing units for margins, padding, and gaps (8px primary grid with 4px sub-grid)

### Spacing Scale

Based on research decision: 8px primary grid with 4px sub-grid for fine-tuning.

| Token | rem | px (at 16px root) | Usage |
|-------|-----|-------------------|-------|
| spacing-0 | 0rem | 0px | Reset spacing |
| spacing-1 | 0.25rem | 4px | Fine-tuning, borders |
| spacing-2 | 0.5rem | 8px | Tight spacing, icon gaps |
| spacing-3 | 0.75rem | 12px | Compact spacing |
| spacing-4 | 1rem | 16px | Default spacing |
| spacing-6 | 1.5rem | 24px | Comfortable spacing |
| spacing-8 | 2rem | 32px | Loose spacing |
| spacing-10 | 2.5rem | 40px | Section spacing |
| spacing-12 | 3rem | 48px | Large sections |
| spacing-16 | 4rem | 64px | Extra large sections |
| spacing-20 | 5rem | 80px | Hero sections |
| spacing-24 | 6rem | 96px | Container spacing |

### Semantic Spacing

Named spacing for specific contexts:

| Token | Value | Usage |
|-------|-------|-------|
| space-component | spacing-4 (16px) | Internal component padding |
| space-card | spacing-6 (24px) | Card padding |
| space-section | spacing-12 (48px) | Between page sections |
| space-container | spacing-24 (96px) | Max-width container padding |

### Usage Guidelines

**8px Increments (2, 4, 6, 8, 12, 16)**:
- Component padding: `p-4`, `p-6`, `p-8`
- Margins between sections: `my-8`, `my-12`, `my-16`
- Gaps in grids/flex: `gap-4`, `gap-6`, `gap-8`

**4px Increments (1, 3, 5)**:
- Icon alignment: `p-1`, `p-2`
- Fine-tuning: `ml-1`, `mt-2`
- Dense UI elements: `space-y-1`, `space-y-2`

**Rationale**: 8px base unit aligns with industry standards (Material Design, Apple HIG, GitHub Primer) and device pixel ratios. 4px sub-grid provides flexibility for dense interfaces.

---

## Entity: Animation Timings

**Description**: Duration and easing values for transitions and animations

### Duration

| Token | Value | Usage |
|-------|-------|-------|
| duration-instant | 0ms | Instant state changes |
| duration-fast | 150ms | Micro-interactions (hover, focus) |
| duration-medium | 300ms | Modal open/close, dropdowns |
| duration-slow | 500ms | Page transitions |
| duration-reveal | 600ms | Scroll-reveal animations (Kentra-inspired) |

**Kentra.com Reference**: AOS uses 800ms duration. Our 600ms is slightly faster for more responsive feel.

### Easing Functions

| Token | Value | Usage |
|-------|-------|-------|
| ease-linear | linear | Progress bars, loaders |
| ease-out | cubic-bezier(0, 0, 0.2, 1) | Entrances, reveals |
| ease-in | cubic-bezier(0.4, 0, 1, 1) | Exits, dismissals |
| ease-in-out | cubic-bezier(0.4, 0, 0.2, 1) | Transitions between states |
| ease-reveal | cubic-bezier(0.22, 1, 0.36, 1) | Scroll reveals (custom, Kentra-inspired) |

**Kentra.com Reference**: AOS uses `ease-out-cubic`. Our `ease-reveal` is a custom curve optimized for scroll animations.

### Animation States

| State | Transform | Opacity | Usage |
|-------|-----------|---------|-------|
| initial | translateY(40px) | 0 | Before scroll reveal |
| animate | translateY(0) | 1 | After scroll reveal |
| exit | translateY(-40px) | 0 | Element leaving viewport (optional) |

### Intersection Observer Settings

| Setting | Value | Rationale |
|---------|-------|-----------|
| once | true | Only animate once (better performance) |
| margin | -100px | Trigger 100px before element enters viewport |
| amount | 0.3 | Trigger when 30% of element is visible |

### Reduced Motion

**Critical**: Respect `prefers-reduced-motion` user preference (Principle III - Accessibility):

```typescript
const reducedMotion = useReducedMotion();

animation = {
  duration: reducedMotion ? 0 : 600,
  y: reducedMotion ? 0 : 40,
}
```

---

## Entity: Component Styles

**Description**: Styling definitions for UI components adapted to dark theme

### Button Variants

| Variant | Background | Text | Hover Background | Border |
|---------|------------|------|------------------|--------|
| Primary | accent-cyan (#00ffc3) | dark-900 (#0d1117) | accent-cyan-hover (#00e6af) | none |
| Secondary | dark-800 (#161b22) | text-primary (#e6edf3) | dark-750 (#1c2128) | 1px dark-750 |
| Ghost | transparent | text-primary (#e6edf3) | dark-800 (#161b22) | none |
| Danger | error (#f85149) | white (#ffffff) | #e6423d | none |

**States**:
- **Normal**: Default appearance
- **Hover**: Background + cursor pointer (within 100ms per SC-005)
- **Active**: Scale(0.98) + darker background
- **Focus**: 2px outline with accent-blue (#58a6ff) + 2px offset
- **Disabled**: Opacity 0.5 + cursor not-allowed

**Accessibility**: Focus states visible without relying on color alone (outline + offset).

### Input Fields

| State | Background | Border | Text | Placeholder |
|-------|------------|--------|------|-------------|
| Default | dark-850 (#121212) | 1px dark-750 | text-primary (#e6edf3) | text-tertiary (#6e7681) |
| Hover | dark-850 (#121212) | 1px dark-750 | text-primary (#e6edf3) | text-tertiary (#6e7681) |
| Focus | dark-850 (#121212) | 2px accent-blue (#58a6ff) | text-primary (#e6edf3) | text-tertiary (#6e7681) |
| Error | dark-850 (#121212) | 2px error (#f85149) | text-primary (#e6edf3) | text-tertiary (#6e7681) |
| Disabled | dark-900 (#0d1117) | 1px dark-800 | text-muted (#484f58) | text-muted (#484f58) |

**Focus Indicators**: 2px border (vs. 1px default) ensures keyboard navigation visibility.

### Cards & Panels

| Element | Background | Border | Shadow |
|---------|------------|--------|--------|
| Card | dark-800 (#161b22) | 1px dark-750 (#1c2128) | none (flat design) |
| Card Hover | dark-750 (#1c2128) | 1px dark-750 (#1c2128) | none |
| Modal | dark-800 (#161b22) | 1px dark-750 (#1c2128) | 0 8px 32px rgba(0,0,0,0.4) |
| Popover | dark-800 (#161b22) | 1px dark-750 (#1c2128) | 0 4px 16px rgba(0,0,0,0.3) |

**Rationale**: Flat design (no shadows on cards) aligns with Kentra's minimalist aesthetic. Shadows reserved for floating elements (modals, popovers) to establish z-index hierarchy.

### Status Badges

| Status | Background | Text | Border |
|--------|------------|------|--------|
| Active | success-bg (#033a16) | success-text (#7ee787) | 1px success (#3fb950) |
| Warning | warning-bg (#3d2e00) | warning-text (#f0c674) | 1px warning (#d29922) |
| Error | error-bg (#3d0f0e) | error-text (#ff7b72) | 1px error (#f85149) |
| Info | info-bg (#0d2d4e) | info-text (#79c0ff) | 1px info (#58a6ff) |
| Neutral | dark-800 (#161b22) | text-secondary (#8d96a0) | 1px dark-750 |

**WCAG Compliance**: All status text colors meet AAA contrast ratio (7:1 minimum) per FR-019.

### Loading States (Skeleton Screens)

| Element | Background | Animation |
|---------|------------|-----------|
| Skeleton | dark-800 (#161b22) | Pulse animation (opacity 0.5 → 1 → 0.5, 2s infinite) |
| Shimmer | linear-gradient(90deg, transparent 0%, dark-750 50%, transparent 100%) | Translate animation (left to right, 1.5s infinite) |

**Preference**: Skeleton screens over spinners (Principle III - Loading States).

### Code Blocks

| Element | Background | Border | Text |
|---------|------------|--------|------|
| Inline Code | dark-800 (#161b22) | 1px dark-750 | accent-cyan (#00ffc3) |
| Code Block | dark-900 (#0d1117) | 1px dark-800 | Syntax-highlighted (Shiki) |
| Code Header | dark-800 (#161b22) | none | text-secondary (#8d96a0) |

**Syntax Highlighting**: Custom theme with neon accents (keywords: pink, strings: cyan, functions: blue, numbers: purple). See [research.md R6](./research.md#r6-syntax-highlighting-for-code-blocks).

---

## Implementation Notes

### Tailwind CSS Configuration

All tokens will be implemented in Tailwind config extending the default theme:

```typescript
// frontend/packages/shared/tailwind.config.base.js
module.exports = {
  theme: {
    extend: {
      colors: { /* Color palette from above */ },
      fontFamily: { /* Typography from above */ },
      fontSize: { /* Font sizes from above */ },
      spacing: { /* Spacing scale from above */ },
      transitionDuration: { /* Animation durations from above */ },
      transitionTimingFunction: { /* Easing functions from above */ },
    },
  },
};
```

### TypeScript Design Tokens

For JavaScript/TypeScript access:

```typescript
// frontend/packages/shared/src/styles/design-tokens.ts
export const designTokens = {
  colors: { /* Color palette */ },
  typography: { /* Typography scale */ },
  spacing: { /* Spacing scale */ },
  animation: { /* Animation timings */ },
};
```

### CSS Custom Properties (Optional)

For runtime theming or dynamic values:

```css
/* frontend/apps/user/src/styles/globals.css */
:root {
  --color-dark-900: #0d1117;
  --color-text-primary: #e6edf3;
  --color-accent-cyan: #00ffc3;
  /* ... */
}
```

---

## Validation Checklist

### Accessibility

- [ ] All text colors meet WCAG AA contrast ratio (4.5:1)
- [ ] Warning/error colors meet WCAG AAA contrast ratio (7:1)
- [ ] Focus indicators visible for keyboard navigation
- [ ] Reduced motion support implemented
- [ ] Font sizes use rem units (respects user preferences)

### Performance

- [ ] Framer Motion tree-shaken (minimize bundle size)
- [ ] Inter Variable font preloaded
- [ ] Animations run at 60fps (hardware-accelerated)
- [ ] Intersection Observer used (vs. scroll events)

### Consistency

- [ ] All components use design tokens (no hardcoded values)
- [ ] Spacing follows 8px grid (with 4px sub-grid for fine-tuning)
- [ ] Color palette consistent across user and admin apps
- [ ] Typography hierarchy maintained across all pages

---

## Revision History

| Date | Version | Changes |
|------|---------|---------|
| 2026-01-24 | 1.0.0 | Initial design system tokens |

**Status**: ✅ Complete - Ready for implementation in Tailwind config and component styling
