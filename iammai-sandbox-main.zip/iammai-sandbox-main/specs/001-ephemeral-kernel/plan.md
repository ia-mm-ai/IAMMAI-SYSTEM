# Implementation Plan: IAMMAI Sandbox System

**Branch**: `001-ephemeral-kernel` | **Date**: 2026-01-24 | **Spec**: [spec.md](./spec.md)
**Input**: Feature specification from `/specs/001-ephemeral-kernel/spec.md`

## Summary

Build a web application enabling admins to create and manage ephemeral chatbot sessions. Users claim anonymous tokens to join sessions and chat privately with an AI. When sessions end, all conversations are destroyed permanently—only session metadata survives. The system enforces privacy architecturally: conversation data exists only in memory and is never persisted.

## Technical Context

**Language/Version**: TypeScript 5.x on Node.js 20 LTS
**Primary Dependencies**: Next.js 14 (frontend), Express/Fastify (backend), native WebSocket
**Storage**: PostgreSQL 16 (session records only), In-memory Map (kernels/conversations)
**Testing**: Vitest (unit/integration), Playwright (E2E)
**Target Platform**: Linux server (Docker), modern browsers (Chrome, Firefox, Safari, Edge)
**Project Type**: Web application (frontend + backend)
**Performance Goals**: <200ms API P95, <100ms WebSocket, <3s TTI, <50ms dissolution
**Constraints**: 100 concurrent users/session, 10 concurrent sessions, 512MB memory/session
**Scale/Scope**: Single admin tier, anonymous users, OpenAI API (GPT-4o/GPT-4o-mini)

## Constitution Check

*GATE: Must pass before Phase 0 research. Re-check after Phase 1 design.*

### Principle I: Code Quality First

| Requirement | Plan Compliance |
|-------------|-----------------|
| TypeScript strict mode | ✅ Enabled in tsconfig.json |
| No `any` types | ✅ Enforced via ESLint rule |
| Max 300 lines/file | ✅ ESLint max-lines rule |
| Max 50 lines/function | ✅ ESLint max-lines-per-function |
| Explicit error handling | ✅ Result types, no silent catches |
| JSDoc on public APIs | ✅ TypeDoc generation in CI |
| Justified dependencies | ✅ See research.md for justifications |

### Principle II: Testing Standards

| Requirement | Plan Compliance |
|-------------|-----------------|
| 80% unit test coverage | ✅ Vitest coverage threshold |
| Integration tests for APIs | ✅ API contract tests in /tests/integration |
| Contract tests (API, WebSocket) | ✅ OpenAPI validation, WebSocket protocol tests |
| Privacy tests (dissolution, isolation, admin access) | ✅ Dedicated /tests/privacy suite |
| Test naming (given_when_then) | ✅ ESLint test naming rule |

### Principle III: User Experience Consistency

| Requirement | Plan Compliance |
|-------------|-----------------|
| State visibility (session, kernel) | ✅ Always-visible status indicators |
| 100ms feedback | ✅ Optimistic UI updates |
| Error clarity (no jargon) | ✅ User-friendly error messages |
| Dissolution experience | ✅ Immediate, unmistakable UI change |
| Loading states | ✅ Skeleton screens for content |
| WCAG 2.1 AA | ✅ Playwright accessibility tests |
| Responsive 320px-4K | ✅ Tailwind responsive utilities |

### Principle IV: Performance Requirements

| Requirement | Plan Compliance |
|-------------|-----------------|
| API P95 <200ms | ✅ k6 load tests in CI |
| WebSocket <100ms | ✅ Latency benchmarks |
| TTI <3s on 3G | ✅ Lighthouse CI threshold |
| 100 users/session <512MB | ✅ Memory profiling tests |
| Dissolution <50ms | ✅ Unit test timing assertions |
| Startup <10s | ✅ Docker health check |

### Principle V: Privacy & Ephemerality Enforcement

| Requirement | Plan Compliance |
|-------------|-----------------|
| Memory-only conversation storage | ✅ Native JS Map, no disk I/O |
| No content logging | ✅ Log sanitization middleware |
| Dissolution verification | ✅ Heap dump tests in dev |
| Token opacity | ✅ crypto.randomBytes(32), no embedded data |
| Session isolation (architectural) | ✅ Kernel keyed by session ID |
| No content analytics | ✅ Only counts and timestamps |

**Constitution Check Status**: ✅ ALL GATES PASS

## Project Structure

### Documentation (this feature)

```text
specs/001-ephemeral-kernel/
├── plan.md                  # This file - overview and constitution check
├── implementation-guide.md  # BUILD SEQUENCE & CROSS-REFERENCES ← Start here for coding
├── research.md              # Technology decisions with rationale
├── data-model.md            # Entity definitions (persistent + ephemeral)
├── quickstart.md            # Development setup and verification
├── contracts/               # API specifications
│   ├── api.yaml             # OpenAPI 3.1 REST spec
│   └── websocket.md         # WebSocket protocol spec
└── tasks.md                 # Implementation tasks (/speckit.tasks)
```

**For Implementers**: Start with `implementation-guide.md` which provides:
- Ordered build sequence (what to implement first)
- Cross-references (which spec documents each file)
- Code examples with spec citations
- Testing requirements per module

### Source Code (repository root)

```text
backend/
├── src/
│   ├── api/
│   │   ├── routes/
│   │   │   ├── auth.ts           # Admin auth endpoints
│   │   │   ├── sessions.ts       # Session CRUD (admin)
│   │   │   ├── public.ts         # Public session browsing
│   │   │   ├── tokens.ts         # Token claim/join
│   │   │   └── chat.ts           # Message sending
│   │   ├── middleware/
│   │   │   ├── auth.ts           # JWT verification
│   │   │   ├── token.ts          # User token verification
│   │   │   └── logging.ts        # Log sanitization
│   │   └── websocket/
│   │       ├── hub.ts            # WebSocket connection manager
│   │       └── handlers.ts       # Message type handlers
│   ├── kernel/
│   │   ├── manager.ts            # Kernel lifecycle
│   │   ├── kernel.ts             # Kernel class (in-memory)
│   │   └── conversation.ts       # Conversation class
│   ├── services/
│   │   ├── session.ts            # Session business logic
│   │   ├── token.ts              # Token generation/validation
│   │   ├── ai.ts                 # AI provider abstraction
│   │   └── presence.ts           # Presence hash derivation
│   ├── models/
│   │   ├── session.ts            # Session entity
│   │   ├── admin.ts              # Admin entity
│   │   └── token.ts              # Token reference entity
│   └── lib/
│       ├── db.ts                 # Database connection
│       ├── config.ts             # Environment config
│       └── types.ts              # Shared types
├── tests/
│   ├── unit/
│   ├── integration/
│   ├── contract/
│   └── privacy/                  # Privacy-specific tests
└── package.json

frontend/
├── apps/
│   ├── admin/
│   │   └── src/
│   │       ├── pages/
│   │       │   ├── login.tsx
│   │       │   └── sessions/
│   │       │       ├── index.tsx       # Session list
│   │       │       └── [id].tsx        # Session details
│   │       └── components/
│   │           ├── SessionCard.tsx
│   │           ├── KernelStatus.tsx
│   │           └── LifecycleTimeline.tsx
│   └── user/
│       └── src/
│           ├── pages/
│           │   ├── index.tsx           # Session browser
│           │   └── chat/[id].tsx       # Chat interface
│           └── components/
│               ├── SessionList.tsx
│               ├── ChatMessage.tsx
│               ├── PresenceIndicator.tsx
│               ├── KernelStatus.tsx
│               └── DissolutionOverlay.tsx
└── packages/
    └── shared/
        ├── components/
        │   ├── StatusBadge.tsx
        │   └── LoadingSkeleton.tsx
        ├── hooks/
        │   └── useWebSocket.ts
        └── types/
            └── api.ts                  # Generated from OpenAPI

tests/
├── e2e/                                # Playwright E2E
│   ├── admin-session-lifecycle.spec.ts
│   ├── user-token-flow.spec.ts
│   ├── chat-dissolution.spec.ts
│   └── accessibility.spec.ts
└── package.json
```

**Structure Decision**: Web application with separate admin and user Next.js apps sharing common packages. Backend is a standalone Node.js service with REST API and WebSocket support. Monorepo managed with pnpm workspaces.

## Complexity Tracking

No constitution violations requiring justification. All principles are satisfied with standard patterns.

## Phase Artifacts Summary

| Phase | Artifact | Status | Purpose |
|-------|----------|--------|---------|
| 0 | research.md | ✅ Complete | Technology decisions |
| 1 | data-model.md | ✅ Complete | Entity definitions |
| 1 | contracts/api.yaml | ✅ Complete | REST API specification |
| 1 | contracts/websocket.md | ✅ Complete | Real-time protocol |
| 1 | quickstart.md | ✅ Complete | Development setup |
| 1 | **implementation-guide.md** | ✅ Complete | **Build sequence & cross-references** |
| 2 | tasks.md | ⏳ Run `/speckit.tasks` | Granular task list |

## How to Use These Artifacts

1. **Understanding the system**: Read `plan.md` (this file) for overview
2. **Technology rationale**: Read `research.md` for why decisions were made
3. **Data structures**: Read `data-model.md` for entity definitions
4. **API contracts**: Read `contracts/api.yaml` and `contracts/websocket.md`
5. **Starting development**: Read `quickstart.md` for setup
6. **Implementing code**: **Follow `implementation-guide.md`** for build order and cross-references

## Next Steps

Run `/speckit.tasks` to generate the granular implementation task list based on this plan.
