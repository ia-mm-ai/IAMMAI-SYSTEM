# Quickstart: IAMMAI Sandbox System

**Feature**: 001-ephemeral-kernel
**Date**: 2026-01-24

## Prerequisites

- Node.js 20 LTS
- pnpm 8.x (package manager)
- PostgreSQL 16 (local or Docker)
- AI provider API key (OpenAI)

## Quick Setup

```bash
# Clone and install
git clone <repository-url>
cd iammai-sandbox
pnpm install

# Setup environment
cp .env.example .env
# Edit .env with your configuration

# Setup database
pnpm db:migrate

# Start development servers
pnpm dev
```

## Environment Variables

```bash
# .env
DATABASE_URL=postgresql://user:password@localhost:5432/iammai_sandbox
AI_PROVIDER=openai
OPENAI_API_KEY=sk-...
OPENAI_MODEL=gpt-4o-mini  # or gpt-4o for higher quality
JWT_SECRET=<random-256-bit-hex>
ADMIN_EMAIL=admin@example.com
ADMIN_PASSWORD=<initial-password>
```

## Development URLs

| Service | URL | Description |
|---------|-----|-------------|
| Admin Dashboard | http://localhost:3000/admin | Session management |
| User Interface | http://localhost:3000 | Session browser & chat |
| API | http://localhost:3001/api/v1 | REST endpoints |
| WebSocket | ws://localhost:3001/ws | Real-time updates |

## Verify Installation

### 1. Admin Login

```bash
curl -X POST http://localhost:3001/api/v1/auth/login \
  -H "Content-Type: application/json" \
  -d '{"email": "admin@example.com", "password": "your-password"}' \
  -c cookies.txt
```

### 2. Create Session

```bash
curl -X POST http://localhost:3001/api/v1/admin/sessions \
  -H "Content-Type: application/json" \
  -b cookies.txt \
  -d '{"name": "Test Session"}'
```

### 3. Claim Token (as user)

```bash
curl -X POST http://localhost:3001/api/v1/sessions/{sessionId}/claim
# Save the returned token
```

### 4. Start Session (as admin)

```bash
curl -X POST http://localhost:3001/api/v1/admin/sessions/{sessionId}/start \
  -b cookies.txt
```

### 5. Join Session (as user)

```bash
curl -X POST http://localhost:3001/api/v1/sessions/{sessionId}/join \
  -H "Content-Type: application/json" \
  -d '{"token": "your-claimed-token"}'
# Returns WebSocket URL and presence hash
```

### 6. Send Message via WebSocket

```javascript
const ws = new WebSocket('ws://localhost:3001/ws/sessions/{sessionId}?token={token}');

ws.onopen = () => {
  ws.send(JSON.stringify({
    type: 'USER_MESSAGE',
    payload: { messageId: crypto.randomUUID(), content: 'Hello!' },
    timestamp: new Date().toISOString()
  }));
};

ws.onmessage = (event) => {
  const msg = JSON.parse(event.data);
  console.log(msg.type, msg.payload);
};
```

### 7. End Session & Verify Dissolution

```bash
# End session (as admin)
curl -X POST http://localhost:3001/api/v1/admin/sessions/{sessionId}/end \
  -b cookies.txt

# WebSocket clients will receive KERNEL_DISSOLVED message
# Verify kernel is gone:
# - No conversation data in memory
# - Session state is ENDED
# - User cannot rejoin
```

## Running Tests

```bash
# Unit tests
pnpm test

# Integration tests
pnpm test:integration

# E2E tests (requires running servers)
pnpm test:e2e

# Privacy tests (verify no data leakage)
pnpm test:privacy

# All tests with coverage
pnpm test:coverage
```

## Common Tasks

### Add Admin User

```bash
pnpm cli admin:create --email new@example.com --password secure123
```

### Reset Database

```bash
pnpm db:reset  # WARNING: Destroys all data
pnpm db:migrate
pnpm db:seed   # Optional: seed test data
```

### View Logs

```bash
# Development logs (structured JSON)
pnpm dev 2>&1 | pnpm logs:pretty

# Production logs
docker logs iammai-sandbox-api -f
```

### Memory Profiling (Kernel)

```bash
# Start with memory inspection enabled
NODE_OPTIONS='--inspect' pnpm dev

# Open Chrome DevTools: chrome://inspect
# Take heap snapshots before/after session lifecycle
```

## Troubleshooting

### WebSocket Connection Fails
- Check token is valid (not expired, correct session)
- Verify session is in ACTIVE state
- Check CORS configuration if cross-origin

### AI Responses Slow
- Verify `OPENAI_API_KEY` is valid
- Check network connectivity to OpenAI API
- Review rate limits on OpenAI account
- Consider using `gpt-4o-mini` for faster responses

### Database Connection Issues
- Verify `DATABASE_URL` is correct
- Ensure PostgreSQL is running
- Check database user permissions

### Kernel Memory Issues
- Monitor with `process.memoryUsage()` in tests
- Each session with 100 users should use <512MB
- Check for memory leaks in long-running sessions

## Architecture Overview

```
┌─────────────────────────────────────────────────────────────┐
│                         Frontend                             │
│  ┌─────────────────┐              ┌─────────────────┐       │
│  │  Admin App      │              │   User App      │       │
│  │  (Next.js)      │              │   (Next.js)     │       │
│  └────────┬────────┘              └────────┬────────┘       │
└───────────┼────────────────────────────────┼────────────────┘
            │                                │
            │ REST API                       │ REST + WebSocket
            ▼                                ▼
┌─────────────────────────────────────────────────────────────┐
│                         Backend                              │
│  ┌─────────────────────────────────────────────────────┐    │
│  │                   API Server (Node.js)               │    │
│  │  ┌──────────┐  ┌──────────┐  ┌──────────────────┐   │    │
│  │  │  Auth    │  │ Sessions │  │  WebSocket Hub   │   │    │
│  │  │ Handler  │  │  Manager │  │  (Real-time)     │   │    │
│  │  └──────────┘  └──────────┘  └──────────────────┘   │    │
│  │                      │                │              │    │
│  │                      ▼                ▼              │    │
│  │  ┌──────────────────────────────────────────────┐   │    │
│  │  │           Kernel Manager (In-Memory)          │   │    │
│  │  │  ┌────────┐  ┌────────┐  ┌────────┐          │   │    │
│  │  │  │Kernel 1│  │Kernel 2│  │Kernel N│ ...      │   │    │
│  │  │  └────────┘  └────────┘  └────────┘          │   │    │
│  │  └──────────────────────────────────────────────┘   │    │
│  └─────────────────────────────────────────────────────┘    │
│                           │                                  │
│                           │ Persistent only                  │
│                           ▼                                  │
│  ┌─────────────────────────────────────────────────────┐    │
│  │                 PostgreSQL Database                  │    │
│  │         (Sessions, Admins - NO conversations)        │    │
│  └─────────────────────────────────────────────────────┘    │
│                                                              │
│                           │                                  │
│                           │ AI Requests                      │
│                           ▼                                  │
│  ┌─────────────────────────────────────────────────────┐    │
│  │                 AI Provider (OpenAI)                 │    │
│  └─────────────────────────────────────────────────────┘    │
└─────────────────────────────────────────────────────────────┘
```

## Privacy Verification Checklist

Before deploying, verify:

- [ ] No `console.log` with message content
- [ ] Log sanitization middleware active
- [ ] Database has no `messages` or `conversations` tables
- [ ] Heap dumps after dissolution show no conversation data
- [ ] Admin API has no conversation read endpoints
- [ ] Token values not in any logs
