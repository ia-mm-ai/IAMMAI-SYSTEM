# Research: IAMMAI Sandbox System

**Feature**: 001-ephemeral-kernel
**Date**: 2026-01-24
**Status**: Complete

## Technology Stack Decisions

### Backend Runtime

**Decision**: Node.js 20 LTS with TypeScript 5.x

**Rationale**:
- Native WebSocket support for real-time dissolution notifications (FR-023)
- Excellent memory management for in-memory kernel storage
- TypeScript strict mode aligns with Constitution Principle I
- Single-threaded event loop simplifies kernel isolation guarantees
- Rich ecosystem for AI service integration

**Alternatives Considered**:
- Deno: Newer, less mature ecosystem for production web apps
- Go: Strong performance but requires more boilerplate for WebSocket + HTTP
- Python/FastAPI: GIL complicates concurrent WebSocket handling

### Frontend Framework

**Decision**: Next.js 14 with React 18 and TypeScript

**Rationale**:
- Server-side rendering for fast TTI (Constitution Principle IV: <3s on 3G)
- Built-in routing for admin/user separation
- React's component model supports WCAG 2.1 AA accessibility (Principle III)
- Excellent TypeScript integration
- WebSocket client support for real-time updates

**Alternatives Considered**:
- Remix: Less mature, smaller community
- SvelteKit: Smaller ecosystem for enterprise features
- Vue/Nuxt: Team familiarity favors React

### Real-Time Communication

**Decision**: Native WebSocket with custom protocol

**Rationale**:
- Constitution Principle IV requires <100ms WebSocket latency
- Socket.io adds overhead; native WebSocket is leaner
- Simple protocol: session state changes, dissolution events, chat messages
- No need for Socket.io's fallback mechanisms (modern browsers only per assumptions)

**Alternatives Considered**:
- Socket.io: Adds ~50KB bundle, unnecessary fallbacks
- Server-Sent Events: Unidirectional, doesn't support chat messages upstream
- Long polling: Latency doesn't meet <100ms requirement

### Database (Session Records)

**Decision**: PostgreSQL 16

**Rationale**:
- ACID compliance for session state transitions (FR-003)
- Efficient for timestamped lifecycle records
- Proven at scale for 10+ concurrent sessions (SC-010)
- No conversation content stored (Constitution Principle V)

**Alternatives Considered**:
- SQLite: Single-file limits horizontal scaling
- MongoDB: Overkill for structured session records
- MySQL: PostgreSQL has better JSON support if needed

### In-Memory Kernel Storage

**Decision**: Native JavaScript Map with structured kernel objects

**Rationale**:
- Zero external dependencies (Constitution Principle I: minimize dependencies)
- Guaranteed memory-only storage (Constitution Principle V)
- O(1) lookup by session ID and token
- Garbage collection handles dissolution automatically
- No serialization to disk possible

**Alternatives Considered**:
- Redis: Persists to disk by default, requires careful configuration
- Memcached: External dependency, network latency
- SQLite in-memory: SQL overhead unnecessary for simple key-value

### AI Service Integration

**Decision**: Abstract AI provider interface with OpenAI API as default

**Rationale**:
- Provider-agnostic interface allows switching (Assumption #3)
- OpenAI Chat Completions API with streaming for real-time responses
- Session-scoped context sent per request (FR-027)
- No context persistence beyond kernel (FR-028)
- GPT-4o or GPT-4o-mini for cost/performance balance

**Alternatives Considered**:
- Anthropic Claude: Viable alternative, interface supports switching
- Local LLM: Resource constraints for 100 concurrent users

### Authentication (Admin)

**Decision**: JWT with HTTP-only cookies + CSRF protection

**Rationale**:
- Stateless authentication for horizontal scaling
- HTTP-only cookies prevent XSS token theft
- CSRF tokens prevent cross-site attacks
- Simple single-admin model (Assumption #4)

**Alternatives Considered**:
- Session-based: Requires shared session store
- OAuth2: Overkill for single admin tier

### Token Generation

**Decision**: Cryptographically secure random bytes (256-bit) encoded as base64url

**Rationale**:
- Constitution Principle V: Token opacity, no embedded information
- crypto.randomBytes(32) for cryptographic randomness
- Base64url encoding for URL-safe transport
- Presence hash derived via SHA-256 of token seed

**Alternatives Considered**:
- UUID v4: Less entropy (122 bits vs 256)
- JWT: Would embed information, violating privacy principle

### Testing Framework

**Decision**: Vitest (unit/integration) + Playwright (E2E)

**Rationale**:
- Vitest: Fast, TypeScript-native, Jest-compatible API
- Playwright: Cross-browser E2E for accessibility testing
- Constitution Principle II: 80% coverage, privacy tests
- Co-located tests with source (tests/ mirror structure)

**Alternatives Considered**:
- Jest: Slower, more configuration needed
- Cypress: Less reliable for WebSocket testing

## Architecture Decisions

### Kernel Isolation Model

**Decision**: Per-session kernel instance with token-keyed conversation Maps

```
kernels: Map<sessionId, Kernel>
Kernel: {
  sessionId: string
  conversations: Map<tokenHash, Conversation>
  createdAt: Date
}
Conversation: {
  messages: Message[]
  presenceHash: string
}
```

**Rationale**:
- Session isolation is structural (FR-012)
- Token hash as key prevents token exposure in memory inspection
- Dissolution = delete kernel from Map (O(1), <50ms guaranteed)

### API Structure

**Decision**: REST for CRUD operations, WebSocket for real-time

- REST: Session management, token claiming, message sending
- WebSocket: Session state changes, dissolution events, AI responses (streaming)

**Rationale**:
- REST for stateless operations simplifies testing
- WebSocket for push-based real-time requirements
- Clear separation of concerns

### Frontend Architecture

**Decision**: Separate admin and user apps sharing common components

```
frontend/
├── apps/
│   ├── admin/        # Admin dashboard (authenticated)
│   └── user/         # User chat interface (token-based)
└── packages/
    └── shared/       # Common components, types, utilities
```

**Rationale**:
- Security boundary between admin and user interfaces
- Shared components for consistent UX (Principle III)
- Monorepo structure for code sharing

## Performance Validation

| Requirement | Target | Validation Method |
|-------------|--------|-------------------|
| API P95 latency | <200ms | Load testing with k6 |
| WebSocket round-trip | <100ms | Automated benchmark suite |
| Time to Interactive | <3s on 3G | Lighthouse CI |
| Kernel memory | <512MB/100 users | Memory profiling in tests |
| Dissolution speed | <50ms | Unit test with timing assertion |
| Service startup | <10s | Docker health check |

## Security Considerations

### Token Handling
- Tokens never logged (grep audit in CI)
- Tokens transmitted via HTTPS only
- Token hash stored in memory, not raw token
- Presence hash is one-way derivation

### Content Protection
- No message content in logs (log sanitization middleware)
- Admin API has no endpoints for conversation access
- Memory inspection disabled in production builds

### Dissolution Verification
- Test suite includes memory dump verification post-dissolution
- Conversations Map explicitly cleared before kernel deletion
- WeakRef not used (would allow GC-dependent cleanup)
