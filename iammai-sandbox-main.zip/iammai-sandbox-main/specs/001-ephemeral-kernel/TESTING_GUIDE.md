# Local Testing Guide: IAMMAI Sandbox System MVP

**Feature**: 001-ephemeral-kernel
**Created**: 2026-01-24
**Last Updated**: 2026-01-24

**Implementation Status**:
- ✅ **Phase 1-2**: Foundation (Complete)
- ✅ **Phase 3**: User Story 1 - Admin Session Management (Complete)
- ✅ **Phase 4**: User Story 2 - User Token System (Complete)
- ⏸️ **Phase 5**: User Story 3 - Private AI Chat (Not Implemented)
- ⏸️ **Phase 6-8**: User Stories 4-6 (Not Implemented)

**Current MVP Scope**: User Stories 1 & 2
**Extended MVP**: + User Story 3 (Private AI Chat)
**Future**: User Stories 4-6

## Table of Contents

1. [Prerequisites](#prerequisites)
2. [Environment Setup](#environment-setup)
3. [Testing Strategy Overview](#testing-strategy-overview)
4. [**MVP Testing Path** (Start Here)](#mvp-testing-path)
5. [Phase 1 & 2: Foundation Testing](#phase-1--2-foundation-testing)
6. [Phase 3: User Story 1 Testing (Admin Session Management)](#phase-3-user-story-1-testing-admin-session-management)
7. [Phase 4: User Story 2 Testing (User Token & Join)](#phase-4-user-story-2-testing-user-token--join)
8. [Phase 5: User Story 3 Testing (Private AI Chat)](#phase-5-user-story-3-testing-private-ai-chat)
9. [Automated Test Execution](#automated-test-execution)
10. [Integration Testing](#integration-testing)
11. [Privacy Verification](#privacy-verification)
12. [Performance Testing](#performance-testing)
13. [Troubleshooting](#troubleshooting)
14. [Pre-Deployment Checklist](#pre-deployment-checklist)

---

## Prerequisites

### System Requirements

- **Node.js**: 20 LTS (verify: `node --version`)
- **pnpm**: 8.x (verify: `pnpm --version`)
- **PostgreSQL**: 16 (verify: `psql --version`)
- **OpenAI API Key**: Valid API key with GPT-4o/GPT-4o-mini access
- **Modern Browser**: Chrome, Firefox, Safari, or Edge (latest version)
- **Tools**: curl, wscat (for WebSocket testing), jq (for JSON parsing)

### Install Testing Tools

```bash
# Install WebSocket testing tool
npm install -g wscat

# Install JSON parser (optional but helpful)
# macOS: brew install jq
# Linux: sudo apt-get install jq
```

---

## Environment Setup

### 1. Clone and Install

```bash
git clone <repository-url>
cd iammai-sandbox
pnpm install
```

### 2. Configure Environment

```bash
cp .env.example .env
```

Edit `.env` with your configuration:

```bash
# Database
DATABASE_URL=postgresql://postgres:postgres@localhost:5432/iammai_sandbox_dev

# AI Provider
AI_PROVIDER=openai
OPENAI_API_KEY=sk-your-actual-openai-api-key
OPENAI_MODEL=gpt-4o-mini

# Security
JWT_SECRET=your-random-256-bit-hex-string-here

# Admin Account
ADMIN_EMAIL=admin@example.com
ADMIN_PASSWORD=SecurePassword123!

# Server Ports
API_PORT=3001
ADMIN_PORT=3000
USER_PORT=3002
```

### 3. Setup Database

```bash
# Start PostgreSQL (if using Docker)
docker-compose up -d postgres

# Run migrations
pnpm db:migrate

# Verify database
psql $DATABASE_URL -c "\dt"
# Should see: admins, sessions, tokens tables
```

### 4. Start Development Servers

```bash
# Terminal 1: Backend API + WebSocket
cd backend
pnpm dev

# Terminal 2: Admin Frontend
cd frontend/apps/admin
pnpm dev

# Terminal 3: User Frontend
cd frontend/apps/user
pnpm dev
```

### 5. Verify Services Running

```bash
# Check API health
curl http://localhost:3001/health
# Expected: {"status": "ok", "timestamp": "..."}

# Check admin app
curl http://localhost:3000
# Expected: HTML response

# Check user app
curl http://localhost:3002
# Expected: HTML response
```

---

## Testing Strategy Overview

### Test Pyramid

```
         ┌─────────────────┐
         │   E2E Tests     │  ← Playwright (full user flows)
         │    (Slow)       │
         └─────────────────┘
       ┌───────────────────────┐
       │  Integration Tests    │  ← API contracts, lifecycle flows
       │     (Medium)          │
       └───────────────────────┘
    ┌───────────────────────────────┐
    │      Unit Tests               │  ← Models, services, utilities
    │       (Fast)                  │
    └───────────────────────────────┘
```

### Testing Phases

Each phase builds on the previous and should be tested in order:

1. **Foundation** (Phase 1-2): Database, models, services work correctly
2. **User Story 1** (Phase 3): Admin can create, start, and end sessions
3. **User Story 2** (Phase 4): Users can claim tokens and join sessions
4. **User Story 3** (Phase 5): Users can chat privately with AI
5. **Integration**: All stories work together seamlessly
6. **Privacy**: No data leakage or isolation violations
7. **Performance**: System meets latency and capacity requirements

### Test-First Approach

Per Constitution Principle II, **write tests first, verify they fail, then implement**:

```bash
# 1. Write test
# 2. Run test → should FAIL
pnpm test:unit backend/tests/unit/session.test.ts
# 3. Implement feature
# 4. Run test → should PASS
```

---

## MVP Testing Path

**🎯 For Current Implementation**: Focus on this streamlined testing path

### Quick Start: 30-Minute MVP Validation

This path tests the currently implemented features (User Stories 1 & 2):

#### 1. Environment Setup (5 min)
```bash
# Verify services running
curl http://localhost:3001/health
curl http://localhost:3000
curl http://localhost:3002
```

#### 2. Foundation Check (5 min)
```bash
# Run foundation tests
pnpm test:unit backend/tests/unit/
```
**✅ Pass Criteria**: All unit tests pass

#### 3. User Story 1 - Admin Flow (10 min)

**Manual Test**:
1. Login at `http://localhost:3000/admin/login`
2. Create new session: "Test Session"
3. Verify state: CREATED (gray indicator)
4. Click "Start" → verify state: ACTIVE (green)
5. Click "End" → verify state: ENDED (red)

**Automated Test**:
```bash
pnpm test backend/tests/contract/auth.test.ts
pnpm test backend/tests/contract/sessions.test.ts
pnpm test backend/tests/integration/session-lifecycle.test.ts
```

**✅ Pass Criteria**: Manual flow works, all automated tests pass

#### 4. User Story 2 - User Flow (10 min)

**Manual Test**:
1. Open `http://localhost:3002`
2. Browse sessions → see test session
3. Click "Claim Token" on CREATED session
4. Admin: Start the session
5. User: Verify "Join" button appears
6. Click "Join" → verify redirect to chat page (even if chat not yet functional)

**Automated Test**:
```bash
pnpm test backend/tests/contract/public.test.ts
pnpm test backend/tests/contract/tokens.test.ts
pnpm test backend/tests/integration/token-flow.test.ts
```

**✅ Pass Criteria**: Token flow works, join succeeds, automated tests pass

#### 5. Integration Validation (5 min)

```bash
# Run full user journey
./tests/scripts/full-journey-test.sh
```

**✅ Pass Criteria**: Admin can create sessions, users can claim tokens and join

### MVP Checklist (Current Implementation)

- [ ] **Environment**: All services running
- [ ] **Foundation**: Unit tests pass, database connected
- [ ] **US1 - Admin**: Can login, create, start, and end sessions
- [ ] **US1 - Tests**: Contract and integration tests pass
- [ ] **US2 - User**: Can browse, claim tokens, and join sessions
- [ ] **US2 - Tests**: Token flow tests pass
- [ ] **Integration**: Full journey test passes
- [ ] **Code Quality**: ESLint passes, no TypeScript errors

### What's NOT in Current MVP

❌ **User Story 3**: AI chat functionality (WebSocket, messages)
❌ **User Story 4**: Dissolution UX
❌ **User Story 5**: Reconnection
❌ **User Story 6**: Analytics

These are covered in sections below for future reference, but are not yet implemented.

### When You're Ready for Extended MVP

Once you implement User Story 3 (Private AI Chat), proceed to:
- [Phase 5: User Story 3 Testing](#phase-5-user-story-3-testing-private-ai-chat)
- WebSocket connection testing
- AI message streaming
- Privacy verification

---

## Phase 1 & 2: Foundation Testing

### Objective

Verify core infrastructure (database, models, services) is functional before building user stories.

### Manual Tests

#### Test F1: Database Connection

```bash
# Connect to database
psql $DATABASE_URL

# Verify tables exist
\dt

# Expected tables:
# - admins
# - sessions
# - tokens

# Check admin user exists
SELECT email, created_at FROM admins;

# Exit
\q
```

**✅ Pass Criteria**: All tables exist, admin user is present

#### Test F2: Admin Model

```bash
# Start Node.js REPL
cd backend
pnpm exec ts-node

# Test admin model
const { findByEmail } = require('./src/models/admin');
const admin = await findByEmail('admin@example.com');
console.log(admin);
```

**✅ Pass Criteria**: Admin object returned with correct email

#### Test F3: Session Model State Machine

```bash
# In ts-node REPL
const Session = require('./src/models/session');

// Create session
const session = await Session.create('Test Session');
console.log(session.state); // Should be 'CREATED'

// Transition to ACTIVE
await Session.transitionState(session.id, 'CREATED', 'ACTIVE');
const active = await Session.findById(session.id);
console.log(active.state); // Should be 'ACTIVE'

// Try invalid transition (should fail)
try {
  await Session.transitionState(session.id, 'CREATED', 'ENDED');
} catch (e) {
  console.log('Correctly rejected invalid transition');
}
```

**✅ Pass Criteria**: Valid transitions work, invalid transitions rejected

#### Test F4: Token Generation

```bash
# In ts-node REPL
const TokenService = require('./src/services/token');

const token = TokenService.generateToken();
console.log('Token length:', token.length); // Should be 64 chars (256-bit hex)
console.log('Token format:', /^[a-f0-9]{64}$/.test(token)); // Should be true

const hash = TokenService.hashToken(token);
console.log('Hash length:', hash.length); // Should be 64 chars
console.log('Hash different from token:', hash !== token); // Should be true
```

**✅ Pass Criteria**: Token is 64-char hex, hash is deterministic and different

#### Test F5: Presence Hash Derivation

```bash
# In ts-node REPL
const PresenceService = require('./src/services/presence');

const token = 'abc123...'; // Sample token
const hash1 = PresenceService.derivePresenceHash(token);
const hash2 = PresenceService.derivePresenceHash(token);

console.log('Hash 1:', hash1);
console.log('Hash 2:', hash2);
console.log('Deterministic:', hash1 === hash2); // Should be true
console.log('Short format:', hash1.length <= 12); // Should be true for display
```

**✅ Pass Criteria**: Presence hash is deterministic and display-friendly

### Automated Tests

```bash
# Run all foundational unit tests
pnpm test:unit backend/tests/unit/

# Run with coverage
pnpm test:coverage

# Verify 80%+ coverage per Constitution Principle II
```

**✅ Pass Criteria**: All unit tests pass, coverage ≥80%

---

## Phase 3: User Story 1 Testing (Admin Session Management)

### Objective

Verify admin can create, start, and end sessions with proper state transitions and kernel lifecycle.

### Manual Tests

#### Test US1-1: Admin Login

```bash
# Test login endpoint
curl -X POST http://localhost:3001/api/v1/auth/login \
  -H "Content-Type: application/json" \
  -d '{
    "email": "admin@example.com",
    "password": "SecurePassword123!"
  }' \
  -c cookies.txt \
  -v

# Expected response:
# - Status: 200 OK
# - Set-Cookie header with JWT
# - Body: {"success": true, "admin": {"email": "admin@example.com"}}
```

**✅ Pass Criteria**: Login succeeds, JWT cookie set

#### Test US1-2: Create Session

```bash
# Create new session
curl -X POST http://localhost:3001/api/v1/admin/sessions \
  -H "Content-Type: application/json" \
  -b cookies.txt \
  -d '{"name": "MVP Test Session"}' \
  | jq

# Save session ID for next tests
export SESSION_ID="<id-from-response>"

# Expected response:
{
  "id": "uuid-here",
  "name": "MVP Test Session",
  "state": "CREATED",
  "createdAt": "2026-01-24T...",
  "kernelStatus": "NOT_CREATED"
}
```

**✅ Pass Criteria**: Session created with CREATED state, kernel NOT_CREATED

#### Test US1-3: List Sessions

```bash
# Get all sessions
curl http://localhost:3001/api/v1/admin/sessions \
  -b cookies.txt \
  | jq

# Expected: Array containing our session
```

**✅ Pass Criteria**: Session list includes newly created session

#### Test US1-4: Get Session Details

```bash
# Get specific session
curl http://localhost:3001/api/v1/admin/sessions/$SESSION_ID \
  -b cookies.txt \
  | jq

# Expected: Full session details with lifecycle array
{
  "id": "...",
  "name": "MVP Test Session",
  "state": "CREATED",
  "kernelStatus": "NOT_CREATED",
  "tokenCount": 0,
  "userCount": 0,
  "lifecycle": [
    {"state": "CREATED", "timestamp": "..."}
  ]
}
```

**✅ Pass Criteria**: Detailed session info with correct initial state

#### Test US1-5: Start Session

```bash
# Transition session to ACTIVE
curl -X POST http://localhost:3001/api/v1/admin/sessions/$SESSION_ID/start \
  -b cookies.txt \
  | jq

# Expected response:
{
  "id": "...",
  "state": "ACTIVE",
  "kernelStatus": "ACTIVE",
  "startedAt": "2026-01-24T..."
}

# Verify kernel created
curl http://localhost:3001/api/v1/admin/sessions/$SESSION_ID \
  -b cookies.txt \
  | jq '.kernelStatus'

# Expected: "ACTIVE"
```

**✅ Pass Criteria**: Session state is ACTIVE, kernel created and ACTIVE

#### Test US1-6: Try Invalid State Transition

```bash
# Try to start already active session
curl -X POST http://localhost:3001/api/v1/admin/sessions/$SESSION_ID/start \
  -b cookies.txt \
  -v

# Expected: 400 Bad Request with error message
```

**✅ Pass Criteria**: Invalid transition rejected with clear error

#### Test US1-7: End Session

```bash
# Transition session to ENDED
curl -X POST http://localhost:3001/api/v1/admin/sessions/$SESSION_ID/end \
  -b cookies.txt \
  | jq

# Expected response:
{
  "id": "...",
  "state": "ENDED",
  "kernelStatus": "DISSOLVED",
  "endedAt": "2026-01-24T..."
}

# Verify kernel dissolved
curl http://localhost:3001/api/v1/admin/sessions/$SESSION_ID \
  -b cookies.txt \
  | jq '.kernelStatus'

# Expected: "DISSOLVED"
```

**✅ Pass Criteria**: Session state is ENDED, kernel DISSOLVED

#### Test US1-8: View Lifecycle Timeline

```bash
# Get full session history
curl http://localhost:3001/api/v1/admin/sessions/$SESSION_ID \
  -b cookies.txt \
  | jq '.lifecycle'

# Expected: Array with all state transitions
[
  {"state": "CREATED", "timestamp": "..."},
  {"state": "ACTIVE", "timestamp": "..."},
  {"state": "ENDED", "timestamp": "..."}
]
```

**✅ Pass Criteria**: Complete lifecycle history with accurate timestamps

### Browser Tests

#### Test US1-9: Admin UI - Login Flow

1. Open browser: `http://localhost:3000/admin/login`
2. Enter credentials: `admin@example.com` / `SecurePassword123!`
3. Click "Login"
4. **Expected**: Redirect to session list page

**✅ Pass Criteria**: Login successful, redirected to dashboard

#### Test US1-10: Admin UI - Create Session

1. On session list page, click "Create Session"
2. Enter name: "Browser Test Session"
3. Click "Create"
4. **Expected**: New session appears in list with:
   - Gray indicator (CREATED state)
   - "Start" button visible
   - Token count: 0
   - User count: 0

**✅ Pass Criteria**: Session created and displayed correctly

#### Test US1-11: Admin UI - Start Session

1. Click "Start" button on created session
2. **Expected**:
   - Indicator turns green (ACTIVE)
   - Button changes to "End"
   - Kernel status shows "ACTIVE"
   - Started timestamp appears

**✅ Pass Criteria**: Session activated, UI updates correctly

#### Test US1-12: Admin UI - Session Details

1. Click on active session to view details
2. **Expected details page shows**:
   - Session name
   - Current state (ACTIVE)
   - Kernel status (ACTIVE)
   - Token count
   - User count
   - Lifecycle timeline with all transitions

**✅ Pass Criteria**: All session details displayed accurately

#### Test US1-13: Admin UI - End Session

1. On session detail page or list, click "End"
2. Confirm action (if confirmation dialog appears)
3. **Expected**:
   - Indicator turns red (ENDED)
   - "End" button disabled/hidden
   - Kernel status shows "DISSOLVED"
   - Ended timestamp appears

**✅ Pass Criteria**: Session ended, kernel dissolved, UI updated

### Automated Tests

```bash
# Run User Story 1 contract tests
pnpm test backend/tests/contract/auth.test.ts
pnpm test backend/tests/contract/sessions.test.ts

# Run User Story 1 integration tests
pnpm test backend/tests/integration/session-lifecycle.test.ts

# Run User Story 1 unit tests
pnpm test backend/tests/unit/kernel-manager.test.ts

# Run E2E for admin flow
pnpm test:e2e tests/e2e/admin-session-lifecycle.spec.ts
```

**✅ Pass Criteria**: All automated tests pass

---

## Phase 4: User Story 2 Testing (User Token & Join)

### Objective

Verify users can browse sessions, claim tokens, and join active sessions.

### Setup

Create a test session as admin:

```bash
# Login as admin
curl -X POST http://localhost:3001/api/v1/auth/login \
  -H "Content-Type: application/json" \
  -d '{"email": "admin@example.com", "password": "SecurePassword123!"}' \
  -c cookies.txt

# Create session
export SESSION_ID=$(curl -X POST http://localhost:3001/api/v1/admin/sessions \
  -H "Content-Type: application/json" \
  -b cookies.txt \
  -d '{"name": "User Test Session"}' \
  | jq -r '.id')

echo "Session ID: $SESSION_ID"
```

### Manual Tests

#### Test US2-1: Browse Public Sessions (CREATED)

```bash
# Get public session list (no auth required)
curl http://localhost:3001/api/v1/sessions | jq

# Expected: Array of sessions in CREATED or ACTIVE states
# ENDED sessions should NOT appear
[
  {
    "id": "...",
    "name": "User Test Session",
    "state": "CREATED",
    "createdAt": "..."
  }
]
```

**✅ Pass Criteria**: Only CREATED/ACTIVE sessions visible, no ENDED sessions

#### Test US2-2: Claim Token for CREATED Session

```bash
# Claim token (no auth required)
export TOKEN=$(curl -X POST http://localhost:3001/api/v1/sessions/$SESSION_ID/claim \
  -H "Content-Type: application/json" \
  | jq -r '.token')

echo "Token: $TOKEN"

# Expected response:
{
  "token": "64-char-hex-string",
  "sessionId": "...",
  "sessionName": "User Test Session",
  "sessionState": "CREATED",
  "message": "Token claimed. Session will activate soon."
}
```

**✅ Pass Criteria**: Token received, session state is CREATED

#### Test US2-3: Try Joining Before Session Active

```bash
# Try to join CREATED session (should fail)
curl -X POST http://localhost:3001/api/v1/sessions/$SESSION_ID/join \
  -H "Content-Type: application/json" \
  -H "Authorization: Bearer $TOKEN" \
  -v

# Expected: 400 Bad Request
# Message: "Session is not active yet"
```

**✅ Pass Criteria**: Join rejected for non-active session

#### Test US2-4: Start Session (Admin)

```bash
# Admin starts session
curl -X POST http://localhost:3001/api/v1/admin/sessions/$SESSION_ID/start \
  -b cookies.txt \
  | jq

# Expected: Session now ACTIVE
```

**✅ Pass Criteria**: Session transitioned to ACTIVE

#### Test US2-5: Join Active Session

```bash
# Join with claimed token
curl -X POST http://localhost:3001/api/v1/sessions/$SESSION_ID/join \
  -H "Content-Type: application/json" \
  -H "Authorization: Bearer $TOKEN" \
  | jq

# Expected response:
{
  "success": true,
  "sessionId": "...",
  "presenceHash": "abc123xyz",
  "websocketUrl": "ws://localhost:3001/ws/sessions/..."
}

# Save presence hash and WebSocket URL
export PRESENCE_HASH="<from-response>"
export WS_URL="<from-response>"
```

**✅ Pass Criteria**: Join successful, received presence hash and WebSocket URL

#### Test US2-6: Verify Token Marked as Joined

```bash
# Try joining again with same token
curl -X POST http://localhost:3001/api/v1/sessions/$SESSION_ID/join \
  -H "Content-Type: application/json" \
  -H "Authorization: Bearer $TOKEN" \
  -v

# Expected: 400 Bad Request (token already used)
# OR: Success with reconnection to existing conversation
# (Depends on implementation - check spec.md#FR-021)
```

**✅ Pass Criteria**: System handles duplicate join appropriately

#### Test US2-7: Claim Multiple Tokens

```bash
# Claim second token (simulating different user)
export TOKEN2=$(curl -X POST http://localhost:3001/api/v1/sessions/$SESSION_ID/claim \
  | jq -r '.token')

echo "Token 2: $TOKEN2"

# Verify tokens are different
test "$TOKEN" != "$TOKEN2" && echo "✓ Tokens are unique" || echo "✗ Tokens are identical!"

# Join with second token
curl -X POST http://localhost:3001/api/v1/sessions/$SESSION_ID/join \
  -H "Authorization: Bearer $TOKEN2" \
  | jq
```

**✅ Pass Criteria**: Each claim generates unique token, all can join

#### Test US2-8: Try Claiming Token for Active Session

```bash
# Claim token for already-active session
curl -X POST http://localhost:3001/api/v1/sessions/$SESSION_ID/claim \
  -H "Content-Type: application/json" \
  | jq

# Expected behavior per spec.md#FR-008:
# - Should FAIL (tokens only claimable in CREATED state)
# OR
# - Should succeed if spec allows claiming during ACTIVE
# (Check spec.md for clarification)
```

**✅ Pass Criteria**: Behavior matches spec requirement FR-008

#### Test US2-9: Verify User Count Updates

```bash
# Admin checks session details
curl http://localhost:3001/api/v1/admin/sessions/$SESSION_ID \
  -b cookies.txt \
  | jq '{userCount, tokenCount}'

# Expected: userCount incremented for each join
{
  "userCount": 2,
  "tokenCount": 2
}
```

**✅ Pass Criteria**: Counts accurately reflect claims and joins

### Browser Tests

#### Test US2-10: User UI - Browse Sessions

1. Open browser: `http://localhost:3002`
2. **Expected**: Session browser page showing:
   - List of CREATED and ACTIVE sessions
   - Session names
   - State indicators (gray for CREATED, green for ACTIVE)
   - "Claim Token" button for CREATED sessions
   - "Join" button for ACTIVE sessions (if user has token)

**✅ Pass Criteria**: Session list displays correctly

#### Test US2-11: User UI - Claim Token

1. Find a CREATED session
2. Click "Claim Token" button
3. **Expected**:
   - Success message: "Token claimed!"
   - Button changes to "Waiting for session to start..."
   - Token stored in browser (check localStorage/sessionStorage)

**✅ Pass Criteria**: Token claimed and stored

#### Test US2-12: User UI - Wait for Session Activation

1. Keep browser open on session with claimed token
2. In another tab/window: Login as admin and start the session
3. **Expected** (on user tab):
   - Session indicator changes from gray to green
   - Button changes from "Waiting..." to "Join Session"
   - Real-time update (polling or WebSocket notification)

**✅ Pass Criteria**: UI updates when session becomes active

#### Test US2-13: User UI - Join Session

1. Click "Join Session" button
2. **Expected**:
   - Redirect to chat interface
   - URL: `http://localhost:3002/chat/{sessionId}`
   - Chat interface loads
   - Presence hash displayed
   - Kernel status indicator shows "Kernel Active"

**✅ Pass Criteria**: Successfully joined and entered chat

#### Test US2-14: User UI - Join Without Token

1. Open new incognito/private browser window
2. Navigate to `http://localhost:3002`
3. Try to join an ACTIVE session without claiming token
4. **Expected**:
   - Error message: "You need a token to join this session"
   - Prevented from accessing chat interface

**✅ Pass Criteria**: Join blocked without valid token

### Automated Tests

```bash
# Run User Story 2 contract tests
pnpm test backend/tests/contract/public.test.ts
pnpm test backend/tests/contract/tokens.test.ts

# Run User Story 2 integration tests
pnpm test backend/tests/integration/token-flow.test.ts

# Run User Story 2 unit tests
pnpm test backend/tests/unit/token-service.test.ts

# Run E2E for user token flow
pnpm test:e2e tests/e2e/user-token-flow.spec.ts
```

**✅ Pass Criteria**: All automated tests pass

---

## Phase 5: User Story 3 Testing (Private AI Chat)

> **⚠️ NOT YET IMPLEMENTED**: This section is for future reference. User Story 3 (chat functionality) has not been implemented yet.
>
> **Current Status**: Phase 5 tasks (T065-T080) are pending implementation.
>
> **Use this section when**: You begin implementing the Extended MVP with chat features.

### Objective

Verify users can chat privately with AI, messages are isolated, and dissolution works correctly.

**Note**: This is part of the Extended MVP. Skip if testing current MVP (User Stories 1 & 2 only).

### Setup

```bash
# Create and start session, claim and join as user
# (Use steps from Phase 3 & 4)

export SESSION_ID="<from-previous-phase>"
export TOKEN="<from-previous-phase>"
export WS_URL="ws://localhost:3001/ws/sessions/$SESSION_ID?token=$TOKEN"
```

### Manual Tests

#### Test US3-1: WebSocket Connection

```bash
# Connect to WebSocket
wscat -c "$WS_URL"

# Expected: Connection established
# Server sends: CONNECTION_ACK message
{
  "type": "CONNECTION_ACK",
  "payload": {
    "sessionId": "...",
    "presenceHash": "...",
    "conversationHistory": []
  },
  "timestamp": "..."
}
```

**✅ Pass Criteria**: WebSocket connection succeeds, receives CONNECTION_ACK

#### Test US3-2: Send User Message

```bash
# In wscat, send message:
{
  "type": "USER_MESSAGE",
  "payload": {
    "messageId": "msg-001",
    "content": "Hello, AI!"
  },
  "timestamp": "2026-01-24T12:00:00.000Z"
}

# Expected server response (streaming):
# 1. MESSAGE_CHUNK (multiple times)
{
  "type": "MESSAGE_CHUNK",
  "payload": {
    "messageId": "msg-001-response",
    "chunk": "Hello! "
  }
}

# 2. MESSAGE_COMPLETE (final)
{
  "type": "MESSAGE_COMPLETE",
  "payload": {
    "messageId": "msg-001-response",
    "content": "Hello! How can I assist you today?",
    "finishedAt": "..."
  }
}
```

**✅ Pass Criteria**: AI responds with streamed message

#### Test US3-3: Send Follow-up Message (Context)

```bash
# Send another message
{
  "type": "USER_MESSAGE",
  "payload": {
    "messageId": "msg-002",
    "content": "What did I just say?"
  },
  "timestamp": "2026-01-24T12:00:10.000Z"
}

# Expected: AI response references previous message
# (e.g., "You said 'Hello, AI!'")
```

**✅ Pass Criteria**: AI has context from previous messages

#### Test US3-4: Conversation Isolation

```bash
# Open second WebSocket connection (different user)
export TOKEN2="<claim-new-token>"
wscat -c "ws://localhost:3001/ws/sessions/$SESSION_ID?token=$TOKEN2"

# Send message from user 2:
{
  "type": "USER_MESSAGE",
  "payload": {
    "messageId": "msg-003",
    "content": "Secret message from user 2"
  }
}

# On first connection (user 1): Should NOT receive any messages from user 2
# Verify: No MESSAGE_CHUNK or MESSAGE_COMPLETE with messageId "msg-003*"
```

**✅ Pass Criteria**: Users cannot see each other's messages

#### Test US3-5: Kernel Dissolution

```bash
# Keep both WebSocket connections open
# As admin, end the session:
curl -X POST http://localhost:3001/api/v1/admin/sessions/$SESSION_ID/end \
  -b cookies.txt

# Expected on BOTH WebSocket connections:
{
  "type": "KERNEL_DISSOLVED",
  "payload": {
    "sessionId": "...",
    "message": "This session has ended. Your conversation is gone."
  },
  "timestamp": "..."
}

# Connection closes with code 1000 (normal closure)
```

**✅ Pass Criteria**: Both users receive dissolution notification, connections close

#### Test US3-6: Measure Dissolution Timing

```bash
# Create script to measure dissolution time
cat > test-dissolution-timing.sh << 'EOF'
#!/bin/bash
START=$(date +%s%3N)
curl -X POST http://localhost:3001/api/v1/admin/sessions/$1/end -b cookies.txt
END=$(date +%s%3N)
DURATION=$((END - START))
echo "Dissolution took: ${DURATION}ms"
test $DURATION -lt 50 && echo "✓ PASS: <50ms" || echo "✗ FAIL: ≥50ms"
EOF

chmod +x test-dissolution-timing.sh
./test-dissolution-timing.sh $SESSION_ID
```

**✅ Pass Criteria**: Dissolution completes in <50ms (Constitution Principle IV)

### Browser Tests

#### Test US3-7: User UI - Chat Interface

1. Join session as user (from Phase 4)
2. **Expected chat interface**:
   - Message list (empty initially)
   - Input field at bottom
   - Send button
   - Kernel status: "Kernel Active" (green)
   - Presence hash displayed
   - No other user indicators

**✅ Pass Criteria**: Chat UI loads correctly

#### Test US3-8: User UI - Send Message

1. Type message: "What is 2+2?"
2. Click Send
3. **Expected**:
   - Message appears immediately (optimistic UI)
   - Typing indicator for AI
   - AI response streams in character-by-character
   - AI response finalizes when complete

**✅ Pass Criteria**: Message sent, AI responds with streaming effect

#### Test US3-9: User UI - Conversation History

1. Send multiple messages back and forth
2. Refresh browser page
3. **Expected**:
   - If token preserved: Conversation history restored
   - If token lost: New conversation starts (FR-022)

**✅ Pass Criteria**: Behavior matches token persistence strategy

#### Test US3-10: User UI - Dissolution Experience

1. While chatting, have admin end session
2. **Expected** (immediate UI changes):
   - Kernel status changes to "Kernel Dissolved" (red)
   - Large dissolution overlay appears
   - Message: "Your conversation is gone"
   - Input field disabled
   - Cannot send new messages

**✅ Pass Criteria**: Dissolution UI clear and immediate

#### Test US3-11: User UI - Privacy Indicators

1. While in chat, inspect UI
2. **Expected NOT visible**:
   - Other users' presence
   - Other users' message counts
   - Total user count in session
   - Any admin information

**✅ Pass Criteria**: No information about other users visible

### Automated Tests

```bash
# Run User Story 3 contract tests
pnpm test backend/tests/contract/chat.test.ts
pnpm test backend/tests/contract/websocket.test.ts

# Run User Story 3 integration tests
pnpm test backend/tests/integration/chat-flow.test.ts

# Run User Story 3 unit tests
pnpm test backend/tests/unit/ai-service.test.ts

# Run User Story 3 privacy tests
pnpm test backend/tests/privacy/conversation-isolation.test.ts

# Run E2E for chat and dissolution
pnpm test:e2e tests/e2e/chat-dissolution.spec.ts
```

**✅ Pass Criteria**: All automated tests pass

---

## Automated Test Execution

### Unit Tests

```bash
# Run all unit tests
pnpm test:unit

# Run specific test file
pnpm test:unit backend/tests/unit/token-service.test.ts

# Run with coverage
pnpm test:coverage

# Watch mode (re-run on file changes)
pnpm test:watch
```

### Integration Tests

```bash
# Run all integration tests
pnpm test:integration

# Run specific user story tests
pnpm test backend/tests/integration/session-lifecycle.test.ts
pnpm test backend/tests/integration/token-flow.test.ts
pnpm test backend/tests/integration/chat-flow.test.ts
```

### Contract Tests

```bash
# Verify API matches OpenAPI spec
pnpm test:contract

# Specific contract tests
pnpm test backend/tests/contract/auth.test.ts
pnpm test backend/tests/contract/sessions.test.ts
pnpm test backend/tests/contract/websocket.test.ts
```

### Privacy Tests

```bash
# Run privacy test suite
pnpm test:privacy

# Specific privacy tests
pnpm test backend/tests/privacy/conversation-isolation.test.ts
pnpm test backend/tests/privacy/admin-access.test.ts
pnpm test backend/tests/privacy/dissolution-timing.test.ts
```

### End-to-End Tests

```bash
# Ensure dev servers are running first
pnpm dev

# In another terminal:
pnpm test:e2e

# Run specific E2E test
pnpm test:e2e tests/e2e/admin-session-lifecycle.spec.ts

# Headless mode (CI)
pnpm test:e2e --headless

# Interactive mode (see browser)
pnpm test:e2e --headed
```

### Accessibility Tests

```bash
# Run WCAG 2.1 AA tests
pnpm test:e2e tests/e2e/accessibility.spec.ts

# Generate accessibility report
pnpm test:e2e --reporter=html
```

### All Tests

```bash
# Run complete test suite
pnpm test:all

# Expected output:
# ✓ Unit tests: XX/XX passed
# ✓ Integration tests: XX/XX passed
# ✓ Contract tests: XX/XX passed
# ✓ Privacy tests: XX/XX passed
# ✓ E2E tests: XX/XX passed
# ✓ Coverage: XX% (must be ≥80%)
```

---

## Integration Testing

> **MVP Note**: Journey 1 below includes chat and dissolution steps that are not yet implemented. For current MVP, focus on Journey 2 (session creation and token flow only).

### Full User Journey Tests

#### Journey 1: Admin Creates Session → User Joins → Chat → Dissolution

> **⚠️ PARTIAL**: Steps 1-5 work (MVP), steps 6+ require User Story 3 (Extended MVP)

```bash
#!/bin/bash
# full-journey-test.sh

set -e

echo "=== Journey 1: Full MVP Flow ==="

# 1. Admin login
echo "1. Admin login..."
curl -X POST http://localhost:3001/api/v1/auth/login \
  -H "Content-Type: application/json" \
  -d '{"email": "admin@example.com", "password": "SecurePassword123!"}' \
  -c cookies.txt -s > /dev/null

# 2. Admin creates session
echo "2. Creating session..."
SESSION_ID=$(curl -X POST http://localhost:3001/api/v1/admin/sessions \
  -H "Content-Type: application/json" \
  -b cookies.txt \
  -d '{"name": "Integration Test"}' -s | jq -r '.id')
echo "   Session ID: $SESSION_ID"

# 3. User claims token
echo "3. User claims token..."
TOKEN=$(curl -X POST http://localhost:3001/api/v1/sessions/$SESSION_ID/claim -s | jq -r '.token')
echo "   Token: ${TOKEN:0:16}..."

# 4. Admin starts session
echo "4. Admin starts session..."
curl -X POST http://localhost:3001/api/v1/admin/sessions/$SESSION_ID/start \
  -b cookies.txt -s > /dev/null

# 5. User joins session
echo "5. User joins session..."
JOIN_RESPONSE=$(curl -X POST http://localhost:3001/api/v1/sessions/$SESSION_ID/join \
  -H "Authorization: Bearer $TOKEN" -s)
PRESENCE=$(echo $JOIN_RESPONSE | jq -r '.presenceHash')
echo "   Presence hash: $PRESENCE"

# 6. Verify kernel active
echo "6. Verifying kernel..."
KERNEL_STATUS=$(curl http://localhost:3001/api/v1/admin/sessions/$SESSION_ID \
  -b cookies.txt -s | jq -r '.kernelStatus')
test "$KERNEL_STATUS" = "ACTIVE" && echo "   ✓ Kernel is ACTIVE" || echo "   ✗ Kernel not active!"

# 7. Admin ends session
echo "7. Ending session..."
curl -X POST http://localhost:3001/api/v1/admin/sessions/$SESSION_ID/end \
  -b cookies.txt -s > /dev/null

# 8. Verify kernel dissolved
echo "8. Verifying dissolution..."
KERNEL_STATUS=$(curl http://localhost:3001/api/v1/admin/sessions/$SESSION_ID \
  -b cookies.txt -s | jq -r '.kernelStatus')
test "$KERNEL_STATUS" = "DISSOLVED" && echo "   ✓ Kernel DISSOLVED" || echo "   ✗ Kernel still exists!"

echo "=== Journey 1: COMPLETE ==="
```

**✅ Pass Criteria**: All steps complete successfully

#### Journey 1b: MVP Flow Only (Without Chat)

> **✅ WORKS NOW**: This is the current MVP integration test

```bash
#!/bin/bash
# mvp-journey-test.sh

set -e

echo "=== MVP Journey: Admin Session + User Token Flow ==="

# 1. Admin login
echo "1. Admin login..."
curl -X POST http://localhost:3001/api/v1/auth/login \
  -H "Content-Type: application/json" \
  -d '{"email": "admin@example.com", "password": "SecurePassword123!"}' \
  -c cookies.txt -s > /dev/null

# 2. Admin creates session
echo "2. Creating session..."
SESSION_ID=$(curl -X POST http://localhost:3001/api/v1/admin/sessions \
  -H "Content-Type: application/json" \
  -b cookies.txt \
  -d '{"name": "MVP Test"}' -s | jq -r '.id')
echo "   Session ID: $SESSION_ID"

# 3. Verify session is CREATED
STATE=$(curl http://localhost:3001/api/v1/admin/sessions/$SESSION_ID \
  -b cookies.txt -s | jq -r '.state')
test "$STATE" = "CREATED" && echo "   ✓ Session is CREATED" || echo "   ✗ Wrong state: $STATE"

# 4. User claims token
echo "3. User claims token..."
TOKEN=$(curl -X POST http://localhost:3001/api/v1/sessions/$SESSION_ID/claim -s | jq -r '.token')
echo "   Token: ${TOKEN:0:16}..."

# 5. Verify session visible in public list
echo "4. Verifying public session list..."
PUBLIC_COUNT=$(curl http://localhost:3001/api/v1/sessions -s | jq 'length')
echo "   Public sessions: $PUBLIC_COUNT"

# 6. Admin starts session
echo "5. Admin starts session..."
curl -X POST http://localhost:3001/api/v1/admin/sessions/$SESSION_ID/start \
  -b cookies.txt -s > /dev/null

# 7. Verify session is ACTIVE
STATE=$(curl http://localhost:3001/api/v1/admin/sessions/$SESSION_ID \
  -b cookies.txt -s | jq -r '.state')
test "$STATE" = "ACTIVE" && echo "   ✓ Session is ACTIVE" || echo "   ✗ Wrong state: $STATE"

# 8. User joins session
echo "6. User joins session..."
JOIN_RESPONSE=$(curl -X POST http://localhost:3001/api/v1/sessions/$SESSION_ID/join \
  -H "Authorization: Bearer $TOKEN" -s)
PRESENCE=$(echo $JOIN_RESPONSE | jq -r '.presenceHash')
echo "   Presence hash: $PRESENCE"

# 9. Verify user count incremented
USER_COUNT=$(curl http://localhost:3001/api/v1/admin/sessions/$SESSION_ID \
  -b cookies.txt -s | jq -r '.userCount')
test "$USER_COUNT" -ge "1" && echo "   ✓ User count: $USER_COUNT" || echo "   ✗ User count is 0"

# 10. Admin ends session
echo "7. Admin ends session..."
curl -X POST http://localhost:3001/api/v1/admin/sessions/$SESSION_ID/end \
  -b cookies.txt -s > /dev/null

# 11. Verify session is ENDED
STATE=$(curl http://localhost:3001/api/v1/admin/sessions/$SESSION_ID \
  -b cookies.txt -s | jq -r '.state')
test "$STATE" = "ENDED" && echo "   ✓ Session is ENDED" || echo "   ✗ Wrong state: $STATE"

# 12. Verify session NOT in public list (ended sessions hidden)
echo "8. Verifying ended session hidden from public..."
SESSION_IN_LIST=$(curl http://localhost:3001/api/v1/sessions -s | jq ".[] | select(.id == \"$SESSION_ID\")")
test -z "$SESSION_IN_LIST" && echo "   ✓ Session correctly hidden" || echo "   ✗ Session still visible"

echo ""
echo "=== MVP Journey: COMPLETE ✅ ==="
```

**✅ Pass Criteria**: All steps complete successfully, session goes through full lifecycle

#### Journey 2: Multiple Users in Same Session

> **✅ WORKS NOW**: Current MVP supports this

```bash
#!/bin/bash
# multi-user-test.sh

echo "=== Journey 2: Multiple Users ==="

# Setup session (as admin)
SESSION_ID=$(# ... create and start session ...)

# User 1 claims and joins
TOKEN1=$(curl -X POST http://localhost:3001/api/v1/sessions/$SESSION_ID/claim -s | jq -r '.token')
curl -X POST http://localhost:3001/api/v1/sessions/$SESSION_ID/join \
  -H "Authorization: Bearer $TOKEN1" -s > /dev/null
echo "✓ User 1 joined"

# User 2 claims and joins
TOKEN2=$(curl -X POST http://localhost:3001/api/v1/sessions/$SESSION_ID/claim -s | jq -r '.token')
curl -X POST http://localhost:3001/api/v1/sessions/$SESSION_ID/join \
  -H "Authorization: Bearer $TOKEN2" -s > /dev/null
echo "✓ User 2 joined"

# User 3 claims and joins
TOKEN3=$(curl -X POST http://localhost:3001/api/v1/sessions/$SESSION_ID/claim -s | jq -r '.token')
curl -X POST http://localhost:3001/api/v1/sessions/$SESSION_ID/join \
  -H "Authorization: Bearer $TOKEN3" -s > /dev/null
echo "✓ User 3 joined"

# Verify user count
USER_COUNT=$(curl http://localhost:3001/api/v1/admin/sessions/$SESSION_ID \
  -b cookies.txt -s | jq -r '.userCount')
test "$USER_COUNT" = "3" && echo "✓ User count correct: $USER_COUNT" || echo "✗ Wrong count: $USER_COUNT"

echo "=== Journey 2: COMPLETE ==="
```

**✅ Pass Criteria**: Multiple users can join, count is accurate

---

## Privacy Verification

### Privacy Test Checklist

#### PV-1: No Conversation Data in Database

```bash
# Connect to database
psql $DATABASE_URL

# Check for any conversation-related tables (should NOT exist)
\dt *message*
\dt *conversation*

# Expected: No tables found

# Verify only allowed tables exist
\dt

# Expected tables ONLY:
# - admins
# - sessions
# - tokens
```

**✅ Pass Criteria**: No conversation data tables exist

#### PV-2: No Content in Logs

```bash
# Search logs for message content
grep -r "Hello" backend/logs/ && echo "✗ FAIL: Found message content in logs!" || echo "✓ PASS: No content in logs"

# Search logs for token values (should be hashed only)
grep -rE "[a-f0-9]{64}" backend/logs/ | grep -v "hash" && echo "✗ FAIL: Found token in logs!" || echo "✓ PASS: No tokens in logs"
```

**✅ Pass Criteria**: No message content or tokens in logs

#### PV-3: Admin Cannot Access Conversations

```bash
# Try to access conversation data as admin
curl http://localhost:3001/api/v1/admin/sessions/$SESSION_ID/conversations \
  -b cookies.txt

# Expected: 404 Not Found (route should not exist)

curl http://localhost:3001/api/v1/admin/sessions/$SESSION_ID/messages \
  -b cookies.txt

# Expected: 404 Not Found
```

**✅ Pass Criteria**: No admin API endpoints for conversation access

#### PV-4: Memory Cleanup After Dissolution

```bash
# Start memory profiling
node --inspect backend/src/index.js

# In Chrome DevTools (chrome://inspect):
# 1. Take heap snapshot
# 2. Create and start session
# 3. Have user join and chat
# 4. Take second heap snapshot
# 5. End session (dissolve kernel)
# 6. Force garbage collection (in DevTools)
# 7. Take third heap snapshot
# 8. Compare snapshots: Conversation data should be gone
```

**✅ Pass Criteria**: No conversation objects remain after dissolution + GC

#### PV-5: Token Opacity

```bash
# Generate token
TOKEN=$(curl -X POST http://localhost:3001/api/v1/sessions/$SESSION_ID/claim -s | jq -r '.token')

# Try to decode token (should contain NO user info)
echo $TOKEN | base64 -d 2>/dev/null && echo "✗ Token is base64-encoded!" || echo "✓ Token is opaque"

# Verify token is just random bytes
echo $TOKEN | grep -E "^[a-f0-9]{64}$" && echo "✓ Token is 256-bit hex" || echo "✗ Token format invalid"
```

**✅ Pass Criteria**: Token is random hex with no embedded data

#### PV-6: Presence Hash Does Not Reveal Identity

```bash
# Get two presence hashes for same user
# (Should be identical - deterministic)
HASH1=$(curl -X POST http://localhost:3001/api/v1/sessions/$SESSION_ID/join \
  -H "Authorization: Bearer $TOKEN" -s | jq -r '.presenceHash')

# Reconnect
HASH2=$(curl -X POST http://localhost:3001/api/v1/sessions/$SESSION_ID/join \
  -H "Authorization: Bearer $TOKEN" -s | jq -r '.presenceHash')

test "$HASH1" = "$HASH2" && echo "✓ Presence hash is deterministic" || echo "✗ Hash changed!"

# Verify hash contains no identifiable information
echo "Presence hash: $HASH1"
# Should be short alphanumeric string, not email/name/IP
```

**✅ Pass Criteria**: Presence hash is deterministic and opaque

---

## Performance Testing

### Load Tests

#### Load Test 1: 100 Concurrent Users per Session

```bash
# Install k6 load testing tool
# macOS: brew install k6
# Linux: sudo apt-get install k6

# Create load test script
cat > load-test-100-users.js << 'EOF'
import ws from 'k6/ws';
import { check } from 'k6';

export const options = {
  vus: 100,
  duration: '30s',
};

export default function () {
  const sessionId = __ENV.SESSION_ID;
  const token = __ENV.TOKEN;
  const url = `ws://localhost:3001/ws/sessions/${sessionId}?token=${token}`;

  const res = ws.connect(url, function (socket) {
    socket.on('open', () => {
      socket.send(JSON.stringify({
        type: 'USER_MESSAGE',
        payload: { messageId: `msg-${__VU}`, content: 'Load test message' }
      }));
    });

    socket.on('message', (data) => {
      const msg = JSON.parse(data);
      check(msg, { 'received response': (m) => m.type === 'MESSAGE_CHUNK' });
    });

    socket.setTimeout(() => socket.close(), 5000);
  });
}
EOF

# Run load test
export SESSION_ID="<active-session-id>"
export TOKEN="<claimed-token>"
k6 run load-test-100-users.js
```

**✅ Pass Criteria**:
- All 100 users connect successfully
- P95 latency <200ms
- No errors or dropped connections

#### Load Test 2: Memory Usage Under Load

```bash
# Monitor memory during load test
watch -n 1 'ps aux | grep node | grep -v grep | awk "{print \$6/1024\" MB\"}"'

# While running:
# - Create session with 100 users
# - Have all users send messages
# - Monitor memory usage

# Expected: Memory stays under 512MB per session
```

**✅ Pass Criteria**: Memory usage <512MB for 100 concurrent users

### Latency Tests

#### Latency Test 1: API Endpoints

```bash
# Create benchmark script
cat > benchmark-api.sh << 'EOF'
#!/bin/bash

echo "=== API Latency Benchmarks ==="

# Test POST /admin/sessions
echo "POST /admin/sessions:"
for i in {1..10}; do
  curl -w "%{time_total}s\n" -o /dev/null -s \
    -X POST http://localhost:3001/api/v1/admin/sessions \
    -H "Content-Type: application/json" \
    -b cookies.txt \
    -d '{"name": "Benchmark"}'
done | awk '{sum+=$1; count++} END {print "Average:", sum/count*1000, "ms"}'

# Test GET /sessions
echo "GET /sessions:"
for i in {1..10}; do
  curl -w "%{time_total}s\n" -o /dev/null -s \
    http://localhost:3001/api/v1/sessions
done | awk '{sum+=$1; count++} END {print "Average:", sum/count*1000, "ms"}'

EOF

chmod +x benchmark-api.sh
./benchmark-api.sh
```

**✅ Pass Criteria**: P95 latency <200ms for all API endpoints

#### Latency Test 2: WebSocket Message Round-Trip

```bash
# Test WebSocket latency
cat > ws-latency-test.js << 'EOF'
const WebSocket = require('ws');

const sessionId = process.env.SESSION_ID;
const token = process.env.TOKEN;
const ws = new WebSocket(`ws://localhost:3001/ws/sessions/${sessionId}?token=${token}`);

const latencies = [];

ws.on('open', () => {
  for (let i = 0; i < 10; i++) {
    const start = Date.now();
    ws.send(JSON.stringify({
      type: 'HEARTBEAT',
      timestamp: new Date().toISOString()
    }));

    ws.once('message', () => {
      const latency = Date.now() - start;
      latencies.push(latency);

      if (latencies.length === 10) {
        const avg = latencies.reduce((a, b) => a + b) / latencies.length;
        console.log(`Average latency: ${avg}ms`);
        ws.close();
      }
    });
  }
});
EOF

node ws-latency-test.js
```

**✅ Pass Criteria**: Average WebSocket latency <100ms

### Dissolution Performance Test

```bash
# Measure time from dissolution trigger to completion
cat > dissolution-benchmark.sh << 'EOF'
#!/bin/bash

# Create session with 10 users connected
# ... setup code ...

# Measure dissolution time
START=$(date +%s%N)
curl -X POST http://localhost:3001/api/v1/admin/sessions/$SESSION_ID/end -b cookies.txt -s
END=$(date +%s%N)

DURATION=$(( (END - START) / 1000000 ))
echo "Dissolution took: ${DURATION}ms"

test $DURATION -lt 50 && echo "✓ PASS" || echo "✗ FAIL"
EOF

./dissolution-benchmark.sh
```

**✅ Pass Criteria**: Dissolution completes in <50ms (Constitution Principle IV)

---

## Troubleshooting

### Common Issues

#### Issue 1: Database Connection Fails

**Symptoms**: `ECONNREFUSED` error when starting backend

**Solutions**:
```bash
# Verify PostgreSQL is running
pg_isready -h localhost -p 5432

# Check DATABASE_URL format
echo $DATABASE_URL
# Should be: postgresql://user:pass@host:port/dbname

# Test connection manually
psql $DATABASE_URL -c "SELECT 1"

# Restart PostgreSQL
docker-compose restart postgres
```

#### Issue 2: WebSocket Connection Refused

**Symptoms**: `Connection refused` when trying to connect WebSocket

**Solutions**:
```bash
# Verify backend is running
curl http://localhost:3001/health

# Check WebSocket endpoint
curl -i -N \
  -H "Connection: Upgrade" \
  -H "Upgrade: websocket" \
  http://localhost:3001/ws/sessions/test

# Verify token is valid
echo $TOKEN | wc -c  # Should be 64 characters

# Check session is ACTIVE
curl http://localhost:3001/api/v1/admin/sessions/$SESSION_ID \
  -b cookies.txt | jq '.state'
```

#### Issue 3: AI Responses Slow or Failing

**Symptoms**: Long wait for AI responses or timeout errors

**Solutions**:
```bash
# Verify OpenAI API key
echo $OPENAI_API_KEY | head -c 10
# Should start with "sk-"

# Test OpenAI API directly
curl https://api.openai.com/v1/chat/completions \
  -H "Authorization: Bearer $OPENAI_API_KEY" \
  -H "Content-Type: application/json" \
  -d '{
    "model": "gpt-4o-mini",
    "messages": [{"role": "user", "content": "test"}]
  }'

# Switch to faster model in .env
OPENAI_MODEL=gpt-4o-mini  # Instead of gpt-4o

# Check rate limits on OpenAI dashboard
```

#### Issue 4: Token Not Working After Claim

**Symptoms**: `Invalid token` error when trying to join

**Solutions**:
```bash
# Verify token format (64-char hex)
echo $TOKEN | grep -E "^[a-f0-9]{64}$" && echo "Valid" || echo "Invalid"

# Check if token was claimed for correct session
curl -X POST http://localhost:3001/api/v1/sessions/$SESSION_ID/join \
  -H "Authorization: Bearer $TOKEN" \
  -v

# Verify session is ACTIVE (tokens work only in ACTIVE sessions)
curl http://localhost:3001/api/v1/sessions/$SESSION_ID | jq '.state'

# Re-claim token if needed
TOKEN=$(curl -X POST http://localhost:3001/api/v1/sessions/$SESSION_ID/claim -s | jq -r '.token')
```

#### Issue 5: Memory Leak Detected

**Symptoms**: Backend memory usage grows continuously

**Solutions**:
```bash
# Enable memory profiling
NODE_OPTIONS='--inspect --expose-gc' pnpm dev

# Take heap snapshots in Chrome DevTools
# 1. Open chrome://inspect
# 2. Click "inspect" on Node process
# 3. Go to Memory tab
# 4. Take snapshot before/after operations
# 5. Compare to find retained objects

# Check for orphaned conversations
# - After dissolution, run gc() in DevTools console
# - Take heap snapshot
# - Search for "Conversation" or "Message" objects
# - Should be none
```

### Test Failures

#### If Unit Tests Fail

```bash
# Run specific test in isolation
pnpm test backend/tests/unit/failing-test.test.ts

# Run with verbose output
pnpm test backend/tests/unit/failing-test.test.ts --reporter=verbose

# Debug test in VS Code
# Add breakpoint in test file
# Run "Debug Test" from testing sidebar
```

#### If Integration Tests Fail

```bash
# Verify database is clean
pnpm db:reset
pnpm db:migrate

# Check test data setup
# Most integration tests should create their own test data

# Run with SQL query logging
DEBUG=knex:query pnpm test:integration
```

#### If E2E Tests Fail

```bash
# Run with headed browser (see what's happening)
pnpm test:e2e --headed

# Enable slow motion
pnpm test:e2e --headed --slow-mo=1000

# Take screenshots on failure (already enabled by default)
# Check: tests/e2e/screenshots/

# Enable trace for debugging
pnpm test:e2e --trace on
# View trace: npx playwright show-trace trace.zip
```

---

## Pre-Deployment Checklist

### MVP Readiness (User Stories 1 & 2)

Before considering the **current MVP** ready for deployment:

#### Functional Completeness

- [ ] **Phase 1-2**: All foundational infrastructure tests pass
- [ ] **User Story 1**: Admin can create, start, and end sessions
- [ ] **User Story 2**: Users can claim tokens and join sessions

#### MVP-Specific Validation

- [ ] Admin can login and logout
- [ ] Sessions transition through all states (CREATED → ACTIVE → ENDED)
- [ ] Kernel lifecycle works (NOT_CREATED → ACTIVE → DISSOLVED)
- [ ] Users can browse public sessions (only CREATED and ACTIVE visible)
- [ ] Token claiming works for CREATED sessions
- [ ] Users can join ACTIVE sessions with valid tokens
- [ ] Session counts (tokenCount, userCount) update correctly

### Extended MVP Readiness (+ User Story 3)

**Only complete this section when User Story 3 is implemented:**

- [ ] **User Story 3**: Users can chat privately with AI
- [ ] WebSocket connections establish successfully
- [ ] AI messages stream correctly
- [ ] Conversation history persists during session
- [ ] Multiple users can chat simultaneously without seeing each other's messages
- [ ] Dissolution broadcasts to all connected users

### Code Quality

- [ ] All TypeScript files use strict mode (no `any` types)
- [ ] No files exceed 300 lines (Constitution Principle I)
- [ ] No functions exceed 50 lines
- [ ] ESLint passes with no warnings: `pnpm lint`
- [ ] Prettier formatting applied: `pnpm format`

### Testing (MVP)

- [ ] Unit test coverage ≥80%: `pnpm test:coverage`
- [ ] Phase 1-2 foundation tests pass
- [ ] User Story 1 tests pass:
  - [ ] Contract tests: `backend/tests/contract/auth.test.ts`
  - [ ] Contract tests: `backend/tests/contract/sessions.test.ts`
  - [ ] Integration: `backend/tests/integration/session-lifecycle.test.ts`
- [ ] User Story 2 tests pass:
  - [ ] Contract tests: `backend/tests/contract/public.test.ts`
  - [ ] Contract tests: `backend/tests/contract/tokens.test.ts`
  - [ ] Integration: `backend/tests/integration/token-flow.test.ts`
- [ ] No TypeScript errors: `pnpm tsc --noEmit`
- [ ] Linting passes: `pnpm lint`

### Testing (Extended MVP - When Implemented)

- [ ] User Story 3 tests pass:
  - [ ] Contract tests: `backend/tests/contract/chat.test.ts`
  - [ ] WebSocket tests: `backend/tests/contract/websocket.test.ts`
  - [ ] Integration: `backend/tests/integration/chat-flow.test.ts`
  - [ ] Privacy: `backend/tests/privacy/conversation-isolation.test.ts`
- [ ] All E2E tests pass: `pnpm test:e2e`

### Privacy & Security (MVP)

- [ ] No token values in logs (grep audit passed)
- [ ] Token opacity verified (no embedded user data)
- [ ] Token hashing works correctly (plaintext tokens never stored)
- [ ] Admin authentication uses HTTP-only cookies
- [ ] No conversation-related tables in database (PV-1 verified)
- [ ] Session isolation: users can only join with valid tokens

### Privacy & Security (Extended MVP - When Chat Implemented)

- [ ] No message content in logs (grep audit passed)
- [ ] Admin cannot access conversation endpoints (404 verified)
- [ ] Memory cleanup after dissolution (heap dump verified)
- [ ] Conversation isolation verified (users can't see each other's messages)
- [ ] Presence hash derivation works (deterministic but opaque)

### Performance (MVP)

- [ ] API P95 latency <200ms (benchmark admin and public endpoints)
- [ ] Session state transitions complete quickly (<100ms)
- [ ] Database queries optimized (use EXPLAIN ANALYZE)
- [ ] Frontend loads quickly (basic Lighthouse check)
- [ ] No memory leaks in session management

### Performance (Extended MVP - When Chat Implemented)

- [ ] WebSocket latency <100ms (latency test passed)
- [ ] Dissolution time <50ms (benchmark passed)
- [ ] Memory usage <512MB per session with 100 users (load test passed)
- [ ] AI streaming performance acceptable
- [ ] Frontend TTI <3s on 3G (full Lighthouse CI passed)

### User Experience

- [ ] All state changes visible within 2 seconds
- [ ] Loading states for all async operations
- [ ] Error messages are clear and user-friendly
- [ ] Dissolution UI is immediate and unmistakable
- [ ] WCAG 2.1 AA compliance (accessibility tests passed)
- [ ] Responsive design works 320px to 4K

### Documentation

- [ ] README has setup instructions
- [ ] API documented with OpenAPI spec
- [ ] WebSocket protocol documented
- [ ] Environment variables documented in .env.example
- [ ] Troubleshooting guide available (this document)

### Deployment Readiness

- [ ] Docker build succeeds: `docker build -t iammai-sandbox .`
- [ ] Docker health check passes
- [ ] Startup time <10s (Constitution Principle IV)
- [ ] All environment variables documented
- [ ] Database migration process tested

---

## Summary

This testing guide provides comprehensive coverage for the IAMMAI Sandbox System at different stages of implementation.

### Current Implementation: MVP (User Stories 1 & 2) ✅

**What's Working**:
- Admin session lifecycle management (create, start, end)
- User token system and session joining
- State transitions and kernel lifecycle
- Database models and core services
- Admin and user frontends (basic flows)

**Testing Focus**:
1. ✅ **Foundation**: Database, models, services
2. ✅ **User Story 1**: Admin authentication and session management
3. ✅ **User Story 2**: Public session browsing and token claiming
4. ⚡ **Quick validation**: 30-minute MVP testing path (see [MVP Testing Path](#mvp-testing-path))

**Next Steps**:
- Implement User Story 3 (Private AI Chat) for Extended MVP
- Then proceed with dissolution UX, reconnection, and analytics

### Future Implementation: Extended MVP (+ User Story 3)

**When Implemented**:
- Private AI chat functionality
- Message streaming via WebSocket
- Conversation isolation
- Kernel dissolution experience
- Full privacy verification

**Testing Approach**:
1. **Start with MVP Path**: Use the 30-minute quick start validation
2. **Manual testing**: Step-by-step browser and API tests for implemented stories
3. **Automated testing**: Unit, integration, contract tests (already written for US1-2)
4. **Privacy verification**: Token hashing, no data leakage
5. **Performance testing**: API latency, state transition speed (load tests for later)

Follow this guide in order:
1. ✅ **Environment Setup** → Verify services running
2. ✅ **MVP Testing Path** → 30-minute validation for current implementation
3. ✅ **Phase 1-2 Tests** → Foundation verification
4. ✅ **Phase 3-4 Tests** → User Stories 1 & 2 (implemented)
5. ⏸️ **Phase 5+ Tests** → Future features (not yet implemented)
6. 📋 **Pre-Deployment Checklist** → Verify MVP readiness

### Key Principle

**Test what's implemented, document what's planned.**

This guide contains detailed testing procedures for all 6 user stories. Currently, only User Stories 1-2 are implemented. Use the [MVP Testing Path](#mvp-testing-path) to focus on what matters now, and reference later sections when implementing additional features.

---

**Questions or Issues?**

If tests fail unexpectedly:
1. Check [Troubleshooting](#troubleshooting) section
2. Verify environment setup is correct
3. Ensure all dependencies are installed
4. Check logs for detailed error messages

---

## Quick Reference: MVP vs Extended MVP

### What to Test NOW (Current MVP)

**Implemented Features** (User Stories 1 & 2):
- ✅ Admin login/logout
- ✅ Session creation (CREATED state)
- ✅ Session start (CREATED → ACTIVE)
- ✅ Session end (ACTIVE → ENDED)
- ✅ Kernel lifecycle (NOT_CREATED → ACTIVE → DISSOLVED)
- ✅ Public session browsing
- ✅ Token claiming
- ✅ User join flow
- ✅ Session counts (tokenCount, userCount)

**Test Commands**:
```bash
# Quick validation
pnpm test:unit backend/tests/unit/
pnpm test backend/tests/contract/auth.test.ts
pnpm test backend/tests/contract/sessions.test.ts
pnpm test backend/tests/contract/public.test.ts
pnpm test backend/tests/contract/tokens.test.ts
pnpm test backend/tests/integration/session-lifecycle.test.ts
pnpm test backend/tests/integration/token-flow.test.ts

# Manual testing
./tests/scripts/mvp-journey-test.sh
```

### What to Test LATER (Extended MVP)

**Not Yet Implemented** (User Story 3+):
- ❌ WebSocket connections
- ❌ AI chat messages
- ❌ Message streaming
- ❌ Conversation isolation
- ❌ Dissolution broadcasting
- ❌ Reconnection
- ❌ Analytics dashboards

**These sections are for future reference**:
- Phase 5: User Story 3 Testing (Private AI Chat)
- Phase 6-8: User Stories 4-6
- Full dissolution testing
- Full privacy verification
- Load testing (100 concurrent users)

### Testing Priority

1. **NOW**: [MVP Testing Path](#mvp-testing-path) (30 minutes)
2. **NOW**: Phases 1-4 automated tests
3. **NOW**: MVP integration journey
4. **LATER**: Phase 5+ when implementing chat
5. **LATER**: Full E2E, load, and stress testing

Happy testing! 🧪
