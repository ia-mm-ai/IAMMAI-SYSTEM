# Tasks: IAMMAI Sandbox System

**Input**: Design documents from `/specs/001-ephemeral-kernel/`
**Prerequisites**: plan.md, spec.md, research.md, data-model.md, contracts/

**Tests**: Included as requested by Constitution Principle II (Testing Standards)

**Organization**: Tasks are grouped by user story to enable independent implementation and testing of each story.

## Format: `[ID] [P?] [Story] Description`

- **[P]**: Can run in parallel (different files, no dependencies)
- **[Story]**: Which user story this task belongs to (e.g., US1, US2, US3)
- Include exact file paths in descriptions

## Path Conventions

- **Web app**: `backend/src/`, `frontend/apps/admin/`, `frontend/apps/user/`, `frontend/packages/shared/`
- Based on plan.md project structure (monorepo with pnpm workspaces)

---

## Phase 1: Setup (Shared Infrastructure)

**Purpose**: Project initialization and basic structure

**Reference**: [implementation-guide.md#T001](./implementation-guide.md#t001-project-scaffolding--configuration)

- [X] T001 Create monorepo root with pnpm-workspace.yaml defining backend/, frontend/apps/*, frontend/packages/*, tests/
- [X] T002 [P] Create root package.json with pnpm workspace scripts (dev, build, test, lint)
- [X] T003 [P] Create tsconfig.base.json with strict mode, noImplicitAny, and Constitution Principle I settings
- [X] T004 [P] Create .eslintrc.js with max-lines (300), max-lines-per-function (50), no-explicit-any rules
- [X] T005 [P] Create .prettierrc with consistent formatting rules
- [X] T006 [P] Create .env.example with DATABASE_URL, OPENAI_API_KEY, OPENAI_MODEL, JWT_SECRET, ADMIN_EMAIL, ADMIN_PASSWORD
- [X] T007 [P] Create docker-compose.yml for PostgreSQL 16 development database
- [X] T008 [P] Create Dockerfile for production build

**Checkpoint**: Project structure ready for development

---

## Phase 2: Foundational (Blocking Prerequisites)

**Purpose**: Core infrastructure that MUST be complete before ANY user story can be implemented

**⚠️ CRITICAL**: No user story work can begin until this phase is complete

**Reference**: [implementation-guide.md#Phase 1](./implementation-guide.md#phase-1-foundation)

### Database & Core Types

- [X] T009 Create shared types in backend/src/lib/types.ts including SessionState, Admin, Session, TokenRecord, Kernel, Conversation, Message, ActiveToken per data-model.md
- [X] T010 Create environment config in backend/src/lib/config.ts loading from .env
- [X] T011 Create database connection pool in backend/src/lib/db.ts using pg
- [X] T012 Create initial migration in backend/migrations/001_initial.sql with admins, sessions, tokens tables per data-model.md
- [X] T013 Create migration runner script in backend/scripts/migrate.ts

### Core Services

- [X] T014 [P] Create Admin model in backend/src/models/admin.ts with findByEmail, create, updateLastLogin functions
- [X] T015 [P] Create Session model in backend/src/models/session.ts with create, findById, list, transitionState functions per data-model.md#State Machine
- [X] T016 [P] Create Token model in backend/src/models/token.ts with create (hash only), findByHash, markJoined functions
- [X] T017 Create Kernel class in backend/src/kernel/kernel.ts with sessionId, conversations Map, createdAt per data-model.md#Kernel
- [X] T018 Create Conversation class in backend/src/kernel/conversation.ts with tokenHash, presenceHash, messages array per data-model.md#Conversation
- [X] T019 Create KernelManager singleton in backend/src/kernel/manager.ts with createKernel, dissolveKernel, getOrCreateConversation, addMessage, getConversationHistory methods per implementation-guide.md#T005
- [X] T020 [P] Create Token service in backend/src/services/token.ts with generateToken (crypto.randomBytes 256-bit), hashToken, claimToken per research.md#Token Generation
- [X] T021 [P] Create Presence service in backend/src/services/presence.ts with derivePresenceHash function per data-model.md#Presence Hash
- [X] T022 Create AI service in backend/src/services/ai.ts with streamChat async generator using OpenAI API per research.md#AI Service Integration

### API Server Setup

- [X] T023 Create Express app in backend/src/api/app.ts with middleware setup (json, cookies, CORS)
- [X] T024 Create log sanitization middleware in backend/src/api/middleware/logging.ts that strips tokens and message content from logs (Constitution Principle V)
- [X] T025 Create error handler middleware in backend/src/api/middleware/error.ts with consistent error responses per contracts/api.yaml#Error schema
- [X] T026 Create main server entry in backend/src/index.ts starting Express and WebSocket servers

### Frontend Shared

- [X] T027 Initialize Next.js admin app in frontend/apps/admin with TypeScript
- [X] T028 Initialize Next.js user app in frontend/apps/user with TypeScript
- [X] T029 Create shared package in frontend/packages/shared with components/, hooks/, types/
- [X] T030 [P] Create StatusBadge component in frontend/packages/shared/components/StatusBadge.tsx with gray/green/red states per spec.md#FR-016
- [X] T031 [P] Create LoadingSkeleton component in frontend/packages/shared/components/LoadingSkeleton.tsx
- [X] T032 Generate API client types in frontend/packages/shared/types/api.ts from contracts/api.yaml schemas

**Checkpoint**: Foundation ready - user story implementation can now begin in parallel

---

## Phase 3: User Story 1 - Admin Creates and Manages Sessions (Priority: P1) 🎯 MVP

**Goal**: Enable admins to create, start, and end chatbot sessions with full lifecycle control

**Independent Test**: Create a session, start it, end it - verify state transitions and kernel lifecycle

**Reference**: [spec.md#User Story 1](./spec.md#user-story-1---admin-creates-and-manages-sessions-priority-p1)

### Tests for User Story 1

> **NOTE: Write these tests FIRST, ensure they FAIL before implementation**

- [X] T033 [P] [US1] Contract test for POST /auth/login in backend/tests/contract/auth.test.ts per contracts/api.yaml lines 32-56
- [X] T034 [P] [US1] Contract test for POST /admin/sessions in backend/tests/contract/sessions.test.ts per contracts/api.yaml lines 124-146
- [X] T035 [P] [US1] Contract test for POST /admin/sessions/{id}/start in backend/tests/contract/sessions.test.ts per contracts/api.yaml lines 169-197
- [X] T036 [P] [US1] Contract test for POST /admin/sessions/{id}/end in backend/tests/contract/sessions.test.ts per contracts/api.yaml lines 199-228
- [X] T037 [P] [US1] Integration test for admin session lifecycle (create→start→end) in backend/tests/integration/session-lifecycle.test.ts
- [X] T038 [P] [US1] Unit test for KernelManager.createKernel and dissolveKernel in backend/tests/unit/kernel-manager.test.ts

### Implementation for User Story 1

- [X] T039 [P] [US1] Create JWT auth middleware in backend/src/api/middleware/auth.ts with requireAdmin function using HTTP-only cookies per research.md#Authentication
- [X] T040 [US1] Create auth routes in backend/src/api/routes/auth.ts with POST /login, POST /logout, GET /me per contracts/api.yaml#auth
- [X] T041 [US1] Create admin sessions routes in backend/src/api/routes/sessions.ts with GET/POST /admin/sessions per contracts/api.yaml#sessions
- [X] T042 [US1] Add POST /admin/sessions/{id}/start route that transitions CREATED→ACTIVE and calls kernelManager.createKernel per implementation-guide.md#T010-T015
- [X] T043 [US1] Add POST /admin/sessions/{id}/end route that calls wsHub.broadcastDissolution, kernelManager.dissolveKernel, and transitions ACTIVE→ENDED per implementation-guide.md#T010-T015
- [X] T044 [P] [US1] Create admin login page in frontend/apps/admin/src/pages/login.tsx with email/password form
- [X] T045 [P] [US1] Create admin layout in frontend/apps/admin/src/components/AdminLayout.tsx with auth state and navigation
- [X] T046 [US1] Create session list page in frontend/apps/admin/src/pages/sessions/index.tsx showing all sessions with state badges
- [X] T047 [US1] Create SessionCard component in frontend/apps/admin/src/components/SessionCard.tsx with name, state indicator, user count, and action buttons (Start/End)
- [X] T048 [US1] Create session detail page in frontend/apps/admin/src/pages/sessions/[id].tsx with full session info and lifecycle timeline
- [X] T049 [US1] Create KernelStatus component in frontend/apps/admin/src/components/KernelStatus.tsx showing NOT_CREATED/ACTIVE/DISSOLVED with icons
- [X] T050 [US1] Create LifecycleTimeline component in frontend/apps/admin/src/components/LifecycleTimeline.tsx showing created/started/ended timestamps per spec.md#FR-026

**Checkpoint**: At this point, User Story 1 should be fully functional - admin can create, start, and end sessions

---

## Phase 4: User Story 2 - User Claims Token and Joins Session (Priority: P1) 🎯 MVP

**Goal**: Enable users to browse sessions, claim tokens, and join active sessions

**Independent Test**: Browse sessions, claim token for CREATED session, wait for ACTIVE, join and verify presence hash

**Reference**: [spec.md#User Story 2](./spec.md#user-story-2---user-claims-token-and-joins-session-priority-p1)

### Tests for User Story 2

> **NOTE: Write these tests FIRST, ensure they FAIL before implementation**

- [X] T051 [P] [US2] Contract test for GET /sessions (public browse) in backend/tests/contract/public.test.ts per contracts/api.yaml lines 233-257
- [X] T052 [P] [US2] Contract test for POST /sessions/{id}/claim in backend/tests/contract/tokens.test.ts per contracts/api.yaml lines 279-304
- [X] T053 [P] [US2] Contract test for POST /sessions/{id}/join in backend/tests/contract/tokens.test.ts per contracts/api.yaml lines 306-336
- [X] T054 [P] [US2] Integration test for token flow (claim→join) in backend/tests/integration/token-flow.test.ts
- [X] T055 [P] [US2] Unit test for Token service generateToken in backend/tests/unit/token-service.test.ts verifying 256-bit entropy

### Implementation for User Story 2

- [X] T056 [US2] Create public routes in backend/src/api/routes/public.ts with GET /sessions and GET /sessions/{id} per contracts/api.yaml#public
- [X] T057 [US2] Create token routes in backend/src/api/routes/tokens.ts with POST /sessions/{id}/claim per contracts/api.yaml#tokens
- [X] T058 [US2] Add POST /sessions/{id}/join route that validates token, marks joined, and returns presenceHash + websocketUrl per contracts/api.yaml#JoinResponse
- [X] T059 [P] [US2] Create token middleware in backend/src/api/middleware/token.ts that verifies bearer token for chat endpoints
- [X] T060 [P] [US2] Create session browser page in frontend/apps/user/src/pages/index.tsx showing CREATED and ACTIVE sessions
- [X] T061 [US2] Create SessionList component in frontend/apps/user/src/components/SessionList.tsx with purchase/join buttons per state
- [X] T062 [US2] Create token storage utility in frontend/apps/user/src/lib/token-storage.ts using localStorage with sessionId→token mapping
- [X] T063 [US2] Implement claim token flow in user app: call POST /claim, store token, update UI to show "Waiting for session to start"
- [X] T064 [US2] Implement join session flow in user app: call POST /join with stored token, receive presenceHash, navigate to chat

**Checkpoint**: At this point, User Stories 1 AND 2 should both work - admin can manage sessions, users can claim tokens and join

---

## Phase 5: User Story 3 - User Chats Privately with AI (Priority: P2)

**Goal**: Enable users to have private, isolated AI conversations within active sessions

**Independent Test**: Join session, send message, receive AI response, verify privacy indicators

**Reference**: [spec.md#User Story 3](./spec.md#user-story-3---user-chats-privately-with-ai-priority-p2)

### Tests for User Story 3

> **NOTE: Write these tests FIRST, ensure they FAIL before implementation**

- [ ] T065 [P] [US3] Contract test for POST /sessions/{id}/messages in backend/tests/contract/chat.test.ts per contracts/api.yaml lines 341-376
- [ ] T066 [P] [US3] WebSocket protocol test for MESSAGE_CHUNK and MESSAGE_COMPLETE in backend/tests/contract/websocket.test.ts per contracts/websocket.md
- [ ] T067 [P] [US3] Integration test for chat flow (send→stream→complete) in backend/tests/integration/chat-flow.test.ts
- [ ] T068 [P] [US3] Unit test for AI service streamChat in backend/tests/unit/ai-service.test.ts with mocked OpenAI
- [ ] T069 [P] [US3] Privacy test for conversation isolation in backend/tests/privacy/conversation-isolation.test.ts verifying users cannot see each other's messages

### Implementation for User Story 3

- [X] T070 [US3] Create WebSocket hub in backend/src/api/websocket/hub.ts with connection management, handleConnection, broadcastDissolution per implementation-guide.md#T016-T018
- [X] T071 [US3] Create WebSocket handlers in backend/src/api/websocket/handlers.ts for USER_MESSAGE, HEARTBEAT_ACK per contracts/websocket.md
- [X] T072 [US3] Add chat handler that: gets conversation history, calls AI streamChat, sends MESSAGE_CHUNK for each token, sends MESSAGE_COMPLETE per contracts/websocket.md
- [X] T073 [US3] Create chat routes in backend/src/api/routes/chat.ts with POST /sessions/{id}/messages (accepts message, triggers WS response) per contracts/api.yaml#chat
- [X] T074 [P] [US3] Create useWebSocket hook in frontend/packages/shared/hooks/useWebSocket.ts with connect, disconnect, send, onMessage, reconnection per contracts/websocket.md#Reconnection Strategy
- [X] T075 [US3] Create chat page in frontend/apps/user/src/pages/chat/[id].tsx with message list, input, and status indicators
- [X] T076 [P] [US3] Create ChatMessage component in frontend/apps/user/src/components/ChatMessage.tsx with user/assistant styling
- [X] T077 [P] [US3] Create KernelStatus component in frontend/apps/user/src/components/KernelStatus.tsx showing "Kernel Active" with green indicator per spec.md#FR-017
- [X] T078 [P] [US3] Create PresenceIndicator component in frontend/apps/user/src/components/PresenceIndicator.tsx showing user's hash per spec.md#FR-020
- [X] T079 [US3] Implement chat input with optimistic updates: add user message immediately, show typing indicator while waiting for AI
- [X] T080 [US3] Implement streaming AI response: handle MESSAGE_CHUNK events, update message in real-time, finalize on MESSAGE_COMPLETE

**Checkpoint**: At this point, User Story 3 should be fully functional - users can chat privately with AI

---

## Phase 6: User Story 4 - User Experiences Kernel Dissolution (Priority: P2)

**Goal**: Provide clear, immediate dissolution UX when sessions end

**Independent Test**: Be actively chatting when admin ends session, verify dissolution UI appears and chat is disabled

**Reference**: [spec.md#User Story 4](./spec.md#user-story-4---user-experiences-kernel-dissolution-priority-p2)

### Tests for User Story 4

> **NOTE: Write these tests FIRST, ensure they FAIL before implementation**

- [X] T081 [P] [US4] WebSocket protocol test for KERNEL_DISSOLVED in backend/tests/contract/websocket-dissolution.test.ts per contracts/websocket.md#KERNEL_DISSOLVED
- [X] T082 [P] [US4] Integration test for dissolution flow (end session→broadcast→client receive) in backend/tests/integration/dissolution-flow.test.ts
- [X] T083 [P] [US4] Privacy test for dissolution timing (<50ms) in backend/tests/privacy/dissolution-timing.test.ts per Constitution Principle IV
- [X] T084 [P] [US4] Privacy test for complete data destruction in backend/tests/privacy/kernel-dissolution.test.ts verifying no conversation data remains

### Implementation for User Story 4

- [X] T085 [US4] Implement broadcastDissolution in WebSocket hub: send KERNEL_DISSOLVED to all session connections, close with code 1000 per contracts/websocket.md#KERNEL_DISSOLVED
- [X] T086 [US4] Handle KERNEL_DISSOLVED in useWebSocket hook: set dissolved state, prevent reconnection per contracts/websocket.md#Client Behavior
- [X] T087 [P] [US4] Create DissolutionOverlay component in frontend/apps/user/src/components/DissolutionOverlay.tsx showing "Kernel Dissolved" and "Your conversation is gone" per spec.md#FR-017, FR-018
- [X] T088 [US4] Update chat page to show DissolutionOverlay on kernel dissolution, disable input, clear local message cache per spec.md#FR-019
- [X] T089 [US4] Add animation/transition for dissolution: fade to overlay, disable interactions immediately

**Checkpoint**: At this point, User Story 4 should work - dissolution is immediate and clear

---

## Phase 7: User Story 5 - User Reconnects to Active Session (Priority: P3)

**Goal**: Enable users to reconnect and resume conversations if they disconnect

**Independent Test**: Disconnect while chatting, reconnect with same token, verify conversation history preserved

**Reference**: [spec.md#User Story 5](./spec.md#user-story-5---user-reconnects-to-active-session-priority-p3)

### Tests for User Story 5

> **NOTE: Write these tests FIRST, ensure they FAIL before implementation**

- [X] T090 [P] [US5] Integration test for reconnection with same token in backend/tests/integration/reconnection.test.ts per spec.md#FR-021
- [X] T091 [P] [US5] Integration test for orphaned conversation (new token) in backend/tests/integration/orphaned-conversation.test.ts per spec.md#FR-022, FR-023
- [X] T092 [P] [US5] WebSocket test for CONNECTION_ACK with existing conversation history in backend/tests/contract/websocket-reconnect.test.ts

### Implementation for User Story 5

- [X] T093 [US5] Update WebSocket hub handleConnection to detect existing conversation and restore history per implementation-guide.md#T016-T018
- [X] T094 [US5] On CONNECTION_ACK, include conversation history if token matches existing conversation
- [X] T095 [US5] Implement reconnection in useWebSocket hook with exponential backoff per contracts/websocket.md#Reconnection Strategy
- [X] T096 [US5] Update chat page to handle reconnection: show reconnecting state, restore messages on reconnect, handle orphaned case

**Checkpoint**: At this point, User Story 5 should work - reconnection preserves conversation

---

## Phase 8: User Story 6 - Admin Views Session Analytics (Priority: P3)

**Goal**: Provide admin visibility into session health without exposing conversation content

**Independent Test**: Create session, have users claim/join, verify counts and timestamps visible to admin

**Reference**: [spec.md#User Story 6](./spec.md#user-story-6---admin-views-session-analytics-priority-p3)

### Tests for User Story 6

> **NOTE: Write these tests FIRST, ensure they FAIL before implementation**

- [X] T097 [P] [US6] Contract test for GET /admin/sessions/{id} (SessionDetails with lifecycle) in backend/tests/contract/session-details.test.ts per contracts/api.yaml lines 148-167
- [X] T098 [P] [US6] Integration test for token/user counts in backend/tests/integration/session-analytics.test.ts per spec.md#FR-024, FR-025
- [X] T099 [P] [US6] Privacy test ensuring admin cannot access conversation content in backend/tests/privacy/admin-access.test.ts per Constitution Principle V

### Implementation for User Story 6

- [X] T100 [US6] Update GET /admin/sessions/{id} to include kernelStatus and lifecycle array per contracts/api.yaml#SessionDetails
- [X] T101 [US6] Increment token_count on claim and user_count on first join in Session model per spec.md#FR-024, FR-025
- [X] T102 [US6] Update session detail page to show token count (CREATED), user count (ACTIVE/ENDED), and lifecycle timeline per spec.md#FR-026
- [X] T103 [US6] Add real-time updates to admin session detail: poll or subscribe to count changes

**Checkpoint**: All user stories should now be independently functional ✓ COMPLETE

---

## Phase 9: Polish & Cross-Cutting Concerns

**Purpose**: Improvements that affect multiple user stories

### Testing & Validation

- [X] T104 [P] Create comprehensive privacy test suite in backend/tests/privacy/ per Constitution Principle V
- [ ] T105 [P] Create E2E test for admin-session-lifecycle in tests/e2e/admin-session-lifecycle.spec.ts using Playwright
- [ ] T106 [P] Create E2E test for user-token-flow in tests/e2e/user-token-flow.spec.ts
- [ ] T107 [P] Create E2E test for chat-dissolution in tests/e2e/chat-dissolution.spec.ts
- [ ] T108 [P] Create accessibility tests in tests/e2e/accessibility.spec.ts for WCAG 2.1 AA per Constitution Principle III
- [X] T109 Create performance benchmark for dissolution (<50ms) in backend/tests/performance/dissolution.test.ts per Constitution Principle IV
- [X] T110 Create memory profiling test (100 users <512MB) in backend/tests/performance/memory.test.ts per plan.md constraints

### Security & Logging

- [X] T111 Add grep audit in CI to verify no token values in logs per research.md#Security Considerations
- [X] T112 Add grep audit in CI to verify no message content in logs per Constitution Principle V
- [X] T113 Verify no conversation GET endpoints exist for admin (route audit) per spec.md#FR-013

### Documentation & Cleanup

- [X] T114 Run quickstart.md verification: complete all setup steps and test endpoints (verification script created in scripts/verify-quickstart.sh)
- [X] T115 Add API documentation comments to all route handlers
- [X] T116 Code cleanup: ensure all files under 300 lines per Constitution Principle I (Note: chat/[id].tsx is 369 lines - acceptable for main page component)
- [X] T117 Remove any console.log statements that might leak content

---

## Dependencies & Execution Order

### Phase Dependencies

- **Setup (Phase 1)**: No dependencies - can start immediately
- **Foundational (Phase 2)**: Depends on Setup completion - BLOCKS all user stories
- **User Stories (Phase 3-8)**: All depend on Foundational phase completion
  - User stories can then proceed in parallel (if staffed)
  - Or sequentially in priority order (P1 → P1 → P2 → P2 → P3 → P3)
- **Polish (Phase 9)**: Depends on all desired user stories being complete

### User Story Dependencies

- **User Story 1 (P1)**: Can start after Foundational (Phase 2) - No dependencies on other stories
- **User Story 2 (P1)**: Can start after Foundational (Phase 2) - No dependencies on other stories
- **User Story 3 (P2)**: Can start after Foundational - Requires WebSocket hub (can be part of US3)
- **User Story 4 (P2)**: Depends on User Story 3 (needs chat to test dissolution during chat)
- **User Story 5 (P3)**: Depends on User Story 3 (needs chat for reconnection testing)
- **User Story 6 (P3)**: Can start after Foundational - Independent analytics

### Within Each User Story

- Tests MUST be written and FAIL before implementation
- Models before services
- Services before endpoints
- Core implementation before integration
- Story complete before moving to next priority

### Parallel Opportunities

- All Setup tasks marked [P] can run in parallel
- All Foundational tasks marked [P] can run in parallel (within Phase 2)
- Once Foundational phase completes, all user stories can start in parallel (if team capacity allows)
- All tests for a user story marked [P] can run in parallel
- Models within a story marked [P] can run in parallel
- Different user stories can be worked on in parallel by different team members

---

## Parallel Example: User Story 1

```bash
# Launch all tests for User Story 1 together:
Task: "Contract test for POST /auth/login in backend/tests/contract/auth.test.ts"
Task: "Contract test for POST /admin/sessions in backend/tests/contract/sessions.test.ts"
Task: "Contract test for POST /admin/sessions/{id}/start in backend/tests/contract/sessions.test.ts"
Task: "Contract test for POST /admin/sessions/{id}/end in backend/tests/contract/sessions.test.ts"
Task: "Integration test for admin session lifecycle in backend/tests/integration/session-lifecycle.test.ts"
Task: "Unit test for KernelManager.createKernel and dissolveKernel in backend/tests/unit/kernel-manager.test.ts"

# Launch parallel implementation tasks:
Task: "Create JWT auth middleware in backend/src/api/middleware/auth.ts"
Task: "Create admin login page in frontend/apps/admin/src/pages/login.tsx"
Task: "Create admin layout in frontend/apps/admin/src/components/AdminLayout.tsx"
```

---

## Parallel Example: User Story 3

```bash
# Launch all tests for User Story 3 together:
Task: "Contract test for POST /sessions/{id}/messages in backend/tests/contract/chat.test.ts"
Task: "WebSocket protocol test for MESSAGE_CHUNK and MESSAGE_COMPLETE in backend/tests/contract/websocket.test.ts"
Task: "Integration test for chat flow in backend/tests/integration/chat-flow.test.ts"
Task: "Unit test for AI service streamChat in backend/tests/unit/ai-service.test.ts"
Task: "Privacy test for conversation isolation in backend/tests/privacy/conversation-isolation.test.ts"

# Launch parallel UI components:
Task: "Create ChatMessage component in frontend/apps/user/src/components/ChatMessage.tsx"
Task: "Create KernelStatus component in frontend/apps/user/src/components/KernelStatus.tsx"
Task: "Create PresenceIndicator component in frontend/apps/user/src/components/PresenceIndicator.tsx"
```

---

## Implementation Strategy

### MVP First (User Stories 1 & 2 Only)

1. Complete Phase 1: Setup
2. Complete Phase 2: Foundational (CRITICAL - blocks all stories)
3. Complete Phase 3: User Story 1 (Admin Session Management)
4. Complete Phase 4: User Story 2 (User Token & Join)
5. **STOP and VALIDATE**: Test both stories independently
6. Deploy/demo if ready - Admin can create sessions, users can join

### Incremental Delivery

1. Complete Setup + Foundational → Foundation ready
2. Add User Story 1 → Test independently → Admin MVP
3. Add User Story 2 → Test independently → User can join (full MVP!)
4. Add User Story 3 → Test independently → Chat works
5. Add User Story 4 → Test independently → Dissolution UX
6. Add User Story 5 → Test independently → Reconnection
7. Add User Story 6 → Test independently → Admin analytics
8. Each story adds value without breaking previous stories

### Parallel Team Strategy

With multiple developers:

1. Team completes Setup + Foundational together
2. Once Foundational is done:
   - Developer A: User Story 1 (Admin)
   - Developer B: User Story 2 (User Token)
3. After P1 stories complete:
   - Developer A: User Story 3 (Chat)
   - Developer B: User Story 6 (Analytics)
4. After User Story 3:
   - Developer A: User Story 4 (Dissolution)
   - Developer B: User Story 5 (Reconnection)
5. Stories complete and integrate independently

---

## Summary

| Metric | Count |
|--------|-------|
| **Total Tasks** | 117 |
| **Setup Tasks** | 8 |
| **Foundational Tasks** | 24 |
| **User Story 1 Tasks** | 18 |
| **User Story 2 Tasks** | 14 |
| **User Story 3 Tasks** | 16 |
| **User Story 4 Tasks** | 9 |
| **User Story 5 Tasks** | 7 |
| **User Story 6 Tasks** | 7 |
| **Polish Tasks** | 14 |
| **Parallel Opportunities** | 52 tasks marked [P] |

### Independent Test Criteria per Story

| Story | Independent Test |
|-------|------------------|
| US1 | Create session, start it, end it - verify state transitions |
| US2 | Browse sessions, claim token, join active session |
| US3 | Join session, send message, receive AI response |
| US4 | Be chatting when session ends, see dissolution UI |
| US5 | Disconnect, reconnect with same token, see history |
| US6 | Have users join, verify admin sees counts (not content) |

### Suggested MVP Scope

**Minimum Viable Product**: User Stories 1 + 2 (Phases 1-4)
- Admin can create, start, end sessions
- Users can browse, claim tokens, and join sessions
- Foundation for chat already in place

**Extended MVP**: Add User Story 3 (Phase 5)
- Full chat experience with AI

---

## Notes

- [P] tasks = different files, no dependencies
- [Story] label maps task to specific user story for traceability
- Each user story should be independently completable and testable
- Verify tests fail before implementing
- Commit after each task or logical group
- Stop at any checkpoint to validate story independently
- Avoid: vague tasks, same file conflicts, cross-story dependencies that break independence
