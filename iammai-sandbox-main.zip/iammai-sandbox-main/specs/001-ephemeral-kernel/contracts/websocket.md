# WebSocket Protocol: IAMMAI Sandbox

**Feature**: 001-ephemeral-kernel
**Date**: 2026-01-24
**Version**: 1.0.0

## Overview

WebSocket connection for real-time updates in the IAMMAI Sandbox system.

**Endpoint**: `wss://{host}/ws/sessions/{sessionId}`

**Authentication**: Token passed as query parameter: `?token={token}`

## Connection Lifecycle

```
Client                                          Server
   |                                               |
   |  CONNECT /ws/sessions/{id}?token={token}      |
   |---------------------------------------------->|
   |                                               |
   |  CONNECTION_ACK {presenceHash, kernelStatus}  |
   |<----------------------------------------------|
   |                                               |
   |  ... bidirectional messages ...               |
   |<--------------------------------------------->|
   |                                               |
   |  KERNEL_DISSOLVED {reason}                    |
   |<----------------------------------------------|
   |                                               |
   |  Connection closed (1000)                     |
   |<----------------------------------------------|
```

## Message Format

All messages are JSON with a `type` field:

```typescript
interface WebSocketMessage {
  type: string;
  payload?: object;
  timestamp: string;  // ISO 8601
}
```

## Server → Client Messages

### CONNECTION_ACK

Sent immediately after successful connection.

```json
{
  "type": "CONNECTION_ACK",
  "payload": {
    "presenceHash": "a7f3b2c1",
    "kernelStatus": "ACTIVE",
    "sessionId": "550e8400-e29b-41d4-a716-446655440000"
  },
  "timestamp": "2026-01-24T10:30:00.000Z"
}
```

### MESSAGE_CHUNK

Streamed AI response chunk (for real-time typing effect).

```json
{
  "type": "MESSAGE_CHUNK",
  "payload": {
    "messageId": "msg-uuid",
    "content": "Hello! How can I",
    "isComplete": false
  },
  "timestamp": "2026-01-24T10:30:01.000Z"
}
```

### MESSAGE_COMPLETE

Final message indicating AI response is complete.

```json
{
  "type": "MESSAGE_COMPLETE",
  "payload": {
    "messageId": "msg-uuid",
    "content": "Hello! How can I help you today?",
    "role": "assistant"
  },
  "timestamp": "2026-01-24T10:30:02.000Z"
}
```

### MESSAGE_ERROR

Error during message processing.

```json
{
  "type": "MESSAGE_ERROR",
  "payload": {
    "messageId": "msg-uuid",
    "code": "AI_SERVICE_UNAVAILABLE",
    "message": "Unable to get AI response. Please try again."
  },
  "timestamp": "2026-01-24T10:30:02.000Z"
}
```

### KERNEL_STATUS

Kernel status update (typically sent before dissolution).

```json
{
  "type": "KERNEL_STATUS",
  "payload": {
    "status": "ACTIVE",
    "sessionId": "550e8400-e29b-41d4-a716-446655440000"
  },
  "timestamp": "2026-01-24T10:30:00.000Z"
}
```

### KERNEL_DISSOLVED

**CRITICAL**: Sent when session ends. Client MUST display dissolution UI.

```json
{
  "type": "KERNEL_DISSOLVED",
  "payload": {
    "sessionId": "550e8400-e29b-41d4-a716-446655440000",
    "message": "Your conversation is gone"
  },
  "timestamp": "2026-01-24T10:35:00.000Z"
}
```

**Client Behavior on KERNEL_DISSOLVED**:
1. Display "Kernel Dissolved" indicator immediately
2. Show "Your conversation is gone" message
3. Disable message input
4. Close WebSocket connection
5. Clear any locally cached messages

### HEARTBEAT

Server ping to keep connection alive.

```json
{
  "type": "HEARTBEAT",
  "timestamp": "2026-01-24T10:30:00.000Z"
}
```

## Client → Server Messages

### USER_MESSAGE

User sends a chat message.

```json
{
  "type": "USER_MESSAGE",
  "payload": {
    "messageId": "client-generated-uuid",
    "content": "What is the weather like?"
  },
  "timestamp": "2026-01-24T10:30:00.000Z"
}
```

### HEARTBEAT_ACK

Response to server heartbeat.

```json
{
  "type": "HEARTBEAT_ACK",
  "timestamp": "2026-01-24T10:30:00.000Z"
}
```

## Error Codes

| Code | Description | Client Action |
|------|-------------|---------------|
| `INVALID_TOKEN` | Token not recognized | Redirect to session browser |
| `SESSION_NOT_ACTIVE` | Session not in ACTIVE state | Show session state, disable chat |
| `KERNEL_NOT_FOUND` | Kernel doesn't exist | Show error, refresh page |
| `AI_SERVICE_UNAVAILABLE` | AI provider error | Show error, allow retry |
| `MESSAGE_TOO_LONG` | Content exceeds 10000 chars | Show validation error |
| `RATE_LIMITED` | Too many messages | Show rate limit warning |

## Close Codes

| Code | Meaning | Client Behavior |
|------|---------|-----------------|
| 1000 | Normal close (dissolution) | Show dissolution UI |
| 1001 | Going away (server shutdown) | Attempt reconnect |
| 1008 | Policy violation (invalid token) | Clear token, redirect |
| 1011 | Server error | Show error, attempt reconnect |

## Reconnection Strategy

```typescript
const reconnect = {
  enabled: true,
  maxAttempts: 5,
  baseDelay: 1000,      // 1 second
  maxDelay: 30000,      // 30 seconds
  backoffMultiplier: 2,

  // Do NOT reconnect if:
  // - KERNEL_DISSOLVED received
  // - Close code 1008 (invalid token)
  // - Session state is ENDED
};
```

## Privacy Guarantees

1. **No Message Persistence**: Messages are NOT stored in WebSocket logs
2. **Token in Query**: Token is passed in URL, logs MUST NOT include query params
3. **Dissolution Immediate**: On KERNEL_DISSOLVED, server has already destroyed all data
4. **No History Endpoint**: There is no API to retrieve past messages via WebSocket
