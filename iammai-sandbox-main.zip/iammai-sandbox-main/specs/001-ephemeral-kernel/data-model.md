# Data Model: IAMMAI Sandbox System

**Feature**: 001-ephemeral-kernel
**Date**: 2026-01-24
**Status**: Complete

## Overview

The data model is split into two distinct storage domains:

1. **Persistent (PostgreSQL)**: Session records, admin accounts - survives restarts
2. **Ephemeral (In-Memory)**: Kernels, conversations, tokens - destroyed on dissolution

This separation enforces Constitution Principle V: conversation data never touches persistent storage.

## Persistent Entities (PostgreSQL)

### Admin

Authenticated administrator account.

| Field | Type | Constraints | Description |
|-------|------|-------------|-------------|
| id | UUID | PK | Unique identifier |
| email | VARCHAR(255) | UNIQUE, NOT NULL | Login email |
| password_hash | VARCHAR(255) | NOT NULL | bcrypt hash |
| created_at | TIMESTAMP | NOT NULL, DEFAULT NOW() | Account creation |
| last_login_at | TIMESTAMP | NULL | Last successful login |

**Indexes**: `email` (unique)

**Notes**: Single admin tier per Assumption #4. No role field needed.

---

### Session

Persistent record of a chatbot session (formerly "NFT").

| Field | Type | Constraints | Description |
|-------|------|-------------|-------------|
| id | UUID | PK | Unique identifier |
| name | VARCHAR(255) | NOT NULL | User-defined session name |
| state | ENUM | NOT NULL, DEFAULT 'CREATED' | CREATED, ACTIVE, ENDED |
| created_at | TIMESTAMP | NOT NULL, DEFAULT NOW() | Session creation time |
| started_at | TIMESTAMP | NULL | When transitioned to ACTIVE |
| ended_at | TIMESTAMP | NULL | When transitioned to ENDED |
| token_count | INTEGER | NOT NULL, DEFAULT 0 | Number of tokens claimed |
| user_count | INTEGER | NOT NULL, DEFAULT 0 | Number of users who joined |
| admin_id | UUID | FK → Admin.id, NOT NULL | Creating admin |

**Indexes**: `state`, `admin_id`, `created_at DESC`

**State Transitions** (FR-003):
```
CREATED → ACTIVE → ENDED
```
- Irreversible: once ACTIVE, cannot return to CREATED
- Irreversible: once ENDED, cannot return to ACTIVE
- Enforced via CHECK constraint or application logic

**Notes**:
- `token_count` increments on each claim (FR-024)
- `user_count` increments on first join per token (FR-025)
- No conversation content stored (Constitution Principle V)

---

### Token (Persistent Reference Only)

Minimal persistent record linking token to session. **Does not store the actual token value.**

| Field | Type | Constraints | Description |
|-------|------|-------------|-------------|
| id | UUID | PK | Unique identifier |
| session_id | UUID | FK → Session.id, NOT NULL | Associated session |
| token_hash | VARCHAR(64) | UNIQUE, NOT NULL | SHA-256 hash of token |
| claimed_at | TIMESTAMP | NOT NULL, DEFAULT NOW() | When token was claimed |
| joined_at | TIMESTAMP | NULL | When user first joined session |

**Indexes**: `session_id`, `token_hash` (unique)

**Notes**:
- Raw token value is NEVER stored (Constitution Principle V: token opacity)
- `token_hash` used only for deduplication and join tracking
- Presence hash derived from token seed, not stored here

---

## Ephemeral Entities (In-Memory)

### Kernel

In-memory container for all conversations in an active session.

```typescript
interface Kernel {
  sessionId: string;           // Reference to Session.id
  conversations: Map<string, Conversation>;  // Key: token hash
  createdAt: Date;             // When kernel was instantiated
}
```

**Lifecycle**:
- Created when Session transitions CREATED → ACTIVE
- Destroyed when Session transitions ACTIVE → ENDED
- Exists ONLY in memory (FR-011)

**Isolation** (FR-012):
- Each token hash maps to exactly one Conversation
- No cross-conversation access possible by design

---

### Conversation

Private message thread between one user and the AI.

```typescript
interface Conversation {
  tokenHash: string;           // SHA-256 of user's token
  presenceHash: string;        // Derived display hash (FR-015)
  messages: Message[];         // Ordered message history
  createdAt: Date;             // When conversation started
  lastActivityAt: Date;        // For potential idle cleanup
}
```

**Notes**:
- `presenceHash` is a short, display-safe hash derived from token seed
- `messages` array sent to AI with each request (FR-027)
- Entire object destroyed on dissolution (FR-014)

---

### Message

Single message in a conversation.

```typescript
interface Message {
  id: string;                  // UUID for client correlation
  role: 'user' | 'assistant';  // Message author
  content: string;             // Message text
  timestamp: Date;             // When message was created
}
```

**Notes**:
- No persistent storage (FR-011)
- No logging of content (Constitution Principle V)
- `id` used for optimistic UI updates, not persistence

---

### ActiveToken

In-memory token with full context for active session participation.

```typescript
interface ActiveToken {
  raw: string;                 // Base64url-encoded 256-bit token
  hash: string;                // SHA-256 hash for kernel lookup
  seed: string;                // Random seed for presence derivation
  sessionId: string;           // Associated session
  issuedAt: Date;              // When token was claimed
}
```

**Notes**:
- `raw` token sent to client, never stored server-side persistently
- `hash` used as key in Kernel.conversations
- `seed` used to derive `presenceHash`
- Destroyed when kernel dissolves

---

## Relationships

```
┌─────────────────────────────────────────────────────────────┐
│                     PERSISTENT (PostgreSQL)                  │
├─────────────────────────────────────────────────────────────┤
│                                                              │
│   Admin ─────────< Session ─────────< Token (hash only)     │
│     │                 │                    │                 │
│   1:N               1:N                  1:1                 │
│                       │                    │                 │
└───────────────────────┼────────────────────┼─────────────────┘
                        │                    │
                        ▼                    ▼
┌───────────────────────┼────────────────────┼─────────────────┐
│                       │   EPHEMERAL        │  (In-Memory)    │
├───────────────────────┼────────────────────┼─────────────────┤
│                       │                    │                 │
│                   Kernel ◄─────────── ActiveToken           │
│                     │                      │                 │
│                   1:N                    1:1                 │
│                     │                      │                 │
│                     ▼                      │                 │
│               Conversation ◄───────────────┘                 │
│                     │                                        │
│                   1:N                                        │
│                     ▼                                        │
│                  Message                                     │
│                                                              │
└──────────────────────────────────────────────────────────────┘
```

## State Machine: Session

```
     ┌─────────────┐
     │   CREATED   │ ◄── Initial state
     └──────┬──────┘
            │
            │ Admin starts session
            │ Action: Create Kernel
            ▼
     ┌─────────────┐
     │   ACTIVE    │ ◄── Kernel exists
     └──────┬──────┘
            │
            │ Admin ends session
            │ Action: Destroy Kernel
            ▼
     ┌─────────────┐
     │   ENDED     │ ◄── Kernel dissolved
     └─────────────┘
```

**Transition Rules**:
- Only forward transitions allowed (FR-003)
- Kernel lifecycle tied to state transitions (FR-004, FR-005)
- All conversations destroyed on ACTIVE → ENDED (FR-014)

## Validation Rules

### Session
- `name`: 1-255 characters, non-empty
- `state`: Must be valid enum value
- `started_at`: Required if state is ACTIVE or ENDED
- `ended_at`: Required if state is ENDED
- `token_count`: Non-negative integer
- `user_count`: Non-negative integer, ≤ token_count

### Token
- `token_hash`: Exactly 64 hex characters (SHA-256)
- `session_id`: Must reference existing session in CREATED state (FR-008)

### Message
- `content`: 1-10000 characters (reasonable limit)
- `role`: Must be 'user' or 'assistant'

## Privacy Enforcement Points

| Layer | Enforcement | Verification |
|-------|-------------|--------------|
| Database | No message tables exist | Schema audit |
| Token storage | Only hash stored, not raw | Column audit |
| Kernel | In-memory Map only | No disk I/O in kernel module |
| Logs | Sanitization middleware | Log grep in CI |
| API | No conversation GET endpoints for admin | Route audit |
