# Implementation Guide: IAMMAI Sandbox System

**Feature**: 001-ephemeral-kernel
**Date**: 2026-01-24
**Purpose**: Provides build sequence, cross-references, and implementation details missing from plan.md

## How to Use This Guide

When implementing a component:
1. Find the component in the **Build Sequence** below
2. Follow the **Reference** links to the relevant specs
3. Check **Dependencies** before starting
4. Implement according to the **Implementation Notes**
5. Write tests as specified in **Testing Requirements**

---

## Build Sequence Overview

```
Phase 1: Foundation (no dependencies)
├── T001: Project scaffolding & config
├── T002: Shared types & interfaces
└── T003: Database setup & migrations

Phase 2: Core Backend Services (depends on Phase 1)
├── T004: Database models (Admin, Session, Token)
├── T005: Kernel Manager & in-memory structures
├── T006: Token service (generation, validation)
├── T007: Presence hash derivation
└── T008: AI service abstraction

Phase 3: API Layer (depends on Phase 2)
├── T009: Express/Fastify server setup
├── T010: Auth middleware & routes
├── T011: Session routes (admin)
├── T012: Public routes (user browsing)
├── T013: Token routes (claim/join)
├── T014: Chat routes (message sending)
└── T015: Log sanitization middleware

Phase 4: WebSocket Layer (depends on Phase 2, 3)
├── T016: WebSocket hub
├── T017: Message handlers
└── T018: Dissolution broadcast

Phase 5: Frontend Shared (depends on Phase 3 contracts)
├── T019: API client generation from OpenAPI
├── T020: Shared components (StatusBadge, LoadingSkeleton)
└── T021: useWebSocket hook

Phase 6: Admin Frontend (depends on Phase 5)
├── T022: Admin layout & auth
├── T023: Session list page
├── T024: Session detail page
└── T025: Kernel status components

Phase 7: User Frontend (depends on Phase 5)
├── T026: Session browser page
├── T027: Chat interface
├── T028: Dissolution overlay
└── T029: Presence indicator

Phase 8: Testing & Polish (depends on all)
├── T030: Privacy test suite
├── T031: E2E tests
├── T032: Performance benchmarks
└── T033: Documentation
```

---

## Phase 1: Foundation

### T001: Project Scaffolding & Configuration

**Creates**: Root config files, monorepo structure

**Files**:
```
/
├── package.json              # Monorepo root with pnpm workspaces
├── pnpm-workspace.yaml       # Workspace definitions
├── tsconfig.base.json        # Shared TypeScript config
├── .eslintrc.js              # ESLint with constitution rules
├── .prettierrc               # Prettier config
├── .env.example              # Environment template
├── docker-compose.yml        # PostgreSQL for development
└── Dockerfile                # Production build
```

**Implementation Notes**:

```jsonc
// tsconfig.base.json - Constitution Principle I compliance
{
  "compilerOptions": {
    "strict": true,                    // Required by constitution
    "noImplicitAny": true,             // No 'any' types
    "strictNullChecks": true,
    "noUnusedLocals": true,
    "noUnusedParameters": true,
    "target": "ES2022",
    "module": "NodeNext",
    "moduleResolution": "NodeNext"
  }
}
```

```javascript
// .eslintrc.js - Constitution enforcement
module.exports = {
  rules: {
    'max-lines': ['error', { max: 300 }],           // Principle I
    'max-lines-per-function': ['error', { max: 50 }], // Principle I
    '@typescript-eslint/no-explicit-any': 'error',  // Principle I
  }
};
```

```yaml
# pnpm-workspace.yaml
packages:
  - 'backend'
  - 'frontend/apps/*'
  - 'frontend/packages/*'
  - 'tests'
```

```bash
# .env.example
DATABASE_URL=postgresql://user:password@localhost:5432/iammai_sandbox
OPENAI_API_KEY=sk-...
OPENAI_MODEL=gpt-4o-mini
JWT_SECRET=generate-256-bit-hex-here
ADMIN_EMAIL=admin@example.com
ADMIN_PASSWORD=change-me
```

**Dependencies**: None

---

### T002: Shared Types & Interfaces

**Creates**: `backend/src/lib/types.ts`

**Reference**: [data-model.md#Ephemeral Entities](./data-model.md#ephemeral-entities-in-memory)

**Implementation Notes**:

```typescript
// backend/src/lib/types.ts

// === Session States (FR-002) ===
export type SessionState = 'CREATED' | 'ACTIVE' | 'ENDED';

// === Persistent Entities ===
// Reference: data-model.md#Admin
export interface Admin {
  id: string;
  email: string;
  passwordHash: string;
  createdAt: Date;
  lastLoginAt: Date | null;
}

// Reference: data-model.md#Session
export interface Session {
  id: string;
  name: string;
  state: SessionState;
  createdAt: Date;
  startedAt: Date | null;
  endedAt: Date | null;
  tokenCount: number;
  userCount: number;
  adminId: string;
}

// Reference: data-model.md#Token
export interface TokenRecord {
  id: string;
  sessionId: string;
  tokenHash: string;  // SHA-256, never raw token
  claimedAt: Date;
  joinedAt: Date | null;
}

// === Ephemeral Entities (In-Memory Only) ===
// Reference: data-model.md#Kernel
export interface Kernel {
  sessionId: string;
  conversations: Map<string, Conversation>;  // Key: tokenHash
  createdAt: Date;
}

// Reference: data-model.md#Conversation
export interface Conversation {
  tokenHash: string;
  presenceHash: string;
  messages: Message[];
  createdAt: Date;
  lastActivityAt: Date;
}

// Reference: data-model.md#Message
export interface Message {
  id: string;
  role: 'user' | 'assistant';
  content: string;
  timestamp: Date;
}

// Reference: data-model.md#ActiveToken
export interface ActiveToken {
  raw: string;      // Sent to client once, never stored
  hash: string;     // SHA-256 for kernel lookup
  seed: string;     // For presence derivation
  sessionId: string;
  issuedAt: Date;
}

// === API Types ===
// Reference: contracts/api.yaml#components/schemas
export interface CreateSessionRequest {
  name: string;
}

export interface LoginRequest {
  email: string;
  password: string;
}

export interface JoinRequest {
  token: string;
}

export interface SendMessageRequest {
  content: string;
  messageId?: string;
}

// === WebSocket Types ===
// Reference: contracts/websocket.md#Message Format
export interface WebSocketMessage {
  type: string;
  payload?: Record<string, unknown>;
  timestamp: string;
}

export type WSMessageType =
  | 'CONNECTION_ACK'
  | 'USER_MESSAGE'
  | 'MESSAGE_CHUNK'
  | 'MESSAGE_COMPLETE'
  | 'MESSAGE_ERROR'
  | 'KERNEL_STATUS'
  | 'KERNEL_DISSOLVED'
  | 'HEARTBEAT'
  | 'HEARTBEAT_ACK';
```

**Dependencies**: None

**Testing**: Type-only file, no runtime tests needed

---

### T003: Database Setup & Migrations

**Creates**:
- `backend/src/lib/db.ts`
- `backend/migrations/001_initial.sql`

**Reference**: [data-model.md#Persistent Entities](./data-model.md#persistent-entities-postgresql)

**Implementation Notes**:

```sql
-- backend/migrations/001_initial.sql

-- Admin table (Reference: data-model.md#Admin)
CREATE TABLE admins (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  email VARCHAR(255) UNIQUE NOT NULL,
  password_hash VARCHAR(255) NOT NULL,
  created_at TIMESTAMP NOT NULL DEFAULT NOW(),
  last_login_at TIMESTAMP
);

CREATE INDEX idx_admins_email ON admins(email);

-- Session table (Reference: data-model.md#Session)
CREATE TYPE session_state AS ENUM ('CREATED', 'ACTIVE', 'ENDED');

CREATE TABLE sessions (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  name VARCHAR(255) NOT NULL,
  state session_state NOT NULL DEFAULT 'CREATED',
  created_at TIMESTAMP NOT NULL DEFAULT NOW(),
  started_at TIMESTAMP,
  ended_at TIMESTAMP,
  token_count INTEGER NOT NULL DEFAULT 0,
  user_count INTEGER NOT NULL DEFAULT 0,
  admin_id UUID NOT NULL REFERENCES admins(id),

  -- Validation: data-model.md#Validation Rules
  CONSTRAINT valid_started_at CHECK (
    (state = 'CREATED') OR (started_at IS NOT NULL)
  ),
  CONSTRAINT valid_ended_at CHECK (
    (state != 'ENDED') OR (ended_at IS NOT NULL)
  ),
  CONSTRAINT valid_user_count CHECK (user_count <= token_count)
);

CREATE INDEX idx_sessions_state ON sessions(state);
CREATE INDEX idx_sessions_admin_id ON sessions(admin_id);
CREATE INDEX idx_sessions_created_at ON sessions(created_at DESC);

-- Token table (Reference: data-model.md#Token)
-- NOTE: Only stores hash, NEVER the raw token (Constitution Principle V)
CREATE TABLE tokens (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  session_id UUID NOT NULL REFERENCES sessions(id),
  token_hash VARCHAR(64) UNIQUE NOT NULL,  -- SHA-256 hex
  claimed_at TIMESTAMP NOT NULL DEFAULT NOW(),
  joined_at TIMESTAMP
);

CREATE INDEX idx_tokens_session_id ON tokens(session_id);
CREATE INDEX idx_tokens_token_hash ON tokens(token_hash);

-- Seed initial admin (for development)
-- Password: 'admin123' hashed with bcrypt
INSERT INTO admins (email, password_hash) VALUES (
  'admin@example.com',
  '$2b$10$...'  -- Generate with: await bcrypt.hash('admin123', 10)
);
```

```typescript
// backend/src/lib/db.ts
import { Pool } from 'pg';
import { config } from './config';

export const pool = new Pool({
  connectionString: config.databaseUrl,
});

// Health check
export async function checkDatabase(): Promise<boolean> {
  try {
    await pool.query('SELECT 1');
    return true;
  } catch {
    return false;
  }
}
```

**Dependencies**: T001 (config)

**Testing**: Integration test for migrations

---

## Phase 2: Core Backend Services

### T004: Database Models

**Creates**:
- `backend/src/models/admin.ts`
- `backend/src/models/session.ts`
- `backend/src/models/token.ts`

**Reference**:
- [data-model.md#Persistent Entities](./data-model.md#persistent-entities-postgresql)
- [contracts/api.yaml#Session](./contracts/api.yaml) (lines 464-488)

**Implementation Notes**:

```typescript
// backend/src/models/session.ts
import { pool } from '../lib/db';
import { Session, SessionState } from '../lib/types';

export async function createSession(
  name: string,
  adminId: string
): Promise<Session> {
  const result = await pool.query(
    `INSERT INTO sessions (name, admin_id)
     VALUES ($1, $2)
     RETURNING *`,
    [name, adminId]
  );
  return mapRow(result.rows[0]);
}

export async function getSession(id: string): Promise<Session | null> {
  const result = await pool.query(
    'SELECT * FROM sessions WHERE id = $1',
    [id]
  );
  return result.rows[0] ? mapRow(result.rows[0]) : null;
}

// State transition with validation (FR-003)
// Reference: data-model.md#State Machine: Session
export async function transitionSession(
  id: string,
  fromState: SessionState,
  toState: SessionState
): Promise<Session> {
  // Validate transition is allowed
  const validTransitions: Record<SessionState, SessionState[]> = {
    'CREATED': ['ACTIVE'],
    'ACTIVE': ['ENDED'],
    'ENDED': []  // Terminal state
  };

  if (!validTransitions[fromState].includes(toState)) {
    throw new Error(`Invalid transition: ${fromState} → ${toState}`);
  }

  const timestampField = toState === 'ACTIVE' ? 'started_at' : 'ended_at';

  const result = await pool.query(
    `UPDATE sessions
     SET state = $1, ${timestampField} = NOW()
     WHERE id = $2 AND state = $3
     RETURNING *`,
    [toState, id, fromState]
  );

  if (result.rows.length === 0) {
    throw new Error('Session not found or invalid state');
  }

  return mapRow(result.rows[0]);
}

function mapRow(row: any): Session {
  return {
    id: row.id,
    name: row.name,
    state: row.state,
    createdAt: row.created_at,
    startedAt: row.started_at,
    endedAt: row.ended_at,
    tokenCount: row.token_count,
    userCount: row.user_count,
    adminId: row.admin_id,
  };
}
```

**Dependencies**: T002 (types), T003 (db)

**Testing**: Unit tests for validation, integration tests for queries

---

### T005: Kernel Manager

**Creates**:
- `backend/src/kernel/manager.ts`
- `backend/src/kernel/kernel.ts`
- `backend/src/kernel/conversation.ts`

**Reference**:
- [data-model.md#Ephemeral Entities](./data-model.md#ephemeral-entities-in-memory)
- [research.md#Kernel Isolation Model](./research.md#kernel-isolation-model)

**Implementation Notes**:

```typescript
// backend/src/kernel/manager.ts
import { Kernel, Conversation, Message } from '../lib/types';

/**
 * KernelManager - In-memory storage for active session kernels
 *
 * PRIVACY CRITICAL (Constitution Principle V):
 * - All data exists ONLY in this Map
 * - No disk I/O, no serialization
 * - Dissolution = delete from Map
 *
 * Reference: data-model.md#Kernel
 */
class KernelManager {
  // Map<sessionId, Kernel>
  private kernels: Map<string, Kernel> = new Map();

  /**
   * Create kernel when session transitions CREATED → ACTIVE
   * Reference: data-model.md#State Machine: Session
   */
  createKernel(sessionId: string): Kernel {
    if (this.kernels.has(sessionId)) {
      throw new Error(`Kernel already exists for session ${sessionId}`);
    }

    const kernel: Kernel = {
      sessionId,
      conversations: new Map(),
      createdAt: new Date(),
    };

    this.kernels.set(sessionId, kernel);
    return kernel;
  }

  /**
   * Dissolve kernel when session transitions ACTIVE → ENDED
   *
   * PRIVACY CRITICAL: Must complete in <50ms (Constitution Principle IV)
   * Reference: research.md#Dissolution Verification
   */
  dissolveKernel(sessionId: string): void {
    const kernel = this.kernels.get(sessionId);
    if (!kernel) return;

    // Explicitly clear all conversations first
    // (Don't rely on GC - make it deterministic)
    for (const conversation of kernel.conversations.values()) {
      conversation.messages.length = 0;  // Clear array
    }
    kernel.conversations.clear();

    // Remove kernel from manager
    this.kernels.delete(sessionId);
  }

  /**
   * Get or create conversation for a token
   * Reference: data-model.md#Conversation
   */
  getOrCreateConversation(
    sessionId: string,
    tokenHash: string,
    presenceHash: string
  ): Conversation {
    const kernel = this.kernels.get(sessionId);
    if (!kernel) {
      throw new Error(`Kernel not found for session ${sessionId}`);
    }

    let conversation = kernel.conversations.get(tokenHash);
    if (!conversation) {
      conversation = {
        tokenHash,
        presenceHash,
        messages: [],
        createdAt: new Date(),
        lastActivityAt: new Date(),
      };
      kernel.conversations.set(tokenHash, conversation);
    }

    return conversation;
  }

  /**
   * Add message to conversation
   * Reference: data-model.md#Message
   */
  addMessage(
    sessionId: string,
    tokenHash: string,
    message: Message
  ): void {
    const kernel = this.kernels.get(sessionId);
    if (!kernel) {
      throw new Error('Kernel dissolved');
    }

    const conversation = kernel.conversations.get(tokenHash);
    if (!conversation) {
      throw new Error('Conversation not found');
    }

    conversation.messages.push(message);
    conversation.lastActivityAt = new Date();
  }

  /**
   * Get conversation history for AI context
   * Reference: FR-027 (session-scoped context)
   */
  getConversationHistory(
    sessionId: string,
    tokenHash: string
  ): Message[] {
    const kernel = this.kernels.get(sessionId);
    if (!kernel) return [];

    const conversation = kernel.conversations.get(tokenHash);
    return conversation?.messages ?? [];
  }

  hasKernel(sessionId: string): boolean {
    return this.kernels.has(sessionId);
  }
}

// Singleton instance
export const kernelManager = new KernelManager();
```

**Dependencies**: T002 (types)

**Testing**:
- Unit tests for create/dissolve/conversation operations
- **Privacy tests**: Verify dissolution clears all data
- **Performance tests**: Verify dissolution <50ms

---

### T006: Token Service

**Creates**: `backend/src/services/token.ts`

**Reference**:
- [research.md#Token Generation](./research.md#token-generation)
- [data-model.md#ActiveToken](./data-model.md#activetoken)

**Implementation Notes**:

```typescript
// backend/src/services/token.ts
import crypto from 'crypto';
import { ActiveToken } from '../lib/types';
import * as tokenModel from '../models/token';

/**
 * Generate cryptographically secure token
 *
 * Constitution Principle V: Token Opacity
 * - 256-bit random (crypto.randomBytes)
 * - No embedded information
 * - Base64url encoding for URL safety
 *
 * Reference: research.md#Token Generation
 */
export function generateToken(sessionId: string): ActiveToken {
  // 32 bytes = 256 bits of entropy
  const rawBytes = crypto.randomBytes(32);
  const raw = rawBytes.toString('base64url');

  // Separate seed for presence hash (16 bytes)
  const seedBytes = crypto.randomBytes(16);
  const seed = seedBytes.toString('hex');

  // Hash for storage/lookup (never store raw)
  const hash = crypto
    .createHash('sha256')
    .update(rawBytes)
    .digest('hex');

  return {
    raw,
    hash,
    seed,
    sessionId,
    issuedAt: new Date(),
  };
}

/**
 * Validate token and return hash for kernel lookup
 */
export function hashToken(rawToken: string): string {
  const buffer = Buffer.from(rawToken, 'base64url');
  return crypto
    .createHash('sha256')
    .update(buffer)
    .digest('hex');
}

/**
 * Claim token for session (persist hash only)
 * Reference: FR-008 (only CREATED state)
 */
export async function claimToken(
  sessionId: string,
  session: { state: string }
): Promise<ActiveToken> {
  if (session.state !== 'CREATED') {
    throw new Error('Tokens can only be claimed for CREATED sessions');
  }

  const token = generateToken(sessionId);

  // Store only the hash (Constitution Principle V)
  await tokenModel.createToken(sessionId, token.hash);

  return token;
}
```

**Dependencies**: T002 (types), T004 (token model)

**Testing**: Unit tests for generation, hash verification

---

### T007: Presence Hash Service

**Creates**: `backend/src/services/presence.ts`

**Reference**: [data-model.md#Presence Hash](./data-model.md#key-entities)

**Implementation Notes**:

```typescript
// backend/src/services/presence.ts
import crypto from 'crypto';

/**
 * Derive presence hash from token seed
 *
 * Creates a short, display-friendly identifier:
 * - 8 hex characters (32 bits)
 * - One-way derivation (cannot reverse to token)
 * - Deterministic (same seed = same hash)
 *
 * Reference: FR-015 (display as hash, never identity)
 */
export function derivePresenceHash(seed: string): string {
  const hash = crypto
    .createHash('sha256')
    .update(seed)
    .update('presence')  // Domain separation
    .digest('hex');

  // First 8 characters for display
  return hash.substring(0, 8);
}
```

**Dependencies**: None

**Testing**: Unit tests for determinism, uniqueness distribution

---

### T008: AI Service

**Creates**: `backend/src/services/ai.ts`

**Reference**:
- [research.md#AI Service Integration](./research.md#ai-service-integration)
- [spec.md#FR-027, FR-028](./spec.md)

**Implementation Notes**:

```typescript
// backend/src/services/ai.ts
import OpenAI from 'openai';
import { Message } from '../lib/types';
import { config } from '../lib/config';

const openai = new OpenAI({
  apiKey: config.openaiApiKey,
});

/**
 * AI Provider abstraction
 *
 * FR-027: Send full conversation history per request
 * FR-028: No context persistence (handled by kernel)
 *
 * Reference: research.md#AI Service Integration
 */
export interface AIProvider {
  chat(messages: Message[]): AsyncGenerator<string, void, unknown>;
}

/**
 * OpenAI implementation with streaming
 */
export async function* streamChat(
  conversationHistory: Message[]
): AsyncGenerator<string, void, unknown> {
  const messages = conversationHistory.map(msg => ({
    role: msg.role as 'user' | 'assistant',
    content: msg.content,
  }));

  const stream = await openai.chat.completions.create({
    model: config.openaiModel,
    messages,
    stream: true,
  });

  for await (const chunk of stream) {
    const content = chunk.choices[0]?.delta?.content;
    if (content) {
      yield content;
    }
  }
}

/**
 * Non-streaming version for simpler use cases
 */
export async function chat(
  conversationHistory: Message[]
): Promise<string> {
  const chunks: string[] = [];
  for await (const chunk of streamChat(conversationHistory)) {
    chunks.push(chunk);
  }
  return chunks.join('');
}
```

**Dependencies**: T002 (types), T001 (config)

**Testing**:
- Unit tests with mocked OpenAI client
- Integration tests with real API (optional, expensive)

---

## Phase 3: API Layer

### T009: Server Setup

**Creates**: `backend/src/index.ts`, `backend/src/api/app.ts`

**Reference**: [quickstart.md#Development URLs](./quickstart.md#development-urls)

**Implementation Notes**:

```typescript
// backend/src/api/app.ts
import express from 'express';
import cookieParser from 'cookie-parser';
import { authRouter } from './routes/auth';
import { adminSessionsRouter } from './routes/sessions';
import { publicRouter } from './routes/public';
import { tokensRouter } from './routes/tokens';
import { chatRouter } from './routes/chat';
import { logSanitizer } from './middleware/logging';
import { errorHandler } from './middleware/error';

export function createApp() {
  const app = express();

  // Middleware
  app.use(express.json());
  app.use(cookieParser());
  app.use(logSanitizer);  // Constitution Principle V

  // Routes - Reference: contracts/api.yaml
  app.use('/api/v1/auth', authRouter);
  app.use('/api/v1/admin/sessions', adminSessionsRouter);
  app.use('/api/v1/sessions', publicRouter);
  app.use('/api/v1/sessions', tokensRouter);
  app.use('/api/v1/sessions', chatRouter);

  // Error handling
  app.use(errorHandler);

  return app;
}
```

**Dependencies**: All Phase 2 services

---

### T010-T015: Route Implementations

Each route file implements endpoints from `contracts/api.yaml`.

**Cross-Reference Table**:

| Route File | API Spec Reference | Data Model Reference |
|------------|-------------------|---------------------|
| `routes/auth.ts` | api.yaml lines 32-86 | data-model.md#Admin |
| `routes/sessions.ts` | api.yaml lines 91-228 | data-model.md#Session |
| `routes/public.ts` | api.yaml lines 233-274 | data-model.md#Session |
| `routes/tokens.ts` | api.yaml lines 279-336 | data-model.md#Token, ActiveToken |
| `routes/chat.ts` | api.yaml lines 341-376 | data-model.md#Message |

**Example Implementation** (sessions.ts):

```typescript
// backend/src/api/routes/sessions.ts
import { Router } from 'express';
import { requireAdmin } from '../middleware/auth';
import * as sessionModel from '../../models/session';
import { kernelManager } from '../../kernel/manager';
import { wsHub } from '../websocket/hub';

export const adminSessionsRouter = Router();

// Reference: contracts/api.yaml#/admin/sessions POST (lines 124-146)
adminSessionsRouter.post('/', requireAdmin, async (req, res) => {
  const { name } = req.body;
  const session = await sessionModel.createSession(name, req.admin.id);
  res.status(201).json(session);
});

// Reference: contracts/api.yaml#/admin/sessions/{id}/start (lines 169-197)
adminSessionsRouter.post('/:id/start', requireAdmin, async (req, res) => {
  const session = await sessionModel.getSession(req.params.id);
  if (!session) {
    return res.status(404).json({ code: 'NOT_FOUND', message: 'Session not found' });
  }

  // Transition state and create kernel
  // Reference: data-model.md#State Machine: Session
  const updated = await sessionModel.transitionSession(session.id, 'CREATED', 'ACTIVE');
  kernelManager.createKernel(session.id);

  res.json(updated);
});

// Reference: contracts/api.yaml#/admin/sessions/{id}/end (lines 199-228)
adminSessionsRouter.post('/:id/end', requireAdmin, async (req, res) => {
  const session = await sessionModel.getSession(req.params.id);
  if (!session) {
    return res.status(404).json({ code: 'NOT_FOUND', message: 'Session not found' });
  }

  // Broadcast dissolution BEFORE destroying kernel
  // Reference: contracts/websocket.md#KERNEL_DISSOLVED
  await wsHub.broadcastDissolution(session.id);

  // Dissolve kernel (PRIVACY CRITICAL)
  kernelManager.dissolveKernel(session.id);

  // Update persistent state
  const updated = await sessionModel.transitionSession(session.id, 'ACTIVE', 'ENDED');

  res.json(updated);
});
```

---

## Phase 4: WebSocket Layer

### T016-T018: WebSocket Implementation

**Creates**:
- `backend/src/api/websocket/hub.ts`
- `backend/src/api/websocket/handlers.ts`

**Reference**: [contracts/websocket.md](./contracts/websocket.md)

**Implementation Notes**:

```typescript
// backend/src/api/websocket/hub.ts
import { WebSocket, WebSocketServer } from 'ws';
import { IncomingMessage } from 'http';
import { URL } from 'url';
import { hashToken } from '../../services/token';
import { kernelManager } from '../../kernel/manager';
import { WebSocketMessage } from '../../lib/types';

interface ClientConnection {
  ws: WebSocket;
  sessionId: string;
  tokenHash: string;
  presenceHash: string;
}

/**
 * WebSocket Hub - manages all active connections
 *
 * Reference: contracts/websocket.md
 */
class WebSocketHub {
  private wss: WebSocketServer | null = null;
  // Map<sessionId, Map<tokenHash, ClientConnection>>
  private connections: Map<string, Map<string, ClientConnection>> = new Map();

  initialize(server: any) {
    this.wss = new WebSocketServer({ server, path: '/ws/sessions' });

    this.wss.on('connection', (ws, req) => {
      this.handleConnection(ws, req);
    });
  }

  private async handleConnection(ws: WebSocket, req: IncomingMessage) {
    // Parse URL: /ws/sessions/{sessionId}?token={token}
    // Reference: contracts/websocket.md#Authentication
    const url = new URL(req.url!, `http://${req.headers.host}`);
    const pathParts = url.pathname.split('/');
    const sessionId = pathParts[pathParts.length - 1];
    const rawToken = url.searchParams.get('token');

    if (!rawToken) {
      ws.close(1008, 'Token required');
      return;
    }

    const tokenHash = hashToken(rawToken);

    // Verify kernel exists
    if (!kernelManager.hasKernel(sessionId)) {
      ws.close(1008, 'Session not active');
      return;
    }

    // Get or create conversation
    const presenceHash = /* derive from token */;
    const conversation = kernelManager.getOrCreateConversation(
      sessionId, tokenHash, presenceHash
    );

    // Store connection
    if (!this.connections.has(sessionId)) {
      this.connections.set(sessionId, new Map());
    }
    this.connections.get(sessionId)!.set(tokenHash, {
      ws, sessionId, tokenHash, presenceHash
    });

    // Send CONNECTION_ACK
    // Reference: contracts/websocket.md#CONNECTION_ACK
    this.send(ws, {
      type: 'CONNECTION_ACK',
      payload: {
        presenceHash,
        kernelStatus: 'ACTIVE',
        sessionId,
      },
      timestamp: new Date().toISOString(),
    });

    // Set up message handling
    ws.on('message', (data) => this.handleMessage(sessionId, tokenHash, data));
    ws.on('close', () => this.handleDisconnect(sessionId, tokenHash));
  }

  /**
   * Broadcast KERNEL_DISSOLVED to all session connections
   * Reference: contracts/websocket.md#KERNEL_DISSOLVED
   */
  async broadcastDissolution(sessionId: string): Promise<void> {
    const sessionConnections = this.connections.get(sessionId);
    if (!sessionConnections) return;

    const message: WebSocketMessage = {
      type: 'KERNEL_DISSOLVED',
      payload: {
        sessionId,
        message: 'Your conversation is gone',
      },
      timestamp: new Date().toISOString(),
    };

    for (const conn of sessionConnections.values()) {
      this.send(conn.ws, message);
      conn.ws.close(1000, 'Kernel dissolved');
    }

    this.connections.delete(sessionId);
  }

  private send(ws: WebSocket, message: WebSocketMessage) {
    ws.send(JSON.stringify(message));
  }
}

export const wsHub = new WebSocketHub();
```

**Dependencies**: T005 (kernel), T006 (token), T007 (presence)

**Testing**:
- Unit tests for message handling
- Integration tests for connection lifecycle
- **Privacy tests**: Verify no messages logged

---

## Phase 5-7: Frontend Implementation

Each frontend component maps to:
1. **API client** generated from `contracts/api.yaml`
2. **WebSocket hook** implementing `contracts/websocket.md`
3. **UI requirements** from Constitution Principle III

**Component Cross-Reference**:

| Component | API Endpoints Used | WebSocket Messages | Constitution Checks |
|-----------|-------------------|-------------------|---------------------|
| `SessionList.tsx` | `GET /sessions` | - | State visibility |
| `ChatMessage.tsx` | - | MESSAGE_COMPLETE | - |
| `KernelStatus.tsx` | - | KERNEL_STATUS, KERNEL_DISSOLVED | State visibility |
| `DissolutionOverlay.tsx` | - | KERNEL_DISSOLVED | Dissolution experience |
| `PresenceIndicator.tsx` | - | CONNECTION_ACK | Presence hash display |

---

## Phase 8: Testing Requirements

### Privacy Test Suite

**Reference**: Constitution Principle V, [research.md#Security Considerations](./research.md#security-considerations)

```typescript
// tests/privacy/kernel-dissolution.test.ts

describe('Kernel Dissolution Privacy', () => {
  it('should destroy all conversation data on dissolution', async () => {
    // Arrange
    const sessionId = 'test-session';
    kernelManager.createKernel(sessionId);
    const conv = kernelManager.getOrCreateConversation(sessionId, 'hash', 'presence');
    conv.messages.push({ id: '1', role: 'user', content: 'secret', timestamp: new Date() });

    // Act
    kernelManager.dissolveKernel(sessionId);

    // Assert
    expect(kernelManager.hasKernel(sessionId)).toBe(false);
    // Verify no references remain (heap inspection in CI)
  });

  it('should complete dissolution in <50ms', async () => {
    // Create kernel with 100 conversations, 100 messages each
    const sessionId = 'perf-test';
    kernelManager.createKernel(sessionId);
    for (let i = 0; i < 100; i++) {
      const conv = kernelManager.getOrCreateConversation(sessionId, `hash${i}`, `presence${i}`);
      for (let j = 0; j < 100; j++) {
        conv.messages.push({ id: `${i}-${j}`, role: 'user', content: 'x'.repeat(1000), timestamp: new Date() });
      }
    }

    // Act & Assert
    const start = performance.now();
    kernelManager.dissolveKernel(sessionId);
    const duration = performance.now() - start;

    expect(duration).toBeLessThan(50);
  });
});
```

---

## Quick Reference: File → Spec Mapping

| Implementation File | Primary Spec Reference |
|---------------------|----------------------|
| `backend/src/lib/types.ts` | data-model.md (all sections) |
| `backend/src/models/session.ts` | data-model.md#Session, api.yaml#Session schema |
| `backend/src/kernel/manager.ts` | data-model.md#Kernel, research.md#Kernel Isolation |
| `backend/src/services/token.ts` | research.md#Token Generation, data-model.md#ActiveToken |
| `backend/src/services/ai.ts` | research.md#AI Service Integration |
| `backend/src/api/routes/sessions.ts` | contracts/api.yaml#/admin/sessions |
| `backend/src/api/websocket/hub.ts` | contracts/websocket.md |
| `frontend/apps/user/src/pages/chat/[id].tsx` | contracts/websocket.md, api.yaml#/sessions/{id}/join |
