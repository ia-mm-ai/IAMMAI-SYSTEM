# Feature Specification: IAMMAI Sandbox System

**Feature Branch**: `001-ephemeral-kernel`
**Created**: 2026-01-24
**Status**: Draft
**Input**: Full system specification from SPECIFICATION.md - A web application for ephemeral chatbot sessions with admin control and anonymous user participation

## User Scenarios & Testing *(mandatory)*

### User Story 1 - Admin Creates and Manages Sessions (Priority: P1)

An administrator creates chatbot sessions that users can join. The admin can start sessions to make them active and end sessions to dissolve all conversations permanently.

**Why this priority**: Core administrative control is the foundation of the entire system. Without session management, no user interactions are possible.

**Independent Test**: Can be fully tested by creating a session, starting it, and ending it - verifies the complete session lifecycle works end-to-end.

**Acceptance Scenarios**:

1. **Given** an admin is logged in, **When** they create a new session with a name, **Then** the session appears in the session list with CREATED state and gray indicator
2. **Given** a session exists in CREATED state, **When** the admin starts the session, **Then** the session transitions to ACTIVE state, shows green indicator, and the kernel is created
3. **Given** a session exists in ACTIVE state, **When** the admin ends the session, **Then** the session transitions to ENDED state, shows red indicator, and all conversations are destroyed
4. **Given** sessions exist in various states, **When** the admin views the session list, **Then** they see all sessions with their current state, user counts, and kernel status history

---

### User Story 2 - User Claims Token and Joins Session (Priority: P1)

A user browses available sessions, claims a free token for a queued session, and joins when the session becomes active to chat with the AI.

**Why this priority**: User participation is equally critical to admin control - together they form the core value loop of the product.

**Independent Test**: Can be fully tested by browsing sessions, purchasing a token, waiting for session activation, and successfully joining the chat interface.

**Acceptance Scenarios**:

1. **Given** sessions exist in CREATED state, **When** a user browses the session list, **Then** they see queued sessions with a purchase button
2. **Given** a user views a queued session, **When** they purchase a token, **Then** they receive an anonymous token linked to that specific session
3. **Given** a user holds a token for a session, **When** the session becomes ACTIVE, **Then** the user can join the session and access the chat interface
4. **Given** a user attempts to join without a token, **When** they click join on an active session, **Then** they are prevented from joining and prompted to purchase a token

---

### User Story 3 - User Chats Privately with AI (Priority: P2)

A user engages in a private, isolated conversation with the AI assistant within an active session, seeing their anonymous presence hash.

**Why this priority**: The chat experience is the core user value, but depends on token/session infrastructure from P1 stories.

**Independent Test**: Can be fully tested by joining a session and exchanging messages with the AI, verifying message display and privacy indicators.

**Acceptance Scenarios**:

1. **Given** a user has joined an active session, **When** they view the chat interface, **Then** they see the kernel status indicator showing "Kernel Active" and their presence hash
2. **Given** a user is in an active chat, **When** they send a message, **Then** the AI responds and both messages appear in the conversation
3. **Given** two users are in the same session, **When** they chat simultaneously, **Then** neither can see the other's messages or know the other exists
4. **Given** a user is chatting, **When** they view any system UI, **Then** no other user's presence or conversation content is visible

---

### User Story 4 - User Experiences Kernel Dissolution (Priority: P2)

When a session ends, users immediately see the dissolution state and understand their conversation is permanently gone.

**Why this priority**: The dissolution experience is central to the privacy promise but depends on chat functionality being established.

**Independent Test**: Can be fully tested by actively chatting when admin ends session, verifying the dissolution UI appears and chat becomes disabled.

**Acceptance Scenarios**:

1. **Given** a user is actively chatting, **When** the admin ends the session, **Then** the user immediately sees "Kernel Dissolved" indicator
2. **Given** a session has ended, **When** the user views the chat interface, **Then** they see "Your conversation is gone" message and the input is disabled
3. **Given** a session has ended, **When** the user attempts to send a message, **Then** the system prevents the action with clear feedback
4. **Given** a user was mid-message when session ended, **When** dissolution occurs, **Then** the unsent message is lost with no warning

---

### User Story 5 - User Reconnects to Active Session (Priority: P3)

A user who disconnects from an active session can rejoin using their same token and continue their conversation.

**Why this priority**: Reconnection is a resilience feature that enhances the core experience but is not required for MVP functionality.

**Independent Test**: Can be fully tested by disconnecting and reconnecting with the same token, verifying conversation history is preserved.

**Acceptance Scenarios**:

1. **Given** a user is chatting and loses connection, **When** they return with the same token, **Then** they see their previous conversation and can continue chatting
2. **Given** a user refreshes their browser, **When** they lose their token, **Then** they must obtain a new token and start a fresh conversation
3. **Given** a user's previous conversation was orphaned (browser refresh), **When** they rejoin with a new token, **Then** the orphaned conversation remains inaccessible in the kernel

---

### User Story 6 - Admin Views Session Analytics (Priority: P3)

An admin monitors session health through user counts, token purchases, and kernel lifecycle history without accessing any conversation content.

**Why this priority**: Analytics enhance operational visibility but are not required for core session management.

**Independent Test**: Can be fully tested by creating sessions, having users join, and verifying counts and timestamps display correctly.

**Acceptance Scenarios**:

1. **Given** a session is in CREATED state, **When** users purchase tokens, **Then** the admin sees the token purchase count update
2. **Given** a session is ACTIVE, **When** users join and chat, **Then** the admin sees the user count but cannot see message content
3. **Given** a session has transitioned through states, **When** the admin views the kernel status panel, **Then** they see timestamps for creation, activation, and dissolution

---

### Edge Cases

- What happens when the admin tries to start an already active session? → Action is disabled/hidden
- What happens when multiple users try to purchase the same token? → Each purchase generates a unique token
- How does the system handle rapid message sends during dissolution? → Messages after dissolution trigger are lost without delivery
- What happens if the AI service is unavailable? → User sees error message but session remains active
- What happens when a user's token is corrupted or invalid? → Join attempt fails with clear error, user prompted to purchase new token
- What happens when admin creates session with duplicate name? → Allowed; sessions are distinguished by unique ID, not name

## Requirements *(mandatory)*

### Functional Requirements

**Session Management**
- **FR-001**: System MUST allow admins to create sessions with a user-defined name
- **FR-002**: System MUST support exactly three session states: CREATED, ACTIVE, ENDED
- **FR-003**: System MUST enforce irreversible state transitions: CREATED → ACTIVE → ENDED
- **FR-004**: System MUST create the kernel when a session transitions from CREATED to ACTIVE
- **FR-005**: System MUST dissolve the kernel and destroy all conversations when a session transitions to ENDED

**Token System**
- **FR-006**: System MUST generate anonymous tokens containing no user identity information
- **FR-007**: System MUST include a random seed in each token for presence hash derivation
- **FR-008**: System MUST allow token claim (free, no payment) only for sessions in CREATED state
- **FR-009**: System MUST allow token use (session join) only for sessions in ACTIVE state
- **FR-010**: System MUST enforce one token per user per session

**Privacy & Isolation**
- **FR-011**: System MUST store all conversation data exclusively in memory (no disk persistence)
- **FR-012**: System MUST isolate each user's conversation from all other users in the same session
- **FR-013**: System MUST prevent admins from accessing any conversation content
- **FR-014**: System MUST destroy all conversation data when kernel dissolves (no recovery possible)
- **FR-015**: System MUST display user presence as a hash, never as an identity

**AI Integration**
- **FR-027**: System MUST send full conversation history from user's kernel space to AI service with each request (session-scoped context)
- **FR-028**: System MUST NOT persist AI context beyond kernel memory (context destroyed on dissolution)

**User Interface**
- **FR-016**: System MUST display session state with color indicators: gray (CREATED), green (ACTIVE), red (ENDED)
- **FR-017**: System MUST display kernel status indicator: "Kernel Active" or "Kernel Dissolved"
- **FR-018**: System MUST display "Your conversation is gone" message after dissolution
- **FR-019**: System MUST disable chat input after kernel dissolution
- **FR-020**: System MUST show user's presence hash in active chat interface

**Reconnection**
- **FR-021**: System MUST allow users to reconnect with the same token and resume their conversation
- **FR-022**: System MUST orphan conversations when users lose their token (browser refresh)
- **FR-023**: System MUST provide immediate dissolution notification to all connected users

**Analytics (Admin)**
- **FR-024**: System MUST display token purchase count for sessions in CREATED state
- **FR-025**: System MUST display user count for sessions in ACTIVE or ENDED states
- **FR-026**: System MUST display kernel lifecycle timestamps (created, activated, dissolved)

### Key Entities

- **Session**: A chatbot instance with name, current state (CREATED/ACTIVE/ENDED), timestamps, and user count
- **Token**: Anonymous access credential linking a user to a specific session, containing random seed for presence derivation
- **Session Record**: Lifecycle record storing session name, state, timestamps, and user count (no conversation content; formerly referred to as "NFT")
- **Kernel**: Ephemeral in-memory container holding isolated conversation spaces for all session participants
- **Conversation**: Private message thread between a single user and the AI, exists only within kernel memory
- **Presence Hash**: Anonymous identifier derived from token seed, displayed to user but containing no identity

## Success Criteria *(mandatory)*

### Measurable Outcomes

**Core Functionality**
- **SC-001**: Admins can complete the full session lifecycle (create → start → end) within 10 user actions
- **SC-002**: Users can discover a session, purchase a token, and join within 60 seconds
- **SC-003**: 100% of conversation data is destroyed when session ends (verifiable via system audit)
- **SC-004**: 100% of chat messages between users in the same session remain invisible to each other

**User Experience**
- **SC-005**: Session state changes are visible to users within 2 seconds of occurrence
- **SC-006**: Users receive AI responses within normal conversational expectations (same as direct AI interaction)
- **SC-007**: 95% of users understand their conversation is gone after seeing the dissolution screen (usability testing)
- **SC-008**: Kernel status indicator updates are visible within 1 second of state change

**System Capacity**
- **SC-009**: System supports at least 100 concurrent users per active session
- **SC-010**: System supports at least 10 concurrent active sessions

**Privacy Verification**
- **SC-011**: No conversation content appears in any system logs or persistent storage (audit verified)
- **SC-012**: No user identity information is derivable from tokens or presence hashes (security review verified)
- **SC-013**: Admin interface provides zero access to conversation content (penetration test verified)

## Clarifications

### Session 2026-01-24

- Q: What does "token purchase" mean - is payment required? → A: Free claim (user requests token, no payment required)
- Q: Does "NFT" involve blockchain or is it metaphorical? → A: Database record (no blockchain; renamed to "Session Record")
- Q: What context does the AI receive for conversations? → A: Session-scoped context (AI receives full conversation history from current kernel)
- Q: Which AI provider should be used? → A: OpenAI API (GPT-4o or GPT-4o-mini)

## Assumptions

The following assumptions were made based on context and industry standards:

1. **Authentication**: Admin access requires authentication; user access is fully anonymous (token-based only)
2. **Token Delivery**: Token is delivered to user immediately upon purchase (in-browser, no email/SMS)
3. **AI Service**: OpenAI API is used for conversations (GPT-4o or GPT-4o-mini); interface abstracted to allow future provider changes
4. **Single Admin Model**: One admin tier with full session control (no role hierarchy)
5. **No Rate Limiting**: Initial version does not enforce message rate limits on users
6. **Browser-Based**: Both admin and user interfaces are web-based, accessible via modern browsers
7. **Synchronous Dissolution**: All connected users see dissolution simultaneously (real-time push)
