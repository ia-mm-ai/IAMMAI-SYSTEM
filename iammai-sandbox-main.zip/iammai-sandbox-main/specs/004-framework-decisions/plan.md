# Implementation Plan: Framework Decisions

**Branch**: `004-framework-decisions` | **Date**: 2026-02-13 | **Spec**: [spec.md](./spec.md)
**Input**: Feature specification from `/specs/004-framework-decisions/spec.md`

## Summary

Organize mm.limited framework documentation under `docs/framework/` and create `FRAMEWORK_DECISIONS.md` documenting all gap-filling implementation decisions for the IAMMAI Sandbox integrity layer. This is a documentation-only feature -- no code changes, no APIs, no data models. It establishes the decision foundation for features 005-009.

## Technical Context

**Language/Version**: N/A (documentation only -- Markdown files)
**Primary Dependencies**: N/A
**Storage**: N/A (filesystem -- moving and creating Markdown files)
**Testing**: Manual verification (file existence, content completeness)
**Target Platform**: Repository documentation (developer reference)
**Project Type**: Documentation reorganization + decision records
**Performance Goals**: N/A
**Constraints**: Must not modify any source code; must not duplicate files
**Scale/Scope**: 14 files to move, 1 document to create, 1 directory to clean up

## Constitution Check

*GATE: Must pass before Phase 0 research. Re-check after Phase 1 design.*

| Principle | Applicable? | Status | Notes |
|-----------|-------------|--------|-------|
| I. Code Quality First | No | PASS | No code changes in this feature |
| II. Testing Standards | No | PASS | Documentation-only; no testable code |
| III. User Experience Consistency | No | PASS | No UI changes |
| IV. Performance Requirements | No | PASS | No runtime changes |
| V. Privacy & Ephemerality Enforcement | Yes | PASS | FRAMEWORK_DECISIONS.md explicitly establishes that the integrity layer records ONLY metadata (session IDs, timestamps, roles, PASS/FAIL) -- never message content, user input, or AI responses. Privacy boundary is documented as a first-class decision. |

**Gate Result: PASS** -- This feature is documentation-only. The constitution's code-focused principles do not apply. Principle V is satisfied because the decisions document explicitly codifies the privacy boundary between content layer (ephemeral) and integrity layer (permanent metadata only).

## Project Structure

### Documentation (this feature)

```text
specs/004-framework-decisions/
├── spec.md              # Feature specification
├── plan.md              # This file
├── research.md          # Phase 0 output (framework gap analysis)
└── checklists/
    └── requirements.md  # Spec quality checklist
```

### Source Code (repository root)

```text
docs/framework/                          # NEW - framework documentation home
├── MM-MODEL.txt                         # Enforcement specification
├── FRAMEWORK_REFERENCE.md               # Implementation patterns and schemas
├── MM-MODEL-REVIEW.md                   # Gap analysis of MM-MODEL
├── MM-MODEL-REVISED-SECTION0.txt        # Scope clarification
├── FRAMEWORK_DECISIONS.md               # NEW - gap-filling decisions
└── protocols/                           # NEW - protocol specifications
    ├── I.01_PRESENCE_TRUTH_PROTOCOL.md
    ├── I.02_EVENT_BOUNDARY_PROTOCOL.md
    ├── I.03_CONTINUITY_NON-REGRESSION_PROTOCOL.md
    ├── I.04_LEDGER_NON-ERASURE_PROTOCOL.md
    ├── I.05_PROTOCOL_SUPREMACY_PROTOCOL.md
    ├── I.06_PRESENCE-DERIVED_IDENTITY_PROTOCOL.md
    ├── I.07_ANTI-ACEDIA_PROTOCOL.md
    ├── I.08_SIGNAL_COHERENCE_PROTOCOL.md
    ├── I.09_CO-AGENCY_BALANCE_PROTOCOL.md
    └── I.10_FUTURE_INTERPRETABILITY_PROTOCOL.md
```

**Structure Decision**: Documentation-only feature. All framework files live under `docs/framework/` at repo root. No source code changes.

## Complexity Tracking

No violations to justify -- this feature is documentation-only with no architectural complexity.
