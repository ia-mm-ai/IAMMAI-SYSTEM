# Research: Framework Decisions

**Feature**: 004-framework-decisions
**Date**: 2026-02-13

## Research Summary

This feature is documentation-only. Research focuses on identifying all gaps in MM-MODEL.txt that require implementation decisions, cross-referencing with MM-MODEL-REVIEW.md findings and IAMMAI-SANDBOX-STRATEGY.md domain mapping.

---

## Gap 1: Event Interface Field Types (MM-MODEL §2.1)

**Gap**: Event fields are named but untyped. `event_id` has no specified format. `context_descriptor` and `environmental_constraints` have no type, structure, or validation rule.

**Decision**: Use UUID v4 for event_id (maps to existing session_id). Timestamps as ISO 8601 UTC strings. `context_descriptor` as JSON object `{ topic: string, purpose?: string }`. `environmental_constraints` as JSON object `{ max_participants: number, time_limit_minutes?: number, ai_model?: string }`.

**Rationale**: UUID v4 aligns with existing session model. ISO 8601 is the universal timestamp standard. JSON schemas give structure while remaining flexible. These match the existing IAMMAI Sandbox session fields.

**Alternatives considered**: Auto-incrementing integer IDs (rejected -- no UUID guarantees), Unix timestamps (rejected -- less human-readable), free-text descriptors (rejected -- not machine-evaluable).

---

## Gap 2: State Space Mapping (MM-MODEL §2.1)

**Gap**: MM-MODEL defines `status ∈ {OPEN, CLOSED}`. IAMMAI Sandbox has three states: `CREATED`, `ACTIVE`, `ENDED`. No mapping is provided.

**Decision**: Map IAMMAI Sandbox `CREATED` and `ACTIVE` to framework `OPEN`. Map IAMMAI Sandbox `ENDED` to framework `CLOSED`. The integrity layer treats any non-ENDED session as OPEN for protocol purposes.

**Rationale**: The framework's OPEN/CLOSED distinction is about whether truth finalization can occur. In IAMMAI Sandbox, truth finalization (witness emission, verification) must not happen until a session reaches ENDED. Both CREATED and ACTIVE are pre-finalization states, making them semantically equivalent to OPEN.

**Alternatives considered**: Three-state model with CREATED as a separate pre-OPEN state (rejected -- framework explicitly uses binary status, and no protocol behavior differs between CREATED and ACTIVE from an integrity perspective).

---

## Gap 3: Presence State Space (MM-MODEL §2.2)

**Gap**: Presence declared as boolean (`true | false`) but section ends with "If any rule fails → Presence = INVALID." INVALID is a contradictory third state.

**Decision**: Binary presence only: `true` or `false`. No INVALID state. If attestation rules fail, presence resolves to `false` (not a third state). The INVALID notation in MM-MODEL is interpreted as "the attestation is rejected, therefore presence = false."

**Rationale**: The review identifies this as a direct contradiction in MM-MODEL. The boolean declaration is the primary specification; the INVALID clause is an error-handling behavior, not a third state. Resolving failed attestation to `false` maintains the binary contract while handling the error case.

**Alternatives considered**: Ternary presence with INVALID (rejected -- contradicts the boolean declaration and complicates all protocol evaluators that check presence).

---

## Gap 4: Identity Formula (MM-MODEL §6)

**Gap**: `ID = Σ presence(event_k)` uses summation notation. If presence is boolean, sum of booleans is an integer. Two different entities present at the same number of events produce the same identity value.

**Decision**: Identity as set construction: `identity(actor) = {session_k | presence(actor, session_k) = true}`. Admin identity is the set of sessions where verified admin presence exists. Anonymous users have no identity (valid -- identity gaps are allowed per §6).

**Rationale**: The review identifies the formula as "mathematically incoherent" and notes it "almost certainly intends a set construction." Set construction produces unique identities (each admin has a unique set of sessions). IAMMAI-SANDBOX-STRATEGY.md §3.10 explicitly adopts this interpretation.

**Alternatives considered**: Literal summation (count of sessions -- rejected because it's not unique), hash-based identity (rejected -- §6 forbids credential-based identity assertions).

---

## Gap 5: Signal Coherence Evaluation (MM-MODEL §2.3)

**Gap**: "Signal meaning MUST be singular" and "Ambiguity → REJECT" require semantic judgment that no machine can perform without NLP. "Narrative framing → REJECT" requires content classification.

**Decision**: Signal coherence applies only to system/admin commands that trigger state changes, not to user chat messages or AI responses. Coherence check: reject contradictory state-changing commands in the same request (e.g., "extend session" + "close session"). Chat content is exempt -- it lives in the ephemeral content layer, not the integrity layer.

**Rationale**: The review notes this is "the worst offender" in the spec. Full semantic signal evaluation is impractical. IAMMAI-SANDBOX-STRATEGY.md §2.3 scopes signals to message types with clear intent fields. By limiting coherence checks to structured admin commands (which have machine-evaluable intent), we avoid the NLP problem entirely while satisfying the protocol's spirit.

**Alternatives considered**: NLP-based signal evaluation (rejected -- impractical, non-deterministic), ignoring signal coherence entirely (rejected -- protocol supremacy requires all protocols to be implemented).

---

## Gap 6: Acedia Thresholds (MM-MODEL §7.2)

**Gap**: "capacity is legitimate" is undefined. "HOLD persists" has no duration, threshold, or measurement. No implementation can detect acedia without these.

**Decision**: Three thresholds:
- CREATED state idle for 15 minutes → acedia warning
- ACTIVE state idle for 30 minutes (no messages) → acedia detection
- On detection: 10-minute countdown with admin notification before forced RELEASE

**Rationale**: IAMMAI-SANDBOX-STRATEGY.md §3.7 proposes these exact thresholds. 15 minutes for CREATED accounts for session setup delays. 30 minutes for ACTIVE gives reasonable conversation pauses. 10-minute countdown provides a final chance before forced resolution. All thresholds are configurable for production tuning.

**Alternatives considered**: Single threshold for all states (rejected -- CREATED and ACTIVE have different activity patterns), immediate forced resolution (rejected -- too aggressive, no grace period).

---

## Gap 7: Co-Agency Balance Metric (MM-MODEL §9)

**Gap**: "Imbalance → suppression" but no metric, ratio, or test for imbalance. "No unilateral dominance" is not machine-evaluable without a threshold.

**Decision**: Maximum 2 consecutive irreversible actions per agent type (human or AI) without the other agent type's involvement. Irreversible actions for this PoC: session termination, presence finalization, verification execution, suppression enforcement.

**Rationale**: IAMMAI-SANDBOX-STRATEGY.md §3.8 proposes this metric. The "consecutive irreversible actions" framing is machine-evaluable (simple counter per agent type). The limit of 2 prevents dominance while allowing reasonable operational flow. Only irreversible actions count -- routine operations (message sending, reading) are exempt.

**Alternatives considered**: Ratio-based balance (e.g., 60/40 split -- rejected because it requires window-based measurement and is harder to evaluate in real-time), per-action voting (rejected -- too restrictive for normal operations).

---

## Gap 8: Verification Dispatch Model (MM-MODEL §3.1)

**Gap**: `V(event, presence, protocol_set) → PASS | FAIL` declares a function signature but not body. Two implementers could write different verification logic and both claim compliance.

**Decision**: Verification dispatches to per-protocol evaluators. Each protocol (I.01-I.10) has its own evaluator with defined pass/fail conditions from the protocol specifications. Overall verification result is PASS only if ALL individual protocol evaluators pass (conjunctive/AND evaluation). This makes verification deterministic given the same protocol implementations.

**Rationale**: The review notes the MM-MODEL "almost certainly intends" that verification logic is defined per protocol_set. The individual protocol specifications (I.01-I.10) each define their own pass/fail conditions, which serve as the function body. Conjunctive evaluation (all must pass) matches the compliance test in §11 which requires ALL conditions to be met.

**Alternatives considered**: Single monolithic evaluator (rejected -- not maintainable, hard to add protocols), weighted scoring (rejected -- §11 compliance is binary, not weighted), disjunctive evaluation (any pass = overall pass -- rejected -- contradicts §11's all-or-nothing compliance).

---

## Gap 9: Witness Artifact Format (MM-MODEL §3.2)

**Gap**: Witness fields are enumerated but format is unspecified. No indication of JSON, protobuf, or other serialization.

**Decision**: JSON format with typed fields. Additional metadata fields: `artifact_type`, `artifact_version`, `system`, `metadata` (participant count, session name, duration). Self-describing per §10 (Future Interpretability).

**Rationale**: JSON is human-readable (satisfying interpretability), widely supported, and matches the project's existing data patterns. Self-describing fields (artifact_type, artifact_version) allow a future system to interpret the artifact without external documentation.

**Alternatives considered**: Protobuf (rejected -- not human-readable, violates interpretability), plain text (rejected -- not structured enough for machine evaluation).

---

## Gap 10: Privacy Boundary

**Gap**: Not a gap in MM-MODEL per se, but the IAMMAI Sandbox constitution (Principle V) requires explicit architectural enforcement of privacy. The integrity layer must be provably separate from content.

**Decision**: The integrity layer records ONLY metadata. Explicitly never recorded: message content, user input, AI responses, user identities, IP addresses, device info, conversation context, personal data. Explicitly recorded: session ID/name/state, timestamps, participant count, presence roles + anonymous hashes, verification PASS/FAIL, suppression events (action type + reason), AI model name + token count (not output content).

**Rationale**: This is the "different layers of the Reality Stack" principle from IAMMAI-SANDBOX-STRATEGY.md §1. The framework governs integrity metadata; the chatbot owns ephemeral content. These never mix. This satisfies both the constitution's privacy mandate and the framework's witness requirements.

**Alternatives considered**: None -- this boundary is non-negotiable per the constitution.
