# Tasks: Framework Decisions

**Input**: Design documents from `/specs/004-framework-decisions/`
**Prerequisites**: plan.md (required), spec.md (required for user stories), research.md

**Tests**: Not applicable -- this is a documentation-only feature with no code.

**Organization**: Tasks are grouped by user story to enable independent implementation and testing of each story.

## Format: `[ID] [P?] [Story] Description`

- **[P]**: Can run in parallel (different files, no dependencies)
- **[Story]**: Which user story this task belongs to (e.g., US1, US2, US3)
- Include exact file paths in descriptions

## Path Conventions

- Documentation-only feature: all paths under `docs/framework/` at repository root
- Source files: `framework-files/` (current location, to be migrated)

---

## Phase 1: Setup

**Purpose**: Create target directory structure for framework documentation

- [x] T001 Create directory structure: `docs/framework/` and `docs/framework/protocols/` at repository root

---

## Phase 2: User Story 1 - Organized Framework Documentation (Priority: P1) MVP

**Goal**: All 14 framework files organized under `docs/framework/` with legacy location cleaned up

**Independent Test**: Verify `docs/framework/` contains 4 core docs, `docs/framework/protocols/` contains 10 protocol files, and `framework-files/` is removed

### Implementation for User Story 1

- [x] T002 [P] [US1] Move `framework-files/MM-MODEL.txt` to `docs/framework/MM-MODEL.txt`
- [x] T003 [P] [US1] Move `framework-files/FRAMEWORK_REFERENCE.md` to `docs/framework/FRAMEWORK_REFERENCE.md`
- [x] T004 [P] [US1] Move `framework-files/MM-MODEL-REVIEW.md` to `docs/framework/MM-MODEL-REVIEW.md`
- [x] T005 [P] [US1] Move `framework-files/MM-MODEL-REVISED-SECTION0.txt` to `docs/framework/MM-MODEL-REVISED-SECTION0.txt`
- [x] T006 [P] [US1] Move `framework-files/pdfs/I.01_PRESENCE_TRUTH_PROTOCOL.md` to `docs/framework/protocols/I.01_PRESENCE_TRUTH_PROTOCOL.md`
- [x] T007 [P] [US1] Move `framework-files/pdfs/I.02_EVENT_BOUNDARY_PROTOCOL.md` to `docs/framework/protocols/I.02_EVENT_BOUNDARY_PROTOCOL.md`
- [x] T008 [P] [US1] Move `framework-files/pdfs/I.03_CONTINUITY_NON-REGRESSION_PROTOCOL.md` to `docs/framework/protocols/I.03_CONTINUITY_NON-REGRESSION_PROTOCOL.md`
- [x] T009 [P] [US1] Move `framework-files/pdfs/I.04_LEDGER_NON-ERASURE_PROTOCOL.md` to `docs/framework/protocols/I.04_LEDGER_NON-ERASURE_PROTOCOL.md`
- [x] T010 [P] [US1] Move `framework-files/pdfs/I.05_PROTOCOL_SUPREMACY_PROTOCOL.md` to `docs/framework/protocols/I.05_PROTOCOL_SUPREMACY_PROTOCOL.md`
- [x] T011 [P] [US1] Move `framework-files/pdfs/I.06_PRESENCE-DERIVED_IDENTITY_PROTOCOL.md` to `docs/framework/protocols/I.06_PRESENCE-DERIVED_IDENTITY_PROTOCOL.md`
- [x] T012 [P] [US1] Move `framework-files/pdfs/I.07_ANTI-ACEDIA_PROTOCOL.md` to `docs/framework/protocols/I.07_ANTI-ACEDIA_PROTOCOL.md`
- [x] T013 [P] [US1] Move `framework-files/pdfs/I.08_SIGNAL_COHERENCE_PROTOCOL.md` to `docs/framework/protocols/I.08_SIGNAL_COHERENCE_PROTOCOL.md`
- [x] T014 [P] [US1] Move `framework-files/pdfs/I.09_CO-AGENCY_BALANCE_PROTOCOL.md` to `docs/framework/protocols/I.09_CO-AGENCY_BALANCE_PROTOCOL.md`
- [x] T015 [P] [US1] Move `framework-files/pdfs/I.10_FUTURE_INTERPRETABILITY_PROTOCOL.md` to `docs/framework/protocols/I.10_FUTURE_INTERPRETABILITY_PROTOCOL.md`
- [x] T016 [US1] Remove empty `framework-files/` directory (and `framework-files/pdfs/` subdirectory) after all files are moved
- [x] T017 [US1] Update `.gitignore` if it references `framework-files/` path, and update any other project files that reference the old location

**Checkpoint**: Framework documentation is accessible at `docs/framework/`. Legacy location is gone.

---

## Phase 3: User Story 2 - Gap-Filling Decisions Document (Priority: P1)

**Goal**: FRAMEWORK_DECISIONS.md created with all 10 gap-filling decisions, each containing gap reference, decision, and rationale

**Independent Test**: Verify `docs/framework/FRAMEWORK_DECISIONS.md` exists with all 8+ decision categories, each having gap reference (MM-MODEL section), decision, and rationale

### Implementation for User Story 2

- [x] T018 [US2] Create `docs/framework/FRAMEWORK_DECISIONS.md` with document header: title, version metadata (framework version: MM-MODEL Post-Freeze, date: 2026-02-13), purpose statement, and amendment history section
- [x] T019 [US2] Write Decision 1 in `docs/framework/FRAMEWORK_DECISIONS.md`: Event Interface Field Types -- gap (MM-MODEL §2.1 fields untyped), decision (UUID v4 for event_id, ISO 8601 UTC timestamps, JSON schemas for context_descriptor and environmental_constraints), rationale (aligns with existing session model)
- [x] T020 [US2] Write Decision 2 in `docs/framework/FRAMEWORK_DECISIONS.md`: State Space Mapping -- gap (MM-MODEL §2.1 OPEN/CLOSED vs IAMMAI Sandbox CREATED/ACTIVE/ENDED), decision (CREATED+ACTIVE=OPEN, ENDED=CLOSED), rationale (both pre-finalization states are semantically OPEN)
- [x] T021 [US2] Write Decision 3 in `docs/framework/FRAMEWORK_DECISIONS.md`: Presence Model -- gap (MM-MODEL §2.2 boolean vs INVALID contradiction), decision (binary true/false only, failed attestation=false), rationale (boolean is primary spec, INVALID is error handling)
- [x] T022 [US2] Write Decision 4 in `docs/framework/FRAMEWORK_DECISIONS.md`: Identity Formula -- gap (MM-MODEL §6 summation incoherent), decision (set construction: {session_k | presence(actor, session_k)=true}), rationale (produces unique identities, matches review recommendation)
- [x] T023 [US2] Write Decision 5 in `docs/framework/FRAMEWORK_DECISIONS.md`: Signal Coherence Criteria -- gap (MM-MODEL §2.3 requires NLP), decision (apply only to admin commands, reject contradictory state-changing commands), rationale (avoids NLP, satisfies protocol spirit)
- [x] T024 [US2] Write Decision 6 in `docs/framework/FRAMEWORK_DECISIONS.md`: Acedia Thresholds -- gap (MM-MODEL §7.2 undefined terms), decision (15min CREATED, 30min ACTIVE, 10min countdown), rationale (matches IAMMAI-SANDBOX-STRATEGY, configurable for production)
- [x] T025 [US2] Write Decision 7 in `docs/framework/FRAMEWORK_DECISIONS.md`: Co-Agency Balance Metric -- gap (MM-MODEL §9 no metric), decision (max 2 consecutive irreversible actions per agent type), rationale (machine-evaluable counter, prevents dominance)
- [x] T026 [US2] Write Decision 8 in `docs/framework/FRAMEWORK_DECISIONS.md`: Verification Dispatch Model -- gap (MM-MODEL §3.1 signature without body), decision (per-protocol evaluators, conjunctive AND, PASS only if ALL pass), rationale (matches §11 compliance test, maintainable)
- [x] T027 [US2] Write Decision 9 in `docs/framework/FRAMEWORK_DECISIONS.md`: Witness Artifact Format -- gap (MM-MODEL §3.2 format unspecified), decision (JSON with self-describing fields: artifact_type, artifact_version, system, metadata), rationale (human-readable, satisfies interpretability)
- [x] T028 [US2] Write Decision 10 in `docs/framework/FRAMEWORK_DECISIONS.md`: Privacy Boundary -- gap (constitution Principle V), decision (integrity layer records ONLY metadata, never content), rationale (Reality Stack layer separation, non-negotiable per constitution)

**Checkpoint**: FRAMEWORK_DECISIONS.md is complete with all 10 decisions, each properly structured.

---

## Phase 4: User Story 3 - Traceability from Framework to Implementation (Priority: P2)

**Goal**: Each decision in FRAMEWORK_DECISIONS.md has full traceability: MM-MODEL section reference, MM-MODEL-REVIEW.md finding, and IAMMAI Sandbox-specific rationale

**Independent Test**: Select any 3 decisions at random, verify each contains MM-MODEL section reference, review finding reference, and IAMMAI Sandbox rationale

### Implementation for User Story 3

- [x] T029 [US3] Enhance all 10 decisions in `docs/framework/FRAMEWORK_DECISIONS.md` to include explicit traceability links: "MM-MODEL Reference" field (section number), "Review Finding" field (specific MM-MODEL-REVIEW.md quote/reference), and "IAMMAI Sandbox Rationale" field (domain-specific justification)
- [x] T030 [US3] Add traceability index table to `docs/framework/FRAMEWORK_DECISIONS.md` mapping each decision to its MM-MODEL section, review finding, and implementing feature (005-009)

**Checkpoint**: Every decision is traceable from framework concept through gap identification to IAMMAI Sandbox implementation choice.

---

## Phase 5: Polish & Cross-Cutting Concerns

**Purpose**: Final validation and consistency checks

- [x] T031 Verify all 14 files exist at correct locations under `docs/framework/` and `docs/framework/protocols/`
- [x] T032 Verify `framework-files/` directory no longer exists
- [x] T033 Review all 10 decisions in `docs/framework/FRAMEWORK_DECISIONS.md` for internal consistency (no decision contradicts another)
- [x] T034 Update `IAMMAI-SANDBOX-STRATEGY.md` to reference new `docs/framework/` paths instead of `framework-files/`

---

## Dependencies & Execution Order

### Phase Dependencies

- **Setup (Phase 1)**: No dependencies -- can start immediately
- **US1 (Phase 2)**: Depends on Setup (T001) -- directory must exist before moving files
- **US2 (Phase 3)**: Can start after Setup (T001) -- does not depend on US1 file moves
- **US3 (Phase 4)**: Depends on US2 completion -- traceability enhances existing decisions
- **Polish (Phase 5)**: Depends on US1 and US2 completion at minimum

### User Story Dependencies

- **User Story 1 (P1)**: Depends only on Setup (Phase 1). No dependencies on other stories.
- **User Story 2 (P1)**: Depends only on Setup (Phase 1). Can run in parallel with US1.
- **User Story 3 (P2)**: Depends on US2 completion (decisions must exist before adding traceability).

### Within Each User Story

- US1: All file moves (T002-T015) are parallel; cleanup (T016-T017) depends on all moves completing
- US2: Document header (T018) first, then all 10 decisions (T019-T028) are sequential within a single file
- US3: Traceability enhancement (T029) before index table (T030)

### Parallel Opportunities

- T002-T015 can all run in parallel (different source and target files)
- US1 and US2 can run in parallel (different target files: moving files vs creating FRAMEWORK_DECISIONS.md)

---

## Parallel Example: User Story 1

```bash
# All file moves can run in parallel (different files):
Task: "Move framework-files/MM-MODEL.txt to docs/framework/MM-MODEL.txt"
Task: "Move framework-files/FRAMEWORK_REFERENCE.md to docs/framework/FRAMEWORK_REFERENCE.md"
Task: "Move framework-files/MM-MODEL-REVIEW.md to docs/framework/MM-MODEL-REVIEW.md"
Task: "Move framework-files/MM-MODEL-REVISED-SECTION0.txt to docs/framework/MM-MODEL-REVISED-SECTION0.txt"
# ... and all 10 protocol files simultaneously
```

---

## Implementation Strategy

### MVP First (User Story 1 Only)

1. Complete Phase 1: Setup (create directories)
2. Complete Phase 2: US1 (move all 14 files, clean up legacy directory)
3. **STOP and VALIDATE**: Verify all files accessible at `docs/framework/`
4. Framework docs are now organized -- developers can find them

### Incremental Delivery

1. Setup + US1 → Framework docs organized (MVP)
2. Add US2 → All decisions documented → Ready for features 005-009
3. Add US3 → Full traceability → Improved auditability
4. Polish → Final validation and consistency

---

## Notes

- [P] tasks = different files, no dependencies
- [Story] label maps task to specific user story for traceability
- This is a documentation-only feature -- all tasks involve creating/moving Markdown files
- No code changes, no tests required
- US2 tasks (T019-T028) write to a single file sequentially; content is drawn from research.md
- Commit after each phase for clean git history
