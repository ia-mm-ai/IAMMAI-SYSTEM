# Feature Specification: Framework Decisions

**Feature Branch**: `004-framework-decisions`
**Created**: 2026-02-13
**Status**: Draft
**Input**: User description: "Organize framework documentation and record all gap-filling implementation decisions before building the integrity layer."

## User Scenarios & Testing *(mandatory)*

### User Story 1 - Organized Framework Documentation (Priority: P1)

A developer joining the IAMMAI Sandbox project needs to understand the mm.limited framework that governs the integrity layer. They navigate to `docs/framework/` and find all framework reference documents (MM-MODEL, Framework Reference, Review, Revised Section 0) organized in a single location, with protocol specifications in a `protocols/` subdirectory. They no longer need to search `framework-files/` or wonder which documents are canonical.

**Why this priority**: Without organized, accessible framework documentation, no developer can understand or implement the integrity layer. This is the prerequisite for all subsequent features (005-009).

**Independent Test**: Can be tested by verifying `docs/framework/` contains all 4 core documents and `docs/framework/protocols/` contains all 10 protocol specifications (I.01-I.10), with no framework documents remaining in `framework-files/`.

**Acceptance Scenarios**:

1. **Given** the project repository, **When** a developer navigates to `docs/framework/`, **Then** they find MM-MODEL.txt, FRAMEWORK_REFERENCE.md, MM-MODEL-REVIEW.md, and MM-MODEL-REVISED-SECTION0.txt
2. **Given** the project repository, **When** a developer navigates to `docs/framework/protocols/`, **Then** they find all 10 protocol specification files (I.01 through I.10)
3. **Given** the framework documents have been moved, **When** a developer checks `framework-files/`, **Then** the directory no longer contains the moved files (directory may be removed or contain only a redirect notice)

---

### User Story 2 - Gap-Filling Decisions Document (Priority: P1)

A developer needs to implement the integrity layer but the MM-MODEL specification leaves structural decisions to implementer judgment (field types, thresholds, state mappings, identity formulas). They open `docs/framework/FRAMEWORK_DECISIONS.md` and find every gap-filling choice explicitly documented with: the gap identified (referencing MM-MODEL-REVIEW.md), the decision made, and the rationale. This eliminates ambiguity and prevents each developer from making inconsistent choices.

**Why this priority**: The MM-MODEL review identifies dozens of gaps that require implementation decisions. Without a single source of truth for these decisions, developers will make inconsistent choices, producing a non-compliant system.

**Independent Test**: Can be tested by verifying that FRAMEWORK_DECISIONS.md covers all 8 decision categories with gap reference, decision, and rationale for each.

**Acceptance Scenarios**:

1. **Given** the decisions document exists, **When** a developer reads FRAMEWORK_DECISIONS.md, **Then** they find documented decisions for: event interface field types, state mapping, presence model, identity formula, signal coherence criteria, acedia thresholds, co-agency balance metric, and verification dispatch model
2. **Given** a specific gap (e.g., "event_id has no specified format"), **When** a developer looks up the decision, **Then** they find the chosen type (UUID v4), the gap it addresses (MM-MODEL §2.1), and why this choice was made
3. **Given** all decisions are documented, **When** a developer cross-references with MM-MODEL-REVIEW.md, **Then** every actionable gap identified in the review has a corresponding decision in FRAMEWORK_DECISIONS.md

---

### User Story 3 - Traceability from Framework to Implementation (Priority: P2)

A developer working on a specific protocol evaluator needs to understand how an abstract framework concept maps to a concrete IAMMAI Sandbox implementation choice. The decisions document provides traceability: each decision references the MM-MODEL section it interprets, the review finding that identified the gap, and the IAMMAI Sandbox-specific rationale. A developer can trace from "MM-MODEL §2.2 presence is boolean" to "Review: INVALID is a contradictory third state" to "Decision: binary true/false, no INVALID state."

**Why this priority**: Traceability is valuable for auditability and onboarding but is not blocking for implementation. Features 005-009 can proceed with just the decisions (US2); traceability improves maintainability.

**Independent Test**: Can be tested by selecting any decision and verifying it contains references to both the MM-MODEL source section and the review finding.

**Acceptance Scenarios**:

1. **Given** a decision about presence model, **When** a developer reads its entry, **Then** they see references to MM-MODEL §2.2, MM-MODEL-REVIEW.md finding about contradictory INVALID state, and the IAMMAI Sandbox-specific rationale
2. **Given** a decision about identity formula, **When** a developer reads its entry, **Then** they see the original formula from MM-MODEL §6, the review's finding of mathematical incoherence, and the replacement set construction formula

---

### Edge Cases

- What happens when a new gap is discovered during implementation (005-009)? The decisions document includes a versioning/amendment section for recording post-initial decisions.
- What happens when a framework document is updated upstream? The decisions document notes the framework version it was written against.
- What if two decisions conflict? Each decision is reviewed for consistency with all others before finalization.

## Requirements *(mandatory)*

### Functional Requirements

- **FR-001**: System MUST organize all framework reference documents under `docs/framework/` with protocol specs under `docs/framework/protocols/`
- **FR-002**: System MUST provide a FRAMEWORK_DECISIONS.md document at `docs/framework/FRAMEWORK_DECISIONS.md`
- **FR-003**: FRAMEWORK_DECISIONS.md MUST document the event interface field types decision: event_id as UUID v4, timestamps as ISO 8601 UTC, context_descriptor and environmental_constraints as JSON objects with defined schemas
- **FR-004**: FRAMEWORK_DECISIONS.md MUST document the state mapping decision: IAMMAI Sandbox states CREATED and ACTIVE map to framework OPEN; IAMMAI Sandbox state ENDED maps to framework CLOSED
- **FR-005**: FRAMEWORK_DECISIONS.md MUST document the presence model decision: binary (true/false) only, no ternary INVALID state; failed validation results in false, not a third state
- **FR-006**: FRAMEWORK_DECISIONS.md MUST document the identity formula decision: set construction `{session_k | presence(admin, session_k) = true}` replacing the mathematically incoherent summation formula
- **FR-007**: FRAMEWORK_DECISIONS.md MUST document the signal coherence criteria: reject contradictory state-changing commands within the same request; coherence evaluation applies only to system/admin commands, not user chat messages
- **FR-008**: FRAMEWORK_DECISIONS.md MUST document acedia threshold decisions: 15-minute idle threshold for CREATED state, 30-minute idle threshold for ACTIVE state, 10-minute countdown after detection before forced resolution
- **FR-009**: FRAMEWORK_DECISIONS.md MUST document the co-agency balance metric: maximum 2 consecutive irreversible actions per agent type (human or AI) before the other must be involved
- **FR-010**: FRAMEWORK_DECISIONS.md MUST document the verification dispatch model: verification dispatches to per-protocol evaluators, overall result is PASS only if ALL protocol evaluators pass (conjunctive evaluation)
- **FR-011**: Each decision entry MUST include: the gap being addressed (with MM-MODEL section reference), the decision made, and the rationale for the choice
- **FR-012**: FRAMEWORK_DECISIONS.md MUST include version metadata (framework version referenced, date created, amendment history section)
- **FR-013**: The original `framework-files/` directory MUST be cleaned up after migration (files moved, not duplicated)

### Key Entities

- **Framework Document**: A reference document from the mm.limited framework (MM-MODEL, review, protocols). Has a title, source location, and target location.
- **Implementation Decision**: A gap-filling choice made where the MM-MODEL is ambiguous or incomplete. Has a gap reference, decision statement, rationale, and traceability links.
- **Protocol Specification**: One of the 10 invariant protocol documents (I.01-I.10). Has an identifier, title, and pass/fail conditions.

## Success Criteria *(mandatory)*

### Measurable Outcomes

- **SC-001**: All 14 framework files (4 core + 10 protocols) are accessible under a single documentation directory with zero files remaining in the legacy location
- **SC-002**: 100% of identified gaps from the framework review have corresponding documented decisions (minimum 8 decision categories)
- **SC-003**: Every decision entry contains all three required elements: gap reference, decision, and rationale
- **SC-004**: A developer unfamiliar with the project can locate and understand any framework concept's IAMMAI Sandbox-specific implementation within 2 minutes by navigating the documentation structure
- **SC-005**: No implementation decision contradicts another — all decisions are internally consistent
- **SC-006**: The decisions document explicitly references the framework version it was written against, enabling future compatibility checks
