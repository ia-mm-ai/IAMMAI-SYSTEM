# Feature Specification: Presence Tracking & Protocol Suppression

**Feature Branch**: `007-presence-suppression`
**Created**: 2026-02-14
**Status**: Draft
**Input**: User description: "Track actor presence (admin, user, AI) with attestation; enforce protocol-based suppression that halts execution on verification FAIL, prevents mutation, and records attempts. Implements protocols I.01 (Presence Truth), I.05 (Protocol Supremacy), I.08 (Signal Coherence). Depends on 006-verification-witness being complete."
**Depends On**: 006-verification-witness (complete)

## User Scenarios & Testing *(mandatory)*

### User Story 1 - Admin Presence Attested on Session Creation (Priority: P1)

When an administrator creates a new chat session, the system automatically records the admin's presence as attested. The attestation is derived from the authentication event that authorized the session creation. The admin's identity is anonymized (no personal details stored — only a presence hash and role).

**Why this priority**: Admin presence is the foundational attestation — every session begins with an admin creating it. Without this, no session can have verified presence.

**Independent Test**: Create a session as an authenticated admin, then inspect the presence records to confirm an admin attestation exists with correct role and method.

**Acceptance Scenarios**:

1. **Given** an authenticated admin, **When** they create a new session, **Then** a presence record is stored with role=CREATOR, attestation method=AUTH_EVENT, and attested=true
2. **Given** an unauthenticated request, **When** it attempts to create a session, **Then** no presence record is created (existing auth rejection applies)
3. **Given** a session already created, **When** the admin's presence is queried, **Then** the record shows attested=true and is not yet finalized

---

### User Story 2 - User Presence Attested on Session Join (Priority: P1)

When an anonymous user joins a session via a join token, the system records their presence. The user is assigned role=PARTICIPANT. Presence is attested by the join event itself — the act of connecting with a valid token constitutes attestation.

**Why this priority**: User presence is required for the Presence Truth protocol (I.01) which mandates 2+ independent attestation methods per session. Without participant attestation, no session can achieve I.01 compliance.

**Independent Test**: Generate a join token, connect as an anonymous user, then verify a participant presence record exists.

**Acceptance Scenarios**:

1. **Given** a valid join token for an active session, **When** a user connects, **Then** a presence record is stored with role=PARTICIPANT, attestation method=JOIN_TOKEN, and attested=true
2. **Given** multiple users joining the same session, **When** each connects, **Then** each gets a distinct presence record with a unique anonymous presence hash
3. **Given** an expired or invalid join token, **When** a user attempts to connect, **Then** no presence record is created

---

### User Story 3 - AI Presence Attested on First Message Processing (Priority: P1)

When the AI agent processes its first message within a session, the system records AI presence. This ensures the AI's involvement is tracked as part of the session's presence set. The AI role is AGENT, attested by the system event of message processing.

**Why this priority**: AI presence completes the three-actor attestation model. The Presence Truth protocol requires that all active participants have attested presence.

**Independent Test**: Start a session, send a message that triggers AI processing, verify an AGENT presence record exists.

**Acceptance Scenarios**:

1. **Given** an active session with no AI presence yet, **When** the AI processes its first message, **Then** a presence record is stored with role=AGENT, attestation method=MESSAGE_PROCESSING, and attested=true
2. **Given** an active session where AI has already been attested, **When** the AI processes subsequent messages, **Then** no duplicate presence record is created
3. **Given** a session that closes without any AI interaction, **When** presence is finalized, **Then** no AGENT presence record exists (absence is valid)

---

### User Story 4 - Presence Finalized Only After Session Closes (Priority: P1)

Presence records are only finalized (locked and made permanent) after the session transitions to ENDED state. While a session is OPEN (CREATED or ACTIVE), presence records remain mutable — new participants can join and be attested. Once the session closes, all presence records for that session are finalized and no further modifications are permitted.

**Why this priority**: The framework mandates that truth finalizes only via presence in closed events. Premature finalization would violate the core integrity guarantee.

**Independent Test**: Create and close a session, verify all presence records are marked finalized. Then attempt to add a new presence record to the closed session — it must be rejected.

**Acceptance Scenarios**:

1. **Given** an active session with attested presence records, **When** the session transitions to ENDED, **Then** all presence records for that session are marked as finalized with a finalization timestamp
2. **Given** a closed session with finalized presence, **When** an attempt is made to add a new presence record, **Then** the system rejects the attempt
3. **Given** a closed session with finalized presence, **When** an attempt is made to modify an existing presence record, **Then** the system rejects the modification

---

### User Story 5 - Suppression Halts Execution on Verification Failure (Priority: P1)

When the verification engine produces a FAIL result for any protocol, the suppression engine intercepts the action that triggered verification and prevents it from completing. The suppression is mandatory — no configuration or authority level can bypass it. The blocked action, the reason for suppression, and the failed protocol are all recorded in the integrity ledger.

**Why this priority**: Suppression is the enforcement mechanism that gives verification teeth. Without it, protocol violations would be logged but not prevented, undermining the entire integrity guarantee.

**Independent Test**: Trigger a scenario that causes protocol verification to FAIL (e.g., attempt to end a session with invalid state), verify the action is blocked and a suppression record appears in the ledger.

**Acceptance Scenarios**:

1. **Given** a non-closure action that triggers verification, **When** verification returns FAIL, **Then** the action is halted before any state mutation occurs
4. **Given** a session closure that triggers verification, **When** verification returns FAIL, **Then** the session still closes but a FAIL witness is emitted and the suppression is recorded
2. **Given** a suppressed action, **When** the suppression is recorded, **Then** the ledger entry includes the action type, the failed protocol(s), and the reason for suppression
3. **Given** a suppressed action, **When** downstream operations depend on it, **Then** those downstream operations are also blocked

---

### User Story 6 - Admin Commands Validated Before Execution (Priority: P2)

Administrative commands (such as extending session duration, terminating a session, or modifying session parameters) must pass through protocol validation before the system executes them. If a command would violate any active protocol, it is suppressed. This ensures that no administrative authority can override the integrity framework.

**Why this priority**: Protocol supremacy (I.05) is a governance requirement but builds on the suppression mechanism from US5. It specifically targets admin actions rather than general session lifecycle events.

**Independent Test**: Issue an admin command that conflicts with protocol rules (e.g., attempt to reopen a closed session), verify the command is rejected with a suppression record.

**Acceptance Scenarios**:

1. **Given** an admin command that complies with all protocols, **When** the command is submitted, **Then** it executes normally
2. **Given** an admin command that violates a protocol, **When** the command is submitted, **Then** it is suppressed before execution and the attempt is recorded
3. **Given** an admin attempting to override a verification result, **When** the override command is submitted, **Then** it is suppressed and the override attempt is recorded in the ledger

---

### User Story 7 - Contradictory Admin Commands Rejected (Priority: P2)

When an administrator issues commands that contradict each other within the same request or within a short coherence window, the system detects the contradiction and rejects both commands. Signal coherence applies only to administrative commands — not to chat content or user messages.

**Why this priority**: Signal coherence (I.08) prevents ambiguous system states caused by conflicting admin instructions. It is scoped to admin commands only per framework decisions.

**Independent Test**: Submit two contradictory admin commands (e.g., "extend session" and "close session" simultaneously), verify both are rejected with a coherence violation.

**Acceptance Scenarios**:

1. **Given** two admin commands that contradict each other, **When** submitted together, **Then** both are rejected with a signal coherence violation
2. **Given** a single unambiguous admin command, **When** submitted, **Then** it proceeds through normal validation
3. **Given** contradictory commands, **When** the rejection is recorded, **Then** the ledger entry identifies which commands conflicted and why

---

### Edge Cases

- What happens when a session closes with zero participants (admin-only session)? Presence finalization still occurs for the admin. The session closes with an I.01 FAIL witness because only 1 attestation method is present (requires 2+). This is acceptable — the FAIL is a factual record.
- What happens when the AI presence attestation event arrives after the session has already started closing? The attestation is accepted only if the session has not yet transitioned to ENDED state.
- What happens when suppression is triggered during witness emission? The witness records the suppression event; the witness itself is still emitted (suppression applies to the triggering action, not to the recording of the suppression).
- What happens when multiple protocols fail simultaneously? All failures are recorded in the suppression entry; the action is suppressed once (not once per protocol).
- What happens when a session has no verification failures but the presence records are incomplete? The I.01 evaluator flags this as a protocol failure during verification.

## Requirements *(mandatory)*

### Functional Requirements

- **FR-001**: System MUST record a presence attestation for the session creator (role=CREATOR) when a session is created, using the authentication event as the attestation method
- **FR-002**: System MUST record a presence attestation for each anonymous participant (role=PARTICIPANT) when they join via a valid token, using the join event as the attestation method
- **FR-003**: System MUST record a presence attestation for the AI agent (role=AGENT) on first message processing within a session, using the message processing event as the attestation method
- **FR-004**: System MUST NOT create duplicate presence records for the same actor within a session (idempotent attestation)
- **FR-005**: System MUST finalize all presence records for a session when the session transitions to ENDED state
- **FR-006**: System MUST reject any attempt to create or modify presence records for a session that has been finalized
- **FR-007**: System MUST store presence records with: session ID, role, anonymous presence hash, attestation method, attested flag, finalization status, and timestamps
- **FR-008**: System MUST evaluate the I.01 (Presence Truth) protocol during session verification, checking that the session has 2+ independent attestation methods
- **FR-009**: System MUST evaluate the I.05 (Protocol Supremacy) protocol during session verification, checking that no admin action has overridden verification results
- **FR-010**: System MUST evaluate the I.08 (Signal Coherence) protocol during session verification, checking that no contradictory admin commands were executed
- **FR-011**: System MUST halt any action before state mutation when verification returns FAIL (suppression), except for session closure — which always completes with a FAIL witness emitted
- **FR-012**: System MUST record every suppression event in the integrity ledger as a dedicated `SUPPRESSION_EVENT` entry, including the action type, failed protocol(s), and suppression reason
- **FR-013**: System MUST validate admin commands against active protocols before allowing execution
- **FR-014**: System MUST detect and reject contradictory admin commands within the same request
- **FR-015**: System MUST NOT allow any authority level (including admin) to bypass suppression
- **FR-016**: System MUST store only anonymous metadata in presence records — never personal identity information, credentials, or session content

### Key Entities

- **Presence Record**: An attestation of an actor's participation in a session. Key attributes: session reference, actor role (CREATOR/PARTICIPANT/AGENT), anonymous presence hash, attestation method, boolean attested status, finalization status, timestamps (created, finalized).
- **Suppression Event**: A record of a blocked action due to protocol violation. Key attributes: session reference, action type that was blocked, protocol(s) that triggered suppression, reason for suppression, timestamp.
- **Protocol Evaluator (I.01, I.05, I.08)**: A verification rule that examines session data and returns PASS or FAIL. Each evaluator is independently testable and versioned. Added to the existing verification engine alongside I.02, I.03, I.04 from feature 006.

## Success Criteria *(mandatory)*

### Measurable Outcomes

- **SC-001**: 100% of created sessions have an admin presence attestation recorded within the same operation
- **SC-002**: 100% of user join events result in a participant presence attestation
- **SC-003**: 100% of AI first-message events result in an agent presence attestation
- **SC-004**: 100% of closed sessions have all presence records finalized; 0% of open sessions have finalized presence
- **SC-005**: 100% of verification FAILs result in action suppression — no unsuppressed failures permitted
- **SC-006**: 100% of suppression events are recorded in the integrity ledger with complete context (action type, protocol, reason)
- **SC-007**: 0% of admin override attempts succeed against protocol rules
- **SC-008**: 100% of contradictory admin command pairs are detected and rejected
- **SC-009**: Verification with I.01, I.05, I.08 evaluators added produces deterministic results (same inputs yield identical PASS/FAIL)
- **SC-010**: Zero personal identity data appears in any presence record — only anonymous hashes and metadata

## Clarifications

### Session 2026-02-14

- Q: If protocols FAIL during session end verification, does suppression prevent the session from closing? → A: No. Session closure always completes — a FAIL witness is emitted. Suppression blocks admin commands and pre-close actions, but never the close operation itself. This prevents orphaned open sessions.
- Q: Admin-only sessions have 1 attestation method — do they fail I.01, and is that acceptable? → A: Yes. Admin-only sessions fail I.01 and close with a FAIL witness. The protocol requires 2+ independent attestation methods; a single-method session is a factual FAIL, not a system error.
- Q: Should suppression events use a new dedicated event type in the ledger? → A: Yes. A new `SUPPRESSION_EVENT` enum value is added via a dedicated database migration, keeping suppression records distinct and queryable.

## Assumptions

- The existing authentication mechanism (admin auth events) provides sufficient signal to serve as the attestation method for admin presence. No new authentication flow is needed.
- The existing join token mechanism provides sufficient signal for participant attestation. Token validation = presence attestation.
- AI presence attestation is triggered by the WebSocket message handler on first AI-processed message, not by every message.
- Signal coherence validation applies within a single request scope — not across separate requests over time. The coherence window is a single HTTP request or WebSocket message batch.
- The existing `PresenceSummary` stub in `types.ts` (from feature 006) will be replaced with real presence data from the presence tracker.
- Suppression in this feature applies to session lifecycle actions and admin commands. Chat message suppression is out of scope.
