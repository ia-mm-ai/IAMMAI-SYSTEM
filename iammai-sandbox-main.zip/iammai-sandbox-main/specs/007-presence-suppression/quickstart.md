# Quickstart: 007-presence-suppression

## Prerequisites

- Feature 006 (verification-witness) merged and working
- PostgreSQL running with existing migrations applied (001-003)
- Node.js 20 LTS, pnpm

## Setup

```bash
# Switch to feature branch
git checkout 007-presence-suppression

# Install dependencies (if any new ones added)
pnpm install

# Run new migrations
psql -d iammai_sandbox < backend/migrations/004_presence_records.sql
psql -d iammai_sandbox < backend/migrations/005_add_suppression_event_type.sql
```

## Key Files (New)

```
backend/src/integrity/
  presence-tracker.ts          # attestPresence(), finalizePresence(), getPresenceSummary()
  suppression-engine.ts        # evaluateAction(), recordSuppression(), checkSignalCoherence()
  protocols/
    i01-presence-truth.ts      # 2+ attestation methods check
    i05-protocol-supremacy.ts  # No admin override check
    i08-signal-coherence.ts    # No contradictory commands check

backend/migrations/
  004_presence_records.sql     # presence_records table + triggers
  005_add_suppression_event_type.sql  # SUPPRESSION_EVENT enum value
```

## Key Files (Modified)

```
backend/src/integrity/
  types.ts                     # PresenceRecord, SuppressionRecord, extended EvaluationContext
  verification-engine.ts       # Extended context building (presence + admin actions)
  witness-emitter.ts           # Replace buildPresenceStub() with real presence
  protocols/protocol-base.ts   # Add I.01, I.05, I.08 to getDefaultProtocols()

backend/src/api/routes/
  sessions.ts                  # Admin presence on create; finalization + suppression on end
  tokens.ts                    # Participant presence on join

backend/src/api/websocket/
  handlers.ts                  # AI presence on first message
```

## Verification Flow (Updated)

```
Session End Request
    │
    ├─ 1. State transition ACTIVE → ENDED (atomic with ledger)
    ├─ 2. Finalize all presence records for session     ← NEW
    ├─ 3. Retrieve presence records + admin actions      ← NEW
    ├─ 4. Run verification (I.01-I.04, I.05, I.08)      ← EXTENDED
    ├─ 5. Emit witness with real presence data           ← UPDATED
    ├─ 6. Broadcast dissolution
    └─ 7. Dissolve kernel
```

## Testing

```bash
# Run all tests
npm test

# Run only 007 tests
npx jest --testPathPattern="presence|suppression|i01|i05|i08"
```

## Quick Verification

1. Create a session → check `presence_records` for CREATOR entry
2. Join with token → check `presence_records` for PARTICIPANT entry
3. Send a message → check `presence_records` for AGENT entry
4. End session → check all records are finalized; witness contains real presence
5. Attempt admin override (e.g., reopen closed session) → verify suppression recorded
