# Research: 007-presence-suppression

**Date**: 2026-02-14
**Feature**: Presence Tracking & Protocol Suppression

## R1: Presence Storage Strategy

**Decision**: Database-backed `presence_records` table with protective triggers (same pattern as `integrity_ledger`).

**Rationale**: Presence records must survive server restarts and be available for verification at session close. The existing in-memory presence hash (`derivePresenceHash()`) is ephemeral and only used for WebSocket identity. Integrity-layer presence attestation needs persistence to satisfy I.01 (Presence Truth) — verification happens after session end, so data must outlive the kernel.

**Alternatives considered**:
- In-memory Map (rejected: lost on restart; presence data needed post-dissolution)
- Embedded in ledger entries (rejected: presence is queried independently of ledger traversal; separate table allows finalization enforcement)

## R2: Presence Record Uniqueness

**Decision**: Composite uniqueness on `(session_id, role, presence_hash)`. Admin has a deterministic hash derived from `admin_id`. Each participant has a unique hash from their token seed. AI agent uses a fixed per-session hash (e.g., `'ai-agent'`).

**Rationale**: Multiple PARTICIPANTs per session each need their own record. Admin is always singular per session. AI agent is singular per session. The composite key prevents duplicate attestations while allowing multiple participants.

**Alternatives considered**:
- `(session_id, role)` only (rejected: can't support multiple participants)
- Surrogate PK only (rejected: doesn't enforce idempotency at DB level)

## R3: Suppression Engine Architecture

**Decision**: Middleware-style `evaluateAction(sessionId, actionType, context)` function called before state-mutating operations. Returns `{ allowed: boolean, suppression?: SuppressionRecord }`. On `allowed: false`, the caller must abort and record the suppression.

**Rationale**: Suppression must happen _before_ mutation, so it must be called at the action boundary (in route handlers or service layer). A pre-check pattern is simpler and more reliable than try-catch-rollback. Session closure is explicitly exempted — it always proceeds with FAIL witness on verification failure.

**Alternatives considered**:
- Database trigger-based suppression (rejected: triggers can't evaluate cross-table protocol logic)
- Post-action rollback (rejected: some mutations are irreversible, e.g., WebSocket broadcasts)

## R4: Admin Command Tracking for I.05 and I.08

**Decision**: Track admin actions via a lightweight in-memory `AdminActionLog` per session. Each admin route handler calls `logAdminAction(sessionId, actionType)` before executing. The I.05 evaluator checks this log for override attempts; I.08 checks for contradictions within the same request batch.

**Rationale**: The current admin API has limited commands (create, start, end sessions). Tracking is lightweight enough for in-memory storage during session lifetime. The log is consulted at verification time and included in the witness artifact.

**Alternatives considered**:
- Persist admin actions in separate DB table (rejected: over-engineering for PoC; admin actions are already recorded in ledger as state transitions)
- No tracking, just verify state (rejected: I.05 requires detecting _attempts_ to override, not just outcomes)

## R5: Signal Coherence Scope

**Decision**: Signal coherence (I.08) validates within a single HTTP request. If the request body contains or implies contradictory operations (e.g., a batch endpoint), both are rejected. For the current API (one action per request), coherence is satisfied by default — the evaluator checks the admin action log for conflicting entries within the session.

**Rationale**: Framework Decision 5 scopes coherence to admin commands only, not chat content. The current API is single-action-per-request, so contradiction detection is primarily a verification-time check on the full admin action history for the session.

**Alternatives considered**:
- Cross-request coherence window (rejected: spec clarification confirms single-request scope)
- Chat content coherence (rejected: Framework Decision 5 explicitly excludes)

## R6: Integration Points for Presence Attestation

**Decision**: Three integration points, each calling `presenceTracker.attestPresence()`:

1. **Session creation** (`sessions.ts` POST `/`): After successful session insert + ledger entry, attest admin presence with `role=CREATOR, method=AUTH_EVENT`
2. **Token join** (`tokens.ts` POST `/:id/join`): After successful join validation, attest participant with `role=PARTICIPANT, method=JOIN_TOKEN`
3. **First AI message** (`websocket/handlers.ts` `handleUserMessage`): Before/after AI response streaming, attest agent with `role=AGENT, method=MESSAGE_PROCESSING` (idempotent — only first call creates record)

**Rationale**: These are the natural trigger points for each actor type. Admin presence is guaranteed (session can't exist without admin). Participant presence is guaranteed on join. AI presence is optional (sessions without AI interaction are valid but may fail I.01 if they only have admin).

## R7: Presence Finalization Timing

**Decision**: Finalize presence in the session end flow, _after_ state transition to ENDED but _before_ verification. This ensures verification evaluates finalized presence.

**Flow**:
1. State transition to ENDED (atomic with ledger)
2. Finalize all presence records for session
3. Retrieve finalized presence for verification
4. Run verification (including I.01 with real presence data)
5. Emit witness (with real presence, not stub)

**Rationale**: Presence must be finalized before verification runs I.01, otherwise the evaluator can't determine if presence is complete. Finalization after state transition ensures no late attestations can arrive (session is already ENDED).

## R8: Replacing the Presence Stub in Witness Emitter

**Decision**: Replace `buildPresenceStub()` in `witness-emitter.ts` with a call to `presenceTracker.getPresenceSummary(sessionId)` that queries the `presence_records` table and returns a real `PresenceSummary`. The `emitWitness()` function signature changes to accept an optional `PresenceSummary` parameter.

**Rationale**: The stub was explicitly documented as a placeholder for 007. The witness artifact must contain real presence data for the system to be self-describing (Framework Decision 9).

## R9: Database Migration Strategy

**Decision**: Two migrations for 007:
1. `004_presence_records.sql` — Create `presence_records` table with columns, constraints, and protective triggers
2. `005_add_suppression_event_type.sql` — Add `SUPPRESSION_EVENT` to `integrity_event_type` enum

**Rationale**: Separate migrations keep changes atomic and rollback-safe. Matches pattern from 005/006 (002 for ledger, 003 for witness type).

## R10: EvaluationContext Extension

**Decision**: Extend `EvaluationContext` to include `presenceRecords` and `adminActions` alongside existing `session` and `ledgerEntries`. This allows I.01, I.05, and I.08 evaluators to access the data they need without separate queries.

**Rationale**: Protocol evaluators are pure functions — they should receive all data via context, not perform I/O. The verification engine collects all context before dispatching to evaluators.
