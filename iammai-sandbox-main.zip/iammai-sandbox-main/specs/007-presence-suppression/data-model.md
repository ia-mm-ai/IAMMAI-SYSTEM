# Data Model: 007-presence-suppression

**Date**: 2026-02-14
**Feature**: Presence Tracking & Protocol Suppression

## New Table: `presence_records`

```sql
CREATE TYPE presence_role AS ENUM ('CREATOR', 'PARTICIPANT', 'AGENT');
CREATE TYPE attestation_method AS ENUM ('AUTH_EVENT', 'JOIN_TOKEN', 'MESSAGE_PROCESSING');

CREATE TABLE presence_records (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    session_id UUID NOT NULL REFERENCES sessions(id) ON DELETE RESTRICT,
    role presence_role NOT NULL,
    presence_hash VARCHAR(64) NOT NULL,
    attestation_method attestation_method NOT NULL,
    attested BOOLEAN NOT NULL DEFAULT true,
    finalized BOOLEAN NOT NULL DEFAULT false,
    created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT NOW(),
    finalized_at TIMESTAMP WITH TIME ZONE,
    UNIQUE (session_id, role, presence_hash)
);

-- Index for fast lookup during verification
CREATE INDEX idx_presence_records_session_id ON presence_records(session_id);

-- Protective trigger: prevent modification of finalized records
CREATE OR REPLACE FUNCTION presence_records_prevent_finalized_update()
RETURNS TRIGGER AS $$
BEGIN
  IF OLD.finalized = true THEN
    RAISE EXCEPTION 'Cannot modify finalized presence record (id: %)', OLD.id;
  END IF;
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER trg_presence_records_no_finalized_update
  BEFORE UPDATE ON presence_records
  FOR EACH ROW
  EXECUTE FUNCTION presence_records_prevent_finalized_update();

-- Protective trigger: prevent deletion of presence records
CREATE OR REPLACE FUNCTION presence_records_prevent_delete()
RETURNS TRIGGER AS $$
BEGIN
  RAISE EXCEPTION 'Deletion of presence records is prohibited (id: %)', OLD.id;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER trg_presence_records_no_delete
  BEFORE DELETE ON presence_records
  FOR EACH ROW
  EXECUTE FUNCTION presence_records_prevent_delete();
```

### Column Descriptions

| Column | Type | Description |
|--------|------|-------------|
| `id` | UUID | Primary key |
| `session_id` | UUID | FK to sessions table |
| `role` | presence_role | CREATOR, PARTICIPANT, or AGENT |
| `presence_hash` | VARCHAR(64) | Anonymous hash identifying the actor (8-char hex for participants, derived from admin_id for admin, fixed 'ai-agent' for AI) |
| `attestation_method` | attestation_method | How presence was attested |
| `attested` | BOOLEAN | Always true on creation (attestation = creation) |
| `finalized` | BOOLEAN | Set to true when session ends; triggers protective lock |
| `created_at` | TIMESTAMPTZ | When attestation was recorded |
| `finalized_at` | TIMESTAMPTZ | When presence was finalized (null while session open) |

### Constraints

- **Uniqueness**: `(session_id, role, presence_hash)` — prevents duplicate attestations
- **Referential**: `session_id` FK to `sessions(id)` with `ON DELETE RESTRICT`
- **Protective**: Update trigger blocks modifications to finalized records
- **Protective**: Delete trigger blocks all deletions

## Enum Extension: `integrity_event_type`

```sql
ALTER TYPE integrity_event_type ADD VALUE 'SUPPRESSION_EVENT';
```

Adds `SUPPRESSION_EVENT` alongside existing values: `SESSION_CREATED`, `SESSION_ACTIVATED`, `SESSION_CLOSED`, `TRANSITION_REJECTED`, `VERIFICATION_WITNESS`.

## Extended TypeScript Types

### PresenceRecord

```typescript
export interface PresenceRecord {
  id: string;
  sessionId: string;
  role: PresenceRole;
  presenceHash: string;
  attestationMethod: AttestationMethod;
  attested: boolean;
  finalized: boolean;
  createdAt: Date;
  finalizedAt: Date | null;
}

export type PresenceRole = 'CREATOR' | 'PARTICIPANT' | 'AGENT';
export type AttestationMethod = 'AUTH_EVENT' | 'JOIN_TOKEN' | 'MESSAGE_PROCESSING';
```

### SuppressionRecord

```typescript
export interface SuppressionRecord {
  sessionId: string;
  actionType: string;
  failedProtocols: ProtocolResult[];
  reason: string;
  timestamp: Date;
}
```

### AdminAction (in-memory tracking)

```typescript
export interface AdminAction {
  sessionId: string;
  actionType: AdminActionType;
  timestamp: Date;
  outcome: 'EXECUTED' | 'SUPPRESSED';
}

export type AdminActionType = 'SESSION_CREATE' | 'SESSION_START' | 'SESSION_END';
```

### EvaluationContext (extended)

```typescript
export interface EvaluationContext {
  session: Session;
  ledgerEntries: LedgerEntry[];
  presenceRecords: PresenceRecord[];    // NEW in 007
  adminActions: AdminAction[];           // NEW in 007
}
```

### PresenceSummary (updated from stub)

```typescript
export interface PresenceSummary {
  admin: { attested: boolean; method: string; hash: string };
  participants: Array<{ attested: boolean; method: string; hash: string }>;
  agents: Array<{ attested: boolean; method: string; hash: string }>;
  total_attestation_methods: number;
  finalized: boolean;
}
```

## Entity Relationships

```
sessions 1──* presence_records    (one session has many presence records)
sessions 1──* integrity_ledger    (one session has many ledger entries, including SUPPRESSION_EVENT)
```

## State Transitions

### Presence Record Lifecycle

```
[Created]  ──attestPresence()──>  attested=true, finalized=false
                                         │
                          session ENDED   │
                                         ▼
[Finalized]  ──finalizePresence()──>  finalized=true, finalized_at=NOW()
                                         │
                                         ▼
                               [LOCKED by DB trigger]
```
