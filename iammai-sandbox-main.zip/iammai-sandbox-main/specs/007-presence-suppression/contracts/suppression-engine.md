# Contract: Suppression Engine

**Module**: `backend/src/integrity/suppression-engine.ts`

## Public API

### `evaluateAction(sessionId, actionType, context?) -> SuppressionResult`

Pre-check before a state-mutating action. Runs relevant protocol evaluators and returns whether the action is allowed.

```typescript
interface SuppressionResult {
  allowed: boolean;
  suppression?: SuppressionRecord;
}
```

- **Session closure is exempt**: `evaluateAction` is NOT called for session end. Session closure always proceeds; verification FAIL results in a FAIL witness, not suppression.
- **Admin commands**: Called before admin-initiated state changes (start session, modify parameters).
- Returns immediately if no protocols are violated (`{ allowed: true }`).

### `recordSuppression(client, sessionId, record) -> LedgerEntry`

Records a suppression event in the integrity ledger as a `SUPPRESSION_EVENT` entry.

- The `metadata_snapshot` of the ledger entry contains the `SuppressionRecord` with action type, failed protocols, and reason.
- Called by route handlers when `evaluateAction` returns `{ allowed: false }`.

### `checkSignalCoherence(sessionId, actionType) -> CoherenceResult`

Validates that the given admin action does not contradict previously recorded actions in the same session.

```typescript
interface CoherenceResult {
  coherent: boolean;
  conflicts?: Array<{ action: string; contradiction: string }>;
}
```

- Scoped to admin commands only (Framework Decision 5).
- Checks within the session's admin action history.

## Error Conditions

| Condition | Behavior |
|-----------|----------|
| Protocol verification FAIL | Returns `{ allowed: false, suppression: ... }` |
| Signal coherence violation | Returns `{ allowed: false, suppression: ... }` with coherence details |
| Session not found | Throws `NotFoundError` |
