# Contract: Presence Tracker

**Module**: `backend/src/integrity/presence-tracker.ts`

## Public API

### `attestPresence(client, sessionId, role, presenceHash, method) -> PresenceRecord`

Records a presence attestation for an actor in a session.

- **Idempotent**: If a record with the same `(sessionId, role, presenceHash)` exists, returns existing record without creating a duplicate.
- **Rejects** if session is ENDED (presence already finalized).
- **Accepts** `pg.PoolClient` for atomic operations within existing transactions.

### `finalizePresence(client, sessionId) -> PresenceRecord[]`

Marks all presence records for a session as finalized.

- Sets `finalized=true` and `finalized_at=NOW()` for all records where `session_id=sessionId` and `finalized=false`.
- Returns the finalized records.
- Called during session end flow, after state transition but before verification.

### `getPresenceRecords(sessionId) -> PresenceRecord[]`

Retrieves all presence records for a session (finalized or not).

- Used by verification engine to build `EvaluationContext`.
- Read-only, no transaction required.

### `getPresenceSummary(sessionId) -> PresenceSummary`

Builds a `PresenceSummary` from presence records for witness artifact emission.

- Replaces the hardcoded `buildPresenceStub()` in `witness-emitter.ts`.
- Groups records by role and counts distinct attestation methods.

## Error Conditions

| Condition | Behavior |
|-----------|----------|
| Session already ENDED | Throws `PresenceFinalizedException` |
| Duplicate attestation | Returns existing record (idempotent) |
| Invalid role/method | Throws `ValidationError` |
