# Contract: Protocol Evaluators (I.01, I.05, I.08)

**Module**: `backend/src/integrity/protocols/`

All evaluators implement the existing `ProtocolEvaluator` interface:

```typescript
interface ProtocolEvaluator {
  readonly id: string;
  readonly version: string;
  evaluate(context: EvaluationContext): ProtocolResult;
}
```

## I.01 — Presence Truth (`i01-presence-truth.ts`)

**ID**: `I.01` | **Version**: `1.0.0`

**Evaluates**: Does the session have 2+ independent attestation methods?

**Logic**:
1. Count distinct `attestation_method` values from `context.presenceRecords`
2. Verify all presence records are finalized
3. PASS if distinct methods >= 2; FAIL otherwise

**Details on FAIL**: `"Session has N attestation method(s), requires 2+"`

**Note**: Admin-only sessions (1 method) legitimately FAIL. This is expected behavior per clarification.

## I.05 — Protocol Supremacy (`i05-protocol-supremacy.ts`)

**ID**: `I.05` | **Version**: `1.0.0`

**Evaluates**: Has any admin action overridden verification results or bypassed protocol rules?

**Logic**:
1. Check `context.adminActions` for any action with `outcome=SUPPRESSED` that was later retried and executed
2. Check ledger for any state transition that contradicts a prior suppression
3. PASS if no override detected; FAIL if admin circumvented suppression

**Details on FAIL**: `"Admin override detected: [action] bypassed suppression at [timestamp]"`

## I.08 — Signal Coherence (`i08-signal-coherence.ts`)

**ID**: `I.08` | **Version**: `1.0.0`

**Evaluates**: Were any contradictory admin commands executed within the session?

**Logic**:
1. Build list of admin actions from `context.adminActions`
2. Check for contradiction pairs (e.g., START after END, conflicting state transitions)
3. PASS if no contradictions found; FAIL if conflicting commands detected

**Details on FAIL**: `"Contradictory commands detected: [action1] conflicts with [action2]"`

**Scope**: Admin commands only. Chat messages are never evaluated for coherence (Framework Decision 5).

## Registration

`getDefaultProtocols()` in `protocol-base.ts` updated to include all 6 evaluators:

```typescript
export function getDefaultProtocols(): ProtocolEvaluator[] {
  return [
    new I01PresenceTruth(),       // NEW in 007
    new I02EventBoundary(),       // From 006
    new I03Continuity(),          // From 006
    new I04LedgerIntegrity(),     // From 006
    new I05ProtocolSupremacy(),   // NEW in 007
    new I08SignalCoherence(),     // NEW in 007
  ];
}
```
