# Tasks: Presence Tracking & Protocol Suppression

**Input**: Design documents from `/specs/007-presence-suppression/`
**Prerequisites**: plan.md, spec.md, research.md, data-model.md, contracts/

**Tests**: Included per Constitution Principle II (Testing Standards) and established patterns from 005/006.

**Organization**: Tasks grouped by user story for independent implementation and testing.

## Format: `[ID] [P?] [Story] Description`

- **[P]**: Can run in parallel (different files, no dependencies)
- **[Story]**: Which user story this task belongs to (e.g., US1, US2, US3)
- Include exact file paths in descriptions

---

## Phase 1: Setup

**Purpose**: Database migrations and type definitions required by all subsequent phases.

- [x] T001 [P] Create presence_records table migration in `backend/migrations/004_presence_records.sql` — includes `presence_role` enum (CREATOR, PARTICIPANT, AGENT), `attestation_method` enum (AUTH_EVENT, JOIN_TOKEN, MESSAGE_PROCESSING), table with columns (id, session_id, role, presence_hash, attestation_method, attested, finalized, created_at, finalized_at), UNIQUE constraint on (session_id, role, presence_hash), session_id index, protective triggers preventing finalized record updates and all deletions (see data-model.md)
- [x] T002 [P] Create SUPPRESSION_EVENT enum migration in `backend/migrations/005_add_suppression_event_type.sql` — add `SUPPRESSION_EVENT` value to existing `integrity_event_type` enum (same pattern as 003_add_witness_event_type.sql)
- [x] T003 Extend integrity types in `backend/src/integrity/types.ts` — add `PresenceRecord` interface, `PresenceRole` type (`CREATOR` | `PARTICIPANT` | `AGENT`), `AttestationMethod` type (`AUTH_EVENT` | `JOIN_TOKEN` | `MESSAGE_PROCESSING`), `SuppressionRecord` interface (sessionId, actionType, failedProtocols, reason, timestamp), `AdminAction` interface (sessionId, actionType, timestamp, outcome), `AdminActionType` type. Update `PresenceSummary` from stub (admin/participants/agents with attested+method+hash, total_attestation_methods, finalized). Add `SUPPRESSION_EVENT` to `IntegrityEventType` union. Extend `EvaluationContext` with `presenceRecords: PresenceRecord[]` and `adminActions: AdminAction[]`

**Checkpoint**: Types and database schema ready for implementation.

---

## Phase 2: Foundational (Blocking Prerequisites)

**Purpose**: Core modules that all user stories depend on. MUST complete before any story implementation.

- [x] T004 Implement presence tracker core in `backend/src/integrity/presence-tracker.ts` — `attestPresence(client, sessionId, role, presenceHash, method)` that INSERTs into presence_records with ON CONFLICT DO NOTHING for idempotency, returns existing record on duplicate; `getPresenceRecords(sessionId)` that queries all records for a session; `getPresenceSummary(sessionId)` that builds `PresenceSummary` from records (groups by role, counts distinct attestation methods, checks finalization status). Accept `pg.PoolClient` for transactional use. Reject attestation if session is ENDED (check session state before insert)
- [x] T005 Implement suppression engine core in `backend/src/integrity/suppression-engine.ts` — `evaluateAction(sessionId, actionType)` that runs verification on current session state and returns `{ allowed: boolean, suppression?: SuppressionRecord }`; `recordSuppression(client, sessionId, record)` that appends a `SUPPRESSION_EVENT` ledger entry with suppression details in metadata_snapshot. Session closure is exempt from suppression (caller responsibility per clarification)
- [x] T006 Update verification engine context building in `backend/src/integrity/verification-engine.ts` — modify `verify()` to accept extended context or add optional `presenceRecords` and `adminActions` parameters; build `EvaluationContext` with all four fields (session, ledgerEntries, presenceRecords, adminActions) and pass to evaluators. Default presenceRecords and adminActions to empty arrays for backward compatibility with existing 006 tests
- [x] T007 [P] Unit tests for presence tracker in `backend/tests/unit/integrity/presence-tracker.test.ts` — test attestPresence creates record with correct fields; test idempotent attestation returns existing; test rejection when session ENDED; test getPresenceRecords returns all records for session; test getPresenceSummary groups by role and counts methods
- [x] T008 [P] Unit tests for suppression engine in `backend/tests/unit/integrity/suppression-engine.test.ts` — test evaluateAction returns allowed:true when verification passes; test evaluateAction returns allowed:false with suppression record when verification fails; test recordSuppression creates SUPPRESSION_EVENT ledger entry with correct metadata

**Checkpoint**: Foundation ready — presence tracking and suppression enforcement modules operational. User story implementation can begin.

---

## Phase 3: User Story 1 — Admin Presence on Session Creation (Priority: P1) MVP

**Goal**: Every session creation automatically records admin presence attestation.

**Independent Test**: Create a session as authenticated admin, query presence_records, verify CREATOR record exists with AUTH_EVENT method and attested=true.

### Implementation for User Story 1

- [x] T009 [US1] Integrate admin presence attestation into session creation route in `backend/src/api/routes/sessions.ts` — inside the existing `transaction()` block for POST `/`, after `observeTransition()` call, add `presenceTracker.attestPresence(client, session.id, 'CREATOR', derivePresenceHash(session.adminId), 'AUTH_EVENT')`. Use the transaction client for atomicity. Import presence-tracker and derivePresenceHash
- [x] T010 [US1] Unit test for admin presence integration in `backend/tests/unit/integrity/protocols/admin-presence-creation.test.ts` — test that session creation results in a CREATOR presence record; test that the presence hash is derived from admin_id; test that attested=true and finalized=false on creation

**Checkpoint**: Admin presence attested on every session creation. Independently verifiable.

---

## Phase 4: User Story 2 — User Presence on Token Join (Priority: P1)

**Goal**: Every anonymous user join via token records participant presence attestation.

**Independent Test**: Claim a token, join a session, query presence_records, verify PARTICIPANT record exists with JOIN_TOKEN method and unique presence hash.

### Implementation for User Story 2

- [x] T011 [US2] Integrate participant presence attestation into token join route in `backend/src/api/routes/tokens.ts` — in POST `/:id/join` handler, after successful token validation and presence hash derivation, call `presenceTracker.attestPresence(client, sessionId, 'PARTICIPANT', presenceHash, 'JOIN_TOKEN')`. Ensure idempotency (rejoining with same token doesn't create duplicate). Use existing presenceHash from `derivePresenceHash(seed)`
- [x] T012 [US2] Unit test for participant presence in `backend/tests/unit/integrity/protocols/participant-presence-join.test.ts` — test that join creates PARTICIPANT record; test multiple users get distinct presence hashes; test rejoin with same token is idempotent; test invalid/expired token creates no record

**Checkpoint**: Participant presence attested on every token join. Independently verifiable.

---

## Phase 5: User Story 3 — AI Presence on First Message (Priority: P1)

**Goal**: First AI message processing in a session records agent presence attestation.

**Independent Test**: Start a session, send a message triggering AI, query presence_records, verify AGENT record exists with MESSAGE_PROCESSING method.

### Implementation for User Story 3

- [x] T013 [US3] Integrate AI presence attestation into WebSocket message handler in `backend/src/api/websocket/handlers.ts` — in `handleUserMessage()`, before or after AI response streaming, call `presenceTracker.attestPresence(null, sessionId, 'AGENT', 'ai-agent', 'MESSAGE_PROCESSING')`. Use non-transactional call (no client needed since this is fire-and-forget attestation). Idempotent — subsequent messages skip due to ON CONFLICT DO NOTHING
- [x] T014 [US3] Unit test for AI presence in `backend/tests/unit/integrity/protocols/agent-presence-message.test.ts` — test first message creates AGENT record; test subsequent messages don't create duplicates; test no AGENT record if session closes without AI interaction

**Checkpoint**: AI presence attested on first message processing. All three actor types now tracked.

---

## Phase 6: User Story 4 — Presence Finalized on Session Close (Priority: P1)

**Goal**: All presence records finalized when session ends. Verification runs I.01 with real presence. Witness contains real presence data.

**Independent Test**: Create session, join with user, send message, end session. Verify all 3 presence records finalized. Verify witness artifact contains real presence (not stub). Attempt to add presence to closed session — rejected.

### Implementation for User Story 4

- [x] T015 [US4] Implement finalizePresence() in `backend/src/integrity/presence-tracker.ts` — `finalizePresence(client, sessionId)` UPDATEs all presence_records for session setting finalized=true, finalized_at=NOW() WHERE finalized=false. Returns array of finalized records. Uses pg.PoolClient for transactional use
- [x] T016 [US4] Integrate presence finalization into session end flow in `backend/src/api/routes/sessions.ts` — in POST `/:id/end`, after state transition to ENDED but before verification: (1) call `presenceTracker.finalizePresence(client, id)`, (2) retrieve finalized records via `presenceTracker.getPresenceRecords(id)`, (3) pass records to verify() as extended context, (4) get presence summary for witness emission
- [x] T017 [US4] Replace buildPresenceStub() in `backend/src/integrity/witness-emitter.ts` — remove `buildPresenceStub()` function; update `buildWitnessArtifact()` to accept a `PresenceSummary` parameter instead of calling the stub; update `emitWitness()` signature to accept `PresenceSummary`. Callers pass real presence from presenceTracker.getPresenceSummary()
- [x] T018 [US4] [P] Implement I.01 Presence Truth evaluator in `backend/src/integrity/protocols/i01-presence-truth.ts` — implements ProtocolEvaluator with id='I.01', version='1.0.0'. evaluate() counts distinct attestation_method values from context.presenceRecords; checks all records are finalized; returns PASS if distinct methods >= 2, FAIL otherwise. Detail on FAIL: "Session has N attestation method(s), requires 2+"
- [x] T019 [US4] Add I.01 to default protocols in `backend/src/integrity/protocols/protocol-base.ts` — import I01PresenceTruth, add to getDefaultProtocols() array before I02
- [x] T020 [US4] [P] Unit test for I.01 evaluator in `backend/tests/unit/integrity/protocols/i01-presence-truth.test.ts` — test PASS with 2+ methods (AUTH_EVENT + JOIN_TOKEN); test FAIL with 1 method (admin-only); test FAIL with 0 records; test FAIL if records not finalized; test deterministic (same input = same output)
- [x] T021 [US4] Unit test for presence finalization in `backend/tests/unit/integrity/presence-tracker-finalization.test.ts` — test finalizePresence sets finalized=true on all records; test finalized_at timestamp is set; test rejection of attestPresence after finalization; test rejection of UPDATE on finalized record (trigger)
- [x] T022 [US4] Integration test for presence lifecycle in `backend/tests/integration/integrity/presence-lifecycle.test.ts` — full flow: create session (admin presence) → join with token (participant presence) → send message (AI presence) → end session (finalize all) → verify witness contains real presence with 3 attestation methods → verify I.01 PASS. Also test admin-only session → I.01 FAIL → session still closes with FAIL witness

**Checkpoint**: Presence fully operational with finalization, real witness data, and I.01 verification. Core integrity guarantee established.

---

## Phase 7: User Story 5 — Suppression Enforcement (Priority: P1)

**Goal**: Verification FAIL triggers suppression that blocks state-mutating actions (except session closure) and records the event.

**Independent Test**: Trigger a protocol FAIL (e.g., tampered ledger entry), verify the action is blocked, verify SUPPRESSION_EVENT in ledger with action type and failed protocol details.

### Implementation for User Story 5

- [x] T023 [US5] Integrate suppression check into session start route in `backend/src/api/routes/sessions.ts` — in POST `/:id/start`, before state transition, call `suppressionEngine.evaluateAction(id, 'SESSION_START')`. If not allowed, record suppression via `suppressionEngine.recordSuppression()` and return 403 with suppression details. Do NOT apply suppression to session end (per clarification)
- [x] T024 [US5] Update session end flow for suppression recording in `backend/src/api/routes/sessions.ts` — session closure always proceeds, but if verification returns FAIL, set `suppression_triggered: true` in witness artifact and record a SUPPRESSION_EVENT entry noting the failed protocols. Update the emitWitness call to pass suppression status
- [x] T025 [US5] Update witness artifact suppression_triggered field in `backend/src/integrity/witness-emitter.ts` — `buildWitnessArtifact()` accepts a boolean `suppressionTriggered` parameter (default false); callers pass true when verification FAILs on session close
- [x] T026 [US5] Integration test for suppression enforcement in `backend/tests/integration/integrity/suppression-enforcement.test.ts` — test: action with FAIL verification → action blocked, SUPPRESSION_EVENT in ledger; test: session close with FAIL → session still closes, FAIL witness emitted with suppression_triggered=true; test: action with PASS → proceeds normally; test: suppression record contains action type, failed protocols, and reason

**Checkpoint**: Suppression engine fully enforced. Protocol violations block actions and are permanently recorded.

---

## Phase 8: User Story 6 — Admin Command Validation / Protocol Supremacy (Priority: P2)

**Goal**: Admin commands validated against protocols before execution. No admin can override verification results.

**Independent Test**: Attempt to reopen a closed session or bypass suppression as admin. Verify command is rejected and override attempt is recorded.

### Implementation for User Story 6

- [x] T027 [US6] Implement admin action tracking in `backend/src/api/routes/sessions.ts` — add in-memory `Map<string, AdminAction[]>` to track admin actions per session. Log each admin action (SESSION_CREATE, SESSION_START, SESSION_END) with timestamp and outcome. Clear session's actions on dissolution. Export `getAdminActions(sessionId)` for verification context
- [x] T028 [US6] Pass admin actions to verification context in `backend/src/api/routes/sessions.ts` — when building verification context in session end flow, retrieve admin actions via `getAdminActions(id)` and pass as `adminActions` to `verify()`. This allows I.05 evaluator to check for override attempts
- [x] T029 [US6] [P] Implement I.05 Protocol Supremacy evaluator in `backend/src/integrity/protocols/i05-protocol-supremacy.ts` — implements ProtocolEvaluator with id='I.05', version='1.0.0'. evaluate() checks context.adminActions for any action with outcome='SUPPRESSED' that was later retried and executed (outcome='EXECUTED' after a 'SUPPRESSED' for same actionType); also checks ledger for state transitions contradicting prior suppressions. PASS if no override detected; FAIL with details of which action bypassed suppression
- [x] T030 [US6] Add I.05 to default protocols in `backend/src/integrity/protocols/protocol-base.ts` — import I05ProtocolSupremacy, add to getDefaultProtocols() array after I04
- [x] T031 [US6] [P] Unit test for I.05 evaluator in `backend/tests/unit/integrity/protocols/i05-protocol-supremacy.test.ts` — test PASS with no admin override attempts; test PASS with suppressed action not retried; test FAIL when suppressed action was later executed; test deterministic results

**Checkpoint**: Protocol supremacy enforced. Admin cannot bypass integrity framework.

---

## Phase 9: User Story 7 — Signal Coherence (Priority: P2)

**Goal**: Contradictory admin commands within the same session detected and rejected.

**Independent Test**: Record contradictory admin actions in a session. Verify I.08 evaluator returns FAIL. Verify coherence violation is recorded.

### Implementation for User Story 7

- [x] T032 [US7] Implement checkSignalCoherence() in `backend/src/integrity/suppression-engine.ts` — `checkSignalCoherence(sessionId, actionType)` retrieves admin action history for session, checks for contradiction pairs (e.g., SESSION_START after SESSION_END within same session, which is already blocked by state machine, but captures attempted contradictions from the admin action log). Returns `{ coherent: boolean, conflicts?: Array<{ action, contradiction }> }`
- [x] T033 [US7] Integrate coherence check into suppression evaluation in `backend/src/integrity/suppression-engine.ts` — update `evaluateAction()` to call `checkSignalCoherence()` before protocol verification. If not coherent, return suppression result with coherence violation details
- [x] T034 [US7] [P] Implement I.08 Signal Coherence evaluator in `backend/src/integrity/protocols/i08-signal-coherence.ts` — implements ProtocolEvaluator with id='I.08', version='1.0.0'. evaluate() checks context.adminActions for contradiction pairs (conflicting action types that indicate ambiguous intent). Scoped to admin commands only (Framework Decision 5). PASS if no contradictions; FAIL with details of conflicting commands
- [x] T035 [US7] Add I.08 to default protocols in `backend/src/integrity/protocols/protocol-base.ts` — import I08SignalCoherence, add to getDefaultProtocols() array after I05
- [x] T036 [US7] [P] Unit test for I.08 evaluator in `backend/tests/unit/integrity/protocols/i08-signal-coherence.test.ts` — test PASS with no contradictions; test PASS with single admin action; test FAIL with contradictory action pair; test that chat messages are not evaluated; test deterministic results

**Checkpoint**: Signal coherence enforced. All three new protocol evaluators (I.01, I.05, I.08) operational.

---

## Phase 10: Polish & Cross-Cutting Concerns

**Purpose**: Final integration, validation, and cleanup across all stories.

- [x] T037 Integration test for full lifecycle with all protocols in `backend/tests/integration/integrity/presence-finalization.test.ts` — end-to-end: create (admin presence) → start (suppression check passes) → join (participant presence) → message (AI presence) → end → verify all 6 protocols (I.01-I.04 + I.05, I.08) → witness with real presence, suppression_triggered=false → all presence finalized. Also test failure scenarios: tampered ledger → I.04 FAIL witness; admin-only → I.01 FAIL witness
- [x] T038 [P] Privacy validation test in `backend/tests/integration/integrity/presence-privacy.test.ts` — verify no personal identity data in presence_records (no names, emails, IPs); verify presence_hash is 8-char hex; verify admin hash derived from admin_id not from credentials; verify witness artifact contains only anonymous metadata
- [x] T039 [P] Update existing 006 tests for backward compatibility in `backend/tests/unit/integrity/verification-engine.test.ts` and `backend/tests/unit/integrity/witness-emitter.test.ts` — ensure existing tests pass with new optional parameters (presenceRecords defaults to [], adminActions defaults to []); update witness-emitter tests to use new signature with PresenceSummary parameter
- [x] T040 Run quickstart.md validation steps — execute all 5 verification steps from quickstart.md manually: (1) create session → CREATOR in presence_records, (2) join with token → PARTICIPANT in presence_records, (3) send message → AGENT in presence_records, (4) end session → all finalized + real witness, (5) admin override attempt → suppression recorded

---

## Dependencies & Execution Order

### Phase Dependencies

- **Setup (Phase 1)**: No dependencies — can start immediately. T001 and T002 are parallel.
- **Foundational (Phase 2)**: Depends on Phase 1 (T003 types). T007 and T008 parallel with each other.
- **US1 (Phase 3)**: Depends on Phase 2 (T004 presence-tracker core)
- **US2 (Phase 4)**: Depends on Phase 2 (T004 presence-tracker core). Can run parallel with US1.
- **US3 (Phase 5)**: Depends on Phase 2 (T004 presence-tracker core). Can run parallel with US1, US2.
- **US4 (Phase 6)**: Depends on US1-US3 (needs presence records to exist for finalization and I.01 evaluation)
- **US5 (Phase 7)**: Depends on US4 (needs verification with I.01 to demonstrate FAIL triggering suppression)
- **US6 (Phase 8)**: Depends on US5 (suppression engine must be integrated before I.05 can detect override attempts)
- **US7 (Phase 9)**: Depends on US6 (admin action tracking must exist before coherence can be checked)
- **Polish (Phase 10)**: Depends on all user stories complete

### User Story Dependencies

```
Phase 1 (Setup) ──→ Phase 2 (Foundation)
                         │
                    ┌────┼────┐
                    ▼    ▼    ▼
                   US1  US2  US3   (parallel)
                    │    │    │
                    └────┼────┘
                         ▼
                        US4  (presence finalization + I.01)
                         │
                         ▼
                        US5  (suppression enforcement)
                         │
                         ▼
                        US6  (admin validation + I.05)
                         │
                         ▼
                        US7  (signal coherence + I.08)
                         │
                         ▼
                      Polish
```

### Within Each User Story

- Types/migrations before services
- Services before route integration
- Route integration before tests (for integration tests)
- Unit tests parallel with implementation where possible (different files)

### Parallel Opportunities

- T001 and T002 (different migration files)
- T007 and T008 (different test files)
- US1, US2, US3 (different route files: sessions.ts, tokens.ts, handlers.ts)
- T018 and T020 (I.01 evaluator + its test in different files)
- T029 and T031 (I.05 evaluator + its test in different files)
- T034 and T036 (I.08 evaluator + its test in different files)
- T037, T038, T039 (different test files in polish phase)

---

## Parallel Example: US1 + US2 + US3

```bash
# After Phase 2 completes, launch all three attestation integrations in parallel:
Task: "T009 [US1] Integrate admin presence in backend/src/api/routes/sessions.ts"
Task: "T011 [US2] Integrate participant presence in backend/src/api/routes/tokens.ts"
Task: "T013 [US3] Integrate AI presence in backend/src/api/websocket/handlers.ts"
```

## Parallel Example: Protocol Evaluators

```bash
# Within each story, evaluator + its test can be parallel:
Task: "T018 [US4] I.01 evaluator in backend/src/integrity/protocols/i01-presence-truth.ts"
Task: "T020 [US4] I.01 test in backend/tests/unit/integrity/protocols/i01-presence-truth.test.ts"
```

---

## Implementation Strategy

### MVP First (US1 Only — Admin Presence)

1. Complete Phase 1: Setup (migrations + types)
2. Complete Phase 2: Foundational (presence-tracker + suppression-engine core)
3. Complete Phase 3: US1 (admin presence on session create)
4. **STOP and VALIDATE**: Create a session, verify CREATOR record in presence_records
5. This alone delivers: presence tracking infrastructure + first attestation point

### Incremental Delivery

1. Setup + Foundation → Core modules ready
2. US1 + US2 + US3 (parallel) → All three actor types tracked
3. US4 → Finalization + I.01 + real witness data (major milestone)
4. US5 → Suppression enforcement (integrity guarantee established)
5. US6 + US7 → Protocol supremacy + signal coherence (governance complete)
6. Polish → Full validation and backward compatibility

---

## Notes

- [P] tasks = different files, no dependencies on incomplete tasks
- [Story] labels map tasks to spec user stories (US1-US7)
- Session closure is NEVER blocked by suppression (per clarification)
- Admin-only sessions legitimately FAIL I.01 (per clarification)
- SUPPRESSION_EVENT is a new dedicated ledger event type (per clarification)
- Existing 006 tests must remain passing (backward compatibility via default empty arrays)
- All presence records store only anonymous hashes — never PII (FR-016)
