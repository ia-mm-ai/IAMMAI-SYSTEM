# Data Model: 008-governance-protocols

**Date**: 2026-02-18

## Database Changes

### Enum Extension: integrity_event_type

```sql
-- Migration: 006_add_acedia_event_types.sql
-- Idempotent: uses IF NOT EXISTS pattern

DO $$
BEGIN
  IF NOT EXISTS (SELECT 1 FROM pg_enum WHERE enumlabel = 'ACEDIA_WARNING'
    AND enumtypid = (SELECT oid FROM pg_type WHERE typname = 'integrity_event_type'))
  THEN
    ALTER TYPE integrity_event_type ADD VALUE 'ACEDIA_WARNING';
  END IF;
END$$;

DO $$
BEGIN
  IF NOT EXISTS (SELECT 1 FROM pg_enum WHERE enumlabel = 'ACEDIA_DETECTION'
    AND enumtypid = (SELECT oid FROM pg_type WHERE typname = 'integrity_event_type'))
  THEN
    ALTER TYPE integrity_event_type ADD VALUE 'ACEDIA_DETECTION';
  END IF;
END$$;

DO $$
BEGIN
  IF NOT EXISTS (SELECT 1 FROM pg_enum WHERE enumlabel = 'ACEDIA_CANCELLED'
    AND enumtypid = (SELECT oid FROM pg_type WHERE typname = 'integrity_event_type'))
  THEN
    ALTER TYPE integrity_event_type ADD VALUE 'ACEDIA_CANCELLED';
  END IF;
END$$;

DO $$
BEGIN
  IF NOT EXISTS (SELECT 1 FROM pg_enum WHERE enumlabel = 'ACEDIA_FORCE_RELEASE'
    AND enumtypid = (SELECT oid FROM pg_type WHERE typname = 'integrity_event_type'))
  THEN
    ALTER TYPE integrity_event_type ADD VALUE 'ACEDIA_FORCE_RELEASE';
  END IF;
END$$;
```

No new tables are required. Acedia state and co-agency counters are tracked in-memory (same pattern as the admin action log in suppression-engine.ts). All governance events are recorded in the existing `integrity_ledger` table using the new event types.

## Extended TypeScript Types

### Acedia Types

```typescript
/**
 * Acedia monitoring thresholds (Framework Decision 6).
 * All values in milliseconds.
 */
export interface AcediaThresholds {
  createdIdleMs: number;    // Default: 15 * 60 * 1000 (15 min)
  activeIdleMs: number;     // Default: 30 * 60 * 1000 (30 min)
  countdownMs: number;      // Default: 10 * 60 * 1000 (10 min)
  checkIntervalMs: number;  // Default: 60 * 1000 (60 sec)
}

/**
 * Acedia lifecycle phases for a session.
 */
export type AcediaPhase = 'NORMAL' | 'WARNING' | 'DETECTION' | 'COUNTDOWN';

/**
 * In-memory acedia state for a monitored session.
 */
export interface AcediaState {
  sessionId: string;
  phase: AcediaPhase;
  lastActivityAt: Date;
  countdownStartedAt: Date | null;
}
```

### Co-Agency Types

```typescript
/**
 * Agent types for co-agency balance tracking.
 */
export type AgentType = 'HUMAN' | 'MACHINE';

/**
 * Irreversible action types tracked for co-agency balance (Framework Decision 7).
 */
export type IrreversibleActionType =
  | 'SESSION_END'               // Human
  | 'PRESENCE_FINALIZATION'     // Machine
  | 'VERIFICATION_EXECUTION';   // Machine

/**
 * A recorded irreversible action for co-agency tracking.
 */
export interface IrreversibleAction {
  sessionId: string;
  agentType: AgentType;
  actionType: IrreversibleActionType;
  timestamp: Date;
}

/**
 * In-memory co-agency balance state for a session.
 */
export interface CoAgencyState {
  sessionId: string;
  consecutiveCount: number;
  lastAgentType: AgentType | null;
  history: IrreversibleAction[];
}
```

### AI Metadata Types

```typescript
/**
 * In-memory AI participation metadata for witness emission.
 */
export interface AiSessionMetadata {
  model: string;
  totalTokens: number;
}
```

### Extended IntegrityEventType

```typescript
export type IntegrityEventType =
  | 'SESSION_CREATED'
  | 'SESSION_ACTIVATED'
  | 'SESSION_CLOSED'
  | 'TRANSITION_REJECTED'
  | 'VERIFICATION_WITNESS'
  | 'SUPPRESSION_EVENT'
  | 'ACEDIA_WARNING'           // NEW: 008
  | 'ACEDIA_DETECTION'         // NEW: 008
  | 'ACEDIA_CANCELLED'         // NEW: 008
  | 'ACEDIA_FORCE_RELEASE';    // NEW: 008
```

### Extended EvaluationContext

```typescript
export interface EvaluationContext {
  session: Session;
  ledgerEntries: LedgerEntry[];
  presenceRecords: PresenceRecord[];
  adminActions: AdminAction[];
  coAgencyActions: IrreversibleAction[];  // NEW: 008
}
```

### Extended WitnessArtifact Metadata

```typescript
// WitnessArtifact.metadata extended with optional AI fields
metadata: {
  participant_count: number;
  session_name: string;
  duration_ms: number;
  ai_model?: string;           // NEW: 008 — from environmental_constraints
  ai_total_tokens?: number;    // NEW: 008 — cumulative in-memory tracking
};
```

## Entity Relationships

```
┌─────────────────────┐     ┌─────────────────────────┐
│     sessions        │     │   integrity_ledger       │
│─────────────────────│     │─────────────────────────│
│ id (PK)             │◄────│ session_id (FK)          │
│ state               │     │ event_type (enum)        │
│ created_at          │     │ metadata_snapshot (JSONB) │
│ started_at          │     │ ...                      │
│ ended_at            │     │ NEW event types:         │
│ environmental_      │     │  ACEDIA_WARNING          │
│   constraints       │     │  ACEDIA_DETECTION        │
│   .ai_model ────────│─┐   │  ACEDIA_CANCELLED        │
│                     │ │   │  ACEDIA_FORCE_RELEASE    │
└─────────────────────┘ │   └─────────────────────────┘
                        │
┌───────────────────┐   │   ┌─────────────────────────┐
│ presence_records  │   │   │ IN-MEMORY STATE          │
│───────────────────│   │   │─────────────────────────│
│ session_id (FK)   │   │   │ AcediaState per session  │
│ role              │   │   │ CoAgencyState per session │
│ presence_hash ────│───│──►│ AiSessionMetadata        │
│ attestation_method│   │   │   .model ◄── ai_model    │
│ ...               │   │   │   .totalTokens           │
└───────────────────┘   │   └─────────────────────────┘
                        │
                    WitnessArtifact.metadata
                      .ai_model ◄──────────┘
                      .ai_total_tokens
```

## Acedia Lifecycle State Machine

```
                    ┌───────────────────────────┐
                    │                           │
                    ▼                           │
              ┌──────────┐   15min idle    ┌─────────┐
  Session     │  NORMAL  │ ──────────────► │ WARNING │  (CREATED state only)
  Created ──► │          │                 │         │
              └──────────┘                 └─────────┘
                    │                           │
                    │ 30min idle                │ Transition to
                    │ (ACTIVE state)            │ ACTIVE resets
                    ▼                           │
              ┌──────────────┐                  │
              │  DETECTION   │ ◄────────────────┘
              │ (countdown   │
              │  starts)     │
              └──────────────┘
                    │         │
         10min      │         │ Activity
         expires    │         │ received
                    ▼         ▼
            ┌────────────┐  ┌──────────────┐
            │ FORCE      │  │  CANCELLED   │
            │ RELEASE    │  │  (→ NORMAL)  │
            │ (→ ENDED)  │  └──────────────┘
            └────────────┘
```

## Co-Agency Counter Logic

```
Action performed by HUMAN:
  if lastAgentType == HUMAN:
    consecutiveCount++
  else:
    consecutiveCount = 1
    lastAgentType = HUMAN

Action performed by MACHINE:
  if lastAgentType == MACHINE:
    consecutiveCount++
  else:
    consecutiveCount = 1
    lastAgentType = MACHINE

Before action:
  if consecutiveCount >= 2 && agentType == lastAgentType:
    → SUPPRESS (co-agency limit reached)
  else:
    → ALLOW

Counter reset:
  any action by OTHER agent type resets consecutiveCount to 1

Exempt actions (not tracked):
  - Acedia force-release (system governance)
  - Suppression recording during close (observational)
  - Witness emission (documentation)
```
