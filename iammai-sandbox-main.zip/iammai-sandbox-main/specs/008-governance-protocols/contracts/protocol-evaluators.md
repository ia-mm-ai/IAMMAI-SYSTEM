# Contract: Protocol Evaluators (I.06, I.07, I.09, I.10)

**Module**: `backend/src/integrity/protocols/`

All evaluators implement the `ProtocolEvaluator` interface:

```typescript
interface ProtocolEvaluator {
  readonly id: string;
  readonly version: string;
  evaluate(context: EvaluationContext): ProtocolResult;
}
```

## I.06 Presence-Derived Identity

**File**: `i06-presence-identity.ts`
**Protocol ID**: `I.06`
**Version**: `1.0.0`

### Evaluation Logic

1. Check that admin presence exists in `context.presenceRecords` with role `CREATOR`
2. Verify presence uses anonymous hash (`presenceHash` is non-empty, not a credential)
3. Verify attestation method is `AUTH_EVENT` (presence-derived, not credential-asserted)
4. If all checks pass → `PASS`: "Admin identity derived from presence set via anonymous hash"

### FAIL Conditions

| Condition | Details String |
|-----------|---------------|
| No admin presence record found | "No admin presence record for session — identity cannot be derived from presence set" |
| Admin presence hash is empty | "Admin presence hash is empty — identity requires non-empty anonymous hash" |
| Admin not attested | "Admin presence not attested — identity requires verified presence" |

### Notes
- Identity is verified per-session: the evaluator confirms the CONSTRUCTION METHOD is correct (anonymous hash, not credentials)
- It does NOT query other sessions for the full identity set (that's a cross-session concern beyond session-close verification)

---

## I.07 Anti-Acedia

**File**: `i07-anti-acedia.ts`
**Protocol ID**: `I.07`
**Version**: `1.0.0`

### Evaluation Logic

1. Scan `context.ledgerEntries` for events of type `ACEDIA_FORCE_RELEASE`
2. If any ACEDIA_FORCE_RELEASE event found → `FAIL`
3. If no ACEDIA_FORCE_RELEASE event found → `PASS`

### FAIL Conditions

| Condition | Details String |
|-----------|---------------|
| Force-release event found | "Session was force-released due to unresolved acedia — anti-acedia protocol violated" |

### PASS Conditions

| Condition | Details String |
|-----------|---------------|
| No force-release events | "No acedia force-release detected — session resolved normally" |
| Acedia detected but cancelled | "No acedia force-release detected — session resolved normally" (cancelled events don't cause FAIL) |

### Notes
- Per spec clarification: evaluates final outcome only. ACEDIA_WARNING and ACEDIA_DETECTION events DO NOT cause FAIL if subsequently cancelled.
- Sessions with ACEDIA_CANCELLED followed by normal close → PASS
- Sessions with ACEDIA_FORCE_RELEASE → FAIL (always)

---

## I.09 Co-Agency Balance

**File**: `i09-co-agency-balance.ts`
**Protocol ID**: `I.09`
**Version**: `1.0.0`

### Evaluation Logic

1. Get co-agency action history from `context.coAgencyActions`
2. Scan history in chronological order, tracking consecutive runs by agent type
3. If any streak of > 2 consecutive irreversible actions by the same agent type → `FAIL`
4. If all streaks are ≤ 2 → `PASS`
5. If no actions recorded (empty history) → `PASS`

### FAIL Conditions

| Condition | Details String |
|-----------|---------------|
| Streak > 2 for same agent type | "Co-agency balance violated: {agentType} performed {count} consecutive irreversible actions (max 2)" |

### PASS Conditions

| Condition | Details String |
|-----------|---------------|
| All streaks ≤ 2 | "Co-agency balance maintained — no agent type exceeded 2 consecutive irreversible actions" |
| No actions | "Co-agency balance maintained — no irreversible actions recorded" |

### Notes
- Evaluates the HISTORY of actions, not the current counter state
- Acedia force-releases are excluded from the history (exempt actions not tracked)
- Suppression recording and witness emission are not tracked (observational/documentation)

---

## I.10 Future Interpretability

**File**: `i10-future-interpretability.ts`
**Protocol ID**: `I.10`
**Version**: `1.0.0`

### Evaluation Logic

1. Check if AI participated: any presence record with role `AGENT` in `context.presenceRecords`
2. If AI participated:
   a. Check `context.session.environmentalConstraints.ai_model` is defined and non-empty
   b. If ai_model missing → `FAIL`
   c. If ai_model present → `PASS`
3. If no AI participation → `PASS` (AI metadata not required)

### FAIL Conditions

| Condition | Details String |
|-----------|---------------|
| AI participated but no model declared | "AI agent participated but no ai_model declared in environmental constraints — witness cannot describe AI involvement" |

### PASS Conditions

| Condition | Details String |
|-----------|---------------|
| AI participated + model declared | "Future interpretability satisfied — AI model '{model}' declared for witness" |
| No AI participation | "Future interpretability satisfied — no AI participation; AI metadata not required" |

### Notes
- Token count is NOT checked by I.10 — it's tracked in-memory and may be 0 for sessions where the AI was attested but no responses were generated
- The evaluator checks PRECONDITIONS for a self-describing witness, not the actual artifact (built after verification)
- `environmental_constraints.ai_model` is set at session creation time

---

## Registration Order

Updated `getDefaultProtocols()` in `protocol-base.ts`:

```
Structural:   I.02, I.03, I.04
Operational:  I.01, I.05, I.08
Governance:   I.06, I.07, I.09, I.10  ← NEW
```

Per Framework Decision 8, governance protocols are evaluated after structural and operational protocols. Total: 10 protocols.
