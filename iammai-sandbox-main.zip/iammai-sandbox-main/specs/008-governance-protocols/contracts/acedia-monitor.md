# Contract: Acedia Monitor

**Module**: `backend/src/integrity/acedia-monitor.ts`

## Public API

### `startMonitor(thresholds?: Partial<AcediaThresholds>): void`

Start the background acedia monitoring process.

- **Parameters**: Optional partial thresholds (defaults from Framework Decision 6: 15min CREATED, 30min ACTIVE, 10min countdown, 60sec check interval)
- **Behavior**: Sets up periodic `setInterval` that calls `checkSessions()` every `checkIntervalMs`
- **Idempotent**: Calling when already running has no effect
- **Called from**: Server startup (`server.ts`)

### `stopMonitor(): void`

Stop the background acedia monitoring process.

- **Behavior**: Clears the interval timer and resets in-memory state
- **Idempotent**: Calling when not running has no effect
- **Called from**: Server shutdown, test teardown

### `checkSessions(): Promise<void>`

Check all CREATED and ACTIVE sessions for acedia conditions.

- **Behavior**:
  1. Query all sessions in CREATED or ACTIVE state
  2. For each session, determine current idle time from last activity
  3. Transition acedia phases as appropriate:
     - NORMAL → WARNING: CREATED idle > 15min (record ACEDIA_WARNING in ledger)
     - NORMAL → DETECTION: ACTIVE idle > 30min (record ACEDIA_DETECTION in ledger, start countdown)
     - COUNTDOWN expired: Force-release session (record ACEDIA_FORCE_RELEASE, transition to ENDED via existing session close flow)
  4. Skip sessions already being closed (state transition in progress)
- **Side effects**: Records ledger entries; may force-close sessions
- **Privacy**: Records only session ID, state, timestamps — never message content

### `recordActivity(sessionId: string): void`

Record participant or admin activity for a session, resetting acedia timers.

- **Parameters**: `sessionId` — the session where activity occurred
- **Behavior**:
  - Updates `lastActivityAt` in the session's acedia state
  - If in COUNTDOWN phase: cancel countdown, record ACEDIA_CANCELLED in ledger, transition to NORMAL
  - If in WARNING or DETECTION: transition to NORMAL
- **Called from**: WebSocket message handler, session route handlers (admin commands)
- **Privacy**: Does not capture what the activity was — only that it occurred

### `getAcediaState(sessionId: string): AcediaState | undefined`

Get the current acedia monitoring state for a session.

- **Parameters**: `sessionId`
- **Returns**: Current AcediaState or undefined if not tracked
- **Used by**: Tests; diagnostic endpoints

### `clearSession(sessionId: string): void`

Remove acedia tracking for a dissolved session.

- **Called from**: Session dissolution flow (after kernel dissolution)
- **Behavior**: Removes session from in-memory acedia tracking map

## Error Conditions

| Condition | Behavior |
|-----------|----------|
| Session not found during force-release | Log warning; skip session (may have been closed concurrently) |
| Session already ENDED during check | Skip (already closed) |
| Database error during ledger write | Log error; retry on next check interval |
| Monitor started twice | No-op (idempotent) |
