# Contract: Co-Agency Tracker

**Module**: `backend/src/integrity/co-agency-tracker.ts`

## Public API

### `canPerformAction(sessionId: string, agentType: AgentType): boolean`

Check if an irreversible action by the given agent type is allowed.

- **Parameters**: `sessionId`, `agentType` ('HUMAN' or 'MACHINE')
- **Returns**: `true` if agent has fewer than 2 consecutive irreversible actions; `false` if limit reached
- **Behavior**: Checks in-memory state only — does not modify state
- **Called from**: Session close flow (before each irreversible step), suppression engine (for co-agency enforcement)

### `trackAction(sessionId: string, agentType: AgentType, actionType: IrreversibleActionType): void`

Record an irreversible action for co-agency tracking.

- **Parameters**: `sessionId`, `agentType`, `actionType` (SESSION_END, PRESENCE_FINALIZATION, VERIFICATION_EXECUTION)
- **Behavior**:
  - If `agentType` matches `lastAgentType`: increment `consecutiveCount`
  - If `agentType` differs from `lastAgentType`: reset `consecutiveCount` to 1, update `lastAgentType`
  - Append action to history
- **Called from**: Session end handler, presence finalization, verification execution
- **Not called for**: Acedia force-release (exempt), suppression recording (observational), witness emission (documentation)

### `getHistory(sessionId: string): IrreversibleAction[]`

Get the full co-agency action history for a session.

- **Parameters**: `sessionId`
- **Returns**: Array of IrreversibleAction records in chronological order
- **Used by**: I.09 protocol evaluator via EvaluationContext.coAgencyActions

### `getState(sessionId: string): CoAgencyState | undefined`

Get the current co-agency counter state for a session.

- **Parameters**: `sessionId`
- **Returns**: Current CoAgencyState or undefined if not tracked

### `clearSession(sessionId: string): void`

Remove co-agency tracking for a dissolved session.

- **Called from**: Session dissolution flow (after kernel dissolution)
- **Behavior**: Removes session from in-memory co-agency tracking map

## Irreversible Action Classification

| Action | Agent Type | Tracked | Notes |
|--------|------------|---------|-------|
| Session termination (SESSION_END) | HUMAN | Yes | Admin ends session |
| Presence finalization | MACHINE | Yes | Machine finalizes presence records |
| Verification execution | MACHINE | Yes | Machine runs protocol verification |
| Suppression recording (close) | MACHINE | No | Observational record, not enforcement |
| Witness emission | MACHINE | No | Documentation, not state-changing |
| Acedia force-release | SYSTEM | No | Governance action, explicitly exempt |
| Session creation | HUMAN | No | Non-irreversible (can be ended) |
| Session start | HUMAN | No | Non-irreversible (can be ended) |
| Message sending | Either | No | Ephemeral, non-irreversible |

## Error Conditions

| Condition | Behavior |
|-----------|----------|
| canPerformAction for unknown session | Returns `true` (no history = no violation) |
| trackAction for unknown session | Creates new CoAgencyState automatically |
| clearSession for unknown session | No-op |
