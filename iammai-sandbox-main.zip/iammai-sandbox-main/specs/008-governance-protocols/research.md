# Research: 008-governance-protocols

**Date**: 2026-02-18

## R1: Acedia Monitoring Approach

**Decision**: Timer-based polling with `setInterval`, checking all CREATED and ACTIVE sessions against thresholds every 60 seconds.

**Rationale**: The acedia thresholds (15min, 30min, 10min) do not require sub-second precision. A 60-second polling interval detects stalls within ±1 minute of the threshold, which is acceptable for a PoC. The `setInterval` approach is the simplest implementation that doesn't require external dependencies (no cron, no message queue). The monitor queries sessions by state (indexed column), making each check O(n) where n = open sessions.

**Alternatives considered**:
- Event-driven with per-session timers (`setTimeout`): More precise but creates many timers; complex timer management; memory leak risk if sessions aren't cleaned up. Rejected for complexity.
- Database-level scheduled jobs (pg_cron): Would couple acedia logic to database; harder to test; not available in all PostgreSQL deployments. Rejected.
- Hybrid (event-driven + periodic sweep): Best of both worlds but over-engineered for PoC scale. Rejected.

## R2: Co-Agency Tracking Storage

**Decision**: In-memory `Map<sessionId, CoAgencyState>` following the same pattern as the existing admin action log in suppression-engine.ts.

**Rationale**: The admin action log (suppression-engine.ts line 37) already proves this pattern works. Co-agency counters are per-session, lightweight, and don't need to survive server restarts (the counter resets when the session is recreated). On restart, all open sessions would naturally have a clean co-agency slate since no actions have occurred since startup. Data is cleared on session dissolution, preventing memory leaks.

**Alternatives considered**:
- Database table: Adds write latency to every co-agency check; over-engineered for a simple counter; requires migration. Rejected.
- Extend admin action log: Would conflate admin tracking (for I.05/I.08) with co-agency tracking (for I.09); different data shapes. Rejected for coupling.
- Redis/external store: Not in the tech stack; unnecessary for PoC. Rejected.

## R3: EvaluationContext Extension Strategy

**Decision**: Add optional `coAgencyActions` field to `EvaluationContext` and corresponding optional parameter to `verify()`. I.07 (anti-acedia) derives its data from `ledgerEntries` (checks for ACEDIA_FORCE_RELEASE events). I.06 and I.10 use existing `presenceRecords` and session fields.

**Rationale**: This follows the exact pattern used in 007 when `presenceRecords` and `adminActions` were added. Adding as optional with defaults preserves backward compatibility. I.07 doesn't need a dedicated context field because acedia events are already in the ledger — the evaluator scans `ledgerEntries` for event type `ACEDIA_FORCE_RELEASE`. I.09 needs co-agency action history which isn't in the ledger, hence the new context field.

**Alternatives considered**:
- Derive everything from ledger entries: Would require I.09 to parse ledger metadata payloads to reconstruct co-agency history; fragile and slow. Rejected.
- Add all governance data as required fields: Would break existing callers. Rejected.
- Create a separate GovernanceContext: Over-engineers the interface; all evaluators already share EvaluationContext. Rejected.

## R4: Acedia Event Types for Ledger

**Decision**: Four new `IntegrityEventType` values: `ACEDIA_WARNING`, `ACEDIA_DETECTION`, `ACEDIA_CANCELLED`, `ACEDIA_FORCE_RELEASE`. Each recorded in the integrity ledger with a metadata snapshot containing acedia-specific details.

**Rationale**: Each acedia lifecycle phase needs a distinct event type for I.07 evaluation and audit trail. ACEDIA_WARNING (15-min CREATED idle), ACEDIA_DETECTION (30-min ACTIVE idle, starts countdown), ACEDIA_CANCELLED (activity resumed during countdown), ACEDIA_FORCE_RELEASE (countdown expired, session force-closed). The I.07 evaluator only needs to check for ACEDIA_FORCE_RELEASE to determine PASS/FAIL (per clarification: final-outcome only).

**Alternatives considered**:
- Single ACEDIA_EVENT type with subtype in metadata: Harder to query; loses the ability to filter by event type in the ledger. Rejected.
- Only record ACEDIA_FORCE_RELEASE (skip warning/detection/cancelled): Would lose the audit trail; harder to debug acedia behavior. Rejected.

## R5: WitnessArtifact Extension for AI Metadata

**Decision**: Extend the `WitnessArtifact.metadata` object with optional `ai_model?: string` and `ai_total_tokens?: number` fields. The AI model name comes from `session.environmentalConstraints.ai_model` (already captured at session creation). Token count is tracked cumulatively in-memory per session by the WebSocket handler.

**Rationale**: `environmental_constraints.ai_model` is already declared at session creation, so no new data capture needed for model name. Token count is tracked per AI response in the WebSocket handler and accumulated to a session-level total. The witness emitter reads this at emission time. Both fields are optional because sessions without AI participation omit them (per spec: I.10 PASS with note that no AI was involved).

**Alternatives considered**:
- Add ai_model and ai_tokens columns to sessions table: Unnecessary database write per AI response; witness only needs the data at emission. Rejected.
- Track per-interaction token breakdown: Risks revealing conversation flow patterns, approaching privacy boundary; spec clarification confirmed single cumulative total. Rejected.
- Derive token count from ledger entries: Token usage isn't recorded in ledger (privacy boundary); in-memory tracking is sufficient. Rejected.

## R6: Co-Agency Counter Interaction with Session Close Flow

**Decision**: The session close flow counts as: 1 human irreversible action (SESSION_END) followed by machine close processing. Machine close processing (presence finalization + verification execution) counts as at most 2 consecutive machine actions. Suppression recording during close is an observational record (not enforcement) and witness emission is documentation — neither counts toward the co-agency counter. Acedia force-release is explicitly exempt (per spec clarification).

**Rationale**: The session close flow is a defined protocol sequence triggered by a human action, not autonomous machine decision-making. The close flow naturally stays within co-agency limits: 1 human action → 2 machine actions (finalize + verify). Suppression recording during close captures the observation that verification failed — it doesn't block or enforce anything (the session is already ended). Witness emission is pure documentation. Distinguishing enforcement from observation prevents the close flow from blocking itself.

**Alternatives considered**:
- Count all close-flow steps as co-agency actions: Would cause the close flow to self-block when suppression recording follows verification (3 consecutive machine actions). Rejected — creates architectural deadlock.
- Treat entire close flow as a single unit: Simpler but loses granularity for I.09 evaluation; makes the counter meaningless during close. Rejected for lack of precision.
- Exempt all close-flow machine actions: Would make I.09 trivially PASS for all sessions. Rejected.

## R7: I.06 Identity Set Verification Strategy

**Decision**: I.06 evaluates at session close by checking: (1) admin presence is attested via presence records using anonymous hash (not credentials), (2) identity is represented as a presence set (the set of sessions where this admin hash appears), (3) no credential-based identity assertions exist in the session's data.

**Rationale**: The identity formula `identity(admin) = { session | presence(admin, session) = true }` is a set construction per Framework Decision 4. I.06 verifies this by confirming that admin presence uses `presenceHash` (anonymous, derived from `admin_id` via one-way hash) and `attestationMethod: 'AUTH_EVENT'` — not by name or email. The evaluator checks the current session's presence records; it doesn't need to query other sessions since it verifies the construction METHOD, not the complete set.

**Alternatives considered**:
- Query all sessions for the admin's presence hash: Would require cross-session queries during verification; expensive; unnecessary for verifying construction method. Rejected.
- Check admin credentials directly: Would violate the privacy boundary. Rejected.
- Skip I.06 for sessions without admin presence: Admin presence is mandatory (attested at creation), so this case shouldn't occur. Rejected.

## R8: I.10 Self-Describing Witness Verification Criteria

**Decision**: I.10 evaluates by checking: (1) if AI participated (AGENT presence records exist), the session has `environmental_constraints.ai_model` declared, (2) all required witness fields are structurally present in the witness format configuration, (3) protocol versions are recorded. The evaluator does not inspect the actual witness artifact (built after verification) — it checks preconditions for a self-describing witness.

**Rationale**: The witness artifact is constructed AFTER verification runs (by witness-emitter.ts), so I.10 cannot inspect the final artifact. Instead, it verifies that the system has the necessary data to produce a self-describing witness. If AI participated but no model name is available, the witness would be incomplete → FAIL. This is a precondition check, not a post-hoc inspection.

**Alternatives considered**:
- Inspect the actual witness artifact: Impossible — witness is built after verification completes. Rejected.
- Always PASS (trust witness-emitter implementation): Would make the protocol meaningless; no verification value. Rejected.
- Check witness template/schema: Over-engineered; the template is defined in code and doesn't change per session. Rejected.

## R9: Acedia Monitor Startup Recovery

**Decision**: On server startup, the acedia monitor queries all CREATED and ACTIVE sessions and evaluates their last activity time from session timestamps (`created_at`, `started_at`) and the most recent ledger entry timestamp. Sessions already exceeding thresholds are immediately processed (warning/detection/force-release as appropriate).

**Rationale**: In-memory acedia state is lost on restart. Rather than persisting acedia state (adding database complexity), we reconstruct it from existing timestamps. Session `created_at` and the latest ledger entry per session provide sufficient information to determine current idle duration. This is consistent with the design principle that acedia state is derived, not stored.

**Alternatives considered**:
- Persist acedia countdown state in database: Adds migration, write on every countdown tick, read on every check. Over-engineered for PoC. Rejected.
- Ignore pre-restart acedia state: Sessions could linger indefinitely after restart. Rejected.

## R10: AI Token Tracking Mechanism

**Decision**: In-memory `Map<sessionId, AiMetadata>` in the WebSocket handler module, updated after each AI response with the model name and token usage. The `AiMetadata` type holds `model: string` and `totalTokens: number` (cumulative). Cleared on session dissolution. Read by witness-emitter at emission time.

**Rationale**: The AI service already returns token usage information per response. We accumulate this to a session-level total. In-memory tracking is sufficient because: (a) the data is only needed at witness emission time, (b) it's captured in the witness artifact before dissolution, (c) on server restart, sessions that haven't ended yet have no AI metadata — which is acceptable (I.10 checks `environmental_constraints.ai_model` availability, not token count).

**Alternatives considered**:
- Track in the session model (database): Adds a write per AI response; unnecessary persistence. Rejected.
- Track in the integrity ledger: Would require a new event type per AI response; too noisy. Rejected.
- Track in the acedia monitor (piggyback on activity tracking): Wrong responsibility; acedia is about idleness, not AI usage. Rejected.
