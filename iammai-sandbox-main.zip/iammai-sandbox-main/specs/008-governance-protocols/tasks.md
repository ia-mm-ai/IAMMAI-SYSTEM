# Tasks: Governance Protocols

**Input**: Design documents from `/specs/008-governance-protocols/`
**Prerequisites**: plan.md, spec.md, research.md, data-model.md, contracts/

**Tests**: Unit tests for all new modules; integration tests for acedia lifecycle and co-agency enforcement (per constitution check in plan.md).

**Organization**: Tasks are grouped by user story. US3 (Protocol Verification at Session Close) is placed after US4 and US5 because it integrates all four governance protocols.

## Format: `[ID] [P?] [Story] Description`

- **[P]**: Can run in parallel (different files, no dependencies)
- **[Story]**: Which user story this task belongs to (e.g., US1, US2, US3)
- Include exact file paths in descriptions

## Path Conventions

- **Web app (backend)**: `backend/src/`, `backend/tests/`, `backend/migrations/`

---

## Phase 1: Setup

**Purpose**: Migration and shared type definitions needed by all user stories

- [X] T001 Create migration for acedia event types in backend/migrations/006_add_acedia_event_types.sql — add ACEDIA_WARNING, ACEDIA_DETECTION, ACEDIA_CANCELLED, ACEDIA_FORCE_RELEASE values to integrity_event_type enum using idempotent IF NOT EXISTS pattern per data-model.md
- [X] T002 Add governance types to backend/src/integrity/types.ts — add AcediaThresholds, AcediaPhase, AcediaState, AgentType, IrreversibleActionType, IrreversibleAction, CoAgencyState, AiSessionMetadata interfaces/types; extend IntegrityEventType with 4 acedia values; add optional coAgencyActions field to EvaluationContext; extend WitnessArtifact.metadata with optional ai_model and ai_total_tokens fields per data-model.md

**Checkpoint**: All shared types and database schema are in place — user story implementation can begin

---

## Phase 2: User Story 1 — Stalled Session Detection and Resolution (Priority: P1) 🎯 MVP

**Goal**: Detect idle sessions (acedia) and force-release them after configurable thresholds. Record all acedia lifecycle events in the integrity ledger.

**Independent Test**: Create a session, simulate idle time exceeding each threshold (15min CREATED, 30min ACTIVE, 10min countdown), and verify ledger entries + forced release.

### Implementation for User Story 1

- [X] T003 [US1] Implement acedia monitor module in backend/src/integrity/acedia-monitor.ts — exports startMonitor(thresholds?), stopMonitor(), checkSessions(), recordActivity(sessionId), getAcediaState(sessionId), clearSession(sessionId); uses in-memory Map<sessionId, AcediaState> for tracking; setInterval-based polling every 60s (configurable); checkSessions queries CREATED/ACTIVE sessions from DB and transitions acedia phases (NORMAL→WARNING→DETECTION→COUNTDOWN→FORCE_RELEASE); recordActivity resets phase to NORMAL and records ACEDIA_CANCELLED if in COUNTDOWN; force-release calls existing session close flow; all events recorded in ledger via appendEntry(); skip sessions already being closed; per contracts/acedia-monitor.md
- [X] T004 [P] [US1] Implement I.07 anti-acedia protocol evaluator in backend/src/integrity/protocols/i07-anti-acedia.ts — id='I.07', version='1.0.0'; scan context.ledgerEntries for ACEDIA_FORCE_RELEASE events; FAIL if any found ("Session was force-released due to unresolved acedia — anti-acedia protocol violated"); PASS if none found ("No acedia force-release detected — session resolved normally"); transient ACEDIA_WARNING/DETECTION/CANCELLED events do NOT cause FAIL; per contracts/protocol-evaluators.md
- [X] T005 [P] [US1] Unit tests for acedia monitor in backend/tests/unit/integrity/acedia-monitor.test.ts — test startMonitor/stopMonitor idempotency; test checkSessions transitions (NORMAL→WARNING for 15min CREATED idle, NORMAL→DETECTION for 30min ACTIVE idle, COUNTDOWN→FORCE_RELEASE for 10min expired); test recordActivity resets phase and records ACEDIA_CANCELLED; test getAcediaState/clearSession; test skip already-closed sessions; mock DB queries and ledger appendEntry
- [X] T006 [P] [US1] Unit tests for I.07 in backend/tests/unit/integrity/protocols/i07-anti-acedia.test.ts — test PASS with no acedia events; test PASS with ACEDIA_WARNING + ACEDIA_CANCELLED (transient); test FAIL with ACEDIA_FORCE_RELEASE; test PASS with empty ledger; test FAIL detail message matches contract
- [X] T007 [US1] Integrate acedia monitor lifecycle in backend/src/server.ts — call startMonitor() on server startup; call stopMonitor() on server shutdown/SIGTERM; import from acedia-monitor.ts
- [X] T008 [US1] Record participant activity for acedia in backend/src/api/websocket/handlers.ts — call recordActivity(sessionId) when any participant sends a message; import from acedia-monitor.ts
- [X] T009 [US1] Record admin command activity for acedia in backend/src/api/routes/sessions.ts — call recordActivity(sessionId) when admin commands are processed (session start, session end); import from acedia-monitor.ts

**Checkpoint**: Acedia monitoring is fully operational — stalled sessions are detected, warned, and force-released with full ledger audit trail

---

## Phase 3: User Story 2 — Co-Agency Balance Enforcement (Priority: P1)

**Goal**: Enforce balanced participation by preventing any agent type from executing more than 2 consecutive irreversible actions without involvement from the other type.

**Independent Test**: Simulate a sequence of irreversible actions by one agent type and confirm the third consecutive action is suppressed.

### Implementation for User Story 2

- [X] T010 [US2] Implement co-agency tracker module in backend/src/integrity/co-agency-tracker.ts — exports canPerformAction(sessionId, agentType), trackAction(sessionId, agentType, actionType), getHistory(sessionId), getState(sessionId), clearSession(sessionId); uses in-memory Map<sessionId, CoAgencyState>; canPerformAction returns false if consecutiveCount >= 2 and agentType matches lastAgentType; trackAction increments or resets counter and appends to history; exempt actions (acedia force-release, suppression recording, witness emission) are never tracked; per contracts/co-agency-tracker.md
- [X] T011 [P] [US2] Implement I.09 co-agency balance protocol evaluator in backend/src/integrity/protocols/i09-co-agency-balance.ts — id='I.09', version='1.0.0'; get history from context.coAgencyActions; scan chronologically for consecutive streaks by same agent type; FAIL if any streak > 2 ("Co-agency balance violated: {agentType} performed {count} consecutive irreversible actions (max 2)"); PASS if all streaks ≤ 2 or empty history; per contracts/protocol-evaluators.md
- [X] T012 [P] [US2] Unit tests for co-agency tracker in backend/tests/unit/integrity/co-agency-tracker.test.ts — test canPerformAction allows first 2 actions by same type; test canPerformAction blocks 3rd consecutive; test trackAction resets counter on agent type switch; test non-irreversible actions not tracked; test canPerformAction returns true for unknown session; test clearSession removes state; test getHistory returns chronological order
- [X] T013 [P] [US2] Unit tests for I.09 in backend/tests/unit/integrity/protocols/i09-co-agency-balance.test.ts — test PASS with balanced alternating actions; test PASS with empty history; test FAIL with 3+ consecutive same-type actions; test PASS with exactly 2 consecutive (limit not exceeded); test detail message includes agent type and count
- [X] T014 [US2] Integrate co-agency tracking in session close flow in backend/src/api/routes/sessions.ts — before session end: call canPerformAction for HUMAN/SESSION_END; after state transition: trackAction HUMAN/SESSION_END; after presence finalization: trackAction MACHINE/PRESENCE_FINALIZATION; after verification: trackAction MACHINE/VERIFICATION_EXECUTION; suppression recording and witness emission are NOT tracked; per quickstart.md verification flow

**Checkpoint**: Co-agency balance is enforced — no agent type can dominate irreversible actions

---

## Phase 4: User Story 4 — Admin Identity as Presence Set (Priority: P2)

**Goal**: Verify that admin identity is derived from presence sets (anonymous hash) rather than credentials or personal identifiers.

**Independent Test**: Create sessions with admin presence and verify I.06 evaluates the identity construction method correctly at session close.

### Implementation for User Story 4

- [X] T015 [P] [US4] Implement I.06 presence-identity protocol evaluator in backend/src/integrity/protocols/i06-presence-identity.ts — id='I.06', version='1.0.0'; check context.presenceRecords for CREATOR role record; verify presenceHash is non-empty (anonymous hash, not credential); verify attestationMethod is AUTH_EVENT; PASS if all checks pass ("Admin identity derived from presence set via anonymous hash"); FAIL if no admin presence, empty hash, or not attested; per contracts/protocol-evaluators.md
- [X] T016 [P] [US4] Unit tests for I.06 in backend/tests/unit/integrity/protocols/i06-presence-identity.test.ts — test PASS with valid admin presence (CREATOR role, non-empty hash, AUTH_EVENT attestation, attested=true); test FAIL with no admin presence record; test FAIL with empty presenceHash; test FAIL with admin not attested; test detail messages match contract strings

**Checkpoint**: I.06 verifies that identity construction follows presence-derived methodology

---

## Phase 5: User Story 5 — AI Reasoning Metadata in Witnesses (Priority: P2)

**Goal**: Track AI participation metadata (model name, cumulative token count) and include it in witness artifacts for future interpretability.

**Independent Test**: End a session with AI participation and verify witness artifact includes ai_model and ai_total_tokens in metadata.

### Implementation for User Story 5

- [X] T017 [US5] Implement AI token tracking in backend/src/api/websocket/handlers.ts — add in-memory Map<sessionId, AiSessionMetadata> tracking AI model name and cumulative token count; update after each AI response with token usage from AI service response; export getAiMetadata(sessionId) and clearAiMetadata(sessionId) for witness emitter and dissolution; AI model from session.environmentalConstraints.ai_model
- [X] T018 [P] [US5] Implement I.10 future-interpretability protocol evaluator in backend/src/integrity/protocols/i10-future-interpretability.ts — id='I.10', version='1.0.0'; check if AI participated (any presenceRecord with role AGENT); if AI participated: verify context.session.environmentalConstraints.ai_model is defined and non-empty; FAIL if ai_model missing ("AI agent participated but no ai_model declared in environmental constraints — witness cannot describe AI involvement"); PASS if present ("Future interpretability satisfied — AI model '{model}' declared for witness"); PASS if no AI participation ("Future interpretability satisfied — no AI participation; AI metadata not required"); per contracts/protocol-evaluators.md
- [X] T019 [P] [US5] Unit tests for I.10 in backend/tests/unit/integrity/protocols/i10-future-interpretability.test.ts — test PASS with AI participation and ai_model declared; test FAIL with AI participation but no ai_model; test PASS with no AI participation (no AGENT records); test detail messages include model name when present
- [X] T020 [US5] Extend witness emitter to include AI metadata in backend/src/integrity/witness-emitter.ts — modify buildWitnessArtifact to accept optional AiSessionMetadata parameter; when provided, add ai_model and ai_total_tokens to WitnessArtifact.metadata; when not provided (no AI), omit AI fields; update emitWitness to pass AI metadata through

**Checkpoint**: AI participation metadata flows from WebSocket handler → witness emitter → witness artifact

---

## Phase 6: User Story 3 — Governance Protocol Verification at Session Close (Priority: P1)

**Goal**: Evaluate all four governance protocols (I.06, I.07, I.09, I.10) at session close and include results in the witness artifact alongside existing protocols.

**Independent Test**: End a session and verify witness artifact includes results for I.06, I.07, I.09, I.10 alongside I.01-I.05, I.08.

**Note**: This phase depends on US1, US2, US4, US5 being complete. It integrates all governance protocols into the existing verification and witness emission flow.

### Implementation for User Story 3

- [X] T021 [US3] Register governance protocols in backend/src/integrity/protocols/protocol-base.ts — import I06PresenceIdentity, I07AntiAcedia, I09CoAgencyBalance, I10FutureInterpretability; add to getDefaultProtocols() return array after I.08 (order: structural I.02-I.04, operational I.01/I.05/I.08, governance I.06/I.07/I.09/I.10); total 10 protocols
- [X] T022 [US3] Extend verify() with coAgencyActions parameter in backend/src/integrity/verification-engine.ts — add optional coAgencyActions: IrreversibleAction[] = [] parameter to verify(); include coAgencyActions in EvaluationContext construction; import IrreversibleAction type
- [X] T023 [US3] Update session close flow in backend/src/api/routes/sessions.ts — retrieve co-agency history via getHistory(sessionId); retrieve AI metadata via getAiMetadata(sessionId); pass coAgencyActions to verify(); pass AI metadata to emitWitness/buildWitnessArtifact; follow verification flow from quickstart.md steps 6-10
- [X] T024 [US3] Clear governance state on session dissolution in backend/src/api/routes/sessions.ts — after kernel dissolution: call clearSession(sessionId) on acedia-monitor; call clearSession(sessionId) on co-agency-tracker; call clearAiMetadata(sessionId) on handlers; place alongside existing admin action clearing
- [X] T025 [P] [US3] Integration test for acedia lifecycle in backend/tests/integration/integrity/acedia-lifecycle.test.ts — test full lifecycle: create session → idle past CREATED threshold → verify ACEDIA_WARNING in ledger → activate → idle past ACTIVE threshold → verify ACEDIA_DETECTION → wait for countdown → verify ACEDIA_FORCE_RELEASE and session ENDED; test activity during countdown → verify ACEDIA_CANCELLED and session remains ACTIVE; use shortened thresholds for test speed
- [X] T026 [P] [US3] Integration test for co-agency enforcement in backend/tests/integration/integrity/co-agency-enforcement.test.ts — test session close flow: verify HUMAN/SESSION_END + MACHINE/FINALIZATION + MACHINE/VERIFICATION stays within co-agency limits; test that 3 consecutive same-type irreversible actions outside close flow are suppressed; test I.09 produces FAIL in verification for sessions with balance violations; verify suppression event recorded in ledger

**Checkpoint**: All 10 protocols (I.01-I.10, excluding I.04 per 007 scope) are evaluated at every session close; witness artifacts are complete

---

## Phase 7: Polish & Cross-Cutting Concerns

**Purpose**: Final validation across all user stories

- [X] T027 Run full test suite (npx vitest run) from backend/ and fix any regressions in existing 148 integrity tests
- [X] T028 Verify privacy boundary compliance — confirm no governance tracking record contains message content, personal data, or conversation details; check all metadata snapshots for acedia events contain only session ID, state, and timestamps

---

## Dependencies & Execution Order

### Phase Dependencies

- **Setup (Phase 1)**: No dependencies — can start immediately
- **Foundational types (T002)**: BLOCKS all user story implementation
- **US1 (Phase 2)**: Depends on T001, T002 — produces acedia-monitor.ts and I.07
- **US2 (Phase 3)**: Depends on T002 — produces co-agency-tracker.ts and I.09
- **US4 (Phase 4)**: Depends on T002 — produces I.06
- **US5 (Phase 5)**: Depends on T002 — produces I.10 and AI metadata tracking
- **US3 (Phase 6)**: Depends on US1, US2, US4, US5 — integrates all protocols
- **Polish (Phase 7)**: Depends on all user stories being complete

### User Story Dependencies

- **US1 (P1)**: Can start after T002 — no dependencies on other stories
- **US2 (P1)**: Can start after T002 — no dependencies on other stories
- **US4 (P2)**: Can start after T002 — no dependencies on other stories
- **US5 (P2)**: Can start after T002 — no dependencies on other stories
- **US3 (P1)**: Depends on US1 + US2 + US4 + US5 (integration story)

### Within Each User Story

- Core module before integration tasks
- Integration tasks before tests that depend on the integration
- Protocol evaluators can be built in parallel with their respective modules
- Unit tests can be built in parallel with each other within a story

### Parallel Opportunities

- T001 and T002 can run in parallel (different files)
- T004, T005, T006 can run in parallel (different files, all depend only on T003 or T002)
- T011, T012, T013 can run in parallel within US2
- T015 and T016 can run in parallel within US4
- T018 and T019 can run in parallel within US5
- T025 and T026 can run in parallel within US3
- US1, US2, US4, US5 can run in parallel (if team capacity allows) after T002

---

## Parallel Example: User Story 1

```bash
# After T003 (acedia-monitor.ts) is complete, launch in parallel:
Task: "Implement I.07 evaluator in backend/src/integrity/protocols/i07-anti-acedia.ts"        # T004
Task: "Unit tests for acedia monitor in backend/tests/unit/integrity/acedia-monitor.test.ts"   # T005
Task: "Unit tests for I.07 in backend/tests/unit/integrity/protocols/i07-anti-acedia.test.ts"  # T006
```

## Parallel Example: User Story 2

```bash
# After T010 (co-agency-tracker.ts) is complete, launch in parallel:
Task: "Implement I.09 evaluator in backend/src/integrity/protocols/i09-co-agency-balance.ts"         # T011
Task: "Unit tests for co-agency tracker in backend/tests/unit/integrity/co-agency-tracker.test.ts"    # T012
Task: "Unit tests for I.09 in backend/tests/unit/integrity/protocols/i09-co-agency-balance.test.ts"   # T013
```

---

## Implementation Strategy

### MVP First (User Story 1 Only)

1. Complete Phase 1: Setup (T001-T002)
2. Complete Phase 2: User Story 1 — Acedia Detection (T003-T009)
3. **STOP and VALIDATE**: Test acedia monitor independently with shortened thresholds
4. Acedia detection is operational; sessions are no longer left in governance limbo

### Incremental Delivery

1. Setup (T001-T002) → Types and migration ready
2. US1 (T003-T009) → Acedia detection operational → Validate
3. US2 (T010-T014) → Co-agency enforcement operational → Validate
4. US4 (T015-T016) → I.06 identity evaluator ready → Validate
5. US5 (T017-T020) → AI metadata tracking + I.10 ready → Validate
6. US3 (T021-T026) → All 10 protocols integrated at session close → Validate
7. Polish (T027-T028) → Full regression + privacy check

### Parallel Team Strategy

With multiple developers after T002 is complete:

1. Developer A: US1 (acedia detection + I.07)
2. Developer B: US2 (co-agency tracking + I.09)
3. Developer C: US4 + US5 (I.06, AI metadata + I.10)
4. All reconvene for US3 (integration) and Polish

---

## Notes

- [P] tasks = different files, no dependencies on incomplete tasks
- [Story] label maps task to specific user story for traceability
- sessions.ts is modified across US1 (T009), US2 (T014), US3 (T023, T024) — execute sequentially
- handlers.ts is modified in US1 (T008) and US5 (T017) — execute sequentially
- Acedia thresholds are configurable; use shortened values in tests (e.g., 100ms) for speed
- All in-memory Maps follow the same pattern as admin action log in suppression-engine.ts
- Co-agency exemptions: acedia force-release, suppression recording, witness emission
- I.07 evaluates final outcome only — transient ACEDIA_WARNING/DETECTION/CANCELLED do not cause FAIL
