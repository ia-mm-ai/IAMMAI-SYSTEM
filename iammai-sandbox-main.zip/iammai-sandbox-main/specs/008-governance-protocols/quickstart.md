# Quickstart: 008-governance-protocols

## Prerequisites

- Feature 007 (presence-suppression) merged and working
- PostgreSQL running with existing migrations applied (001-005)
- Node.js 20 LTS, pnpm

## Setup

```bash
# Switch to feature branch
git checkout 008-governance-protocols

# Install dependencies (no new external deps)
pnpm install

# Run new migration
psql -d iammai_sandbox < backend/migrations/006_add_acedia_event_types.sql
```

## Key Files (New)

```
backend/src/integrity/
  acedia-monitor.ts              # startMonitor(), stopMonitor(), checkSessions(), recordActivity()
  co-agency-tracker.ts           # trackAction(), canPerformAction(), getHistory()
  protocols/
    i06-presence-identity.ts     # Identity from presence set, not credentials
    i07-anti-acedia.ts           # FAIL only if force-released
    i09-co-agency-balance.ts     # Max 2 consecutive irreversible actions per agent type
    i10-future-interpretability.ts # AI metadata available for witness

backend/migrations/
  006_add_acedia_event_types.sql # ACEDIA_WARNING, ACEDIA_DETECTION, ACEDIA_CANCELLED, ACEDIA_FORCE_RELEASE
```

## Key Files (Modified)

```
backend/src/integrity/
  types.ts                       # AcediaPhase, CoAgencyState, IrreversibleAction, AI metadata types
  verification-engine.ts         # Extended verify() with coAgencyActions param
  witness-emitter.ts             # AI metadata (model, tokens) in witness artifact
  protocols/protocol-base.ts     # Add I.06, I.07, I.09, I.10 to getDefaultProtocols()

backend/src/api/routes/
  sessions.ts                    # Co-agency tracking; acedia activity recording; AI metadata in close flow

backend/src/api/websocket/
  handlers.ts                    # AI token tracking per session; acedia activity recording

backend/src/server.ts            # Start/stop acedia monitor on server lifecycle
```

## Verification Flow (Updated)

```
Session End Request
    │
    ├─ 1. Log admin action: SESSION_END
    ├─ 2. Co-agency: track HUMAN irreversible action (SESSION_END)     ← NEW
    ├─ 3. State transition ACTIVE → ENDED (atomic with ledger)
    ├─ 4. Finalize all presence records for session
    ├─ 5. Co-agency: track MACHINE irreversible action (FINALIZATION)   ← NEW
    ├─ 6. Retrieve presence records + admin actions + co-agency history ← EXTENDED
    ├─ 7. Run verification (I.01-I.04, I.05, I.08, I.06, I.07, I.09, I.10)  ← EXTENDED
    ├─ 8. Co-agency: track MACHINE irreversible action (VERIFICATION)  ← NEW
    ├─ 9. If FAIL: record suppression (observational, not co-agency tracked)
    ├─ 10. Emit witness with AI metadata                               ← UPDATED
    ├─ 11. Broadcast dissolution
    ├─ 12. Dissolve kernel + clear acedia/co-agency state              ← UPDATED
    └─ 13. Clear admin actions
```

## Acedia Monitor Flow (New)

```
Server Startup
    │
    ├─ startMonitor() — begins 60-second polling interval
    │
    └─ Every 60 seconds: checkSessions()
         │
         ├─ Query CREATED sessions where created_at + 15min < NOW
         │   └─ Record ACEDIA_WARNING in ledger (if not already warned)
         │
         ├─ Query ACTIVE sessions where lastActivity + 30min < NOW
         │   └─ Record ACEDIA_DETECTION in ledger; start countdown
         │
         └─ Check sessions in COUNTDOWN where countdown + 10min < NOW
             └─ Record ACEDIA_FORCE_RELEASE; close session via existing end flow
```

## Testing

```bash
# Run all tests
npm test

# Run only 008 tests
npx vitest run tests/unit/integrity/acedia-monitor.test.ts
npx vitest run tests/unit/integrity/co-agency-tracker.test.ts
npx vitest run tests/unit/integrity/protocols/i06-presence-identity.test.ts
npx vitest run tests/unit/integrity/protocols/i07-anti-acedia.test.ts
npx vitest run tests/unit/integrity/protocols/i09-co-agency-balance.test.ts
npx vitest run tests/unit/integrity/protocols/i10-future-interpretability.test.ts
```

## Quick Verification

1. Start server → verify acedia monitor logs "Acedia monitor started"
2. Create a session and wait 15+ minutes → check ledger for ACEDIA_WARNING entry
3. Start a session and wait 30+ minutes → check ledger for ACEDIA_DETECTION entry
4. Wait 10 more minutes → check session is force-closed; ledger has ACEDIA_FORCE_RELEASE
5. End a session normally → verify witness includes I.06, I.07, I.09, I.10 results
6. End a session with AI participation → verify witness metadata includes ai_model and ai_total_tokens
7. Attempt 3 consecutive machine irreversible actions → verify 3rd is suppressed
