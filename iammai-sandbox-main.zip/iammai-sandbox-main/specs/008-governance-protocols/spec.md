# Feature Specification: Governance Protocols

**Feature Branch**: `008-governance-protocols`
**Created**: 2026-02-18
**Status**: Draft
**Input**: User description: "Governance protocols: acedia detection, co-agency balance, presence-derived identity, and future interpretability for the integrity layer"

## User Scenarios & Testing *(mandatory)*

### User Story 1 - Stalled Session Detection and Resolution (Priority: P1)

When a session remains idle beyond defined thresholds, the system detects the stall (acedia) and takes corrective action. Sessions stuck in the initial state for more than 15 minutes without progressing receive a warning. Active sessions with no participant activity for more than 30 minutes trigger acedia detection, followed by a 10-minute countdown before automatic forced release. This prevents resource waste and ensures sessions don't linger indefinitely in a governance-ambiguous state.

**Why this priority**: Stalled sessions consume system resources and create governance gaps — an open session with no activity is neither productive nor properly closed, leaving the integrity layer in an ambiguous state where verification and witness emission cannot occur.

**Independent Test**: Can be verified by creating a session and observing system behavior as idle time exceeds each threshold (15min, 30min, 10min countdown).

**Acceptance Scenarios**:

1. **Given** a session in CREATED state with no transition to ACTIVE, **When** 15 minutes elapse, **Then** the system issues an acedia warning recorded in the integrity ledger.
2. **Given** an ACTIVE session with no messages from any participant, **When** 30 minutes of inactivity elapse, **Then** acedia detection triggers and a 10-minute countdown begins.
3. **Given** acedia detection has triggered and 10 minutes pass with no activity, **Then** the system forces the session to close (RELEASE) and records the forced resolution in the ledger.
4. **Given** acedia detection has triggered, **When** any participant sends a message or an admin command is issued within the countdown, **Then** the countdown resets and detection clears.

---

### User Story 2 - Co-Agency Balance Enforcement (Priority: P1)

The system enforces balanced participation between human and AI agents in irreversible actions. No agent type (human or AI) may execute more than 2 consecutive irreversible actions without involvement from the other type. This prevents unilateral dominance and ensures meaningful co-participation in governance-significant operations.

**Why this priority**: Without balance enforcement, one agent type could dominate session governance — for example, the machine could finalize presence, run verification, and execute suppression with no human involvement, violating the co-agency principle.

**Independent Test**: Can be verified by simulating a sequence of irreversible actions by one agent type and confirming the third consecutive action is suppressed until the other type acts.

**Acceptance Scenarios**:

1. **Given** two consecutive irreversible actions by the same agent type, **When** a third irreversible action by the same type is attempted, **Then** the system suppresses the action and records the suppression event.
2. **Given** two consecutive irreversible actions by one agent type, **When** the other agent type performs an action, **Then** the counter resets and the first type may act again.
3. **Given** a non-irreversible action (e.g., reading session state, sending a chat message), **When** it is performed, **Then** the co-agency counter is NOT affected.

---

### User Story 3 - Governance Protocol Verification at Session Close (Priority: P1)

When a session closes, four governance protocols are evaluated as part of the existing verification process: presence-derived identity (I.06), anti-acedia (I.07), co-agency balance (I.09), and future interpretability (I.10). Each produces a binary PASS/FAIL result. All four must PASS (along with existing protocols) for overall verification to PASS. Results are included in the session's witness artifact.

**Why this priority**: Without governance protocol evaluation at session close, the system cannot verify compliance with governance requirements, and witness artifacts would be incomplete — undermining the integrity of the entire framework.

**Independent Test**: Can be verified by ending a session and confirming that the witness artifact includes all four governance protocol results.

**Acceptance Scenarios**:

1. **Given** a session that closes with proper governance behavior (no acedia, balanced co-agency, valid identity, self-describing witness), **When** verification runs, **Then** all four governance protocols produce PASS results.
2. **Given** a session where co-agency balance was violated during its lifecycle, **When** verification runs, **Then** I.09 produces FAIL and overall verification produces FAIL.
3. **Given** a session where acedia was detected but not resolved through participant activity (force-released), **When** verification runs, **Then** I.07 produces FAIL.
4. **Given** a session where acedia detection triggered but participant activity resumed (countdown cancelled), **When** verification runs, **Then** I.07 produces PASS — transient stalls that are resolved do not constitute persistent neglect.
5. **Given** a session closes, **When** the witness artifact is emitted, **Then** it includes results for I.06, I.07, I.09, and I.10 alongside existing protocols.

---

### User Story 4 - Admin Identity as Presence Set (Priority: P2)

Admin identity is defined exclusively as the set of sessions where verified admin presence exists — not by credentials, names, or external identifiers. The system constructs and tracks this identity set, enabling identity verification based on behavioral presence rather than traditional authentication claims. This aligns with the framework's principle that identity is a set construction, not a summation.

**Why this priority**: Presence-derived identity is a framework compliance requirement evaluated at session close rather than actively gating real-time operations. Its verification confirms adherence to identity principles rather than blocking actions.

**Independent Test**: Can be verified by creating multiple sessions with admin presence and confirming the identity set is correctly constructed and evaluated at each session close.

**Acceptance Scenarios**:

1. **Given** an admin has created sessions S1, S2, S3 with verified presence in each, **When** identity is evaluated for any of those sessions, **Then** the admin's identity set contains the sessions where presence was attested.
2. **Given** a session where admin presence was NOT attested, **When** identity is evaluated, **Then** that session is NOT included in the admin's identity set.
3. **Given** an anonymous user with no admin presence, **When** identity is evaluated, **Then** the user has no identity set (empty set — permitted by the framework).

---

### User Story 5 - AI Reasoning Metadata in Witnesses (Priority: P2)

Witness artifacts include AI reasoning metadata — specifically the AI model name and token count — to ensure future interpretability. This metadata describes what AI system participated and the scope of its involvement, without ever capturing AI output content. This enables future auditors to understand the AI's role without exposing private conversation data.

**Why this priority**: Future interpretability is a compliance requirement but does not gate real-time operations. It enhances auditability for post-hoc review.

**Independent Test**: Can be verified by ending a session with AI participation and checking that the witness artifact includes model name and token count.

**Acceptance Scenarios**:

1. **Given** a session with AI participation, **When** the witness artifact is emitted, **Then** it includes the AI model name and token count in its metadata.
2. **Given** a witness artifact, **When** read by an external system with no prior knowledge of the IAMMAI Sandbox system, **Then** the artifact is self-describing — all fields, their meanings, and the verification outcome are interpretable without external documentation.
3. **Given** a witness artifact, **When** inspected for content, **Then** it contains NO AI output, conversation text, or personal data.
4. **Given** a session with no AI participation, **When** the witness is emitted, **Then** AI metadata fields are omitted and I.10 still produces PASS.

---

### Edge Cases

- What happens when the acedia countdown reaches zero simultaneously with a participant message? The message takes priority if received before the forced release is executed.
- What happens when the system restarts during an acedia countdown? Sessions with last activity exceeding thresholds are re-evaluated on startup; countdown state is recoverable from recorded timestamps.
- What happens when exactly 2 irreversible actions have occurred and the next action is non-irreversible? Non-irreversible actions do not trigger suppression and do not reset the counter.
- What happens when a session has no AI participation? I.10 (future interpretability) passes with a note that no AI was involved; AI metadata fields are absent from the witness.
- What happens when multiple admins create sessions? Each admin has their own identity set, distinguished by their anonymous presence hash.
- What happens when acedia detection triggers but the session is already being closed? The closing process takes precedence; acedia does not force-release a session already transitioning to ENDED.
- What happens when the only activity during a session is admin commands (no participant messages)? Admin commands count as activity for acedia purposes, preventing false stall detection.
- What happens when acedia forces a release but the machine has exceeded the co-agency limit? Acedia force-release is exempt from co-agency enforcement — it always executes and is not counted as an agent action, preventing governance deadlocks.

## Requirements *(mandatory)*

### Functional Requirements

- **FR-001**: The system MUST detect sessions in CREATED state that have not transitioned to ACTIVE within 15 minutes and record an acedia warning in the integrity ledger.
- **FR-002**: The system MUST detect ACTIVE sessions with no participant messages for 30 minutes and trigger acedia detection with a 10-minute countdown.
- **FR-003**: The system MUST force-close (RELEASE) sessions where the 10-minute acedia countdown expires without new activity, recording the forced resolution.
- **FR-004**: The system MUST cancel the acedia countdown and clear detection when any participant message or admin command is received during the countdown period.
- **FR-005**: Activity for acedia purposes MUST include any message from any participant or any admin command — NOT system-generated events.
- **FR-006**: The system MUST track consecutive irreversible actions per agent type (human or AI) on a per-session basis.
- **FR-007**: The system MUST suppress any irreversible action when the acting agent type has already performed 2 consecutive irreversible actions without involvement from the other type.
- **FR-008**: The co-agency counter MUST reset when the other agent type performs any action (irreversible or not).
- **FR-009**: Irreversible actions are defined as: session termination (human), presence finalization (machine), verification execution (machine), and suppression enforcement (machine). Acedia force-release is explicitly exempt — it is a system governance action, not an agent action, and does not increment or reset co-agency counters.
- **FR-010**: Non-irreversible actions (session creation, message sending, reading state) MUST NOT affect the co-agency counter.
- **FR-011**: The system MUST construct admin identity as a set of sessions where verified admin presence exists: `identity(admin) = { session | presence(admin, session) = true }`.
- **FR-012**: The system MUST NOT derive identity from credentials, names, emails, or any personal identifiers.
- **FR-013**: Anonymous users MUST have no identity set — empty set is permitted by the framework.
- **FR-014**: Witness artifacts MUST include AI model name and total token count (single cumulative input + output number across all AI interactions) when AI participated in the session.
- **FR-015**: Witness artifacts MUST be self-describing — all fields interpretable without external documentation.
- **FR-016**: The system MUST evaluate four governance protocols (I.06, I.07, I.09, I.10) during session close verification, producing individual PASS/FAIL results.
- **FR-017**: Governance protocol results MUST be included in the witness artifact alongside existing protocol results (I.01-I.05, I.08).
- **FR-018**: All acedia events (warnings, detection, countdown start, countdown cancellation, forced release) MUST be recorded in the integrity ledger.
- **FR-019**: All co-agency suppression events MUST be recorded in the integrity ledger with action type and reason.
- **FR-020**: The privacy boundary MUST be maintained — governance tracking records only metadata (timestamps, counts, action types), never message content or personal data.
- **FR-021**: Protocol I.07 MUST evaluate based on final session outcome only — sessions where acedia was detected but activity resumed (countdown cancelled) MUST produce PASS. Only sessions force-released due to unresolved acedia produce FAIL.

### Key Entities

- **Acedia State**: Represents the stall-detection status of a session — includes idle duration tracking, current threshold phase (normal / warning / detection / countdown), last activity timestamp, and countdown expiration time.
- **Co-Agency Counter**: Per-session tracker of consecutive irreversible actions by agent type — includes current consecutive count, last acting agent type (human or machine), and action history for the session.
- **Admin Identity Set**: The collection of session references where a specific admin (identified by anonymous presence hash) has verified presence — constructed exclusively from presence records.
- **Governance Protocol Result**: Binary PASS/FAIL evaluation for each governance protocol (I.06, I.07, I.09, I.10) with human-readable details explaining the outcome.

## Success Criteria *(mandatory)*

### Measurable Outcomes

- **SC-001**: 100% of sessions idle beyond the CREATED threshold (15 minutes) receive a recorded acedia warning.
- **SC-002**: 100% of sessions idle beyond the ACTIVE threshold (30 minutes) trigger acedia detection with a countdown.
- **SC-003**: 100% of sessions where the acedia countdown expires without activity are automatically force-closed.
- **SC-004**: 0% of irreversible actions succeed when the acting agent type has exceeded the consecutive action limit of 2.
- **SC-005**: 100% of co-agency suppression events are recorded with action type and reason.
- **SC-006**: Admin identity is always derived from presence sets, never from credentials — verified by protocol I.06 on every session close.
- **SC-007**: 100% of witness artifacts for sessions with AI participation include model name and token count.
- **SC-008**: 100% of witness artifacts are self-describing and interpretable without external reference material.
- **SC-009**: All four governance protocols are evaluated on every session close and results appear in the witness artifact.
- **SC-010**: 0% of governance tracking records contain message content, personal data, or conversation details.

## Assumptions

- Feature 007 (Presence + Suppression) is complete — suppression engine, presence tracker, and protocols I.01, I.05, I.08 are operational.
- Feature 006 (Verification + Witness) is complete — verification engine, witness emitter, protocol evaluator interface, and witness artifact format are operational.
- Feature 005 (Structural Foundation) is complete — ledger, state observer, boundary enforcement, and hash-chained event recording are operational.
- Acedia thresholds (15min CREATED, 30min ACTIVE, 10min countdown) are as defined in Framework Decision 6.
- Co-agency balance limit (max 2 consecutive irreversible actions per agent type) is as defined in Framework Decision 7.
- Identity formula (set construction, not summation) is as defined in Framework Decision 4.
- Verification dispatch order places governance protocols (I.06, I.07, I.09, I.10) after structural and operational protocols, as defined in Framework Decision 8.
- AI model name and token count are available from the session metadata layer without exposing message content.

## Clarifications

### Session 2026-02-18

- Q: When evaluating I.07 at session close, does any acedia event in history cause FAIL, or only the final resolution? → A: Final-outcome only — I.07 FAIL only if the session was force-released due to acedia. Sessions where acedia was detected but activity resumed get PASS. Transient stalls that are resolved do not constitute "persistent neglect."
- Q: Does co-agency enforcement apply to acedia force-releases? → A: Acedia force-release is exempt from co-agency tracking. It executes regardless of the co-agency counter and is NOT counted as a co-agency action (does not increment or reset counters). It is a system governance action, not an agent action.
- Q: What level of detail should "token count" capture for AI participation metadata? → A: Total tokens — a single cumulative number (input + output) across all AI interactions in the session. Per-interaction breakdowns risk revealing conversation flow patterns and approaching the privacy boundary.

## Dependencies

- **005-structural-foundation**: Ledger service, state observer, session model, hash chain utilities.
- **006-verification-witness**: Verification engine, witness emitter, protocol evaluator interface, witness artifact format.
- **007-presence-suppression**: Presence tracker, suppression engine, presence records, admin actions tracking.
