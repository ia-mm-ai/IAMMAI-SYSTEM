# Data Model: Feature 009 — Compliance Test

**Feature Branch**: `009-compliance-test`
**Date**: 2026-02-18

## Overview

Feature 009 introduces no new database tables or schema changes. It is a read-only audit module that queries existing tables and produces in-memory result objects. All types below are TypeScript interfaces added to `backend/src/integrity/types.ts`.

## New Types

### ComplianceResult

The top-level output of a compliance test run.

```typescript
interface ComplianceResult {
  overall: 'COMPLIANT' | 'NON_COMPLIANT' | 'ERROR';
  conditions: ConditionEvaluation[];
  executedAt: string;      // ISO 8601 timestamp
  systemVersion: string;   // Package version or git SHA
  sessionsEvaluated: number;
  error?: string;          // Present only when overall === 'ERROR'
}
```

| Field | Type | Constraints |
|-------|------|-------------|
| `overall` | `'COMPLIANT' \| 'NON_COMPLIANT' \| 'ERROR'` | COMPLIANT iff all conditions PASS. ERROR on infrastructure failure. |
| `conditions` | `ConditionEvaluation[]` | Always 5 elements (one per §11 condition) in a full run. 1 element for single-condition runs. |
| `executedAt` | `string` | ISO 8601 UTC. Set at start of evaluation. |
| `systemVersion` | `string` | Read from package.json or hardcoded constant. |
| `sessionsEvaluated` | `number` | Count of ENDED sessions examined. |
| `error` | `string \| undefined` | Infrastructure error message. Absent when evaluation completes. |

### ConditionEvaluation

Result of evaluating a single §11 condition.

```typescript
interface ConditionEvaluation {
  condition: ComplianceCondition;
  label: string;
  result: 'PASS' | 'FAIL';
  evidence: EvidenceItem[];
}
```

| Field | Type | Constraints |
|-------|------|-------------|
| `condition` | `ComplianceCondition` | Enum identifier (see below). |
| `label` | `string` | Human-readable name (e.g., "Truth finalizes only in closed events"). |
| `result` | `'PASS' \| 'FAIL'` | Binary determination for this condition. |
| `evidence` | `EvidenceItem[]` | At least 1 item on FAIL. May have items on PASS for audit trail. |

### ComplianceCondition

Identifier for the five §11 conditions.

```typescript
type ComplianceCondition =
  | 'TRUTH_FINALIZATION'
  | 'DETERMINISTIC_VERIFICATION'
  | 'MANDATORY_SUPPRESSION'
  | 'HISTORY_NON_REGRESSION'
  | 'AUTHORITY_NON_ASSERTION';
```

### EvidenceItem

A specific data point supporting a condition evaluation.

```typescript
interface EvidenceItem {
  type: EvidenceType;
  description: string;
  sessionId?: string;
  details?: Record<string, unknown>;
}
```

| Field | Type | Constraints |
|-------|------|-------------|
| `type` | `EvidenceType` | Category of evidence (see below). |
| `description` | `string` | Human-readable explanation of what this evidence demonstrates. |
| `sessionId` | `string \| undefined` | Relevant session ID, if applicable. |
| `details` | `Record<string, unknown> \| undefined` | Structured data — entry IDs, timestamps, hash values. Never message content. |

### EvidenceType

```typescript
type EvidenceType =
  | 'SESSION_REFERENCE'
  | 'LEDGER_ENTRY'
  | 'PRESENCE_RECORD'
  | 'WITNESS_ARTIFACT'
  | 'SUPPRESSION_RECORD'
  | 'PROTOCOL_RESULT'
  | 'SCHEMA_CHECK'
  | 'HASH_CHAIN'
  | 'STATE_TRANSITION'
  | 'ADMIN_ACTION';
```

## Existing Tables Queried (Read-Only)

### sessions
- **Filter**: `state = 'ENDED'`
- **Fields used**: `id`, `state`, `created_at`, `started_at`, `ended_at`

### integrity_ledger
- **Per session**: All entries via `getEntriesBySession(sessionId)`
- **Global**: Full chain via `validateChain()`
- **Event types of interest**: `VERIFICATION_WITNESS`, `SUPPRESSION_EVENT`, `SESSION_CLOSED`

### presence_records
- **Per session**: All records via `getPresenceRecords(sessionId)`
- **Fields used**: `session_id`, `finalized`, `finalized_at`, `role`, `presence_hash`, `attestation_method`

### pg_trigger + pg_class (schema inspection)
- **Check**: Existence of `trg_integrity_ledger_no_update` and `trg_integrity_ledger_no_delete` triggers on `integrity_ledger` table

## API Response Mapping

The `GET /api/v1/admin/compliance` endpoint returns `ComplianceResult` as JSON with no transformation. The frontend consumes the same shape directly.

```
GET /api/v1/admin/compliance
→ 200: ComplianceResult (JSON)
→ 401: { code: 'UNAUTHORIZED', message: '...' }
→ 500: { code: 'INTERNAL_ERROR', message: '...' }

GET /api/v1/admin/compliance?condition=TRUTH_FINALIZATION
→ 200: ComplianceResult (single condition in conditions array)
→ 400: { code: 'INVALID_CONDITION', message: '...' }
```

## Entity Relationships

```
ComplianceResult (1) ──has──> (5) ConditionEvaluation
ConditionEvaluation (1) ──has──> (0..*) EvidenceItem
```

No relationships to persistent entities — all references are by ID (string), maintaining the read-only boundary.

## Privacy Boundary

All types strictly exclude:
- Message content (`Conversation.messages`)
- Raw token values (`ActiveToken.raw`)
- Personal data (no email, no names beyond session names)
- Presence hashes are referenced only when demonstrating attestation patterns, never correlated to identity

This aligns with FR-016 and Constitution Principle V.
