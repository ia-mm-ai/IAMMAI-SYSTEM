# Quickstart: Feature 009 — Compliance Test

## What This Feature Does

Feature 009 adds a read-only compliance module that evaluates the complete integrity layer against the five MM-MODEL §11 conditions. It produces a binary COMPLIANT / NON_COMPLIANT result with per-condition breakdowns and supporting evidence. An admin dashboard provides visual access to compliance results with expandable evidence.

## Prerequisites

- Features 005-008 must be complete and operational
- PostgreSQL database with all migrations applied (001-006)
- Node.js 20 LTS, TypeScript 5.3+

## Module Location

```
backend/src/integrity/compliance-checker.ts    # The compliance module
backend/src/integrity/types.ts                 # New types added here
backend/src/api/routes/compliance.ts           # API endpoint
frontend/apps/admin/src/pages/compliance/      # Admin dashboard page
frontend/apps/admin/src/components/ConditionCard.tsx  # Condition display component
```

## Backend Usage

### Full Compliance Check (Programmatic)

```typescript
import { runComplianceCheck } from './integrity/compliance-checker.js';

const result = await runComplianceCheck();

console.log(result.overall);           // 'COMPLIANT' | 'NON_COMPLIANT' | 'ERROR'
console.log(result.sessionsEvaluated); // Number of ENDED sessions checked
console.log(result.conditions);        // Array of 5 ConditionEvaluation objects

for (const cond of result.conditions) {
  console.log(`${cond.label}: ${cond.result}`);
  for (const ev of cond.evidence) {
    console.log(`  - [${ev.type}] ${ev.description}`);
  }
}
```

### Single Condition Check (Programmatic)

```typescript
import { runConditionCheck } from './integrity/compliance-checker.js';

const result = await runConditionCheck('TRUTH_FINALIZATION');
// result.conditions has exactly 1 element
// result.overall reflects only that condition
```

### API Endpoint

```bash
# Full compliance check (requires admin auth token)
curl -H "Authorization: Bearer <token>" \
  http://localhost:3001/api/v1/admin/compliance

# Single condition check
curl -H "Authorization: Bearer <token>" \
  http://localhost:3001/api/v1/admin/compliance?condition=TRUTH_FINALIZATION
```

### Available Conditions

| Condition | Description |
|-----------|-------------|
| `TRUTH_FINALIZATION` | Presence finalizes only in closed events |
| `DETERMINISTIC_VERIFICATION` | Verification is deterministic and witnessed |
| `MANDATORY_SUPPRESSION` | Suppression is mandatory and enforced |
| `HISTORY_NON_REGRESSION` | History never regresses |
| `AUTHORITY_NON_ASSERTION` | Authority is never asserted |

## Frontend Dashboard

Navigate to `/compliance` in the admin panel (requires admin login). The dashboard provides:

1. **Run Compliance Check** button — triggers on-demand evaluation
2. **Overall status** — large COMPLIANT/NON_COMPLIANT/ERROR badge
3. **Per-condition cards** — 5 cards showing PASS/FAIL for each §11 condition
4. **Expandable evidence** — click a condition card to see supporting evidence items

## Running Tests

```bash
cd backend

# Run compliance module unit tests
npx vitest run tests/unit/integrity/compliance-checker.test.ts

# Run compliance integration tests (active probing)
npx vitest run tests/integration/integrity/compliance-suppression-enforcement.test.ts
npx vitest run tests/integration/integrity/compliance-history-immutability.test.ts
npx vitest run tests/integration/integrity/compliance-authority-override.test.ts

# Run all integrity tests
npx vitest run tests/unit/integrity/ tests/integration/integrity/
```

## Output Format

The `ComplianceResult` object serializes to JSON:

```json
{
  "overall": "COMPLIANT",
  "conditions": [
    {
      "condition": "TRUTH_FINALIZATION",
      "label": "Truth finalizes only in closed events",
      "result": "PASS",
      "evidence": [
        {
          "type": "SESSION_REFERENCE",
          "description": "All 3 closed sessions have fully finalized presence records",
          "details": { "sessionCount": 3 }
        }
      ]
    }
  ],
  "executedAt": "2026-02-18T12:00:00.000Z",
  "systemVersion": "1.0.0",
  "sessionsEvaluated": 3
}
```

## Key Design Decisions

1. **Read-only**: The compliance module never writes to the database
2. **Existing APIs**: Uses `ledger.getEntriesBySession()`, `presenceTracker.getPresenceRecords()`, etc.
3. **Privacy-safe**: Never accesses message content or personal data
4. **Deterministic**: Same system state always produces the same result
5. **Error isolation**: Infrastructure failures produce `ERROR`, not `NON_COMPLIANT`
6. **On-demand**: Dashboard triggers checks when the admin clicks the button — no polling or scheduling
7. **Admin-only**: Both API endpoint and dashboard page require admin authentication
