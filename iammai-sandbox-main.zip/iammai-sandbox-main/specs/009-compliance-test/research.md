# Research: Feature 009 — Compliance Test

**Feature Branch**: `009-compliance-test`
**Date**: 2026-02-18

## R.01: Compliance Module Architecture

**Decision**: Single `compliance-checker.ts` module in `backend/src/integrity/` with one exported function per condition plus a top-level `runComplianceCheck()` orchestrator.

**Rationale**: The compliance module is a read-only auditor — it queries existing data and produces a structured result. It has no state, no side effects, and no persistence. A single module keeps it co-located with the integrity layer it audits without introducing unnecessary file proliferation. Each condition evaluator is a private function; only the orchestrator and per-condition runners are exported.

**Alternatives considered**:
- **Separate file per condition**: Rejected. Five conditions are not complex enough to warrant five files. Each condition is 30-60 lines. A single file stays well under the 300-line constitution limit (~250 lines total).
- **Class-based evaluator pattern** (mirroring protocol evaluators): Rejected. Protocol evaluators need polymorphism for the verification engine's generic loop. The compliance module calls specific conditions by name — no polymorphism needed. Functions are simpler.
- **Separate `/compliance/` directory**: Rejected. One module and its tests don't justify a new directory. The module belongs in `integrity/` alongside the systems it audits.

## R.02: Data Access Strategy

**Decision**: The compliance module uses existing public APIs from the integrity layer — no direct SQL queries. Specifically:
- `session.list({ state: 'ENDED' })` for closed sessions
- `ledger.getEntriesBySession(sessionId)` for per-session ledger entries
- `ledger.validateChain()` for global hash chain integrity
- `presenceTracker.getPresenceRecords(sessionId)` for presence data
- `verify()` from verification-engine for determinism checks
- Direct `query()` for schema inspection (trigger existence check)

**Rationale**: Reusing existing APIs ensures the compliance module evaluates data the same way the system does. Direct SQL is only needed for one specific check: confirming database triggers exist (an infrastructure concern, not a data concern).

**Alternatives considered**:
- **All direct SQL**: Rejected. Duplicates logic already encapsulated in existing modules, and couples the compliance module to schema details.
- **New repository abstraction**: Rejected. Over-engineering for a read-only auditor that simply calls existing queries.

## R.03: Machine-Readable Output Format

**Decision**: The compliance result is a TypeScript interface (`ComplianceResult`) returned as a plain object. When served via API, it serializes naturally to JSON. The frontend consumes this JSON directly.

**Rationale**: The spec requires both human-readable and machine-readable output. A structured TypeScript object serves both — JSON for API consumers (CI, frontend), structured display for the admin dashboard. No need for separate formats.

**Alternatives considered**:
- **JUnit XML**: Rejected. Adds a dependency for a format only CI tools consume. JSON is universally parseable.
- **TAP (Test Anything Protocol)**: Rejected. Text-oriented, harder to parse programmatically than JSON.

## R.04: Determinism Verification Strategy

**Decision**: For Condition 2 (deterministic verification), the compliance module:
1. Checks that a `VERIFICATION_WITNESS` ledger entry exists for every ENDED session.
2. For a sample of sessions, re-runs `verify()` with the same inputs and compares results to the stored witness artifact.

**Rationale**: Existence of witness entries proves witnessing occurred. Re-running verification against stored inputs proves determinism — if the pure `verify()` function produces different results from what was witnessed, something is broken. The compliance module avoids re-running verification for ALL sessions (which could be expensive) by sampling up to a configurable limit.

**Alternatives considered**:
- **Check witness existence only**: Rejected. Proves witnessing but not determinism.
- **Re-run all sessions**: Rejected for production compliance checks with large datasets. Sampling is sufficient since `verify()` is a pure function — if it's non-deterministic, even a small sample will catch it.

## R.05: CI Integration Approach

**Decision**: The compliance module exposes a `runComplianceCheck()` function that returns `ComplianceResult`. Vitest tests call this function directly. For CI, the existing `npx vitest run` pipeline is sufficient — compliance tests are just another test suite that produces pass/fail.

**Rationale**: The compliance test is already a vitest-compatible module. No separate CLI runner needed. The integration tests that actively probe enforcement are also vitest tests. CI just runs the full test suite.

**Alternatives considered**:
- **Standalone CLI binary**: Rejected. Adds build/deployment complexity for something that's already a function call.

## R.06: Edge Case — Empty System

**Decision**: When no ENDED sessions exist, all conditions return PASS (vacuous truth). The compliance result is COMPLIANT with evidence noting "No closed sessions to evaluate."

**Rationale**: Per the spec: "conditions are vacuously satisfied when there is no data to violate them." The hash chain check (`validateChain()`) on an empty ledger also returns valid.

## R.07: Edge Case — Active Sessions During Check

**Decision**: The compliance module filters to `state = 'ENDED'` sessions only. ACTIVE and CREATED sessions are excluded entirely.

**Rationale**: Per FR-013: "The compliance test MUST evaluate only closed sessions." Active sessions have incomplete lifecycles — they haven't been through verification, witnessing, or finalization yet.

## R.08: Integration Test Strategy for Active Probing

**Decision**: Separate vitest integration test files in `backend/tests/integration/integrity/` for active probing:
- `compliance-suppression-enforcement.test.ts` — Attempts mutations after FAIL, confirms suppression
- `compliance-history-immutability.test.ts` — Attempts DELETE/UPDATE on ledger, confirms trigger blocks them
- `compliance-authority-override.test.ts` — Simulates admin override attempts, confirms they're suppressed

These tests mock DB at the module level (same pattern as existing integration tests) and exercise the actual enforcement code paths.

**Rationale**: The spec explicitly separates read-only compliance audit (the module) from active probing (integration tests). Existing test infrastructure already has patterns for these — `suppression-enforcement.test.ts` and `ledger-immutability.test.ts` already test some of these scenarios. The compliance integration tests build on and extend these patterns.

**Alternatives considered**:
- **Tests inside the compliance module**: Rejected. Active probing is fundamentally different from passive auditing. Different files, different concerns.
- **E2E tests with real DB**: Not needed — the enforcement mechanisms (triggers, state observer, suppression engine) are already tested with mocked DB. Real DB tests are in the existing integration suite.

## R.09: Trigger Existence Verification

**Decision**: Condition 4 (History Non-Regression) includes a check for DB trigger existence by querying `pg_trigger` joined with `pg_class`. This is the only direct SQL query in the compliance module.

**Rationale**: Database triggers (`trg_integrity_ledger_no_update`, `trg_integrity_ledger_no_delete`) are infrastructure-level protections. Their existence can only be verified by schema inspection. This is a lightweight query that proves the protective mechanism is in place.

**Query pattern**:
```sql
SELECT tgname FROM pg_trigger
JOIN pg_class ON pg_trigger.tgrelid = pg_class.oid
WHERE pg_class.relname = 'integrity_ledger'
AND tgname IN ('trg_integrity_ledger_no_update', 'trg_integrity_ledger_no_delete')
```

## R.10: API Endpoint Design

**Decision**: Single `GET /api/v1/admin/compliance` endpoint behind `requireAdmin` middleware. Returns the `ComplianceResult` JSON. Optional `?condition=TRUTH_FINALIZATION` query parameter for single-condition checks.

**Rationale**: Follows the existing admin route pattern (`/api/v1/admin/sessions`). GET is appropriate since the operation is read-only. The endpoint calls `runComplianceCheck()` or `runConditionCheck(condition)` directly — no caching, no scheduling. Admin auth ensures only authorized operators can trigger compliance checks.

**Alternatives considered**:
- **POST endpoint**: Rejected. The operation has no side effects — GET is semantically correct.
- **Separate endpoints per condition**: Rejected. A single endpoint with an optional query parameter is simpler. The frontend can call it once for the full check or with a parameter for a targeted check.
- **WebSocket streaming**: Rejected. The compliance check completes in <200ms — streaming adds complexity for no benefit.

## R.11: Frontend Dashboard Architecture

**Decision**: A new admin page at `/compliance` (file: `pages/compliance/index.tsx`) with a reusable `ConditionCard` component for expandable condition results.

**Rationale**: Follows the established admin app patterns:
- Pages Router with `AdminLayout` wrapper
- Raw `fetch()` to the API endpoint with `getAuthHeaders()`
- Local `useState` for result, loading, and error states
- `FadeUp` animations for staggered reveal
- Dark futuristic design tokens (`bg-dark-surface1`, `border-dark-border`, `text-accent-cyan`, etc.)

The page has three states:
1. **Initial** — "Run Compliance Check" button, no results
2. **Loading** — Skeleton placeholders for the 5 condition cards
3. **Loaded** — Overall status badge + 5 condition cards with expandable evidence

**Alternatives considered**:
- **Real-time polling / auto-refresh**: Rejected. Compliance is checked on demand per user requirement. No need for automatic re-checking.
- **Separate page per condition**: Rejected. All 5 conditions fit comfortably on one page with expandable cards.
- **Shared component library addition**: Rejected. `ConditionCard` is specific to the compliance dashboard — no need to generalize it into `@iammai-sandbox/shared`.

## R.12: Evidence Display Strategy

**Decision**: Each `ConditionCard` shows the condition label and PASS/FAIL status. On FAIL (or on explicit toggle), the evidence items expand below with type badge, description, and optional session ID. Evidence `details` are shown as formatted key-value pairs.

**Rationale**: The spec requires "specific evidence (session IDs, timestamps, ledger entries) that pinpoint the failure." The expandable pattern keeps the dashboard clean when everything passes while providing full diagnostic detail when something fails.

**Design tokens used**:
- PASS: `text-success` (`#00ff88`) + `shadow-glow-success-subtle`
- FAIL: `text-error` (`#ff3366`) + `shadow-glow-error-subtle`
- COMPLIANT overall: `text-accent-cyan` with `shadow-glow-cyan-medium`
- NON_COMPLIANT overall: `text-error` with `shadow-glow-error-medium`
- ERROR overall: `text-warning` (`#ffaa00`)

## R.13: Navigation Integration

**Decision**: Add a "Compliance" link in `AdminLayout.tsx` navigation bar, after the existing "Sessions" link. Active state detected by `router.pathname.startsWith('/compliance')`.

**Rationale**: Follows the exact pattern of the existing "Sessions" nav link. Minimal change — one `<Link>` element added to the nav bar.
