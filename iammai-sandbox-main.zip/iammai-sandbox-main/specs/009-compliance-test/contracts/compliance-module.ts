/**
 * Contract: Compliance Module Public API
 * Feature 009 — Compliance Test
 *
 * This contract defines the public interface of the compliance-checker module.
 * The module is read-only and produces structured results without modifying system state.
 */

// ============================================================================
// Types (added to backend/src/integrity/types.ts)
// ============================================================================

type ComplianceCondition =
  | 'TRUTH_FINALIZATION'
  | 'DETERMINISTIC_VERIFICATION'
  | 'MANDATORY_SUPPRESSION'
  | 'HISTORY_NON_REGRESSION'
  | 'AUTHORITY_NON_ASSERTION';

type EvidenceType =
  | 'SESSION_REFERENCE'
  | 'LEDGER_ENTRY'
  | 'PRESENCE_RECORD'
  | 'WITNESS_ARTIFACT'
  | 'SUPPRESSION_RECORD'
  | 'PROTOCOL_RESULT'
  | 'SCHEMA_CHECK'
  | 'HASH_CHAIN'
  | 'STATE_TRANSITION'
  | 'ADMIN_ACTION';

interface EvidenceItem {
  type: EvidenceType;
  description: string;
  sessionId?: string;
  details?: Record<string, unknown>;
}

interface ConditionEvaluation {
  condition: ComplianceCondition;
  label: string;
  result: 'PASS' | 'FAIL';
  evidence: EvidenceItem[];
}

interface ComplianceResult {
  overall: 'COMPLIANT' | 'NON_COMPLIANT' | 'ERROR';
  conditions: ConditionEvaluation[];
  executedAt: string;
  systemVersion: string;
  sessionsEvaluated: number;
  error?: string;
}

// ============================================================================
// Module Exports (backend/src/integrity/compliance-checker.ts)
// ============================================================================

/**
 * Run the full compliance check — evaluates all 5 §11 conditions.
 *
 * @returns ComplianceResult with overall determination and per-condition breakdown.
 *
 * Behavior:
 * - Queries only ENDED sessions (FR-013)
 * - Read-only — does not modify any state (FR-015)
 * - Deterministic — same state produces same result (FR-009)
 * - Returns ERROR (not NON_COMPLIANT) on infrastructure failures (FR-014)
 * - Privacy-safe — never accesses message content (FR-016)
 *
 * @example
 * const result = await runComplianceCheck();
 * if (result.overall === 'COMPLIANT') { ... }
 */
declare function runComplianceCheck(): Promise<ComplianceResult>;

/**
 * Run a single compliance condition independently.
 *
 * @param condition - The condition to evaluate
 * @returns ComplianceResult with a single condition in the conditions array.
 *
 * Behavior:
 * - Evaluates only the specified condition (FR-011)
 * - Per-condition result is identical whether run independently or as part of full check (SC-004)
 * - Same error handling as full check
 *
 * @example
 * const result = await runConditionCheck('TRUTH_FINALIZATION');
 * if (result.conditions[0].result === 'PASS') { ... }
 */
declare function runConditionCheck(condition: ComplianceCondition): Promise<ComplianceResult>;

// ============================================================================
// Condition Evaluator Contracts
// ============================================================================

/**
 * Condition 1: Truth Finalization
 *
 * PASS when:
 *   - All ENDED sessions have all presence records finalized (finalized === true)
 *   - No presence record has finalizedAt before the session's endedAt
 *
 * FAIL when:
 *   - Any ENDED session has unfinalized presence records
 *   - Any presence record was finalized before session closure
 *
 * Evidence on FAIL:
 *   - SessionId + presenceRecordId where violation occurred
 *   - Timestamps showing the temporal violation
 */

/**
 * Condition 2: Deterministic Witnessed Verification
 *
 * PASS when:
 *   - Every ENDED session has a VERIFICATION_WITNESS ledger entry
 *   - Re-running verify() with same inputs produces same pass/fail as stored witness
 *
 * FAIL when:
 *   - Any ENDED session lacks a VERIFICATION_WITNESS entry
 *   - Re-verification produces different result than stored witness
 *
 * Evidence on FAIL:
 *   - SessionId missing witness entry
 *   - Mismatch details (expected vs actual result)
 */

/**
 * Condition 3: Mandatory Suppression
 *
 * PASS when:
 *   - Every VERIFICATION_WITNESS with pass_fail='FAIL' has corresponding SUPPRESSION_EVENT(s)
 *   - No mutating ledger entries follow a SUPPRESSION_EVENT for the same session
 *     (except SESSION_CLOSED which is never suppressed)
 *
 * FAIL when:
 *   - A FAIL witness exists without corresponding suppression events
 *   - Mutating actions succeeded after suppression
 *
 * Evidence on FAIL:
 *   - SessionId with FAIL witness but no suppression
 *   - Entry that succeeded after suppression
 */

/**
 * Condition 4: History Non-Regression
 *
 * PASS when:
 *   - Global hash chain validates (validateChain() returns valid)
 *   - All session state transitions are forward-only (CREATED→ACTIVE→ENDED)
 *   - Database triggers trg_integrity_ledger_no_update and trg_integrity_ledger_no_delete exist
 *
 * FAIL when:
 *   - Hash chain has broken links
 *   - Any backward state transition detected in ledger entries
 *   - Protective triggers are missing
 *
 * Evidence on FAIL:
 *   - Broken chain entry sequence number and expected/actual hashes
 *   - Session with backward transition + the specific entries
 *   - Missing trigger name(s)
 */

/**
 * Condition 5: Authority Non-Assertion
 *
 * PASS when:
 *   - No ledger evidence of successful admin overrides after suppression
 *   - All admin actions on suppressed sessions were themselves suppressed
 *
 * FAIL when:
 *   - An admin action succeeded after a SUPPRESSION_EVENT for the same session
 *     (where the action contradicts the suppression reason)
 *
 * Evidence on FAIL:
 *   - SessionId where admin override succeeded
 *   - The suppression event and the subsequent admin action
 */

export type {
  ComplianceResult,
  ConditionEvaluation,
  ComplianceCondition,
  EvidenceItem,
  EvidenceType,
};
