# Tasks: Compliance Test

**Input**: Design documents from `/specs/009-compliance-test/`
**Prerequisites**: plan.md, spec.md, research.md, data-model.md, contracts/

**Tests**: Included. The spec explicitly requires unit tests (compliance-checker.test.ts) and integration tests (active probing for suppression, immutability, authority override).

**Organization**: Tasks grouped by user story. US2-US6 implement the five individual conditions. US1 is the orchestrator. US7+US8 add the API layer. Frontend dashboard delivers visual access.

## Format: `[ID] [P?] [Story] Description`

- **[P]**: Can run in parallel (different files, no dependencies)
- **[Story]**: Which user story this task belongs to (e.g., US1, US2, US3)
- Include exact file paths in descriptions

---

## Phase 1: Setup

**Purpose**: Add new types needed by all subsequent tasks

- [X] T001 Add ComplianceCondition, EvidenceType, EvidenceItem, ConditionEvaluation, and ComplianceResult types to backend/src/integrity/types.ts per the contract in specs/009-compliance-test/contracts/compliance-module.ts

---

## Phase 2: Foundational (Blocking Prerequisites)

**Purpose**: Create module skeleton and test file that all condition implementations build on

**CRITICAL**: No condition implementation can begin until this phase is complete

- [X] T002 Create compliance-checker.ts module skeleton with imports (ledger, presenceTracker, verify, query), helper function to load all ENDED sessions with their ledger entries and presence records, and exported function stubs for runComplianceCheck() and runConditionCheck() in backend/src/integrity/compliance-checker.ts
- [X] T003 [P] Create compliance-checker.test.ts test file skeleton with describe blocks for each of the 5 condition evaluators plus the orchestrator, using vitest mocks for ledger, presenceTracker, verify, and query in backend/tests/unit/integrity/compliance-checker.test.ts

**Checkpoint**: Module skeleton and test skeleton ready — condition implementation can begin

---

## Phase 3: User Story 2 — Truth Finalization Condition (Priority: P1)

**Goal**: Validate that presence finalizes only in closed events — no premature finalization, all records finalized after session ENDED

**Independent Test**: Run evaluateTruthFinalization() against sessions with correct and incorrect finalization timing, confirm PASS/FAIL

### Implementation

- [X] T004 [US2] Implement evaluateTruthFinalization() that iterates ENDED sessions, checks all presence records are finalized (finalized === true) and no record has finalized_at before session ended_at, returns ConditionEvaluation with PASS/FAIL and evidence in backend/src/integrity/compliance-checker.ts
- [X] T005 [US2] Write unit tests for truth finalization: (1) PASS when all records finalized after closure, (2) FAIL when unfinalized records exist on ENDED session, (3) FAIL when finalized_at precedes ended_at, (4) vacuous PASS when no ENDED sessions exist in backend/tests/unit/integrity/compliance-checker.test.ts

**Checkpoint**: Truth finalization condition independently testable

---

## Phase 4: User Story 3 — Deterministic Witnessed Verification Condition (Priority: P1)

**Goal**: Validate that verification is deterministic (same inputs produce same outputs) and every closed session has a VERIFICATION_WITNESS ledger entry

**Independent Test**: Run evaluateDeterministicVerification() against sessions with/without witness entries and with deterministic/non-deterministic verify() results

### Implementation

- [X] T006 [US3] Implement evaluateDeterministicVerification() that checks every ENDED session has a VERIFICATION_WITNESS entry in the ledger, and re-runs verify() for a sample of sessions to confirm results match stored witness artifacts in backend/src/integrity/compliance-checker.ts
- [X] T007 [US3] Write unit tests for deterministic verification: (1) PASS when all sessions have witness entries and re-verification matches, (2) FAIL when a session lacks VERIFICATION_WITNESS entry, (3) FAIL when re-verification produces different result than stored witness, (4) vacuous PASS when no ENDED sessions in backend/tests/unit/integrity/compliance-checker.test.ts

**Checkpoint**: Deterministic verification condition independently testable

---

## Phase 5: User Story 4 — Mandatory Suppression Condition (Priority: P1)

**Goal**: Validate that every verification FAIL has corresponding suppression events and no mutating actions succeeded after suppression

**Independent Test**: Run evaluateMandatorySuppression() against ledger data with/without proper suppression records. Integration test actively triggers FAIL and attempts post-failure mutations.

### Implementation

- [X] T008 [US4] Implement evaluateMandatorySuppression() that finds all VERIFICATION_WITNESS entries with pass_fail='FAIL', checks each has corresponding SUPPRESSION_EVENT(s), and verifies no mutating ledger entries follow the suppression (excluding SESSION_CLOSED) in backend/src/integrity/compliance-checker.ts
- [X] T009 [US4] Write unit tests for mandatory suppression: (1) PASS when all FAILs have suppression events and no post-suppression mutations, (2) FAIL when FAIL witness has no suppression event, (3) FAIL when mutating action succeeded after suppression, (4) vacuous PASS when no FAIL witnesses exist in backend/tests/unit/integrity/compliance-checker.test.ts
- [X] T010 [P] [US4] Create active probing integration test that triggers a verification FAIL via mock, attempts subsequent mutating actions, and confirms they are suppressed with SUPPRESSION_EVENT recorded in backend/tests/integration/integrity/compliance-suppression-enforcement.test.ts

**Checkpoint**: Mandatory suppression condition + active probing independently testable

---

## Phase 6: User Story 5 — History Non-Regression Condition (Priority: P1)

**Goal**: Validate that the integrity ledger is append-only (hash chain intact), state transitions are forward-only, and protective DB triggers exist

**Independent Test**: Run evaluateHistoryNonRegression() against valid/tampered ledger data and with/without triggers. Integration test attempts DELETE/UPDATE on ledger.

### Implementation

- [X] T011 [US5] Implement evaluateHistoryNonRegression() that calls ledger.validateChain() for hash chain integrity, examines session state transitions in ledger entries for forward-only progression (CREATED->ACTIVE->ENDED), and queries pg_trigger/pg_class to confirm trg_integrity_ledger_no_update and trg_integrity_ledger_no_delete exist in backend/src/integrity/compliance-checker.ts
- [X] T012 [US5] Write unit tests for history non-regression: (1) PASS when chain valid + transitions forward-only + triggers exist, (2) FAIL when hash chain broken, (3) FAIL when backward state transition detected, (4) FAIL when protective triggers missing in backend/tests/unit/integrity/compliance-checker.test.ts
- [X] T013 [P] [US5] Create active probing integration test that attempts DELETE and UPDATE on integrity_ledger table (confirms trigger blocks them) and attempts backward state transition ENDED->ACTIVE (confirms state observer rejects it) in backend/tests/integration/integrity/compliance-history-immutability.test.ts

**Checkpoint**: History non-regression condition + active probing independently testable

---

## Phase 7: User Story 6 — Authority Non-Assertion Condition (Priority: P1)

**Goal**: Validate that no admin override succeeded after suppression — all admin override attempts were themselves suppressed

**Independent Test**: Run evaluateAuthorityNonAssertion() against ledger data with/without admin override attempts. Integration test simulates admin override on suppressed session.

### Implementation

- [X] T014 [US6] Implement evaluateAuthorityNonAssertion() that examines ledger entries for admin actions following SUPPRESSION_EVENT entries on the same session, confirms all such admin actions were themselves suppressed (recorded as further SUPPRESSION_EVENTs), and allows non-conflicting admin operations (session creation, token generation) in backend/src/integrity/compliance-checker.ts
- [X] T015 [US6] Write unit tests for authority non-assertion: (1) PASS when no override attempts exist, (2) PASS when override attempted but suppressed, (3) FAIL when admin action succeeded after suppression, (4) PASS when normal admin actions (non-conflicting) proceed without suppression in backend/tests/unit/integrity/compliance-checker.test.ts
- [X] T016 [P] [US6] Create active probing integration test that simulates an admin issuing an override command on a suppressed session, confirms the override is itself suppressed and recorded with the admin's presence hash and the blocking protocol in backend/tests/integration/integrity/compliance-authority-override.test.ts

**Checkpoint**: Authority non-assertion condition + active probing independently testable

---

## Phase 8: User Story 1 — Binary Compliance Determination (Priority: P1) MVP

**Goal**: Orchestrate all 5 conditions into a single COMPLIANT/NON_COMPLIANT/ERROR result with per-condition breakdown, evidence, timestamp, and system version

**Independent Test**: Run runComplianceCheck() on a fully compliant system (expect COMPLIANT), then with one condition failing (expect NON_COMPLIANT), then with DB error (expect ERROR)

### Implementation

- [X] T017 [US1] Complete runComplianceCheck() orchestrator that executes all 5 condition evaluators, aggregates results (COMPLIANT iff all PASS, NON_COMPLIANT if any FAIL), catches infrastructure errors and returns ERROR with error message, populates executedAt timestamp and systemVersion in backend/src/integrity/compliance-checker.ts
- [X] T018 [US1] Complete runConditionCheck(condition) that executes a single specified condition and returns ComplianceResult with one element in conditions array, overall reflecting that single condition's result in backend/src/integrity/compliance-checker.ts
- [X] T019 [US1] Write orchestrator unit tests: (1) all conditions PASS returns COMPLIANT, (2) single condition FAIL returns NON_COMPLIANT with failing condition identified, (3) infrastructure error returns ERROR with error message, (4) empty system returns COMPLIANT, (5) determinism — same mock state produces identical results on repeated runs, (6) runConditionCheck returns same result as corresponding condition in full run in backend/tests/unit/integrity/compliance-checker.test.ts

**Checkpoint**: Full compliance module complete and all unit tests pass. Binary determination verified.

---

## Phase 9: User Story 7 + User Story 8 — API Endpoint (Priority: P2)

**Goal**: Expose compliance module via admin-authenticated REST endpoint with full and per-condition check support

**Independent Test**: Call GET /api/v1/admin/compliance with admin token (expect ComplianceResult JSON), call with ?condition=TRUTH_FINALIZATION (expect single-condition result), call with invalid condition (expect 400), call without auth (expect 401)

### Implementation

- [X] T020 [US7] Create compliance API route file with GET handler behind requireAdmin middleware that calls runComplianceCheck() and returns ComplianceResult as JSON (200 on success, 500 on ERROR result) in backend/src/api/routes/compliance.ts
- [X] T021 [US8] Add optional condition query parameter handling — validate against ComplianceCondition values (return 400 INVALID_CONDITION for invalid values), call runConditionCheck(condition) when parameter present in backend/src/api/routes/compliance.ts
- [X] T022 [US7] Register compliance router in the Express app at /api/v1/admin/compliance by importing and mounting in the route setup file alongside existing admin routes

**Checkpoint**: API endpoint functional — full check and per-condition check available via HTTP

---

## Phase 10: Frontend Dashboard

**Goal**: Provide visual admin dashboard for on-demand compliance checking with per-condition expandable results

**Independent Test**: Navigate to /compliance in admin panel, click Run Compliance Check, verify results display with PASS/FAIL indicators and expandable evidence

### Implementation

- [X] T023 [P] [US7] Create ConditionCard component with condition label, PASS/FAIL status badge (text-success for PASS, text-error for FAIL), expandable evidence section with EvidenceItem rendering (type badge, description, sessionId, formatted details), using Framer Motion for expand/collapse animation in frontend/apps/admin/src/components/ConditionCard.tsx
- [X] T024 [US7] Create compliance dashboard page wrapped in AdminLayout with: (1) "Run Compliance Check" button, (2) loading state with 5 skeleton cards, (3) overall status badge (COMPLIANT=text-accent-cyan, NON_COMPLIANT=text-error, ERROR=text-warning), (4) grid of 5 ConditionCards, (5) error handling for fetch failures, using fetch with getAuthHeaders() to call GET /api/v1/admin/compliance in frontend/apps/admin/src/pages/compliance/index.tsx
- [X] T025 [US7] Add "Compliance" navigation link after the existing "Sessions" link in the nav bar with active state detected by router.pathname.startsWith('/compliance') in frontend/apps/admin/src/components/AdminLayout.tsx

**Checkpoint**: Full admin dashboard functional — can trigger checks and view results visually

---

## Phase 11: Polish & Cross-Cutting Concerns

**Purpose**: Final validation across all stories

- [X] T026 Run all compliance unit tests (npx vitest run tests/unit/integrity/compliance-checker.test.ts) and verify all pass
- [X] T027 Run all compliance integration tests (npx vitest run tests/integration/integrity/compliance-*.test.ts) and verify all pass
- [X] T028 Validate edge cases from spec: empty system returns COMPLIANT, active sessions are excluded, infrastructure errors produce ERROR not NON_COMPLIANT, acedia force-released sessions are included in evaluation

---

## Dependencies & Execution Order

### Phase Dependencies

- **Setup (Phase 1)**: No dependencies — start immediately
- **Foundational (Phase 2)**: Depends on Phase 1 (types must exist) — BLOCKS all conditions
- **Conditions (Phases 3-7)**: All depend on Phase 2. Can proceed sequentially (US2→US3→US4→US5→US6) or in parallel for integration tests
- **Orchestrator (Phase 8)**: Depends on ALL conditions (Phases 3-7) being complete
- **API Endpoint (Phase 9)**: Depends on Phase 8 (orchestrator must be complete)
- **Frontend (Phase 10)**: Depends on Phase 9 (API endpoint must exist)
- **Polish (Phase 11)**: Depends on all previous phases

### User Story Dependencies

- **US2 (Truth Finalization)**: After Foundational — no dependencies on other stories
- **US3 (Deterministic Verification)**: After Foundational — no dependencies on other stories
- **US4 (Mandatory Suppression)**: After Foundational — no dependencies on other stories
- **US5 (History Non-Regression)**: After Foundational — no dependencies on other stories
- **US6 (Authority Non-Assertion)**: After Foundational — no dependencies on other stories
- **US1 (Binary Determination)**: After US2-US6 complete (orchestrator needs all conditions)
- **US7 (Automated Execution)**: After US1 (needs orchestrator for API endpoint)
- **US8 (Per-Condition Testing)**: After US1 (needs runConditionCheck for API parameter)

### Within Each Condition Phase

- Implementation before unit tests (tests reference the implementation)
- Unit tests and integration tests can run in parallel (different files)

### Parallel Opportunities

- T002 + T003 can run in parallel (compliance-checker.ts + test file = different files)
- Integration tests T010, T013, T016 are in separate files and can be written in parallel
- T023 (ConditionCard) can run in parallel with T020-T022 (frontend vs backend)
- Conditions US2-US6 could theoretically run in parallel (different functions) but share one file, so sequential is safer

---

## Parallel Example: Phase 5 (US4 - Mandatory Suppression)

```bash
# After T008 (suppression evaluator) and T009 (unit tests) complete:
# T010 (integration test) is [P] — different file, can overlap with Phase 6 start

Task: "T010 Create active probing integration test in compliance-suppression-enforcement.test.ts"
Task: "T011 Implement evaluateHistoryNonRegression() in compliance-checker.ts"
# These touch different files and have no dependency
```

## Parallel Example: Phase 10 (Frontend)

```bash
# T023 is [P] — ConditionCard is a standalone component
Task: "T023 Create ConditionCard component in ConditionCard.tsx"
Task: "T020 Create compliance API route in compliance.ts"
# Frontend component and backend route are completely independent
```

---

## Implementation Strategy

### MVP First (User Story 1 = Binary Compliance Determination)

1. Complete Phase 1: Setup (types)
2. Complete Phase 2: Foundational (module skeleton)
3. Complete Phases 3-7: All 5 conditions (US2-US6)
4. Complete Phase 8: Orchestrator (US1)
5. **STOP and VALIDATE**: Run unit tests, verify COMPLIANT on correct system, NON_COMPLIANT on violations
6. This gives you the complete compliance module — usable programmatically

### Incremental Delivery

1. Setup + Foundational + Conditions + Orchestrator → Module ready (programmatic use)
2. Add API Endpoint (Phase 9) → HTTP access for CI and tools
3. Add Frontend Dashboard (Phase 10) → Visual admin access
4. Each increment adds value without breaking previous work

### Sequential Implementation (Recommended)

Since all conditions share one file (compliance-checker.ts ~250 lines total):
1. Implement conditions sequentially: US2 → US3 → US4 → US5 → US6
2. Each condition adds ~30-60 lines
3. Integration tests [P] can overlap with next condition
4. After all conditions: orchestrator → API → frontend → polish

---

## Notes

- All backend code is in `backend/src/integrity/compliance-checker.ts` (~250 lines total)
- API route is in `backend/src/api/routes/compliance.ts` (~40 lines)
- The compliance module is READ-ONLY — no INSERT, UPDATE, or DELETE operations
- Active probing (attempting violations) is ONLY in integration test files, never in the module
- Privacy boundary: EvidenceItem.details contains only IDs, timestamps, hash values — never message content
- Edge cases: empty system → COMPLIANT, active sessions → excluded, DB errors → ERROR (not NON_COMPLIANT)
- [P] tasks = different files, no dependencies
- [Story] label maps task to specific user story for traceability
- Commit after each phase or logical group
