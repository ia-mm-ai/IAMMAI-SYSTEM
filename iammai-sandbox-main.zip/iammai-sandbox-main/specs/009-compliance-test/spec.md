# Feature Specification: Compliance Test

**Feature Branch**: `009-compliance-test`
**Created**: 2026-02-18
**Status**: Draft
**Input**: User description: "Feature 009: Compliance Test (Phase 5) — MM-MODEL §11 binary compliance validation of the complete integrity layer"

## User Scenarios & Testing *(mandatory)*

### User Story 1 - Binary Compliance Determination (Priority: P1)

An operator runs the compliance test against the system and receives a definitive COMPLIANT or NON-COMPLIANT result. The test evaluates all five conditions from MM-MODEL §11 independently and produces a final binary determination. If any single condition fails, the overall result is NON-COMPLIANT. The operator sees the per-condition breakdown alongside the overall result so they can identify which specific area is failing.

**Why this priority**: This is the core purpose of the feature — without a binary compliance determination, the system cannot prove it satisfies the framework. Every other user story supports or extends this capability.

**Independent Test**: Can be verified by running the compliance test against a properly configured system and confirming a COMPLIANT result, then deliberately introducing a violation and confirming NON-COMPLIANT.

**Acceptance Scenarios**:

1. **Given** a system where all integrity layer features (005-008) are operational and correctly configured, **When** the compliance test runs, **Then** it produces a COMPLIANT result with all five conditions marked PASS.
2. **Given** a system where any single condition is violated (e.g., truth finalization occurs without presence), **When** the compliance test runs, **Then** it produces NON-COMPLIANT with the failing condition(s) clearly identified.
3. **Given** a compliance test execution, **When** the result is returned, **Then** it includes: the overall binary result, per-condition PASS/FAIL with descriptive labels, evidence supporting each evaluation, and a timestamp of the test execution.
4. **Given** the same system state, **When** the compliance test is run multiple times, **Then** it produces identical results every time (deterministic).

---

### User Story 2 - Truth Finalization Condition (Priority: P1)

The compliance test validates that truth (presence) finalizes only via presence in closed events. No presence record may be finalized while a session is still ACTIVE. All presence records must be finalized after the session transitions to ENDED. This verifies that the system correctly enforces the temporal constraint between session closure and truth finalization.

**Why this priority**: This is the first of five mandatory conditions. Truth finalization is the foundation of the framework — if presence can be finalized prematurely, all subsequent verification and witness emission is built on unreliable data.

**Independent Test**: Can be verified by examining presence records across multiple sessions and confirming that no finalization occurred before session closure, and all finalizations occurred after.

**Acceptance Scenarios**:

1. **Given** a session that has been properly closed (state=ENDED), **When** the truth finalization condition is evaluated, **Then** it produces PASS if all presence records were finalized only after the session reached ENDED state.
2. **Given** a session where presence was finalized while the session was still ACTIVE, **When** the truth finalization condition is evaluated, **Then** it produces FAIL with evidence pointing to the premature finalization.
3. **Given** a session where presence records exist but none are finalized despite the session being ENDED, **When** the truth finalization condition is evaluated, **Then** it produces FAIL because finalization did not occur.

---

### User Story 3 - Deterministic Witnessed Verification Condition (Priority: P1)

The compliance test validates that verification is deterministic and witnessed. Given the same session data (ledger entries, presence records, admin actions), the verification engine always produces the same PASS/FAIL outcome. Additionally, every verification execution results in a witness artifact being stored in the integrity ledger.

**Why this priority**: Determinism and witnessing are inseparable requirements — a non-deterministic system cannot be audited, and unwitnessed verification cannot be proven to have occurred.

**Independent Test**: Can be verified by running verification twice against the same session data and confirming identical results, and by confirming a VERIFICATION_WITNESS entry exists in the ledger for every closed session.

**Acceptance Scenarios**:

1. **Given** a closed session with complete ledger entries and presence data, **When** verification is run twice with the same inputs, **Then** both executions produce identical PASS/FAIL results and identical protocol-level details.
2. **Given** any closed session, **When** the ledger is inspected, **Then** a VERIFICATION_WITNESS entry exists for that session.
3. **Given** a session where verification was executed, **When** the witness artifact is inspected, **Then** it contains all required fields (artifact type, version, protocol results, timestamp, presence summary, pass/fail determination).

---

### User Story 4 - Mandatory Suppression Condition (Priority: P1)

The compliance test validates that suppression is mandatory and enforced. When verification produces FAIL, the system must halt execution, prevent mutation, block downstream operations, and record the suppression event. No mechanism exists to bypass suppression — not admin authority, not system override.

The read-only compliance module validates this by examining suppression records in the ledger: confirming that every verification FAIL has corresponding suppression events, and that no mutating actions succeeded after a FAIL. Separate automated integration tests actively trigger verification failures and attempt post-failure mutations to prove enforcement works.

**Why this priority**: Suppression enforcement is what gives verification teeth — without it, FAIL results are advisory rather than binding, and the integrity layer becomes decorative.

**Independent Test**: The compliance module can be verified by examining ledger records for suppression consistency. The integration tests can be verified by triggering FAIL and confirming subsequent operations are blocked.

**Acceptance Scenarios**:

*Compliance module (read-only audit):*

1. **Given** closed sessions where verification produced FAIL, **When** the ledger is examined, **Then** corresponding suppression events exist for every FAIL result.
2. **Given** suppression events in the ledger, **When** subsequent ledger entries for the same session are examined, **Then** no mutating actions succeeded after the suppression.
3. **Given** a suppression event, **When** the ledger is inspected, **Then** the event includes the action that was suppressed, the reason for suppression, and the agent that attempted the action.

*Integration tests (active probing):*

4. **Given** a session where verification produced FAIL, **When** any subsequent mutating action is attempted, **Then** the action is suppressed and a suppression event is recorded.
5. **Given** an admin with full system authority, **When** they attempt to override a suppression, **Then** the override attempt is itself suppressed and recorded (protocol supremacy).

---

### User Story 5 - History Non-Regression Condition (Priority: P1)

The compliance test validates that history never regresses. The integrity ledger is append-only — no entries can be modified or deleted. State transitions are forward-only — no session can revert to a previous state. The hash chain ensures tamper detection if any entry is altered outside the system.

The read-only compliance module validates this condition by examining existing data: verifying hash chain integrity across all ledger entries, confirming monotonic state transitions in session history, and checking that protective database triggers exist. Separate automated integration tests actively exercise violations (attempting DELETE, UPDATE, and backward transitions) to prove the protective mechanisms work.

**Why this priority**: Non-regression is the structural guarantee that makes all other conditions meaningful — if history can be rewritten, verification results, witness artifacts, and suppression records are all unreliable.

**Independent Test**: The compliance module can be verified by examining ledger entries for hash chain integrity and session records for monotonic transitions. The integration tests can be verified by attempting destructive operations and confirming they are blocked.

**Acceptance Scenarios**:

*Compliance module (read-only audit):*

1. **Given** a sequence of ledger entries, **When** the hash chain is validated, **Then** validation confirms integrity (no gaps, no altered hashes).
2. **Given** session history records, **When** state transitions are examined, **Then** all transitions are forward-only (no regressions detected).
3. **Given** the database schema, **When** protective triggers are inspected, **Then** BEFORE UPDATE and BEFORE DELETE triggers exist on the integrity_ledger table.

*Integration tests (active probing):*

4. **Given** an existing ledger entry, **When** a DELETE operation is attempted on the integrity_ledger table, **Then** the operation is blocked by the database trigger.
5. **Given** an existing ledger entry, **When** an UPDATE operation is attempted on the integrity_ledger table, **Then** the operation is blocked by the database trigger.
6. **Given** a session in ENDED state, **When** a transition to ACTIVE is attempted, **Then** the transition is rejected by the state observer.

---

### User Story 6 - Authority Non-Assertion Condition (Priority: P1)

The compliance test validates that authority is never asserted — no admin, regardless of their access level, can override protocol verification or bypass suppression enforcement. Admin commands that contradict protocol results are themselves subject to suppression. Authority flows from the protocol, not from the person.

The read-only compliance module validates this by examining the ledger for any admin override attempts and confirming they were all suppressed — no successful overrides exist. Separate automated integration tests actively simulate admin override attempts to prove the enforcement mechanism works.

**Why this priority**: If authority can override protocols, the entire framework collapses to a permissions-based system rather than a verification-based one. This is the governance capstone.

**Independent Test**: The compliance module can be verified by examining the ledger for admin override records and confirming all were suppressed. The integration tests can be verified by simulating override attempts and confirming they are blocked.

**Acceptance Scenarios**:

*Compliance module (read-only audit):*

1. **Given** suppression events involving admin actions, **When** the ledger is examined, **Then** every admin override attempt was suppressed and recorded — no successful overrides exist.
2. **Given** admin actions in the ledger, **When** non-conflicting operations are examined (session creation, token generation), **Then** they proceeded normally without suppression.

*Integration tests (active probing):*

3. **Given** a session where verification produced FAIL and suppression is active, **When** an admin issues a command that would override the suppression, **Then** the override is suppressed and recorded as a protocol violation.
4. **Given** a session where admin attempted to override verification results, **When** the ledger is inspected, **Then** the override attempt is recorded with the admin's anonymous presence hash, the attempted action, and the protocol that blocked it.

---

### User Story 7 - Automated and Repeatable Execution (Priority: P2)

The compliance test can be run automatically as part of a continuous integration pipeline. It requires no manual intervention, produces machine-readable output alongside human-readable output, and completes within a bounded time. Failed conditions include enough evidence for developers to diagnose the specific issue.

**Why this priority**: Manual compliance testing is error-prone and doesn't scale. Automated execution ensures compliance is continuously validated, not just checked once at deployment.

**Independent Test**: Can be verified by running the compliance test in a headless environment and confirming it completes without human input and produces structured output.

**Acceptance Scenarios**:

1. **Given** a properly configured system, **When** the compliance test is invoked programmatically, **Then** it runs to completion without manual input and returns structured results.
2. **Given** a failing condition, **When** the compliance test completes, **Then** the output includes specific evidence (session IDs, timestamps, ledger entries) that pinpoint the failure.
3. **Given** a CI pipeline, **When** the compliance test is added as a step, **Then** it produces a clear pass/fail exit status suitable for build gating.

---

### User Story 8 - Per-Condition Independent Testing (Priority: P2)

Each of the five compliance conditions can be tested independently. An operator can run a single condition check (e.g., only "history never regresses") without executing the full compliance suite. This enables targeted investigation when a specific condition fails and allows incremental validation during development.

**Why this priority**: During development and debugging, running all five conditions is often unnecessary. Independent condition testing accelerates the feedback loop and makes compliance test development itself more manageable.

**Independent Test**: Can be verified by invoking a single condition check and confirming it evaluates only that condition without dependencies on the others.

**Acceptance Scenarios**:

1. **Given** an operator selects a single condition to test (e.g., "truth finalization"), **When** the test runs, **Then** only that condition is evaluated and the result reflects only that condition's status.
2. **Given** all five conditions are run independently, **When** their results are compared to a full compliance run, **Then** the per-condition results are identical in both modes.

---

### Edge Cases

- What happens when no sessions exist in the system? The compliance test reports COMPLIANT — the conditions are vacuously satisfied when there is no data to violate them.
- What happens when the compliance test is run against a system with features 005-007 complete but 008 (governance) incomplete? The test reports NON-COMPLIANT for conditions that depend on governance protocols, with evidence explaining which protocols are missing.
- What happens when the database is unreachable during the compliance test? The test fails with an infrastructure error, not a NON-COMPLIANT result — inability to evaluate is distinct from evaluation failure.
- What happens when a session is currently in-progress (ACTIVE) during the compliance test? The test evaluates only closed sessions — in-progress sessions are excluded since their lifecycle is incomplete and cannot yet satisfy or violate conditions.
- What happens when the compliance test itself encounters an unexpected error mid-evaluation? The test reports an error state distinct from COMPLIANT/NON-COMPLIANT, ensuring that partial evaluation is never presented as a complete result.
- What happens when ledger entries exist but the hash chain has been externally tampered with? The "history never regresses" condition detects the tampering and produces FAIL with evidence of the broken chain link.
- What happens when a session was force-released due to acedia? The session is included in evaluation — acedia force-release is a valid session closure mechanism and the session should still satisfy all applicable conditions.

## Requirements *(mandatory)*

### Functional Requirements

- **FR-001**: The system MUST provide a compliance test that produces a binary COMPLIANT or NON-COMPLIANT result based on evaluation of all five MM-MODEL §11 conditions.
- **FR-002**: The system MUST evaluate each of the five conditions independently and report per-condition PASS/FAIL results alongside the overall determination.
- **FR-003**: Condition 1 (Truth Finalization) MUST verify that no presence record is finalized while its session is in a state other than ENDED, and that all presence records for closed sessions are finalized.
- **FR-004**: Condition 2 (Deterministic Verification) MUST verify that running verification with the same inputs produces identical outputs, and that a VERIFICATION_WITNESS ledger entry exists for every closed session.
- **FR-005**: Condition 3 (Mandatory Suppression) MUST verify that verification FAIL results block subsequent mutating actions, that suppression events are recorded, and that no bypass mechanism succeeds.
- **FR-006**: Condition 4 (History Non-Regression) MUST verify that ledger entries cannot be modified or deleted, that state transitions are forward-only, and that the hash chain is intact.
- **FR-007**: Condition 5 (Authority Non-Assertion) MUST verify that admin commands that contradict protocol results are suppressed and recorded, with no successful overrides.
- **FR-008**: The overall result MUST be COMPLIANT only when all five conditions produce PASS. If any condition produces FAIL, the overall result MUST be NON-COMPLIANT.
- **FR-009**: The compliance test MUST be deterministic — identical system state produces identical results on every execution.
- **FR-010**: The compliance test MUST run without manual intervention and produce both human-readable and machine-readable output.
- **FR-011**: Each condition MUST be independently executable — an operator can test a single condition without running the others.
- **FR-012**: Failed conditions MUST include evidence: specific session IDs, timestamps, ledger entries, or protocol results that demonstrate the violation.
- **FR-013**: The compliance test MUST evaluate only closed sessions (state=ENDED) — in-progress sessions are excluded from evaluation.
- **FR-014**: Infrastructure errors (database unreachable, unexpected exceptions) MUST produce an error state distinct from COMPLIANT or NON-COMPLIANT.
- **FR-015**: The compliance test module MUST NOT modify any system state — it is a read-only audit of existing records and configuration. Active probing of enforcement mechanisms (attempting violations to confirm they are blocked) is the responsibility of separate automated integration tests, not the compliance module itself.
- **FR-016**: The compliance test MUST respect the privacy boundary — it evaluates metadata only and never accesses or reports message content or personal data.
- **FR-017**: The compliance test MUST produce a structured result containing: overall result, per-condition results, evidence for each condition, execution timestamp, and system version.

### Key Entities

- **Compliance Result**: The top-level output of a compliance test run — contains the binary overall determination (COMPLIANT/NON-COMPLIANT), an array of per-condition evaluations, execution metadata (timestamp, system version), and an error state if evaluation could not complete.
- **Condition Evaluation**: The result of evaluating a single §11 condition — contains the condition identifier, human-readable label, binary PASS/FAIL result, and an array of evidence items supporting the determination.
- **Evidence Item**: A specific data point supporting a condition evaluation — includes the type of evidence (session reference, ledger entry, protocol result, suppression record), a description of what it demonstrates, and the relevant identifiers.

## Success Criteria *(mandatory)*

### Measurable Outcomes

- **SC-001**: 100% of compliance test executions against a correctly configured system produce COMPLIANT.
- **SC-002**: 100% of compliance test executions against a system with any single deliberate violation produce NON-COMPLIANT with the specific failing condition identified.
- **SC-003**: The compliance test produces identical results when run multiple times against the same system state (100% determinism).
- **SC-004**: Each of the five conditions is independently testable and produces results identical to the corresponding condition in a full compliance run.
- **SC-005**: The compliance test runs to completion without manual intervention in an automated environment.
- **SC-006**: 100% of failed conditions include at least one evidence item with specific identifiers enabling diagnosis.
- **SC-007**: 0% of compliance test output contains message content, personal data, or conversation details.
- **SC-008**: Infrastructure errors are correctly distinguished from compliance failures — 0% of infrastructure errors produce COMPLIANT or NON-COMPLIANT results.

## Clarifications

### Session 2026-02-18

- Q: Does the compliance test validate conditions by actively probing the system (attempting violations) or by passively auditing existing state? → A: Dual approach — a read-only compliance module audits existing records and configuration (production-safe), plus separate vitest integration tests actively exercise violations to prove enforcement mechanisms work. The compliance result comes from the module; the integration tests prove the module's conditions hold.

## Assumptions

- Features 005 (Structural Foundation), 006 (Verification + Witness), 007 (Presence + Suppression), and 008 (Governance Protocols) are all complete and operational before this feature begins.
- The integrity ledger, verification engine, witness emitter, presence tracker, suppression engine, acedia monitor, co-agency tracker, and all ten protocol evaluators (I.01-I.10) are available and functional.
- Database protective triggers (BEFORE UPDATE, BEFORE DELETE on integrity_ledger) are in place from feature 005.
- The state observer rejects backward state transitions from feature 005.
- The suppression engine blocks mutating actions on FAIL from feature 007.
- Acedia thresholds, co-agency limits, and identity formula are as defined in Framework Decisions 4, 6, and 7.
- The compliance test evaluates the same session data that the verification engine and protocol evaluators use — it does not create separate test fixtures but rather validates the actual system state.

## Dependencies

- **005-structural-foundation**: Ledger service, state observer, hash chain, boundary enforcement, database triggers.
- **006-verification-witness**: Verification engine, witness emitter, protocol evaluator interface, protocols I.02-I.04.
- **007-presence-suppression**: Presence tracker, suppression engine, protocols I.01, I.05, I.08.
- **008-governance-protocols**: Acedia monitor, co-agency tracker, protocols I.06, I.07, I.09, I.10.
