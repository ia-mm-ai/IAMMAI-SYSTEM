# IAMMAI Sandbox Framework Implementation Decisions

> **Purpose**: Document every gap-filling implementation decision where the MM-MODEL specification is ambiguous, incomplete, or contradictory. Each decision records what was chosen, why, and how it traces back to the framework.
>
> **Framework Version**: MM-MODEL (Execution-Ready, Implementation-Agnostic, Protocol-Bound, Post-Freeze)
> **Protocol Library**: event.limited I.01-I.10 (SHA256-pinned, immutable)
> **Created**: 2026-02-13
> **Last Amended**: 2026-02-13
> **IAMMAI Sandbox Feature**: 004-framework-decisions

---

## Table of Contents

1. [Event Interface Field Types](#decision-1-event-interface-field-types)
2. [State Space Mapping](#decision-2-state-space-mapping)
3. [Presence Model](#decision-3-presence-model)
4. [Identity Formula](#decision-4-identity-formula)
5. [Signal Coherence Criteria](#decision-5-signal-coherence-criteria)
6. [Acedia Thresholds](#decision-6-acedia-thresholds)
7. [Co-Agency Balance Metric](#decision-7-co-agency-balance-metric)
8. [Verification Dispatch Model](#decision-8-verification-dispatch-model)
9. [Witness Artifact Format](#decision-9-witness-artifact-format)
10. [Privacy Boundary](#decision-10-privacy-boundary)

---

## Decision 1: Event Interface Field Types

**MM-MODEL Reference**: §2.1 — Event Interface

**Gap**: Event fields are named but untyped. `event_id` has no specified format. `context_descriptor` and `environmental_constraints` have no type, structure, or validation rule. A machine cannot construct or validate an Event without making assumptions.

**Review Finding**: MM-MODEL-REVIEW.md §1 — "event_id has no specified format. A machine reading this specification cannot construct or validate an Event without making assumptions."

**Decision**:

| Field | Type | Constraints |
|-------|------|-------------|
| `event_id` | UUID v4 | Maps to existing `session_id` in IAMMAI Sandbox |
| `t_open` | ISO 8601 UTC string | `YYYY-MM-DDTHH:mm:ss.sssZ` |
| `t_close` | ISO 8601 UTC string | Must be > `t_open`; required per §2.1 |
| `context_descriptor` | JSON object | `{ topic: string, purpose?: string }` |
| `environmental_constraints` | JSON object | `{ max_participants: number, time_limit_minutes?: number, ai_model?: string }` |
| `status` | Enum | `OPEN \| CLOSED` (see Decision 2 for mapping) |

**IAMMAI Sandbox Rationale**: UUID v4 aligns with the existing session model (`backend/src/lib/types.ts`). ISO 8601 is the universal timestamp standard and already used in session creation. JSON schemas for descriptors give structure while remaining flexible — these match the existing IAMMAI Sandbox session fields declared at session creation time.

**Alternatives Rejected**:
- Auto-incrementing integer IDs — no global uniqueness guarantee across distributed systems
- Unix epoch timestamps — less human-readable, violates Future Interpretability (I.10)
- Free-text descriptors — not machine-evaluable, violates deterministic verification (§3.1)

**Implementing Feature**: 005-structural-foundation

---

## Decision 2: State Space Mapping

**MM-MODEL Reference**: §2.1 — `status ∈ {OPEN, CLOSED}`

**Gap**: MM-MODEL defines a binary status. IAMMAI Sandbox has three session states: `CREATED`, `ACTIVE`, `ENDED`. No mapping is provided between these state spaces.

**Review Finding**: MM-MODEL-REVIEW.md §1 — The document is clear on binary status but does not address systems with intermediate states.

**Decision**:

| IAMMAI Sandbox State | Framework Status | Integrity Behavior |
|-----------|-----------------|-------------------|
| `CREATED` | `OPEN` | No truth finalization; no witness emission |
| `ACTIVE` | `OPEN` | No truth finalization; no witness emission |
| `ENDED` | `CLOSED` | Truth finalization permitted; verification runs; witness emitted |

The integrity layer treats any non-`ENDED` session as `OPEN` for all protocol purposes.

**IAMMAI Sandbox Rationale**: The framework's OPEN/CLOSED distinction is about whether truth finalization can occur (§2.1: "No truth finalization may reference an OPEN event"). In IAMMAI Sandbox, truth finalization (witness emission, verification) must not happen until a session reaches `ENDED`. Both `CREATED` and `ACTIVE` are pre-finalization states, making them semantically equivalent to `OPEN`. No protocol behavior differs between `CREATED` and `ACTIVE` from an integrity perspective.

**Alternatives Rejected**:
- Three-state model with `CREATED` as a separate pre-OPEN state — framework explicitly uses binary status; adding a third framework state contradicts §2.1

**Implementing Feature**: 005-structural-foundation

---

## Decision 3: Presence Model

**MM-MODEL Reference**: §2.2 — `presence := true | false`

**Gap**: Presence is declared as boolean (`true | false`), but the section ends with "If any rule fails → Presence = INVALID." `INVALID` is a contradictory third state that violates the boolean declaration.

**Review Finding**: MM-MODEL-REVIEW.md §1 — "Presence has a contradictory state space. Declared as boolean (true | false), but the section ends with 'If any rule fails → Presence = INVALID.' INVALID is a third state that contradicts the boolean declaration."

**Decision**: Binary presence only — `true` or `false`. No `INVALID` state exists in the IAMMAI Sandbox implementation.

- If attestation rules are satisfied → `presence = true`
- If any attestation rule fails → `presence = false` (not `INVALID`)
- The `INVALID` notation in MM-MODEL is interpreted as: "the attestation is rejected, therefore presence = false"

**IAMMAI Sandbox Rationale**: The boolean declaration (`true | false`) is the primary specification. The `INVALID` clause is an error-handling behavior, not a third state. Resolving failed attestation to `false` maintains the binary contract while handling the error case cleanly. This simplifies all protocol evaluators that check presence — they only need to handle two states.

**Alternatives Rejected**:
- Ternary presence with `INVALID` — contradicts the boolean declaration, complicates all 10 protocol evaluators, and creates ambiguity about what `INVALID` means for verification (does it trigger PASS or FAIL?)

**Implementing Feature**: 007-presence-suppression

---

## Decision 4: Identity Formula

**MM-MODEL Reference**: §6 — `ID = Σ presence(event_k)`

**Gap**: The formula uses summation notation (Σ). If presence is boolean, the sum of booleans is an integer. Two different entities present at the same number of events would produce the same identity value, making identity non-unique.

**Review Finding**: MM-MODEL-REVIEW.md §1 — "The identity formula is mathematically incoherent. The formula almost certainly intends a set construction (the collection of events where presence = true), but it uses summation notation (Σ). A machine reading this literally gets a count, not an identity."

**Decision**: Identity as **set construction**, not summation:

```
identity(actor) = { session_k | presence(actor, session_k) = true }
```

- **Admin identity** = the set of sessions where verified admin presence exists
- **Anonymous users** have no identity (valid — identity gaps are allowed per §6)
- No credential-based identity assertions (forbidden by §6: "No documents, No credentials, No access rights")

**IAMMAI Sandbox Rationale**: Set construction produces unique identities (each admin has a unique set of sessions with verified presence). This matches the IAMMAI-SANDBOX-STRATEGY.md §3.10 interpretation and the review's recommendation. Anonymous users having no identity is explicitly valid per §6 ("Identity gaps are allowed").

**Alternatives Rejected**:
- Literal summation (count of sessions) — not unique, two admins with same session count are indistinguishable
- Hash-based identity — §6 forbids credential-based identity assertions; cryptographic identity ties to credentials

**Implementing Feature**: 008-governance-protocols

---

## Decision 5: Signal Coherence Criteria

**MM-MODEL Reference**: §2.3 — "Signal meaning MUST be singular. Ambiguity → REJECT. Narrative framing → REJECT."

**Gap**: "Singular meaning" requires semantic judgment. "Ambiguity → REJECT" requires detecting ambiguity, which is an interpretive act. "Narrative framing → REJECT" requires distinguishing narrative from operational content — one of the hardest problems in NLP.

**Review Finding**: MM-MODEL-REVIEW.md §3 — "Section 2.3 (Signal Interface) is the worst offender. It demands machines reject ambiguity and narrative framing, but provides no machine-evaluable test for either."

**Decision**: Signal coherence applies **only to system/admin commands that trigger state changes**, not to user chat messages or AI responses.

**Coherence rules**:
1. Reject contradictory state-changing commands in the same request (e.g., "extend session" + "close session")
2. Reject commands that reference invalid session states (e.g., "start" a session that is already `ACTIVE`)
3. Chat content is exempt — it lives in the ephemeral content layer, not the integrity layer

**What counts as a signal for coherence purposes**:

| Signal Type | Coherence Check | Reason |
|-------------|----------------|--------|
| Admin command (state-changing) | Yes | Machine-evaluable intent, triggers state transitions |
| System notification | Yes | Structured, unambiguous by definition |
| User chat message | No | Ephemeral content layer; NLP evaluation impractical |
| AI response | No | Ephemeral content layer; content not recorded |

**IAMMAI Sandbox Rationale**: By limiting coherence checks to structured admin commands (which have machine-evaluable intent fields), we avoid the NLP problem entirely while satisfying the protocol's spirit. IAMMAI-SANDBOX-STRATEGY.md §2.3 scopes signals to message types with clear intent fields. The integrity layer never sees chat content, so evaluating it for coherence is both impossible and unnecessary.

**Alternatives Rejected**:
- NLP-based signal evaluation — impractical, non-deterministic, violates §3.1 determinism requirement
- Ignoring signal coherence entirely — violates Protocol Supremacy (I.05), all protocols must be implemented

**Implementing Feature**: 007-presence-suppression

---

## Decision 6: Acedia Thresholds

**MM-MODEL Reference**: §7.2 — Acedia Detection

**Gap**: "Capacity is legitimate" is undefined. "HOLD persists" has no duration, threshold, or measurement. A machine cannot implement acedia detection without concrete values.

**Review Finding**: MM-MODEL-REVIEW.md §1 — "Acedia detection uses undefined terms. 'Capacity is legitimate' — what makes capacity legitimate? No definition. 'HOLD persists' — for how long? No duration, no threshold, no measurement."

**Decision**: Three configurable thresholds:

| State | Idle Threshold | Action |
|-------|---------------|--------|
| `CREATED` | 15 minutes with no transition to `ACTIVE` | Acedia warning issued to admin |
| `ACTIVE` | 30 minutes with no messages from any participant | Acedia detection triggered |
| Post-detection | 10-minute countdown | Admin notified; forced `RELEASE` (session termination) if no activity |

**Definitions**:
- **"Capacity is legitimate"**: Server is running, session exists, participants have active connections
- **"HOLD persists"**: Session remains in a state without meaningful activity beyond the defined threshold
- **Activity**: Any message from any participant, or any admin command

**IAMMAI Sandbox Rationale**: IAMMAI-SANDBOX-STRATEGY.md §3.7 proposes these exact thresholds. 15 minutes for `CREATED` accounts for session setup delays (admin creating session, sharing links). 30 minutes for `ACTIVE` gives reasonable conversation pauses without allowing indefinite stalling. The 10-minute countdown provides a final chance before forced resolution. All thresholds are stored as configuration values for production tuning.

**Alternatives Rejected**:
- Single threshold for all states — `CREATED` and `ACTIVE` have fundamentally different activity patterns
- Immediate forced resolution — too aggressive; no grace period for legitimate pauses
- No acedia detection — violates Anti-Acedia protocol (I.07)

**Implementing Feature**: 008-governance-protocols

---

## Decision 7: Co-Agency Balance Metric

**MM-MODEL Reference**: §9 — "No unilateral dominance. Imbalance → suppression."

**Gap**: No metric, ratio, or test for "imbalance" is defined. "No unilateral dominance" is not machine-evaluable without a concrete threshold.

**Review Finding**: MM-MODEL-REVIEW.md §1 — "'Imbalance' is not machine-evaluable. When does machine verification become 'unilateral dominance'? The boundary is unstated."

**Decision**: Maximum **2 consecutive irreversible actions** per agent type (human or AI) without the other agent type's involvement.

**Irreversible actions in IAMMAI Sandbox**:

| Action | Agent Type | Irreversible? |
|--------|-----------|--------------|
| Session termination | Human (admin) | Yes |
| Presence finalization | Machine | Yes |
| Verification execution | Machine | Yes |
| Suppression enforcement | Machine | Yes |
| Session creation | Human (admin) | No (can be terminated) |
| Message sending | Either | No (ephemeral) |
| Reading session state | Either | No (read-only) |

**Balance tracking**: Per-session counter. Reset when the other agent type performs an irreversible action. If counter reaches 2, the next irreversible action by the same agent type is suppressed until the other type acts.

**IAMMAI Sandbox Rationale**: IAMMAI-SANDBOX-STRATEGY.md §3.8 proposes this metric. The "consecutive irreversible actions" framing is machine-evaluable (simple counter per agent type per session). The limit of 2 prevents dominance while allowing reasonable operational flow — a machine can verify and then emit a witness (2 actions) but cannot also suppress without human involvement. Only irreversible actions count; routine operations are exempt.

**Alternatives Rejected**:
- Ratio-based balance (e.g., 60/40 split) — requires window-based measurement, harder to evaluate in real-time
- Per-action voting — too restrictive for normal operations, would require human approval for every machine action

**Implementing Feature**: 008-governance-protocols

---

## Decision 8: Verification Dispatch Model

**MM-MODEL Reference**: §3.1 — `V(event, presence, protocol_set) → PASS | FAIL`

**Gap**: The function signature is declared but the body is not. Two implementers could write different verification logic, both claim compliance, and produce different results for the same inputs — violating the deterministic requirement.

**Review Finding**: MM-MODEL-REVIEW.md §5 — "V(event, presence, protocol_set) → PASS | FAIL declares a function signature, not a function body. Two implementers could write different verification logic, both claim compliance, and produce different results for the same inputs."

**Decision**: Verification dispatches to **per-protocol evaluators**. Each protocol (I.01-I.10) has its own evaluator with pass/fail conditions defined by that protocol's specification. The overall result uses **conjunctive (AND) evaluation**: PASS only if ALL individual protocol evaluators pass.

```
V(event, presence, protocol_set) =
  FOR EACH protocol IN protocol_set:
    result = protocol.evaluate(event, presence)
    IF result == FAIL: RETURN FAIL
  RETURN PASS
```

**Protocol evaluation order**: Structural (I.02, I.03, I.04) → Operational (I.01, I.05, I.08) → Governance (I.06, I.07, I.09, I.10). Early termination on first FAIL.

**IAMMAI Sandbox Rationale**: The MM-MODEL "almost certainly intends" that verification logic is defined per protocol_set (Review §5). The individual protocol specifications each define their own pass/fail conditions, serving as the function body. Conjunctive evaluation matches the compliance test in §11 which requires ALL five conditions to be met. Early termination is an optimization that doesn't affect determinism.

**Alternatives Rejected**:
- Single monolithic evaluator — not maintainable, hard to add or modify individual protocols
- Weighted scoring — §11 compliance is binary (COMPLIANT/NON-COMPLIANT), not graduated
- Disjunctive evaluation (any pass = overall pass) — contradicts §11's all-or-nothing compliance requirement

**Implementing Feature**: 006-verification-witness

---

## Decision 9: Witness Artifact Format

**MM-MODEL Reference**: §3.2 — Witness Artifact (MANDATORY)

**Gap**: Witness fields are enumerated (event_id, t_open, t_close, presence, protocols_evaluated, pass_fail, suppression_triggered, timestamp_utc, protocol_versions) but the serialization format is unspecified.

**Review Finding**: MM-MODEL-REVIEW.md §2 — "All field types across all interfaces (string? UUID? enum? structured object?) [...] Witness artifact format (JSON? protobuf? custom?)" are left to implementer judgment.

**Decision**: JSON format with self-describing fields per Future Interpretability (I.10).

```json
{
  "artifact_type": "SESSION_WITNESS",
  "artifact_version": "1.0",
  "system": "iammai-sandbox",
  "event_id": "uuid-v4",
  "t_open": "ISO 8601 UTC",
  "t_close": "ISO 8601 UTC",
  "presence": {
    "admin": { "attested": true, "method": "auth_event" },
    "participants": [{ "role": "PARTICIPANT", "attested": true, "method": "session_join" }],
    "agents": [{ "role": "AGENT", "attested": true, "method": "first_message" }]
  },
  "protocols_evaluated": ["I.01", "I.02", "..."],
  "pass_fail": "PASS | FAIL",
  "protocol_results": [
    { "protocol": "I.01", "result": "PASS | FAIL", "details": "..." }
  ],
  "suppression_triggered": false,
  "timestamp_utc": "ISO 8601 UTC",
  "protocol_versions": { "I.01": "sha256-hash", "..." : "..." },
  "metadata": {
    "participant_count": 3,
    "session_name": "string",
    "duration_ms": 12345
  }
}
```

**Self-describing fields** (satisfying I.10):
- `artifact_type` — what kind of artifact this is
- `artifact_version` — schema version for forward compatibility
- `system` — which system produced it
- `protocol_results` — per-protocol breakdown (not just aggregate PASS/FAIL)
- `metadata` — contextual information for human interpretation

**IAMMAI Sandbox Rationale**: JSON is human-readable (satisfying I.10 interpretability), widely supported, and matches the project's existing data patterns (TypeScript/Node.js). Self-describing fields allow a future system to interpret the artifact without external documentation — "a future competent agent" can determine what it governs, permits, forbids, and how violations are handled (§10).

**Alternatives Rejected**:
- Protobuf — not human-readable, violates I.10 interpretability requirement
- Plain text — not structured enough for deterministic machine evaluation
- XML — more verbose than JSON with no added benefit for this use case

**Implementing Feature**: 006-verification-witness

---

## Decision 10: Privacy Boundary

**MM-MODEL Reference**: N/A (not a gap in MM-MODEL)

**Gap**: The IAMMAI Sandbox constitution (Principle V: Privacy & Ephemerality Enforcement) requires explicit architectural enforcement of privacy. The integrity layer must be provably separate from the content layer. This decision bridges the framework's witness/ledger requirements with the constitution's privacy mandate.

**Review Finding**: N/A — this is an IAMMAI Sandbox-specific constraint, not an MM-MODEL gap.

**Decision**: The integrity layer records **ONLY metadata**. The boundary is absolute and architecturally enforced.

| Recorded (Integrity Layer) | NEVER Recorded |
|---------------------------|----------------|
| Session ID, name, state | Message content |
| Timestamps (t_open, t_close) | User input / AI responses |
| Participant count | User identities (names, emails) |
| Presence roles + anonymous hashes | IP addresses / device info |
| Verification PASS/FAIL | Conversation context |
| Suppression events (action type + reason) | Personal data |
| AI model name, token count | AI output content |
| Protocol evaluation results | Session topic details beyond declared context_descriptor |

**Enforcement mechanism**: The integrity layer code never receives message content. The architecture passes only session lifecycle events (create, start, end) and metadata to the integrity layer. The chat engine and integrity layer share only the session ID as a join key.

**IAMMAI Sandbox Rationale**: This is the "different layers of the Reality Stack" principle from IAMMAI-SANDBOX-STRATEGY.md §1. The framework governs integrity metadata; the chatbot owns ephemeral content. These never mix. This satisfies both the constitution's privacy mandate ("Conversation data MUST never touch persistent storage") and the framework's witness requirements (all required witness fields are metadata, not content).

**Alternatives Rejected**: None — this boundary is non-negotiable per the constitution. Any design that leaks content into the integrity layer violates Principle V.

**Implementing Feature**: All (005-009)

---

## Traceability Index

| Decision | MM-MODEL § | Review Finding | Implementing Feature |
|----------|-----------|----------------|---------------------|
| 1. Event Interface Field Types | §2.1 | §1: Fields named but untyped | 005-structural-foundation |
| 2. State Space Mapping | §2.1 | §1: Binary status vs. IAMMAI Sandbox three-state | 005-structural-foundation |
| 3. Presence Model | §2.2 | §1: Boolean vs. INVALID contradiction | 007-presence-suppression |
| 4. Identity Formula | §6 | §1: Summation mathematically incoherent | 008-governance-protocols |
| 5. Signal Coherence Criteria | §2.3 | §3: Requires NLP, worst offender | 007-presence-suppression |
| 6. Acedia Thresholds | §7.2 | §1: Undefined terms, no thresholds | 008-governance-protocols |
| 7. Co-Agency Balance Metric | §9 | §1: Imbalance not machine-evaluable | 008-governance-protocols |
| 8. Verification Dispatch Model | §3.1 | §5: Signature without body | 006-verification-witness |
| 9. Witness Artifact Format | §3.2 | §2: Format unspecified | 006-verification-witness |
| 10. Privacy Boundary | N/A | N/A (constitution) | All (005-009) |

---

## Amendment History

| Date | Version | Change | Author |
|------|---------|--------|--------|
| 2026-02-13 | 1.0 | Initial decisions document with 10 decisions | IAMMAI Sandbox Team |

> **Amendment Process**: New decisions discovered during implementation of features 005-009 should be appended to this document with the next version number. Each amendment must include: gap reference, decision, rationale, and implementing feature. Amendments must not contradict existing decisions without explicit justification.
