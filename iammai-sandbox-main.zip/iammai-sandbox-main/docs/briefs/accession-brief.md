# Accession Experiment

This is not a request to implement IAMMAI itself. It is not a real product integration. It is not access to the whole body.

I only want a neutral simulator that behaves like an outside system so I can test a new accession/inspection flow against it.

## Task

Build a small sandboxed external system that can expose one bounded exportable unit for inspection.

Think of it as:

- a fake outside system
- with one clearly defined source object
- and a way to export one small slice of it
- so another system could later inspect that slice without trusting the whole source system

## What is needed in the sandbox

### 1. One fake external system

Small and self-contained.

No need for auth, payments, networking, accounts, or production concerns unless absolutely necessary.

### 2. One source object

Pick one simple object type, for example:

- session
- event
- record
- state object

Doesn't matter which, as long as it is:

- small
- inspectable
- easy to reason about
- carries some visible provenance/history

### 3. One exportable slice

The important part:

the sandbox must be able to expose one bounded slice of the source object.

Not the whole fake system. Not all data. Just one explicit exportable slice.

### 4. At least 2 example cases

Please include:

- one clean / well-structured case
- one messy / blocked / problematic case

The goal is to let me later test whether the inspection/adoption rules can distinguish them.

### 5. Clear role separation

Please keep the sandbox explicit about:

- what is source/original
- what is exported/derived
- what is just presentation/display

That distinction matters a lot.

## Design constraints

Please optimize for:

- simplicity
- explicitness
- reversibility
- inspectability
- easy local running
- easy extension later

Please do not optimize for:

- completeness
- production architecture
- scale
- nice UI
- clever abstractions
- heavy frameworks unless you truly need them

If in doubt, choose:

**smaller + clearer + more boring**

## What this is for

I am trying to test a newer IAMMAI rule-set for how an external system might be:

- seen
- inspected
- compared
- and maybe later evaluated for deeper integration

So this sandbox is only a neutral rehearsal object.

It is intentionally:

- not real
- not privileged
- not a hidden first product integration
- not business logic heavy

## Deliverable

What I'd like back:

- a small runnable sandbox
- one source object model
- one export/export-slice mechanism
- one clean sample
- one problematic sample
- short README / run instructions
- short note explaining:
  - what is source
  - what is exported
  - what is derived
  - what is display only

## What success looks like

Success means:

- I can point at one exported slice and say "this is the thing to inspect"
- I can compare the clean and problematic cases
- the system is neutral enough that it does not bias the test toward any real business/product
- the whole thing is easy to throw away if needed

I'll separately share a small doctrine bundle for context. You do not need the whole repo.
