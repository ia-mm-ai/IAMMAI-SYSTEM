# Accession Sandbox — Walkthrough

## What you're looking at

**IAMMAI** is a sandbox implementation of a constitutional protocol for how a system can lawfully take in material from the outside world without ever losing track of what is *original* vs. what is *derived*. It already exists as a running admin dashboard with its own governance, witness, and validation records.

The **Accession** module is a bolt-on that lets a separate external chat platform formally present a session to IAMMAI and have it inspected, tested, and either admitted or refused. It reuses IAMMAI's existing governance and witness tables, but runs its own 7-stage flow.

## The source object

The **source** is a full chat session sitting inside a fake external platform. It is the complete, original record — and it never leaves that platform. The following fields exist on the source side only:

| Field | What it holds |
|---|---|
| `participants[]` | Full list with names, roles, join times |
| `messages[]` | Every raw message, sender, timestamp |
| `started_at` / `ended_at` | Full timestamps |
| `metadata{}` | Any platform-specific extras |
| `topic`, `outcome`, `platform_name`, `duration_seconds` | Session summary fields |

Raw messages, participant names, and free-form metadata **never cross the boundary into IAMMAI**.

## The exported slice

The **exported slice** is the bounded summary that IAMMAI is actually allowed to see. It is the only thing that crosses the boundary, and it contains exactly these fields:

| Field | Example (Momacka) |
|---|---|
| `platform_name` | `"Momacka"` |
| `participant_count` | `2` |
| `duration_seconds` | `1800` |
| `topic` | `"Dogovor za momacku"` |
| `outcome` | `"resolved"` |
| `has_explicit_end` | `true` |

Plus two IDs: a new `slice_id` generated for the slice, and a `source_session_ref` pointing back to the original session on the external platform. No raw messages. No names. No PII.

## The two seed cases

Two sessions are seeded so you can see both a clean path and a blocked path. The chats are in casual Croatian — click into the **Contact** stage inspector to read the messages, because that is where the joke lives.

| Field | **Momacka** (clean) | **Seen** (blocked) |
|---|---|---|
| `participant_count` | 2 | 2 |
| `duration_seconds` | 1800 | 0 |
| `topic` | `"Dogovor za momacku"` | `"Momacka v2: sad stvarno"` |
| `outcome` | `"resolved"` | *(null)* |
| `has_explicit_end` | true | false |
| **Result** | ✅ ADMITTED → Bound Vessel | ❌ REFUSED at Admission |

**Momacka** is a 30-minute group chat between Mario (the groom) and Marko (his best man) trying, and comically failing, to plan the bachelor party. It ends with Marko declaring `rijeseno` — which happens to map exactly onto the validator's hard-coded `"resolved"` state. All shadow checks pass, all four proof tests pass, and IAMMAI admits it and creates a *Bound Vessel* — a read-only, derivative record that references the original but cannot govern it. The punchline: the system is fully convinced the bachelor party is under control.

**Seen** is the follow-up. Mario double-texts Marko about the bachelor party — `Brt, reminder za momacku` / `Brt?` — and Marko never replies. The session has no end, no outcome, no duration. It accumulates 3 typed discrepancies at the Shadow stage, fails all 4 proof tests (`required_fields_present`, `duration_plausible`, `explicit_end`, `outcome_valid`), and is **refused** at Admission. The ADVANCE button then disables. The system agrees with what the name already says: there is no reply here to bear witness to. Every refusal reason stays visible in the stage inspector — nothing is erased.

```mermaid
graph TD
    contact["Contact"]
    eligibility["Eligibility"]
    shadow_clean["Shadow — 0 issues"]
    shadow_messy["Shadow — 3 issues"]
    proof_clean["Proof — 4/4 pass"]
    proof_messy["Proof — 0/4 pass"]
    admitted["ADMITTED"]
    refused["REFUSED"]
    vessel["Bound Vessel"]
    preserved["Records preserved"]

    contact --> eligibility
    eligibility --> shadow_clean & shadow_messy
    shadow_clean --> proof_clean --> admitted --> vessel
    shadow_messy --> proof_messy --> refused --> preserved

    style shadow_clean stroke:#00ff88,color:#00ff88
    style proof_clean stroke:#00ff88,color:#00ff88
    style admitted stroke:#00ff88,color:#00ff88
    style vessel stroke:#00ffff,color:#00ffff
    style shadow_messy stroke:#ff3366,color:#ff3366
    style proof_messy stroke:#ff3366,color:#ff3366
    style refused stroke:#ff3366,color:#ff3366
    style preserved stroke:#ffaa00,color:#ffaa00
```

## Getting started

1. Open the deployed admin dashboard and log in.
2. Click **Accession** in the top navigation.
3. Click **Load Seeds** — both cases appear in the left panel at the Contact stage.
4. Select a slice on the left, then click **ADVANCE** to move it one stage forward. Do this repeatedly to walk through the flow.
5. Click any completed stage in the timeline to open the inspector and see the records that stage produced.
6. Click **Reset** at any time to wipe the accession tables and reload both seeds from Contact.

## What to look for in the inspector

- **Contact** — was the slice accepted for observation
- **Eligibility** — per-condition pass/fail (bounded slice named, source visible, roles distinguishable, inspection possible)
- **Shadow** — IAMMAI's own mirror copy plus any typed discrepancies it found against the slice
- **Proof** — each of the four proof tests with a pass/fail badge
- **Admission** — the governance decision, and for a refusal, which proofs failed

Every record in the inspector is labeled with its **data role** (source, exported, derived, display) so it is always visible at a glance whether what you are looking at is the original or something IAMMAI built from it.
