# IAMMAI Sandbox PoC Integrity Layer — Implementation Plan

> Maps each phase from IAMMAI-SANDBOX-STRATEGY.md to a speckit feature (004-009).
> Each feature follows the speckit workflow: `/speckit.specify` -> `/speckit.plan` -> `/speckit.tasks` -> `/speckit.implement`.
>
> Created: 2026-02-14
> Status: In Progress (004, 005 complete)

---

## Feature Map: Strategy Phases -> Speckit Features

| Phase | Feature | Protocols | Depends On | Status |
|-------|---------|-----------|------------|--------|
| 0: Preparation | `004-framework-decisions` | -- | None | **Complete** |
| 1: Structural Foundation | `005-structural-foundation` | I.02, I.03, I.04 | 004 | **Complete** |
| 2: Verification + Witness | `006-verification-witness` | (structural checks) | 005 | Planned |
| 3: Presence + Suppression | `007-presence-suppression` | I.01, I.05, I.08 | 006 | Planned |
| 4: Governance | `008-governance-protocols` | I.06, I.07, I.09, I.10 | 007 | Planned |
| 5: Compliance Test | `009-compliance-test` | All (MM-MODEL §11) | 008 | Planned |

Features are **strictly sequential** — each builds on the previous.

---

## Architecture Overview

The integrity layer sits **beside** the chat engine — it observes session lifecycle events, verifies protocol compliance, and records metadata. It never touches ephemeral chat content.

```
IAMMAI SANDBOX
│
├── Chat Engine (ephemeral — NOT governed by framework)
│   ├── WebSocket messaging
│   ├── AI response generation
│   └── Content destruction on session close
│
└── Integrity Layer (permanent — governed by framework)
    ├── State Observer          ← 005 (complete)
    ├── Ledger (append-only)    ← 005 (complete)
    ├── Boundary Enforcement    ← 005 (complete)
    ├── Verification Engine     ← 006
    ├── Witness Emitter         ← 006
    ├── Protocol Evaluators     ← 006, 007, 008
    ├── Presence Tracker        ← 007
    ├── Suppression Engine      ← 007
    ├── Acedia Monitor          ← 008
    ├── Co-Agency Tracker       ← 008
    └── Compliance Test         ← 009
```

### Source Code Layout

```
backend/src/integrity/
  types.ts                 # Shared integrity types (005)
  hash.ts                  # SHA-256 hash chain utilities (005)
  ledger.ts                # Append-only ledger service (005)
  state-observer.ts        # State transition observer (005)
  boundary.ts              # Event boundary validation (005)
  verification-engine.ts   # V(event, presence, protocols) -> PASS|FAIL (006)
  witness-emitter.ts       # Self-describing witness artifacts (006)
  presence-tracker.ts      # Actor presence attestation (007)
  suppression-engine.ts    # Protocol-based suppression (007)
  acedia-monitor.ts        # Stalled session detection (008)
  co-agency-tracker.ts     # Human/AI balance enforcement (008)
  compliance-test.ts       # MM-MODEL §11 compliance runner (009)
  protocols/
    protocol-base.ts       # ProtocolEvaluator interface (006)
    i02-event-boundary.ts  # Event Boundary Protocol (006)
    i03-continuity.ts      # Continuity Non-Regression (006)
    i04-ledger-integrity.ts# Ledger Non-Erasure (006)
    i01-presence-truth.ts  # Presence Truth Protocol (007)
    i05-protocol-supremacy.ts  # Protocol Supremacy (007)
    i08-signal-coherence.ts    # Signal Coherence (007)
    i06-presence-identity.ts   # Presence-Derived Identity (008)
    i07-anti-acedia.ts         # Anti-Acedia Protocol (008)
    i09-co-agency-balance.ts   # Co-Agency Balance (008)
    i10-future-interpretability.ts # Future Interpretability (008)
```

### Database Migrations

| Migration | Feature | Tables/Changes |
|-----------|---------|----------------|
| `002_integrity_ledger.sql` | 005 | `integrity_ledger` table, `integrity_event_type` enum, session boundary columns, protective triggers |
| `003_add_witness_event_type.sql` | 006 | Add `VERIFICATION_WITNESS` to enum |
| `004_presence_records.sql` | 007 | `presence_records` table |

---

## Feature 004: Framework Decisions (Phase 0) — COMPLETE

**Branch**: `004-framework-decisions`
**Purpose**: Organize framework docs and record all gap-filling implementation decisions.

### Deliverables
- `docs/framework/` — organized framework reference docs and protocol specs (I.01-I.10)
- `docs/framework/FRAMEWORK_DECISIONS.md` — 10 decisions covering:
  1. Event interface field types (UUID v4, ISO 8601, JSON schemas)
  2. State space mapping (CREATED+ACTIVE = OPEN, ENDED = CLOSED)
  3. Presence model (binary only, no INVALID state)
  4. Identity formula (set construction, not summation)
  5. Signal coherence criteria (admin commands only, not chat content)
  6. Acedia thresholds (15min CREATED, 30min ACTIVE, 10min countdown)
  7. Co-agency balance metric (max 2 consecutive irreversible actions)
  8. Verification dispatch model (per-protocol, conjunctive AND)
  9. Witness artifact format (self-describing JSON)
  10. Privacy boundary (metadata only, never content)

---

## Feature 005: Structural Foundation (Phase 1) — COMPLETE

**Branch**: `005-structural-foundation`
**Purpose**: Forward-only state machine, append-only ledger with hash-chaining, event boundary enforcement.

### Deliverables
- `backend/src/integrity/types.ts` — `LedgerEntry`, `MetadataSnapshot`, `IntegrityEventType`, `FrameworkStatus`
- `backend/src/integrity/hash.ts` — `computeEntryHash()`, `validateHashChain()`
- `backend/src/integrity/ledger.ts` — `appendEntry()`, `getEntriesBySession()`, `validateChain()`
- `backend/src/integrity/state-observer.ts` — `observeTransition()`, `buildMetadataSnapshot()`
- `backend/src/integrity/boundary.ts` — `validateContextDescriptor()`, `validateEnvironmentalConstraints()`, `isFinalizationPermitted()`
- `backend/migrations/002_integrity_ledger.sql` — ledger table with BEFORE UPDATE/DELETE triggers
- Session model enhanced with `externalClient` parameter for atomic transactions
- Session routes recording all transitions in the ledger
- 26 tasks across 6 phases (all complete)

---

## Feature 006: Verification + Witness (Phase 2) — NEXT

**Branch**: `006-verification-witness`
**Purpose**: Verification engine evaluating protocols on session close; self-describing witness artifacts stored in ledger.

### User Stories
- **US1 (P1):** Every session close triggers verification producing binary PASS/FAIL
- **US2 (P1):** Witness artifacts emitted and stored in ledger with all required fields
- **US3 (P2):** Verification is deterministic (same inputs -> identical results)
- **US4 (P2):** Witness artifacts are self-describing (interpretable without external docs)

### Architecture
- `verification-engine.ts` — `verify(session, ledgerEntries, protocolSet) -> VerificationResult`
- `witness-emitter.ts` — builds `WitnessArtifact` JSON, appends to ledger as `VERIFICATION_WITNESS`
- `protocols/protocol-base.ts` — `ProtocolEvaluator` interface
- `protocols/i02-event-boundary.ts` — has t_open, t_close, context, constraints, status=CLOSED?
- `protocols/i03-continuity.ts` — state transitions monotonic? no rollbacks?
- `protocols/i04-ledger-integrity.ts` — hash chain valid? no sequence gaps?

### Witness Artifact Fields (per FRAMEWORK_DECISIONS.md Decision 9)
```
artifact_type, artifact_version, system, event_id, t_open, t_close,
presence, protocols_evaluated, pass_fail, protocol_results,
suppression_triggered, timestamp_utc, protocol_versions, metadata
```

### Integration
Session end flow: state transition -> ledger record -> **verification** -> **witness emission** -> dissolution

### Key Decision
Verification FAIL does NOT block session closure in 006. Suppression enforcement comes in 007.

### Estimated Tasks: ~22

---

## Feature 007: Presence + Suppression (Phase 3)

**Branch**: `007-presence-suppression`
**Purpose**: Track actor presence; enforce protocol-based suppression of invalid actions.

### User Stories
- **US1 (P1):** Admin presence attested on session creation (auth event)
- **US2 (P1):** User presence attested on session join (anonymous, role=PARTICIPANT)
- **US3 (P1):** AI presence attested on first message processing (role=AGENT)
- **US4 (P1):** Presence finalized only after session closes
- **US5 (P2):** Suppression halts execution on FAIL, prevents mutation, records attempt
- **US6 (P2):** Admin commands pass through protocol validation before execution

### Architecture
- `presence-tracker.ts` — `attestPresence()`, `finalizePresence()`, `getPresence()`
- `suppression-engine.ts` — `evaluateAction()` -> suppress or allow; `recordSuppression()`
- `protocols/i01-presence-truth.ts` — 2+ independent attestation methods?
- `protocols/i05-protocol-supremacy.ts` — no admin override of verification results?
- `protocols/i08-signal-coherence.ts` — no contradictory commands?

### Database
New `presence_records` table with role, attestation method, finalization tracking.

### Integration Points
- Session routes: suppression check before start/end; admin presence on create
- Token routes: user presence on join
- WebSocket handlers: AI presence on first message
- Verification engine: add I.01, I.05, I.08 evaluators; replace presence stub from 006

### Estimated Tasks: ~25

---

## Feature 008: Governance Protocols (Phase 4)

**Branch**: `008-governance-protocols`
**Purpose**: Acedia detection, co-agency balance, future interpretability.

### User Stories
- **US1 (P1):** Stalled sessions detected (15min CREATED, 30min ACTIVE idle) and force-resolved
- **US2 (P1):** AI cannot execute irreversible actions without human involvement (max 2 consecutive)
- **US3 (P1):** Admin cannot bypass verification or suppression regardless of authority
- **US4 (P2):** AI reasoning metadata (model, token count — not content) stored in witnesses
- **US5 (P2):** Admin identity = set of sessions with verified presence, not credentials

### Architecture
- `acedia-monitor.ts` — timer-based stall detection with configurable thresholds
- `co-agency-tracker.ts` — in-memory per-session balance tracker
- `protocols/i06-presence-identity.ts` — identity derived from presence set?
- `protocols/i07-anti-acedia.ts` — session resolved without lingering acedia?
- `protocols/i09-co-agency-balance.ts` — no agent type exceeded consecutive limit?
- `protocols/i10-future-interpretability.ts` — witness self-describing?

### Integration Points
- Server startup: initialize acedia monitor with interval check
- Session lifecycle: monitor/record activity/stop on create/message/end
- Session routes: co-agency check before admin actions

### Estimated Tasks: ~22

---

## Feature 009: Compliance Test (Phase 5)

**Branch**: `009-compliance-test`
**Purpose**: MM-MODEL §11 binary compliance validation of the complete integrity layer.

### User Stories
- **US1 (P1):** Running compliance test produces COMPLIANT or NON-COMPLIANT with per-condition results
- **US2 (P1):** Each of 5 conditions is independently testable with evidence
- **US3 (P2):** Compliance test is automated and repeatable in CI

### The 5 Conditions (MM-MODEL §11)

| # | Condition | Test |
|---|-----------|------|
| 1 | Truth finalizes only via presence in closed events | No presence finalization while ACTIVE; all finalized after ENDED |
| 2 | Verification is deterministic and witnessed | Same inputs -> identical PASS/FAIL; witness artifact exists |
| 3 | Suppression is mandatory and enforced | FAIL -> halt, no mutation, downstream blocked, recorded |
| 4 | History never regresses | Rollback rejected; ledger deletion rejected |
| 5 | Authority is never asserted | Admin override of protocol -> suppressed and recorded |

### Files
```
backend/src/integrity/compliance-test.ts
backend/tests/compliance/
  truth-finalization.test.ts
  deterministic-verification.test.ts
  mandatory-suppression.test.ts
  history-non-regression.test.ts
  authority-non-assertion.test.ts
  full-compliance.test.ts
```

### Estimated Tasks: ~16

---

## Privacy Boundary (Constitution Principle V)

The integrity layer records ONLY metadata — enforced architecturally:

| Recorded | NEVER Recorded |
|----------|----------------|
| Session ID, name, state | Message content |
| Timestamps (t_open, t_close) | User input / AI responses |
| Participant count | User identities (names, emails) |
| Presence roles + anonymous hashes | IP addresses / device info |
| Verification PASS/FAIL | Conversation context |
| Suppression events (action type + reason) | Personal data |
| AI model name, token count | AI output content |
| Protocol evaluation results | Session topic details beyond context_descriptor |

---

## Task Count Summary

| Feature | Estimated Tasks | Status |
|---------|----------------|--------|
| 004-framework-decisions | ~10 | Complete |
| 005-structural-foundation | 26 | Complete |
| 006-verification-witness | ~22 | Next |
| 007-presence-suppression | ~25 | Planned |
| 008-governance-protocols | ~22 | Planned |
| 009-compliance-test | ~16 | Planned |
| **Total** | **~121** | |

---

## Final Verification (after all features)

1. `npm test` — all integrity module tests pass
2. `DELETE FROM integrity_ledger` via raw SQL — verify blocked by triggers
3. Transition ENDED -> ACTIVE via API — verify 400 rejection
4. End a session — verify witness entry in ledger with all required fields
5. End two identical sessions — verify deterministic witness artifacts
6. Attempt admin protocol override — verify suppression recorded
7. Run `compliance-test.ts` — verify COMPLIANT result
8. Search ledger for message content — verify zero results
