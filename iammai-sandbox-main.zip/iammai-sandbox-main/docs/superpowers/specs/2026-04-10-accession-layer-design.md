# Accession Layer — Design Spec

## Context

The client brief (`docs/briefs/accession-brief.md`) asks for a sandboxed system to test accession/inspection flows — how an external system's bounded slice can be seen, inspected, compared, and evaluated for deeper integration.

Rather than building a standalone sandbox, we extend the existing IAMMAI implementation. The existing sandbox IS the body in IAMMAI terms — it has the full 9-phase state machine, 6 runtime components, 7 canonical record types, and 15 protocol evaluators. The accession layer adds the ability for external systems to lawfully approach this body.

The fake external system is a chat platform. Its source object is a session record. The exportable slice is a session summary — no raw messages cross the boundary.

## Approach: Lightweight Accession Module

Constitutionally correct (separate 7-stage state machine, no semantic collapse with the 9-phase engine) but scoped to what the brief needs. Simple, boring, inspectable, easy to throw away or extend later.

Key architectural decisions:

- **Separate state machine** — accession stages are NOT phases in the existing 9-phase engine. They are a parallel state machine tracking how external slices enter the body. This prevents semantic collapse between two distinct processes.
- **Shared canonical tables** — governance actions, witness artifacts, and validation artifacts reuse the existing IAMMAI tables via `matter_ref = 'bnk:accession:slice:{sliceId}'`. Only accession-specific records need new tables.
- **Step-through UI** — admin interface lets the client advance one stage at a time, inspect intermediate state, then decide whether to continue.

## The Source Object

### External System: Fake Chat Platform

A simple module that generates external session records. Not persisted in its own right — it's a data generator that produces source objects on demand.

**Full source object (never stored directly in the body):**

```typescript
interface ExternalSession {
  session_id: string;
  platform_name: string;
  participants: Array<{
    id: string;
    name: string;
    role: string;
    joined_at: string;
  }>;
  started_at: string;
  ended_at: string;
  duration_seconds: number;
  messages: Array<{              // raw messages — NEVER cross the boundary
    sender_id: string;
    content: string;
    sent_at: string;
  }>;
  topic: string;
  outcome: string | null;
  metadata: Record<string, unknown>;
}
```

### Exported Slice: Session Summary

The bounded piece that crosses the contact boundary. Deliberately excludes raw messages, participant details beyond count, and internal metadata.

```typescript
interface SessionSummarySlice {
  slice_id: string;
  source_session_ref: string;
  platform_name: string;
  participant_count: number;
  duration_seconds: number;
  topic: string;
  outcome: string | null;
  has_explicit_end: boolean;
}
```

### Role Separation

| Role | What it is | Example |
|---|---|---|
| **Source** | Full session in the external system | `ExternalSession` with messages, participants, metadata |
| **Exported** | Bounded summary crossing the boundary | `SessionSummarySlice` — no messages, no PII |
| **Derived** | Body's shadow copy + proof results | Shadow record with discrepancies, proof test outcomes |
| **Display** | API/UI presentation | JSON responses, UI cards — always labeled as derivative |

## The Two Seed Cases

### Clean Case: "Alpha Chat"

```
Source: {
  platform_name: "Alpha Chat",
  participants: [
    { id: "u1", name: "Alice", role: "initiator", joined_at: "2026-04-01T10:00:00Z" },
    { id: "u2", name: "Bob", role: "responder", joined_at: "2026-04-01T10:01:00Z" },
    { id: "u3", name: "Support Agent", role: "agent", joined_at: "2026-04-01T10:02:00Z" }
  ],
  started_at: "2026-04-01T10:00:00Z",
  ended_at: "2026-04-01T10:45:00Z",
  duration_seconds: 2700,
  messages: [ ... 12 messages ... ],
  topic: "Account access recovery",
  outcome: "resolved",
  metadata: { channel: "web", priority: "normal" }
}

Exported Slice: {
  platform_name: "Alpha Chat",
  participant_count: 3,
  duration_seconds: 2700,
  topic: "Account access recovery",
  outcome: "resolved",
  has_explicit_end: true
}
```

**Expected progression:** Contact (accepted-for-observation) -> Eligibility (pass) -> Shadow (no anomalies) -> Proof (all tests pass) -> Admission (admitted) -> Bound Vessel (derivative, read-only)

### Messy Case: "Beta Legacy"

```
Source: {
  platform_name: "Beta Legacy",
  participants: [],
  started_at: "2026-04-01T10:00:00Z",
  ended_at: "2026-04-01T10:00:00Z",
  duration_seconds: 0,
  messages: [],
  topic: "",
  outcome: null,
  metadata: {}
}

Exported Slice: {
  platform_name: "Beta Legacy",
  participant_count: 0,
  duration_seconds: 0,
  topic: "",
  outcome: null,
  has_explicit_end: false
}
```

**Expected progression:** Contact (accepted-for-observation) -> Eligibility (pass — only checks source exists) -> Shadow (anomalies: zero participants, zero duration, empty topic, no outcome) -> Proof (FAILS: no participants, implausible duration, missing required fields) -> Admission (refused with typed reasons)

All records preserved. Refusal is not erasure.

## 7-Stage Accession Flow

### Stage 1: Contact

External system registers and presents one slice. Body decides:
- **Accepted for observation** — bounded enough to hold at threshold
- **Out of scope** — not relevant to this body
- **Insufficient grounding** — too underformed for handling
- **Refused** — malformed or hostile approach

Records produced: accession state record (stage=contact), governance action, witness artifact.

### Stage 2: Eligibility

Body checks minimal candidacy conditions:
- One bounded slice is named (not whole-system)
- Source visibility is possible (can trace back to external session)
- Roles are distinguishable (source/exported/derived not fused)
- Bounded inspection is possible

Records produced: accession state record (stage=eligibility), validation artifact (pass/fail per condition), governance action, witness.

### Stage 3: Shadow

Body creates a non-native mirror of the slice (derived copy). Compares against body's standards. Records discrepancies:
- Missing fields the body would expect
- Values outside body's expected ranges
- Structural differences from body's native format

Records produced: accession state record (stage=shadow), shadow record (mirror data + discrepancies), witness.

### Stage 4: Proof

Bounded tests against the shadow:
- **Required fields present**: participant_count > 0, topic non-empty, outcome non-null
- **Duration plausible**: > 0 and < 86400 (24h)
- **Explicit end**: has_explicit_end is true
- **Outcome valid**: outcome is one of known values (resolved, abandoned, escalated, expired)

Each test produces a typed result (pass/fail/blocked/indeterminate). Records produced: accession state record (stage=proof), proof records (one per test), validation artifact (aggregate outcome), witness.

### Stage 5: Admission

Governance decision based on proof results:
- **Admitted** — all proofs passed, governance authorizes
- **Not yet** — proofs incomplete, defer
- **Refused** — proofs failed, governance refuses with reasons

Records produced: accession state record (stage=admission), governance action (with decision + legitimacy basis), witness.

### Stage 6: Bound Vessel

If admitted: derivative operational record created. The slice can be read and referenced within the body but is NOT native. Cannot create standing state, govern, or become canonical source.

Records produced: accession state record (stage=bound_vessel), governance action (vessel grant), witness.

### Stage 7: Revocation

Can happen from any post-contact stage. Narrows, pauses, or terminates the relation. All prior records preserved.

Records produced: accession state record (stage=revoked), governance action (revocation), witness.

## Database Migration (008)

### New Enums

- `accession_stage`: contact, eligibility, shadow, proof, admission, bound_vessel, revoked
- `accession_family`: pre_admission, post_admission
- `contact_outcome`: accepted_for_observation, out_of_scope, insufficient_grounding, refused
- `admission_decision`: admitted, not_yet, refused
- `data_role`: source, exported, derived, display

### New Tables

All append-only with immutability triggers (reuses existing `iammai_prevent_update` and `iammai_prevent_delete` functions from migration 007).

**1. `iammai_external_sources`** — external systems that approach

| Column | Type | Notes |
|---|---|---|
| source_id | UUID PK | |
| source_name | VARCHAR(255) | e.g., "Alpha Chat" |
| source_system_ref | VARCHAR(255) | external system identifier |
| source_data | JSONB | full source object for reference |
| actor_ref | VARCHAR(255) | who registered the source |
| created_at | TIMESTAMPTZ | |

**2. `iammai_exported_slices`** — bounded slices presented for accession

| Column | Type | Notes |
|---|---|---|
| slice_id | UUID PK | |
| source_id | UUID FK -> external_sources | |
| slice_name | VARCHAR(255) | |
| slice_data | JSONB | the summary slice |
| data_role | data_role DEFAULT 'exported' | |
| created_at | TIMESTAMPTZ | |

**3. `iammai_accession_state_records`** — accession stage state

| Column | Type | Notes |
|---|---|---|
| state_id | UUID PK | |
| slice_ref | UUID FK -> exported_slices | |
| accession_family | accession_family | pre_admission or post_admission |
| accession_stage | accession_stage | |
| stage_outcome | JSONB | stage-specific outcome data |
| recorded_at | TIMESTAMPTZ | |
| predecessor_ref | UUID FK -> self | |
| related_governance_ref | UUID FK -> iammai_governance_actions | |
| related_validation_ref | UUID FK -> iammai_validation_artifacts | |
| related_witness_ref | UUID FK -> iammai_witness_artifacts | |

**4. `iammai_accession_transitions`** — stage-to-stage movement

| Column | Type | Notes |
|---|---|---|
| transition_id | UUID PK | |
| slice_ref | UUID FK -> exported_slices | |
| source_state_ref | UUID FK -> accession_state_records | |
| target_state_ref | UUID FK -> accession_state_records | |
| transition_type | VARCHAR(100) | e.g., contact_to_eligibility |
| occurred_at | TIMESTAMPTZ | |

**5. `iammai_shadow_records`** — shadow stage inspection data

| Column | Type | Notes |
|---|---|---|
| shadow_id | UUID PK | |
| slice_ref | UUID FK -> exported_slices | |
| shadow_data | JSONB | body's mirror copy |
| discrepancies | JSONB | array of typed discrepancies |
| data_role | data_role DEFAULT 'derived' | |
| created_at | TIMESTAMPTZ | |
| governance_action_ref | UUID FK -> iammai_governance_actions | |

**6. `iammai_proof_records`** — individual proof test results

| Column | Type | Notes |
|---|---|---|
| proof_id | UUID PK | |
| slice_ref | UUID FK -> exported_slices | |
| shadow_ref | UUID FK -> shadow_records | |
| test_name | VARCHAR(255) | e.g., "required_fields_present" |
| test_result | validation_outcome | pass/fail/blocked/indeterminate |
| test_details | JSONB | test-specific output |
| checked_at | TIMESTAMPTZ | |

## Backend Module Structure

```
backend/src/integrity/iammai/accession/
  types.ts                 — AccessionStage, AccessionFamily, DataRole, record interfaces, constants
  stage-engine.ts          — 7-stage state machine (valid transitions, family mapping, ordering)
  accession-registry.ts    — Insert/query for accession-specific tables
  accession-validator.ts   — Stage transition validation, eligibility checks, proof tests
  accession-coordinator.ts — Orchestrates: Validate -> Witness -> Govern -> Advance -> Persist
  external-simulator.ts    — Generates ExternalSession + SessionSummarySlice for seeds
  seed-cases.ts            — Runs clean + messy cases through coordinator
  index.ts                 — Barrel export
```

**Reuses from existing IAMMAI modules:**
- `governor.ts` — governance actions with attribution
- `witness-factory.ts` — witness artifacts with mandatory non-claims
- `registry.ts` — insert governance/witness/validation into existing canonical tables
- `record-factory.ts` — UUID generation, timestamps

## API Routes

Mounted at `/api/v1/admin/iammai/accession`.

**Seed management:**
- `POST /seed` — load both seed cases (creates external sources + slices at Contact stage)
- `POST /reset` — truncate accession tables for fresh start

**Stage advancement:**
- `POST /slices/:sliceId/advance` — advance to next stage (validates, governs, witnesses, persists)

**Inspection (read-only, derivative):**
- `GET /sources` — list external sources
- `GET /slices` — list slices with current accession stage
- `GET /slices/:sliceId` — full accession context (current stage, history, all records)
- `GET /slices/:sliceId/stages/:stage` — records produced at a specific stage

## Admin UI

New page at `/admin/accession` in the existing Next.js frontend. Follows the established dark futuristic admin pattern.

### Layout

**Left panel: Slice list**
- Lists seed slices (clean + messy)
- Each shows: platform name, current stage (badge), stage outcome
- Click to select and inspect

**Main panel: Stage timeline + inspector**
- Horizontal timeline showing all 7 stages
- Current stage highlighted, completed stages show outcome
- "Advance" button to move to next stage
- Each completed stage expandable to show:
  - Records produced (governance action, witness, validation)
  - Role labels on all data (source/exported/derived/display)
  - Stage-specific content:
    - **Contact**: contact outcome
    - **Eligibility**: per-condition pass/fail
    - **Shadow**: mirror copy + discrepancies list
    - **Proof**: individual test results with pass/fail badges
    - **Admission**: decision + governance reasoning
    - **Bound Vessel**: operational constraints + derivative label
    - **Revocation**: reason + preserved history confirmation

**Top bar:**
- "Load Seeds" button
- "Reset" button
- Breadcrumb: Admin > IAMMAI > Accession

### UI Constraints
- Functional, not polished — admin dashboard style
- All data labeled with its role (source/exported/derived/display)
- No raw message content ever displayed (enforces slice boundary)
- Stage advancement is manual (step-through)

## Modified Existing Files

| File | Change |
|---|---|
| `backend/src/integrity/iammai/index.ts` | Add barrel export for accession module |
| `backend/src/integrity/iammai/event-bus.ts` | Add accession event types |
| `backend/src/api/app.ts` | Import and mount accession router |
| `frontend/src/app/admin/` | Add accession page route |

## What We're NOT Building

- No protocol evaluator (I.16) — can add later
- No custom slice creation — seeds only
- No pluggable proof rules — hardcoded checks
- No SSE streaming for accession events
- No production concerns (auth hardening, rate limiting)
- No continuity layer integration

## Accession Invariants Enforced

- **Slice-first**: every accession record references `slice_ref`, never source directly
- **Contact is not accession**: contact stage creates no vessel records
- **Eligibility is not admission**: passing eligibility does not create vessel records
- **Shadow is not vesselhood**: shadow data is `derived` role, no operational permissions
- **Revocation preserves history**: all prior records remain queryable
- **No founder privilege**: every stage transition requires governance action with actor_ref + authority_class + legitimacy_basis_ref
- **Admitted is not native**: bound vessel cannot create standing state, govern, or become canonical source

## Verification

1. Run migration 008 against local DB
2. `POST /seed` — verify both seed cases created at Contact stage
3. Step clean case through all stages — verify it reaches Bound Vessel
4. Step messy case — verify it fails at Proof, gets refused at Admission
5. Verify all records preserved for both cases via `GET /slices/:id`
6. Verify shadow shows discrepancies for messy case
7. Verify proof shows typed failures for messy case
8. Verify role labels present on all API responses
9. Verify UI renders stage timeline, step-through works, records inspectable
10. Run `npx vitest run` — existing tests still pass
11. Auditor can answer: what stage, what made it eligible, what was shadowed, what was proved, what was the decision, what history remains
