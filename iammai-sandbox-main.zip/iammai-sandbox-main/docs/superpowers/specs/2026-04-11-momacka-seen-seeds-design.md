# Design: Momacka + Seen accession seeds

**Date:** 2026-04-11
**Status:** Implemented

## Context

The accession sandbox ships with two seed cases that the client walks through to understand how the module works. Until now those seeds were generic: `Alpha Chat` (clean) and `Beta Legacy` (messy). Functional, forgettable, and impossible to tell apart from any other demo data.

The client for this sandbox is the user's best-man, responsible for organizing the user's bachelor party. Both are self-admittedly unorganized. Replacing the seeds with a tailored inside joke — a Croatian chat about failing to plan the bachelor party, plus a follow-up left on seen — turns the walkthrough into a personalized demo the client will remember and retell.

This spec captures the symbolic and technical design of that replacement.

## Goals

1. Replace both seed cases with content that carries a personal joke for the client.
2. Preserve the accession layer's existing validator semantics — `Momacka` must still pass all four proof tests, `Seen` must still be refused.
3. Make the punchline legible from inside the admin dashboard with no extra UI work — the humor has to surface through the existing stage inspectors.
4. No schema, migration, validator, or UI changes.

## Non-goals

- Rewriting historical design docs under `docs/superpowers/specs/2026-04-10-accession-layer-design.md` — those describe the original Alpha/Beta seeds and remain as an archival record.
- Touching the admission decision logic, the proof test list, or the `VALID_OUTCOMES` array.

## Design

### Clean seed: `Momacka`

A 30-minute Croatian group chat between two participants trying — and comically failing — to plan a bachelor party. The joke lands because the validator treats the chat as fully `resolved` even though nothing is actually decided.

**Source object (`ExternalSession`):**
- `platform_name`: `"Momacka"` (Croatian for "bachelor party")
- `participants` (2): `Mario` (role `mladozenja` — groom), `Marko` (role `kum` — best man)
- `started_at`: `2026-06-01T20:00:00Z`
- `ended_at`: `2026-06-01T20:30:00Z`
- `duration_seconds`: `1800`
- `topic`: `"Dogovor za momacku"` (agreement/planning for the bachelor party)
- `outcome`: `"resolved"` (valid per `VALID_OUTCOMES`)
- `metadata`: `{ channel: 'group_chat', language: 'hr' }`

**Messages (14, casual ASCII Croatian, no diacritics):**

| # | Sender | Message |
|---|---|---|
| 1 | Mario | Brt, sta cemo za momacku? |
| 2 | Marko | Brateee, kad je uopce vjencanje? |
| 3 | Mario | Pa u osmom mjesecu |
| 4 | Marko | Aaaaa pa kad je osmi mjesec |
| 5 | Mario | Za dva mjeseca brt |
| 6 | Marko | Dva mjeseca?? Ima jos vremena |
| 7 | Mario | Ma dobro, ali moramo neso smisliti |
| 8 | Marko | Joj dobro ja cu organizirat. Di bi isli? |
| 9 | Mario | Ne znam brt, ti si kum, ti reci |
| 10 | Marko | Aj znas sta, nadji ti mjesto |
| 11 | Mario | Cekaj ti si kum. Ti organiziras. |
| 12 | Marko | Dobro dobro. Javim ti sutra. |
| 13 | Mario | Sutra?? Brt vrtimo se u krug. |
| 14 | Marko | Aj rijeseno. Javim ti sutra. 100%. |

**The punchline:** Marko's closing `rijeseno` maps directly onto the validator's hard-coded `resolved` state. All four proof tests pass (`required_fields_present`, `duration_plausible`, `explicit_end`, `outcome_valid`), zero shadow discrepancies, and IAMMAI admits the session and creates a Bound Vessel. The system is fully convinced the bachelor party is under control while the messages make it obvious that absolutely nothing has been planned.

**Exported slice (what IAMMAI sees):**

| Field | Value |
|---|---|
| `platform_name` | `"Momacka"` |
| `participant_count` | `2` |
| `duration_seconds` | `1800` |
| `topic` | `"Dogovor za momacku"` |
| `outcome` | `"resolved"` |
| `has_explicit_end` | `true` |

Raw messages, participant names, and metadata stay on the source side exactly as before — the slice carries only the summary fields.

### Blocked seed: `Seen`

The narrative follow-up to Momacka. Mario messages Marko again about the bachelor party and gets nothing back. The session never ends, has no outcome, no duration — and is refused at admission. The name is the joke: left on seen.

**Source object (`ExternalSession`):**
- `platform_name`: `"Seen"`
- `participants` (2): `Mario` and `Marko` — Marko must be present for the joke to work, because he has to *see* the messages to leave them on seen
- `started_at` / `ended_at`: both `2026-06-10T21:00:00Z` (identical → `has_explicit_end` evaluates false)
- `duration_seconds`: `0`
- `topic`: `"Momacka v2: sad stvarno"` (direct callback to Momacka — "Bachelor party v2: now for real")
- `outcome`: `null`
- `metadata`: `{ channel: 'group_chat', language: 'hr' }`

**Messages (2, both from Mario):**

| # | Sender | Message |
|---|---|---|
| 1 | Mario | Brt, reminder za momacku |
| 2 | Mario | Brt? |

**Why all four proofs still fail** (matching the previous Beta Legacy behavior, so the walkthrough narrative is unchanged):
1. `required_fields_present` — FAIL because `outcome` is null.
2. `duration_plausible` — FAIL because `duration_seconds` is 0.
3. `explicit_end` — FAIL because `has_explicit_end` is false.
4. `outcome_valid` — FAIL because `outcome` is null.

**Shadow discrepancies drop from 5 to 3** compared to the old Beta Legacy seed:
- `missing_value` / `outcome` (null) — still present
- `out_of_range` / `duration_seconds` (0) — still present
- `structural_difference` / `has_explicit_end` (false) — still present
- `missing_value` / `topic` — **gone**, because the topic is now non-empty
- `out_of_range` / `participant_count` — **gone**, because there are now 2 participants

The client walkthrough doc is updated to reflect `3` discrepancies instead of `5`.

## Files changed

### Backend code
- `backend/src/integrity/iammai/accession/external-simulator.ts` — rewrote `generateCleanSession()` and `generateMessySession()` with the new content. `exportSlice()` is unchanged (it is field-generic).
- `backend/src/integrity/iammai/accession/seed-cases.ts` — updated `source_name`, `source_system_ref`, `slice_name`, and the two section comments from Alpha/Beta to Momacka/Seen.

### Tests
- `backend/tests/unit/integrity/iammai/accession/external-simulator.test.ts` — updated platform/topic/duration/participant assertions. Swapped the old `messages: []` assertion for the new two-message `Seen` shape check.
- `backend/tests/unit/integrity/iammai/accession/accession-coordinator.test.ts` — updated the `cleanSliceData` and `messySliceData` fixtures to mirror the new seeds. Numeric fields now match what the seed generators actually produce.
- `backend/tests/unit/integrity/iammai/accession/accession-validator.test.ts` — same fixture update. The validator tests continue to assert "0 discrepancies for clean slice" and "all 4 proofs fail for messy slice" — both still true under the new values.
- `backend/tests/unit/integrity/iammai/accession/accession-registry.test.ts` — renamed the `SAMPLE_SOURCE` mock's `source_name` and `source_system_ref` for consistency.

### Documentation
- `docs/briefs/accession-readme.md` — updated the example exported-slice table, the two-seed comparison table, the prose walkthrough, and the Mermaid `Shadow — 5 issues` label → `Shadow — 3 issues`. Added one sentence telling the client to click into the Contact-stage inspector to read the Croatian messages, since the punchline lives in the source, not in the slice.

### Deliberately untouched
- `backend/src/integrity/iammai/accession/accession-validator.ts` — no change. `VALID_OUTCOMES` already accepts `'resolved'`.
- `backend/migrations/*` — no schema changes.
- `docs/superpowers/specs/2026-04-10-accession-layer-design.md` and `docs/superpowers/plans/2026-04-10-accession-layer.md` — historical design artifacts from the accession layer build, left alone.

## Verification

1. **Unit tests:** `cd backend && npx vitest run tests/unit/integrity/iammai/accession/` — 50 tests pass across 6 files (validator, stage-engine, registry, types, external-simulator, coordinator).
2. **Type-check:** `cd backend && npx tsc --noEmit` — no new errors in any of the files touched by this change. (Pre-existing errors exist in unrelated protocol evaluators and `resolution-engine.ts`; none of them reference accession code.)
3. **End-to-end walkthrough against the deployed admin dashboard:**
   - Log in, navigate to **Accession**, click **Reset**, then **Load Seeds**.
   - Confirm the left panel shows `Momacka` and `Seen`.
   - Advance `Momacka` through all 7 stages; click each completed stage and confirm: Contact inspector shows the 14 Croatian messages, Shadow shows 0 discrepancies, Proof shows 4/4 pass, Admission shows `ADMITTED`, Bound Vessel is created.
   - Advance `Seen` through to Admission; click each stage and confirm: Contact inspector shows Mario's two unanswered messages, Shadow shows 3 discrepancies, Proof shows 0/4 pass, Admission shows `REFUSED`, ADVANCE disables.
4. **Client-readability check:** hand `docs/briefs/accession-readme.md` to someone who has never seen IAMMAI and confirm the Momacka/Seen framing tells the joke without needing the spec.
