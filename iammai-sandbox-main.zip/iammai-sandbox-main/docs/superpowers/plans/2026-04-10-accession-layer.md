# Accession Layer Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Add a 7-stage accession layer that lets external systems lawfully approach, be inspected, and potentially be admitted into the existing IAMMAI body — with step-through admin UI.

**Architecture:** Separate 7-stage state machine (contact → bound_vessel / revoked) parallel to the existing 9-phase engine. Accession-specific tables (6 new) for external sources, slices, accession state, transitions, shadows, and proofs. Shared canonical tables (governance, witness, validation) via `matter_ref = 'bnk:accession:slice:{sliceId}'`. Two seed cases (clean/messy) demonstrate the full flow.

**Tech Stack:** TypeScript 5.x, Node.js 20 LTS, Express 4.18, PostgreSQL (pg 8.11), vitest, Next.js 14, React 18, Tailwind CSS 3.4, Framer Motion 12.x

**Spec:** `docs/superpowers/specs/2026-04-10-accession-layer-design.md`

---

## File Structure

### New Files

```
backend/migrations/008_accession_tables.sql
backend/src/integrity/iammai/accession/types.ts
backend/src/integrity/iammai/accession/stage-engine.ts
backend/src/integrity/iammai/accession/accession-registry.ts
backend/src/integrity/iammai/accession/accession-validator.ts
backend/src/integrity/iammai/accession/accession-coordinator.ts
backend/src/integrity/iammai/accession/external-simulator.ts
backend/src/integrity/iammai/accession/seed-cases.ts
backend/src/integrity/iammai/accession/index.ts
backend/src/api/routes/accession.ts
frontend/apps/admin/src/pages/accession/index.tsx
frontend/apps/admin/src/components/accession/StageTimeline.tsx
frontend/apps/admin/src/components/accession/SliceCard.tsx
frontend/apps/admin/src/components/accession/StageDetail.tsx
```

### Modified Files

```
backend/src/integrity/iammai/index.ts          — barrel export for accession
backend/src/integrity/iammai/event-bus.ts       — accession event types
backend/src/api/app.ts                          — mount accession router
frontend/apps/admin/src/components/AdminLayout.tsx — nav link
```

### Test Files

```
backend/tests/unit/integrity/iammai/accession/types.test.ts
backend/tests/unit/integrity/iammai/accession/stage-engine.test.ts
backend/tests/unit/integrity/iammai/accession/external-simulator.test.ts
backend/tests/unit/integrity/iammai/accession/accession-validator.test.ts
backend/tests/unit/integrity/iammai/accession/accession-coordinator.test.ts
```

---

### Task 1: Database Migration 008 — Accession Tables

**Files:**
- Create: `backend/migrations/008_accession_tables.sql`

- [ ] **Step 1: Write the migration SQL**

```sql
-- Accession Layer: External system approach, inspection, and admission
-- Reuses iammai_prevent_update / iammai_prevent_delete from migration 007.
-- All tables are append-only with immutability triggers.

-- ============================================================================
-- Accession Enums
-- ============================================================================

CREATE TYPE accession_stage AS ENUM (
  'contact', 'eligibility', 'shadow', 'proof', 'admission', 'bound_vessel', 'revoked'
);

CREATE TYPE accession_family AS ENUM ('pre_admission', 'post_admission');

CREATE TYPE contact_outcome AS ENUM (
  'accepted_for_observation', 'out_of_scope', 'insufficient_grounding', 'refused'
);

CREATE TYPE admission_decision AS ENUM ('admitted', 'not_yet', 'refused');

CREATE TYPE data_role AS ENUM ('source', 'exported', 'derived', 'display');

-- ============================================================================
-- 1. External Sources
-- ============================================================================

CREATE TABLE iammai_external_sources (
  source_id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  source_name VARCHAR(255) NOT NULL,
  source_system_ref VARCHAR(255) NOT NULL,
  source_data JSONB NOT NULL DEFAULT '{}',
  actor_ref VARCHAR(255) NOT NULL,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX idx_accession_source_name ON iammai_external_sources(source_name);

-- Immutability
CREATE TRIGGER trg_accession_source_no_update
  BEFORE UPDATE ON iammai_external_sources FOR EACH ROW
  EXECUTE FUNCTION iammai_prevent_update();
CREATE TRIGGER trg_accession_source_no_delete
  BEFORE DELETE ON iammai_external_sources FOR EACH ROW
  EXECUTE FUNCTION iammai_prevent_delete();

-- ============================================================================
-- 2. Exported Slices
-- ============================================================================

CREATE TABLE iammai_exported_slices (
  slice_id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  source_id UUID NOT NULL REFERENCES iammai_external_sources(source_id),
  slice_name VARCHAR(255) NOT NULL,
  slice_data JSONB NOT NULL DEFAULT '{}',
  data_role data_role NOT NULL DEFAULT 'exported',
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX idx_accession_slice_source ON iammai_exported_slices(source_id);

CREATE TRIGGER trg_accession_slice_no_update
  BEFORE UPDATE ON iammai_exported_slices FOR EACH ROW
  EXECUTE FUNCTION iammai_prevent_update();
CREATE TRIGGER trg_accession_slice_no_delete
  BEFORE DELETE ON iammai_exported_slices FOR EACH ROW
  EXECUTE FUNCTION iammai_prevent_delete();

-- ============================================================================
-- 3. Accession State Records
-- ============================================================================

CREATE TABLE iammai_accession_state_records (
  state_id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  slice_ref UUID NOT NULL REFERENCES iammai_exported_slices(slice_id),
  accession_family accession_family NOT NULL,
  accession_stage accession_stage NOT NULL,
  stage_outcome JSONB NOT NULL DEFAULT '{}',
  recorded_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  predecessor_ref UUID REFERENCES iammai_accession_state_records(state_id),
  related_governance_ref UUID REFERENCES iammai_governance_actions(governance_action_id),
  related_validation_ref UUID REFERENCES iammai_validation_artifacts(validation_id),
  related_witness_ref UUID REFERENCES iammai_witness_artifacts(witness_id)
);

CREATE INDEX idx_accession_state_slice ON iammai_accession_state_records(slice_ref);
CREATE INDEX idx_accession_state_stage ON iammai_accession_state_records(accession_stage);
CREATE INDEX idx_accession_state_recorded ON iammai_accession_state_records(recorded_at);

CREATE TRIGGER trg_accession_state_no_update
  BEFORE UPDATE ON iammai_accession_state_records FOR EACH ROW
  EXECUTE FUNCTION iammai_prevent_update();
CREATE TRIGGER trg_accession_state_no_delete
  BEFORE DELETE ON iammai_accession_state_records FOR EACH ROW
  EXECUTE FUNCTION iammai_prevent_delete();

-- ============================================================================
-- 4. Accession Transitions
-- ============================================================================

CREATE TABLE iammai_accession_transitions (
  transition_id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  slice_ref UUID NOT NULL REFERENCES iammai_exported_slices(slice_id),
  source_state_ref UUID NOT NULL REFERENCES iammai_accession_state_records(state_id),
  target_state_ref UUID NOT NULL REFERENCES iammai_accession_state_records(state_id),
  transition_type VARCHAR(100) NOT NULL,
  occurred_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX idx_accession_transition_slice ON iammai_accession_transitions(slice_ref);

CREATE TRIGGER trg_accession_transition_no_update
  BEFORE UPDATE ON iammai_accession_transitions FOR EACH ROW
  EXECUTE FUNCTION iammai_prevent_update();
CREATE TRIGGER trg_accession_transition_no_delete
  BEFORE DELETE ON iammai_accession_transitions FOR EACH ROW
  EXECUTE FUNCTION iammai_prevent_delete();

-- ============================================================================
-- 5. Shadow Records
-- ============================================================================

CREATE TABLE iammai_shadow_records (
  shadow_id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  slice_ref UUID NOT NULL REFERENCES iammai_exported_slices(slice_id),
  shadow_data JSONB NOT NULL DEFAULT '{}',
  discrepancies JSONB NOT NULL DEFAULT '[]',
  data_role data_role NOT NULL DEFAULT 'derived',
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  governance_action_ref UUID REFERENCES iammai_governance_actions(governance_action_id)
);

CREATE INDEX idx_accession_shadow_slice ON iammai_shadow_records(slice_ref);

CREATE TRIGGER trg_accession_shadow_no_update
  BEFORE UPDATE ON iammai_shadow_records FOR EACH ROW
  EXECUTE FUNCTION iammai_prevent_update();
CREATE TRIGGER trg_accession_shadow_no_delete
  BEFORE DELETE ON iammai_shadow_records FOR EACH ROW
  EXECUTE FUNCTION iammai_prevent_delete();

-- ============================================================================
-- 6. Proof Records
-- ============================================================================

CREATE TABLE iammai_proof_records (
  proof_id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  slice_ref UUID NOT NULL REFERENCES iammai_exported_slices(slice_id),
  shadow_ref UUID NOT NULL REFERENCES iammai_shadow_records(shadow_id),
  test_name VARCHAR(255) NOT NULL,
  test_result validation_outcome NOT NULL,
  test_details JSONB NOT NULL DEFAULT '{}',
  checked_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX idx_accession_proof_slice ON iammai_proof_records(slice_ref);
CREATE INDEX idx_accession_proof_shadow ON iammai_proof_records(shadow_ref);

CREATE TRIGGER trg_accession_proof_no_update
  BEFORE UPDATE ON iammai_proof_records FOR EACH ROW
  EXECUTE FUNCTION iammai_prevent_update();
CREATE TRIGGER trg_accession_proof_no_delete
  BEFORE DELETE ON iammai_proof_records FOR EACH ROW
  EXECUTE FUNCTION iammai_prevent_delete();
```

- [ ] **Step 2: Verify migration file exists**

Run: `ls -la backend/migrations/008_accession_tables.sql`
Expected: File exists with correct size

- [ ] **Step 3: Commit**

```bash
git add backend/migrations/008_accession_tables.sql
git commit -m "feat(accession): add migration 008 — accession layer tables and enums"
```

---

### Task 2: Accession Types

**Files:**
- Create: `backend/src/integrity/iammai/accession/types.ts`
- Test: `backend/tests/unit/integrity/iammai/accession/types.test.ts`

- [ ] **Step 1: Write the failing test**

```typescript
/**
 * Accession Types — Unit Tests
 */

import { describe, it, expect } from 'vitest';
import {
  ACCESSION_STAGE_ORDINAL,
  ACCESSION_STAGES_IN_ORDER,
  ACCESSION_STAGE_FAMILY,
  VALID_ACCESSION_TRANSITIONS,
  sliceMatterRef,
} from '../../../../../src/integrity/iammai/accession/types.js';
import type {
  AccessionStage,
  AccessionFamily,
  ContactOutcome,
  AdmissionDecision,
  DataRole,
} from '../../../../../src/integrity/iammai/accession/types.js';

describe('ACCESSION_STAGE_ORDINAL', () => {
  it('assigns ordinals 1-7 with no gaps', () => {
    const ordinals = Object.values(ACCESSION_STAGE_ORDINAL).sort((a, b) => a - b);
    expect(ordinals).toEqual([1, 2, 3, 4, 5, 6, 7]);
  });

  it('has exactly 7 stages', () => {
    expect(Object.keys(ACCESSION_STAGE_ORDINAL)).toHaveLength(7);
  });

  it('assigns correct ordinals', () => {
    expect(ACCESSION_STAGE_ORDINAL.contact).toBe(1);
    expect(ACCESSION_STAGE_ORDINAL.eligibility).toBe(2);
    expect(ACCESSION_STAGE_ORDINAL.shadow).toBe(3);
    expect(ACCESSION_STAGE_ORDINAL.proof).toBe(4);
    expect(ACCESSION_STAGE_ORDINAL.admission).toBe(5);
    expect(ACCESSION_STAGE_ORDINAL.bound_vessel).toBe(6);
    expect(ACCESSION_STAGE_ORDINAL.revoked).toBe(7);
  });
});

describe('ACCESSION_STAGES_IN_ORDER', () => {
  it('lists all 7 stages in canonical order', () => {
    expect(ACCESSION_STAGES_IN_ORDER).toEqual([
      'contact', 'eligibility', 'shadow', 'proof', 'admission', 'bound_vessel', 'revoked',
    ]);
  });
});

describe('ACCESSION_STAGE_FAMILY', () => {
  it('maps contact through admission to pre_admission', () => {
    expect(ACCESSION_STAGE_FAMILY.contact).toBe('pre_admission');
    expect(ACCESSION_STAGE_FAMILY.eligibility).toBe('pre_admission');
    expect(ACCESSION_STAGE_FAMILY.shadow).toBe('pre_admission');
    expect(ACCESSION_STAGE_FAMILY.proof).toBe('pre_admission');
    expect(ACCESSION_STAGE_FAMILY.admission).toBe('pre_admission');
  });

  it('maps bound_vessel and revoked to post_admission', () => {
    expect(ACCESSION_STAGE_FAMILY.bound_vessel).toBe('post_admission');
    expect(ACCESSION_STAGE_FAMILY.revoked).toBe('post_admission');
  });
});

describe('VALID_ACCESSION_TRANSITIONS', () => {
  it('allows forward progression plus revocation from each stage', () => {
    expect(VALID_ACCESSION_TRANSITIONS.contact).toContain('eligibility');
    expect(VALID_ACCESSION_TRANSITIONS.contact).toContain('revoked');
    expect(VALID_ACCESSION_TRANSITIONS.eligibility).toContain('shadow');
    expect(VALID_ACCESSION_TRANSITIONS.shadow).toContain('proof');
    expect(VALID_ACCESSION_TRANSITIONS.proof).toContain('admission');
    expect(VALID_ACCESSION_TRANSITIONS.admission).toContain('bound_vessel');
  });

  it('allows no transitions from revoked', () => {
    expect(VALID_ACCESSION_TRANSITIONS.revoked).toEqual([]);
  });

  it('allows no transitions from bound_vessel except revoked', () => {
    expect(VALID_ACCESSION_TRANSITIONS.bound_vessel).toEqual(['revoked']);
  });
});

describe('sliceMatterRef', () => {
  it('generates matter ref with bnk:accession:slice: prefix', () => {
    expect(sliceMatterRef('abc-123')).toBe('bnk:accession:slice:abc-123');
  });
});
```

- [ ] **Step 2: Run test to verify it fails**

Run: `cd backend && npx vitest run tests/unit/integrity/iammai/accession/types.test.ts`
Expected: FAIL — module not found

- [ ] **Step 3: Write the implementation**

```typescript
/**
 * Accession Layer — Type Definitions
 *
 * 7-stage accession state machine for external system approach.
 * Parallel to (NOT merged with) the 9-phase canonical engine.
 */

// ============================================================================
// Accession Stage Types
// ============================================================================

export type AccessionStage =
  | 'contact'
  | 'eligibility'
  | 'shadow'
  | 'proof'
  | 'admission'
  | 'bound_vessel'
  | 'revoked';

export type AccessionFamily = 'pre_admission' | 'post_admission';

export type ContactOutcome =
  | 'accepted_for_observation'
  | 'out_of_scope'
  | 'insufficient_grounding'
  | 'refused';

export type AdmissionDecision = 'admitted' | 'not_yet' | 'refused';

export type DataRole = 'source' | 'exported' | 'derived' | 'display';

// ============================================================================
// Stage Constants
// ============================================================================

export const ACCESSION_STAGE_ORDINAL: Record<AccessionStage, number> = {
  contact: 1,
  eligibility: 2,
  shadow: 3,
  proof: 4,
  admission: 5,
  bound_vessel: 6,
  revoked: 7,
};

export const ACCESSION_STAGES_IN_ORDER: AccessionStage[] = [
  'contact', 'eligibility', 'shadow', 'proof', 'admission', 'bound_vessel', 'revoked',
];

export const ACCESSION_STAGE_FAMILY: Record<AccessionStage, AccessionFamily> = {
  contact: 'pre_admission',
  eligibility: 'pre_admission',
  shadow: 'pre_admission',
  proof: 'pre_admission',
  admission: 'pre_admission',
  bound_vessel: 'post_admission',
  revoked: 'post_admission',
};

/** Forward progression + revocation from any post-contact stage */
export const VALID_ACCESSION_TRANSITIONS: Record<AccessionStage, AccessionStage[]> = {
  contact: ['eligibility', 'revoked'],
  eligibility: ['shadow', 'revoked'],
  shadow: ['proof', 'revoked'],
  proof: ['admission', 'revoked'],
  admission: ['bound_vessel', 'revoked'],
  bound_vessel: ['revoked'],
  revoked: [],
};

/** Transition type names for the accession state machine */
export const ACCESSION_TRANSITION_TYPES: Record<string, string> = {
  contact_to_eligibility: 'contact_to_eligibility',
  eligibility_to_shadow: 'eligibility_to_shadow',
  shadow_to_proof: 'shadow_to_proof',
  proof_to_admission: 'proof_to_admission',
  admission_to_bound_vessel: 'admission_to_bound_vessel',
  to_revoked: 'to_revoked',
};

// ============================================================================
// Record Interfaces — 6 Accession-Specific Tables
// ============================================================================

export interface ExternalSource {
  source_id: string;
  source_name: string;
  source_system_ref: string;
  source_data: Record<string, unknown>;
  actor_ref: string;
  created_at: Date;
}

export interface ExportedSlice {
  slice_id: string;
  source_id: string;
  slice_name: string;
  slice_data: Record<string, unknown>;
  data_role: DataRole;
  created_at: Date;
}

export interface AccessionStateRecord {
  state_id: string;
  slice_ref: string;
  accession_family: AccessionFamily;
  accession_stage: AccessionStage;
  stage_outcome: Record<string, unknown>;
  recorded_at: Date;
  predecessor_ref: string | null;
  related_governance_ref: string | null;
  related_validation_ref: string | null;
  related_witness_ref: string | null;
}

export interface AccessionTransition {
  transition_id: string;
  slice_ref: string;
  source_state_ref: string;
  target_state_ref: string;
  transition_type: string;
  occurred_at: Date;
}

export interface ShadowRecord {
  shadow_id: string;
  slice_ref: string;
  shadow_data: Record<string, unknown>;
  discrepancies: Array<Record<string, unknown>>;
  data_role: DataRole;
  created_at: Date;
  governance_action_ref: string | null;
}

export interface ProofRecord {
  proof_id: string;
  slice_ref: string;
  shadow_ref: string;
  test_name: string;
  test_result: 'pass' | 'fail' | 'blocked' | 'indeterminate';
  test_details: Record<string, unknown>;
  checked_at: Date;
}

// ============================================================================
// External System Interfaces (source objects — never stored directly in body)
// ============================================================================

export interface ExternalSession {
  session_id: string;
  platform_name: string;
  participants: Array<{
    id: string;
    name: string;
    role: string;
    joined_at: string;
  }>;
  started_at: string;
  ended_at: string;
  duration_seconds: number;
  messages: Array<{
    sender_id: string;
    content: string;
    sent_at: string;
  }>;
  topic: string;
  outcome: string | null;
  metadata: Record<string, unknown>;
}

export interface SessionSummarySlice {
  slice_id: string;
  source_session_ref: string;
  platform_name: string;
  participant_count: number;
  duration_seconds: number;
  topic: string;
  outcome: string | null;
  has_explicit_end: boolean;
}

// ============================================================================
// Helpers
// ============================================================================

/** Generate a matter_ref for an accession slice */
export function sliceMatterRef(sliceId: string): string {
  return `bnk:accession:slice:${sliceId}`;
}
```

- [ ] **Step 4: Run test to verify it passes**

Run: `cd backend && npx vitest run tests/unit/integrity/iammai/accession/types.test.ts`
Expected: PASS — all tests green

- [ ] **Step 5: Commit**

```bash
git add backend/src/integrity/iammai/accession/types.ts backend/tests/unit/integrity/iammai/accession/types.test.ts
git commit -m "feat(accession): add accession layer types and constants"
```

---

### Task 3: Stage Engine

**Files:**
- Create: `backend/src/integrity/iammai/accession/stage-engine.ts`
- Test: `backend/tests/unit/integrity/iammai/accession/stage-engine.test.ts`

- [ ] **Step 1: Write the failing test**

```typescript
/**
 * Accession Stage Engine — Unit Tests
 */

import { describe, it, expect } from 'vitest';
import {
  isValidAccessionTransition,
  getNextStage,
  getTransitionType,
  isPreAdmission,
  isPostAdmission,
} from '../../../../../src/integrity/iammai/accession/stage-engine.js';

describe('isValidAccessionTransition', () => {
  it('allows forward progression', () => {
    expect(isValidAccessionTransition('contact', 'eligibility')).toBe(true);
    expect(isValidAccessionTransition('eligibility', 'shadow')).toBe(true);
    expect(isValidAccessionTransition('shadow', 'proof')).toBe(true);
    expect(isValidAccessionTransition('proof', 'admission')).toBe(true);
    expect(isValidAccessionTransition('admission', 'bound_vessel')).toBe(true);
  });

  it('allows revocation from any post-contact stage', () => {
    expect(isValidAccessionTransition('contact', 'revoked')).toBe(true);
    expect(isValidAccessionTransition('eligibility', 'revoked')).toBe(true);
    expect(isValidAccessionTransition('shadow', 'revoked')).toBe(true);
    expect(isValidAccessionTransition('proof', 'revoked')).toBe(true);
    expect(isValidAccessionTransition('admission', 'revoked')).toBe(true);
    expect(isValidAccessionTransition('bound_vessel', 'revoked')).toBe(true);
  });

  it('rejects backward transitions', () => {
    expect(isValidAccessionTransition('eligibility', 'contact')).toBe(false);
    expect(isValidAccessionTransition('shadow', 'eligibility')).toBe(false);
    expect(isValidAccessionTransition('admission', 'proof')).toBe(false);
  });

  it('rejects skipping stages', () => {
    expect(isValidAccessionTransition('contact', 'shadow')).toBe(false);
    expect(isValidAccessionTransition('eligibility', 'proof')).toBe(false);
    expect(isValidAccessionTransition('contact', 'admission')).toBe(false);
  });

  it('rejects transitions from revoked', () => {
    expect(isValidAccessionTransition('revoked', 'contact')).toBe(false);
    expect(isValidAccessionTransition('revoked', 'eligibility')).toBe(false);
  });
});

describe('getNextStage', () => {
  it('returns the next forward stage', () => {
    expect(getNextStage('contact')).toBe('eligibility');
    expect(getNextStage('eligibility')).toBe('shadow');
    expect(getNextStage('shadow')).toBe('proof');
    expect(getNextStage('proof')).toBe('admission');
    expect(getNextStage('admission')).toBe('bound_vessel');
  });

  it('returns null for bound_vessel (terminal)', () => {
    expect(getNextStage('bound_vessel')).toBeNull();
  });

  it('returns null for revoked (terminal)', () => {
    expect(getNextStage('revoked')).toBeNull();
  });
});

describe('getTransitionType', () => {
  it('returns typed transition names', () => {
    expect(getTransitionType('contact', 'eligibility')).toBe('contact_to_eligibility');
    expect(getTransitionType('eligibility', 'shadow')).toBe('eligibility_to_shadow');
    expect(getTransitionType('shadow', 'proof')).toBe('shadow_to_proof');
    expect(getTransitionType('proof', 'admission')).toBe('proof_to_admission');
    expect(getTransitionType('admission', 'bound_vessel')).toBe('admission_to_bound_vessel');
  });

  it('returns to_revoked for any revocation', () => {
    expect(getTransitionType('contact', 'revoked')).toBe('to_revoked');
    expect(getTransitionType('bound_vessel', 'revoked')).toBe('to_revoked');
  });
});

describe('isPreAdmission / isPostAdmission', () => {
  it('identifies pre-admission stages', () => {
    expect(isPreAdmission('contact')).toBe(true);
    expect(isPreAdmission('eligibility')).toBe(true);
    expect(isPreAdmission('shadow')).toBe(true);
    expect(isPreAdmission('proof')).toBe(true);
    expect(isPreAdmission('admission')).toBe(true);
  });

  it('identifies post-admission stages', () => {
    expect(isPostAdmission('bound_vessel')).toBe(true);
    expect(isPostAdmission('revoked')).toBe(true);
  });

  it('pre and post are mutually exclusive', () => {
    expect(isPreAdmission('bound_vessel')).toBe(false);
    expect(isPostAdmission('contact')).toBe(false);
  });
});
```

- [ ] **Step 2: Run test to verify it fails**

Run: `cd backend && npx vitest run tests/unit/integrity/iammai/accession/stage-engine.test.ts`
Expected: FAIL — module not found

- [ ] **Step 3: Write the implementation**

```typescript
/**
 * Accession Stage Engine — 7-Stage State Machine
 *
 * Manages valid transitions, family mapping, and ordering for the
 * accession sequence. Separate from the 9-phase canonical engine.
 */

import {
  VALID_ACCESSION_TRANSITIONS,
  ACCESSION_STAGE_FAMILY,
  ACCESSION_STAGES_IN_ORDER,
} from './types.js';
import type { AccessionStage, AccessionFamily } from './types.js';

/**
 * Check if a transition between two accession stages is valid.
 * Only forward progression and revocation are allowed.
 */
export function isValidAccessionTransition(
  from: AccessionStage,
  to: AccessionStage
): boolean {
  return VALID_ACCESSION_TRANSITIONS[from].includes(to);
}

/**
 * Get the next forward stage (excludes revocation).
 * Returns null for terminal stages (bound_vessel, revoked).
 */
export function getNextStage(current: AccessionStage): AccessionStage | null {
  const idx = ACCESSION_STAGES_IN_ORDER.indexOf(current);
  // bound_vessel (index 5) and revoked (index 6) are terminal
  if (idx >= 5 || idx < 0) return null;
  return ACCESSION_STAGES_IN_ORDER[idx + 1]!;
}

/**
 * Get the typed transition name for a stage-to-stage movement.
 */
export function getTransitionType(
  from: AccessionStage,
  to: AccessionStage
): string {
  if (to === 'revoked') return 'to_revoked';
  return `${from}_to_${to}`;
}

/** Check if a stage is in the pre-admission family */
export function isPreAdmission(stage: AccessionStage): boolean {
  return ACCESSION_STAGE_FAMILY[stage] === 'pre_admission';
}

/** Check if a stage is in the post-admission family */
export function isPostAdmission(stage: AccessionStage): boolean {
  return ACCESSION_STAGE_FAMILY[stage] === 'post_admission';
}
```

- [ ] **Step 4: Run test to verify it passes**

Run: `cd backend && npx vitest run tests/unit/integrity/iammai/accession/stage-engine.test.ts`
Expected: PASS

- [ ] **Step 5: Commit**

```bash
git add backend/src/integrity/iammai/accession/stage-engine.ts backend/tests/unit/integrity/iammai/accession/stage-engine.test.ts
git commit -m "feat(accession): add 7-stage accession state machine"
```

---

### Task 4: External Simulator

**Files:**
- Create: `backend/src/integrity/iammai/accession/external-simulator.ts`
- Test: `backend/tests/unit/integrity/iammai/accession/external-simulator.test.ts`

- [ ] **Step 1: Write the failing test**

```typescript
/**
 * External Simulator — Unit Tests
 */

import { describe, it, expect } from 'vitest';
import {
  generateCleanSession,
  generateMessySession,
  exportSlice,
} from '../../../../../src/integrity/iammai/accession/external-simulator.js';

describe('generateCleanSession', () => {
  it('returns a well-formed Alpha Chat session', () => {
    const session = generateCleanSession();
    expect(session.platform_name).toBe('Alpha Chat');
    expect(session.participants.length).toBe(3);
    expect(session.duration_seconds).toBe(2700);
    expect(session.topic).toBe('Account access recovery');
    expect(session.outcome).toBe('resolved');
    expect(session.messages.length).toBeGreaterThan(0);
    expect(session.ended_at).not.toBe(session.started_at);
  });
});

describe('generateMessySession', () => {
  it('returns a degenerate Beta Legacy session', () => {
    const session = generateMessySession();
    expect(session.platform_name).toBe('Beta Legacy');
    expect(session.participants).toEqual([]);
    expect(session.duration_seconds).toBe(0);
    expect(session.topic).toBe('');
    expect(session.outcome).toBeNull();
    expect(session.messages).toEqual([]);
  });
});

describe('exportSlice', () => {
  it('exports a summary slice from a clean session', () => {
    const session = generateCleanSession();
    const slice = exportSlice(session);
    expect(slice.platform_name).toBe('Alpha Chat');
    expect(slice.participant_count).toBe(3);
    expect(slice.duration_seconds).toBe(2700);
    expect(slice.topic).toBe('Account access recovery');
    expect(slice.outcome).toBe('resolved');
    expect(slice.has_explicit_end).toBe(true);
    expect(slice.source_session_ref).toBe(session.session_id);
  });

  it('exports a summary slice from a messy session — no messages cross boundary', () => {
    const session = generateMessySession();
    const slice = exportSlice(session);
    expect(slice.platform_name).toBe('Beta Legacy');
    expect(slice.participant_count).toBe(0);
    expect(slice.duration_seconds).toBe(0);
    expect(slice.topic).toBe('');
    expect(slice.outcome).toBeNull();
    expect(slice.has_explicit_end).toBe(false);
  });

  it('never includes raw messages in the slice', () => {
    const session = generateCleanSession();
    const slice = exportSlice(session);
    const sliceStr = JSON.stringify(slice);
    for (const msg of session.messages) {
      expect(sliceStr).not.toContain(msg.content);
    }
  });
});
```

- [ ] **Step 2: Run test to verify it fails**

Run: `cd backend && npx vitest run tests/unit/integrity/iammai/accession/external-simulator.test.ts`
Expected: FAIL — module not found

- [ ] **Step 3: Write the implementation**

```typescript
/**
 * External Simulator — Generates ExternalSession + SessionSummarySlice
 *
 * Produces source objects for the two seed cases.
 * Not persisted in its own right — a data generator.
 */

import { v4 as uuidv4 } from 'uuid';
import type { ExternalSession, SessionSummarySlice } from './types.js';

/**
 * Generate the clean "Alpha Chat" session (well-formed, should pass all proofs).
 */
export function generateCleanSession(): ExternalSession {
  return {
    session_id: uuidv4(),
    platform_name: 'Alpha Chat',
    participants: [
      { id: 'u1', name: 'Alice', role: 'initiator', joined_at: '2026-04-01T10:00:00Z' },
      { id: 'u2', name: 'Bob', role: 'responder', joined_at: '2026-04-01T10:01:00Z' },
      { id: 'u3', name: 'Support Agent', role: 'agent', joined_at: '2026-04-01T10:02:00Z' },
    ],
    started_at: '2026-04-01T10:00:00Z',
    ended_at: '2026-04-01T10:45:00Z',
    duration_seconds: 2700,
    messages: [
      { sender_id: 'u1', content: 'Hi, I need help recovering my account.', sent_at: '2026-04-01T10:00:30Z' },
      { sender_id: 'u3', content: 'Sure, I can help with that. Let me look up your account.', sent_at: '2026-04-01T10:01:00Z' },
      { sender_id: 'u1', content: 'My username is alice_doe.', sent_at: '2026-04-01T10:02:00Z' },
      { sender_id: 'u3', content: 'I found your account. I will send a recovery link.', sent_at: '2026-04-01T10:05:00Z' },
      { sender_id: 'u1', content: 'Got the link, logging in now.', sent_at: '2026-04-01T10:10:00Z' },
      { sender_id: 'u2', content: 'Good to hear that is resolved.', sent_at: '2026-04-01T10:12:00Z' },
      { sender_id: 'u3', content: 'Happy to help. Anything else?', sent_at: '2026-04-01T10:15:00Z' },
      { sender_id: 'u1', content: 'No, that is all. Thanks!', sent_at: '2026-04-01T10:20:00Z' },
      { sender_id: 'u3', content: 'Great, closing this session. Have a good day!', sent_at: '2026-04-01T10:25:00Z' },
      { sender_id: 'u1', content: 'Thanks, bye!', sent_at: '2026-04-01T10:30:00Z' },
      { sender_id: 'u2', content: 'Bye!', sent_at: '2026-04-01T10:35:00Z' },
      { sender_id: 'u3', content: 'Session closed. Summary: account access recovery completed.', sent_at: '2026-04-01T10:45:00Z' },
    ],
    topic: 'Account access recovery',
    outcome: 'resolved',
    metadata: { channel: 'web', priority: 'normal' },
  };
}

/**
 * Generate the messy "Beta Legacy" session (degenerate — should fail proofs).
 */
export function generateMessySession(): ExternalSession {
  return {
    session_id: uuidv4(),
    platform_name: 'Beta Legacy',
    participants: [],
    started_at: '2026-04-01T10:00:00Z',
    ended_at: '2026-04-01T10:00:00Z',
    duration_seconds: 0,
    messages: [],
    topic: '',
    outcome: null,
    metadata: {},
  };
}

/**
 * Export a bounded summary slice from an external session.
 * Raw messages NEVER cross the boundary.
 */
export function exportSlice(session: ExternalSession): SessionSummarySlice {
  return {
    slice_id: uuidv4(),
    source_session_ref: session.session_id,
    platform_name: session.platform_name,
    participant_count: session.participants.length,
    duration_seconds: session.duration_seconds,
    topic: session.topic,
    outcome: session.outcome,
    has_explicit_end: session.ended_at !== session.started_at && session.ended_at !== '',
  };
}
```

- [ ] **Step 4: Run test to verify it passes**

Run: `cd backend && npx vitest run tests/unit/integrity/iammai/accession/external-simulator.test.ts`
Expected: PASS

- [ ] **Step 5: Commit**

```bash
git add backend/src/integrity/iammai/accession/external-simulator.ts backend/tests/unit/integrity/iammai/accession/external-simulator.test.ts
git commit -m "feat(accession): add external system simulator with clean and messy seeds"
```

---

### Task 5: Accession Registry

**Files:**
- Create: `backend/src/integrity/iammai/accession/accession-registry.ts`

- [ ] **Step 1: Write the accession registry**

```typescript
/**
 * Accession Registry — Insert/query for accession-specific tables
 *
 * All insert functions require a pg.PoolClient (transaction context).
 * All query functions use the shared pool.
 * Reuses existing IAMMAI canonical tables via matter_ref for
 * governance, witness, and validation records.
 */

import type pg from 'pg';
import { v4 as uuidv4 } from 'uuid';
import { query } from '../../../lib/db.js';
import { iammaiEventBus } from '../event-bus.js';
import type {
  ExternalSource,
  ExportedSlice,
  AccessionStateRecord,
  AccessionTransition,
  ShadowRecord,
  ProofRecord,
  AccessionStage,
  DataRole,
} from './types.js';

// ============================================================================
// Insert Functions
// ============================================================================

export async function insertExternalSource(
  client: pg.PoolClient,
  source: ExternalSource
): Promise<ExternalSource> {
  await client.query(
    `INSERT INTO iammai_external_sources
     (source_id, source_name, source_system_ref, source_data, actor_ref, created_at)
     VALUES ($1, $2, $3, $4, $5, $6)`,
    [source.source_id, source.source_name, source.source_system_ref,
     JSON.stringify(source.source_data), source.actor_ref, source.created_at]
  );
  return source;
}

export async function insertExportedSlice(
  client: pg.PoolClient,
  slice: ExportedSlice
): Promise<ExportedSlice> {
  await client.query(
    `INSERT INTO iammai_exported_slices
     (slice_id, source_id, slice_name, slice_data, data_role, created_at)
     VALUES ($1, $2, $3, $4, $5, $6)`,
    [slice.slice_id, slice.source_id, slice.slice_name,
     JSON.stringify(slice.slice_data), slice.data_role, slice.created_at]
  );
  return slice;
}

export async function insertAccessionState(
  client: pg.PoolClient,
  record: AccessionStateRecord
): Promise<AccessionStateRecord> {
  await client.query(
    `INSERT INTO iammai_accession_state_records
     (state_id, slice_ref, accession_family, accession_stage, stage_outcome,
      recorded_at, predecessor_ref, related_governance_ref, related_validation_ref, related_witness_ref)
     VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10)`,
    [record.state_id, record.slice_ref, record.accession_family, record.accession_stage,
     JSON.stringify(record.stage_outcome), record.recorded_at, record.predecessor_ref,
     record.related_governance_ref, record.related_validation_ref, record.related_witness_ref]
  );
  iammaiEventBus.emitRecord('accession_stage_change', record as unknown as Record<string, unknown>);
  return record;
}

export async function insertAccessionTransition(
  client: pg.PoolClient,
  transition: AccessionTransition
): Promise<AccessionTransition> {
  await client.query(
    `INSERT INTO iammai_accession_transitions
     (transition_id, slice_ref, source_state_ref, target_state_ref, transition_type, occurred_at)
     VALUES ($1, $2, $3, $4, $5, $6)`,
    [transition.transition_id, transition.slice_ref, transition.source_state_ref,
     transition.target_state_ref, transition.transition_type, transition.occurred_at]
  );
  return transition;
}

export async function insertShadowRecord(
  client: pg.PoolClient,
  shadow: ShadowRecord
): Promise<ShadowRecord> {
  await client.query(
    `INSERT INTO iammai_shadow_records
     (shadow_id, slice_ref, shadow_data, discrepancies, data_role, created_at, governance_action_ref)
     VALUES ($1, $2, $3, $4, $5, $6, $7)`,
    [shadow.shadow_id, shadow.slice_ref, JSON.stringify(shadow.shadow_data),
     JSON.stringify(shadow.discrepancies), shadow.data_role, shadow.created_at,
     shadow.governance_action_ref]
  );
  return shadow;
}

export async function insertProofRecord(
  client: pg.PoolClient,
  proof: ProofRecord
): Promise<ProofRecord> {
  await client.query(
    `INSERT INTO iammai_proof_records
     (proof_id, slice_ref, shadow_ref, test_name, test_result, test_details, checked_at)
     VALUES ($1, $2, $3, $4, $5, $6, $7)`,
    [proof.proof_id, proof.slice_ref, proof.shadow_ref, proof.test_name,
     proof.test_result, JSON.stringify(proof.test_details), proof.checked_at]
  );
  return proof;
}

// ============================================================================
// Query Functions
// ============================================================================

export async function getExternalSources(): Promise<ExternalSource[]> {
  const result = await query<ExternalSource>(
    `SELECT * FROM iammai_external_sources ORDER BY created_at ASC`
  );
  return result.rows;
}

export async function getExportedSlices(): Promise<ExportedSlice[]> {
  const result = await query<ExportedSlice>(
    `SELECT * FROM iammai_exported_slices ORDER BY created_at ASC`
  );
  return result.rows;
}

export async function getExportedSlice(sliceId: string): Promise<ExportedSlice | null> {
  const result = await query<ExportedSlice>(
    `SELECT * FROM iammai_exported_slices WHERE slice_id = $1`,
    [sliceId]
  );
  return result.rows[0] ?? null;
}

export async function getAccessionStatesBySlice(sliceRef: string): Promise<AccessionStateRecord[]> {
  const result = await query<AccessionStateRecord>(
    `SELECT * FROM iammai_accession_state_records WHERE slice_ref = $1 ORDER BY recorded_at ASC`,
    [sliceRef]
  );
  return result.rows;
}

export async function getCurrentAccessionStage(sliceRef: string): Promise<AccessionStage | null> {
  const result = await query<{ accession_stage: AccessionStage }>(
    `SELECT accession_stage FROM iammai_accession_state_records
     WHERE slice_ref = $1 ORDER BY recorded_at DESC LIMIT 1`,
    [sliceRef]
  );
  return result.rows[0]?.accession_stage ?? null;
}

export async function getAccessionTransitionsBySlice(sliceRef: string): Promise<AccessionTransition[]> {
  const result = await query<AccessionTransition>(
    `SELECT * FROM iammai_accession_transitions WHERE slice_ref = $1 ORDER BY occurred_at ASC`,
    [sliceRef]
  );
  return result.rows;
}

export async function getShadowRecordsBySlice(sliceRef: string): Promise<ShadowRecord[]> {
  const result = await query<ShadowRecord>(
    `SELECT * FROM iammai_shadow_records WHERE slice_ref = $1 ORDER BY created_at ASC`,
    [sliceRef]
  );
  return result.rows;
}

export async function getProofRecordsBySlice(sliceRef: string): Promise<ProofRecord[]> {
  const result = await query<ProofRecord>(
    `SELECT * FROM iammai_proof_records WHERE slice_ref = $1 ORDER BY checked_at ASC`,
    [sliceRef]
  );
  return result.rows;
}

/**
 * Get full accession context for a slice — all records needed for inspection.
 */
export async function loadAccessionContext(sliceRef: string) {
  const [slice, states, transitions, shadows, proofs] = await Promise.all([
    getExportedSlice(sliceRef),
    getAccessionStatesBySlice(sliceRef),
    getAccessionTransitionsBySlice(sliceRef),
    getShadowRecordsBySlice(sliceRef),
    getProofRecordsBySlice(sliceRef),
  ]);
  return { slice, states, transitions, shadows, proofs };
}

/**
 * List slices with their current accession stage.
 */
export async function listSlicesWithStage(): Promise<Array<ExportedSlice & { current_stage: AccessionStage | null; source_name: string }>> {
  const result = await query<ExportedSlice & { current_stage: AccessionStage | null; source_name: string }>(
    `SELECT es.*,
       (SELECT asr.accession_stage FROM iammai_accession_state_records asr
        WHERE asr.slice_ref = es.slice_id ORDER BY asr.recorded_at DESC LIMIT 1) AS current_stage,
       xs.source_name
     FROM iammai_exported_slices es
     JOIN iammai_external_sources xs ON xs.source_id = es.source_id
     ORDER BY es.created_at ASC`
  );
  return result.rows;
}

// ============================================================================
// Reset (for seed management — truncates accession tables only)
// ============================================================================

export async function resetAccessionTables(client: pg.PoolClient): Promise<void> {
  // Must disable triggers temporarily for truncation
  await client.query('SET session_replication_role = replica');
  await client.query('TRUNCATE iammai_proof_records CASCADE');
  await client.query('TRUNCATE iammai_shadow_records CASCADE');
  await client.query('TRUNCATE iammai_accession_transitions CASCADE');
  await client.query('TRUNCATE iammai_accession_state_records CASCADE');
  await client.query('TRUNCATE iammai_exported_slices CASCADE');
  await client.query('TRUNCATE iammai_external_sources CASCADE');
  await client.query('SET session_replication_role = DEFAULT');
}
```

- [ ] **Step 2: Commit**

```bash
git add backend/src/integrity/iammai/accession/accession-registry.ts
git commit -m "feat(accession): add accession registry — insert/query for 6 accession tables"
```

---

### Task 6: Accession Validator

**Files:**
- Create: `backend/src/integrity/iammai/accession/accession-validator.ts`
- Test: `backend/tests/unit/integrity/iammai/accession/accession-validator.test.ts`

- [ ] **Step 1: Write the failing test**

```typescript
/**
 * Accession Validator — Unit Tests
 */

import { describe, it, expect } from 'vitest';
import {
  checkEligibility,
  buildShadow,
  runProofTests,
  makeAdmissionDecision,
} from '../../../../../src/integrity/iammai/accession/accession-validator.js';
import type { SessionSummarySlice, ExportedSlice } from '../../../../../src/integrity/iammai/accession/types.js';

const cleanSliceData: SessionSummarySlice = {
  slice_id: 'clean-slice',
  source_session_ref: 'clean-session',
  platform_name: 'Alpha Chat',
  participant_count: 3,
  duration_seconds: 2700,
  topic: 'Account access recovery',
  outcome: 'resolved',
  has_explicit_end: true,
};

const messySliceData: SessionSummarySlice = {
  slice_id: 'messy-slice',
  source_session_ref: 'messy-session',
  platform_name: 'Beta Legacy',
  participant_count: 0,
  duration_seconds: 0,
  topic: '',
  outcome: null,
  has_explicit_end: false,
};

const makeExportedSlice = (data: SessionSummarySlice): ExportedSlice => ({
  slice_id: data.slice_id,
  source_id: 'source-1',
  slice_name: data.platform_name,
  slice_data: data as unknown as Record<string, unknown>,
  data_role: 'exported',
  created_at: new Date(),
});

describe('checkEligibility', () => {
  it('passes for clean slice', () => {
    const result = checkEligibility(makeExportedSlice(cleanSliceData));
    expect(result.passed).toBe(true);
    expect(result.conditions.every(c => c.passed)).toBe(true);
  });

  it('passes for messy slice (eligibility only checks existence, not quality)', () => {
    const result = checkEligibility(makeExportedSlice(messySliceData));
    expect(result.passed).toBe(true);
  });
});

describe('buildShadow', () => {
  it('returns no discrepancies for clean slice', () => {
    const shadow = buildShadow(cleanSliceData);
    expect(shadow.discrepancies).toHaveLength(0);
  });

  it('identifies discrepancies for messy slice', () => {
    const shadow = buildShadow(messySliceData);
    expect(shadow.discrepancies.length).toBeGreaterThan(0);
    const types = shadow.discrepancies.map(d => d['type']);
    expect(types).toContain('missing_value');
    expect(types).toContain('out_of_range');
  });
});

describe('runProofTests', () => {
  it('all pass for clean slice', () => {
    const shadow = buildShadow(cleanSliceData);
    const proofs = runProofTests(cleanSliceData, shadow);
    expect(proofs.every(p => p.result === 'pass')).toBe(true);
    expect(proofs.length).toBe(4);
  });

  it('some fail for messy slice', () => {
    const shadow = buildShadow(messySliceData);
    const proofs = runProofTests(messySliceData, shadow);
    expect(proofs.some(p => p.result === 'fail')).toBe(true);
  });

  it('checks required_fields_present', () => {
    const shadow = buildShadow(messySliceData);
    const proofs = runProofTests(messySliceData, shadow);
    const reqFields = proofs.find(p => p.test_name === 'required_fields_present');
    expect(reqFields).toBeDefined();
    expect(reqFields!.result).toBe('fail');
  });

  it('checks duration_plausible', () => {
    const shadow = buildShadow(messySliceData);
    const proofs = runProofTests(messySliceData, shadow);
    const dur = proofs.find(p => p.test_name === 'duration_plausible');
    expect(dur).toBeDefined();
    expect(dur!.result).toBe('fail');
  });

  it('checks explicit_end', () => {
    const shadow = buildShadow(messySliceData);
    const proofs = runProofTests(messySliceData, shadow);
    const end = proofs.find(p => p.test_name === 'explicit_end');
    expect(end).toBeDefined();
    expect(end!.result).toBe('fail');
  });

  it('checks outcome_valid', () => {
    const shadow = buildShadow(messySliceData);
    const proofs = runProofTests(messySliceData, shadow);
    const out = proofs.find(p => p.test_name === 'outcome_valid');
    expect(out).toBeDefined();
    expect(out!.result).toBe('fail');
  });
});

describe('makeAdmissionDecision', () => {
  it('admits when all proofs pass', () => {
    const proofs = [
      { test_name: 'a', result: 'pass' as const, details: {} },
      { test_name: 'b', result: 'pass' as const, details: {} },
    ];
    expect(makeAdmissionDecision(proofs)).toBe('admitted');
  });

  it('refuses when any proof fails', () => {
    const proofs = [
      { test_name: 'a', result: 'pass' as const, details: {} },
      { test_name: 'b', result: 'fail' as const, details: {} },
    ];
    expect(makeAdmissionDecision(proofs)).toBe('refused');
  });

  it('defers when any proof is indeterminate and none fail', () => {
    const proofs = [
      { test_name: 'a', result: 'pass' as const, details: {} },
      { test_name: 'b', result: 'indeterminate' as const, details: {} },
    ];
    expect(makeAdmissionDecision(proofs)).toBe('not_yet');
  });
});
```

- [ ] **Step 2: Run test to verify it fails**

Run: `cd backend && npx vitest run tests/unit/integrity/iammai/accession/accession-validator.test.ts`
Expected: FAIL — module not found

- [ ] **Step 3: Write the implementation**

```typescript
/**
 * Accession Validator — Stage transition validation, eligibility checks, proof tests
 *
 * Pure validation logic. Does NOT exercise governance force.
 */

import type {
  ExportedSlice,
  SessionSummarySlice,
  AdmissionDecision,
} from './types.js';

// ============================================================================
// Eligibility Check (Stage 2)
// ============================================================================

interface EligibilityCondition {
  name: string;
  description: string;
  passed: boolean;
}

interface EligibilityResult {
  passed: boolean;
  conditions: EligibilityCondition[];
}

/**
 * Check minimal candidacy conditions.
 * Eligibility checks that the slice EXISTS and is bounded — not quality.
 */
export function checkEligibility(slice: ExportedSlice): EligibilityResult {
  const conditions: EligibilityCondition[] = [
    {
      name: 'bounded_slice_named',
      description: 'One bounded slice is named (not whole-system)',
      passed: !!slice.slice_id && !!slice.slice_name,
    },
    {
      name: 'source_visibility',
      description: 'Source visibility is possible (can trace back to external session)',
      passed: !!slice.source_id,
    },
    {
      name: 'roles_distinguishable',
      description: 'Roles are distinguishable (source/exported/derived not fused)',
      passed: slice.data_role === 'exported',
    },
    {
      name: 'bounded_inspection_possible',
      description: 'Bounded inspection is possible',
      passed: slice.slice_data !== null && typeof slice.slice_data === 'object',
    },
  ];

  return {
    passed: conditions.every(c => c.passed),
    conditions,
  };
}

// ============================================================================
// Shadow Builder (Stage 3)
// ============================================================================

interface ShadowResult {
  shadow_data: Record<string, unknown>;
  discrepancies: Array<Record<string, unknown>>;
}

/**
 * Create a non-native mirror of the slice and compare against body standards.
 */
export function buildShadow(sliceData: SessionSummarySlice): ShadowResult {
  const shadow_data: Record<string, unknown> = { ...sliceData };
  const discrepancies: Array<Record<string, unknown>> = [];

  // Check for missing fields the body would expect
  if (!sliceData.topic || sliceData.topic.trim() === '') {
    discrepancies.push({
      type: 'missing_value',
      field: 'topic',
      expected: 'non-empty string',
      actual: sliceData.topic,
    });
  }

  if (sliceData.outcome === null || sliceData.outcome === undefined) {
    discrepancies.push({
      type: 'missing_value',
      field: 'outcome',
      expected: 'one of: resolved, abandoned, escalated, expired',
      actual: null,
    });
  }

  if (sliceData.participant_count === 0) {
    discrepancies.push({
      type: 'out_of_range',
      field: 'participant_count',
      expected: '> 0',
      actual: 0,
    });
  }

  // Check values outside expected ranges
  if (sliceData.duration_seconds <= 0) {
    discrepancies.push({
      type: 'out_of_range',
      field: 'duration_seconds',
      expected: '> 0 and < 86400',
      actual: sliceData.duration_seconds,
    });
  } else if (sliceData.duration_seconds >= 86400) {
    discrepancies.push({
      type: 'out_of_range',
      field: 'duration_seconds',
      expected: '> 0 and < 86400',
      actual: sliceData.duration_seconds,
    });
  }

  if (!sliceData.has_explicit_end) {
    discrepancies.push({
      type: 'structural_difference',
      field: 'has_explicit_end',
      expected: true,
      actual: false,
    });
  }

  return { shadow_data, discrepancies };
}

// ============================================================================
// Proof Tests (Stage 4)
// ============================================================================

const VALID_OUTCOMES = ['resolved', 'abandoned', 'escalated', 'expired'];

interface ProofTestResult {
  test_name: string;
  result: 'pass' | 'fail' | 'blocked' | 'indeterminate';
  details: Record<string, unknown>;
}

/**
 * Run bounded proof tests against the shadow.
 * Each test produces a typed result.
 */
export function runProofTests(
  sliceData: SessionSummarySlice,
  shadow: ShadowResult
): ProofTestResult[] {
  return [
    {
      test_name: 'required_fields_present',
      result: (sliceData.participant_count > 0 && sliceData.topic.trim() !== '' && sliceData.outcome !== null)
        ? 'pass' : 'fail',
      details: {
        participant_count: sliceData.participant_count,
        topic_present: sliceData.topic.trim() !== '',
        outcome_present: sliceData.outcome !== null,
      },
    },
    {
      test_name: 'duration_plausible',
      result: (sliceData.duration_seconds > 0 && sliceData.duration_seconds < 86400)
        ? 'pass' : 'fail',
      details: {
        duration_seconds: sliceData.duration_seconds,
        min: 1,
        max: 86399,
      },
    },
    {
      test_name: 'explicit_end',
      result: sliceData.has_explicit_end ? 'pass' : 'fail',
      details: {
        has_explicit_end: sliceData.has_explicit_end,
      },
    },
    {
      test_name: 'outcome_valid',
      result: (sliceData.outcome !== null && VALID_OUTCOMES.includes(sliceData.outcome))
        ? 'pass' : 'fail',
      details: {
        outcome: sliceData.outcome,
        valid_outcomes: VALID_OUTCOMES,
      },
    },
  ];
}

// ============================================================================
// Admission Decision (Stage 5)
// ============================================================================

/**
 * Make admission decision based on proof results.
 */
export function makeAdmissionDecision(
  proofs: Array<{ test_name: string; result: 'pass' | 'fail' | 'blocked' | 'indeterminate'; details: Record<string, unknown> }>
): AdmissionDecision {
  const hasFail = proofs.some(p => p.result === 'fail');
  if (hasFail) return 'refused';

  const hasIndeterminate = proofs.some(p => p.result === 'indeterminate' || p.result === 'blocked');
  if (hasIndeterminate) return 'not_yet';

  return 'admitted';
}
```

- [ ] **Step 4: Run test to verify it passes**

Run: `cd backend && npx vitest run tests/unit/integrity/iammai/accession/accession-validator.test.ts`
Expected: PASS

- [ ] **Step 5: Commit**

```bash
git add backend/src/integrity/iammai/accession/accession-validator.ts backend/tests/unit/integrity/iammai/accession/accession-validator.test.ts
git commit -m "feat(accession): add accession validator — eligibility, shadow, proof, admission"
```

---

### Task 7: Accession Coordinator

**Files:**
- Create: `backend/src/integrity/iammai/accession/accession-coordinator.ts`
- Test: `backend/tests/unit/integrity/iammai/accession/accession-coordinator.test.ts`

- [ ] **Step 1: Write the failing test**

```typescript
/**
 * Accession Coordinator — Unit Tests
 *
 * Tests the stage advancement orchestration logic without DB.
 * Verifies the coordinator calls the right sequence: Validate -> Witness -> Govern -> Advance.
 */

import { describe, it, expect } from 'vitest';
import {
  determineContactOutcome,
  buildStageOutcome,
} from '../../../../../src/integrity/iammai/accession/accession-coordinator.js';
import type { SessionSummarySlice } from '../../../../../src/integrity/iammai/accession/types.js';

const cleanSliceData: SessionSummarySlice = {
  slice_id: 'clean-slice',
  source_session_ref: 'clean-session',
  platform_name: 'Alpha Chat',
  participant_count: 3,
  duration_seconds: 2700,
  topic: 'Account access recovery',
  outcome: 'resolved',
  has_explicit_end: true,
};

const messySliceData: SessionSummarySlice = {
  slice_id: 'messy-slice',
  source_session_ref: 'messy-session',
  platform_name: 'Beta Legacy',
  participant_count: 0,
  duration_seconds: 0,
  topic: '',
  outcome: null,
  has_explicit_end: false,
};

describe('determineContactOutcome', () => {
  it('accepts well-formed slices for observation', () => {
    expect(determineContactOutcome(cleanSliceData)).toBe('accepted_for_observation');
  });

  it('accepts degenerate slices for observation (contact does not judge quality)', () => {
    expect(determineContactOutcome(messySliceData)).toBe('accepted_for_observation');
  });
});

describe('buildStageOutcome', () => {
  it('builds contact outcome', () => {
    const outcome = buildStageOutcome('contact', { contact_outcome: 'accepted_for_observation' });
    expect(outcome['contact_outcome']).toBe('accepted_for_observation');
  });

  it('builds eligibility outcome with conditions', () => {
    const outcome = buildStageOutcome('eligibility', {
      passed: true,
      conditions: [{ name: 'test', passed: true }],
    });
    expect(outcome['passed']).toBe(true);
  });

  it('builds admission outcome with decision', () => {
    const outcome = buildStageOutcome('admission', { decision: 'admitted' });
    expect(outcome['decision']).toBe('admitted');
  });
});
```

- [ ] **Step 2: Run test to verify it fails**

Run: `cd backend && npx vitest run tests/unit/integrity/iammai/accession/accession-coordinator.test.ts`
Expected: FAIL — module not found

- [ ] **Step 3: Write the implementation**

```typescript
/**
 * Accession Coordinator — Orchestrates stage advancement
 *
 * Coordination sequence: Validate -> Witness -> Govern -> Advance -> Persist
 * Reuses existing IAMMAI governor, witness-factory, and validator.
 */

import type pg from 'pg';
import { v4 as uuidv4 } from 'uuid';
import { transaction } from '../../../lib/db.js';
import { recordGovernanceAction } from '../governor.js';
import { emitIammaiWitness } from '../witness-factory.js';
import { isValidAccessionTransition, getNextStage, getTransitionType } from './stage-engine.js';
import { checkEligibility, buildShadow, runProofTests, makeAdmissionDecision } from './accession-validator.js';
import {
  insertAccessionState,
  insertAccessionTransition,
  insertShadowRecord,
  insertProofRecord,
  getAccessionStatesBySlice,
  getExportedSlice,
  insertExternalSource,
  insertExportedSlice,
} from './accession-registry.js';
import { ACCESSION_STAGE_FAMILY, sliceMatterRef } from './types.js';
import type {
  AccessionStage,
  AccessionStateRecord,
  AccessionTransition,
  ContactOutcome,
  AdmissionDecision,
  ExternalSource,
  ExportedSlice,
  SessionSummarySlice,
  ShadowRecord,
  ProofRecord,
} from './types.js';

// ============================================================================
// Pure helpers (testable without DB)
// ============================================================================

/**
 * Determine the contact outcome for a slice.
 * Contact accepts for observation if a bounded slice is presented.
 * Contact does NOT judge quality — that is eligibility/proof's job.
 */
export function determineContactOutcome(
  sliceData: SessionSummarySlice
): ContactOutcome {
  // If we can identify the source and the platform, accept for observation
  if (sliceData.source_session_ref && sliceData.platform_name) {
    return 'accepted_for_observation';
  }
  return 'insufficient_grounding';
}

/**
 * Build a stage_outcome JSONB value.
 */
export function buildStageOutcome(
  stage: AccessionStage,
  data: Record<string, unknown>
): Record<string, unknown> {
  return { stage, ...data };
}

// ============================================================================
// Stage Advancement Result
// ============================================================================

export interface StageAdvanceResult {
  stateRecord: AccessionStateRecord;
  transitionRecord: AccessionTransition | null;
  governanceActionId: string;
  witnessArtifactId: string;
  validationArtifactId: string | null;
  stageSpecificRecords: {
    shadow?: ShadowRecord;
    proofs?: ProofRecord[];
    admissionDecision?: AdmissionDecision;
  };
}

// ============================================================================
// Advance to Next Stage
// ============================================================================

/**
 * Advance a slice to the next accession stage.
 * Orchestrates: Validate -> Witness -> Govern -> Advance -> Persist
 */
export async function advanceSlice(
  sliceId: string,
  actorRef: string
): Promise<StageAdvanceResult> {
  return transaction(async (client) => {
    // 1. Load current state
    const slice = await getExportedSlice(sliceId);
    if (!slice) throw new Error(`Slice ${sliceId} not found`);

    const states = await getAccessionStatesBySlice(sliceId);
    const currentState = states[states.length - 1];
    if (!currentState) throw new Error(`No state records found for slice ${sliceId}`);

    const currentStage = currentState.accession_stage;
    const nextStage = getNextStage(currentStage);
    if (!nextStage) throw new Error(`Slice ${sliceId} is at terminal stage ${currentStage}`);

    if (!isValidAccessionTransition(currentStage, nextStage)) {
      throw new Error(`Invalid transition: ${currentStage} -> ${nextStage}`);
    }

    // Defensive: block advancement past refused admission
    if (nextStage === 'bound_vessel') {
      const admissionState = states.find(s => s.accession_stage === 'admission');
      const decision = (admissionState?.stage_outcome as Record<string, unknown>)?.['decision'];
      if (decision !== 'admitted') {
        throw new Error(`Cannot advance to bound_vessel: admission decision was '${decision}', not 'admitted'`);
      }
    }

    const matterRef = sliceMatterRef(sliceId);
    const sliceData = slice.slice_data as unknown as SessionSummarySlice;

    // 2. Run stage-specific logic to produce outcome + records
    let stageOutcome: Record<string, unknown> = {};
    let validationArtifactId: string | null = null;
    const stageSpecificRecords: StageAdvanceResult['stageSpecificRecords'] = {};

    switch (nextStage) {
      case 'eligibility': {
        const eligibility = checkEligibility(slice);
        stageOutcome = buildStageOutcome('eligibility', {
          passed: eligibility.passed,
          conditions: eligibility.conditions,
        });
        // Create validation artifact via shared table
        const valArtifact = await emitIammaiWitness(client, {
          witness_type: 'validation',
          target_ref: matterRef,
          claims: [
            `eligibility_check:${eligibility.passed ? 'pass' : 'fail'}`,
            ...eligibility.conditions.map(c => `condition:${c.name}:${c.passed ? 'pass' : 'fail'}`),
          ],
          actor_ref: actorRef,
          surface_ref: 'accession-coordinator',
        });
        validationArtifactId = valArtifact.witness_id;
        break;
      }

      case 'shadow': {
        const shadow = buildShadow(sliceData);
        const shadowRecord: ShadowRecord = {
          shadow_id: uuidv4(),
          slice_ref: sliceId,
          shadow_data: shadow.shadow_data,
          discrepancies: shadow.discrepancies,
          data_role: 'derived',
          created_at: new Date(),
          governance_action_ref: null, // set after governance action
        };
        await insertShadowRecord(client, shadowRecord);
        stageSpecificRecords.shadow = shadowRecord;
        stageOutcome = buildStageOutcome('shadow', {
          discrepancy_count: shadow.discrepancies.length,
          discrepancies: shadow.discrepancies,
        });
        break;
      }

      case 'proof': {
        // Get the shadow for this slice
        const shadowResult = await client.query<ShadowRecord>(
          `SELECT * FROM iammai_shadow_records WHERE slice_ref = $1 ORDER BY created_at DESC LIMIT 1`,
          [sliceId]
        );
        const shadowRecord = shadowResult.rows[0];
        if (!shadowRecord) throw new Error(`No shadow record found for slice ${sliceId}`);

        const proofResults = runProofTests(sliceData, {
          shadow_data: shadowRecord.shadow_data as Record<string, unknown>,
          discrepancies: shadowRecord.discrepancies as Array<Record<string, unknown>>,
        });

        const proofRecords: ProofRecord[] = [];
        for (const proof of proofResults) {
          const proofRecord: ProofRecord = {
            proof_id: uuidv4(),
            slice_ref: sliceId,
            shadow_ref: shadowRecord.shadow_id,
            test_name: proof.test_name,
            test_result: proof.result,
            test_details: proof.details,
            checked_at: new Date(),
          };
          await insertProofRecord(client, proofRecord);
          proofRecords.push(proofRecord);
        }
        stageSpecificRecords.proofs = proofRecords;
        stageOutcome = buildStageOutcome('proof', {
          test_count: proofResults.length,
          pass_count: proofResults.filter(p => p.result === 'pass').length,
          fail_count: proofResults.filter(p => p.result === 'fail').length,
          tests: proofResults,
        });
        break;
      }

      case 'admission': {
        // Get proof records for decision
        const proofsResult = await client.query<ProofRecord>(
          `SELECT * FROM iammai_proof_records WHERE slice_ref = $1 ORDER BY checked_at ASC`,
          [sliceId]
        );
        const proofs = proofsResult.rows;
        const decision = makeAdmissionDecision(
          proofs.map(p => ({ test_name: p.test_name, result: p.test_result, details: p.test_details as Record<string, unknown> }))
        );
        stageSpecificRecords.admissionDecision = decision;
        stageOutcome = buildStageOutcome('admission', {
          decision,
          proof_count: proofs.length,
          failed_proofs: proofs.filter(p => p.test_result === 'fail').map(p => p.test_name),
        });
        break;
      }

      case 'bound_vessel': {
        // Verify admission was 'admitted'
        const admissionState = states.find(s => s.accession_stage === 'admission');
        const admissionOutcome = admissionState?.stage_outcome as Record<string, unknown> | undefined;
        if (admissionOutcome?.['decision'] !== 'admitted') {
          throw new Error(`Cannot create bound vessel: admission decision was ${admissionOutcome?.['decision']}, not 'admitted'`);
        }
        stageOutcome = buildStageOutcome('bound_vessel', {
          vessel_type: 'derivative',
          permissions: ['read'],
          constraints: ['non-native', 'no-standing-state', 'no-governance', 'no-canonical-source'],
        });
        break;
      }

      default:
        stageOutcome = buildStageOutcome(nextStage, {});
    }

    // 3. Govern — record governance action via shared table
    const governanceAction = await recordGovernanceAction(client, {
      action_type: 'authorize',
      authority_class: 'OPERATOR',
      actor_ref: actorRef,
      legitimacy_basis_ref: `accession:${currentStage}_to_${nextStage}`,
      matter_ref: matterRef,
    });

    // 4. Witness — emit with mandatory non-claims
    const witness = await emitIammaiWitness(client, {
      witness_type: 'transition',
      target_ref: matterRef,
      claims: [
        `accession_stage_transition:${currentStage}_to_${nextStage}`,
        `actor:${actorRef}`,
        `slice:${sliceId}`,
      ],
      actor_ref: actorRef,
      surface_ref: 'accession-coordinator',
    });

    // 5. Create new state record
    const newState: AccessionStateRecord = {
      state_id: uuidv4(),
      slice_ref: sliceId,
      accession_family: ACCESSION_STAGE_FAMILY[nextStage],
      accession_stage: nextStage,
      stage_outcome: stageOutcome,
      recorded_at: new Date(),
      predecessor_ref: currentState.state_id,
      related_governance_ref: governanceAction.governance_action_id,
      related_validation_ref: validationArtifactId,
      related_witness_ref: witness.witness_id,
    };
    await insertAccessionState(client, newState);

    // 6. Create transition record
    const transitionRecord: AccessionTransition = {
      transition_id: uuidv4(),
      slice_ref: sliceId,
      source_state_ref: currentState.state_id,
      target_state_ref: newState.state_id,
      transition_type: getTransitionType(currentStage, nextStage),
      occurred_at: new Date(),
    };
    await insertAccessionTransition(client, transitionRecord);

    return {
      stateRecord: newState,
      transitionRecord,
      governanceActionId: governanceAction.governance_action_id,
      witnessArtifactId: witness.witness_id,
      validationArtifactId,
      stageSpecificRecords,
    };
  });
}

// ============================================================================
// Seed Loading
// ============================================================================

/**
 * Load seed cases: create external source + exported slice + initial Contact state.
 */
export async function seedSlice(
  client: pg.PoolClient,
  source: ExternalSource,
  slice: ExportedSlice,
  sliceData: SessionSummarySlice,
  actorRef: string
): Promise<AccessionStateRecord> {
  await insertExternalSource(client, source);
  await insertExportedSlice(client, slice);

  const matterRef = sliceMatterRef(slice.slice_id);
  const contactOutcome = determineContactOutcome(sliceData);

  // Govern
  const governanceAction = await recordGovernanceAction(client, {
    action_type: 'authorize',
    authority_class: 'OPERATOR',
    actor_ref: actorRef,
    legitimacy_basis_ref: 'accession:initial_contact',
    matter_ref: matterRef,
  });

  // Witness
  const witness = await emitIammaiWitness(client, {
    witness_type: 'interaction',
    target_ref: matterRef,
    claims: [
      `contact_initiated:${slice.slice_id}`,
      `contact_outcome:${contactOutcome}`,
      `source:${source.source_name}`,
      `actor:${actorRef}`,
    ],
    actor_ref: actorRef,
    surface_ref: 'accession-coordinator',
  });

  // Create initial Contact state
  const contactState: AccessionStateRecord = {
    state_id: uuidv4(),
    slice_ref: slice.slice_id,
    accession_family: 'pre_admission',
    accession_stage: 'contact',
    stage_outcome: buildStageOutcome('contact', { contact_outcome: contactOutcome }),
    recorded_at: new Date(),
    predecessor_ref: null,
    related_governance_ref: governanceAction.governance_action_id,
    related_validation_ref: null,
    related_witness_ref: witness.witness_id,
  };
  await insertAccessionState(client, contactState);

  return contactState;
}
```

- [ ] **Step 4: Run test to verify it passes**

Run: `cd backend && npx vitest run tests/unit/integrity/iammai/accession/accession-coordinator.test.ts`
Expected: PASS

- [ ] **Step 5: Commit**

```bash
git add backend/src/integrity/iammai/accession/accession-coordinator.ts backend/tests/unit/integrity/iammai/accession/accession-coordinator.test.ts
git commit -m "feat(accession): add accession coordinator — stage advancement orchestration"
```

---

### Task 8: Seed Cases

**Files:**
- Create: `backend/src/integrity/iammai/accession/seed-cases.ts`

- [ ] **Step 1: Write the seed cases module**

```typescript
/**
 * Seed Cases — Runs clean + messy cases through the accession coordinator
 */

import { v4 as uuidv4 } from 'uuid';
import type pg from 'pg';
import { generateCleanSession, generateMessySession, exportSlice } from './external-simulator.js';
import { seedSlice } from './accession-coordinator.js';
import { resetAccessionTables } from './accession-registry.js';
import { systemActorRef } from '../types.js';
import type { ExternalSource, ExportedSlice } from './types.js';

const SEED_ACTOR = systemActorRef('accession-seeder');

/**
 * Load both seed cases into the database.
 * Creates external sources, exported slices, and initial Contact state for each.
 */
export async function loadSeedCases(client: pg.PoolClient): Promise<{
  cleanSliceId: string;
  messySliceId: string;
}> {
  // Clean case: Alpha Chat
  const cleanSession = generateCleanSession();
  const cleanSummary = exportSlice(cleanSession);
  const cleanSourceId = uuidv4();
  const cleanSource: ExternalSource = {
    source_id: cleanSourceId,
    source_name: 'Alpha Chat',
    source_system_ref: `ext:alpha-chat:${cleanSession.session_id}`,
    source_data: cleanSession as unknown as Record<string, unknown>,
    actor_ref: SEED_ACTOR,
    created_at: new Date(),
  };
  const cleanSlice: ExportedSlice = {
    slice_id: cleanSummary.slice_id,
    source_id: cleanSourceId,
    slice_name: `Alpha Chat — ${cleanSession.topic}`,
    slice_data: cleanSummary as unknown as Record<string, unknown>,
    data_role: 'exported',
    created_at: new Date(),
  };
  await seedSlice(client, cleanSource, cleanSlice, cleanSummary, SEED_ACTOR);

  // Messy case: Beta Legacy
  const messySession = generateMessySession();
  const messySummary = exportSlice(messySession);
  const messySourceId = uuidv4();
  const messySource: ExternalSource = {
    source_id: messySourceId,
    source_name: 'Beta Legacy',
    source_system_ref: `ext:beta-legacy:${messySession.session_id}`,
    source_data: messySession as unknown as Record<string, unknown>,
    actor_ref: SEED_ACTOR,
    created_at: new Date(),
  };
  const messySlice: ExportedSlice = {
    slice_id: messySummary.slice_id,
    source_id: messySourceId,
    slice_name: 'Beta Legacy — (empty)',
    slice_data: messySummary as unknown as Record<string, unknown>,
    data_role: 'exported',
    created_at: new Date(),
  };
  await seedSlice(client, messySource, messySlice, messySummary, SEED_ACTOR);

  return {
    cleanSliceId: cleanSummary.slice_id,
    messySliceId: messySummary.slice_id,
  };
}

/**
 * Reset all accession tables and reload seeds.
 */
export async function resetAndReseed(client: pg.PoolClient): Promise<{
  cleanSliceId: string;
  messySliceId: string;
}> {
  await resetAccessionTables(client);
  return loadSeedCases(client);
}
```

- [ ] **Step 2: Commit**

```bash
git add backend/src/integrity/iammai/accession/seed-cases.ts
git commit -m "feat(accession): add seed cases — clean Alpha Chat + messy Beta Legacy"
```

---

### Task 9: Barrel Export and Event Bus Update

**Files:**
- Create: `backend/src/integrity/iammai/accession/index.ts`
- Modify: `backend/src/integrity/iammai/index.ts`
- Modify: `backend/src/integrity/iammai/event-bus.ts`

- [ ] **Step 1: Create the accession barrel export**

```typescript
/**
 * Accession Layer — Barrel Export
 */

export * from './types.js';
export * from './stage-engine.js';
export * from './accession-registry.js';
export * from './accession-validator.js';
export * from './accession-coordinator.js';
export * from './external-simulator.js';
export * from './seed-cases.js';
```

- [ ] **Step 2: Update the parent barrel export**

In `backend/src/integrity/iammai/index.ts`, add at the end:

```typescript
export * from './accession/index.js';
```

- [ ] **Step 3: Add accession event type to event bus**

In `backend/src/integrity/iammai/event-bus.ts`, update the type:

Change:
```typescript
export type IammaiEventType =
  | 'phase_change'
  | 'transition_occurred'
  | 'governance_action'
  | 'witness_emitted'
  | 'validation_completed'
  | 'contribution_recorded'
  | 'containment_change';
```

To:
```typescript
export type IammaiEventType =
  | 'phase_change'
  | 'transition_occurred'
  | 'governance_action'
  | 'witness_emitted'
  | 'validation_completed'
  | 'contribution_recorded'
  | 'containment_change'
  | 'accession_stage_change';
```

- [ ] **Step 4: Verify existing tests still pass**

Run: `cd backend && npx vitest run tests/unit/integrity/iammai/`
Expected: All existing tests PASS

- [ ] **Step 5: Commit**

```bash
git add backend/src/integrity/iammai/accession/index.ts backend/src/integrity/iammai/index.ts backend/src/integrity/iammai/event-bus.ts
git commit -m "feat(accession): add barrel exports and accession event type"
```

---

### Task 10: API Routes

**Files:**
- Create: `backend/src/api/routes/accession.ts`
- Modify: `backend/src/api/app.ts`

- [ ] **Step 1: Write the accession router**

```typescript
/**
 * Accession Layer API Routes
 *
 * Mounted at /api/v1/admin/iammai/accession
 *
 * Seed management: POST /seed, POST /reset
 * Stage advancement: POST /slices/:sliceId/advance
 * Inspection (read-only, derivative): GET /sources, GET /slices, GET /slices/:sliceId, GET /slices/:sliceId/stages/:stage
 */

import { Router } from 'express';
import { requireAdmin } from '../middleware/auth.js';
import { asyncHandler, errors } from '../middleware/error.js';
import { transaction } from '../../lib/db.js';
import { actorRef } from '../../integrity/iammai/types.js';
import {
  getExternalSources,
  listSlicesWithStage,
  loadAccessionContext,
  getAccessionStatesBySlice,
} from '../../integrity/iammai/accession/accession-registry.js';
import { advanceSlice } from '../../integrity/iammai/accession/accession-coordinator.js';
import { loadSeedCases, resetAndReseed } from '../../integrity/iammai/accession/seed-cases.js';

export const accessionRouter = Router();

accessionRouter.use(requireAdmin);

/** Wrap response with derivative surface metadata */
function derivative(data: unknown) {
  return {
    _derivative: {
      surface: 'admin-dashboard',
      authoritative_source: 'iammai_accession_tables',
      fetched_at: new Date().toISOString(),
    },
    data,
  };
}

// ============================================================================
// Seed Management
// ============================================================================

/**
 * POST /seed — Load both seed cases (creates sources + slices at Contact)
 */
accessionRouter.post(
  '/seed',
  asyncHandler(async (req, res) => {
    const adminActor = actorRef(req.admin!.id);
    const result = await transaction(async (client) => {
      return loadSeedCases(client);
    });
    res.status(201).json({
      message: 'Seed cases loaded',
      clean_slice_id: result.cleanSliceId,
      messy_slice_id: result.messySliceId,
    });
  })
);

/**
 * POST /reset — Truncate accession tables and optionally reseed
 */
accessionRouter.post(
  '/reset',
  asyncHandler(async (req, res) => {
    const reseed = req.body?.reseed !== false;
    const result = await transaction(async (client) => {
      if (reseed) {
        return resetAndReseed(client);
      }
      const { resetAccessionTables } = await import(
        '../../integrity/iammai/accession/accession-registry.js'
      );
      await resetAccessionTables(client);
      return null;
    });
    res.status(200).json({
      message: reseed ? 'Reset and reseeded' : 'Reset complete',
      ...(result && { clean_slice_id: result.cleanSliceId, messy_slice_id: result.messySliceId }),
    });
  })
);

// ============================================================================
// Stage Advancement
// ============================================================================

/**
 * POST /slices/:sliceId/advance — Advance to next stage
 */
accessionRouter.post(
  '/slices/:sliceId/advance',
  asyncHandler(async (req, res) => {
    const sliceId = req.params['sliceId']!;
    const adminActor = actorRef(req.admin!.id);

    const result = await advanceSlice(sliceId, adminActor);

    res.status(200).json({
      stage: result.stateRecord.accession_stage,
      state_record: result.stateRecord,
      transition: result.transitionRecord,
      governance_action_id: result.governanceActionId,
      witness_artifact_id: result.witnessArtifactId,
      stage_specific: result.stageSpecificRecords,
    });
  })
);

// ============================================================================
// Inspection (read-only, derivative)
// ============================================================================

/**
 * GET /sources — List external sources
 */
accessionRouter.get(
  '/sources',
  asyncHandler(async (_req, res) => {
    const sources = await getExternalSources();
    res.json(derivative({ sources }));
  })
);

/**
 * GET /slices — List slices with current accession stage
 */
accessionRouter.get(
  '/slices',
  asyncHandler(async (_req, res) => {
    const slices = await listSlicesWithStage();
    res.json(derivative({ slices }));
  })
);

/**
 * GET /slices/:sliceId — Full accession context
 */
accessionRouter.get(
  '/slices/:sliceId',
  asyncHandler(async (req, res) => {
    const sliceId = req.params['sliceId']!;
    const context = await loadAccessionContext(sliceId);
    if (!context.slice) {
      throw errors.notFound(`Slice ${sliceId} not found`);
    }
    res.json(derivative(context));
  })
);

/**
 * GET /slices/:sliceId/stages/:stage — Records at a specific stage
 */
accessionRouter.get(
  '/slices/:sliceId/stages/:stage',
  asyncHandler(async (req, res) => {
    const sliceId = req.params['sliceId']!;
    const stage = req.params['stage']!;
    const states = await getAccessionStatesBySlice(sliceId);
    const stageState = states.find(s => s.accession_stage === stage);
    if (!stageState) {
      throw errors.notFound(`Stage ${stage} not found for slice ${sliceId}`);
    }
    res.json(derivative({ state: stageState }));
  })
);
```

- [ ] **Step 2: Mount the accession router in app.ts**

In `backend/src/api/app.ts`, add the import:

```typescript
import { accessionRouter } from './routes/accession.js';
```

And add the mount after the existing IAMMAI routes:

```typescript
app.use('/api/v1/admin/iammai/accession', accessionRouter);
```

- [ ] **Step 3: Verify the app compiles**

Run: `cd backend && npx tsc --noEmit`
Expected: No new errors (pre-existing errors in auth.ts, error.ts, public.ts, tokens.ts are expected)

- [ ] **Step 4: Commit**

```bash
git add backend/src/api/routes/accession.ts backend/src/api/app.ts
git commit -m "feat(accession): add API routes — seed, reset, advance, inspection"
```

---

### Task 11: Frontend — Accession Admin Page

**Files:**
- Create: `frontend/apps/admin/src/pages/accession/index.tsx`
- Create: `frontend/apps/admin/src/components/accession/StageTimeline.tsx`
- Create: `frontend/apps/admin/src/components/accession/SliceCard.tsx`
- Create: `frontend/apps/admin/src/components/accession/StageDetail.tsx`
- Modify: `frontend/apps/admin/src/components/AdminLayout.tsx`

- [ ] **Step 1: Create the StageTimeline component**

```tsx
/**
 * StageTimeline — Horizontal timeline showing all 7 accession stages.
 * Current stage highlighted, completed stages show outcome.
 *
 * DERIVATIVE SURFACE — display only.
 */

import { motion } from 'framer-motion';

const STAGES = ['contact', 'eligibility', 'shadow', 'proof', 'admission', 'bound_vessel', 'revoked'] as const;

const STAGE_LABELS: Record<string, string> = {
  contact: 'Contact',
  eligibility: 'Eligibility',
  shadow: 'Shadow',
  proof: 'Proof',
  admission: 'Admission',
  bound_vessel: 'Bound Vessel',
  revoked: 'Revoked',
};

interface StageTimelineProps {
  currentStage: string | null;
  completedStages: string[];
  onStageClick: (stage: string) => void;
  selectedStage: string | null;
}

export function StageTimeline({ currentStage, completedStages, onStageClick, selectedStage }: StageTimelineProps): JSX.Element {
  const currentIdx = currentStage ? STAGES.indexOf(currentStage as typeof STAGES[number]) : -1;

  return (
    <div className="flex items-center gap-1 overflow-x-auto pb-2">
      {STAGES.filter(s => s !== 'revoked').map((stage, idx) => {
        const isCompleted = completedStages.includes(stage);
        const isCurrent = stage === currentStage;
        const isSelected = stage === selectedStage;
        const isPast = idx < currentIdx;
        const isRevoked = currentStage === 'revoked';

        let bgClass = 'bg-dark-surface2 border-dark-border text-text-secondary';
        if (isCompleted || isPast) bgClass = 'bg-accent-cyan/10 border-accent-cyan/30 text-accent-cyan';
        if (isCurrent && !isRevoked) bgClass = 'bg-accent-cyan/20 border-accent-cyan text-accent-cyan shadow-glow-cyan-subtle';
        if (isRevoked && isCurrent) bgClass = 'bg-error/20 border-error text-error shadow-glow-error-subtle';
        if (isSelected) bgClass += ' ring-1 ring-accent-magenta';

        return (
          <div key={stage} className="flex items-center">
            <motion.button
              onClick={() => isCompleted || isCurrent ? onStageClick(stage) : undefined}
              className={`px-3 py-1.5 text-[10px] font-mono font-bold rounded border transition-colors duration-hover whitespace-nowrap ${bgClass} ${isCompleted || isCurrent ? 'cursor-pointer hover:border-accent-magenta/50' : 'cursor-default opacity-50'}`}
              whileHover={isCompleted || isCurrent ? { scale: 1.05 } : undefined}
            >
              {STAGE_LABELS[stage]}
            </motion.button>
            {idx < 5 && (
              <div className={`w-4 h-px mx-0.5 ${isPast || (isCompleted && idx < currentIdx) ? 'bg-accent-cyan/50' : 'bg-dark-border'}`} />
            )}
          </div>
        );
      })}
      {currentStage === 'revoked' && (
        <div className="flex items-center ml-2">
          <div className="w-4 h-px mx-0.5 bg-error/50" />
          <span className="px-3 py-1.5 text-[10px] font-mono font-bold rounded border bg-error/20 border-error text-error shadow-glow-error-subtle">
            REVOKED
          </span>
        </div>
      )}
    </div>
  );
}
```

- [ ] **Step 2: Create the SliceCard component**

```tsx
/**
 * SliceCard — Summary card for an accession slice.
 *
 * DERIVATIVE SURFACE — display only.
 */

import { motion } from 'framer-motion';

interface SliceCardProps {
  sliceName: string;
  sourceName: string;
  currentStage: string | null;
  isSelected: boolean;
  onClick: () => void;
}

const STAGE_COLORS: Record<string, string> = {
  contact: 'text-text-secondary border-dark-border',
  eligibility: 'text-accent-cyan border-accent-cyan/30',
  shadow: 'text-accent-blue border-accent-blue/30',
  proof: 'text-warning-text border-warning/30',
  admission: 'text-accent-magenta border-accent-magenta/30',
  bound_vessel: 'text-success-text border-success/30',
  revoked: 'text-error border-error/30',
};

export function SliceCard({ sliceName, sourceName, currentStage, isSelected, onClick }: SliceCardProps): JSX.Element {
  const stageStyle = STAGE_COLORS[currentStage ?? ''] ?? STAGE_COLORS['contact'];

  return (
    <motion.button
      onClick={onClick}
      className={`w-full text-left rounded-lg border p-3 transition-colors duration-hover ${isSelected ? 'border-accent-magenta/50 bg-dark-surface2' : 'border-dark-border bg-dark-surface1 hover:border-accent-cyan/30'}`}
      whileHover={{ scale: 1.01 }}
    >
      <div className="flex items-center justify-between mb-1">
        <span className="text-xs font-mono text-text-bright truncate">{sourceName}</span>
        {currentStage && (
          <span className={`px-1.5 py-0.5 text-[9px] font-mono font-bold rounded border ${stageStyle}`}>
            {currentStage.toUpperCase().replace('_', ' ')}
          </span>
        )}
      </div>
      <div className="text-[10px] text-text-secondary font-mono truncate">{sliceName}</div>
    </motion.button>
  );
}
```

- [ ] **Step 3: Create the StageDetail component**

```tsx
/**
 * StageDetail — Shows records produced at a specific accession stage.
 *
 * DERIVATIVE SURFACE — all data labeled with its role.
 */

interface StageDetailProps {
  stageState: {
    accession_stage: string;
    stage_outcome: Record<string, unknown>;
    recorded_at: string;
    related_governance_ref: string | null;
    related_witness_ref: string | null;
  } | null;
  shadows: Array<{
    shadow_id: string;
    shadow_data: Record<string, unknown>;
    discrepancies: Array<Record<string, unknown>>;
    data_role: string;
  }>;
  proofs: Array<{
    proof_id: string;
    test_name: string;
    test_result: string;
    test_details: Record<string, unknown>;
  }>;
}

function RoleBadge({ role }: { role: string }): JSX.Element {
  const colors: Record<string, string> = {
    source: 'text-warning-text bg-warning/10 border-warning/30',
    exported: 'text-accent-cyan bg-accent-cyan/10 border-accent-cyan/30',
    derived: 'text-accent-magenta bg-accent-magenta/10 border-accent-magenta/30',
    display: 'text-text-secondary bg-dark-surface2 border-dark-border',
  };
  return (
    <span className={`px-1 py-0.5 text-[8px] font-mono font-bold rounded border ${colors[role] ?? colors['display']}`}>
      {role.toUpperCase()}
    </span>
  );
}

function ProofBadge({ result }: { result: string }): JSX.Element {
  const colors: Record<string, string> = {
    pass: 'text-success-text bg-success/10 border-success/30',
    fail: 'text-error bg-error/10 border-error/30',
    blocked: 'text-warning-text bg-warning/10 border-warning/30',
    indeterminate: 'text-text-secondary bg-dark-surface2 border-dark-border',
  };
  return (
    <span className={`px-1.5 py-0.5 text-[9px] font-mono font-bold rounded border ${colors[result] ?? colors['indeterminate']}`}>
      {result.toUpperCase()}
    </span>
  );
}

export function StageDetail({ stageState, shadows, proofs }: StageDetailProps): JSX.Element {
  if (!stageState) {
    return <div className="text-text-muted text-xs font-mono p-4">Select a completed stage to inspect</div>;
  }

  const outcome = stageState.stage_outcome;
  const stage = stageState.accession_stage;

  return (
    <div className="space-y-4">
      {/* Stage Header */}
      <div className="flex items-center justify-between">
        <h3 className="text-sm font-mono text-text-bright uppercase tracking-wider">
          {stage.replace('_', ' ')}
        </h3>
        <RoleBadge role="display" />
      </div>

      {/* Outcome */}
      <div className="rounded border border-dark-border bg-dark-surface2 p-3">
        <div className="text-[10px] font-mono text-text-muted mb-2">STAGE OUTCOME</div>
        <pre className="text-[10px] font-mono text-text-primary whitespace-pre-wrap">
          {JSON.stringify(outcome, null, 2)}
        </pre>
      </div>

      {/* Shadow (if present) */}
      {shadows.length > 0 && stage === 'shadow' && (
        <div className="rounded border border-dark-border bg-dark-surface2 p-3">
          <div className="flex items-center gap-2 mb-2">
            <span className="text-[10px] font-mono text-text-muted">SHADOW MIRROR</span>
            <RoleBadge role={shadows[0]!.data_role} />
          </div>
          {shadows[0]!.discrepancies.length > 0 ? (
            <div className="space-y-1">
              {shadows[0]!.discrepancies.map((d, i) => (
                <div key={i} className="flex items-center gap-2 text-[10px] font-mono">
                  <span className="text-warning-text">{String(d['type'])}</span>
                  <span className="text-text-secondary">{String(d['field'])}</span>
                  <span className="text-text-muted">expected: {String(d['expected'])}</span>
                  <span className="text-error">actual: {JSON.stringify(d['actual'])}</span>
                </div>
              ))}
            </div>
          ) : (
            <div className="text-[10px] font-mono text-success-text">No discrepancies</div>
          )}
        </div>
      )}

      {/* Proof Tests (if present) */}
      {proofs.length > 0 && stage === 'proof' && (
        <div className="rounded border border-dark-border bg-dark-surface2 p-3">
          <div className="text-[10px] font-mono text-text-muted mb-2">PROOF TESTS</div>
          <div className="space-y-2">
            {proofs.map((p) => (
              <div key={p.proof_id} className="flex items-center justify-between">
                <span className="text-[10px] font-mono text-text-primary">{p.test_name}</span>
                <ProofBadge result={p.test_result} />
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Governance + Witness refs */}
      <div className="flex gap-4 text-[9px] font-mono text-text-muted">
        {stageState.related_governance_ref && (
          <span>gov: {stageState.related_governance_ref.slice(0, 8)}...</span>
        )}
        {stageState.related_witness_ref && (
          <span>wit: {stageState.related_witness_ref.slice(0, 8)}...</span>
        )}
      </div>
    </div>
  );
}
```

- [ ] **Step 4: Create the main Accession page**

```tsx
/**
 * Accession Layer — Admin Step-Through UI
 *
 * DERIVATIVE SURFACE — Displays data derived from canonical accession records.
 * Not a source of truth. All data labeled with its role.
 */

import { useState, useEffect, useCallback } from 'react';
import { AdminLayout } from '../../components/AdminLayout';
import { DerivativeBanner } from '../../components/iammai/DerivativeBanner';
import { StageTimeline } from '../../components/accession/StageTimeline';
import { SliceCard } from '../../components/accession/SliceCard';
import { StageDetail } from '../../components/accession/StageDetail';
import { FadeUp } from '@iammai-sandbox/shared';

const API_URL = process.env['NEXT_PUBLIC_API_URL'] || 'http://localhost:3001';
const BASE = `${API_URL}/api/v1/admin/iammai/accession`;

function getAuthHeaders(): HeadersInit {
  if (typeof window === 'undefined') return {};
  const token = localStorage.getItem('auth_token');
  return token ? { Authorization: `Bearer ${token}`, 'Content-Type': 'application/json' } : { 'Content-Type': 'application/json' };
}

interface SliceSummary {
  slice_id: string;
  slice_name: string;
  source_name: string;
  current_stage: string | null;
  slice_data: Record<string, unknown>;
}

interface AccessionState {
  state_id: string;
  accession_stage: string;
  stage_outcome: Record<string, unknown>;
  recorded_at: string;
  related_governance_ref: string | null;
  related_witness_ref: string | null;
}

export default function AccessionPage(): JSX.Element {
  const [slices, setSlices] = useState<SliceSummary[]>([]);
  const [selectedSliceId, setSelectedSliceId] = useState<string | null>(null);
  const [selectedStage, setSelectedStage] = useState<string | null>(null);
  const [states, setStates] = useState<AccessionState[]>([]);
  const [shadows, setShadows] = useState<Array<Record<string, unknown>>>([]);
  const [proofs, setProofs] = useState<Array<Record<string, unknown>>>([]);
  const [isLoading, setIsLoading] = useState(false);
  const [isAdvancing, setIsAdvancing] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const fetchSlices = useCallback(async () => {
    try {
      const resp = await fetch(`${BASE}/slices`, { credentials: 'include', headers: getAuthHeaders() });
      if (!resp.ok) throw new Error(`HTTP ${resp.status}`);
      const json = await resp.json();
      setSlices(json.data?.slices ?? []);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to fetch slices');
    }
  }, []);

  const fetchSliceContext = useCallback(async (sliceId: string) => {
    try {
      const resp = await fetch(`${BASE}/slices/${sliceId}`, { credentials: 'include', headers: getAuthHeaders() });
      if (!resp.ok) throw new Error(`HTTP ${resp.status}`);
      const json = await resp.json();
      const ctx = json.data;
      setStates(ctx?.states ?? []);
      setShadows(ctx?.shadows ?? []);
      setProofs(ctx?.proofs ?? []);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to fetch context');
    }
  }, []);

  useEffect(() => { fetchSlices(); }, [fetchSlices]);
  useEffect(() => { if (selectedSliceId) fetchSliceContext(selectedSliceId); }, [selectedSliceId, fetchSliceContext]);

  const handleSeed = async () => {
    setIsLoading(true);
    setError(null);
    try {
      const resp = await fetch(`${BASE}/seed`, { method: 'POST', credentials: 'include', headers: getAuthHeaders() });
      if (!resp.ok) throw new Error(`HTTP ${resp.status}`);
      await fetchSlices();
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to seed');
    } finally {
      setIsLoading(false);
    }
  };

  const handleReset = async () => {
    setIsLoading(true);
    setError(null);
    try {
      const resp = await fetch(`${BASE}/reset`, { method: 'POST', credentials: 'include', headers: getAuthHeaders(), body: JSON.stringify({ reseed: true }) });
      if (!resp.ok) throw new Error(`HTTP ${resp.status}`);
      setSelectedSliceId(null);
      setSelectedStage(null);
      setStates([]);
      setShadows([]);
      setProofs([]);
      await fetchSlices();
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to reset');
    } finally {
      setIsLoading(false);
    }
  };

  const handleAdvance = async () => {
    if (!selectedSliceId) return;
    setIsAdvancing(true);
    setError(null);
    try {
      const resp = await fetch(`${BASE}/slices/${selectedSliceId}/advance`, { method: 'POST', credentials: 'include', headers: getAuthHeaders() });
      if (!resp.ok) {
        const body = await resp.json().catch(() => ({}));
        throw new Error(body.error?.message ?? body.message ?? `HTTP ${resp.status}`);
      }
      await fetchSliceContext(selectedSliceId);
      await fetchSlices();
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to advance');
    } finally {
      setIsAdvancing(false);
    }
  };

  const currentSlice = slices.find(s => s.slice_id === selectedSliceId);
  const currentStage = currentSlice?.current_stage ?? null;
  const completedStages = states.map(s => s.accession_stage);
  const selectedStateRecord = states.find(s => s.accession_stage === selectedStage) ?? null;
  const isTerminal = currentStage === 'bound_vessel' || currentStage === 'revoked';
  // Check if admission was refused — cannot advance past admission if refused
  const admissionState = states.find(s => s.accession_stage === 'admission');
  const admissionDecision = (admissionState?.stage_outcome as Record<string, unknown>)?.['decision'];
  const isRefused = admissionDecision === 'refused';
  const canAdvance = selectedSliceId && !isTerminal && !isRefused && !isAdvancing;

  return (
    <AdminLayout>
      <div className="space-y-4">
        {/* Top bar */}
        <FadeUp>
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <span className="text-[10px] font-mono text-text-muted">Admin &gt; IAMMAI &gt;</span>
              <h1 className="text-sm font-mono text-text-bright tracking-wider">ACCESSION</h1>
            </div>
            <div className="flex gap-2">
              <button
                onClick={handleSeed}
                disabled={isLoading}
                className="px-3 py-1 text-xs font-mono text-accent-cyan border border-accent-cyan/30 rounded hover:bg-accent-cyan/10 transition-colors disabled:opacity-50"
              >
                {isLoading ? 'Loading...' : 'Load Seeds'}
              </button>
              <button
                onClick={handleReset}
                disabled={isLoading}
                className="px-3 py-1 text-xs font-mono text-accent-magenta border border-accent-magenta/30 rounded hover:bg-accent-magenta/10 transition-colors disabled:opacity-50"
              >
                Reset
              </button>
            </div>
          </div>
        </FadeUp>

        <DerivativeBanner />

        {error && (
          <div className="rounded border border-error/30 bg-error/10 p-3 text-xs font-mono text-error">
            {error}
          </div>
        )}

        <div className="grid grid-cols-1 lg:grid-cols-4 gap-4">
          {/* Left panel: Slice list */}
          <div className="lg:col-span-1 space-y-2">
            <div className="text-[10px] font-mono text-text-muted uppercase tracking-wider mb-2">Slices</div>
            {slices.length === 0 ? (
              <div className="text-xs font-mono text-text-muted p-3 rounded border border-dark-border bg-dark-surface1">
                No slices loaded. Click "Load Seeds" to begin.
              </div>
            ) : (
              slices.map((s) => (
                <SliceCard
                  key={s.slice_id}
                  sliceName={s.slice_name}
                  sourceName={s.source_name}
                  currentStage={s.current_stage}
                  isSelected={s.slice_id === selectedSliceId}
                  onClick={() => { setSelectedSliceId(s.slice_id); setSelectedStage(null); }}
                />
              ))
            )}
          </div>

          {/* Main panel: Timeline + Inspector */}
          <div className="lg:col-span-3 space-y-4">
            {selectedSliceId ? (
              <>
                {/* Stage Timeline */}
                <FadeUp>
                  <div className="rounded-lg border border-dark-border bg-dark-surface1 p-4">
                    <StageTimeline
                      currentStage={currentStage}
                      completedStages={completedStages}
                      onStageClick={(stage) => setSelectedStage(stage)}
                      selectedStage={selectedStage}
                    />
                    <div className="flex items-center justify-between mt-3 pt-3 border-t border-dark-border">
                      <div className="text-[10px] font-mono text-text-muted">
                        Current: <span className="text-text-primary">{currentStage?.toUpperCase().replace('_', ' ') ?? 'N/A'}</span>
                        {isRefused && <span className="text-error ml-2">(REFUSED — cannot advance)</span>}
                      </div>
                      <button
                        onClick={handleAdvance}
                        disabled={!canAdvance}
                        className="px-4 py-1.5 text-xs font-mono font-bold text-dark-base bg-accent-cyan rounded hover:bg-accent-cyan/80 transition-colors disabled:opacity-30 disabled:cursor-not-allowed"
                      >
                        {isAdvancing ? 'Advancing...' : 'ADVANCE'}
                      </button>
                    </div>
                  </div>
                </FadeUp>

                {/* Stage Detail Inspector */}
                <FadeUp>
                  <div className="rounded-lg border border-dark-border bg-dark-surface1 p-4">
                    <StageDetail
                      stageState={selectedStateRecord as StageDetailProps['stageState']}
                      shadows={shadows as StageDetailProps['shadows']}
                      proofs={proofs as StageDetailProps['proofs']}
                    />
                  </div>
                </FadeUp>
              </>
            ) : (
              <div className="rounded-lg border border-dark-border bg-dark-surface1 p-8 text-center">
                <div className="text-xs font-mono text-text-muted">
                  Select a slice to inspect its accession progression
                </div>
              </div>
            )}
          </div>
        </div>
      </div>
    </AdminLayout>
  );
}

// Type helper for StageDetail import
type StageDetailProps = Parameters<typeof StageDetail>[0];
```

- [ ] **Step 5: Add nav link to AdminLayout**

In `frontend/apps/admin/src/components/AdminLayout.tsx`, add `/accession` to the navigation links array, following the existing pattern for `/iammai`.

Find the navigation links section (where `/sessions`, `/compliance`, `/iammai` are listed) and add:

```tsx
{ href: '/accession', label: 'Accession' },
```

- [ ] **Step 6: Commit**

```bash
git add frontend/apps/admin/src/pages/accession/index.tsx frontend/apps/admin/src/components/accession/StageTimeline.tsx frontend/apps/admin/src/components/accession/SliceCard.tsx frontend/apps/admin/src/components/accession/StageDetail.tsx frontend/apps/admin/src/components/AdminLayout.tsx
git commit -m "feat(accession): add admin step-through UI with stage timeline and inspector"
```

---

### Task 12: Verify Full Stack

- [ ] **Step 1: Run all accession unit tests**

Run: `cd backend && npx vitest run tests/unit/integrity/iammai/accession/`
Expected: All tests PASS

- [ ] **Step 2: Run all existing IAMMAI tests (regression)**

Run: `cd backend && npx vitest run tests/unit/integrity/iammai/`
Expected: All existing tests PASS (no regressions)

- [ ] **Step 3: Run full test suite**

Run: `cd backend && npx vitest run`
Expected: All tests PASS

- [ ] **Step 4: Verify TypeScript compilation**

Run: `cd backend && npx tsc --noEmit`
Expected: No new errors

- [ ] **Step 5: Commit all remaining changes**

```bash
git add -A
git commit -m "feat(accession): complete accession layer implementation"
```
