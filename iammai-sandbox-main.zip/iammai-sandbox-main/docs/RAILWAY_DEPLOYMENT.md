# Railway Deployment Guide

Deploy the IAMMAI Sandbox monorepo to Railway. This creates 3 services (backend, admin frontend, user frontend) and a managed PostgreSQL database.

## Prerequisites

- [Railway CLI v3](https://docs.railway.com/cli/installation) installed
- Railway account
- OpenAI API key
- Repository cloned and on `main` branch with the rebrand merged

```bash
railway login
```

## Architecture

```
Railway Project: iammai-sandbox
├── Postgres        (managed DB, auto-injects DATABASE_URL)
├── backend         (Express API, port 3001, built via Dockerfile.backend)
├── admin           (Next.js admin panel, port 3000, built via nixpacks.toml)
└── user            (Next.js user app, port 3002, built via nixpacks.toml)
```

**Config files that control the build:**

| File | Purpose |
|---|---|
| `Dockerfile.backend` | Multi-stage Node 20 Alpine build for the backend |
| `backend/railway.toml` | Tells Railway to use `../Dockerfile.backend`, sets healthcheck at `/health` |
| `nixpacks.toml` | Frontend build config; uses `RAILWAY_APP` env var to select which Next.js app to build |

---

## Step 1: Create Project

```bash
railway init
```

Choose **"Create new project"** and name it `iammai-sandbox`.

## Step 2: Add PostgreSQL

```bash
railway add
```

Select **Database** > **PostgreSQL**. Railway will provision a managed Postgres instance and make `DATABASE_URL` available to linked services.

## Step 3: Create Backend Service

```bash
railway add
```

Select **Empty Service**, name it `backend`.

### Configure backend source (Railway Dashboard)

1. Open the **backend** service in the Railway dashboard
2. Go to **Settings** > **Source**
3. Connect your GitHub repo (`sariomaric/iammai-sandbox`)
4. Set **Root Directory** to `backend/`
5. Railway will auto-detect `backend/railway.toml` and use `Dockerfile.backend`

### Set backend environment variables

```bash
railway service backend

railway variables set \
    NODE_ENV=production \
    PORT=3001 \
    JWT_SECRET=$(openssl rand -hex 32) \
    OPENAI_API_KEY=sk-your-key-here \
    ADMIN_EMAIL=admin@example.com \
    ADMIN_PASSWORD=$(openssl rand -base64 12 | tr -d '/+=' | head -c 16)
```

> Save the generated `JWT_SECRET` and `ADMIN_PASSWORD` somewhere safe.

### Link the database

In the Railway dashboard, go to the **backend** service > **Variables** > **Reference Variables** and add a reference to the Postgres service's `DATABASE_URL`. This ensures the backend connects to the managed database.

## Step 4: Create Admin Frontend Service

```bash
railway add
```

Select **Empty Service**, name it `admin`.

### Configure admin source (Railway Dashboard)

1. Open the **admin** service in the Railway dashboard
2. Go to **Settings** > **Source**
3. Connect the same GitHub repo
4. Leave **Root Directory** as `/` (monorepo root) -- `nixpacks.toml` handles the build

### Set admin environment variables

```bash
railway service admin

railway variables set \
    NODE_ENV=production \
    PORT=3000 \
    RAILWAY_APP=admin
```

> `RAILWAY_APP=admin` tells `nixpacks.toml` to run `pnpm --filter admin build` and `pnpm --filter admin start`.

## Step 5: Create User Frontend Service

```bash
railway add
```

Select **Empty Service**, name it `user`.

### Configure user source (Railway Dashboard)

1. Open the **user** service in the Railway dashboard
2. Go to **Settings** > **Source**
3. Connect the same GitHub repo
4. Leave **Root Directory** as `/`

### Set user environment variables

```bash
railway service user

railway variables set \
    NODE_ENV=production \
    PORT=3002 \
    RAILWAY_APP=user
```

## Step 6: Deploy

Trigger a deploy from the Railway dashboard, or push to main:

```bash
git push origin main
```

Railway will build and deploy all 3 services.

## Step 7: Wire Up Frontend URLs

After the backend finishes deploying, grab its public URL from the Railway dashboard (e.g., `backend-production-xxxx.up.railway.app`).

### Set API URLs on admin service

```bash
railway service admin

railway variables set \
    NEXT_PUBLIC_API_URL=https://BACKEND_URL_HERE \
    NEXT_PUBLIC_WS_URL=wss://BACKEND_URL_HERE
```

### Set API URLs on user service

```bash
railway service user

railway variables set \
    NEXT_PUBLIC_API_URL=https://BACKEND_URL_HERE/api/v1 \
    NEXT_PUBLIC_WS_URL=wss://BACKEND_URL_HERE
```

> Note: the user service uses `/api/v1` suffix; admin does not.

### Set CORS on backend

Grab the admin and user public URLs from the dashboard, then:

```bash
railway service backend

railway variables set \
    CORS_ORIGINS=https://ADMIN_URL_HERE,https://USER_URL_HERE
```

### Redeploy frontends

The `NEXT_PUBLIC_*` variables are baked into the Next.js build at build time. After setting them, trigger a redeploy so the frontends pick them up:

```bash
railway service admin
railway redeploy

railway service user
railway redeploy
```

## Step 8: Run Migrations

```bash
railway service backend
railway run pnpm db:migrate
railway run pnpm db:seed
```

This creates all database tables and seeds the admin account.

---

## Verification

| Check | How |
|---|---|
| Backend health | `curl https://BACKEND_URL/health` should return `{"status":"ok"}` |
| Admin loads | Visit the admin URL in a browser, login page should appear |
| Admin login | Use `admin@example.com` + the generated password |
| User frontend | Visit the user URL, should load the session interface |
| WebSocket | Open browser dev tools > Network > WS tab, confirm connection to backend |

## Environment Variable Reference

### Backend

| Variable | Required | Default | Notes |
|---|---|---|---|
| `DATABASE_URL` | Yes | -- | Auto-injected by Railway Postgres reference |
| `NODE_ENV` | -- | `development` | Set `production` |
| `PORT` | -- | `3001` | |
| `JWT_SECRET` | Yes | test value | `openssl rand -hex 32` |
| `OPENAI_API_KEY` | Yes | -- | From OpenAI dashboard |
| `OPENAI_MODEL` | -- | `gpt-4o-mini` | |
| `AI_PROVIDER` | -- | `openai` | |
| `ADMIN_EMAIL` | -- | `''` | Used by db:seed |
| `ADMIN_PASSWORD` | -- | `''` | Used by db:seed |
| `CORS_ORIGINS` | -- | `localhost:3000,3002` | Comma-separated frontend URLs |
| `WS_HEARTBEAT_INTERVAL` | -- | `30000` | WebSocket ping interval (ms) |
| `RATE_LIMIT_WINDOW` | -- | `60000` | Rate limit window (ms) |
| `RATE_LIMIT_MAX` | -- | `100` | Max requests per window |

### Frontend (both admin and user)

| Variable | Required | Notes |
|---|---|---|
| `NODE_ENV` | -- | Set `production` |
| `PORT` | -- | admin: `3000`, user: `3002` |
| `RAILWAY_APP` | Yes | `admin` or `user` -- drives nixpacks.toml build |
| `NEXT_PUBLIC_API_URL` | Yes | Backend URL (user app adds `/api/v1`) |
| `NEXT_PUBLIC_WS_URL` | Yes | Backend WebSocket URL (`wss://...`) |

## Troubleshooting

**Build fails on frontend:** Check that `RAILWAY_APP` is set correctly (`admin` or `user`). Without it, `nixpacks.toml` defaults to building `admin`.

**Database connection refused:** Verify the `DATABASE_URL` reference variable is linked from the Postgres service to the backend service in the Railway dashboard.

**CORS errors in browser:** Ensure `CORS_ORIGINS` on the backend includes both frontend URLs (with `https://`, no trailing slash).

**Frontend shows blank / API errors:** `NEXT_PUBLIC_*` vars are build-time only. After changing them, you must redeploy the frontend service for changes to take effect.

**Health check fails:** The backend healthcheck path is `/health` with a 300s timeout. If the build is slow, Railway may mark the service unhealthy before it's ready. Check build logs.
