-- Migration 004: Presence Records
-- Feature: 007-presence-suppression
-- @see specs/007-presence-suppression/data-model.md

-- Presence role enum (idempotent)
DO $$ BEGIN
  CREATE TYPE presence_role AS ENUM ('CREATOR', 'PARTICIPANT', 'AGENT');
EXCEPTION WHEN duplicate_object THEN NULL;
END $$;

-- Attestation method enum (idempotent)
DO $$ BEGIN
  CREATE TYPE attestation_method AS ENUM ('AUTH_EVENT', 'JOIN_TOKEN', 'MESSAGE_PROCESSING');
EXCEPTION WHEN duplicate_object THEN NULL;
END $$;

-- Presence records table
CREATE TABLE IF NOT EXISTS presence_records (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    session_id UUID NOT NULL REFERENCES sessions(id) ON DELETE RESTRICT,
    role presence_role NOT NULL,
    presence_hash VARCHAR(64) NOT NULL,
    attestation_method attestation_method NOT NULL,
    attested BOOLEAN NOT NULL DEFAULT true,
    finalized BOOLEAN NOT NULL DEFAULT false,
    created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT NOW(),
    finalized_at TIMESTAMP WITH TIME ZONE,
    UNIQUE (session_id, role, presence_hash)
);

-- Index for fast lookup during verification
CREATE INDEX IF NOT EXISTS idx_presence_records_session_id ON presence_records(session_id);

-- Protective trigger: prevent modification of finalized records
CREATE OR REPLACE FUNCTION presence_records_prevent_finalized_update()
RETURNS TRIGGER AS $$
BEGIN
  IF OLD.finalized = true THEN
    RAISE EXCEPTION 'Cannot modify finalized presence record (id: %)', OLD.id;
  END IF;
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

DROP TRIGGER IF EXISTS trg_presence_records_no_finalized_update ON presence_records;
CREATE TRIGGER trg_presence_records_no_finalized_update
  BEFORE UPDATE ON presence_records
  FOR EACH ROW
  EXECUTE FUNCTION presence_records_prevent_finalized_update();

-- Protective trigger: prevent deletion of presence records
CREATE OR REPLACE FUNCTION presence_records_prevent_delete()
RETURNS TRIGGER AS $$
BEGIN
  RAISE EXCEPTION 'Deletion of presence records is prohibited (id: %)', OLD.id;
END;
$$ LANGUAGE plpgsql;

DROP TRIGGER IF EXISTS trg_presence_records_no_delete ON presence_records;
CREATE TRIGGER trg_presence_records_no_delete
  BEFORE DELETE ON presence_records
  FOR EACH ROW
  EXECUTE FUNCTION presence_records_prevent_delete();

-- Track migration
INSERT INTO migrations (name) VALUES ('004_presence_records') ON CONFLICT (name) DO NOTHING;
