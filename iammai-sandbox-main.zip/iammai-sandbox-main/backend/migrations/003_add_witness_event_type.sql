-- Migration 003: Add VERIFICATION_WITNESS to integrity_event_type enum
-- Required by Feature 006 — Verification + Witness
-- @see specs/006-verification-witness

ALTER TYPE integrity_event_type ADD VALUE IF NOT EXISTS 'VERIFICATION_WITNESS';
