-- Integrity Layer: Append-only ledger and session boundary columns
-- @see specs/005-structural-foundation/data-model.md
-- @see docs/framework/FRAMEWORK_DECISIONS.md

-- ============================================================================
-- Session Boundary Columns (Framework Decision 1)
-- ============================================================================

ALTER TABLE sessions
  ADD COLUMN context_descriptor JSONB NOT NULL DEFAULT '{"topic": "unspecified"}'::jsonb;

ALTER TABLE sessions
  ADD COLUMN environmental_constraints JSONB NOT NULL DEFAULT '{"max_participants": 10}'::jsonb;

-- ============================================================================
-- Integrity Event Type Enum
-- ============================================================================

CREATE TYPE integrity_event_type AS ENUM (
  'SESSION_CREATED',
  'SESSION_ACTIVATED',
  'SESSION_CLOSED',
  'TRANSITION_REJECTED'
);

-- ============================================================================
-- Integrity Ledger Table (Append-Only, Hash-Chained)
-- ============================================================================
-- This table records session lifecycle metadata ONLY.
-- It NEVER stores message content, token values, or presence hashes.
-- @see FRAMEWORK_DECISIONS.md Decision 10: Privacy Boundary

CREATE TABLE integrity_ledger (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    sequence_number BIGSERIAL UNIQUE,
    session_id UUID NOT NULL REFERENCES sessions(id) ON DELETE RESTRICT,
    event_type integrity_event_type NOT NULL,
    timestamp TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT NOW(),
    from_state session_state,
    to_state VARCHAR(10) NOT NULL,
    metadata_snapshot JSONB NOT NULL,
    previous_hash VARCHAR(64),
    entry_hash VARCHAR(64) NOT NULL UNIQUE
);

CREATE INDEX idx_integrity_ledger_session_id ON integrity_ledger(session_id);
CREATE INDEX idx_integrity_ledger_sequence ON integrity_ledger(sequence_number);
CREATE INDEX idx_integrity_ledger_hash ON integrity_ledger(entry_hash);

-- ============================================================================
-- Immutability Triggers
-- ============================================================================
-- These triggers enforce append-only behavior at the database level.
-- Even direct SQL access cannot update or delete ledger entries.

CREATE OR REPLACE FUNCTION integrity_ledger_prevent_update()
RETURNS TRIGGER AS $$
BEGIN
  RAISE EXCEPTION 'Ledger entries cannot be updated';
END;
$$ LANGUAGE plpgsql;

CREATE OR REPLACE FUNCTION integrity_ledger_prevent_delete()
RETURNS TRIGGER AS $$
BEGIN
  RAISE EXCEPTION 'Ledger entries cannot be deleted';
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER trg_integrity_ledger_no_update
  BEFORE UPDATE ON integrity_ledger
  FOR EACH ROW
  EXECUTE FUNCTION integrity_ledger_prevent_update();

CREATE TRIGGER trg_integrity_ledger_no_delete
  BEFORE DELETE ON integrity_ledger
  FOR EACH ROW
  EXECUTE FUNCTION integrity_ledger_prevent_delete();

-- ============================================================================
-- Record Migration
-- ============================================================================

INSERT INTO migrations (name) VALUES ('002_integrity_ledger');
