-- Migration 006: Add acedia event types to integrity_event_type enum
-- Feature: 008-governance-protocols
-- Pattern: same as 003_add_witness_event_type.sql and 005_add_suppression_event_type.sql

ALTER TYPE integrity_event_type ADD VALUE IF NOT EXISTS 'ACEDIA_WARNING';
ALTER TYPE integrity_event_type ADD VALUE IF NOT EXISTS 'ACEDIA_DETECTION';
ALTER TYPE integrity_event_type ADD VALUE IF NOT EXISTS 'ACEDIA_CANCELLED';
ALTER TYPE integrity_event_type ADD VALUE IF NOT EXISTS 'ACEDIA_FORCE_RELEASE';
