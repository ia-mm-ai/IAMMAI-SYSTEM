-- Accession Layer: External system approach, inspection, and admission
-- Reuses iammai_prevent_update / iammai_prevent_delete from migration 007.
-- All tables are append-only with immutability triggers.

-- ============================================================================
-- Accession Enums
-- ============================================================================

CREATE TYPE accession_stage AS ENUM (
  'contact', 'eligibility', 'shadow', 'proof', 'admission', 'bound_vessel', 'revoked'
);

CREATE TYPE accession_family AS ENUM ('pre_admission', 'post_admission');

CREATE TYPE contact_outcome AS ENUM (
  'accepted_for_observation', 'out_of_scope', 'insufficient_grounding', 'refused'
);

CREATE TYPE admission_decision AS ENUM ('admitted', 'not_yet', 'refused');

CREATE TYPE data_role AS ENUM ('source', 'exported', 'derived', 'display');

-- ============================================================================
-- 1. External Sources
-- ============================================================================

CREATE TABLE iammai_external_sources (
  source_id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  source_name VARCHAR(255) NOT NULL,
  source_system_ref VARCHAR(255) NOT NULL,
  source_data JSONB NOT NULL DEFAULT '{}',
  actor_ref VARCHAR(255) NOT NULL,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX idx_accession_source_name ON iammai_external_sources(source_name);

-- Immutability
CREATE TRIGGER trg_accession_source_no_update
  BEFORE UPDATE ON iammai_external_sources FOR EACH ROW
  EXECUTE FUNCTION iammai_prevent_update();
CREATE TRIGGER trg_accession_source_no_delete
  BEFORE DELETE ON iammai_external_sources FOR EACH ROW
  EXECUTE FUNCTION iammai_prevent_delete();

-- ============================================================================
-- 2. Exported Slices
-- ============================================================================

CREATE TABLE iammai_exported_slices (
  slice_id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  source_id UUID NOT NULL REFERENCES iammai_external_sources(source_id),
  slice_name VARCHAR(255) NOT NULL,
  slice_data JSONB NOT NULL DEFAULT '{}',
  data_role data_role NOT NULL DEFAULT 'exported',
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX idx_accession_slice_source ON iammai_exported_slices(source_id);

CREATE TRIGGER trg_accession_slice_no_update
  BEFORE UPDATE ON iammai_exported_slices FOR EACH ROW
  EXECUTE FUNCTION iammai_prevent_update();
CREATE TRIGGER trg_accession_slice_no_delete
  BEFORE DELETE ON iammai_exported_slices FOR EACH ROW
  EXECUTE FUNCTION iammai_prevent_delete();

-- ============================================================================
-- 3. Accession State Records
-- ============================================================================

CREATE TABLE iammai_accession_state_records (
  state_id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  slice_ref UUID NOT NULL REFERENCES iammai_exported_slices(slice_id),
  accession_family accession_family NOT NULL,
  accession_stage accession_stage NOT NULL,
  stage_outcome JSONB NOT NULL DEFAULT '{}',
  recorded_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  predecessor_ref UUID REFERENCES iammai_accession_state_records(state_id),
  related_governance_ref UUID REFERENCES iammai_governance_actions(governance_action_id),
  related_validation_ref UUID REFERENCES iammai_validation_artifacts(validation_id),
  related_witness_ref UUID REFERENCES iammai_witness_artifacts(witness_id)
);

CREATE INDEX idx_accession_state_slice ON iammai_accession_state_records(slice_ref);
CREATE INDEX idx_accession_state_stage ON iammai_accession_state_records(accession_stage);
CREATE INDEX idx_accession_state_recorded ON iammai_accession_state_records(recorded_at);

CREATE TRIGGER trg_accession_state_no_update
  BEFORE UPDATE ON iammai_accession_state_records FOR EACH ROW
  EXECUTE FUNCTION iammai_prevent_update();
CREATE TRIGGER trg_accession_state_no_delete
  BEFORE DELETE ON iammai_accession_state_records FOR EACH ROW
  EXECUTE FUNCTION iammai_prevent_delete();

-- ============================================================================
-- 4. Accession Transitions
-- ============================================================================

CREATE TABLE iammai_accession_transitions (
  transition_id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  slice_ref UUID NOT NULL REFERENCES iammai_exported_slices(slice_id),
  source_state_ref UUID NOT NULL REFERENCES iammai_accession_state_records(state_id),
  target_state_ref UUID NOT NULL REFERENCES iammai_accession_state_records(state_id),
  transition_type VARCHAR(100) NOT NULL,
  occurred_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX idx_accession_transition_slice ON iammai_accession_transitions(slice_ref);

CREATE TRIGGER trg_accession_transition_no_update
  BEFORE UPDATE ON iammai_accession_transitions FOR EACH ROW
  EXECUTE FUNCTION iammai_prevent_update();
CREATE TRIGGER trg_accession_transition_no_delete
  BEFORE DELETE ON iammai_accession_transitions FOR EACH ROW
  EXECUTE FUNCTION iammai_prevent_delete();

-- ============================================================================
-- 5. Shadow Records
-- ============================================================================

CREATE TABLE iammai_shadow_records (
  shadow_id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  slice_ref UUID NOT NULL REFERENCES iammai_exported_slices(slice_id),
  shadow_data JSONB NOT NULL DEFAULT '{}',
  discrepancies JSONB NOT NULL DEFAULT '[]',
  data_role data_role NOT NULL DEFAULT 'derived',
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  governance_action_ref UUID REFERENCES iammai_governance_actions(governance_action_id)
);

CREATE INDEX idx_accession_shadow_slice ON iammai_shadow_records(slice_ref);

CREATE TRIGGER trg_accession_shadow_no_update
  BEFORE UPDATE ON iammai_shadow_records FOR EACH ROW
  EXECUTE FUNCTION iammai_prevent_update();
CREATE TRIGGER trg_accession_shadow_no_delete
  BEFORE DELETE ON iammai_shadow_records FOR EACH ROW
  EXECUTE FUNCTION iammai_prevent_delete();

-- ============================================================================
-- 6. Proof Records
-- ============================================================================

CREATE TABLE iammai_proof_records (
  proof_id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  slice_ref UUID NOT NULL REFERENCES iammai_exported_slices(slice_id),
  shadow_ref UUID NOT NULL REFERENCES iammai_shadow_records(shadow_id),
  test_name VARCHAR(255) NOT NULL,
  test_result validation_outcome NOT NULL,
  test_details JSONB NOT NULL DEFAULT '{}',
  checked_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX idx_accession_proof_slice ON iammai_proof_records(slice_ref);
CREATE INDEX idx_accession_proof_shadow ON iammai_proof_records(shadow_ref);

CREATE TRIGGER trg_accession_proof_no_update
  BEFORE UPDATE ON iammai_proof_records FOR EACH ROW
  EXECUTE FUNCTION iammai_prevent_update();
CREATE TRIGGER trg_accession_proof_no_delete
  BEFORE DELETE ON iammai_proof_records FOR EACH ROW
  EXECUTE FUNCTION iammai_prevent_delete();
