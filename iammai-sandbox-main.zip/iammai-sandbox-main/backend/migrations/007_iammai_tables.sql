-- IAMMAI Constitutional Protocol: Canonical Record Tables
-- @see .claude/skills/iammai/references/canonical-schemas.md
-- All tables are append-only with immutability triggers.

-- ============================================================================
-- Session Extension
-- ============================================================================

ALTER TABLE sessions ADD COLUMN IF NOT EXISTS iammai_tracked BOOLEAN NOT NULL DEFAULT false;

-- ============================================================================
-- IAMMAI Enums
-- ============================================================================

CREATE TYPE iammai_phase AS ENUM (
  'signal', 'acceptance', 'scope', 'presence', 'threshold',
  'truth', 'continuity', 'decision', 'consequence'
);

CREATE TYPE state_family AS ENUM ('preparation', 'standing');

CREATE TYPE resolution_type AS ENUM ('FINALIZE', 'INVALIDATE', 'EVOLVE');

CREATE TYPE iammai_transition_type AS ENUM (
  'preparation_progression', 'threshold_eligibility', 'truth_formation',
  'continuity_transition', 'decision_transition', 'consequence_transition',
  'containment_apply', 'containment_release', 'resolution_transition'
);

CREATE TYPE governance_action_type AS ENUM (
  'authorize', 'deny', 'hold', 'release', 'finalize', 'invalidate', 'evolve'
);

CREATE TYPE authority_class AS ENUM ('SYSTEM', 'OPERATOR', 'DELEGATED');

CREATE TYPE iammai_witness_type AS ENUM (
  'interaction', 'validation', 'transition', 'publication', 'state_observation'
);

CREATE TYPE iammai_validation_type AS ENUM (
  'admissibility', 'threshold', 'transition_legality',
  'governance_precondition', 'bounded_consistency'
);

CREATE TYPE validation_outcome AS ENUM ('pass', 'fail', 'blocked', 'indeterminate');

CREATE TYPE contribution_role AS ENUM (
  'ORIGIN', 'ELICITATION', 'FORMALIZATION', 'AUTHORIZATION', 'RENDERING', 'TRANSMISSION'
);

CREATE TYPE containment_action AS ENUM ('HOLD', 'RELEASE');

-- ============================================================================
-- 1. State Records
-- ============================================================================

CREATE TABLE iammai_state_records (
  state_id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  matter_ref VARCHAR(255) NOT NULL,
  state_family state_family NOT NULL,
  state_type iammai_phase NOT NULL,
  recorded_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  predecessor_ref UUID REFERENCES iammai_state_records(state_id),
  containment_ref UUID,
  related_transition_ref UUID,
  related_governance_ref UUID,
  related_validation_ref UUID,
  related_witness_ref UUID
);

CREATE INDEX idx_iammai_state_matter ON iammai_state_records(matter_ref);
CREATE INDEX idx_iammai_state_type ON iammai_state_records(state_type);
CREATE INDEX idx_iammai_state_recorded ON iammai_state_records(recorded_at);

-- ============================================================================
-- 2. Transition Records
-- ============================================================================

CREATE TABLE iammai_transition_records (
  transition_id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  matter_ref VARCHAR(255) NOT NULL,
  source_ref UUID NOT NULL REFERENCES iammai_state_records(state_id),
  target_ref UUID NOT NULL REFERENCES iammai_state_records(state_id),
  transition_type iammai_transition_type NOT NULL,
  occurred_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  resolution_type resolution_type,
  predecessor_ref UUID REFERENCES iammai_transition_records(transition_id)
);

CREATE INDEX idx_iammai_transition_matter ON iammai_transition_records(matter_ref);

-- ============================================================================
-- 3. Governance Action Records
-- ============================================================================

CREATE TABLE iammai_governance_actions (
  governance_action_id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  action_type governance_action_type NOT NULL,
  authority_class authority_class NOT NULL,
  actor_ref VARCHAR(255) NOT NULL,
  legitimacy_basis_ref VARCHAR(255) NOT NULL,
  matter_ref VARCHAR(255) NOT NULL,
  acted_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  delegated_from_ref UUID REFERENCES iammai_governance_actions(governance_action_id),
  target_state_ref UUID REFERENCES iammai_state_records(state_id),
  target_transition_ref UUID REFERENCES iammai_transition_records(transition_id),
  contribution_role_map_ref UUID
);

CREATE INDEX idx_iammai_governance_matter ON iammai_governance_actions(matter_ref);
CREATE INDEX idx_iammai_governance_actor ON iammai_governance_actions(actor_ref);

-- ============================================================================
-- 4. Witness Artifacts
-- ============================================================================

CREATE TABLE iammai_witness_artifacts (
  witness_id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  witness_type iammai_witness_type NOT NULL,
  target_ref VARCHAR(255) NOT NULL,
  observed_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  claims JSONB NOT NULL,
  non_claims JSONB NOT NULL,
  actor_ref VARCHAR(255),
  surface_ref VARCHAR(255)
);

CREATE INDEX idx_iammai_witness_target ON iammai_witness_artifacts(target_ref);

-- ============================================================================
-- 5. Validation Artifacts
-- ============================================================================

CREATE TABLE iammai_validation_artifacts (
  validation_id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  validation_type iammai_validation_type NOT NULL,
  target_ref VARCHAR(255) NOT NULL,
  condition_set_ref VARCHAR(255) NOT NULL,
  outcome validation_outcome NOT NULL,
  checked_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  reason_refs JSONB,
  actor_ref VARCHAR(255)
);

CREATE INDEX idx_iammai_validation_target ON iammai_validation_artifacts(target_ref);

-- ============================================================================
-- 6. Contribution Records
-- ============================================================================

CREATE TABLE iammai_contribution_records (
  contribution_id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  matter_ref VARCHAR(255) NOT NULL,
  actor_ref VARCHAR(255) NOT NULL,
  role contribution_role NOT NULL,
  recorded_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  context_ref VARCHAR(255),
  UNIQUE (matter_ref, actor_ref, role)
);

CREATE INDEX idx_iammai_contribution_matter ON iammai_contribution_records(matter_ref);

-- ============================================================================
-- 7. Containment Records
-- ============================================================================

CREATE TABLE iammai_containment_records (
  containment_id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  matter_ref VARCHAR(255) NOT NULL,
  target_state_ref UUID NOT NULL REFERENCES iammai_state_records(state_id),
  action containment_action NOT NULL,
  actor_ref VARCHAR(255) NOT NULL,
  reason TEXT NOT NULL,
  recorded_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  governance_action_ref UUID REFERENCES iammai_governance_actions(governance_action_id)
);

CREATE INDEX idx_iammai_containment_matter ON iammai_containment_records(matter_ref);

-- ============================================================================
-- Immutability Triggers (all 7 tables)
-- ============================================================================

-- Generic prevent-update function
CREATE OR REPLACE FUNCTION iammai_prevent_update()
RETURNS TRIGGER AS $$
BEGIN
  RAISE EXCEPTION 'IAMMAI canonical records cannot be updated: %', TG_TABLE_NAME;
END;
$$ LANGUAGE plpgsql;

-- Generic prevent-delete function
CREATE OR REPLACE FUNCTION iammai_prevent_delete()
RETURNS TRIGGER AS $$
BEGIN
  RAISE EXCEPTION 'IAMMAI canonical records cannot be deleted: %', TG_TABLE_NAME;
END;
$$ LANGUAGE plpgsql;

-- State Records
CREATE TRIGGER trg_iammai_state_no_update
  BEFORE UPDATE ON iammai_state_records FOR EACH ROW
  EXECUTE FUNCTION iammai_prevent_update();
CREATE TRIGGER trg_iammai_state_no_delete
  BEFORE DELETE ON iammai_state_records FOR EACH ROW
  EXECUTE FUNCTION iammai_prevent_delete();

-- Transition Records
CREATE TRIGGER trg_iammai_transition_no_update
  BEFORE UPDATE ON iammai_transition_records FOR EACH ROW
  EXECUTE FUNCTION iammai_prevent_update();
CREATE TRIGGER trg_iammai_transition_no_delete
  BEFORE DELETE ON iammai_transition_records FOR EACH ROW
  EXECUTE FUNCTION iammai_prevent_delete();

-- Governance Actions
CREATE TRIGGER trg_iammai_governance_no_update
  BEFORE UPDATE ON iammai_governance_actions FOR EACH ROW
  EXECUTE FUNCTION iammai_prevent_update();
CREATE TRIGGER trg_iammai_governance_no_delete
  BEFORE DELETE ON iammai_governance_actions FOR EACH ROW
  EXECUTE FUNCTION iammai_prevent_delete();

-- Witness Artifacts
CREATE TRIGGER trg_iammai_witness_no_update
  BEFORE UPDATE ON iammai_witness_artifacts FOR EACH ROW
  EXECUTE FUNCTION iammai_prevent_update();
CREATE TRIGGER trg_iammai_witness_no_delete
  BEFORE DELETE ON iammai_witness_artifacts FOR EACH ROW
  EXECUTE FUNCTION iammai_prevent_delete();

-- Validation Artifacts
CREATE TRIGGER trg_iammai_validation_no_update
  BEFORE UPDATE ON iammai_validation_artifacts FOR EACH ROW
  EXECUTE FUNCTION iammai_prevent_update();
CREATE TRIGGER trg_iammai_validation_no_delete
  BEFORE DELETE ON iammai_validation_artifacts FOR EACH ROW
  EXECUTE FUNCTION iammai_prevent_delete();

-- Contribution Records
CREATE TRIGGER trg_iammai_contribution_no_update
  BEFORE UPDATE ON iammai_contribution_records FOR EACH ROW
  EXECUTE FUNCTION iammai_prevent_update();
CREATE TRIGGER trg_iammai_contribution_no_delete
  BEFORE DELETE ON iammai_contribution_records FOR EACH ROW
  EXECUTE FUNCTION iammai_prevent_delete();

-- Containment Records
CREATE TRIGGER trg_iammai_containment_no_update
  BEFORE UPDATE ON iammai_containment_records FOR EACH ROW
  EXECUTE FUNCTION iammai_prevent_update();
CREATE TRIGGER trg_iammai_containment_no_delete
  BEFORE DELETE ON iammai_containment_records FOR EACH ROW
  EXECUTE FUNCTION iammai_prevent_delete();

-- ============================================================================
-- Back-references (add FKs that couldn't be created inline due to ordering)
-- ============================================================================

ALTER TABLE iammai_state_records
  ADD CONSTRAINT fk_state_containment
  FOREIGN KEY (containment_ref) REFERENCES iammai_containment_records(containment_id);

ALTER TABLE iammai_state_records
  ADD CONSTRAINT fk_state_transition
  FOREIGN KEY (related_transition_ref) REFERENCES iammai_transition_records(transition_id);

ALTER TABLE iammai_state_records
  ADD CONSTRAINT fk_state_governance
  FOREIGN KEY (related_governance_ref) REFERENCES iammai_governance_actions(governance_action_id);

ALTER TABLE iammai_state_records
  ADD CONSTRAINT fk_state_validation
  FOREIGN KEY (related_validation_ref) REFERENCES iammai_validation_artifacts(validation_id);

ALTER TABLE iammai_state_records
  ADD CONSTRAINT fk_state_witness
  FOREIGN KEY (related_witness_ref) REFERENCES iammai_witness_artifacts(witness_id);

-- ============================================================================
-- Record Migration
-- ============================================================================

INSERT INTO migrations (name) VALUES ('007_iammai_tables');
