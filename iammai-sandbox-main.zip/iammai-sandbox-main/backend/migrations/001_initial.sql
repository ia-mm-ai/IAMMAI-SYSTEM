-- Initial database schema for Ephemeral Kernel System
-- @see specs/001-ephemeral-kernel/data-model.md

-- Enable UUID extension
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";

-- ============================================================================
-- Session State Enum
-- ============================================================================

CREATE TYPE session_state AS ENUM ('CREATED', 'ACTIVE', 'ENDED');

-- ============================================================================
-- Admins Table
-- ============================================================================

CREATE TABLE admins (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    email VARCHAR(255) NOT NULL UNIQUE,
    password_hash VARCHAR(255) NOT NULL,
    created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT NOW(),
    last_login_at TIMESTAMP WITH TIME ZONE
);

CREATE INDEX idx_admins_email ON admins(email);

-- ============================================================================
-- Sessions Table
-- ============================================================================

CREATE TABLE sessions (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    name VARCHAR(255) NOT NULL,
    state session_state NOT NULL DEFAULT 'CREATED',
    created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT NOW(),
    started_at TIMESTAMP WITH TIME ZONE,
    ended_at TIMESTAMP WITH TIME ZONE,
    token_count INTEGER NOT NULL DEFAULT 0,
    user_count INTEGER NOT NULL DEFAULT 0,
    admin_id UUID NOT NULL REFERENCES admins(id) ON DELETE RESTRICT
);

-- Enforce state transition rules
-- started_at required when ACTIVE or ENDED
-- ended_at required when ENDED
ALTER TABLE sessions ADD CONSTRAINT chk_started_at
    CHECK (
        (state = 'CREATED' AND started_at IS NULL)
        OR (state IN ('ACTIVE', 'ENDED') AND started_at IS NOT NULL)
    );

ALTER TABLE sessions ADD CONSTRAINT chk_ended_at
    CHECK (
        (state IN ('CREATED', 'ACTIVE') AND ended_at IS NULL)
        OR (state = 'ENDED' AND ended_at IS NOT NULL)
    );

-- Ensure user_count never exceeds token_count
ALTER TABLE sessions ADD CONSTRAINT chk_user_count
    CHECK (user_count >= 0 AND user_count <= token_count);

-- Ensure token_count is non-negative
ALTER TABLE sessions ADD CONSTRAINT chk_token_count
    CHECK (token_count >= 0);

CREATE INDEX idx_sessions_state ON sessions(state);
CREATE INDEX idx_sessions_admin_id ON sessions(admin_id);
CREATE INDEX idx_sessions_created_at ON sessions(created_at DESC);

-- ============================================================================
-- Tokens Table (Persistent Reference Only)
-- ============================================================================
-- NOTE: This table stores ONLY the hash of tokens, never the raw token value
-- This enforces Constitution Principle V: Token Opacity

CREATE TABLE tokens (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    session_id UUID NOT NULL REFERENCES sessions(id) ON DELETE CASCADE,
    token_hash VARCHAR(64) NOT NULL UNIQUE,  -- SHA-256 hash (64 hex chars)
    claimed_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT NOW(),
    joined_at TIMESTAMP WITH TIME ZONE
);

CREATE INDEX idx_tokens_session_id ON tokens(session_id);
CREATE INDEX idx_tokens_token_hash ON tokens(token_hash);

-- ============================================================================
-- Migrations Tracking Table
-- ============================================================================

CREATE TABLE IF NOT EXISTS migrations (
    id SERIAL PRIMARY KEY,
    name VARCHAR(255) NOT NULL UNIQUE,
    applied_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT NOW()
);

-- Record this migration
INSERT INTO migrations (name) VALUES ('001_initial');

-- ============================================================================
-- Privacy Note
-- ============================================================================
-- NO tables for messages, conversations, or kernels exist.
-- These are ephemeral and stored ONLY in memory.
-- This schema enforces that conversation data can NEVER be persisted.
