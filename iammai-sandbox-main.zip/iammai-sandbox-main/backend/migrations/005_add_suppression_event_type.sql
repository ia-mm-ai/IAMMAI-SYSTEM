-- Migration 005: Add SUPPRESSION_EVENT to integrity_event_type enum
-- Feature: 007-presence-suppression
-- Pattern: same as 003_add_witness_event_type.sql

ALTER TYPE integrity_event_type ADD VALUE IF NOT EXISTS 'SUPPRESSION_EVENT';
