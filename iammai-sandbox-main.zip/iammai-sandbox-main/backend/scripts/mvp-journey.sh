#!/bin/bash
# MVP User Journey Test
# Tests the complete flow: Admin creates session → User claims token → User joins
# Based on specs/001-ephemeral-kernel/TESTING_GUIDE.md#mvp-journey-test

set -e

# Configuration
API_URL="http://localhost:3001/api/v1"
ADMIN_EMAIL="${ADMIN_EMAIL:-admin@example.com}"
ADMIN_PASSWORD="${ADMIN_PASSWORD:-change-this-password}"
COOKIES_FILE="/tmp/iammai-sandbox-cookies.txt"

# Colors
GREEN='\033[0;32m'
BLUE='\033[0;34m'
YELLOW='\033[1;33m'
NC='\033[0m'

step() {
  echo -e "${BLUE}→${NC} $1"
}

success() {
  echo -e "${GREEN}✓${NC} $1"
}

info() {
  echo -e "${YELLOW}ℹ${NC} $1"
}

echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo "MVP User Journey Test"
echo "Testing: Admin Session Creation + User Token Flow"
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo ""

# Check if backend is running
step "Checking backend API..."
if ! curl -s "$API_URL/../health" > /dev/null 2>&1; then
  echo "❌ Backend API is not running at $API_URL"
  echo "   Please start it with: pnpm dev"
  exit 1
fi
success "Backend API is running"

# Step 1: Admin login
step "1. Admin login..."
LOGIN_RESPONSE=$(curl -s -X POST "$API_URL/auth/login" \
  -H "Content-Type: application/json" \
  -d "{\"email\": \"$ADMIN_EMAIL\", \"password\": \"$ADMIN_PASSWORD\"}" \
  -c "$COOKIES_FILE")

if echo "$LOGIN_RESPONSE" | grep -q '"id"'; then
  ADMIN_ID=$(echo "$LOGIN_RESPONSE" | grep -oE '"id":"[^"]*"' | cut -d'"' -f4)
  success "Admin logged in (ID: ${ADMIN_ID:0:8}...)"
else
  echo "❌ Admin login failed"
  echo "$LOGIN_RESPONSE"
  exit 1
fi

# Step 2: Admin creates session
step "2. Creating session..."
SESSION_RESPONSE=$(curl -s -X POST "$API_URL/admin/sessions" \
  -H "Content-Type: application/json" \
  -b "$COOKIES_FILE" \
  -d '{"name": "MVP Journey Test"}')

SESSION_ID=$(echo "$SESSION_RESPONSE" | grep -oE '"id":"[^"]*"' | cut -d'"' -f4)
SESSION_STATE=$(echo "$SESSION_RESPONSE" | grep -oE '"state":"[^"]*"' | cut -d'"' -f4)

if [ -n "$SESSION_ID" ]; then
  success "Session created (ID: ${SESSION_ID:0:8}..., State: $SESSION_STATE)"
else
  echo "❌ Session creation failed"
  echo "$SESSION_RESPONSE"
  exit 1
fi

# Step 3: Verify session is CREATED
step "3. Verifying session state..."
STATE_CHECK=$(curl -s "$API_URL/admin/sessions/$SESSION_ID" -b "$COOKIES_FILE" | grep -oE '"state":"[^"]*"' | cut -d'"' -f4)
if [ "$STATE_CHECK" = "CREATED" ]; then
  success "Session is CREATED"
else
  echo "❌ Expected state CREATED, got $STATE_CHECK"
  exit 1
fi

# Step 4: User claims token
step "4. User claims token..."
TOKEN_RESPONSE=$(curl -s -X POST "$API_URL/sessions/$SESSION_ID/claim")
TOKEN=$(echo "$TOKEN_RESPONSE" | grep -oE '"token":"[^"]*"' | cut -d'"' -f4)

if [ -n "$TOKEN" ] && [ ${#TOKEN} -eq 64 ]; then
  success "Token claimed (${TOKEN:0:16}...)"
else
  echo "❌ Token claim failed"
  echo "$TOKEN_RESPONSE"
  exit 1
fi

# Step 5: Verify session visible in public list
step "5. Verifying public session list..."
PUBLIC_COUNT=$(curl -s "$API_URL/sessions" | grep -o "\"id\"" | wc -l | tr -d ' ')
if [ "$PUBLIC_COUNT" -ge "1" ]; then
  success "Public sessions visible (count: $PUBLIC_COUNT)"
else
  echo "❌ No public sessions found"
  exit 1
fi

# Step 6: Admin starts session
step "6. Admin starts session..."
START_RESPONSE=$(curl -s -X POST "$API_URL/admin/sessions/$SESSION_ID/start" -b "$COOKIES_FILE")
STARTED_STATE=$(echo "$START_RESPONSE" | grep -oE '"state":"[^"]*"' | cut -d'"' -f4)

if [ "$STARTED_STATE" = "ACTIVE" ]; then
  success "Session is now ACTIVE"
else
  echo "❌ Failed to start session (state: $STARTED_STATE)"
  exit 1
fi

# Step 7: User joins session
step "7. User joins session..."
JOIN_RESPONSE=$(curl -s -X POST "$API_URL/sessions/$SESSION_ID/join" \
  -H "Authorization: Bearer $TOKEN")

PRESENCE_HASH=$(echo "$JOIN_RESPONSE" | grep -oE '"presenceHash":"[^"]*"' | cut -d'"' -f4)

if [ -n "$PRESENCE_HASH" ]; then
  success "User joined session (Presence: $PRESENCE_HASH)"
else
  echo "❌ User join failed"
  echo "$JOIN_RESPONSE"
  exit 1
fi

# Step 8: Verify user count incremented
step "8. Verifying user count..."
USER_COUNT=$(curl -s "$API_URL/admin/sessions/$SESSION_ID" -b "$COOKIES_FILE" | grep -oE '"userCount":[0-9]+' | grep -oE "[0-9]+")

if [ "$USER_COUNT" -ge "1" ]; then
  success "User count updated (count: $USER_COUNT)"
else
  echo "❌ User count not updated"
  exit 1
fi

# Step 9: Admin ends session
step "9. Admin ends session..."
END_RESPONSE=$(curl -s -X POST "$API_URL/admin/sessions/$SESSION_ID/end" -b "$COOKIES_FILE")
ENDED_STATE=$(echo "$END_RESPONSE" | grep -oE '"state":"[^"]*"' | cut -d'"' -f4)
KERNEL_STATUS=$(echo "$END_RESPONSE" | grep -oE '"kernelStatus":"[^"]*"' | cut -d'"' -f4)

if [ "$ENDED_STATE" = "ENDED" ]; then
  success "Session is now ENDED (Kernel: $KERNEL_STATUS)"
else
  echo "❌ Failed to end session"
  exit 1
fi

# Step 10: Verify session hidden from public list
step "10. Verifying ended session hidden from public..."
SESSION_IN_LIST=$(curl -s "$API_URL/sessions" | grep -o "\"$SESSION_ID\"" || true)

if [ -z "$SESSION_IN_LIST" ]; then
  success "Session correctly hidden from public list"
else
  echo "❌ Ended session still visible in public list"
  exit 1
fi

# Cleanup
rm -f "$COOKIES_FILE"

echo ""
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo "✅ MVP User Journey Complete"
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo ""
info "All steps completed successfully!"
info "Session ID: $SESSION_ID"
info "Token: ${TOKEN:0:16}..."
info "Presence Hash: $PRESENCE_HASH"
echo ""
