#!/bin/bash
# MVP Testing Script for IAMMAI Sandbox System
# Tests User Stories 1 & 2 (Admin Session Management + User Token System)
# Based on specs/001-ephemeral-kernel/TESTING_GUIDE.md

set -e

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

# Track test results
TOTAL_TESTS=0
PASSED_TESTS=0
FAILED_TESTS=0

print_header() {
  echo -e "\n${BLUE}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${NC}"
  echo -e "${BLUE}$1${NC}"
  echo -e "${BLUE}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${NC}\n"
}

print_success() {
  echo -e "${GREEN}✓${NC} $1"
  ((PASSED_TESTS++))
  ((TOTAL_TESTS++))
}

print_failure() {
  echo -e "${RED}✗${NC} $1"
  ((FAILED_TESTS++))
  ((TOTAL_TESTS++))
}

print_info() {
  echo -e "${YELLOW}→${NC} $1"
}

print_summary() {
  echo -e "\n${BLUE}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${NC}"
  echo -e "${BLUE}Test Summary${NC}"
  echo -e "${BLUE}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${NC}"
  echo -e "Total Tests: $TOTAL_TESTS"
  echo -e "${GREEN}Passed: $PASSED_TESTS${NC}"
  if [ $FAILED_TESTS -gt 0 ]; then
    echo -e "${RED}Failed: $FAILED_TESTS${NC}"
    echo -e "\n${RED}❌ MVP TESTS FAILED${NC}"
    exit 1
  else
    echo -e "${RED}Failed: $FAILED_TESTS${NC}"
    echo -e "\n${GREEN}✅ ALL MVP TESTS PASSED${NC}"
  fi
  echo -e "${BLUE}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${NC}\n"
}

# Change to backend directory
cd "$(dirname "$0")/.."

print_header "🧪 IAMMAI Sandbox System - MVP Test Suite"
echo "Testing User Stories 1 & 2 (Admin + User Token System)"
echo ""

# Step 1: Foundation Tests
print_header "📦 Phase 1: Foundation Tests (Unit Tests)"
print_info "Running unit tests for core services and models..."

if pnpm test:unit > /dev/null 2>&1; then
  UNIT_COUNT=$(pnpm test:unit 2>&1 | grep "Tests" | grep -oE "[0-9]+ passed" | head -1 | grep -oE "[0-9]+")
  print_success "Unit tests passed ($UNIT_COUNT tests)"
else
  print_failure "Unit tests failed"
fi

# Step 2: Contract Tests
print_header "📝 Phase 2: Contract Tests (API Contracts)"
print_info "Running contract tests for User Stories 1 & 2..."

if pnpm test:contract > /dev/null 2>&1; then
  CONTRACT_COUNT=$(pnpm test:contract 2>&1 | grep "Tests" | grep -oE "[0-9]+ passed" | head -1 | grep -oE "[0-9]+")
  print_success "Contract tests passed ($CONTRACT_COUNT tests)"

  # Break down by test file
  print_info "  - auth.test.ts (Admin authentication)"
  print_info "  - sessions.test.ts (Session management)"
  print_info "  - public.test.ts (Public session browsing)"
  print_info "  - tokens.test.ts (Token claiming & joining)"
else
  print_failure "Contract tests failed"
fi

# Step 3: Integration Tests
print_header "🔗 Phase 3: Integration Tests (User Flows)"
print_info "Running integration tests for session lifecycle and token flow..."

if pnpm test:integration > /dev/null 2>&1; then
  INTEGRATION_COUNT=$(pnpm test:integration 2>&1 | grep "Tests" | grep -oE "[0-9]+ passed" | head -1 | grep -oE "[0-9]+")
  print_success "Integration tests passed ($INTEGRATION_COUNT tests)"

  print_info "  - session-lifecycle.test.ts (CREATED → ACTIVE → ENDED)"
  print_info "  - token-flow.test.ts (Claim → Join flow)"
else
  print_failure "Integration tests failed"
fi

# Step 4: Code Quality Checks
print_header "🔍 Phase 4: Code Quality Checks"

# TypeScript type checking
print_info "Running TypeScript type checking..."
if pnpm typecheck > /dev/null 2>&1; then
  print_success "TypeScript: No type errors"
else
  ERROR_COUNT=$(pnpm typecheck 2>&1 | grep -oE "error TS[0-9]+" | wc -l | tr -d ' ')
  print_failure "TypeScript: $ERROR_COUNT type errors found (strict mode)"
  print_info "  Note: Tests pass but strict TypeScript mode found issues"
fi

# Step 5: Database Status
print_header "🗄️  Phase 5: Database Status"
print_info "Checking database connection and tables..."

if docker exec iammai-sandbox-db-test psql -U postgres -d iammai_sandbox_test -c "\dt" > /dev/null 2>&1; then
  print_success "Test database accessible"

  # Check tables exist
  TABLES=$(docker exec iammai-sandbox-db-test psql -U postgres -d iammai_sandbox_test -c "\dt" 2>&1 | grep -E "admins|sessions|tokens" | wc -l | tr -d ' ')
  if [ "$TABLES" -eq "3" ]; then
    print_success "All required tables exist (admins, sessions, tokens)"
  else
    print_failure "Missing database tables"
  fi
else
  print_failure "Cannot connect to test database"
fi

# Final Summary
print_summary

# Exit with appropriate code
if [ $FAILED_TESTS -gt 0 ]; then
  exit 1
else
  exit 0
fi
