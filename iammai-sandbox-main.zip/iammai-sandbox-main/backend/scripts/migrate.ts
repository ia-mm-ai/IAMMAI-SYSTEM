/**
 * Database migration runner
 * Executes SQL migrations in order, tracking applied migrations
 */

import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import pg from 'pg';
import { config as loadEnv } from 'dotenv';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

// Load environment from root .env file (one level up from backend)
loadEnv({ path: path.join(__dirname, '..', '..', '.env') });

const MIGRATIONS_DIR = path.join(__dirname, '..', 'migrations');

async function main(): Promise<void> {
  const databaseUrl = process.env['DATABASE_URL'];
  if (!databaseUrl) {
    console.error('DATABASE_URL environment variable is required');
    process.exit(1);
  }

  const pool = new pg.Pool({ connectionString: databaseUrl });

  try {
    console.log('Running migrations...');

    // Get list of migration files
    const files = fs.readdirSync(MIGRATIONS_DIR)
      .filter(f => f.endsWith('.sql'))
      .sort();

    if (files.length === 0) {
      console.log('No migration files found');
      return;
    }

    // Check which migrations have been applied
    const appliedResult = await pool.query(`
      SELECT name FROM migrations ORDER BY applied_at
    `).catch(() => ({ rows: [] }));

    const applied = new Set(
      appliedResult.rows.map((r: { name: string }) => r.name)
    );

    // Run pending migrations
    let count = 0;
    for (const file of files) {
      const name = file.replace('.sql', '');

      if (applied.has(name)) {
        console.log(`  Skipping ${file} (already applied)`);
        continue;
      }

      console.log(`  Applying ${file}...`);
      const sql = fs.readFileSync(path.join(MIGRATIONS_DIR, file), 'utf-8');

      await pool.query(sql);
      await pool.query(
        `INSERT INTO migrations (name) VALUES ($1) ON CONFLICT (name) DO NOTHING`,
        [name]
      );
      count++;
      console.log(`  Applied ${file}`);
    }

    if (count === 0) {
      console.log('All migrations already applied');
    } else {
      console.log(`Applied ${count} migration(s)`);
    }
  } catch (error) {
    console.error('Migration failed:', error);
    process.exit(1);
  } finally {
    await pool.end();
  }
}

main();
