/**
 * Express application setup
 * @see specs/001-ephemeral-kernel/contracts/api.yaml
 */

import express from 'express';
import cors from 'cors';
import cookieParser from 'cookie-parser';
import { config } from '../lib/config.js';
import { requestLogger } from './middleware/logging.js';
import { errorHandler, notFoundHandler } from './middleware/error.js';

// Import routes
import { authRouter } from './routes/auth.js';
import { sessionsRouter } from './routes/sessions.js';
import { publicRouter } from './routes/public.js';
import { tokensRouter } from './routes/tokens.js';
import { chatRouter } from './routes/chat.js';
import { complianceRouter } from './routes/compliance.js';
import { iammaiRouter } from './routes/iammai.js';
import { iammaiSseRouter } from './routes/iammai-sse.js';
import { iammaiGovernanceRouter } from './routes/iammai-governance.js';
import { accessionRouter } from './routes/accession.js';

/**
 * Create and configure Express application
 */
export function createApp(): express.Application {
  const app = express();

  // Trust proxy for accurate IP addresses behind reverse proxy
  app.set('trust proxy', 1);

  // ============================================================================
  // Middleware
  // ============================================================================

  // CORS configuration
  app.use(cors({
    origin: config.corsOrigins,
    credentials: true,
    methods: ['GET', 'POST', 'PUT', 'DELETE', 'OPTIONS'],
    allowedHeaders: ['Content-Type', 'Authorization'],
  }));

  // Parse JSON bodies
  app.use(express.json({ limit: '1mb' }));

  // Parse cookies
  app.use(cookieParser());

  // Request logging with sanitization
  app.use(requestLogger);

  // ============================================================================
  // Health Check
  // ============================================================================

  app.get('/health', (_req, res) => {
    res.json({ status: 'ok', timestamp: new Date().toISOString() });
  });

  // ============================================================================
  // API Routes
  // ============================================================================

  // API Routes
  app.use('/api/v1/auth', authRouter);
  app.use('/api/v1/admin/sessions', sessionsRouter);
  app.use('/api/v1/admin/compliance', complianceRouter);
  app.use('/api/v1/admin/iammai', iammaiRouter);
  app.use('/api/v1/admin/iammai', iammaiSseRouter);
  app.use('/api/v1/admin/iammai', iammaiGovernanceRouter);
  app.use('/api/v1/admin/iammai/accession', accessionRouter);
  app.use('/api/v1/sessions', publicRouter);
  app.use('/api/v1/sessions', tokensRouter);
  app.use('/api/v1/sessions', chatRouter);

  // API info endpoint
  app.get('/api/v1', (_req, res) => {
    res.json({
      name: 'IAMMAI Sandbox API',
      version: '1.0.0',
      documentation: '/api/v1/docs',
    });
  });

  // ============================================================================
  // Error Handling
  // ============================================================================

  // Handle 404 for unmatched routes
  app.use(notFoundHandler);

  // Global error handler (must be last)
  app.use(errorHandler);

  return app;
}
