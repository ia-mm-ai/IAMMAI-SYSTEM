/**
 * IAMMAI Governance API routes — Admin governance operations
 *
 * AUTHORITATIVE SURFACE — These endpoints exercise typed governance force
 * (HOLD, RELEASE, INVALIDATE, EVOLVE, DENY). Each follows the canonical
 * coordination sequence: Validate → Govern → Witness.
 *
 * All operations require admin auth and are matter-bounded.
 */

import { Router } from 'express';
import { requireAdmin } from '../middleware/auth.js';
import { asyncHandler, errors } from '../middleware/error.js';
import { transaction } from '../../lib/db.js';
import { matterRef, actorRef } from '../../integrity/iammai/types.js';
import { wsHub } from '../websocket/hub.js';
import {
  validateGovernancePreconditions,
  validateResolution,
} from '../../integrity/iammai/validator.js';
import { hold, release } from '../../integrity/iammai/containment-engine.js';
import { resolve } from '../../integrity/iammai/resolution-engine.js';
import { recordGovernanceAction } from '../../integrity/iammai/governor.js';
import { emitIammaiWitness } from '../../integrity/iammai/witness-factory.js';
import {
  getStateRecordsByMatter,
  getContainmentRecordsByMatter,
  getTransitionRecordsByMatter,
} from '../../integrity/iammai/registry.js';

export const iammaiGovernanceRouter = Router();

iammaiGovernanceRouter.use(requireAdmin);

// ============================================================================
// HOLD — Apply orthogonal containment to current state
// ============================================================================

iammaiGovernanceRouter.post(
  '/matters/:matterRef/hold',
  asyncHandler(async (req, res) => {
    const matter = decodeURIComponent(req.params['matterRef']!);
    const adminActor = actorRef(req.admin!.id);
    const { reason, legitimacy_basis_ref } = req.body as {
      reason?: string;
      legitimacy_basis_ref?: string;
    };

    if (!reason) throw errors.badRequest('reason is required');
    if (!legitimacy_basis_ref) throw errors.badRequest('legitimacy_basis_ref is required');

    const result = await transaction(async (client) => {
      // Step 1: Validate governance preconditions — produces typed artifact
      const validationArtifact = await validateGovernancePreconditions(client, {
        matter_ref: matter,
        actor_ref: adminActor,
        authority_class: 'OPERATOR',
        legitimacy_basis_ref,
      });

      if (validationArtifact.outcome !== 'pass') {
        return { validationArtifact, blocked: true };
      }

      // Get current state for target_state_ref
      const states = await getStateRecordsByMatter(matter, client);
      if (states.length === 0) {
        throw errors.notFound(`No state records found for matter ${matter}`);
      }
      const currentState = states[states.length - 1]!;

      // Step 2: Govern — apply HOLD
      const containmentResult = await hold(client, {
        matter_ref: matter,
        target_state_ref: currentState.state_id,
        actor_ref: adminActor,
        reason,
        legitimacy_basis_ref,
        authority_class: 'OPERATOR',
      });

      // Step 3: Witness — emit with all 5 mandatory non-claims
      const witnessArtifact = await emitIammaiWitness(client, {
        witness_type: 'state_observation',
        target_ref: matter,
        claims: [
          `hold_applied_to_state:${currentState.state_id}`,
          `actor:${adminActor}`,
          `authority_class:OPERATOR`,
          `legitimacy_basis:${legitimacy_basis_ref}`,
        ],
        actor_ref: adminActor,
        surface_ref: 'admin-governance-api',
      });

      return {
        validationArtifact,
        containmentResult,
        witnessArtifact,
        blocked: false,
      };
    });

    if (result.blocked) {
      res.status(422).json({
        error: 'GOVERNANCE_PRECONDITION_FAILED',
        validation: result.validationArtifact,
      });
      return;
    }

    // Broadcast IAMMAI_HELD to all connected users in this session
    const sessionId = matter.replace('bnk:session:', '');
    wsHub.broadcastIammaiEvent(sessionId, {
      type: 'IAMMAI_HELD',
      payload: { reason },
    });

    res.status(200).json({
      action: 'hold',
      matter_ref: matter,
      containment: result.containmentResult,
      witness: result.witnessArtifact,
      validation: result.validationArtifact,
    });
  })
);

// ============================================================================
// RELEASE — Release orthogonal containment
// ============================================================================

iammaiGovernanceRouter.post(
  '/matters/:matterRef/release',
  asyncHandler(async (req, res) => {
    const matter = decodeURIComponent(req.params['matterRef']!);
    const adminActor = actorRef(req.admin!.id);
    const { reason, legitimacy_basis_ref } = req.body as {
      reason?: string;
      legitimacy_basis_ref?: string;
    };

    if (!reason) throw errors.badRequest('reason is required');
    if (!legitimacy_basis_ref) throw errors.badRequest('legitimacy_basis_ref is required');

    const result = await transaction(async (client) => {
      // Step 1: Validate governance preconditions
      const validationArtifact = await validateGovernancePreconditions(client, {
        matter_ref: matter,
        actor_ref: adminActor,
        authority_class: 'OPERATOR',
        legitimacy_basis_ref,
      });

      if (validationArtifact.outcome !== 'pass') {
        return { validationArtifact, blocked: true };
      }

      // Get current state for target_state_ref
      const states = await getStateRecordsByMatter(matter, client);
      if (states.length === 0) {
        throw errors.notFound(`No state records found for matter ${matter}`);
      }
      const currentState = states[states.length - 1]!;

      // Step 2: Govern — apply RELEASE
      const containmentResult = await release(client, {
        matter_ref: matter,
        target_state_ref: currentState.state_id,
        actor_ref: adminActor,
        reason,
        legitimacy_basis_ref,
        authority_class: 'OPERATOR',
      });

      // Step 3: Witness
      const witnessArtifact = await emitIammaiWitness(client, {
        witness_type: 'state_observation',
        target_ref: matter,
        claims: [
          `hold_released_from_state:${currentState.state_id}`,
          `actor:${adminActor}`,
          `authority_class:OPERATOR`,
          `legitimacy_basis:${legitimacy_basis_ref}`,
        ],
        actor_ref: adminActor,
        surface_ref: 'admin-governance-api',
      });

      return {
        validationArtifact,
        containmentResult,
        witnessArtifact,
        blocked: false,
      };
    });

    if (result.blocked) {
      res.status(422).json({
        error: 'GOVERNANCE_PRECONDITION_FAILED',
        validation: result.validationArtifact,
      });
      return;
    }

    // Broadcast IAMMAI_RELEASED to all connected users
    const sessionId = matter.replace('bnk:session:', '');
    wsHub.broadcastIammaiEvent(sessionId, {
      type: 'IAMMAI_RELEASED',
      payload: {},
    });

    res.status(200).json({
      action: 'release',
      matter_ref: matter,
      containment: result.containmentResult,
      witness: result.witnessArtifact,
      validation: result.validationArtifact,
    });
  })
);

// ============================================================================
// INVALIDATE — Remove standing without erasing trace
// ============================================================================

iammaiGovernanceRouter.post(
  '/matters/:matterRef/invalidate',
  asyncHandler(async (req, res) => {
    const matter = decodeURIComponent(req.params['matterRef']!);
    const adminActor = actorRef(req.admin!.id);
    const { legitimacy_basis_ref } = req.body as {
      legitimacy_basis_ref?: string;
    };

    if (!legitimacy_basis_ref) throw errors.badRequest('legitimacy_basis_ref is required');

    const result = await transaction(async (client) => {
      // Step 1a: Validate governance preconditions
      const govValidation = await validateGovernancePreconditions(client, {
        matter_ref: matter,
        actor_ref: adminActor,
        authority_class: 'OPERATOR',
        legitimacy_basis_ref,
      });

      if (govValidation.outcome !== 'pass') {
        return { govValidation, blocked: true };
      }

      // Step 1b: Validate resolution eligibility
      const states = await getStateRecordsByMatter(matter, client);
      const containments = await getContainmentRecordsByMatter(matter);
      const transitions = await getTransitionRecordsByMatter(matter);
      const alreadyResolved = transitions.some(t => t.transition_type === 'resolution_transition');

      const resolutionValidation = await validateResolution(client, {
        matter_ref: matter,
        current_state: states[states.length - 1] ?? null,
        containment_records: containments,
        is_already_resolved: alreadyResolved,
        actor_ref: adminActor,
      });

      if (resolutionValidation.outcome !== 'pass') {
        return { govValidation, resolutionValidation, blocked: true };
      }

      // Step 2: Govern — INVALIDATE
      const resolutionResult = await resolve(client, {
        matter_ref: matter,
        resolution_type: 'INVALIDATE',
        actor_ref: adminActor,
        legitimacy_basis_ref,
        authority_class: 'OPERATOR',
      });

      // Step 3: Witness
      const witnessArtifact = await emitIammaiWitness(client, {
        witness_type: 'transition',
        target_ref: matter,
        claims: [
          `resolution_type:INVALIDATE`,
          `actor:${adminActor}`,
          `authority_class:OPERATOR`,
          `legitimacy_basis:${legitimacy_basis_ref}`,
          'standing_removed_trace_preserved',
        ],
        actor_ref: adminActor,
        surface_ref: 'admin-governance-api',
      });

      return {
        govValidation,
        resolutionValidation,
        resolutionResult,
        witnessArtifact,
        blocked: false,
      };
    });

    if (result.blocked) {
      res.status(422).json({
        error: 'INVALIDATE_PRECONDITION_FAILED',
        gov_validation: result.govValidation,
        resolution_validation: result.resolutionValidation,
      });
      return;
    }

    // Broadcast IAMMAI_RESOLVED to all connected users
    const sessionId = matter.replace('bnk:session:', '');
    wsHub.broadcastIammaiEvent(sessionId, {
      type: 'IAMMAI_RESOLVED',
      payload: { resolutionType: 'INVALIDATE' },
    });

    res.status(200).json({
      action: 'invalidate',
      matter_ref: matter,
      resolution: result.resolutionResult,
      witness: result.witnessArtifact,
    });
  })
);

// ============================================================================
// EVOLVE — Create lawful successor with explicit predecessor relation
// ============================================================================

iammaiGovernanceRouter.post(
  '/matters/:matterRef/evolve',
  asyncHandler(async (req, res) => {
    const matter = decodeURIComponent(req.params['matterRef']!);
    const adminActor = actorRef(req.admin!.id);
    const { successor_session_name, legitimacy_basis_ref } = req.body as {
      successor_session_name?: string;
      legitimacy_basis_ref?: string;
    };

    if (!successor_session_name) throw errors.badRequest('successor_session_name is required');
    if (!legitimacy_basis_ref) throw errors.badRequest('legitimacy_basis_ref is required');

    const result = await transaction(async (client) => {
      // Step 1a: Validate governance preconditions
      const govValidation = await validateGovernancePreconditions(client, {
        matter_ref: matter,
        actor_ref: adminActor,
        authority_class: 'OPERATOR',
        legitimacy_basis_ref,
      });

      if (govValidation.outcome !== 'pass') {
        return { govValidation, blocked: true };
      }

      // Step 1b: Validate resolution eligibility
      const states = await getStateRecordsByMatter(matter, client);
      const containments = await getContainmentRecordsByMatter(matter);
      const transitions = await getTransitionRecordsByMatter(matter);
      const alreadyResolved = transitions.some(t => t.transition_type === 'resolution_transition');

      const resolutionValidation = await validateResolution(client, {
        matter_ref: matter,
        current_state: states[states.length - 1] ?? null,
        containment_records: containments,
        is_already_resolved: alreadyResolved,
        actor_ref: adminActor,
      });

      if (resolutionValidation.outcome !== 'pass') {
        return { govValidation, resolutionValidation, blocked: true };
      }

      // Create successor session record in same transaction
      const successorRow = await client.query<{ id: string }>(
        `INSERT INTO sessions (name, admin_id, context_descriptor, environmental_constraints, iammai_tracked)
         VALUES ($1, $2, $3, $4, true)
         RETURNING id`,
        [
          successor_session_name,
          req.admin!.id,
          JSON.stringify({ topic: `Evolved from ${matter}`, purpose: 'IAMMAI EVOLVE successor' }),
          JSON.stringify({ maxParticipants: 10 }),
        ]
      );
      const successorSessionId = successorRow.rows[0]!.id;
      const successorMatter = matterRef(successorSessionId);

      // Step 2: Govern — EVOLVE with successor
      const resolutionResult = await resolve(client, {
        matter_ref: matter,
        resolution_type: 'EVOLVE',
        actor_ref: adminActor,
        legitimacy_basis_ref,
        authority_class: 'OPERATOR',
        successor_matter_ref: successorMatter,
      });

      // Step 3: Witness
      const witnessArtifact = await emitIammaiWitness(client, {
        witness_type: 'transition',
        target_ref: matter,
        claims: [
          `resolution_type:EVOLVE`,
          `successor_matter:${successorMatter}`,
          `actor:${adminActor}`,
          `authority_class:OPERATOR`,
          `legitimacy_basis:${legitimacy_basis_ref}`,
          'predecessor_successor_relation_established',
        ],
        actor_ref: adminActor,
        surface_ref: 'admin-governance-api',
      });

      return {
        govValidation,
        resolutionValidation,
        resolutionResult,
        witnessArtifact,
        successorSessionId,
        successorMatter,
        blocked: false,
      };
    });

    if (result.blocked) {
      res.status(422).json({
        error: 'EVOLVE_PRECONDITION_FAILED',
        gov_validation: result.govValidation,
        resolution_validation: result.resolutionValidation,
      });
      return;
    }

    // Broadcast IAMMAI_RESOLVED to connected users
    const sessionId = matter.replace('bnk:session:', '');
    wsHub.broadcastIammaiEvent(sessionId, {
      type: 'IAMMAI_RESOLVED',
      payload: { resolutionType: 'EVOLVE' },
    });

    res.status(200).json({
      action: 'evolve',
      matter_ref: matter,
      successor_matter_ref: result.successorMatter,
      successor_session_id: result.successorSessionId,
      resolution: result.resolutionResult,
      witness: result.witnessArtifact,
    });
  })
);

// ============================================================================
// DENY — Record typed governance denial (not absence of response)
// ============================================================================

iammaiGovernanceRouter.post(
  '/matters/:matterRef/deny',
  asyncHandler(async (req, res) => {
    const matter = decodeURIComponent(req.params['matterRef']!);
    const adminActor = actorRef(req.admin!.id);
    const { target_action, reason, legitimacy_basis_ref } = req.body as {
      target_action?: string;
      reason?: string;
      legitimacy_basis_ref?: string;
    };

    if (!target_action) throw errors.badRequest('target_action is required');
    if (!reason) throw errors.badRequest('reason is required');
    if (!legitimacy_basis_ref) throw errors.badRequest('legitimacy_basis_ref is required');

    const result = await transaction(async (client) => {
      // Step 1: Validate governance preconditions
      const validationArtifact = await validateGovernancePreconditions(client, {
        matter_ref: matter,
        actor_ref: adminActor,
        authority_class: 'OPERATOR',
        legitimacy_basis_ref,
      });

      if (validationArtifact.outcome !== 'pass') {
        return { validationArtifact, blocked: true };
      }

      // Step 2: Govern — record typed DENY (denial is not absence of response)
      const governanceAction = await recordGovernanceAction(client, {
        action_type: 'deny',
        authority_class: 'OPERATOR',
        actor_ref: adminActor,
        legitimacy_basis_ref,
        matter_ref: matter,
      });

      // Step 3: Witness — denial must be recorded with trace
      const witnessArtifact = await emitIammaiWitness(client, {
        witness_type: 'validation',
        target_ref: matter,
        claims: [
          `governance_denial_recorded`,
          `target_action:${target_action}`,
          `reason:${reason}`,
          `actor:${adminActor}`,
          `authority_class:OPERATOR`,
          `legitimacy_basis:${legitimacy_basis_ref}`,
        ],
        actor_ref: adminActor,
        surface_ref: 'admin-governance-api',
      });

      return {
        validationArtifact,
        governanceAction,
        witnessArtifact,
        blocked: false,
      };
    });

    if (result.blocked) {
      res.status(422).json({
        error: 'GOVERNANCE_PRECONDITION_FAILED',
        validation: result.validationArtifact,
      });
      return;
    }

    res.status(200).json({
      action: 'deny',
      matter_ref: matter,
      target_action,
      reason,
      governance_action: result.governanceAction,
      witness: result.witnessArtifact,
    });
  })
);
