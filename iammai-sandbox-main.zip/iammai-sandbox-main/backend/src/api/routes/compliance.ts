/**
 * Admin compliance route
 * @see specs/009-compliance-test/spec.md
 * @see specs/009-compliance-test/contracts/compliance-api.yaml
 */

import { Router } from 'express';
import { requireAdmin } from '../middleware/auth.js';
import { asyncHandler } from '../middleware/error.js';
import { runComplianceCheck, runConditionCheck } from '../../integrity/compliance-checker.js';
import type { ComplianceCondition } from '../../integrity/types.js';

export const complianceRouter = Router();

// All compliance routes require admin authentication
complianceRouter.use(requireAdmin);

const VALID_CONDITIONS = new Set<ComplianceCondition>([
  'TRUTH_FINALIZATION',
  'DETERMINISTIC_VERIFICATION',
  'MANDATORY_SUPPRESSION',
  'HISTORY_NON_REGRESSION',
  'AUTHORITY_NON_ASSERTION',
]);

/**
 * GET /admin/compliance
 * Run the full compliance check, or a single condition when ?condition= is provided.
 * @see specs/009-compliance-test/contracts/compliance-api.yaml
 */
complianceRouter.get(
  '/',
  asyncHandler(async (req, res) => {
    const conditionParam = req.query['condition'] as string | undefined;

    if (conditionParam !== undefined) {
      if (!VALID_CONDITIONS.has(conditionParam as ComplianceCondition)) {
        res.status(400).json({
          code: 'INVALID_CONDITION',
          message: `Invalid condition: ${conditionParam}. Valid conditions: ${[...VALID_CONDITIONS].join(', ')}`,
        });
        return;
      }

      const result = await runConditionCheck(conditionParam as ComplianceCondition);
      const statusCode = result.overall === 'ERROR' ? 500 : 200;
      res.status(statusCode).json(result);
      return;
    }

    const result = await runComplianceCheck();
    const statusCode = result.overall === 'ERROR' ? 500 : 200;
    res.status(statusCode).json(result);
  })
);
