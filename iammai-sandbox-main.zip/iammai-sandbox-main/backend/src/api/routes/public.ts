/**
 * Public session routes (no authentication required)
 * @see specs/001-ephemeral-kernel/tasks.md#T056
 * @see specs/001-ephemeral-kernel/contracts/api.yaml#public
 */

import { Router } from 'express';
import * as sessionModel from '../../models/session.js';
import { asyncHandler, errors } from '../middleware/error.js';
import type { Session, PublicSession } from '../../lib/types.js';
import {
  getStateRecordsByMatter,
  getContributionRecordsByMatter,
  getTransitionRecordsByMatter,
} from '../../integrity/iammai/registry.js';
import { isCurrentStateHeld } from '../../integrity/iammai/containment-engine.js';
import { matterRef as makeMatterRef } from '../../integrity/iammai/types.js';

export const publicRouter = Router();

/**
 * Format session for public API response
 * Only exposes non-sensitive information
 */
function formatPublicSession(session: Session): PublicSession {
  return {
    id: session.id,
    name: session.name,
    state: session.state,
    canClaim: session.state === 'CREATED',
    canJoin: session.state === 'ACTIVE',
  };
}

/**
 * GET /sessions
 * Browse available sessions (CREATED or ACTIVE only)
 * @see contracts/api.yaml lines 233-257
 */
publicRouter.get(
  '/',
  asyncHandler(async (req, res) => {
    const stateFilter = req.query.state as string | undefined;
    const limit = Math.min(parseInt(req.query.limit as string) || 20, 50);

    // Validate state filter - only CREATED or ACTIVE allowed
    if (stateFilter && stateFilter !== 'CREATED' && stateFilter !== 'ACTIVE') {
      throw errors.badRequest(
        'Invalid state filter. Only CREATED or ACTIVE are allowed for public browsing'
      );
    }

    const sessions = await sessionModel.listPublic({
      state: stateFilter as 'CREATED' | 'ACTIVE' | undefined,
      limit,
    });

    res.json({
      sessions: sessions.map(formatPublicSession),
    });
  })
);

/**
 * GET /sessions/:id
 * Get public session info
 * @see contracts/api.yaml lines 259-274
 */
publicRouter.get(
  '/:id',
  asyncHandler(async (req, res) => {
    const { id } = req.params;

    const session = await sessionModel.findById(id);

    if (!session) {
      throw errors.notFound('Session');
    }

    // Only show CREATED or ACTIVE sessions to public
    if (session.state === 'ENDED') {
      throw errors.notFound('Session');
    }

    res.json(formatPublicSession(session));
  })
);

/**
 * GET /sessions/:id/iammai-status
 * Get IAMMAI phase/containment status for a session (public, derivative surface).
 * Used by user-facing status bar to show constitutional state without sensitive governance details.
 */
publicRouter.get(
  '/:id/iammai-status',
  asyncHandler(async (req, res) => {
    const { id } = req.params as { id: string };

    const session = await sessionModel.findById(id);
    if (!session) throw errors.notFound('Session');
    if (session.state === 'ENDED') throw errors.notFound('Session');

    if (!session.iammaiTracked) {
      res.json({ tracked: false });
      return;
    }

    const matter = makeMatterRef(id);
    const [states, transitions, contributions] = await Promise.all([
      getStateRecordsByMatter(matter),
      getTransitionRecordsByMatter(matter),
      getContributionRecordsByMatter(matter),
    ]);

    if (states.length === 0) {
      res.json({ tracked: true, phase: null, family: null, isHeld: false, isResolved: false, resolutionType: null, contributionRoles: [] });
      return;
    }

    const currentState = states[states.length - 1]!;
    const isHeld = await isCurrentStateHeld(matter);
    const resolutionTransition = transitions.find(t => t.transition_type === 'resolution_transition');

    // Expose only typed-safe public information — no actor_ref, no governance detail
    res.json({
      tracked: true,
      phase: currentState.state_type,
      family: currentState.state_family,
      isHeld,
      isResolved: !!resolutionTransition,
      resolutionType: resolutionTransition?.resolution_type ?? null,
      contributionRoles: [...new Set(contributions.map(c => c.role))],
    });
  })
);
