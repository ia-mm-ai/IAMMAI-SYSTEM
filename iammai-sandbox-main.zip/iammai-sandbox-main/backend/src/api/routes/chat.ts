/**
 * Chat routes - user sends messages, receives via WebSocket
 * @see specs/001-ephemeral-kernel/tasks.md#T073
 * @see specs/001-ephemeral-kernel/contracts/api.yaml lines 341-376
 */

import { Router } from 'express';
import { asyncHandler, errors } from '../middleware/error.js';
import { requireTokenForSession } from '../middleware/token.js';
import { v4 as uuidv4 } from 'uuid';
import type { SendMessageRequest } from '../../lib/types.js';

export const chatRouter = Router();

/**
 * POST /api/v1/sessions/:sessionId/messages
 * Send a chat message (response streams via WebSocket)
 * @see contracts/api.yaml lines 341-376
 */
chatRouter.post(
  '/:sessionId/messages',
  requireTokenForSession('sessionId'),
  asyncHandler(async (req, res) => {
    const { sessionId } = req.params;
    const { content, messageId } = req.body as Partial<SendMessageRequest>;

    // Session validation is handled by requireTokenForSession middleware

    // Validate content
    if (!content || typeof content !== 'string') {
      throw errors.badRequest('Message content is required');
    }

    const trimmedContent = content.trim();

    if (trimmedContent.length === 0) {
      throw errors.badRequest('Message content cannot be empty');
    }

    if (trimmedContent.length > 10000) {
      throw errors.badRequest('Message content must be 10000 characters or less');
    }

    // Validate messageId if provided
    let finalMessageId = messageId;
    if (messageId) {
      // Basic UUID validation
      const uuidRegex =
        /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i;
      if (!uuidRegex.test(messageId)) {
        throw errors.badRequest('Invalid messageId format');
      }
    } else {
      finalMessageId = uuidv4();
    }

    // Return 202 Accepted - actual response streams via WebSocket
    // The WebSocket handler will process this message when it receives USER_MESSAGE
    res.status(202).json({
      messageId: finalMessageId,
      status: 'ACCEPTED',
    });
  })
);
