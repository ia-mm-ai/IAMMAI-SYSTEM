/**
 * Admin session routes
 * @see specs/001-ephemeral-kernel/tasks.md#T041-T043
 * @see specs/001-ephemeral-kernel/contracts/api.yaml#sessions
 * @see specs/005-structural-foundation/spec.md
 */

import { Router } from 'express';
import * as sessionModel from '../../models/session.js';
import { kernelManager } from '../../kernel/manager.js';
import { asyncHandler, errors } from '../middleware/error.js';
import { requireAdmin } from '../middleware/auth.js';
import { wsHub } from '../websocket/hub.js';
import { transaction } from '../../lib/db.js';
import { observeTransition } from '../../integrity/state-observer.js';
import { validateContextDescriptor, validateEnvironmentalConstraints } from '../../integrity/boundary.js';
import * as ledger from '../../integrity/ledger.js';
import { verify } from '../../integrity/verification-engine.js';
import { emitWitness } from '../../integrity/witness-emitter.js';
import * as presenceTracker from '../../integrity/presence-tracker.js';
import * as suppressionEngine from '../../integrity/suppression-engine.js';
import { recordActivity, clearSession as clearAcediaSession } from '../../integrity/acedia-monitor.js';
import * as coAgencyTracker from '../../integrity/co-agency-tracker.js';
import { getAiMetadata, clearAiMetadata } from '../websocket/handlers.js';
import { derivePresenceHash } from '../../services/presence.js';
import {
  coordinateSessionCreate,
  coordinateSessionStartFull,
  coordinateSessionEnd,
  coordinateThresholdToTruth,
} from '../../integrity/iammai/coordinator.js';
import { isCurrentStateHeld } from '../../integrity/iammai/containment-engine.js';
import { matterRef as makeMatterRef } from '../../integrity/iammai/types.js';
import { logger } from '../../lib/logger.js';
import type { SessionState, KernelStatus, LifecycleEvent } from '../../lib/types.js';

export const sessionsRouter = Router();

// All session routes require admin authentication
sessionsRouter.use(requireAdmin);

/**
 * Get kernel status by checking actual kernel manager
 */
function getActualKernelStatus(sessionId: string, state: SessionState): KernelStatus {
  if (state === 'ENDED') {
    return 'DISSOLVED';
  }
  if (state === 'ACTIVE' && kernelManager.hasKernel(sessionId)) {
    return 'ACTIVE';
  }
  return 'NOT_CREATED';
}

/**
 * Build lifecycle events from session timestamps
 */
function buildLifecycle(session: {
  createdAt: Date;
  startedAt: Date | null;
  endedAt: Date | null;
}): LifecycleEvent[] {
  const events: LifecycleEvent[] = [
    { event: 'CREATED', timestamp: session.createdAt },
  ];

  if (session.startedAt) {
    events.push({ event: 'STARTED', timestamp: session.startedAt });
  }

  if (session.endedAt) {
    events.push({ event: 'ENDED', timestamp: session.endedAt });
  }

  return events;
}

/**
 * Format session for API response
 */
function formatSession(session: {
  id: string;
  name: string;
  state: SessionState;
  createdAt: Date;
  startedAt: Date | null;
  endedAt: Date | null;
  tokenCount: number;
  userCount: number;
  contextDescriptor: { topic: string; purpose?: string };
  environmentalConstraints: { max_participants: number; time_limit_minutes?: number; ai_model?: string };
}) {
  return {
    id: session.id,
    name: session.name,
    state: session.state,
    createdAt: session.createdAt.toISOString(),
    startedAt: session.startedAt?.toISOString() ?? null,
    endedAt: session.endedAt?.toISOString() ?? null,
    tokenCount: session.tokenCount,
    userCount: session.userCount,
    contextDescriptor: session.contextDescriptor,
    environmentalConstraints: session.environmentalConstraints,
  };
}

/**
 * GET /admin/sessions
 * List all sessions
 */
sessionsRouter.get(
  '/',
  asyncHandler(async (req, res) => {
    const state = req.query['state'] as SessionState | undefined;
    const limit = Math.min(parseInt(req.query['limit'] as string) || 50, 100);
    const offset = parseInt(req.query['offset'] as string) || 0;

    const { sessions, total } = await sessionModel.list({
      state: state as SessionState,
      limit,
      offset,
    });

    res.json({
      sessions: sessions.map(formatSession),
      total,
      limit,
      offset,
    });
  })
);

/**
 * POST /admin/sessions
 * Create a new session with boundary declarations
 * @see specs/005-structural-foundation/spec.md US3 - Event Boundary Enforcement
 */
sessionsRouter.post(
  '/',
  asyncHandler(async (req, res) => {
    const { name, context_descriptor, environmental_constraints, iammai_tracked } = req.body;

    // Validate name
    if (!name || typeof name !== 'string') {
      throw errors.badRequest('Name is required');
    }

    const trimmedName = name.trim();

    if (trimmedName.length === 0) {
      throw errors.badRequest('Name cannot be empty');
    }

    if (trimmedName.length > 255) {
      throw errors.badRequest('Name must be 255 characters or less');
    }

    // Validate boundary declarations (FR-004)
    const ctxResult = validateContextDescriptor(context_descriptor);
    if (!ctxResult.ok) {
      throw errors.badRequest(ctxResult.error.message, ctxResult.error.details);
    }

    const envResult = validateEnvironmentalConstraints(environmental_constraints);
    if (!envResult.ok) {
      throw errors.badRequest(envResult.error.message, envResult.error.details);
    }

    // Coerce iammai_tracked to boolean, default false
    const iammaiTrackedFlag = iammai_tracked === true || iammai_tracked === 'true';

    // Create session with boundaries and record in ledger atomically
    const session = await transaction(async (client) => {
      // Insert session using direct query within transaction
      const result = await client.query(
        `INSERT INTO sessions (name, admin_id, context_descriptor, environmental_constraints, iammai_tracked)
         VALUES ($1, $2, $3, $4, $5)
         RETURNING *`,
        [trimmedName, req.admin!.id, JSON.stringify(ctxResult.value), JSON.stringify(envResult.value), iammaiTrackedFlag]
      );
      const row = result.rows[0];
      if (!row) throw new Error('Failed to create session');

      const created = {
        id: row.id,
        name: row.name,
        state: row.state as SessionState,
        createdAt: row.created_at,
        startedAt: row.started_at,
        endedAt: row.ended_at,
        tokenCount: row.token_count,
        userCount: row.user_count,
        adminId: row.admin_id,
        contextDescriptor: row.context_descriptor,
        environmentalConstraints: row.environmental_constraints,
        iammaiTracked: row.iammai_tracked ?? false,
      };

      // Record creation in integrity ledger (atomic with session insert)
      await observeTransition(client, created, null, 'CREATED', 'SESSION_CREATED');

      // Attest admin presence (atomic with session creation)
      await presenceTracker.attestPresence(
        client,
        created.id,
        'CREATOR',
        derivePresenceHash(created.adminId),
        'AUTH_EVENT'
      );

      // Coordinate IAMMAI phases: signal + acceptance (BLOCKING — rolls back on failure)
      if (created.iammaiTracked) {
        await coordinateSessionCreate(client, {
          sessionId: created.id,
          adminId: created.adminId,
        });
      }

      return created;
    });

    // Log admin action
    suppressionEngine.logAdminAction({
      sessionId: session.id,
      actionType: 'SESSION_CREATE',
      timestamp: new Date(),
      outcome: 'EXECUTED',
    });

    res.status(201).json(formatSession(session));
  })
);

/**
 * GET /admin/sessions/:id
 * Get session details
 */
sessionsRouter.get(
  '/:id',
  asyncHandler(async (req, res) => {
    const id = req.params['id'] as string;

    const session = await sessionModel.findById(id);

    if (!session) {
      throw errors.notFound('Session not found');
    }

    res.json({
      ...formatSession(session),
      kernelStatus: getActualKernelStatus(session.id, session.state),
      lifecycle: buildLifecycle(session).map(e => ({
        event: e.event,
        timestamp: e.timestamp.toISOString(),
      })),
    });
  })
);

/**
 * POST /admin/sessions/:id/start
 * Start a session (CREATED -> ACTIVE) with atomic ledger recording
 */
sessionsRouter.post(
  '/:id/start',
  asyncHandler(async (req, res) => {
    const id = req.params['id'] as string;

    const session = await sessionModel.findById(id);

    if (!session) {
      throw errors.notFound('Session not found');
    }

    // IAMMAI containment gate — block if matter is held
    if (session.iammaiTracked) {
      const held = await isCurrentStateHeld(makeMatterRef(id));
      if (held) {
        throw errors.forbidden('Session matter is held by IAMMAI containment. Release the hold before starting.');
      }
    }

    // Suppression check before state mutation
    const suppressionResult = await suppressionEngine.evaluateAction(id, 'SESSION_START');
    if (!suppressionResult.allowed) {
      // Record suppression and log admin action
      await transaction(async (client) => {
        await suppressionEngine.recordSuppression(client, id, suppressionResult.suppression!);
      });
      suppressionEngine.logAdminAction({
        sessionId: id,
        actionType: 'SESSION_START',
        timestamp: new Date(),
        outcome: 'SUPPRESSED',
      });
      throw errors.forbidden(suppressionResult.suppression!.reason);
    }

    // Log admin action
    suppressionEngine.logAdminAction({
      sessionId: id,
      actionType: 'SESSION_START',
      timestamp: new Date(),
      outcome: 'EXECUTED',
    });

    // Record admin activity for acedia monitoring (Feature 008)
    recordActivity(id);

    // Atomic state transition + ledger entry
    const updated = await transaction(async (client) => {
      const result = await sessionModel.transitionState(id, session.state, 'ACTIVE', client);

      if (!result) {
        // Record the rejected transition
        await observeTransition(client, session, session.state, 'ACTIVE', 'TRANSITION_REJECTED');
        return null;
      }

      // Record successful transition
      await observeTransition(client, result, session.state, 'ACTIVE', 'SESSION_ACTIVATED');

      // Coordinate IAMMAI phases: scope + presence + threshold (BLOCKING — rolls back on failure)
      // Note: truth phase is advanced separately via POST /admin/sessions/:id/confirm-truth (Phase 3)
      if (result && result.iammaiTracked) {
        await coordinateSessionStartFull(client, {
          sessionId: id,
          adminId: req.admin!.id,
        });
      }

      return result;
    });

    if (!updated) {
      throw errors.badRequest(
        `Invalid state transition: cannot start session in ${session.state} state`
      );
    }

    // Create kernel
    kernelManager.createKernel(id);

    res.json(formatSession(updated));
  })
);

/**
 * POST /admin/sessions/:id/confirm-truth
 * Explicitly advance IAMMAI matter from threshold → truth (preparation → standing-state boundary).
 * This is the most critical IAMMAI boundary crossing and requires explicit admin acknowledgment.
 * Without this call, users cannot send messages (matter is in preparation regime).
 */
sessionsRouter.post(
  '/:id/confirm-truth',
  asyncHandler(async (req, res) => {
    const id = req.params['id'] as string;
    const { legitimacy_basis_ref } = req.body as { legitimacy_basis_ref?: string };

    const session = await sessionModel.findById(id);
    if (!session) throw errors.notFound('Session not found');
    if (session.state !== 'ACTIVE') {
      throw errors.badRequest('Session must be ACTIVE to confirm truth formation');
    }
    if (!session.iammaiTracked) {
      throw errors.badRequest('Session is not IAMMAI-tracked');
    }

    // Advance threshold → truth (preparation → standing-state boundary)
    const phaseResult = await transaction(async (client) => {
      return coordinateThresholdToTruth(client, {
        sessionId: id,
        adminId: req.admin!.id,
        ...(legitimacy_basis_ref ? { legitimacy_basis_ref } : {}),
      });
    });

    res.json({
      sessionId: id,
      matter_ref: `bnk:session:${id}`,
      phase: 'truth',
      family: 'standing',
      message: 'Truth formation confirmed. Matter is now in standing-state regime. Messaging is permitted.',
      phaseResult: {
        stateRecord: phaseResult.stateRecord,
        governanceAction: phaseResult.governanceAction,
        witnessArtifact: phaseResult.witnessArtifact,
      },
    });
  })
);

/**
 * POST /admin/sessions/:id/end
 * End a session (ACTIVE -> ENDED) with atomic ledger recording
 */
sessionsRouter.post(
  '/:id/end',
  asyncHandler(async (req, res) => {
    const id = req.params['id'] as string;

    const session = await sessionModel.findById(id);

    if (!session) {
      throw errors.notFound('Session not found');
    }

    // Session closure is NEVER blocked by suppression — always proceeds
    suppressionEngine.logAdminAction({
      sessionId: id,
      actionType: 'SESSION_END',
      timestamp: new Date(),
      outcome: 'EXECUTED',
    });

    // Record admin activity for acedia monitoring (Feature 008)
    recordActivity(id);

    // Co-agency check (informational — SESSION_END is never blocked)
    coAgencyTracker.canPerformAction(id, 'HUMAN');

    // Atomic state transition + ledger entry
    const updated = await transaction(async (client) => {
      const result = await sessionModel.transitionState(id, session.state, 'ENDED', client);

      if (!result) {
        // Record the rejected transition
        await observeTransition(client, session, session.state, 'ENDED', 'TRANSITION_REJECTED');
        return null;
      }

      // Record successful transition
      await observeTransition(client, result, session.state, 'ENDED', 'SESSION_CLOSED');
      return result;
    });

    if (!updated) {
      throw errors.badRequest(
        `Invalid state transition: cannot end session in ${session.state} state`
      );
    }

    // Co-agency: track HUMAN irreversible action (SESSION_END) — Feature 008
    coAgencyTracker.trackAction(id, 'HUMAN', 'SESSION_END');

    // Coordinate IAMMAI phases: decision + consequence + FINALIZE (non-blocking)
    if (updated.iammaiTracked) {
      try {
        await transaction(async (client) => {
          await coordinateSessionEnd(client, {
            sessionId: id,
            adminId: req.admin!.id,
          });
        });
      } catch (err) {
        logger.warn('IAMMAI coordination failed during session end', {
          sessionId: id,
          error: (err as Error).message,
        });
      }
    }

    // Finalize presence records (separate transaction)
    await transaction(async (client) => {
      await presenceTracker.finalizePresence(client, id);
    });

    // Co-agency: track MACHINE irreversible action (PRESENCE_FINALIZATION) — Feature 008
    coAgencyTracker.trackAction(id, 'MACHINE', 'PRESENCE_FINALIZATION');

    // Retrieve finalized presence records and admin actions
    const presenceRecords = await presenceTracker.getPresenceRecords(id);
    const presenceSummary = await presenceTracker.getPresenceSummary(id);
    const adminActions = suppressionEngine.getAdminActions(id);
    const coAgencyActions = coAgencyTracker.getHistory(id);

    // Load IAMMAI context for tracked sessions
    let iammaiContext;
    if (updated.iammaiTracked) {
      const { loadIammaiContext } = await import('../../integrity/iammai/registry.js');
      const { matterRef: makeMatterRef } = await import('../../integrity/iammai/types.js');
      iammaiContext = await loadIammaiContext(makeMatterRef(id));
    }

    // Run verification with presence, co-agency, and IAMMAI context (read-only, outside transaction)
    const entries = await ledger.getEntriesBySession(id);
    const verificationResult = verify(updated, entries, undefined, presenceRecords, adminActions, coAgencyActions, iammaiContext);

    // Co-agency: track MACHINE irreversible action (VERIFICATION_EXECUTION) — Feature 008
    coAgencyTracker.trackAction(id, 'MACHINE', 'VERIFICATION_EXECUTION');

    // If verification FAILed, record SUPPRESSION_EVENT noting the failed protocols
    const suppressionTriggered = !verificationResult.pass;
    if (suppressionTriggered) {
      const failedProtocols = verificationResult.protocolResults.filter(r => r.result === 'FAIL');
      await transaction(async (client) => {
        await suppressionEngine.recordSuppression(client, id, {
          sessionId: id,
          actionType: 'SESSION_END',
          failedProtocols,
          reason: `Verification failed on session close: ${failedProtocols.map(p => p.protocol).join(', ')}`,
          timestamp: new Date(),
        });
      });
    }

    // Retrieve AI metadata for witness emission (Feature 008: US5)
    const aiMetadata = getAiMetadata(id);

    // Emit witness with real presence and AI metadata
    await emitWitness(verificationResult, updated, entries, presenceSummary, suppressionTriggered, aiMetadata);

    // Broadcast dissolution to all connected users
    wsHub.broadcastDissolution(id, 'Your conversation is gone');

    // Dissolve kernel (this destroys ALL conversations)
    kernelManager.dissolveKernel(id);

    // Clear admin actions for this session
    suppressionEngine.clearAdminActions(id);

    // Clear governance tracking state (Feature 008)
    clearAcediaSession(id);
    coAgencyTracker.clearSession(id);
    clearAiMetadata(id);

    res.json(formatSession(updated));
  })
);

/**
 * GET /admin/sessions/:id/ledger
 * Get integrity ledger entries for a session
 * @see specs/005-structural-foundation/spec.md US2
 */
sessionsRouter.get(
  '/:id/ledger',
  asyncHandler(async (req, res) => {
    const id = req.params['id'] as string;

    const session = await sessionModel.findById(id);
    if (!session) {
      throw errors.notFound('Session not found');
    }

    const entries = await ledger.getEntriesBySession(id);
    res.json({ entries });
  })
);

/**
 * GET /admin/integrity/validate
 * Validate the integrity ledger hash chain
 * @see specs/005-structural-foundation/spec.md US2
 */
sessionsRouter.get(
  '/integrity/validate',
  asyncHandler(async (_req, res) => {
    const result = await ledger.validateChain();
    res.json(result);
  })
);
