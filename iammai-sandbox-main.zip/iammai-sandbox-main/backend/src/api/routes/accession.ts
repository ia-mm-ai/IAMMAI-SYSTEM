/**
 * Accession Layer API Routes
 *
 * Mounted at /api/v1/admin/iammai/accession
 *
 * Seed management: POST /seed, POST /reset
 * Stage advancement: POST /slices/:sliceId/advance
 * Inspection (read-only, derivative): GET /sources, GET /slices, GET /slices/:sliceId, GET /slices/:sliceId/stages/:stage
 */

import { Router } from 'express';
import { requireAdmin } from '../middleware/auth.js';
import { asyncHandler, errors } from '../middleware/error.js';
import { transaction } from '../../lib/db.js';
import { actorRef } from '../../integrity/iammai/types.js';
import {
  getExternalSources,
  listSlicesWithStage,
  loadAccessionContext,
  getAccessionStatesBySlice,
} from '../../integrity/iammai/accession/accession-registry.js';
import { advanceSlice } from '../../integrity/iammai/accession/accession-coordinator.js';
import { loadSeedCases, resetAndReseed } from '../../integrity/iammai/accession/seed-cases.js';

export const accessionRouter = Router();

accessionRouter.use(requireAdmin);

/** Wrap response with derivative surface metadata */
function derivative(data: unknown) {
  return {
    _derivative: {
      surface: 'admin-dashboard',
      authoritative_source: 'iammai_accession_tables',
      fetched_at: new Date().toISOString(),
    },
    data,
  };
}

// ============================================================================
// Seed Management
// ============================================================================

/**
 * POST /seed — Load both seed cases (creates sources + slices at Contact)
 */
accessionRouter.post(
  '/seed',
  asyncHandler(async (_req, res) => {
    const result = await transaction(async (client) => {
      return loadSeedCases(client);
    });
    res.status(201).json({
      message: 'Seed cases loaded',
      clean_slice_id: result.cleanSliceId,
      messy_slice_id: result.messySliceId,
    });
  })
);

/**
 * POST /reset — Truncate accession tables and optionally reseed
 */
accessionRouter.post(
  '/reset',
  asyncHandler(async (req, res) => {
    const reseed = req.body?.reseed !== false;
    const result = await transaction(async (client) => {
      if (reseed) {
        return resetAndReseed(client);
      }
      const { resetAccessionTables } = await import(
        '../../integrity/iammai/accession/accession-registry.js'
      );
      await resetAccessionTables(client);
      return null;
    });
    res.status(200).json({
      message: reseed ? 'Reset and reseeded' : 'Reset complete',
      ...(result && { clean_slice_id: result.cleanSliceId, messy_slice_id: result.messySliceId }),
    });
  })
);

// ============================================================================
// Stage Advancement
// ============================================================================

/**
 * POST /slices/:sliceId/advance — Advance to next stage
 */
accessionRouter.post(
  '/slices/:sliceId/advance',
  asyncHandler(async (req, res) => {
    const sliceId = req.params['sliceId']!;
    const adminActor = actorRef(req.admin!.id);

    const result = await advanceSlice(sliceId, adminActor);

    res.status(200).json({
      stage: result.stateRecord.accession_stage,
      state_record: result.stateRecord,
      transition: result.transitionRecord,
      governance_action_id: result.governanceActionId,
      witness_artifact_id: result.witnessArtifactId,
      stage_specific: result.stageSpecificRecords,
    });
  })
);

// ============================================================================
// Inspection (read-only, derivative)
// ============================================================================

/**
 * GET /sources — List external sources
 */
accessionRouter.get(
  '/sources',
  asyncHandler(async (_req, res) => {
    const sources = await getExternalSources();
    res.json(derivative({ sources }));
  })
);

/**
 * GET /slices — List slices with current accession stage
 */
accessionRouter.get(
  '/slices',
  asyncHandler(async (_req, res) => {
    const slices = await listSlicesWithStage();
    res.json(derivative({ slices }));
  })
);

/**
 * GET /slices/:sliceId — Full accession context
 */
accessionRouter.get(
  '/slices/:sliceId',
  asyncHandler(async (req, res) => {
    const sliceId = req.params['sliceId']!;
    const context = await loadAccessionContext(sliceId);
    if (!context.slice) {
      throw errors.notFound(`Slice ${sliceId} not found`);
    }
    res.json(derivative(context));
  })
);

/**
 * GET /slices/:sliceId/stages/:stage — Records at a specific stage
 */
accessionRouter.get(
  '/slices/:sliceId/stages/:stage',
  asyncHandler(async (req, res) => {
    const sliceId = req.params['sliceId']!;
    const stage = req.params['stage']!;
    const states = await getAccessionStatesBySlice(sliceId);
    const stageState = states.find(s => s.accession_stage === stage);
    if (!stageState) {
      throw errors.notFound(`Stage ${stage} not found for slice ${sliceId}`);
    }
    res.json(derivative({ state: stageState }));
  })
);
