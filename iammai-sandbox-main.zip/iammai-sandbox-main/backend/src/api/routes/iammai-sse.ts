/**
 * IAMMAI SSE (Server-Sent Events) endpoint for real-time compliance streaming
 *
 * DERIVATIVE SURFACE — Streams new canonical records as they appear.
 * Uses event-bus subscription (event-driven push) instead of polling.
 * Canonical state lives in the DB tables — this stream is derivative.
 */

import { Router } from 'express';
import type { Response } from 'express';
import { requireAdmin } from '../middleware/auth.js';
import { iammaiEventBus, type IammaiEventType } from '../../integrity/iammai/event-bus.js';

export const iammaiSseRouter = Router();

iammaiSseRouter.use(requireAdmin);

const HEARTBEAT_INTERVAL = 15000;

const ALL_EVENT_TYPES: IammaiEventType[] = [
  'phase_change',
  'transition_occurred',
  'governance_action',
  'witness_emitted',
  'validation_completed',
  'contribution_recorded',
  'containment_change',
];

/**
 * GET /stream — SSE endpoint for real-time IAMMAI record events
 * Events are pushed within milliseconds of canonical record insertion.
 */
iammaiSseRouter.get('/stream', (req, res: Response) => {
  // SSE headers
  res.writeHead(200, {
    'Content-Type': 'text/event-stream',
    'Cache-Control': 'no-cache',
    'Connection': 'keep-alive',
    'X-Accel-Buffering': 'no',
  });

  res.write(`event: connected\ndata: ${JSON.stringify({ surface: 'derivative', timestamp: new Date().toISOString() })}\n\n`);

  // Create typed handlers for each event type
  const handlers = new Map<IammaiEventType, (record: Record<string, unknown>) => void>();

  for (const eventType of ALL_EVENT_TYPES) {
    const handler = (record: Record<string, unknown>): void => {
      try {
        res.write(`event: ${eventType}\ndata: ${JSON.stringify(record)}\n\n`);
      } catch {
        // Client disconnected — will be cleaned up by close handler
      }
    };
    handlers.set(eventType, handler);
    iammaiEventBus.onRecord(eventType, handler);
  }

  // Heartbeat to prevent proxy timeouts
  const heartbeatTimer = setInterval(() => {
    try {
      res.write(`event: heartbeat\ndata: ${JSON.stringify({ timestamp: new Date().toISOString() })}\n\n`);
    } catch {
      clearInterval(heartbeatTimer);
    }
  }, HEARTBEAT_INTERVAL);

  // Cleanup on client disconnect
  req.on('close', () => {
    clearInterval(heartbeatTimer);
    for (const [eventType, handler] of handlers) {
      iammaiEventBus.offRecord(eventType, handler);
    }
  });
});
