/**
 * IAMMAI compliance dashboard API routes
 *
 * DERIVATIVE SURFACE — These endpoints expose read-only views
 * over canonical IAMMAI records. They do not write to any
 * IAMMAI table. All responses include _derivative metadata.
 */

import { Router } from 'express';
import { requireAdmin } from '../middleware/auth.js';
import { asyncHandler } from '../middleware/error.js';
import {
  listTrackedMatters,
  loadIammaiContext,
  getGovernanceActionsByMatter,
  getContainmentRecordsByMatter,
  getStateRecordsByMatter,
  getContributionRecordsByMatter,
  getTransitionRecordsByMatter,
} from '../../integrity/iammai/registry.js';
import { assessConformance } from '../../integrity/iammai/conformance-assessor.js';
import { auditMatter } from '../../integrity/iammai/governance-query.js';
import { isCurrentStateHeld } from '../../integrity/iammai/containment-engine.js';
import { query } from '../../lib/db.js';

export const iammaiRouter = Router();

iammaiRouter.use(requireAdmin);

/** Wrap response with derivative surface metadata */
function derivative(matterRef: string | null, data: unknown) {
  return {
    _derivative: {
      surface: 'admin-dashboard',
      authoritative_source: 'iammai_canonical_tables',
      fetched_at: new Date().toISOString(),
      ...(matterRef && { matter_ref: matterRef }),
    },
    data,
  };
}

/**
 * GET /matters — List all IAMMAI-tracked matters with summary
 */
iammaiRouter.get(
  '/matters',
  asyncHandler(async (_req, res) => {
    const matters = await listTrackedMatters();
    res.json(derivative(null, { matters }));
  })
);

/**
 * GET /matters/:matterRef/conformance — 10-category conformance assessment
 */
iammaiRouter.get(
  '/matters/:matterRef/conformance',
  asyncHandler(async (req, res) => {
    const matterRef = decodeURIComponent(req.params['matterRef']!);
    const ctx = await loadIammaiContext(matterRef);
    const report = assessConformance(matterRef, ctx);
    res.json(derivative(matterRef, report));
  })
);

/**
 * GET /matters/:matterRef/audit — 8 audit question answers
 */
iammaiRouter.get(
  '/matters/:matterRef/audit',
  asyncHandler(async (req, res) => {
    const matterRef = decodeURIComponent(req.params['matterRef']!);
    const ctx = await loadIammaiContext(matterRef);
    const answers = auditMatter(ctx);
    res.json(derivative(matterRef, { answers }));
  })
);

/**
 * GET /matters/:matterRef/context — Full IAMMAI evaluation context (all 7 record types)
 */
iammaiRouter.get(
  '/matters/:matterRef/context',
  asyncHandler(async (req, res) => {
    const matterRef = decodeURIComponent(req.params['matterRef']!);
    const ctx = await loadIammaiContext(matterRef);
    res.json(derivative(matterRef, ctx));
  })
);

/**
 * GET /matters/:matterRef/governance — Governance actions
 */
iammaiRouter.get(
  '/matters/:matterRef/governance',
  asyncHandler(async (req, res) => {
    const matterRef = decodeURIComponent(req.params['matterRef']!);
    const actions = await getGovernanceActionsByMatter(matterRef);
    res.json(derivative(matterRef, { actions }));
  })
);

/**
 * GET /matters/:matterRef/containment — Containment records
 */
iammaiRouter.get(
  '/matters/:matterRef/containment',
  asyncHandler(async (req, res) => {
    const matterRef = decodeURIComponent(req.params['matterRef']!);
    const records = await getContainmentRecordsByMatter(matterRef);
    res.json(derivative(matterRef, { records }));
  })
);

/**
 * GET /matters/:matterRef/status — Lightweight phase/containment/resolution status
 * Used by user-facing status bar and admin quick-status checks.
 */
iammaiRouter.get(
  '/matters/:matterRef/status',
  asyncHandler(async (req, res) => {
    const matter = decodeURIComponent(req.params['matterRef']!);

    const [states, transitions, contributions] = await Promise.all([
      getStateRecordsByMatter(matter),
      getTransitionRecordsByMatter(matter),
      getContributionRecordsByMatter(matter),
    ]);

    if (states.length === 0) {
      res.status(404).json(derivative(matter, { error: 'Matter not found' }));
      return;
    }

    const currentState = states[states.length - 1]!;
    const isHeld = await isCurrentStateHeld(matter);
    const resolutionTransition = transitions.find(t => t.transition_type === 'resolution_transition');

    res.json(derivative(matter, {
      phase: currentState.state_type,
      family: currentState.state_family,
      isHeld,
      isResolved: !!resolutionTransition,
      resolutionType: resolutionTransition?.resolution_type ?? null,
      contributionRoles: [...new Set(contributions.map(c => c.role))],
    }));
  })
);

/**
 * GET /matters/orphans — Matters with ended sessions but no resolution
 * Used by admin dashboard to surface orphan matters requiring manual resolution.
 */
iammaiRouter.get(
  '/matters/orphans',
  asyncHandler(async (_req, res) => {
    // Find matters where session is ENDED but no resolution_transition exists
    const result = await query<{
      matter_ref: string;
      latest_phase: string;
      state_family: string;
      session_id: string;
      session_name: string;
      ended_at: Date | null;
    }>(
      `SELECT DISTINCT ON (sr.matter_ref)
         sr.matter_ref,
         sr.state_type AS latest_phase,
         sr.state_family,
         s.id AS session_id,
         s.name AS session_name,
         s.ended_at
       FROM iammai_state_records sr
       JOIN sessions s ON sr.matter_ref = ('bnk:session:' || s.id)
       WHERE s.state = 'ENDED'
         AND NOT EXISTS (
           SELECT 1 FROM iammai_transition_records tr
           WHERE tr.matter_ref = sr.matter_ref
             AND tr.transition_type = 'resolution_transition'
         )
       ORDER BY sr.matter_ref, sr.recorded_at DESC`
    );

    res.json(derivative(null, {
      orphans: result.rows,
      count: result.rows.length,
    }));
  })
);
