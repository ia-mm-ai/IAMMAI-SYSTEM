/**
 * Token routes - claim and join operations
 * @see specs/001-ephemeral-kernel/tasks.md#T057-T058
 * @see specs/001-ephemeral-kernel/contracts/api.yaml#tokens
 */

import { Router } from 'express';
import * as sessionModel from '../../models/session.js';
import * as tokenModel from '../../models/token.js';
import { createActiveToken, hashToken, isValidTokenFormat } from '../../services/token.js';
import { derivePresenceHash } from '../../services/presence.js';
import { kernelManager } from '../../kernel/manager.js';
import { asyncHandler, errors } from '../middleware/error.js';
import { config } from '../../lib/config.js';
import * as presenceTracker from '../../integrity/presence-tracker.js';
import type { JoinRequest, TokenClaim, JoinResponse } from '../../lib/types.js';

export const tokensRouter = Router();

/**
 * In-memory storage for active tokens (seed needed for presence hash derivation)
 * Key: token hash, Value: seed
 * This is cleared when kernel is dissolved
 */
const tokenSeeds = new Map<string, string>();

/**
 * Store token seed for later presence hash derivation
 */
export function storeTokenSeed(tokenHash: string, seed: string): void {
  tokenSeeds.set(tokenHash, seed);
}

/**
 * Get token seed for presence hash derivation
 */
export function getTokenSeed(tokenHash: string): string | undefined {
  return tokenSeeds.get(tokenHash);
}

/**
 * Clear all token seeds for a session (called on dissolution)
 */
export function clearTokenSeedsForSession(sessionId: string): void {
  // Note: In a production system, we'd track which seeds belong to which session
  // For now, this is called during kernel dissolution
  // The seeds will be garbage collected when no longer referenced
}

/**
 * Generate WebSocket URL for a session
 */
function generateWebSocketUrl(sessionId: string, token: string): string {
  const protocol = config.isProduction() ? 'wss' : 'ws';
  const host = config.isProduction() ? 'localhost' : `localhost:${config.port}`;
  return `${protocol}://${host}/ws/sessions/${sessionId}?token=${encodeURIComponent(token)}`;
}

/**
 * POST /sessions/:id/claim
 * Claim a token for a session in CREATED state
 * @see contracts/api.yaml lines 279-304
 */
tokensRouter.post(
  '/:id/claim',
  asyncHandler(async (req, res) => {
    const sessionId = req.params['id']!;

    // Find session
    const session = await sessionModel.findById(sessionId);

    if (!session) {
      throw errors.notFound('Session');
    }

    // Only allow claiming for CREATED sessions
    if (session.state !== 'CREATED') {
      throw errors.badRequest(
        'Tokens can only be claimed for sessions in CREATED state'
      );
    }

    // Generate a new token
    const activeToken = createActiveToken(sessionId);

    // Store only the hash in the database (privacy: never store raw token)
    await tokenModel.create(sessionId, activeToken.hash);

    // Store the seed in memory for later presence hash derivation
    storeTokenSeed(activeToken.hash, activeToken.seed);

    // Increment session token count
    await sessionModel.incrementTokenCount(sessionId);

    // Return the token to the client
    const response: TokenClaim = {
      token: activeToken.raw,
      sessionId: sessionId,
      claimedAt: activeToken.issuedAt,
    };

    res.status(201).json({
      token: response.token,
      sessionId: response.sessionId,
      claimedAt: response.claimedAt.toISOString(),
    });
  })
);

/**
 * POST /sessions/:id/join
 * Join an active session with a previously claimed token
 * @see contracts/api.yaml lines 306-336
 */
tokensRouter.post(
  '/:id/join',
  asyncHandler(async (req, res) => {
    const sessionId = req.params['id']!;
    const { token } = req.body as Partial<JoinRequest>;

    // Find session first (to return 404 for non-existent sessions)
    const session = await sessionModel.findById(sessionId);

    if (!session) {
      throw errors.notFound('Session');
    }

    // Validate token is provided
    if (!token || typeof token !== 'string') {
      throw errors.badRequest('Token is required');
    }

    // Validate token format
    if (!isValidTokenFormat(token)) {
      throw errors.badRequest('Invalid token format');
    }

    // Only allow joining ACTIVE sessions
    if (session.state !== 'ACTIVE') {
      throw errors.badRequest(
        `Cannot join session in ${session.state} state. Session must be ACTIVE.`
      );
    }

    // Verify kernel exists, recreate if missing (handles server restart case)
    if (!kernelManager.hasKernel(sessionId)) {
      // Session is ACTIVE but kernel was lost (e.g., server restart)
      // Recreate the kernel to allow users to join
      kernelManager.createKernel(sessionId);
    }

    // Hash the token to look up in database
    const tokenHash = hashToken(token);

    // Find token record and verify it belongs to this session
    const tokenRecord = await tokenModel.findByHashAndSession(tokenHash, sessionId);

    if (!tokenRecord) {
      throw errors.badRequest('Invalid token for this session');
    }

    // Get the seed for presence hash derivation
    let seed = getTokenSeed(tokenHash);

    // If seed is not in memory (server restart), we need to regenerate it
    // In a production system, we might store encrypted seeds or use a deterministic derivation
    if (!seed) {
      // Generate a new seed based on the token hash (deterministic for reconnection)
      const crypto = await import('node:crypto');
      seed = crypto
        .createHash('sha256')
        .update(tokenHash + 'presence-seed')
        .digest('base64url')
        .substring(0, 22);
      storeTokenSeed(tokenHash, seed);
    }

    // Derive presence hash
    const presenceHash = derivePresenceHash(seed);

    // Check if this is first join (for user count)
    const wasAlreadyJoined = tokenRecord.joinedAt !== null;

    // Mark token as joined (idempotent - won't increment if already joined)
    const wasFirstJoin = await tokenModel.markJoined(tokenHash);

    // Increment user count only on first join
    if (wasFirstJoin && !wasAlreadyJoined) {
      await sessionModel.incrementUserCount(sessionId);
    }

    // Attest participant presence (idempotent — rejoining won't duplicate)
    await presenceTracker.attestPresence(
      null,
      sessionId,
      'PARTICIPANT',
      presenceHash,
      'JOIN_TOKEN'
    );

    // Create or get conversation in kernel
    kernelManager.getOrCreateConversation(sessionId, tokenHash, presenceHash);

    // Generate WebSocket URL
    const websocketUrl = generateWebSocketUrl(sessionId, token);

    const response: JoinResponse = {
      presenceHash,
      kernelStatus: 'ACTIVE',
      websocketUrl,
    };

    res.json(response);
  })
);
