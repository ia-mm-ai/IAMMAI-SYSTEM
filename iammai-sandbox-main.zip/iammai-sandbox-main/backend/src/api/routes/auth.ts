/**
 * Auth routes for admin authentication
 * @see specs/001-ephemeral-kernel/tasks.md#T040
 * @see specs/001-ephemeral-kernel/contracts/api.yaml#auth
 */

import { Router } from 'express';
import bcrypt from 'bcrypt';
import * as adminModel from '../../models/admin.js';
import { asyncHandler, errors } from '../middleware/error.js';
import {
  generateToken,
  setAuthCookie,
  clearAuthCookie,
  requireAdmin,
} from '../middleware/auth.js';
import type { LoginRequest } from '../../lib/types.js';

export const authRouter = Router();

/**
 * Validate email format
 */
function isValidEmail(email: string): boolean {
  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  return emailRegex.test(email);
}

/**
 * POST /auth/login
 * Admin login with email/password
 * @see contracts/api.yaml lines 32-56
 */
authRouter.post(
  '/login',
  asyncHandler(async (req, res) => {
    const { email, password } = req.body as Partial<LoginRequest>;

    // Validate request body
    if (!email || typeof email !== 'string') {
      throw errors.badRequest('Email is required');
    }

    if (!password || typeof password !== 'string') {
      throw errors.badRequest('Password is required');
    }

    if (!isValidEmail(email)) {
      throw errors.badRequest('Invalid email format');
    }

    if (password.length < 8) {
      throw errors.badRequest('Password must be at least 8 characters');
    }

    // Find admin by email
    const admin = await adminModel.findByEmail(email);

    if (!admin) {
      throw errors.unauthorized('Invalid email or password');
    }

    // Verify password
    const passwordValid = await bcrypt.compare(password, admin.passwordHash);

    if (!passwordValid) {
      throw errors.unauthorized('Invalid email or password');
    }

    // Update last login timestamp
    await adminModel.updateLastLogin(admin.id);

    // Generate JWT token
    const token = generateToken(admin);

    // Set HTTP-only cookie (for desktop browsers)
    setAuthCookie(res, token);

    // Return admin profile with token (for mobile/iOS compatibility)
    res.json({
      id: admin.id,
      email: admin.email,
      lastLoginAt: new Date().toISOString(),
      token,
    });
  })
);

/**
 * POST /auth/logout
 * Admin logout - clears auth cookie
 * @see contracts/api.yaml lines 58-69
 */
authRouter.post(
  '/logout',
  requireAdmin,
  asyncHandler(async (_req, res) => {
    clearAuthCookie(res);
    res.status(204).send();
  })
);

/**
 * GET /auth/me
 * Get current admin profile
 * @see contracts/api.yaml lines 71-86
 */
authRouter.get(
  '/me',
  requireAdmin,
  asyncHandler(async (req, res) => {
    // Admin is already attached by requireAdmin middleware
    const admin = req.admin!;

    // Get full admin details
    const fullAdmin = await adminModel.findById(admin.id);

    if (!fullAdmin) {
      throw errors.unauthorized('Admin not found');
    }

    res.json({
      id: fullAdmin.id,
      email: fullAdmin.email,
      lastLoginAt: fullAdmin.lastLoginAt?.toISOString() ?? null,
    });
  })
);
