/**
 * IAMMAI Gate Middleware
 *
 * Enforces IAMMAI constitutional constraints on Express routes.
 * Passes through silently for non-tracked sessions.
 */

import type { Request, Response, NextFunction } from 'express';
import { query } from '../../lib/db.js';
import { matterRef, PHASE_ORDINAL } from '../../integrity/iammai/types.js';
import {
  isCurrentStateHeld,
} from '../../integrity/iammai/containment-engine.js';
import { getStateRecordsByMatter } from '../../integrity/iammai/registry.js';

/**
 * Extracts session ID from request, considering common param names.
 */
function extractSessionId(req: Request): string | null {
  return req.params['id'] ?? req.params['sessionId'] ?? null;
}

/**
 * Check if a session is IAMMAI-tracked.
 */
async function isIammaiTracked(sessionId: string): Promise<boolean> {
  const result = await query<{ iammai_tracked: boolean }>(
    'SELECT iammai_tracked FROM sessions WHERE id = $1',
    [sessionId]
  );
  return result.rows[0]?.iammai_tracked ?? false;
}

/**
 * Middleware: Block if IAMMAI matter is currently held.
 * Returns 403 FORBIDDEN with MATTER_HELD code.
 * Passes through for non-IAMMAI-tracked sessions.
 */
export function requireNotHeld() {
  return async (req: Request, res: Response, next: NextFunction): Promise<void> => {
    const sessionId = extractSessionId(req);
    if (!sessionId) {
      next();
      return;
    }

    try {
      const tracked = await isIammaiTracked(sessionId);
      if (!tracked) {
        next();
        return;
      }

      const matter = matterRef(sessionId);
      const held = await isCurrentStateHeld(matter);

      if (held) {
        res.status(403).json({
          error: 'MATTER_HELD',
          code: 'MATTER_HELD',
          message: 'Session matter is held by IAMMAI containment. Operation not permitted until released.',
          matter_ref: matter,
        });
        return;
      }

      next();
    } catch {
      // If we can't check containment, fail open (don't block operations on DB error)
      next();
    }
  };
}

/**
 * Middleware: Block if IAMMAI matter is not at or beyond the minimum phase.
 * Returns 403 FORBIDDEN with IAMMAI_PHASE_VIOLATION code.
 * Passes through for non-IAMMAI-tracked sessions.
 */
export function requirePhaseAtLeast(minPhase: keyof typeof PHASE_ORDINAL) {
  return async (req: Request, res: Response, next: NextFunction): Promise<void> => {
    const sessionId = extractSessionId(req);
    if (!sessionId) {
      next();
      return;
    }

    try {
      const tracked = await isIammaiTracked(sessionId);
      if (!tracked) {
        next();
        return;
      }

      const matter = matterRef(sessionId);
      const states = await getStateRecordsByMatter(matter);

      if (states.length === 0) {
        // No IAMMAI state yet — pass through
        next();
        return;
      }

      const currentState = states[states.length - 1]!;
      const currentOrdinal = PHASE_ORDINAL[currentState.state_type];
      const requiredOrdinal = PHASE_ORDINAL[minPhase];

      if (currentOrdinal < requiredOrdinal) {
        res.status(403).json({
          error: 'IAMMAI_PHASE_VIOLATION',
          code: 'IAMMAI_PHASE_VIOLATION',
          message: `Session matter is in preparation regime (phase: ${currentState.state_type}). ` +
                   `Operation requires at least phase: ${minPhase}.`,
          current_phase: currentState.state_type,
          required_phase: minPhase,
          matter_ref: matter,
        });
        return;
      }

      next();
    } catch {
      next();
    }
  };
}
