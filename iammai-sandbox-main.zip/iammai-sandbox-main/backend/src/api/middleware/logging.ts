/**
 * Log sanitization middleware
 * @see specs/001-ephemeral-kernel/research.md#Security Considerations
 *
 * Constitution Principle V: No conversation content in logs
 *
 * This middleware ensures that:
 * - Token values are never logged
 * - Message content is never logged
 * - Request bodies with sensitive data are sanitized
 */

import type { Request, Response, NextFunction } from 'express';

/**
 * Fields that must never appear in logs
 */
const SENSITIVE_FIELDS = [
  'token',
  'password',
  'content',
  'message',
  'messages',
  'apiKey',
  'secret',
];

/**
 * Sanitize an object by replacing sensitive fields
 */
function sanitizeObject(obj: unknown): unknown {
  if (obj === null || obj === undefined) {
    return obj;
  }

  if (typeof obj !== 'object') {
    return obj;
  }

  if (Array.isArray(obj)) {
    return obj.map(sanitizeObject);
  }

  const result: Record<string, unknown> = {};

  for (const [key, value] of Object.entries(obj as Record<string, unknown>)) {
    const lowerKey = key.toLowerCase();

    if (SENSITIVE_FIELDS.some((field) => lowerKey.includes(field))) {
      result[key] = '[REDACTED]';
    } else if (typeof value === 'object') {
      result[key] = sanitizeObject(value);
    } else {
      result[key] = value;
    }
  }

  return result;
}

/**
 * Sanitize URL by removing token query parameters
 */
function sanitizeUrl(url: string): string {
  try {
    const parsed = new URL(url, 'http://localhost');
    const sensitiveParams = ['token', 'auth', 'key', 'secret'];

    for (const param of sensitiveParams) {
      if (parsed.searchParams.has(param)) {
        parsed.searchParams.set(param, '[REDACTED]');
      }
    }

    return parsed.pathname + parsed.search;
  } catch {
    return url;
  }
}

/**
 * Create a safe log entry for a request
 */
export function createSafeLogEntry(req: Request): Record<string, unknown> {
  return {
    method: req.method,
    url: sanitizeUrl(req.originalUrl),
    ip: req.ip,
    userAgent: req.get('user-agent'),
    body: sanitizeObject(req.body),
  };
}

/**
 * Request logging middleware
 * Logs requests with sensitive data redacted
 */
export function requestLogger(
  req: Request,
  res: Response,
  next: NextFunction
): void {
  const start = Date.now();

  // Log on response finish
  res.on('finish', () => {
    const duration = Date.now() - start;
    const entry = createSafeLogEntry(req);

    console.log(JSON.stringify({
      type: 'request',
      ...entry,
      status: res.statusCode,
      duration,
    }));
  });

  next();
}

/**
 * Sanitize any data before logging
 * Use this when you need to log something that might contain sensitive data
 */
export function sanitize(data: unknown): unknown {
  return sanitizeObject(data);
}
