/**
 * Token middleware for user authentication on chat endpoints
 * @see specs/001-ephemeral-kernel/tasks.md#T059
 * @see specs/001-ephemeral-kernel/contracts/api.yaml#tokenAuth
 */

import type { Request, Response, NextFunction } from 'express';
import * as tokenModel from '../../models/token.js';
import { hashToken, isValidTokenFormat } from '../../services/token.js';
import { errors, asyncHandler } from './error.js';

/**
 * Extended Request interface with token context
 */
declare global {
  namespace Express {
    interface Request {
      tokenHash?: string;
      tokenRecord?: {
        id: string;
        sessionId: string;
        tokenHash: string;
        claimedAt: Date;
        joinedAt: Date | null;
      };
    }
  }
}

/**
 * Extract bearer token from Authorization header
 */
function extractBearerToken(authHeader: string | undefined): string | null {
  if (!authHeader) {
    return null;
  }

  const parts = authHeader.split(' ');
  if (parts.length !== 2 || parts[0].toLowerCase() !== 'bearer') {
    return null;
  }

  return parts[1];
}

/**
 * Middleware to require valid user token
 * Extracts token from Authorization header, validates it, and attaches to request
 */
export const requireToken = asyncHandler(
  async (req: Request, _res: Response, next: NextFunction) => {
    // Extract token from Authorization header
    const token = extractBearerToken(req.headers.authorization);

    if (!token) {
      throw errors.unauthorized('Token required in Authorization header');
    }

    // Validate token format
    if (!isValidTokenFormat(token)) {
      throw errors.unauthorized('Invalid token format');
    }

    // Hash the token
    const tokenHash = hashToken(token);

    // Look up token in database
    const tokenRecord = await tokenModel.findByHash(tokenHash);

    if (!tokenRecord) {
      throw errors.unauthorized('Invalid or expired token');
    }

    // Verify token has been used to join (was validated at join time)
    if (!tokenRecord.joinedAt) {
      throw errors.unauthorized('Token has not been used to join a session');
    }

    // Attach token context to request
    req.tokenHash = tokenHash;
    req.tokenRecord = tokenRecord;

    next();
  }
);

/**
 * Middleware to require token for specific session
 * Must be used after requireToken
 */
export function requireTokenForSession(sessionIdParam = 'id') {
  return asyncHandler(
    async (req: Request, _res: Response, next: NextFunction) => {
      const sessionId = req.params[sessionIdParam];

      if (!req.tokenRecord) {
        throw errors.unauthorized('Token not validated');
      }

      if (req.tokenRecord.sessionId !== sessionId) {
        throw errors.unauthorized('Token is not valid for this session');
      }

      next();
    }
  );
}

/**
 * Optional token middleware - doesn't fail if token is missing
 * Useful for endpoints that have different behavior for authenticated users
 */
export const optionalToken = asyncHandler(
  async (req: Request, _res: Response, next: NextFunction) => {
    const token = extractBearerToken(req.headers.authorization);

    if (!token) {
      next();
      return;
    }

    if (!isValidTokenFormat(token)) {
      next();
      return;
    }

    const tokenHash = hashToken(token);
    const tokenRecord = await tokenModel.findByHash(tokenHash);

    if (tokenRecord && tokenRecord.joinedAt) {
      req.tokenHash = tokenHash;
      req.tokenRecord = tokenRecord;
    }

    next();
  }
);
