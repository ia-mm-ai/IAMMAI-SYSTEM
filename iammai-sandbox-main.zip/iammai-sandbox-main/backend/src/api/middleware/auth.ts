/**
 * JWT authentication middleware for admin routes
 * @see specs/001-ephemeral-kernel/tasks.md#T039
 * @see specs/001-ephemeral-kernel/research.md#Authentication
 */

import type { Request, Response, NextFunction } from 'express';
import jwt from 'jsonwebtoken';
import { config } from '../../lib/config.js';
import * as adminModel from '../../models/admin.js';
import { errors } from './error.js';

// Extend Express Request to include admin
declare global {
  namespace Express {
    interface Request {
      admin?: {
        id: string;
        email: string;
      };
    }
  }
}

interface JWTPayload {
  sub: string; // Admin ID
  email: string;
  iat: number;
  exp: number;
}

const AUTH_COOKIE_NAME = 'auth_token';

/**
 * Get cookie options based on environment
 * In production, use sameSite=none for cross-origin requests
 */
function getCookieOptions() {
  return {
    httpOnly: true,
    secure: config.isProduction(),
    sameSite: config.isProduction() ? 'none' as const : 'lax' as const,
    maxAge: 24 * 60 * 60 * 1000, // 24 hours
    path: '/',
  };
}

/**
 * Generate JWT token for admin
 */
export function generateToken(admin: { id: string; email: string }): string {
  const payload: Omit<JWTPayload, 'iat' | 'exp'> = {
    sub: admin.id,
    email: admin.email,
  };

  return jwt.sign(payload, config.jwtSecret, {
    expiresIn: config.jwtExpiresIn as jwt.SignOptions['expiresIn'],
  });
}

/**
 * Verify JWT token
 */
export function verifyToken(token: string): JWTPayload | null {
  try {
    return jwt.verify(token, config.jwtSecret) as JWTPayload;
  } catch {
    return null;
  }
}

/**
 * Set auth cookie on response
 */
export function setAuthCookie(res: Response, token: string): void {
  res.cookie(AUTH_COOKIE_NAME, token, getCookieOptions());
}

/**
 * Clear auth cookie
 */
export function clearAuthCookie(res: Response): void {
  res.cookie(AUTH_COOKIE_NAME, '', {
    ...getCookieOptions(),
    maxAge: 0,
  });
}

/**
 * Extract token from Authorization header or cookie
 */
function extractToken(req: Request): string | null {
  // First try Authorization header (for iOS/mobile compatibility)
  const authHeader = req.headers.authorization;
  if (authHeader?.startsWith('Bearer ')) {
    return authHeader.slice(7);
  }
  // Fall back to cookie
  return req.cookies[AUTH_COOKIE_NAME] || null;
}

/**
 * Middleware to require admin authentication
 * Extracts JWT from Authorization header or HTTP-only cookie and validates
 */
export async function requireAdmin(
  req: Request,
  res: Response,
  next: NextFunction
): Promise<void> {
  try {
    // Get token from header or cookie
    const token = extractToken(req);

    if (!token) {
      const error = errors.unauthorized('Authentication required');
      res.status(error.statusCode).json({
        code: 'UNAUTHORIZED',
        message: error.message,
      });
      return;
    }

    // Verify token
    const payload = verifyToken(token);

    if (!payload) {
      const error = errors.unauthorized('Invalid or expired token');
      res.status(error.statusCode).json({
        code: 'UNAUTHORIZED',
        message: error.message,
      });
      return;
    }

    // Verify admin still exists
    const admin = await adminModel.findById(payload.sub);

    if (!admin) {
      const error = errors.unauthorized('Admin not found');
      res.status(error.statusCode).json({
        code: 'UNAUTHORIZED',
        message: error.message,
      });
      return;
    }

    // Attach admin to request
    req.admin = {
      id: admin.id,
      email: admin.email,
    };

    next();
  } catch (err) {
    next(err);
  }
}

/**
 * Optional admin authentication - doesn't fail if not authenticated
 */
export async function optionalAdmin(
  req: Request,
  _res: Response,
  next: NextFunction
): Promise<void> {
  try {
    const token = extractToken(req);

    if (token) {
      const payload = verifyToken(token);

      if (payload) {
        const admin = await adminModel.findById(payload.sub);

        if (admin) {
          req.admin = {
            id: admin.id,
            email: admin.email,
          };
        }
      }
    }

    next();
  } catch {
    // Ignore errors for optional auth
    next();
  }
}
