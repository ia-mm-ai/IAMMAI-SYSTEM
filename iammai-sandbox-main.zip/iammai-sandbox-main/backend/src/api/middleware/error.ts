/**
 * Error handler middleware
 * @see specs/001-ephemeral-kernel/contracts/api.yaml#Error
 *
 * Provides consistent error responses across all endpoints.
 * Never exposes internal error details to clients.
 */

import type { Request, Response, NextFunction } from 'express';
import type { ApiError } from '../../lib/types.js';
import { config } from '../../lib/config.js';

/**
 * Application error with HTTP status code
 */
export class AppError extends Error {
  readonly statusCode: number;
  readonly code: string;
  readonly details?: Record<string, unknown>;

  constructor(
    statusCode: number,
    code: string,
    message: string,
    details?: Record<string, unknown>
  ) {
    super(message);
    this.statusCode = statusCode;
    this.code = code;
    this.details = details;
    this.name = 'AppError';
  }
}

/**
 * Common error factory functions
 */
export const errors = {
  badRequest(message: string, details?: Record<string, unknown>): AppError {
    return new AppError(400, 'BAD_REQUEST', message, details);
  },

  unauthorized(message = 'Authentication required'): AppError {
    return new AppError(401, 'UNAUTHORIZED', message);
  },

  forbidden(message = 'Access denied'): AppError {
    return new AppError(403, 'FORBIDDEN', message);
  },

  notFound(resource = 'Resource'): AppError {
    return new AppError(404, 'NOT_FOUND', `${resource} not found`);
  },

  conflict(message: string): AppError {
    return new AppError(409, 'CONFLICT', message);
  },

  invalidState(message: string): AppError {
    return new AppError(400, 'INVALID_STATE', message);
  },

  rateLimited(): AppError {
    return new AppError(429, 'RATE_LIMITED', 'Too many requests');
  },

  internal(message = 'Internal server error'): AppError {
    return new AppError(500, 'INTERNAL_ERROR', message);
  },

  serviceUnavailable(service: string): AppError {
    return new AppError(503, 'SERVICE_UNAVAILABLE', `${service} unavailable`);
  },
};

/**
 * Error handler middleware
 * Must be registered last in the middleware chain
 */
export function errorHandler(
  err: Error,
  _req: Request,
  res: Response,
  _next: NextFunction
): void {
  // Log the error (without sensitive data)
  console.error('Error:', {
    name: err.name,
    message: err.message,
    stack: config.nodeEnv === 'development' ? err.stack : undefined,
  });

  // Handle known application errors
  if (err instanceof AppError) {
    const response: ApiError = {
      code: err.code,
      message: err.message,
      details: err.details,
    };

    res.status(err.statusCode).json(response);
    return;
  }

  // Handle unknown errors
  const response: ApiError = {
    code: 'INTERNAL_ERROR',
    message: config.nodeEnv === 'development'
      ? err.message
      : 'An unexpected error occurred',
  };

  res.status(500).json(response);
}

/**
 * 404 handler for unmatched routes
 */
export function notFoundHandler(req: Request, res: Response): void {
  const response: ApiError = {
    code: 'NOT_FOUND',
    message: `Cannot ${req.method} ${req.path}`,
  };

  res.status(404).json(response);
}

/**
 * Async handler wrapper to catch errors in async route handlers
 */
export function asyncHandler(
  fn: (req: Request, res: Response, next: NextFunction) => Promise<void>
) {
  return (req: Request, res: Response, next: NextFunction): void => {
    fn(req, res, next).catch(next);
  };
}
