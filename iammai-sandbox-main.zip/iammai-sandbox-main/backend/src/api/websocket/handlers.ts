/**
 * WebSocket handlers - message processing and chat streaming
 * @see specs/001-ephemeral-kernel/tasks.md#T071-T072
 * @see specs/001-ephemeral-kernel/contracts/websocket.md
 */

import type { WebSocket } from 'ws';
import type { IncomingMessage } from 'http';
import { wsHub } from './hub.js';
import { hashToken, isValidTokenFormat } from '../../services/token.js';
import { query, transaction } from '../../lib/db.js';
import { coordinateMessageExchange } from '../../integrity/iammai/coordinator.js';
import { isCurrentStateHeld } from '../../integrity/iammai/containment-engine.js';
import { matterRef as makeMatterRef, PHASE_ORDINAL } from '../../integrity/iammai/types.js';
import { createValidationArtifact } from '../../integrity/iammai/record-factory.js';
import { insertValidationArtifact, getStateRecordsByMatter } from '../../integrity/iammai/registry.js';
import { kernelManager } from '../../kernel/manager.js';
import { streamChat } from '../../services/ai.js';
import { logger } from '../../lib/logger.js';
import { derivePresenceHash } from '../../services/presence.js';
import * as presenceTracker from '../../integrity/presence-tracker.js';
import { recordActivity } from '../../integrity/acedia-monitor.js';
import { config } from '../../lib/config.js';
import type { AiSessionMetadata } from '../../integrity/types.js';

// ============================================================================
// AI Session Metadata Tracking (Feature 008: US5)
// Tracks AI model name and cumulative token count per session in memory.
// ============================================================================

const aiMetadataMap = new Map<string, AiSessionMetadata>();

/** Tracks sessions that have already advanced to continuity phase (first message only) */
const iammaiContinuityAdvanced = new Set<string>();

/**
 * Get AI session metadata for a session (for witness emission at close).
 */
export function getAiMetadata(sessionId: string): AiSessionMetadata | undefined {
  return aiMetadataMap.get(sessionId);
}

/**
 * Clear AI session metadata after session dissolution.
 */
export function clearAiMetadata(sessionId: string): void {
  aiMetadataMap.delete(sessionId);
  iammaiContinuityAdvanced.delete(sessionId);
}

interface ClientMessage {
  type: string;
  payload?: {
    messageId?: string;
    content?: string;
  };
  timestamp: string;
}

/**
 * Handle new WebSocket connection
 */
export async function handleConnection(
  ws: WebSocket,
  request: IncomingMessage
): Promise<void> {
  // Extract sessionId and token from URL
  const url = new URL(request.url || '', `http://${request.headers.host}`);
  const pathParts = url.pathname.split('/');
  const sessionId = pathParts[pathParts.length - 1];
  const token = url.searchParams.get('token');

  // Validate token format
  if (!token || !isValidTokenFormat(token)) {
    logger.warn('WebSocket connection rejected: invalid token format');
    ws.close(1008, 'Invalid token');
    return;
  }

  const tokenHash = hashToken(token);

  try {
    // Validate token and session
    const result = await query(
      `SELECT s.id, s.state
       FROM sessions s
       INNER JOIN tokens t ON t.session_id = s.id
       WHERE s.id = $1 AND t.token_hash = $2`,
      [sessionId, tokenHash]
    );

    if (result.rows.length === 0) {
      logger.warn('WebSocket connection rejected: token not found', {
        sessionId,
      });
      ws.close(1008, 'Invalid token');
      return;
    }

    const session = result.rows[0] as { id: string; state: string };

    if (session['state'] !== 'ACTIVE') {
      logger.warn('WebSocket connection rejected: session not active', {
        sessionId,
        state: session['state'],
      });
      ws.close(1000, 'Session not active');
      return;
    }

    // Derive presence hash from token hash (used as seed)
    const presenceHash = derivePresenceHash(tokenHash);

    // Ensure kernel and conversation exists - sessionId is guaranteed to be a string at this point
    kernelManager.getOrCreateConversation(sessionId!, tokenHash, presenceHash);

    // Add connection to hub
    const connectionId = wsHub.addConnection(
      ws,
      sessionId!,
      tokenHash,
      presenceHash
    );

    // Set up message handler
    ws.on('message', (data: Buffer) => {
      handleMessage(connectionId, data).catch((error) => {
        logger.error('Error handling WebSocket message', { error });
      });
    });

    // Set up close handler
    ws.on('close', () => {
      wsHub.removeConnection(connectionId);
    });

    // Set up error handler
    ws.on('error', (error) => {
      logger.error('WebSocket error', { connectionId, error });
      wsHub.removeConnection(connectionId);
    });

    logger.info('WebSocket connection established', { sessionId });
  } catch (error) {
    logger.error('Error handling WebSocket connection', { error });
    ws.close(1011, 'Server error');
  }
}

/**
 * Handle incoming WebSocket message
 */
async function handleMessage(
  connectionId: string,
  data: Buffer
): Promise<void> {
  const connection = wsHub.getConnection(connectionId);
  if (!connection) {
    return;
  }

  let message: ClientMessage;
  try {
    message = JSON.parse(data.toString());
  } catch {
    logger.warn('Invalid WebSocket message format', { connectionId });
    return;
  }

  switch (message.type) {
    case 'USER_MESSAGE':
      await handleUserMessage(connectionId, message);
      break;

    case 'HEARTBEAT_ACK':
      wsHub.updateHeartbeat(connectionId);
      break;

    default:
      logger.warn('Unknown WebSocket message type', {
        type: message.type,
        connectionId,
      });
  }
}

/**
 * Handle user chat message with AI streaming
 */
async function handleUserMessage(
  connectionId: string,
  message: ClientMessage
): Promise<void> {
  const connection = wsHub.getConnection(connectionId);
  if (!connection) {
    return;
  }

  const { tokenHash, sessionId } = connection;
  const content = message.payload?.content;
  const messageId = message.payload?.messageId || crypto.randomUUID();

  // Validate message content
  if (!content || typeof content !== 'string') {
    wsHub.sendMessage(connectionId, {
      type: 'MESSAGE_ERROR',
      payload: {
        messageId,
        code: 'BAD_REQUEST',
        message: 'Message content is required',
      },
      timestamp: new Date().toISOString(),
    });
    return;
  }

  if (content.length === 0 || content.length > 10000) {
    wsHub.sendMessage(connectionId, {
      type: 'MESSAGE_ERROR',
      payload: {
        messageId,
        code: 'MESSAGE_TOO_LONG',
        message: 'Message must be between 1 and 10000 characters',
      },
      timestamp: new Date().toISOString(),
    });
    return;
  }

  // IAMMAI enforcement checks — run before content validation reaches the kernel
  try {
    const sessionResult = await query<{ iammai_tracked: boolean }>(
      'SELECT iammai_tracked FROM sessions WHERE id = $1',
      [sessionId]
    );
    if (sessionResult.rows[0]?.iammai_tracked) {
      const matter = makeMatterRef(sessionId);

      // Check 1: Containment — is the matter held?
      const held = await isCurrentStateHeld(matter);
      if (held) {
        // Write canonical validation artifact (typed non-passage — visible in registry)
        await transaction(async (client) => {
          await insertValidationArtifact(client, createValidationArtifact({
            validation_type: 'transition_legality',
            target_ref: matter,
            condition_set_ref: 'containment_check:message_exchange',
            outcome: 'blocked',
            reason_refs: ['matter_is_held'],
            actor_ref: null,
          }));
        });
        wsHub.sendMessage(connectionId, {
          type: 'MESSAGE_ERROR',
          payload: {
            messageId,
            code: 'MATTER_HELD',
            message: 'Session is held by IAMMAI containment. Messages are frozen until released.',
          },
          timestamp: new Date().toISOString(),
        });
        return;
      }

      // Check 2: Phase — must be in standing-state regime (truth or beyond)
      const states = await getStateRecordsByMatter(matter);
      if (states.length > 0) {
        const currentState = states[states.length - 1]!;
        const currentOrdinal = PHASE_ORDINAL[currentState.state_type];
        const truthOrdinal = PHASE_ORDINAL['truth'];
        if (currentOrdinal < truthOrdinal) {
          // Write canonical validation artifact for phase violation
          await transaction(async (client) => {
            await insertValidationArtifact(client, createValidationArtifact({
              validation_type: 'transition_legality',
              target_ref: matter,
              condition_set_ref: `phase_check:requires_truth:current_${currentState.state_type}`,
              outcome: 'fail',
              reason_refs: [`phase_${currentState.state_type}_is_preparation_regime`],
              actor_ref: null,
            }));
          });
          wsHub.sendMessage(connectionId, {
            type: 'MESSAGE_ERROR',
            payload: {
              messageId,
              code: 'IAMMAI_PHASE_VIOLATION',
              message: `Session matter is in preparation regime (phase: ${currentState.state_type}). ` +
                       'Admin must confirm truth formation before messaging is permitted.',
              current_phase: currentState.state_type,
            },
            timestamp: new Date().toISOString(),
          });
          return;
        }
      }
    }
  } catch (err) {
    // IAMMAI checks non-blocking on DB error — log and continue
    logger.warn('IAMMAI enforcement check failed', { sessionId, error: (err as Error).message });
  }

  try {
    // Record participant activity for acedia monitoring (Feature 008)
    recordActivity(sessionId);

    // Coordinate IAMMAI continuity phase on first message (non-blocking, fire-and-forget)
    if (!iammaiContinuityAdvanced.has(sessionId)) {
      iammaiContinuityAdvanced.add(sessionId);
      transaction(async (client) => {
        const r = await client.query('SELECT iammai_tracked FROM sessions WHERE id = $1', [sessionId]);
        if (!r.rows[0]?.iammai_tracked) return;
        await coordinateMessageExchange(client, { sessionId, aiModel: config.openaiModel });
      }).catch(err => {
        logger.warn('IAMMAI continuity coordination failed', {
          sessionId,
          error: (err as Error).message,
        });
      });
    }

    // Attest AI agent presence (idempotent — only first message creates record)
    await presenceTracker.attestPresence(
      null,
      sessionId,
      'AGENT',
      'ai-agent',
      'MESSAGE_PROCESSING'
    ).catch(err => {
      // Non-blocking: log and continue if attestation fails (e.g., session already ended)
      logger.warn('AI presence attestation failed', { sessionId, error: err.message });
    });

    // Add user message to kernel
    kernelManager.addMessage(sessionId, tokenHash, 'user', content);

    // Get conversation history
    const history = kernelManager.getConversationHistory(sessionId, tokenHash);
    const historyWithoutCurrent = history.slice(0, -1); // Exclude current message

    // Stream AI response
    const aiMessageId = crypto.randomUUID();
    let fullContent = '';

    for await (const chunk of streamChat(historyWithoutCurrent, content)) {
      fullContent += chunk;

      // Send chunk to client
      wsHub.sendMessage(connectionId, {
        type: 'MESSAGE_CHUNK',
        payload: {
          messageId: aiMessageId,
          content: chunk,
          isComplete: false,
        },
        timestamp: new Date().toISOString(),
      });
    }

    // Add AI message to kernel
    kernelManager.addMessage(sessionId, tokenHash, 'assistant', fullContent);

    // Update AI session metadata for witness emission (Feature 008: US5)
    const existing = aiMetadataMap.get(sessionId);
    const estimatedTokens = Math.ceil(fullContent.length / 4);
    aiMetadataMap.set(sessionId, {
      model: config.openaiModel,
      totalTokens: (existing?.totalTokens ?? 0) + estimatedTokens,
    });

    // Send completion message
    wsHub.sendMessage(connectionId, {
      type: 'MESSAGE_COMPLETE',
      payload: {
        messageId: aiMessageId,
        content: fullContent,
        role: 'assistant',
      },
      timestamp: new Date().toISOString(),
    });

    logger.info('AI message streamed successfully', { sessionId });
  } catch (error) {
    logger.error('Error streaming AI response', { error, sessionId });

    wsHub.sendMessage(connectionId, {
      type: 'MESSAGE_ERROR',
      payload: {
        messageId,
        code: 'AI_SERVICE_UNAVAILABLE',
        message: 'Unable to get AI response. Please try again.',
      },
      timestamp: new Date().toISOString(),
    });
  }
}
