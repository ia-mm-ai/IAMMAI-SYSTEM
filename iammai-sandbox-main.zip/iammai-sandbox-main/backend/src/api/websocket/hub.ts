/**
 * WebSocket hub - connection management and broadcasting
 * @see specs/001-ephemeral-kernel/tasks.md#T070
 * @see specs/001-ephemeral-kernel/contracts/websocket.md
 */

import type { WebSocket } from 'ws';
import { logger } from '../../lib/logger.js';
import { kernelManager } from '../../kernel/manager.js';

interface Connection {
  ws: WebSocket;
  sessionId: string;
  tokenHash: string;
  presenceHash: string;
  lastHeartbeat: Date;
}

interface WebSocketMessage {
  type: string;
  payload?: object;
  timestamp: string;
}

/**
 * WebSocket hub singleton
 * Manages all active WebSocket connections
 */
class WebSocketHub {
  private connections: Map<string, Connection> = new Map();
  private heartbeatInterval: NodeJS.Timeout | null = null;
  private readonly HEARTBEAT_INTERVAL = 30000; // 30 seconds
  private readonly CONNECTION_TIMEOUT = 60000; // 60 seconds

  /**
   * Initialize the hub and start heartbeat
   */
  initialize(): void {
    if (this.heartbeatInterval) {
      return; // Already initialized
    }

    this.heartbeatInterval = setInterval(() => {
      this.sendHeartbeats();
      this.closeStaleConnections();
    }, this.HEARTBEAT_INTERVAL);

    logger.info('WebSocket hub initialized');
  }

  /**
   * Shutdown the hub
   */
  shutdown(): void {
    if (this.heartbeatInterval) {
      clearInterval(this.heartbeatInterval);
      this.heartbeatInterval = null;
    }

    // Close all connections
    for (const [connectionId, connection] of this.connections) {
      connection.ws.close(1001, 'Server shutdown');
      this.connections.delete(connectionId);
    }

    logger.info('WebSocket hub shutdown');
  }

  /**
   * Add a new connection
   * @see specs/001-ephemeral-kernel/tasks.md#T093
   * Detects existing conversation and includes history in CONNECTION_ACK
   */
  addConnection(
    ws: WebSocket,
    sessionId: string,
    tokenHash: string,
    presenceHash: string
  ): string {
    const connectionId = `${sessionId}-${Date.now()}`;

    this.connections.set(connectionId, {
      ws,
      sessionId,
      tokenHash,
      presenceHash,
      lastHeartbeat: new Date(),
    });

    // Check for existing conversation history
    const conversationHistory = kernelManager.getConversationHistory(
      sessionId,
      tokenHash
    );

    // Send CONNECTION_ACK with history (FR-021)
    this.sendMessage(connectionId, {
      type: 'CONNECTION_ACK',
      payload: {
        presenceHash,
        kernelStatus: 'ACTIVE',
        sessionId,
        conversationHistory, // Empty array for new connections, full history for reconnections
      },
      timestamp: new Date().toISOString(),
    });

    logger.info('WebSocket connection added', {
      sessionId,
      hasHistory: conversationHistory.length > 0,
    });
    return connectionId;
  }

  /**
   * Remove a connection
   */
  removeConnection(connectionId: string): void {
    const connection = this.connections.get(connectionId);
    if (connection) {
      logger.info('WebSocket connection removed', {
        sessionId: connection.sessionId,
      });
      this.connections.delete(connectionId);
    }
  }

  /**
   * Get connection by ID
   */
  getConnection(connectionId: string): Connection | undefined {
    return this.connections.get(connectionId);
  }

  /**
   * Get all connections for a session
   */
  getSessionConnections(sessionId: string): Connection[] {
    const connections: Connection[] = [];
    for (const connection of this.connections.values()) {
      if (connection.sessionId === sessionId) {
        connections.push(connection);
      }
    }
    return connections;
  }

  /**
   * Send message to a specific connection
   */
  sendMessage(connectionId: string, message: WebSocketMessage): void {
    const connection = this.connections.get(connectionId);
    if (!connection || connection.ws.readyState !== 1) {
      // WebSocket.OPEN = 1
      return;
    }

    try {
      connection.ws.send(JSON.stringify(message));
    } catch (error) {
      logger.error('Failed to send WebSocket message', { connectionId, error });
    }
  }

  /**
   * Broadcast message to all connections in a session
   */
  broadcastToSession(sessionId: string, message: WebSocketMessage): void {
    const connections = this.getSessionConnections(sessionId);
    for (const connection of connections) {
      const connectionId = Array.from(this.connections.entries()).find(
        ([, conn]) => conn === connection
      )?.[0];

      if (connectionId) {
        this.sendMessage(connectionId, message);
      }
    }
  }

  /**
   * Broadcast an IAMMAI state change event to all connected users in a session.
   * These are derivative notifications — canonical state lives in the registry.
   */
  broadcastIammaiEvent(
    sessionId: string,
    event:
      | { type: 'IAMMAI_PHASE_CHANGE'; payload: { phase: string; family: string } }
      | { type: 'IAMMAI_HELD'; payload: { reason: string } }
      | { type: 'IAMMAI_RELEASED'; payload: Record<string, never> }
      | { type: 'IAMMAI_RESOLVED'; payload: { resolutionType: string } }
  ): void {
    this.broadcastToSession(sessionId, {
      type: event.type,
      payload: event.payload as object,
      timestamp: new Date().toISOString(),
    });
  }

  /**
   * Broadcast kernel dissolution to all session connections
   */
  broadcastDissolution(sessionId: string, message: string): void {
    const dissolutionMessage: WebSocketMessage = {
      type: 'KERNEL_DISSOLVED',
      payload: {
        sessionId,
        message,
      },
      timestamp: new Date().toISOString(),
    };

    this.broadcastToSession(sessionId, dissolutionMessage);

    // Close all connections for this session
    const connections = this.getSessionConnections(sessionId);
    for (const connection of connections) {
      connection.ws.close(1000, 'Kernel dissolved');
    }

    // Remove all session connections
    for (const [connectionId, connection] of this.connections) {
      if (connection.sessionId === sessionId) {
        this.connections.delete(connectionId);
      }
    }

    logger.info('Kernel dissolution broadcast complete', { sessionId });
  }

  /**
   * Send heartbeat to all connections
   */
  private sendHeartbeats(): void {
    const heartbeatMessage: WebSocketMessage = {
      type: 'HEARTBEAT',
      timestamp: new Date().toISOString(),
    };

    for (const [connectionId] of this.connections) {
      this.sendMessage(connectionId, heartbeatMessage);
    }
  }

  /**
   * Close stale connections (no heartbeat response)
   */
  private closeStaleConnections(): void {
    const now = Date.now();
    const staleConnections: string[] = [];

    for (const [connectionId, connection] of this.connections) {
      const timeSinceHeartbeat = now - connection.lastHeartbeat.getTime();
      if (timeSinceHeartbeat > this.CONNECTION_TIMEOUT) {
        staleConnections.push(connectionId);
      }
    }

    for (const connectionId of staleConnections) {
      const connection = this.connections.get(connectionId);
      if (connection) {
        connection.ws.close(1001, 'Connection timeout');
        this.removeConnection(connectionId);
        logger.warn('Closed stale connection', {
          sessionId: connection.sessionId,
        });
      }
    }
  }

  /**
   * Update heartbeat timestamp for a connection
   */
  updateHeartbeat(connectionId: string): void {
    const connection = this.connections.get(connectionId);
    if (connection) {
      connection.lastHeartbeat = new Date();
    }
  }

  /**
   * Get connection count
   */
  getConnectionCount(): number {
    return this.connections.size;
  }

  /**
   * Get session connection count
   */
  getSessionConnectionCount(sessionId: string): number {
    return this.getSessionConnections(sessionId).length;
  }
}

// Singleton instance
export const wsHub = new WebSocketHub();
