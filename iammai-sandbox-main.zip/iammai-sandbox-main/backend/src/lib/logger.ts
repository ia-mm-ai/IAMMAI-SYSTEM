/**
 * Logger utility
 * @see specs/001-ephemeral-kernel/research.md#Security Considerations
 *
 * Constitution Principle V: No conversation content in logs
 */

import { sanitize } from '../api/middleware/logging.js';

type LogLevel = 'info' | 'warn' | 'error' | 'debug';

/**
 * Log a message with optional context
 */
function log(level: LogLevel, message: string, context?: Record<string, unknown>): void {
  const entry = {
    timestamp: new Date().toISOString(),
    level,
    message,
    ...(context ? { context: sanitize(context) } : {}),
  };

  console.log(JSON.stringify(entry));
}

/**
 * Logger object with level methods
 */
export const logger = {
  info(message: string, context?: Record<string, unknown>): void {
    log('info', message, context);
  },

  warn(message: string, context?: Record<string, unknown>): void {
    log('warn', message, context);
  },

  error(message: string, context?: Record<string, unknown>): void {
    log('error', message, context);
  },

  debug(message: string, context?: Record<string, unknown>): void {
    if (process.env['NODE_ENV'] !== 'production') {
      log('debug', message, context);
    }
  },
};
