/**
 * Shared types for the IAMMAI Sandbox System
 * @see specs/001-ephemeral-kernel/data-model.md
 */

// ============================================================================
// Session State Machine
// ============================================================================

/**
 * Session state enum - transitions are unidirectional
 * CREATED -> ACTIVE -> ENDED
 */
export type SessionState = 'CREATED' | 'ACTIVE' | 'ENDED';

/**
 * Kernel status for UI display
 */
export type KernelStatus = 'NOT_CREATED' | 'ACTIVE' | 'DISSOLVED';

// ============================================================================
// Persistent Entities (PostgreSQL)
// ============================================================================

/**
 * Admin user account
 * @see data-model.md#Admin
 */
export interface Admin {
  id: string;
  email: string;
  passwordHash: string;
  createdAt: Date;
  lastLoginAt: Date | null;
}

/**
 * Session record - persistent metadata only
 * @see data-model.md#Session
 */
export interface Session {
  id: string;
  name: string;
  state: SessionState;
  createdAt: Date;
  startedAt: Date | null;
  endedAt: Date | null;
  tokenCount: number;
  userCount: number;
  adminId: string;
  contextDescriptor: ContextDescriptor;
  environmentalConstraints: EnvironmentalConstraints;
  iammaiTracked: boolean;
}

/**
 * Session context declaration — required at creation (Integrity Layer).
 * @see docs/framework/FRAMEWORK_DECISIONS.md Decision 1
 */
export interface ContextDescriptor {
  topic: string;
  purpose?: string;
}

/**
 * Session environmental constraints — required at creation (Integrity Layer).
 * @see docs/framework/FRAMEWORK_DECISIONS.md Decision 1
 */
export interface EnvironmentalConstraints {
  max_participants: number;
  time_limit_minutes?: number;
  ai_model?: string;
}

/**
 * Token persistent reference - only stores hash, never raw token
 * @see data-model.md#Token
 */
export interface TokenRecord {
  id: string;
  sessionId: string;
  tokenHash: string;
  claimedAt: Date;
  joinedAt: Date | null;
}

// ============================================================================
// Ephemeral Entities (In-Memory Only)
// ============================================================================

/**
 * Message role - user or AI assistant
 */
export type MessageRole = 'user' | 'assistant';

/**
 * Single message in a conversation
 * @see data-model.md#Message
 */
export interface Message {
  id: string;
  role: MessageRole;
  content: string;
  timestamp: Date;
}

/**
 * Private conversation between user and AI
 * @see data-model.md#Conversation
 */
export interface Conversation {
  tokenHash: string;
  presenceHash: string;
  messages: Message[];
  createdAt: Date;
  lastActivityAt: Date;
}

/**
 * Kernel - in-memory container for session conversations
 * @see data-model.md#Kernel
 */
export interface Kernel {
  sessionId: string;
  conversations: Map<string, Conversation>;
  createdAt: Date;
}

/**
 * Active token with full context for session participation
 * @see data-model.md#ActiveToken
 */
export interface ActiveToken {
  raw: string;
  hash: string;
  seed: string;
  sessionId: string;
  issuedAt: Date;
}

// ============================================================================
// API Response Types
// ============================================================================

/**
 * Lifecycle event for session history
 */
export interface LifecycleEvent {
  event: 'CREATED' | 'STARTED' | 'ENDED';
  timestamp: Date;
}

/**
 * Session with kernel status for admin view
 */
export interface SessionDetails extends Session {
  kernelStatus: KernelStatus;
  lifecycle: LifecycleEvent[];
}

/**
 * Public session info for browsing
 */
export interface PublicSession {
  id: string;
  name: string;
  state: SessionState;
  canClaim: boolean;
  canJoin: boolean;
}

/**
 * Token claim response
 */
export interface TokenClaim {
  token: string;
  sessionId: string;
  claimedAt: Date;
}

/**
 * Join session response
 */
export interface JoinResponse {
  presenceHash: string;
  kernelStatus: 'ACTIVE';
  websocketUrl: string;
}

// ============================================================================
// API Request Types
// ============================================================================

export interface LoginRequest {
  email: string;
  password: string;
}

export interface CreateSessionRequest {
  name: string;
  context_descriptor: ContextDescriptor;
  environmental_constraints: EnvironmentalConstraints;
}

export interface JoinRequest {
  token: string;
}

export interface SendMessageRequest {
  content: string;
  messageId?: string;
}

// ============================================================================
// Error Types
// ============================================================================

export interface ApiError {
  code: string;
  message: string;
  details?: Record<string, unknown>;
}

// ============================================================================
// Result Type for Error Handling
// ============================================================================

export type Result<T, E = ApiError> =
  | { ok: true; value: T }
  | { ok: false; error: E };

export function ok<T>(value: T): Result<T, never> {
  return { ok: true, value };
}

export function err<E>(error: E): Result<never, E> {
  return { ok: false, error };
}
