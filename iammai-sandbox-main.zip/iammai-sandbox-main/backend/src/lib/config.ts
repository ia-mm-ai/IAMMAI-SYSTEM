/**
 * Environment configuration loader
 * @see specs/001-ephemeral-kernel/quickstart.md#Environment Variables
 */

import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { config as loadEnv } from 'dotenv';

// Get directory path for ES modules
const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

// Load .env file from project root
loadEnv({ path: path.join(__dirname, '..', '..', '..', '.env') });

// eslint-disable-next-line @typescript-eslint/no-unused-vars
function _requireEnv(key: string): string {
  const value = process.env[key];
  if (value === undefined || value === '') {
    throw new Error(`Missing required environment variable: ${key}`);
  }
  return value;
}

function optionalEnv(key: string, defaultValue: string): string {
  return process.env[key] ?? defaultValue;
}

function optionalIntEnv(key: string, defaultValue: number): number {
  const value = process.env[key];
  if (value === undefined) {
    return defaultValue;
  }
  const parsed = parseInt(value, 10);
  if (isNaN(parsed)) {
    throw new Error(`Invalid integer value for ${key}: ${value}`);
  }
  return parsed;
}

/**
 * Application configuration loaded from environment
 */
// Make environment variables optional for tests
// eslint-disable-next-line @typescript-eslint/no-unused-vars
function _optionalRequireEnv(key: string): string {
  const value = process.env[key];
  if (value === undefined || value === '') {
    // Return empty for tests, will throw if actually used
    if (process.env['NODE_ENV'] === 'test') {
      return '';
    }
    throw new Error(`Missing required environment variable: ${key}`);
  }
  return value;
}

export const config = {
  // Server
  nodeEnv: optionalEnv('NODE_ENV', 'development'),
  port: optionalIntEnv('PORT', 3001),
  host: optionalEnv('HOST', '0.0.0.0'),

  // Database
  databaseUrl: optionalEnv('DATABASE_URL', 'postgresql://localhost:5432/iammai_sandbox'),

  // JWT Authentication
  jwtSecret: optionalEnv('JWT_SECRET', 'test-jwt-secret-for-testing-only'),
  jwtExpiresIn: optionalEnv('JWT_EXPIRES_IN', '24h'),

  // Admin Credentials (for seeding)
  adminEmail: optionalEnv('ADMIN_EMAIL', ''),
  adminPassword: optionalEnv('ADMIN_PASSWORD', ''),

  // AI Provider
  aiProvider: optionalEnv('AI_PROVIDER', 'openai'),
  openaiApiKey: optionalEnv('OPENAI_API_KEY', ''),
  openaiModel: optionalEnv('OPENAI_MODEL', 'gpt-4o-mini'),

  // CORS
  corsOrigins: optionalEnv('CORS_ORIGINS', 'http://localhost:3000,http://localhost:3002').split(','),

  // WebSocket
  wsHeartbeatInterval: optionalIntEnv('WS_HEARTBEAT_INTERVAL', 30000),

  // Rate Limiting
  rateLimitWindow: optionalIntEnv('RATE_LIMIT_WINDOW', 60000),
  rateLimitMax: optionalIntEnv('RATE_LIMIT_MAX', 100),

  // Helper methods (added as properties for convenience)
  isProduction(): boolean {
    return this.nodeEnv === 'production';
  },
  isDevelopment(): boolean {
    return this.nodeEnv === 'development';
  },
  isTest(): boolean {
    return this.nodeEnv === 'test';
  },
};

export type Config = typeof config;
