/**
 * Presence service - derive anonymous presence hashes
 * @see specs/001-ephemeral-kernel/data-model.md#Presence Hash
 *
 * The presence hash is a short, display-safe identifier derived from
 * a random seed. It allows users to see their own identity without
 * exposing any linkable information.
 */

import crypto from 'node:crypto';

/**
 * Length of the presence hash (8 hex characters = 32 bits)
 * This provides ~4 billion unique values, sufficient for per-session uniqueness
 */
const PRESENCE_HASH_LENGTH = 8;

/**
 * Derive a presence hash from a seed
 * Uses SHA-256 and takes first 8 hex characters
 *
 * @param seed - Random seed generated at token claim time
 * @returns Short hex string for display (e.g., "a7f3b2c1")
 */
export function derivePresenceHash(seed: string): string {
  const hash = crypto
    .createHash('sha256')
    .update(seed)
    .digest('hex');

  return hash.substring(0, PRESENCE_HASH_LENGTH);
}

/**
 * Validate presence hash format
 */
export function isValidPresenceHash(hash: string): boolean {
  return (
    hash.length === PRESENCE_HASH_LENGTH &&
    /^[0-9a-f]+$/.test(hash)
  );
}
