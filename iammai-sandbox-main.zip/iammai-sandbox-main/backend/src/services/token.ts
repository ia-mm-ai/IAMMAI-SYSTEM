/**
 * Token service - secure token generation and validation
 * @see specs/001-ephemeral-kernel/research.md#Token Generation
 *
 * PRIVACY GUARANTEE:
 * - Tokens are cryptographically random (256-bit)
 * - No information is embedded in tokens
 * - Only hash is stored, never raw token
 */

import crypto from 'node:crypto';
import type { ActiveToken } from '../lib/types.js';

/**
 * Token size in bytes (256-bit = 32 bytes)
 */
const TOKEN_BYTES = 32;

/**
 * Generate a cryptographically secure random token
 * Returns base64url encoded string
 */
export function generateToken(): string {
  const buffer = crypto.randomBytes(TOKEN_BYTES);
  return buffer.toString('base64url');
}

/**
 * Generate a seed for presence hash derivation
 * Separate from token for additional privacy
 */
export function generateSeed(): string {
  const buffer = crypto.randomBytes(16);
  return buffer.toString('base64url');
}

/**
 * Hash a token using SHA-256
 * Returns hex-encoded hash (64 characters)
 */
export function hashToken(token: string): string {
  return crypto
    .createHash('sha256')
    .update(token)
    .digest('hex');
}

/**
 * Create an active token with all context
 */
export function createActiveToken(sessionId: string): ActiveToken {
  const raw = generateToken();
  const seed = generateSeed();

  return {
    raw,
    hash: hashToken(raw),
    seed,
    sessionId,
    issuedAt: new Date(),
  };
}

/**
 * Validate token format
 * Returns true if token appears to be valid format
 */
export function isValidTokenFormat(token: string): boolean {
  // Base64url encoded 32 bytes should be ~43 characters
  if (token.length < 40 || token.length > 50) {
    return false;
  }

  // Check for valid base64url characters
  return /^[A-Za-z0-9_-]+$/.test(token);
}

/**
 * Constant-time comparison to prevent timing attacks
 */
export function secureCompare(a: string, b: string): boolean {
  if (a.length !== b.length) {
    return false;
  }

  const bufA = Buffer.from(a);
  const bufB = Buffer.from(b);

  return crypto.timingSafeEqual(bufA, bufB);
}
