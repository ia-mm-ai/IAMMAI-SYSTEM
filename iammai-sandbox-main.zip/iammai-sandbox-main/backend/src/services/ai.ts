/**
 * AI service - provider abstraction with streaming support
 * @see specs/001-ephemeral-kernel/research.md#AI Service Integration
 *
 * PRIVACY GUARANTEE:
 * - No conversation content is logged
 * - Messages are sent per-request, not persisted
 * - Context is session-scoped only
 */

import OpenAI from 'openai';
import { config } from '../lib/config.js';
import type { Message } from '../lib/types.js';

/**
 * Initialize OpenAI client
 */
const openai = new OpenAI({
  apiKey: config.openaiApiKey,
});

/**
 * System prompt for the AI assistant
 */
const SYSTEM_PROMPT = `You are a helpful AI assistant in an ephemeral chat session.
Your responses are private and will be permanently deleted when the session ends.
Be concise, helpful, and friendly.`;

/**
 * Convert internal messages to OpenAI format
 */
function toOpenAIMessages(
  messages: Message[]
): Array<{ role: 'user' | 'assistant' | 'system'; content: string }> {
  return [
    { role: 'system', content: SYSTEM_PROMPT },
    ...messages.map((msg) => ({
      role: msg.role as 'user' | 'assistant',
      content: msg.content,
    })),
  ];
}

/**
 * Stream chat completion from AI provider
 * Yields chunks of the response as they arrive
 *
 * @param history - Conversation history for context
 * @param userMessage - The new user message
 * @yields Response chunks as strings
 */
export async function* streamChat(
  history: Message[],
  userMessage: string
): AsyncGenerator<string, void, unknown> {
  const messages = toOpenAIMessages(history);

  // Add the new user message
  messages.push({ role: 'user', content: userMessage });

  const stream = await openai.chat.completions.create({
    model: config.openaiModel,
    messages,
    stream: true,
    max_tokens: 2048,
    temperature: 0.7,
  });

  for await (const chunk of stream) {
    const content = chunk.choices[0]?.delta?.content;
    if (content) {
      yield content;
    }
  }
}

/**
 * Get complete chat response (non-streaming)
 * Use this for simpler integrations or testing
 */
export async function chat(
  history: Message[],
  userMessage: string
): Promise<string> {
  const messages = toOpenAIMessages(history);
  messages.push({ role: 'user', content: userMessage });

  const response = await openai.chat.completions.create({
    model: config.openaiModel,
    messages,
    max_tokens: 2048,
    temperature: 0.7,
  });

  return response.choices[0]?.message?.content ?? '';
}

/**
 * Check AI service connectivity
 */
export async function checkConnection(): Promise<boolean> {
  try {
    const response = await openai.chat.completions.create({
      model: config.openaiModel,
      messages: [{ role: 'user', content: 'ping' }],
      max_tokens: 5,
    });
    return response.choices.length > 0;
  } catch {
    return false;
  }
}
