/**
 * Session model - database operations for sessions
 * @see specs/001-ephemeral-kernel/data-model.md#Session
 * @see specs/005-structural-foundation/data-model.md#SessionBoundary
 */

import { query, transaction } from '../lib/db.js';
import type pg from 'pg';
import type { Session, SessionState, ContextDescriptor, EnvironmentalConstraints } from '../lib/types.js';

interface SessionRow {
  id: string;
  name: string;
  state: SessionState;
  created_at: Date;
  started_at: Date | null;
  ended_at: Date | null;
  token_count: number;
  user_count: number;
  admin_id: string;
  context_descriptor: ContextDescriptor;
  environmental_constraints: EnvironmentalConstraints;
  iammai_tracked: boolean;
}

function rowToSession(row: SessionRow): Session {
  return {
    id: row.id,
    name: row.name,
    state: row.state,
    createdAt: row.created_at,
    startedAt: row.started_at,
    endedAt: row.ended_at,
    tokenCount: row.token_count,
    userCount: row.user_count,
    adminId: row.admin_id,
    contextDescriptor: row.context_descriptor,
    environmentalConstraints: row.environmental_constraints,
    iammaiTracked: row.iammai_tracked,
  };
}

/**
 * Find session by ID
 */
export async function findById(id: string): Promise<Session | null> {
  const result = await query<SessionRow>(
    'SELECT * FROM sessions WHERE id = $1',
    [id]
  );
  const row = result.rows[0];
  return row ? rowToSession(row) : null;
}

/**
 * List sessions with optional filtering
 */
export async function list(options: {
  state?: SessionState;
  adminId?: string;
  limit?: number;
  offset?: number;
}): Promise<{ sessions: Session[]; total: number }> {
  const { state, adminId, limit = 50, offset = 0 } = options;

  const conditions: string[] = [];
  const params: unknown[] = [];
  let paramIndex = 1;

  if (state) {
    conditions.push(`state = $${paramIndex++}`);
    params.push(state);
  }

  if (adminId) {
    conditions.push(`admin_id = $${paramIndex++}`);
    params.push(adminId);
  }

  const whereClause = conditions.length > 0
    ? `WHERE ${conditions.join(' AND ')}`
    : '';

  // Get total count
  const countResult = await query<{ count: string }>(
    `SELECT COUNT(*) as count FROM sessions ${whereClause}`,
    params
  );
  const total = parseInt(countResult.rows[0]?.count ?? '0', 10);

  // Get paginated results
  const result = await query<SessionRow>(
    `SELECT * FROM sessions ${whereClause}
     ORDER BY created_at DESC
     LIMIT $${paramIndex++} OFFSET $${paramIndex}`,
    [...params, limit, offset]
  );

  return {
    sessions: result.rows.map(rowToSession),
    total,
  };
}

/**
 * List public sessions (CREATED or ACTIVE only)
 */
export async function listPublic(options: {
  state?: 'CREATED' | 'ACTIVE';
  limit?: number;
}): Promise<Session[]> {
  const { state, limit = 20 } = options;

  let whereClause = "WHERE state IN ('CREATED', 'ACTIVE')";
  const params: unknown[] = [];

  if (state) {
    whereClause = 'WHERE state = $1';
    params.push(state);
  }

  const result = await query<SessionRow>(
    `SELECT * FROM sessions ${whereClause}
     ORDER BY created_at DESC
     LIMIT $${params.length + 1}`,
    [...params, limit]
  );

  return result.rows.map(rowToSession);
}

/**
 * Create a new session with boundary declarations.
 */
export async function create(
  name: string,
  adminId: string,
  contextDescriptor: ContextDescriptor,
  environmentalConstraints: EnvironmentalConstraints,
  iammaiTracked: boolean = false
): Promise<Session> {
  const result = await query<SessionRow>(
    `INSERT INTO sessions (name, admin_id, context_descriptor, environmental_constraints, iammai_tracked)
     VALUES ($1, $2, $3, $4, $5)
     RETURNING *`,
    [name, adminId, JSON.stringify(contextDescriptor), JSON.stringify(environmentalConstraints), iammaiTracked]
  );
  const row = result.rows[0];
  if (!row) {
    throw new Error('Failed to create session');
  }
  return rowToSession(row);
}

/**
 * Transition session state.
 * Supports an optional external transaction client for atomic operations
 * with the integrity ledger.
 *
 * @param id - Session ID
 * @param from - Expected current state
 * @param to - Target state
 * @param externalClient - Optional transaction client for atomicity with ledger writes
 * @returns Updated session or null if transition not allowed
 */
export async function transitionState(
  id: string,
  from: SessionState,
  to: SessionState,
  externalClient?: pg.PoolClient
): Promise<Session | null> {
  // Validate transition is allowed
  const validTransitions: Record<SessionState, SessionState[]> = {
    CREATED: ['ACTIVE'],
    ACTIVE: ['ENDED'],
    ENDED: [],
  };

  if (!validTransitions[from].includes(to)) {
    return null;
  }

  const doTransition = async (client: pg.PoolClient): Promise<Session | null> => {
    // Lock the row for update
    const checkResult = await client.query<SessionRow>(
      'SELECT * FROM sessions WHERE id = $1 AND state = $2 FOR UPDATE',
      [id, from]
    );

    if (checkResult.rows.length === 0) {
      return null;
    }

    // Build update based on target state
    let updateQuery: string;
    const updateParams: unknown[] = [id];

    if (to === 'ACTIVE') {
      updateQuery = `
        UPDATE sessions
        SET state = 'ACTIVE', started_at = NOW()
        WHERE id = $1
        RETURNING *
      `;
    } else if (to === 'ENDED') {
      updateQuery = `
        UPDATE sessions
        SET state = 'ENDED', ended_at = NOW()
        WHERE id = $1
        RETURNING *
      `;
    } else {
      return null;
    }

    const result = await client.query<SessionRow>(updateQuery, updateParams);
    const row = result.rows[0];
    return row ? rowToSession(row) : null;
  };

  // If external client provided, use it (caller manages transaction)
  if (externalClient) {
    return doTransition(externalClient);
  }

  // Otherwise, wrap in our own transaction (backward compatible)
  return transaction(doTransition);
}

/**
 * Increment token count (when token is claimed)
 */
export async function incrementTokenCount(id: string): Promise<void> {
  await query(
    'UPDATE sessions SET token_count = token_count + 1 WHERE id = $1',
    [id]
  );
}

/**
 * Increment user count (when user first joins)
 */
export async function incrementUserCount(id: string): Promise<void> {
  await query(
    'UPDATE sessions SET user_count = user_count + 1 WHERE id = $1',
    [id]
  );
}
