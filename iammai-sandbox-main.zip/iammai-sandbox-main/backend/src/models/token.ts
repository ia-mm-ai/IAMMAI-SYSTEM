/**
 * Token model - database operations for token records
 * @see specs/001-ephemeral-kernel/data-model.md#Token
 *
 * PRIVACY NOTE: This model stores ONLY the hash of tokens, never raw values.
 * Raw tokens exist only in memory during active sessions.
 */

import { query } from '../lib/db.js';
import type { TokenRecord } from '../lib/types.js';

interface TokenRow {
  id: string;
  session_id: string;
  token_hash: string;
  claimed_at: Date;
  joined_at: Date | null;
}

function rowToToken(row: TokenRow): TokenRecord {
  return {
    id: row.id,
    sessionId: row.session_id,
    tokenHash: row.token_hash,
    claimedAt: row.claimed_at,
    joinedAt: row.joined_at,
  };
}

/**
 * Find token record by hash
 * Used for validating tokens without exposing raw value
 */
export async function findByHash(tokenHash: string): Promise<TokenRecord | null> {
  const result = await query<TokenRow>(
    'SELECT * FROM tokens WHERE token_hash = $1',
    [tokenHash]
  );
  const row = result.rows[0];
  return row ? rowToToken(row) : null;
}

/**
 * Find token record by hash and session
 * Used for validating token belongs to specific session
 */
export async function findByHashAndSession(
  tokenHash: string,
  sessionId: string
): Promise<TokenRecord | null> {
  const result = await query<TokenRow>(
    'SELECT * FROM tokens WHERE token_hash = $1 AND session_id = $2',
    [tokenHash, sessionId]
  );
  const row = result.rows[0];
  return row ? rowToToken(row) : null;
}

/**
 * Create a new token record
 * Only stores the hash, not the raw token
 */
export async function create(
  sessionId: string,
  tokenHash: string
): Promise<TokenRecord> {
  const result = await query<TokenRow>(
    `INSERT INTO tokens (session_id, token_hash)
     VALUES ($1, $2)
     RETURNING *`,
    [sessionId, tokenHash]
  );
  const row = result.rows[0];
  if (!row) {
    throw new Error('Failed to create token record');
  }
  return rowToToken(row);
}

/**
 * Mark token as joined (first use)
 * Updates joined_at timestamp
 */
export async function markJoined(tokenHash: string): Promise<boolean> {
  const result = await query(
    `UPDATE tokens
     SET joined_at = NOW()
     WHERE token_hash = $1 AND joined_at IS NULL`,
    [tokenHash]
  );
  return (result.rowCount ?? 0) > 0;
}

/**
 * Check if token has already joined
 */
export async function hasJoined(tokenHash: string): Promise<boolean> {
  const result = await query<{ joined: boolean }>(
    'SELECT joined_at IS NOT NULL as joined FROM tokens WHERE token_hash = $1',
    [tokenHash]
  );
  return result.rows[0]?.joined ?? false;
}

/**
 * Count tokens for a session
 */
export async function countBySession(sessionId: string): Promise<number> {
  const result = await query<{ count: string }>(
    'SELECT COUNT(*) as count FROM tokens WHERE session_id = $1',
    [sessionId]
  );
  return parseInt(result.rows[0]?.count ?? '0', 10);
}

/**
 * Count joined tokens for a session
 */
export async function countJoinedBySession(sessionId: string): Promise<number> {
  const result = await query<{ count: string }>(
    `SELECT COUNT(*) as count FROM tokens
     WHERE session_id = $1 AND joined_at IS NOT NULL`,
    [sessionId]
  );
  return parseInt(result.rows[0]?.count ?? '0', 10);
}
