/**
 * Admin model - database operations for admin users
 * @see specs/001-ephemeral-kernel/data-model.md#Admin
 */

import { query } from '../lib/db.js';
import type { Admin } from '../lib/types.js';

interface AdminRow {
  id: string;
  email: string;
  password_hash: string;
  created_at: Date;
  last_login_at: Date | null;
}

function rowToAdmin(row: AdminRow): Admin {
  return {
    id: row.id,
    email: row.email,
    passwordHash: row.password_hash,
    createdAt: row.created_at,
    lastLoginAt: row.last_login_at,
  };
}

/**
 * Find admin by email
 */
export async function findByEmail(email: string): Promise<Admin | null> {
  const result = await query<AdminRow>(
    'SELECT * FROM admins WHERE email = $1',
    [email]
  );
  const row = result.rows[0];
  return row ? rowToAdmin(row) : null;
}

/**
 * Find admin by ID
 */
export async function findById(id: string): Promise<Admin | null> {
  const result = await query<AdminRow>(
    'SELECT * FROM admins WHERE id = $1',
    [id]
  );
  const row = result.rows[0];
  return row ? rowToAdmin(row) : null;
}

/**
 * Create a new admin
 */
export async function create(
  email: string,
  passwordHash: string
): Promise<Admin> {
  const result = await query<AdminRow>(
    `INSERT INTO admins (email, password_hash)
     VALUES ($1, $2)
     RETURNING *`,
    [email, passwordHash]
  );
  const row = result.rows[0];
  if (!row) {
    throw new Error('Failed to create admin');
  }
  return rowToAdmin(row);
}

/**
 * Update last login timestamp
 */
export async function updateLastLogin(id: string): Promise<void> {
  await query(
    'UPDATE admins SET last_login_at = NOW() WHERE id = $1',
    [id]
  );
}

/**
 * Check if any admin exists
 */
export async function existsAny(): Promise<boolean> {
  const result = await query<{ exists: boolean }>(
    'SELECT EXISTS(SELECT 1 FROM admins) as exists'
  );
  return result.rows[0]?.exists ?? false;
}
