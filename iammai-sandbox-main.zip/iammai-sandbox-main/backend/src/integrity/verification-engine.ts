/**
 * Verification engine — evaluates all protocols against a session.
 * Returns a conjunctive result (all must PASS for overall PASS).
 * @see specs/006-verification-witness
 * @see specs/007-presence-suppression
 */

import type { Session } from '../lib/types.js';
import type {
  LedgerEntry,
  ProtocolEvaluator,
  VerificationResult,
  EvaluationContext,
  PresenceRecord,
  AdminAction,
  IrreversibleAction,
} from './types.js';
import type { IammaiEvaluationContext } from './iammai/types.js';
import { getDefaultProtocols } from './protocols/protocol-base.js';

/**
 * Run all protocol evaluators against a session and its ledger entries.
 * Uses conjunctive AND: overall PASS only if ALL protocols PASS.
 *
 * @param session - The session to verify (must be ENDED)
 * @param ledgerEntries - All ledger entries for the session
 * @param protocols - Protocol evaluators to run (defaults to all registered)
 * @param presenceRecords - Presence records for the session (defaults to [])
 * @param adminActions - Admin actions for the session (defaults to [])
 * @param coAgencyActions - Co-agency irreversible action history (defaults to [])
 * @param iammaiContext - IAMMAI evaluation context for tracked sessions (defaults to undefined)
 */
export function verify(
  session: Session,
  ledgerEntries: LedgerEntry[],
  protocols?: ProtocolEvaluator[],
  presenceRecords: PresenceRecord[] = [],
  adminActions: AdminAction[] = [],
  coAgencyActions: IrreversibleAction[] = [],
  iammaiContext?: IammaiEvaluationContext
): VerificationResult {
  const evaluators = protocols ?? getDefaultProtocols();

  const context: EvaluationContext = {
    session,
    ledgerEntries,
    presenceRecords,
    adminActions,
    coAgencyActions,
    iammaiContext,
  };

  const protocolResults = evaluators.map(evaluator => evaluator.evaluate(context));

  return {
    pass: protocolResults.every(r => r.result === 'PASS'),
    protocolResults,
    timestamp: new Date(),
  };
}
