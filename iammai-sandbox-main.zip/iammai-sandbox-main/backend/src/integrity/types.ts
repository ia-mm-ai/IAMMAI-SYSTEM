/**
 * Integrity Layer types
 * @see specs/005-structural-foundation/data-model.md
 * @see docs/framework/FRAMEWORK_DECISIONS.md
 */

import type { SessionState } from '../lib/types.js';

// ============================================================================
// Integrity Event Types
// ============================================================================

/**
 * Events recorded in the integrity ledger.
 * Extensible — features 006-009 will add new event types.
 */
export type IntegrityEventType =
  | 'SESSION_CREATED'
  | 'SESSION_ACTIVATED'
  | 'SESSION_CLOSED'
  | 'TRANSITION_REJECTED'
  | 'VERIFICATION_WITNESS'
  | 'SUPPRESSION_EVENT'
  | 'ACEDIA_WARNING'       // Feature 008: acedia idle warning
  | 'ACEDIA_DETECTION'     // Feature 008: acedia detected, countdown started
  | 'ACEDIA_CANCELLED'     // Feature 008: acedia cancelled by activity
  | 'ACEDIA_FORCE_RELEASE'; // Feature 008: session force-released due to acedia

// ============================================================================
// Session Boundary Types (Framework Decision 1)
// ============================================================================

/**
 * Session context declaration — required at creation.
 * @see FRAMEWORK_DECISIONS.md Decision 1: context_descriptor
 */
export interface ContextDescriptor {
  topic: string;
  purpose?: string;
}

/**
 * Session environmental constraints — required at creation.
 * @see FRAMEWORK_DECISIONS.md Decision 1: environmental_constraints
 */
export interface EnvironmentalConstraints {
  max_participants: number;
  time_limit_minutes?: number;
  ai_model?: string;
}

// ============================================================================
// Framework Status (Framework Decision 2)
// ============================================================================

/**
 * MM-MODEL framework status.
 * CREATED + ACTIVE = OPEN; ENDED = CLOSED.
 * @see FRAMEWORK_DECISIONS.md Decision 2: State Space Mapping
 */
export type FrameworkStatus = 'OPEN' | 'CLOSED';

/**
 * Map IAMMAI session state to framework status.
 * Per Decision 2: CREATED and ACTIVE both map to OPEN; ENDED maps to CLOSED.
 */
export function frameworkStatus(state: SessionState): FrameworkStatus {
  return state === 'ENDED' ? 'CLOSED' : 'OPEN';
}

// ============================================================================
// Metadata Snapshot (ledger entry payload)
// ============================================================================

/**
 * Session metadata captured at the time of an integrity event.
 * NEVER contains message content, token values, or presence hashes.
 * @see FRAMEWORK_DECISIONS.md Decision 10: Privacy Boundary
 */
export interface MetadataSnapshot {
  session_id: string;
  session_name: string;
  state: SessionState;
  framework_status: FrameworkStatus;
  admin_id: string;
  token_count: number;
  user_count: number;
  created_at: string;
  started_at: string | null;
  ended_at: string | null;
  context_descriptor: ContextDescriptor;
  environmental_constraints: EnvironmentalConstraints;
}

// ============================================================================
// Ledger Entry
// ============================================================================

/**
 * An immutable, hash-chained record in the append-only integrity ledger.
 */
export interface LedgerEntry {
  id: string;
  sequenceNumber: number;
  sessionId: string;
  eventType: IntegrityEventType;
  timestamp: Date;
  fromState: SessionState | null;
  toState: string;
  metadataSnapshot: MetadataSnapshot;
  previousHash: string | null;
  entryHash: string;
}

// ============================================================================
// Hash Chain Validation
// ============================================================================

export interface HashChainError {
  sequenceNumber: number;
  expectedHash: string;
  actualHash: string;
}

/**
 * Result of validating the ledger hash chain.
 */
export interface HashChainValidationResult {
  valid: boolean;
  totalEntries: number;
  validatedEntries: number;
  firstBrokenEntry: number | null;
  errors: HashChainError[];
}

// ============================================================================
// Verification & Witness Types (Feature 006)
// ============================================================================

/**
 * Context provided to protocol evaluators during verification.
 */
export interface EvaluationContext {
  session: import('../lib/types.js').Session;
  ledgerEntries: LedgerEntry[];
  presenceRecords: PresenceRecord[];
  adminActions: AdminAction[];
  coAgencyActions: IrreversibleAction[]; // Feature 008: co-agency action history
  iammaiContext?: import('./iammai/types.js').IammaiEvaluationContext; // Feature 010: IAMMAI
}

/**
 * Interface for protocol evaluators.
 * Each evaluator checks one integrity protocol against a session's data.
 */
export interface ProtocolEvaluator {
  readonly id: string;
  readonly version: string;
  evaluate(context: EvaluationContext): ProtocolResult;
}

/**
 * Result of evaluating a single protocol.
 */
export interface ProtocolResult {
  protocol: string;
  result: 'PASS' | 'FAIL';
  details: string;
}

/**
 * Result of running all protocol evaluations for a session.
 */
export interface VerificationResult {
  pass: boolean;
  protocolResults: ProtocolResult[];
  timestamp: Date;
}

// ============================================================================
// Presence Types (Feature 007)
// ============================================================================

export type PresenceRole = 'CREATOR' | 'PARTICIPANT' | 'AGENT';
export type AttestationMethod = 'AUTH_EVENT' | 'JOIN_TOKEN' | 'MESSAGE_PROCESSING';

/**
 * A presence attestation record stored in the database.
 * @see specs/007-presence-suppression/data-model.md
 */
export interface PresenceRecord {
  id: string;
  sessionId: string;
  role: PresenceRole;
  presenceHash: string;
  attestationMethod: AttestationMethod;
  attested: boolean;
  finalized: boolean;
  createdAt: Date;
  finalizedAt: Date | null;
}

/**
 * Presence summary for witness artifacts.
 * Updated from stub to real presence data in feature 007.
 */
export interface PresenceSummary {
  admin: { attested: boolean; method: string; hash: string };
  participants: Array<{ attested: boolean; method: string; hash: string }>;
  agents: Array<{ attested: boolean; method: string; hash: string }>;
  total_attestation_methods: number;
  finalized: boolean;
}

// ============================================================================
// Suppression Types (Feature 007)
// ============================================================================

/**
 * Record of a suppressed action due to protocol violation.
 */
export interface SuppressionRecord {
  sessionId: string;
  actionType: string;
  failedProtocols: ProtocolResult[];
  reason: string;
  timestamp: Date;
}

/**
 * Admin action tracked for I.05 and I.08 evaluators.
 */
export interface AdminAction {
  sessionId: string;
  actionType: AdminActionType;
  timestamp: Date;
  outcome: 'EXECUTED' | 'SUPPRESSED';
}

export type AdminActionType = 'SESSION_CREATE' | 'SESSION_START' | 'SESSION_END';

// ============================================================================
// Governance Types (Feature 008)
// ============================================================================

/**
 * Acedia monitoring thresholds (Framework Decision 6).
 * All values in milliseconds.
 */
export interface AcediaThresholds {
  createdIdleMs: number;   // Default: 15 * 60 * 1000 (15 min)
  activeIdleMs: number;    // Default: 30 * 60 * 1000 (30 min)
  countdownMs: number;     // Default: 10 * 60 * 1000 (10 min)
  checkIntervalMs: number; // Default: 60 * 1000 (60 sec)
}

/**
 * Acedia lifecycle phases for a session.
 */
export type AcediaPhase = 'NORMAL' | 'WARNING' | 'DETECTION' | 'COUNTDOWN';

/**
 * In-memory acedia state for a monitored session.
 */
export interface AcediaState {
  sessionId: string;
  phase: AcediaPhase;
  lastActivityAt: Date;
  countdownStartedAt: Date | null;
}

/**
 * Agent types for co-agency balance tracking.
 */
export type AgentType = 'HUMAN' | 'MACHINE';

/**
 * Irreversible action types tracked for co-agency balance (Framework Decision 7).
 */
export type IrreversibleActionType =
  | 'SESSION_END'              // Human
  | 'PRESENCE_FINALIZATION'    // Machine
  | 'VERIFICATION_EXECUTION';  // Machine

/**
 * A recorded irreversible action for co-agency tracking.
 */
export interface IrreversibleAction {
  sessionId: string;
  agentType: AgentType;
  actionType: IrreversibleActionType;
  timestamp: Date;
}

/**
 * In-memory co-agency balance state for a session.
 */
export interface CoAgencyState {
  sessionId: string;
  consecutiveCount: number;
  lastAgentType: AgentType | null;
  history: IrreversibleAction[];
}

/**
 * In-memory AI participation metadata for witness emission.
 */
export interface AiSessionMetadata {
  model: string;
  totalTokens: number;
}

// ============================================================================
// Compliance Types (Feature 009)
// ============================================================================

/**
 * The five MM-MODEL §11 compliance conditions.
 */
export type ComplianceCondition =
  | 'TRUTH_FINALIZATION'
  | 'DETERMINISTIC_VERIFICATION'
  | 'MANDATORY_SUPPRESSION'
  | 'HISTORY_NON_REGRESSION'
  | 'AUTHORITY_NON_ASSERTION';

/**
 * The type of evidence supporting a condition evaluation.
 */
export type EvidenceType =
  | 'SESSION_REFERENCE'
  | 'LEDGER_ENTRY'
  | 'PRESENCE_RECORD'
  | 'WITNESS_ARTIFACT'
  | 'SUPPRESSION_RECORD'
  | 'PROTOCOL_RESULT'
  | 'SCHEMA_CHECK'
  | 'HASH_CHAIN'
  | 'STATE_TRANSITION'
  | 'ADMIN_ACTION';

/**
 * A single piece of evidence supporting or explaining a condition evaluation.
 * Privacy boundary: details must contain only IDs, timestamps, and hash values.
 */
export interface EvidenceItem {
  type: EvidenceType;
  description: string;
  sessionId?: string;
  details?: Record<string, unknown>;
}

/**
 * Evaluation result for a single compliance condition.
 */
export interface ConditionEvaluation {
  condition: ComplianceCondition;
  label: string;
  result: 'PASS' | 'FAIL';
  evidence: EvidenceItem[];
}

/**
 * Full compliance check result — overall determination with per-condition breakdown.
 */
export interface ComplianceResult {
  overall: 'COMPLIANT' | 'NON_COMPLIANT' | 'ERROR';
  conditions: ConditionEvaluation[];
  executedAt: string;
  systemVersion: string;
  sessionsEvaluated: number;
  error?: string;
}

/**
 * Self-describing witness artifact stored in the ledger's metadata_snapshot.
 * Contains the full verification result for a closed session.
 * @see specs/006-verification-witness
 */
export interface WitnessArtifact {
  artifact_type: 'SESSION_WITNESS';
  artifact_version: '1.0';
  system: 'iammai-sandbox';
  event_id: string;
  t_open: string;
  t_close: string;
  presence: PresenceSummary;
  protocols_evaluated: string[];
  pass_fail: 'PASS' | 'FAIL';
  protocol_results: ProtocolResult[];
  suppression_triggered: boolean;
  timestamp_utc: string;
  protocol_versions: Record<string, string>;
  metadata: {
    participant_count: number;
    session_name: string;
    duration_ms: number;
    ai_model?: string;         // Feature 008: AI model from environmental_constraints
    ai_total_tokens?: number;  // Feature 008: cumulative token count
  };
}
