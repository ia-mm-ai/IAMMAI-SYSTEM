/**
 * Presence tracker — records and manages presence attestations.
 * Each actor (admin, participant, AI) gets an attestation when they interact.
 * @see specs/007-presence-suppression/contracts/presence-tracker.md
 */

import type pg from 'pg';
import { query } from '../lib/db.js';
import type {
  PresenceRecord,
  PresenceRole,
  AttestationMethod,
  PresenceSummary,
} from './types.js';

interface PresenceRow {
  id: string;
  session_id: string;
  role: PresenceRole;
  presence_hash: string;
  attestation_method: AttestationMethod;
  attested: boolean;
  finalized: boolean;
  created_at: Date;
  finalized_at: Date | null;
}

function rowToRecord(row: PresenceRow): PresenceRecord {
  return {
    id: row.id,
    sessionId: row.session_id,
    role: row.role,
    presenceHash: row.presence_hash,
    attestationMethod: row.attestation_method,
    attested: row.attested,
    finalized: row.finalized,
    createdAt: row.created_at,
    finalizedAt: row.finalized_at,
  };
}

/**
 * Record a presence attestation for an actor in a session.
 * Idempotent: returns existing record on duplicate (session_id, role, presence_hash).
 * Rejects if session is ENDED.
 */
export async function attestPresence(
  client: pg.PoolClient | null,
  sessionId: string,
  role: PresenceRole,
  presenceHash: string,
  method: AttestationMethod
): Promise<PresenceRecord> {
  const exec = client
    ? (text: string, params: unknown[]) => client.query(text, params)
    : (text: string, params: unknown[]) => query(text, params);

  // Check session state — reject if ENDED
  const sessionResult = await exec(
    'SELECT state FROM sessions WHERE id = $1',
    [sessionId]
  );
  if (sessionResult.rows.length === 0) {
    throw new Error(`Session not found: ${sessionId}`);
  }
  if (sessionResult.rows[0].state === 'ENDED') {
    throw new Error(`Cannot attest presence for ended session: ${sessionId}`);
  }

  // INSERT with ON CONFLICT DO NOTHING for idempotency
  const insertResult = await exec(
    `INSERT INTO presence_records (session_id, role, presence_hash, attestation_method)
     VALUES ($1, $2, $3, $4)
     ON CONFLICT (session_id, role, presence_hash) DO NOTHING
     RETURNING *`,
    [sessionId, role, presenceHash, method]
  );

  if (insertResult.rows.length > 0) {
    return rowToRecord(insertResult.rows[0] as PresenceRow);
  }

  // Duplicate — return existing record
  const existingResult = await exec(
    `SELECT * FROM presence_records
     WHERE session_id = $1 AND role = $2 AND presence_hash = $3`,
    [sessionId, role, presenceHash]
  );

  if (existingResult.rows.length === 0) {
    throw new Error('Failed to insert or find presence record');
  }

  return rowToRecord(existingResult.rows[0] as PresenceRow);
}

/**
 * Finalize all presence records for a session.
 * Sets finalized=true and finalized_at=NOW() for all non-finalized records.
 */
export async function finalizePresence(
  client: pg.PoolClient,
  sessionId: string
): Promise<PresenceRecord[]> {
  const result = await client.query(
    `UPDATE presence_records
     SET finalized = true, finalized_at = NOW()
     WHERE session_id = $1 AND finalized = false
     RETURNING *`,
    [sessionId]
  );

  return result.rows.map((row: PresenceRow) => rowToRecord(row));
}

/**
 * Get all presence records for a session.
 */
export async function getPresenceRecords(
  sessionId: string
): Promise<PresenceRecord[]> {
  const result = await query<PresenceRow>(
    'SELECT * FROM presence_records WHERE session_id = $1 ORDER BY created_at ASC',
    [sessionId]
  );
  return result.rows.map(rowToRecord);
}

/**
 * Build a PresenceSummary from presence records for witness artifact emission.
 */
export async function getPresenceSummary(
  sessionId: string
): Promise<PresenceSummary> {
  const records = await getPresenceRecords(sessionId);
  return buildPresenceSummaryFromRecords(records);
}

/**
 * Build a PresenceSummary from an array of PresenceRecords.
 */
export function buildPresenceSummaryFromRecords(
  records: PresenceRecord[]
): PresenceSummary {
  const admin = records.find(r => r.role === 'CREATOR');
  const participants = records.filter(r => r.role === 'PARTICIPANT');
  const agents = records.filter(r => r.role === 'AGENT');

  const distinctMethods = new Set(records.map(r => r.attestationMethod));
  const allFinalized = records.length > 0 && records.every(r => r.finalized);

  return {
    admin: admin
      ? { attested: admin.attested, method: admin.attestationMethod, hash: admin.presenceHash }
      : { attested: false, method: '', hash: '' },
    participants: participants.map(p => ({
      attested: p.attested,
      method: p.attestationMethod,
      hash: p.presenceHash,
    })),
    agents: agents.map(a => ({
      attested: a.attested,
      method: a.attestationMethod,
      hash: a.presenceHash,
    })),
    total_attestation_methods: distinctMethods.size,
    finalized: allFinalized,
  };
}
