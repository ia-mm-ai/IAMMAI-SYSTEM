/**
 * Hash chain utilities for the integrity ledger.
 * Uses SHA-256 (consistent with existing token hashing in the codebase).
 * @see specs/005-structural-foundation/data-model.md#Hash-Chain-Algorithm
 */

import { createHash } from 'node:crypto';
import type { LedgerEntry, HashChainValidationResult, MetadataSnapshot } from './types.js';

/**
 * Compute the SHA-256 hash for a ledger entry.
 * The hash incorporates the previous entry's hash to form a chain.
 *
 * Input is serialized as: previousHash|sequenceNumber|sessionId|eventType|timestamp|JSON(metadata)
 * Output is a lowercase 64-char hex string.
 */
export function computeEntryHash(
  previousHash: string | null,
  sequenceNumber: number,
  sessionId: string,
  eventType: string,
  timestamp: string,
  metadataSnapshot: MetadataSnapshot
): string {
  const serialized = [
    previousHash ?? '',
    sequenceNumber.toString(),
    sessionId,
    eventType,
    timestamp,
    JSON.stringify(metadataSnapshot),
  ].join('|');

  return createHash('sha256').update(serialized).digest('hex');
}

/**
 * Validate the entire hash chain.
 * Iterates entries in sequence order, recomputes each hash,
 * and checks it matches the stored hash.
 *
 * @param entries - Ledger entries ordered by sequence_number (ascending)
 * @returns Validation result with details on any broken entries
 */
export function validateHashChain(entries: LedgerEntry[]): HashChainValidationResult {
  if (entries.length === 0) {
    return {
      valid: true,
      totalEntries: 0,
      validatedEntries: 0,
      firstBrokenEntry: null,
      errors: [],
    };
  }

  const errors: HashChainValidationResult['errors'] = [];
  let previousHash: string | null = null;

  for (const entry of entries) {
    const expectedHash = computeEntryHash(
      previousHash,
      entry.sequenceNumber,
      entry.sessionId,
      entry.eventType,
      entry.timestamp.toISOString(),
      entry.metadataSnapshot
    );

    if (expectedHash !== entry.entryHash) {
      errors.push({
        sequenceNumber: entry.sequenceNumber,
        expectedHash,
        actualHash: entry.entryHash,
      });
    }

    // Also check that the entry's previousHash matches what we expect
    if (entry.previousHash !== previousHash) {
      // If we haven't already recorded this entry as broken
      if (!errors.some(e => e.sequenceNumber === entry.sequenceNumber)) {
        errors.push({
          sequenceNumber: entry.sequenceNumber,
          expectedHash: previousHash ?? '(null)',
          actualHash: entry.previousHash ?? '(null)',
        });
      }
    }

    previousHash = entry.entryHash;
  }

  return {
    valid: errors.length === 0,
    totalEntries: entries.length,
    validatedEntries: entries.length,
    firstBrokenEntry: errors.length > 0 ? errors[0]!.sequenceNumber : null,
    errors,
  };
}
