/**
 * State transition observer for the integrity layer.
 * Observes session state transitions and records them in the ledger.
 * @see specs/005-structural-foundation/spec.md US1
 */

import type pg from 'pg';
import type { Session, SessionState } from '../lib/types.js';
import type { IntegrityEventType, MetadataSnapshot, LedgerEntry } from './types.js';
import { frameworkStatus } from './types.js';
import { appendEntry } from './ledger.js';

/**
 * Build a metadata snapshot from a session.
 * Captures ONLY session metadata — never message content, tokens, or presence data.
 * @see FRAMEWORK_DECISIONS.md Decision 10: Privacy Boundary
 */
export function buildMetadataSnapshot(session: Session): MetadataSnapshot {
  return {
    session_id: session.id,
    session_name: session.name,
    state: session.state,
    framework_status: frameworkStatus(session.state),
    admin_id: session.adminId,
    token_count: session.tokenCount,
    user_count: session.userCount,
    created_at: session.createdAt.toISOString(),
    started_at: session.startedAt?.toISOString() ?? null,
    ended_at: session.endedAt?.toISOString() ?? null,
    context_descriptor: session.contextDescriptor,
    environmental_constraints: session.environmentalConstraints,
  };
}

/**
 * Observe a state transition and record it in the integrity ledger.
 * Must be called within a database transaction for atomicity with the state change.
 *
 * @param client - PostgreSQL transaction client (for atomic ledger + state write)
 * @param session - The session AFTER the transition (current state)
 * @param fromState - Previous state (null for creation)
 * @param toState - Target state
 * @param eventType - The type of integrity event
 */
export async function observeTransition(
  client: pg.PoolClient,
  session: Session,
  fromState: SessionState | null,
  toState: SessionState | string,
  eventType: IntegrityEventType
): Promise<LedgerEntry> {
  const snapshot = buildMetadataSnapshot(session);
  return appendEntry(client, session.id, eventType, fromState, toState, snapshot);
}
