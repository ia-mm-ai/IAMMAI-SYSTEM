/**
 * Suppression engine — evaluates actions against protocols and blocks violations.
 * Session closure is exempt from suppression (caller responsibility).
 * @see specs/007-presence-suppression/contracts/suppression-engine.md
 */

import type pg from 'pg';
import * as sessionModel from '../models/session.js';
import * as ledger from './ledger.js';
import { verify } from './verification-engine.js';
import { appendEntry } from './ledger.js';
import { buildMetadataSnapshot } from './state-observer.js';
import { getPresenceRecords } from './presence-tracker.js';
import { I05ProtocolSupremacy } from './protocols/i05-protocol-supremacy.js';
import { I08SignalCoherence } from './protocols/i08-signal-coherence.js';
import type {
  SuppressionRecord,
  AdminAction,
  LedgerEntry,
  MetadataSnapshot,
} from './types.js';

export interface SuppressionResult {
  allowed: boolean;
  suppression?: SuppressionRecord;
}

export interface CoherenceResult {
  coherent: boolean;
  conflicts?: Array<{ action: string; contradiction: string }> | undefined;
}

/**
 * In-memory admin action log per session.
 * Tracks admin commands for I.05 and I.08 evaluators.
 */
const adminActionLog = new Map<string, AdminAction[]>();

/**
 * Log an admin action for a session.
 */
export function logAdminAction(action: AdminAction): void {
  const actions = adminActionLog.get(action.sessionId) ?? [];
  actions.push(action);
  adminActionLog.set(action.sessionId, actions);
}

/**
 * Get admin actions for a session.
 */
export function getAdminActions(sessionId: string): AdminAction[] {
  return adminActionLog.get(sessionId) ?? [];
}

/**
 * Clear admin actions for a session (called on dissolution).
 */
export function clearAdminActions(sessionId: string): void {
  adminActionLog.delete(sessionId);
}

/**
 * Evaluate whether an action should be allowed based on protocol verification.
 * Session closure is exempt — callers must NOT call this for session end.
 */
export async function evaluateAction(
  sessionId: string,
  actionType: string
): Promise<SuppressionResult> {
  const session = await sessionModel.findById(sessionId);
  if (!session) {
    throw new Error(`Session not found: ${sessionId}`);
  }

  const entries = await ledger.getEntriesBySession(sessionId);
  const presenceRecords = await getPresenceRecords(sessionId);
  const adminActions = getAdminActions(sessionId);

  // Check signal coherence first
  const coherence = checkSignalCoherence(sessionId, actionType);
  if (!coherence.coherent) {
    const reason = `Signal coherence violation: ${coherence.conflicts!.map(c => `${c.action} conflicts with ${c.contradiction}`).join('; ')}`;
    return {
      allowed: false,
      suppression: {
        sessionId,
        actionType,
        failedProtocols: [],
        reason,
        timestamp: new Date(),
      },
    };
  }

  // Only evaluate suppression-relevant protocols for live sessions.
  // I.01 (Presence Truth), I.02 (Event Boundary), I.03 (Continuity) are
  // post-session verification protocols and will always fail on live sessions.
  // I.04 (Ledger Integrity) validates the global hash chain but entries are
  // queried per-session, causing false failures from cross-session gaps.
  // Ledger integrity is a post-hoc verification concern, not a suppression concern.
  const suppressionProtocols = [
    new I05ProtocolSupremacy(),
    new I08SignalCoherence(),
  ];
  const result = verify(session, entries, suppressionProtocols, presenceRecords, adminActions);

  if (result.pass) {
    return { allowed: true };
  }

  const failedProtocols = result.protocolResults.filter(r => r.result === 'FAIL');
  const reason = `Protocol verification failed: ${failedProtocols.map(p => `${p.protocol} (${p.details})`).join('; ')}`;

  return {
    allowed: false,
    suppression: {
      sessionId,
      actionType,
      failedProtocols,
      reason,
      timestamp: new Date(),
    },
  };
}

/**
 * Record a suppression event in the integrity ledger.
 */
export async function recordSuppression(
  client: pg.PoolClient,
  sessionId: string,
  record: SuppressionRecord
): Promise<LedgerEntry> {
  const session = await sessionModel.findById(sessionId);
  if (!session) {
    throw new Error(`Session not found: ${sessionId}`);
  }

  const baseSnapshot = buildMetadataSnapshot(session);
  const suppressionSnapshot: MetadataSnapshot & { suppression: SuppressionRecord } = {
    ...baseSnapshot,
    suppression: record,
  };

  return appendEntry(
    client,
    sessionId,
    'SUPPRESSION_EVENT',
    session.state,
    session.state,
    suppressionSnapshot as unknown as MetadataSnapshot
  );
}

/**
 * Evaluate a message exchange action against I.05 and I.03 protocols.
 * Read-only evaluation (does not write suppression records).
 * Returns pass/fail so the WS handler can block and write its own validation artifact.
 */
export function evaluateMessageAction(
  sessionId: string
): { allowed: boolean; reason?: string } {
  const actions = getAdminActions(sessionId);

  // I.05 Protocol Supremacy: no suppressed SESSION_START followed by message exchange
  const suppressedStart = actions.find(
    a => a.actionType === 'SESSION_START' && a.outcome === 'SUPPRESSED'
  );
  if (suppressedStart) {
    return {
      allowed: false,
      reason: 'I.05_PROTOCOL_SUPREMACY: session start was suppressed; messaging not permitted',
    };
  }

  // I.03 Continuity: no SESSION_END already in the log
  const sessionEnded = actions.find(a => a.actionType === 'SESSION_END');
  if (sessionEnded) {
    return {
      allowed: false,
      reason: 'I.03_CONTINUITY: session end has been recorded; messaging not permitted',
    };
  }

  return { allowed: true };
}

/**
 * Check signal coherence for an admin action.
 * Detects contradictory admin commands within the same session.
 */
export function checkSignalCoherence(
  sessionId: string,
  actionType: string
): CoherenceResult {
  const actions = getAdminActions(sessionId);

  if (actions.length === 0) {
    return { coherent: true };
  }

  const conflicts: Array<{ action: string; contradiction: string }> = [];

  // Contradiction pairs: attempting an action that conflicts with the session history
  for (const prev of actions) {
    if (prev.outcome === 'SUPPRESSED') continue; // Suppressed actions don't count as executed

    // SESSION_START after SESSION_END = contradiction (session already closed)
    if (actionType === 'SESSION_START' && prev.actionType === 'SESSION_END') {
      conflicts.push({
        action: actionType,
        contradiction: `${prev.actionType} at ${prev.timestamp.toISOString()}`,
      });
    }
  }

  return {
    coherent: conflicts.length === 0,
    conflicts: conflicts.length > 0 ? conflicts : undefined,
  };
}
