/**
 * I.09 — Co-Agency Balance protocol evaluator.
 * FAIL if any agent type performed more than 2 consecutive irreversible actions.
 * Evaluates the full action history, not the current counter state.
 * @see specs/008-governance-protocols/contracts/protocol-evaluators.md
 */

import type { ProtocolEvaluator, EvaluationContext, ProtocolResult } from '../types.js';

const PROTOCOL_ID = 'I.09';
const PROTOCOL_VERSION = '1.0.0';

export class I09CoAgencyBalance implements ProtocolEvaluator {
  readonly id = PROTOCOL_ID;
  readonly version = PROTOCOL_VERSION;

  evaluate(context: EvaluationContext): ProtocolResult {
    const actions = context.coAgencyActions;

    if (!actions || actions.length === 0) {
      return {
        protocol: PROTOCOL_ID,
        result: 'PASS',
        details: 'Co-agency balance maintained — no irreversible actions recorded',
      };
    }

    // Scan history chronologically for consecutive streaks by agent type
    let consecutiveCount = 1;
    let currentAgentType = actions[0].agentType;

    for (let i = 1; i < actions.length; i++) {
      const action = actions[i];
      if (action.agentType === currentAgentType) {
        consecutiveCount++;
        if (consecutiveCount > 2) {
          return {
            protocol: PROTOCOL_ID,
            result: 'FAIL',
            details: `Co-agency balance violated: ${currentAgentType} performed ${consecutiveCount} consecutive irreversible actions (max 2)`,
          };
        }
      } else {
        consecutiveCount = 1;
        currentAgentType = action.agentType;
      }
    }

    return {
      protocol: PROTOCOL_ID,
      result: 'PASS',
      details: 'Co-agency balance maintained — no agent type exceeded 2 consecutive irreversible actions',
    };
  }
}
