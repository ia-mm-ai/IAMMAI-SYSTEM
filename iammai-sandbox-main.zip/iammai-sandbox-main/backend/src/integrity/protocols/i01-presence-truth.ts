/**
 * I.01 — Presence Truth protocol evaluator.
 * Checks that a session has 2+ independent attestation methods
 * and all presence records are finalized.
 * @see specs/007-presence-suppression/contracts/protocol-evaluators.md
 */

import type { ProtocolEvaluator, EvaluationContext, ProtocolResult } from '../types.js';

const PROTOCOL_ID = 'I.01';
const PROTOCOL_VERSION = '1.0.0';

export class I01PresenceTruth implements ProtocolEvaluator {
  readonly id = PROTOCOL_ID;
  readonly version = PROTOCOL_VERSION;

  evaluate(context: EvaluationContext): ProtocolResult {
    const { presenceRecords } = context;

    // No records = FAIL
    if (!presenceRecords || presenceRecords.length === 0) {
      return {
        protocol: PROTOCOL_ID,
        result: 'FAIL',
        details: 'Session has 0 attestation method(s), requires 2+',
      };
    }

    // Check all records are finalized
    const unfinalized = presenceRecords.filter(r => !r.finalized);
    if (unfinalized.length > 0) {
      return {
        protocol: PROTOCOL_ID,
        result: 'FAIL',
        details: `${unfinalized.length} presence record(s) not finalized`,
      };
    }

    // Count distinct attestation methods
    const distinctMethods = new Set(presenceRecords.map(r => r.attestationMethod));

    if (distinctMethods.size < 2) {
      return {
        protocol: PROTOCOL_ID,
        result: 'FAIL',
        details: `Session has ${distinctMethods.size} attestation method(s), requires 2+`,
      };
    }

    return {
      protocol: PROTOCOL_ID,
      result: 'PASS',
      details: `Presence verified: ${distinctMethods.size} attestation methods, all records finalized`,
    };
  }
}
