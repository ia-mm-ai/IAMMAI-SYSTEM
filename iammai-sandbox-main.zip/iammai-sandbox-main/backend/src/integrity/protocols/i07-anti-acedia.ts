/**
 * I.07 — Anti-Acedia protocol evaluator.
 * FAIL if session was force-released due to unresolved acedia.
 * Transient ACEDIA_WARNING/DETECTION/CANCELLED events do NOT cause FAIL.
 * @see specs/008-governance-protocols/contracts/protocol-evaluators.md
 */

import type { ProtocolEvaluator, EvaluationContext, ProtocolResult } from '../types.js';

const PROTOCOL_ID = 'I.07';
const PROTOCOL_VERSION = '1.0.0';

export class I07AntiAcedia implements ProtocolEvaluator {
  readonly id = PROTOCOL_ID;
  readonly version = PROTOCOL_VERSION;

  evaluate(context: EvaluationContext): ProtocolResult {
    const { ledgerEntries } = context;

    const forceRelease = ledgerEntries.find(
      e => e.eventType === 'ACEDIA_FORCE_RELEASE'
    );

    if (forceRelease) {
      return {
        protocol: PROTOCOL_ID,
        result: 'FAIL',
        details: 'Session was force-released due to unresolved acedia — anti-acedia protocol violated',
      };
    }

    return {
      protocol: PROTOCOL_ID,
      result: 'PASS',
      details: 'No acedia force-release detected — session resolved normally',
    };
  }
}
