/**
 * I.06 — Presence-Derived Identity protocol evaluator.
 * Verifies admin identity is constructed from a presence set (anonymous hash),
 * not from credentials or personal identifiers.
 *
 * IAMMAI extension: For tracked sessions, also verifies admin actor has
 * ORIGIN and/or AUTHORIZATION contribution roles recorded.
 *
 * @see specs/008-governance-protocols/contracts/protocol-evaluators.md
 */

import type { ProtocolEvaluator, EvaluationContext, ProtocolResult } from '../types.js';
import { hasAdminRoles } from '../iammai/contribution-tracker.js';
import { actorRef } from '../iammai/types.js';

const PROTOCOL_ID = 'I.06';
const PROTOCOL_VERSION = '1.1.0';

export class I06PresenceIdentity implements ProtocolEvaluator {
  readonly id = PROTOCOL_ID;
  readonly version = PROTOCOL_VERSION;

  evaluate(context: EvaluationContext): ProtocolResult {
    const { presenceRecords } = context;

    const adminRecord = presenceRecords.find(r => r.role === 'CREATOR');

    if (!adminRecord) {
      return {
        protocol: PROTOCOL_ID,
        result: 'FAIL',
        details: 'No admin presence record for session — identity cannot be derived from presence set',
      };
    }

    if (!adminRecord.presenceHash) {
      return {
        protocol: PROTOCOL_ID,
        result: 'FAIL',
        details: 'Admin presence hash is empty — identity requires non-empty anonymous hash',
      };
    }

    if (!adminRecord.attested) {
      return {
        protocol: PROTOCOL_ID,
        result: 'FAIL',
        details: 'Admin presence not attested — identity requires verified presence',
      };
    }

    // IAMMAI extension: check admin contribution roles
    if (context.session.iammaiTracked && context.iammaiContext) {
      const adminActorRef = actorRef(context.session.adminId);
      const { hasOrigin, hasAuthorization } = hasAdminRoles(
        context.iammaiContext.contributionRecords,
        adminActorRef
      );

      if (!hasOrigin && !hasAuthorization) {
        return {
          protocol: PROTOCOL_ID,
          result: 'FAIL',
          details: 'IAMMAI: admin actor has no ORIGIN or AUTHORIZATION contribution role recorded',
        };
      }
    }

    return {
      protocol: PROTOCOL_ID,
      result: 'PASS',
      details: context.session.iammaiTracked
        ? 'Admin identity derived from presence set via anonymous hash; IAMMAI contribution roles verified'
        : 'Admin identity derived from presence set via anonymous hash',
    };
  }
}
