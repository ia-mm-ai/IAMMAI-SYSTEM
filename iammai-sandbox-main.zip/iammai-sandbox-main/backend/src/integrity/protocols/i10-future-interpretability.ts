/**
 * I.10 — Future Interpretability protocol evaluator.
 * Verifies that AI model metadata is present when AI participated,
 * enabling future interpretability of witness artifacts.
 *
 * IAMMAI extension: For tracked sessions, also verifies AI actor has
 * FORMALIZATION and/or RENDERING contribution roles recorded.
 *
 * @see specs/008-governance-protocols/contracts/protocol-evaluators.md
 */

import type { ProtocolEvaluator, EvaluationContext, ProtocolResult } from '../types.js';
import { hasAiRoles } from '../iammai/contribution-tracker.js';
import { agentActorRef } from '../iammai/types.js';

const PROTOCOL_ID = 'I.10';
const PROTOCOL_VERSION = '1.1.0';

export class I10FutureInterpretability implements ProtocolEvaluator {
  readonly id = PROTOCOL_ID;
  readonly version = PROTOCOL_VERSION;

  evaluate(context: EvaluationContext): ProtocolResult {
    const hasAiParticipation = context.presenceRecords.some(r => r.role === 'AGENT');

    if (!hasAiParticipation) {
      return {
        protocol: PROTOCOL_ID,
        result: 'PASS',
        details: 'Future interpretability satisfied — no AI participation; AI metadata not required',
      };
    }

    const aiModel = context.session.environmentalConstraints.ai_model;

    if (!aiModel) {
      return {
        protocol: PROTOCOL_ID,
        result: 'FAIL',
        details: 'AI agent participated but no ai_model declared in environmental constraints — witness cannot describe AI involvement',
      };
    }

    // IAMMAI extension: check AI contribution roles
    if (context.session.iammaiTracked && context.iammaiContext) {
      const aiActorRef = agentActorRef(aiModel);
      const { hasFormalization, hasRendering } = hasAiRoles(
        context.iammaiContext.contributionRecords,
        aiActorRef
      );

      if (!hasFormalization && !hasRendering) {
        return {
          protocol: PROTOCOL_ID,
          result: 'FAIL',
          details: `IAMMAI: AI actor '${aiModel}' has no FORMALIZATION or RENDERING contribution role recorded`,
        };
      }
    }

    return {
      protocol: PROTOCOL_ID,
      result: 'PASS',
      details: context.session.iammaiTracked
        ? `Future interpretability satisfied — AI model '${aiModel}' declared; IAMMAI contribution roles verified`
        : `Future interpretability satisfied — AI model '${aiModel}' declared for witness`,
    };
  }
}
