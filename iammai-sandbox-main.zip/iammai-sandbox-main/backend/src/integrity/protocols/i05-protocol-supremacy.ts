/**
 * I.05 — Protocol Supremacy evaluator.
 * Checks that no admin action has overridden verification results
 * or bypassed protocol rules.
 * @see specs/007-presence-suppression/contracts/protocol-evaluators.md
 */

import type { ProtocolEvaluator, EvaluationContext, ProtocolResult } from '../types.js';

const PROTOCOL_ID = 'I.05';
const PROTOCOL_VERSION = '1.0.0';

export class I05ProtocolSupremacy implements ProtocolEvaluator {
  readonly id = PROTOCOL_ID;
  readonly version = PROTOCOL_VERSION;

  evaluate(context: EvaluationContext): ProtocolResult {
    const { adminActions, ledgerEntries } = context;

    if (!adminActions || adminActions.length === 0) {
      return {
        protocol: PROTOCOL_ID,
        result: 'PASS',
        details: 'No admin actions recorded — no override possible',
      };
    }

    // Check for override pattern: a SUPPRESSED action that was later retried and EXECUTED
    const suppressedActions = adminActions.filter(a => a.outcome === 'SUPPRESSED');
    const executedActions = adminActions.filter(a => a.outcome === 'EXECUTED');

    for (const suppressed of suppressedActions) {
      const override = executedActions.find(
        e => e.actionType === suppressed.actionType &&
             e.timestamp.getTime() > suppressed.timestamp.getTime()
      );

      if (override) {
        return {
          protocol: PROTOCOL_ID,
          result: 'FAIL',
          details: `Admin override detected: ${override.actionType} bypassed suppression at ${suppressed.timestamp.toISOString()}`,
        };
      }
    }

    // Check ledger for SUPPRESSION_EVENT followed by contradicting state transition
    const suppressionEvents = ledgerEntries.filter(
      e => e.eventType === 'SUPPRESSION_EVENT'
    );
    for (const suppEvent of suppressionEvents) {
      const laterTransitions = ledgerEntries.filter(
        e => e.sequenceNumber > suppEvent.sequenceNumber &&
             e.eventType !== 'SUPPRESSION_EVENT' &&
             e.eventType !== 'VERIFICATION_WITNESS'
      );

      for (const transition of laterTransitions) {
        // Check if a suppressed action type was later executed as a state transition
        const meta = suppEvent.metadataSnapshot as unknown as Record<string, unknown>;
        const suppression = meta['suppression'] as { actionType?: string } | undefined;
        if (suppression?.actionType === 'SESSION_START' &&
            transition.eventType === 'SESSION_ACTIVATED') {
          return {
            protocol: PROTOCOL_ID,
            result: 'FAIL',
            details: `Admin override detected: SESSION_START was suppressed but session was later activated`,
          };
        }
      }
    }

    return {
      protocol: PROTOCOL_ID,
      result: 'PASS',
      details: 'Protocol supremacy maintained — no admin overrides detected',
    };
  }
}
