/**
 * I.04 — Ledger Non-Erasure protocol evaluator.
 * Checks that the hash chain is valid, no sequence gaps exist,
 * and all entries are retrievable.
 * @see specs/006-verification-witness
 */

import type { ProtocolEvaluator, EvaluationContext, ProtocolResult } from '../types.js';
import { validateHashChain } from '../hash.js';

const PROTOCOL_ID = 'I.04';
const PROTOCOL_VERSION = '1.0.0';

export class I04LedgerIntegrity implements ProtocolEvaluator {
  readonly id = PROTOCOL_ID;
  readonly version = PROTOCOL_VERSION;

  evaluate(context: EvaluationContext): ProtocolResult {
    const { ledgerEntries } = context;
    const failures: string[] = [];

    if (ledgerEntries.length === 0) {
      return {
        protocol: PROTOCOL_ID,
        result: 'FAIL',
        details: 'No ledger entries found',
      };
    }

    // Check hash chain validity
    const chainResult = validateHashChain(ledgerEntries);
    if (!chainResult.valid) {
      const brokenAt = chainResult.firstBrokenEntry;
      failures.push(
        `Hash chain broken at sequence ${brokenAt} (${chainResult.errors.length} error(s))`
      );
    }

    // Check for sequence gaps within this session's entries
    const sequences = ledgerEntries.map(e => e.sequenceNumber).sort((a, b) => a - b);
    for (let i = 1; i < sequences.length; i++) {
      if (sequences[i]! - sequences[i - 1]! !== 1) {
        failures.push(
          `Sequence gap between ${sequences[i - 1]} and ${sequences[i]}`
        );
      }
    }

    if (failures.length > 0) {
      return {
        protocol: PROTOCOL_ID,
        result: 'FAIL',
        details: failures.join('; '),
      };
    }

    return {
      protocol: PROTOCOL_ID,
      result: 'PASS',
      details: `Hash chain valid, ${ledgerEntries.length} entries, no sequence gaps`,
    };
  }
}
