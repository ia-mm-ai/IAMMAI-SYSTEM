/**
 * I.03 — Continuity Non-Regression protocol evaluator.
 * Checks that state transitions are monotonic (CREATED -> ACTIVE -> ENDED)
 * with no backward regressions or metadata erasure.
 * @see specs/006-verification-witness
 */

import type { ProtocolEvaluator, EvaluationContext, ProtocolResult, MetadataSnapshot } from '../types.js';
import type { SessionState } from '../../lib/types.js';

const PROTOCOL_ID = 'I.03';
const PROTOCOL_VERSION = '1.0.0';

const STATE_ORDER: Record<string, number> = {
  CREATED: 0,
  ACTIVE: 1,
  ENDED: 2,
};

export class I03Continuity implements ProtocolEvaluator {
  readonly id = PROTOCOL_ID;
  readonly version = PROTOCOL_VERSION;

  evaluate(context: EvaluationContext): ProtocolResult {
    const { ledgerEntries } = context;
    const failures: string[] = [];

    // Filter to state transition entries (exclude TRANSITION_REJECTED and VERIFICATION_WITNESS)
    const transitionEntries = ledgerEntries.filter(
      e => e.eventType !== 'TRANSITION_REJECTED' && e.eventType !== 'VERIFICATION_WITNESS'
    );

    if (transitionEntries.length === 0) {
      return {
        protocol: PROTOCOL_ID,
        result: 'FAIL',
        details: 'No state transition entries found in ledger',
      };
    }

    // Check monotonic state progression
    for (let i = 1; i < transitionEntries.length; i++) {
      const prev = transitionEntries[i - 1]!;
      const curr = transitionEntries[i]!;

      const prevOrder = STATE_ORDER[prev.toState];
      const currOrder = STATE_ORDER[curr.toState];

      if (prevOrder !== undefined && currOrder !== undefined && currOrder <= prevOrder) {
        failures.push(
          `Non-monotonic transition at sequence ${curr.sequenceNumber}: ${prev.toState} -> ${curr.toState}`
        );
      }
    }

    // Check for metadata erasure between successive entries
    for (let i = 1; i < transitionEntries.length; i++) {
      const prev = transitionEntries[i - 1]!;
      const curr = transitionEntries[i]!;

      const erasedFields = checkMetadataErasure(prev.metadataSnapshot, curr.metadataSnapshot);
      if (erasedFields.length > 0) {
        failures.push(
          `Metadata erasure at sequence ${curr.sequenceNumber}: ${erasedFields.join(', ')}`
        );
      }
    }

    if (failures.length > 0) {
      return {
        protocol: PROTOCOL_ID,
        result: 'FAIL',
        details: failures.join('; '),
      };
    }

    return {
      protocol: PROTOCOL_ID,
      result: 'PASS',
      details: `Monotonic state progression verified across ${transitionEntries.length} entries`,
    };
  }
}

/**
 * Check if any previously-set metadata fields were erased (set to null/undefined)
 * in a subsequent snapshot.
 */
function checkMetadataErasure(
  prev: MetadataSnapshot,
  curr: MetadataSnapshot
): string[] {
  const erased: string[] = [];
  const prevRecord = prev as unknown as Record<string, unknown>;
  const currRecord = curr as unknown as Record<string, unknown>;
  for (const key of Object.keys(prevRecord)) {
    if (prevRecord[key] !== null && prevRecord[key] !== undefined &&
        (currRecord[key] === null || currRecord[key] === undefined)) {
      erased.push(key);
    }
  }
  return erased;
}
