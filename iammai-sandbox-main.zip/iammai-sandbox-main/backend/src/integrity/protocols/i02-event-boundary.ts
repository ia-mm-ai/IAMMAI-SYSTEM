/**
 * I.02 — Event Boundary protocol evaluator.
 * Checks that a session has valid open/close timestamps, ENDED state,
 * and required boundary declarations.
 *
 * IAMMAI extension: for iammai_tracked sessions, also verifies that
 * standing-state regime was reached before resolution (decision/consequence
 * phases present in state records).
 *
 * @see specs/006-verification-witness
 */

import type { ProtocolEvaluator, EvaluationContext, ProtocolResult } from '../types.js';
import { PHASE_FAMILY } from '../iammai/types.js';
import type { IammaiPhase } from '../iammai/types.js';

const PROTOCOL_ID = 'I.02';
const PROTOCOL_VERSION = '1.1.0';

export class I02EventBoundary implements ProtocolEvaluator {
  readonly id = PROTOCOL_ID;
  readonly version = PROTOCOL_VERSION;

  evaluate(context: EvaluationContext): ProtocolResult {
    const { session } = context;
    const failures: string[] = [];

    // Check t_open exists
    if (!session.createdAt) {
      failures.push('Missing t_open (createdAt)');
    }

    // Check t_close exists
    if (!session.endedAt) {
      failures.push('Missing t_close (endedAt)');
    }

    // Check t_close > t_open
    if (session.createdAt && session.endedAt) {
      if (session.endedAt.getTime() <= session.createdAt.getTime()) {
        failures.push('t_close must be after t_open');
      }
    }

    // Check state is ENDED
    if (session.state !== 'ENDED') {
      failures.push(`Session state is ${session.state}, expected ENDED`);
    }

    // Check context_descriptor.topic exists
    if (!session.contextDescriptor?.topic) {
      failures.push('Missing context_descriptor.topic');
    }

    // Check environmental_constraints.max_participants exists
    if (session.environmentalConstraints?.max_participants === undefined ||
        session.environmentalConstraints?.max_participants === null) {
      failures.push('Missing environmental_constraints.max_participants');
    }

    // IAMMAI branch: verify standing reached before resolution
    if (session.iammaiTracked && context.iammaiContext) {
      const iammaiFailures = this.evaluateIammaiResolution(context);
      failures.push(...iammaiFailures);
    }

    if (failures.length > 0) {
      return {
        protocol: PROTOCOL_ID,
        result: 'FAIL',
        details: failures.join('; '),
      };
    }

    const iammaiSuffix = session.iammaiTracked
      ? ', IAMMAI standing-state verified'
      : '';

    return {
      protocol: PROTOCOL_ID,
      result: 'PASS',
      details: 'Event boundary valid: t_open, t_close, state=ENDED, boundary declarations present' + iammaiSuffix,
    };
  }

  /**
   * IAMMAI-specific checks: standing must be reached before resolution.
   */
  private evaluateIammaiResolution(context: EvaluationContext): string[] {
    const failures: string[] = [];
    const iammaiCtx = context.iammaiContext!;
    const { stateRecords, transitionRecords } = iammaiCtx;

    // Check if there are resolution transitions
    const resolutionTransitions = transitionRecords.filter(
      t => t.transition_type === 'resolution_transition'
    );

    if (resolutionTransitions.length === 0) {
      // No resolution yet — boundary check for IAMMAI is about standing
      // If session is ENDED but no resolution transition exists, that's a gap
      if (context.session.state === 'ENDED') {
        failures.push('IAMMAI session ended without resolution transition');
      }
      return failures;
    }

    // For each resolution, verify the source was in standing-state regime
    for (const transition of resolutionTransitions) {
      const sourceState = stateRecords.find(s => s.state_id === transition.source_ref);
      if (!sourceState) {
        failures.push('Resolution source state not found: ' + transition.source_ref);
        continue;
      }

      if (PHASE_FAMILY[sourceState.state_type as IammaiPhase] !== 'standing') {
        failures.push(
          'Resolution from preparation phase \'' + sourceState.state_type +
          '\' — standing-state regime required before resolution'
        );
      }
    }

    return failures;
  }
}
