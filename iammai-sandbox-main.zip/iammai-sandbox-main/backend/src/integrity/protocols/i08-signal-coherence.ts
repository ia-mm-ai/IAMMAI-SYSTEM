/**
 * I.08 — Signal Coherence evaluator.
 * Checks for contradictory admin commands within the same session.
 * Scoped to admin commands only (Framework Decision 5).
 * @see specs/007-presence-suppression/contracts/protocol-evaluators.md
 */

import type { ProtocolEvaluator, EvaluationContext, ProtocolResult } from '../types.js';

const PROTOCOL_ID = 'I.08';
const PROTOCOL_VERSION = '1.0.0';

/**
 * Contradiction pairs: actions that indicate ambiguous or conflicting intent.
 */
const CONTRADICTION_PAIRS: Array<[string, string]> = [
  ['SESSION_START', 'SESSION_END'], // Starting after ending
];

export class I08SignalCoherence implements ProtocolEvaluator {
  readonly id = PROTOCOL_ID;
  readonly version = PROTOCOL_VERSION;

  evaluate(context: EvaluationContext): ProtocolResult {
    const { adminActions } = context;

    if (!adminActions || adminActions.length <= 1) {
      return {
        protocol: PROTOCOL_ID,
        result: 'PASS',
        details: 'Signal coherence maintained — insufficient actions for contradiction',
      };
    }

    // Only consider executed actions (suppressed ones don't count)
    const executed = adminActions.filter(a => a.outcome === 'EXECUTED');

    const conflicts: Array<{ action1: string; action2: string }> = [];

    for (let i = 0; i < executed.length; i++) {
      for (let j = i + 1; j < executed.length; j++) {
        const a1 = executed[i]!;
        const a2 = executed[j]!;

        for (const [first, second] of CONTRADICTION_PAIRS) {
          // Check if a2 contradicts a1 (later action undoes earlier)
          if (a1.actionType === second && a2.actionType === first) {
            conflicts.push({
              action1: `${a1.actionType} at ${a1.timestamp.toISOString()}`,
              action2: `${a2.actionType} at ${a2.timestamp.toISOString()}`,
            });
          }
        }
      }
    }

    if (conflicts.length > 0) {
      const details = conflicts
        .map(c => `${c.action2} conflicts with ${c.action1}`)
        .join('; ');
      return {
        protocol: PROTOCOL_ID,
        result: 'FAIL',
        details: `Contradictory commands detected: ${details}`,
      };
    }

    return {
      protocol: PROTOCOL_ID,
      result: 'PASS',
      details: 'Signal coherence maintained — no contradictory admin commands',
    };
  }
}
