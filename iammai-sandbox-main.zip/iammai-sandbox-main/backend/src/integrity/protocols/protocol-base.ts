/**
 * Protocol evaluator interface and registry.
 * Each protocol evaluator checks one integrity protocol against session data.
 * @see specs/006-verification-witness
 * @see specs/007-presence-suppression
 * @see specs/008-governance-protocols
 */

import type { ProtocolEvaluator } from '../types.js';
import { I01PresenceTruth } from './i01-presence-truth.js';
import { I02EventBoundary } from './i02-event-boundary.js';
import { I03Continuity } from './i03-continuity.js';
import { I04LedgerIntegrity } from './i04-ledger-integrity.js';
import { I05ProtocolSupremacy } from './i05-protocol-supremacy.js';
import { I08SignalCoherence } from './i08-signal-coherence.js';
import { I06PresenceIdentity } from './i06-presence-identity.js';
import { I07AntiAcedia } from './i07-anti-acedia.js';
import { I09CoAgencyBalance } from './i09-co-agency-balance.js';
import { I10FutureInterpretability } from './i10-future-interpretability.js';
import { I11PhaseIntegrity } from '../iammai/protocols/i11-phase-integrity.js';
import { I12ContainmentOrthogonality } from '../iammai/protocols/i12-containment-orthogonality.js';
import { I13ResolutionLegality } from '../iammai/protocols/i13-resolution-legality.js';
import { I14LineagePreservation } from '../iammai/protocols/i14-lineage-preservation.js';
import { I15GovernanceAttribution } from '../iammai/protocols/i15-governance-attribution.js';

/**
 * Default set of protocol evaluators for session verification.
 * Order: Structural (I.02-I.04), Operational (I.01, I.05, I.08),
 *        Governance (I.06, I.07, I.09, I.10),
 *        IAMMAI (I.11-I.15).
 * Total: 15 protocols.
 */
export function getDefaultProtocols(): ProtocolEvaluator[] {
  return [
    new I01PresenceTruth(),
    new I02EventBoundary(),
    new I03Continuity(),
    new I04LedgerIntegrity(),
    new I05ProtocolSupremacy(),
    new I08SignalCoherence(),
    new I06PresenceIdentity(),
    new I07AntiAcedia(),
    new I09CoAgencyBalance(),
    new I10FutureInterpretability(),
    new I11PhaseIntegrity(),
    new I12ContainmentOrthogonality(),
    new I13ResolutionLegality(),
    new I14LineagePreservation(),
    new I15GovernanceAttribution(),
  ];
}
