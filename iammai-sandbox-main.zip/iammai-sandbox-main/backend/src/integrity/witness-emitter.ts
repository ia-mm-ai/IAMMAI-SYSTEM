/**
 * Witness emitter — builds and stores witness artifacts in the ledger.
 * A witness is a self-describing record of a session's verification outcome.
 * @see specs/006-verification-witness
 * @see specs/007-presence-suppression
 */

import { v4 as uuidv4 } from 'uuid';
import type { Session } from '../lib/types.js';
import type {
  LedgerEntry,
  VerificationResult,
  WitnessArtifact,
  PresenceSummary,
  MetadataSnapshot,
  AiSessionMetadata,
} from './types.js';
import { appendEntry } from './ledger.js';
import { buildMetadataSnapshot } from './state-observer.js';
import { transaction } from '../lib/db.js';

/**
 * Build protocol version map from verification result.
 */
function buildProtocolVersions(result: VerificationResult): Record<string, string> {
  const versions: Record<string, string> = {};
  for (const pr of result.protocolResults) {
    versions[pr.protocol] = '1.0.0';
  }
  return versions;
}

/**
 * Build a witness artifact from verification results.
 * Accepts real PresenceSummary (replaces buildPresenceStub from 006).
 * Accepts optional AiSessionMetadata (Feature 008: US5) for AI witness fields.
 */
export function buildWitnessArtifact(
  result: VerificationResult,
  session: Session,
  presence?: PresenceSummary,
  suppressionTriggered: boolean = false,
  aiMetadata?: AiSessionMetadata,
): WitnessArtifact {
  const tOpen = session.createdAt.toISOString();
  const tClose = session.endedAt?.toISOString() ?? result.timestamp.toISOString();
  const durationMs = (session.endedAt ?? result.timestamp).getTime() - session.createdAt.getTime();

  // Default presence for backward compatibility with 006 callers
  const presenceData: PresenceSummary = presence ?? {
    admin: { attested: true, method: 'auth_event', hash: '' },
    participants: [],
    agents: [],
    total_attestation_methods: 1,
    finalized: false,
  };

  return {
    artifact_type: 'SESSION_WITNESS',
    artifact_version: '1.0',
    system: 'iammai-sandbox',
    event_id: uuidv4(),
    t_open: tOpen,
    t_close: tClose,
    presence: presenceData,
    protocols_evaluated: result.protocolResults.map(r => r.protocol),
    pass_fail: result.pass ? 'PASS' : 'FAIL',
    protocol_results: result.protocolResults,
    suppression_triggered: suppressionTriggered,
    timestamp_utc: result.timestamp.toISOString(),
    protocol_versions: buildProtocolVersions(result),
    metadata: {
      participant_count: session.userCount,
      session_name: session.name,
      duration_ms: durationMs,
      ...(aiMetadata ? { ai_model: aiMetadata.model, ai_total_tokens: aiMetadata.totalTokens } : {}),
    },
  };
}

/**
 * Emit a witness artifact by storing it as a ledger entry.
 * Runs in its own transaction (separate from the session state transition).
 *
 * @param result - Verification result
 * @param session - The ended session
 * @param _ledgerEntries - Ledger entries (unused, kept for signature compat)
 * @param presence - Real presence summary from presence-tracker
 * @param suppressionTriggered - Whether suppression was triggered
 * @param aiMetadata - Optional AI session metadata for witness artifact (Feature 008: US5)
 */
export async function emitWitness(
  result: VerificationResult,
  session: Session,
  _ledgerEntries: LedgerEntry[],
  presence?: PresenceSummary,
  suppressionTriggered: boolean = false,
  aiMetadata?: AiSessionMetadata,
): Promise<LedgerEntry> {
  const artifact = buildWitnessArtifact(result, session, presence, suppressionTriggered, aiMetadata);
  const baseSnapshot = buildMetadataSnapshot(session);

  const witnessSnapshot: MetadataSnapshot & { witness: WitnessArtifact } = {
    ...baseSnapshot,
    witness: artifact,
  };

  return transaction(async (client) => {
    return appendEntry(
      client,
      session.id,
      'VERIFICATION_WITNESS',
      'ENDED',
      'ENDED',
      witnessSnapshot as unknown as MetadataSnapshot
    );
  });
}
