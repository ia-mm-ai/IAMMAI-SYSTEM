/**
 * Event boundary enforcement for the integrity layer.
 * Validates session boundary declarations and finalization guards.
 * @see specs/005-structural-foundation/spec.md US3
 * @see docs/framework/FRAMEWORK_DECISIONS.md Decision 1, Decision 2
 */

import type { Session, ContextDescriptor, EnvironmentalConstraints, Result, ApiError } from '../lib/types.js';
import { ok, err } from '../lib/types.js';

/**
 * Validate a context_descriptor object.
 * Required: topic (non-empty string, max 500 chars)
 * Optional: purpose (string, max 1000 chars)
 */
export function validateContextDescriptor(input: unknown): Result<ContextDescriptor, ApiError> {
  if (!input || typeof input !== 'object') {
    return err({
      code: 'INVALID_CONTEXT_DESCRIPTOR',
      message: 'context_descriptor is required and must be an object',
    });
  }

  const obj = input as Record<string, unknown>;

  if (!obj['topic'] || typeof obj['topic'] !== 'string') {
    return err({
      code: 'INVALID_CONTEXT_DESCRIPTOR',
      message: 'context_descriptor.topic is required and must be a non-empty string',
    });
  }

  const topic = (obj['topic'] as string).trim();
  if (topic.length === 0) {
    return err({
      code: 'INVALID_CONTEXT_DESCRIPTOR',
      message: 'context_descriptor.topic cannot be empty',
    });
  }

  if (topic.length > 500) {
    return err({
      code: 'INVALID_CONTEXT_DESCRIPTOR',
      message: 'context_descriptor.topic must be 500 characters or less',
    });
  }

  const result: ContextDescriptor = { topic };

  if (obj['purpose'] !== undefined) {
    if (typeof obj['purpose'] !== 'string') {
      return err({
        code: 'INVALID_CONTEXT_DESCRIPTOR',
        message: 'context_descriptor.purpose must be a string',
      });
    }
    if ((obj['purpose'] as string).length > 1000) {
      return err({
        code: 'INVALID_CONTEXT_DESCRIPTOR',
        message: 'context_descriptor.purpose must be 1000 characters or less',
      });
    }
    result.purpose = obj['purpose'] as string;
  }

  return ok(result);
}

/**
 * Validate an environmental_constraints object.
 * Required: max_participants (positive integer, 1-1000)
 * Optional: time_limit_minutes (positive integer, 1-1440), ai_model (non-empty string)
 */
export function validateEnvironmentalConstraints(input: unknown): Result<EnvironmentalConstraints, ApiError> {
  if (!input || typeof input !== 'object') {
    return err({
      code: 'INVALID_ENVIRONMENTAL_CONSTRAINTS',
      message: 'environmental_constraints is required and must be an object',
    });
  }

  const obj = input as Record<string, unknown>;

  if (obj['max_participants'] === undefined || obj['max_participants'] === null) {
    return err({
      code: 'INVALID_ENVIRONMENTAL_CONSTRAINTS',
      message: 'environmental_constraints.max_participants is required',
    });
  }

  if (typeof obj['max_participants'] !== 'number' || !Number.isInteger(obj['max_participants'])) {
    return err({
      code: 'INVALID_ENVIRONMENTAL_CONSTRAINTS',
      message: 'environmental_constraints.max_participants must be an integer',
    });
  }

  if ((obj['max_participants'] as number) < 1 || (obj['max_participants'] as number) > 1000) {
    return err({
      code: 'INVALID_ENVIRONMENTAL_CONSTRAINTS',
      message: 'environmental_constraints.max_participants must be between 1 and 1000',
    });
  }

  const result: EnvironmentalConstraints = {
    max_participants: obj['max_participants'] as number,
  };

  if (obj['time_limit_minutes'] !== undefined) {
    if (typeof obj['time_limit_minutes'] !== 'number' || !Number.isInteger(obj['time_limit_minutes'])) {
      return err({
        code: 'INVALID_ENVIRONMENTAL_CONSTRAINTS',
        message: 'environmental_constraints.time_limit_minutes must be an integer',
      });
    }
    if ((obj['time_limit_minutes'] as number) < 1 || (obj['time_limit_minutes'] as number) > 1440) {
      return err({
        code: 'INVALID_ENVIRONMENTAL_CONSTRAINTS',
        message: 'environmental_constraints.time_limit_minutes must be between 1 and 1440',
      });
    }
    result.time_limit_minutes = obj['time_limit_minutes'] as number;
  }

  if (obj['ai_model'] !== undefined) {
    if (typeof obj['ai_model'] !== 'string' || (obj['ai_model'] as string).trim().length === 0) {
      return err({
        code: 'INVALID_ENVIRONMENTAL_CONSTRAINTS',
        message: 'environmental_constraints.ai_model must be a non-empty string',
      });
    }
    result.ai_model = obj['ai_model'] as string;
  }

  return ok(result);
}

/**
 * Check if truth finalization is permitted for a session.
 * Per Framework Decision 2: only ENDED (CLOSED) sessions may be finalized.
 * Used by future features (006-verification-witness) before witness emission.
 */
export function isFinalizationPermitted(session: Session): boolean {
  return session.state === 'ENDED';
}
