/**
 * Compliance checker — evaluates the five MM-MODEL §11 conditions.
 * Read-only: queries existing data, never modifies system state.
 * @see specs/009-compliance-test/spec.md
 * @see specs/009-compliance-test/contracts/compliance-module.ts
 */

import { query } from '../lib/db.js';
import { getEntriesBySession, validateChain } from './ledger.js';
import { getPresenceRecords } from './presence-tracker.js';
import { verify } from './verification-engine.js';
import type {
  ComplianceCondition,
  ComplianceResult,
  ConditionEvaluation,
  EvidenceItem,
  LedgerEntry,
  PresenceRecord,
} from './types.js';
import type { Session } from '../lib/types.js';

// ============================================================================
// System Version
// ============================================================================

const SYSTEM_VERSION = '009';

// ============================================================================
// Helper: Load ENDED sessions with their integrity data
// ============================================================================

interface EndedSessionData {
  session: Session;
  ledgerEntries: LedgerEntry[];
  presenceRecords: PresenceRecord[];
}

/**
 * Load all ENDED sessions along with their ledger entries and presence records.
 * This is the read-only data set that all condition evaluators operate on.
 */
async function loadEndedSessions(): Promise<EndedSessionData[]> {
  const result = await query<Session & { id: string }>(
    `SELECT id, name, state, admin_id, created_at, started_at, ended_at,
            context_descriptor, environmental_constraints, token_count, user_count
       FROM sessions
      WHERE state = 'ENDED'
      ORDER BY ended_at ASC`
  );

  const sessions = result.rows.map((row) => ({
    id: row.id,
    name: (row as unknown as Record<string, string>).name,
    state: row.state,
    adminId: (row as unknown as Record<string, string>).admin_id,
    createdAt: (row as unknown as Record<string, Date>).created_at,
    startedAt: (row as unknown as Record<string, Date | null>).started_at,
    endedAt: (row as unknown as Record<string, Date | null>).ended_at,
    contextDescriptor: (row as unknown as Record<string, unknown>).context_descriptor,
    environmentalConstraints: (row as unknown as Record<string, unknown>).environmental_constraints,
    tokenCount: (row as unknown as Record<string, number>).token_count,
    userCount: (row as unknown as Record<string, number>).user_count,
  })) as unknown as Session[];

  const dataList: EndedSessionData[] = [];
  for (const session of sessions) {
    const [ledgerEntries, presenceRecords] = await Promise.all([
      getEntriesBySession(session.id),
      getPresenceRecords(session.id),
    ]);
    dataList.push({ session, ledgerEntries, presenceRecords });
  }

  return dataList;
}

// ============================================================================
// Condition 1: Truth Finalization
// ============================================================================

/**
 * PASS when all ENDED sessions have all presence records finalized
 * and no record has finalizedAt before the session's endedAt.
 */
export async function evaluateTruthFinalization(
  endedSessions: EndedSessionData[]
): Promise<ConditionEvaluation> {
  const evidence: EvidenceItem[] = [];

  // Vacuous PASS: no ENDED sessions
  if (endedSessions.length === 0) {
    return {
      condition: 'TRUTH_FINALIZATION',
      label: 'Truth Finalization',
      result: 'PASS',
      evidence: [],
    };
  }

  let failed = false;

  for (const { session, presenceRecords } of endedSessions) {
    for (const record of presenceRecords) {
      if (!record.finalized) {
        failed = true;
        evidence.push({
          type: 'PRESENCE_RECORD',
          description: 'Unfinalized presence record on ENDED session',
          sessionId: session.id,
          details: { presenceRecordId: record.id, sessionId: session.id },
        });
      } else if (session.endedAt && record.finalizedAt && record.finalizedAt < session.endedAt) {
        failed = true;
        evidence.push({
          type: 'PRESENCE_RECORD',
          description: 'Presence record finalized before session closure',
          sessionId: session.id,
          details: {
            presenceRecordId: record.id,
            finalizedAt: record.finalizedAt.toISOString(),
            sessionEndedAt: session.endedAt.toISOString(),
          },
        });
      }
    }
  }

  return {
    condition: 'TRUTH_FINALIZATION',
    label: 'Truth Finalization',
    result: failed ? 'FAIL' : 'PASS',
    evidence,
  };
}

// ============================================================================
// Condition 2: Deterministic Witnessed Verification
// ============================================================================

/**
 * PASS when every ENDED session has a VERIFICATION_WITNESS ledger entry
 * and re-running verify() produces the same pass_fail as the stored witness.
 */
export async function evaluateDeterministicVerification(
  endedSessions: EndedSessionData[]
): Promise<ConditionEvaluation> {
  const evidence: EvidenceItem[] = [];

  if (endedSessions.length === 0) {
    return {
      condition: 'DETERMINISTIC_VERIFICATION',
      label: 'Deterministic Witnessed Verification',
      result: 'PASS',
      evidence: [],
    };
  }

  let failed = false;

  for (const { session, ledgerEntries, presenceRecords } of endedSessions) {
    const witnessEntry = ledgerEntries.find((e) => e.eventType === 'VERIFICATION_WITNESS');

    if (!witnessEntry) {
      failed = true;
      evidence.push({
        type: 'WITNESS_ARTIFACT',
        description: 'Session has no VERIFICATION_WITNESS ledger entry',
        sessionId: session.id,
        details: { sessionId: session.id },
      });
      continue;
    }

    // Re-run verification and compare to stored witness
    const storedArtifact = witnessEntry.metadataSnapshot as unknown as { pass_fail?: 'PASS' | 'FAIL' };
    const storedPassFail = storedArtifact.pass_fail;

    const rerun = verify(session, ledgerEntries, undefined, presenceRecords);
    const rerunPassFail = rerun.pass ? 'PASS' : 'FAIL';

    if (storedPassFail !== rerunPassFail) {
      failed = true;
      evidence.push({
        type: 'WITNESS_ARTIFACT',
        description: 'Re-verification result differs from stored witness',
        sessionId: session.id,
        details: {
          sessionId: session.id,
          storedResult: storedPassFail,
          rerunResult: rerunPassFail,
        },
      });
    }
  }

  return {
    condition: 'DETERMINISTIC_VERIFICATION',
    label: 'Deterministic Witnessed Verification',
    result: failed ? 'FAIL' : 'PASS',
    evidence,
  };
}

// ============================================================================
// Condition 3: Mandatory Suppression
// ============================================================================

// Event types that represent mutating actions (excluding SESSION_CLOSED)
const MUTATING_EVENT_TYPES = new Set([
  'SESSION_CREATED',
  'SESSION_ACTIVATED',
  'TRANSITION_REJECTED',
  'VERIFICATION_WITNESS',
  'SUPPRESSION_EVENT',
]);

/**
 * PASS when every FAIL witness has corresponding SUPPRESSION_EVENT(s)
 * and no mutating ledger entries follow a SUPPRESSION_EVENT for the same session.
 */
export async function evaluateMandatorySuppression(
  endedSessions: EndedSessionData[]
): Promise<ConditionEvaluation> {
  const evidence: EvidenceItem[] = [];

  if (endedSessions.length === 0) {
    return {
      condition: 'MANDATORY_SUPPRESSION',
      label: 'Mandatory Suppression',
      result: 'PASS',
      evidence: [],
    };
  }

  let failed = false;

  for (const { session, ledgerEntries } of endedSessions) {
    const sorted = [...ledgerEntries].sort((a, b) => a.sequenceNumber - b.sequenceNumber);

    const failWitnesses = sorted.filter(
      (e) => e.eventType === 'VERIFICATION_WITNESS' &&
        (e.metadataSnapshot as unknown as { pass_fail?: string }).pass_fail === 'FAIL'
    );

    for (const witness of failWitnesses) {
      const suppressions = sorted.filter(
        (e) => e.eventType === 'SUPPRESSION_EVENT' && e.sequenceNumber > witness.sequenceNumber
      );

      if (suppressions.length === 0) {
        failed = true;
        evidence.push({
          type: 'SUPPRESSION_RECORD',
          description: 'FAIL witness has no corresponding SUPPRESSION_EVENT',
          sessionId: session.id,
          details: { sessionId: session.id, witnessId: witness.id, witnessSequence: witness.sequenceNumber },
        });
        continue;
      }

      // Check for mutating actions after suppression (excluding SESSION_CLOSED)
      const firstSuppression = suppressions[0];
      const postSuppressionEntries = sorted.filter(
        (e) =>
          e.sequenceNumber > firstSuppression.sequenceNumber &&
          e.eventType !== 'SESSION_CLOSED' &&
          e.eventType !== 'SUPPRESSION_EVENT' &&
          MUTATING_EVENT_TYPES.has(e.eventType)
      );

      for (const entry of postSuppressionEntries) {
        failed = true;
        evidence.push({
          type: 'LEDGER_ENTRY',
          description: 'Mutating action succeeded after SUPPRESSION_EVENT',
          sessionId: session.id,
          details: {
            sessionId: session.id,
            entryId: entry.id,
            eventType: entry.eventType,
            sequenceNumber: entry.sequenceNumber,
          },
        });
      }
    }
  }

  return {
    condition: 'MANDATORY_SUPPRESSION',
    label: 'Mandatory Suppression',
    result: failed ? 'FAIL' : 'PASS',
    evidence,
  };
}

// ============================================================================
// Condition 4: History Non-Regression
// ============================================================================

const STATE_ORDER: Record<string, number> = { CREATED: 0, ACTIVE: 1, ENDED: 2 };

/**
 * PASS when hash chain is valid, all state transitions are forward-only,
 * and protective DB triggers exist.
 */
export async function evaluateHistoryNonRegression(
  endedSessions: EndedSessionData[]
): Promise<ConditionEvaluation> {
  const evidence: EvidenceItem[] = [];
  let failed = false;

  // 1. Validate global hash chain
  const chainResult = await validateChain();
  if (!chainResult.valid) {
    failed = true;
    for (const err of chainResult.errors) {
      evidence.push({
        type: 'HASH_CHAIN',
        description: 'Hash chain integrity violation',
        details: {
          sequenceNumber: err.sequenceNumber,
          expectedHash: err.expectedHash,
          actualHash: err.actualHash,
        },
      });
    }
  }

  // 2. Check forward-only state transitions
  for (const { session, ledgerEntries } of endedSessions) {
    const sorted = [...ledgerEntries].sort((a, b) => a.sequenceNumber - b.sequenceNumber);
    let maxOrder = -1;

    for (const entry of sorted) {
      if (entry.toState && STATE_ORDER[entry.toState] !== undefined) {
        const order = STATE_ORDER[entry.toState];
        if (order < maxOrder) {
          failed = true;
          evidence.push({
            type: 'STATE_TRANSITION',
            description: 'Backward state transition detected',
            sessionId: session.id,
            details: {
              sessionId: session.id,
              entryId: entry.id,
              toState: entry.toState,
              sequenceNumber: entry.sequenceNumber,
            },
          });
        } else {
          maxOrder = order;
        }
      }
    }
  }

  // 3. Check protective triggers exist
  const triggerNames = ['trg_integrity_ledger_no_update', 'trg_integrity_ledger_no_delete'];
  const triggerResult = await query<{ tgname: string }>(
    `SELECT t.tgname
       FROM pg_trigger t
       JOIN pg_class c ON c.oid = t.tgrelid
      WHERE c.relname = 'integrity_ledger'
        AND t.tgname = ANY($1)`,
    [triggerNames]
  );
  const foundTriggers = new Set(triggerResult.rows.map((r) => r.tgname));

  for (const name of triggerNames) {
    if (!foundTriggers.has(name)) {
      failed = true;
      evidence.push({
        type: 'SCHEMA_CHECK',
        description: `Protective trigger missing: ${name}`,
        details: { triggerName: name },
      });
    }
  }

  return {
    condition: 'HISTORY_NON_REGRESSION',
    label: 'History Non-Regression',
    result: failed ? 'FAIL' : 'PASS',
    evidence,
  };
}

// ============================================================================
// Condition 5: Authority Non-Assertion
// ============================================================================

// Admin action event types that conflict with suppression
const ADMIN_OVERRIDE_EVENT_TYPES = new Set([
  'SESSION_ACTIVATED',
  'SESSION_CLOSED',
  'TRANSITION_REJECTED',
]);

/**
 * PASS when no admin action succeeded after a SUPPRESSION_EVENT for the same session
 * (excluding non-conflicting operations like SESSION_CREATED, token generation).
 */
export async function evaluateAuthorityNonAssertion(
  endedSessions: EndedSessionData[]
): Promise<ConditionEvaluation> {
  const evidence: EvidenceItem[] = [];

  if (endedSessions.length === 0) {
    return {
      condition: 'AUTHORITY_NON_ASSERTION',
      label: 'Authority Non-Assertion',
      result: 'PASS',
      evidence: [],
    };
  }

  let failed = false;

  for (const { session, ledgerEntries } of endedSessions) {
    const sorted = [...ledgerEntries].sort((a, b) => a.sequenceNumber - b.sequenceNumber);

    // Find all SUPPRESSION_EVENTs for this session
    const suppressions = sorted.filter((e) => e.eventType === 'SUPPRESSION_EVENT');
    if (suppressions.length === 0) continue;

    const firstSuppression = suppressions[0];

    // Check for conflicting admin actions after first suppression
    const postSuppressionAdminActions = sorted.filter(
      (e) =>
        e.sequenceNumber > firstSuppression.sequenceNumber &&
        ADMIN_OVERRIDE_EVENT_TYPES.has(e.eventType)
    );

    for (const entry of postSuppressionAdminActions) {
      // An admin action after suppression is a violation unless it was itself suppressed
      // (i.e. followed immediately by another SUPPRESSION_EVENT)
      const nextEntry = sorted.find((e) => e.sequenceNumber > entry.sequenceNumber);
      const wasItSelfSuppressed = nextEntry?.eventType === 'SUPPRESSION_EVENT';

      if (!wasItSelfSuppressed) {
        failed = true;
        evidence.push({
          type: 'ADMIN_ACTION',
          description: 'Admin action succeeded after SUPPRESSION_EVENT',
          sessionId: session.id,
          details: {
            sessionId: session.id,
            entryId: entry.id,
            eventType: entry.eventType,
            sequenceNumber: entry.sequenceNumber,
            firstSuppressionSequence: firstSuppression.sequenceNumber,
          },
        });
      }
    }
  }

  return {
    condition: 'AUTHORITY_NON_ASSERTION',
    label: 'Authority Non-Assertion',
    result: failed ? 'FAIL' : 'PASS',
    evidence,
  };
}

// ============================================================================
// Orchestrator
// ============================================================================

const ALL_CONDITIONS: ComplianceCondition[] = [
  'TRUTH_FINALIZATION',
  'DETERMINISTIC_VERIFICATION',
  'MANDATORY_SUPPRESSION',
  'HISTORY_NON_REGRESSION',
  'AUTHORITY_NON_ASSERTION',
];

/**
 * Run the full compliance check — evaluates all 5 §11 conditions.
 * Returns ERROR (not NON_COMPLIANT) on infrastructure failures.
 */
export async function runComplianceCheck(): Promise<ComplianceResult> {
  const executedAt = new Date().toISOString();

  try {
    const endedSessions = await loadEndedSessions();

    const [c1, c2, c3, c4, c5] = await Promise.all([
      evaluateTruthFinalization(endedSessions),
      evaluateDeterministicVerification(endedSessions),
      evaluateMandatorySuppression(endedSessions),
      evaluateHistoryNonRegression(endedSessions),
      evaluateAuthorityNonAssertion(endedSessions),
    ]);

    const conditions = [c1, c2, c3, c4, c5];
    const allPass = conditions.every((c) => c.result === 'PASS');

    return {
      overall: allPass ? 'COMPLIANT' : 'NON_COMPLIANT',
      conditions,
      executedAt,
      systemVersion: SYSTEM_VERSION,
      sessionsEvaluated: endedSessions.length,
    };
  } catch (err) {
    return {
      overall: 'ERROR',
      conditions: [],
      executedAt,
      systemVersion: SYSTEM_VERSION,
      sessionsEvaluated: 0,
      error: err instanceof Error ? err.message : String(err),
    };
  }
}

/**
 * Run a single compliance condition independently.
 * Returns ComplianceResult with a single condition in the conditions array.
 */
export async function runConditionCheck(condition: ComplianceCondition): Promise<ComplianceResult> {
  const executedAt = new Date().toISOString();

  try {
    const endedSessions = await loadEndedSessions();

    let evaluation: ConditionEvaluation;

    switch (condition) {
      case 'TRUTH_FINALIZATION':
        evaluation = await evaluateTruthFinalization(endedSessions);
        break;
      case 'DETERMINISTIC_VERIFICATION':
        evaluation = await evaluateDeterministicVerification(endedSessions);
        break;
      case 'MANDATORY_SUPPRESSION':
        evaluation = await evaluateMandatorySuppression(endedSessions);
        break;
      case 'HISTORY_NON_REGRESSION':
        evaluation = await evaluateHistoryNonRegression(endedSessions);
        break;
      case 'AUTHORITY_NON_ASSERTION':
        evaluation = await evaluateAuthorityNonAssertion(endedSessions);
        break;
    }

    return {
      overall: evaluation.result === 'PASS' ? 'COMPLIANT' : 'NON_COMPLIANT',
      conditions: [evaluation],
      executedAt,
      systemVersion: SYSTEM_VERSION,
      sessionsEvaluated: endedSessions.length,
    };
  } catch (err) {
    return {
      overall: 'ERROR',
      conditions: [],
      executedAt,
      systemVersion: SYSTEM_VERSION,
      sessionsEvaluated: 0,
      error: err instanceof Error ? err.message : String(err),
    };
  }
}
