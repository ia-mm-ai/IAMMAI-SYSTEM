/**
 * IAMMAI Contribution Tracker — 6-Role Semantic Participation
 *
 * Tracks who contributed what to a matter, preserving the distinction
 * between 6 contribution roles:
 * - ORIGIN: who initiated the matter
 * - ELICITATION: who drew out the content (e.g., admin asking questions)
 * - FORMALIZATION: who gave structure to content (e.g., AI formatting)
 * - AUTHORIZATION: who approved/governed the matter
 * - RENDERING: who produced the final artifact (e.g., AI generating response)
 * - TRANSMISSION: who delivered the output
 *
 * These roles are NOT mutually exclusive per actor — an actor may hold
 * multiple roles on the same matter. They ARE append-only.
 */

import type pg from 'pg';
import type { ContributionRole, IammaiContributionRecord } from './types.js';
import { createContributionRecord } from './record-factory.js';
import { insertContributionRecord, getContributionRecordsByMatter } from './registry.js';

export interface ContributionParams {
  matter_ref: string;
  actor_ref: string;
  role: ContributionRole;
  context_ref?: string | null;
}

/**
 * Record a contribution role for an actor on a matter.
 * Idempotent: duplicate (matter_ref, actor_ref, role) is a no-op.
 */
export async function recordContribution(
  client: pg.PoolClient,
  params: ContributionParams
): Promise<IammaiContributionRecord> {
  const record = createContributionRecord(params);
  await insertContributionRecord(client, record);
  return record;
}

/**
 * Record multiple contribution roles in a batch.
 */
export async function recordContributions(
  client: pg.PoolClient,
  contributions: ContributionParams[]
): Promise<IammaiContributionRecord[]> {
  const records: IammaiContributionRecord[] = [];
  for (const params of contributions) {
    records.push(await recordContribution(client, params));
  }
  return records;
}

/**
 * Get all contributions for a matter.
 */
export async function getContributionsByMatter(
  matterRef: string
): Promise<IammaiContributionRecord[]> {
  return getContributionRecordsByMatter(matterRef);
}

/**
 * Get contributions by a specific actor on a matter.
 */
export function getActorRoles(
  contributions: IammaiContributionRecord[],
  actorRef: string
): ContributionRole[] {
  return contributions
    .filter(c => c.actor_ref === actorRef)
    .map(c => c.role);
}

/**
 * Check if an actor has a specific role on a matter.
 */
export function hasRole(
  contributions: IammaiContributionRecord[],
  actorRef: string,
  role: ContributionRole
): boolean {
  return contributions.some(c => c.actor_ref === actorRef && c.role === role);
}

/**
 * Check if an actor has the admin-expected roles (ORIGIN and/or AUTHORIZATION).
 */
export function hasAdminRoles(
  contributions: IammaiContributionRecord[],
  actorRef: string
): { hasOrigin: boolean; hasAuthorization: boolean } {
  const roles = getActorRoles(contributions, actorRef);
  return {
    hasOrigin: roles.includes('ORIGIN'),
    hasAuthorization: roles.includes('AUTHORIZATION'),
  };
}

/**
 * Check if an actor has the AI-expected roles (FORMALIZATION and/or RENDERING).
 */
export function hasAiRoles(
  contributions: IammaiContributionRecord[],
  actorRef: string
): { hasFormalization: boolean; hasRendering: boolean } {
  const roles = getActorRoles(contributions, actorRef);
  return {
    hasFormalization: roles.includes('FORMALIZATION'),
    hasRendering: roles.includes('RENDERING'),
  };
}

/**
 * Get a map of actors to their roles for a set of contributions.
 */
export function getRoleMap(
  contributions: IammaiContributionRecord[]
): Record<string, ContributionRole[]> {
  const map: Record<string, ContributionRole[]> = {};
  for (const c of contributions) {
    if (!map[c.actor_ref]) {
      map[c.actor_ref] = [];
    }
    if (!map[c.actor_ref].includes(c.role)) {
      map[c.actor_ref].push(c.role);
    }
  }
  return map;
}
