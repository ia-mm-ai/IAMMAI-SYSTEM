/**
 * Accession Coordinator — Orchestrates stage advancement
 *
 * Coordination sequence: Validate -> Witness -> Govern -> Advance -> Persist
 * Reuses existing IAMMAI governor, witness-factory, and validator.
 */

import type pg from 'pg';
import { v4 as uuidv4 } from 'uuid';
import { transaction } from '../../../lib/db.js';
import { recordGovernanceAction } from '../governor.js';
import { emitIammaiWitness } from '../witness-factory.js';
import { createValidationArtifact } from '../record-factory.js';
import { insertValidationArtifact } from '../registry.js';
import { isValidAccessionTransition, getNextStage, getTransitionType } from './stage-engine.js';
import { checkEligibility, buildShadow, runProofTests, makeAdmissionDecision } from './accession-validator.js';
import {
  insertAccessionState,
  insertAccessionTransition,
  insertShadowRecord,
  insertProofRecord,
  getAccessionStatesBySlice,
  getExportedSlice,
  insertExternalSource,
  insertExportedSlice,
} from './accession-registry.js';
import { ACCESSION_STAGE_FAMILY, sliceMatterRef } from './types.js';
import type {
  AccessionStage,
  AccessionStateRecord,
  AccessionTransition,
  ContactOutcome,
  AdmissionDecision,
  ExternalSource,
  ExportedSlice,
  SessionSummarySlice,
  ShadowRecord,
  ProofRecord,
} from './types.js';

// ============================================================================
// Pure helpers (testable without DB)
// ============================================================================

/**
 * Determine the contact outcome for a slice.
 * Contact accepts for observation if a bounded slice is presented.
 * Contact does NOT judge quality — that is eligibility/proof's job.
 */
export function determineContactOutcome(
  sliceData: SessionSummarySlice
): ContactOutcome {
  if (sliceData.source_session_ref && sliceData.platform_name) {
    return 'accepted_for_observation';
  }
  return 'insufficient_grounding';
}

/**
 * Build a stage_outcome JSONB value.
 */
export function buildStageOutcome(
  stage: AccessionStage,
  data: Record<string, unknown>
): Record<string, unknown> {
  return { stage, ...data };
}

// ============================================================================
// Stage Advancement Result
// ============================================================================

export interface StageAdvanceResult {
  stateRecord: AccessionStateRecord;
  transitionRecord: AccessionTransition | null;
  governanceActionId: string;
  witnessArtifactId: string;
  validationArtifactId: string | null;
  stageSpecificRecords: {
    shadow?: ShadowRecord;
    proofs?: ProofRecord[];
    admissionDecision?: AdmissionDecision;
  };
}

// ============================================================================
// Advance to Next Stage
// ============================================================================

/**
 * Advance a slice to the next accession stage.
 * Orchestrates: Validate -> Witness -> Govern -> Advance -> Persist
 */
export async function advanceSlice(
  sliceId: string,
  actorRef: string
): Promise<StageAdvanceResult> {
  return transaction(async (client) => {
    // 1. Load current state
    const slice = await getExportedSlice(sliceId);
    if (!slice) throw new Error(`Slice ${sliceId} not found`);

    const states = await getAccessionStatesBySlice(sliceId);
    const currentState = states[states.length - 1];
    if (!currentState) throw new Error(`No state records found for slice ${sliceId}`);

    const currentStage = currentState.accession_stage;
    const nextStage = getNextStage(currentStage);
    if (!nextStage) throw new Error(`Slice ${sliceId} is at terminal stage ${currentStage}`);

    if (!isValidAccessionTransition(currentStage, nextStage)) {
      throw new Error(`Invalid transition: ${currentStage} -> ${nextStage}`);
    }

    // Defensive: block advancement past refused admission
    if (nextStage === 'bound_vessel') {
      const admissionState = states.find(s => s.accession_stage === 'admission');
      const decision = (admissionState?.stage_outcome as Record<string, unknown>)?.['decision'];
      if (decision !== 'admitted') {
        throw new Error(`Cannot advance to bound_vessel: admission decision was '${decision}', not 'admitted'`);
      }
    }

    const matterRef = sliceMatterRef(sliceId);
    const sliceData = slice.slice_data as unknown as SessionSummarySlice;

    // 2. Run stage-specific logic to produce outcome + records
    let stageOutcome: Record<string, unknown> = {};
    let validationArtifactId: string | null = null;
    const stageSpecificRecords: StageAdvanceResult['stageSpecificRecords'] = {};

    switch (nextStage) {
      case 'eligibility': {
        const eligibility = checkEligibility(slice);
        stageOutcome = buildStageOutcome('eligibility', {
          passed: eligibility.passed,
          conditions: eligibility.conditions,
        });
        const valArtifact = createValidationArtifact({
          validation_type: 'admissibility',
          target_ref: matterRef,
          condition_set_ref: `accession:eligibility:${sliceId}`,
          outcome: eligibility.passed ? 'pass' : 'fail',
          reason_refs: eligibility.conditions.map(c => `condition:${c.name}:${c.passed ? 'pass' : 'fail'}`),
          actor_ref: actorRef,
        });
        await insertValidationArtifact(client, valArtifact);
        validationArtifactId = valArtifact.validation_id;
        break;
      }

      case 'shadow': {
        const shadow = buildShadow(sliceData);
        const shadowRecord: ShadowRecord = {
          shadow_id: uuidv4(),
          slice_ref: sliceId,
          shadow_data: shadow.shadow_data,
          discrepancies: shadow.discrepancies,
          data_role: 'derived',
          created_at: new Date(),
          governance_action_ref: null,
        };
        await insertShadowRecord(client, shadowRecord);
        stageSpecificRecords.shadow = shadowRecord;
        stageOutcome = buildStageOutcome('shadow', {
          discrepancy_count: shadow.discrepancies.length,
          discrepancies: shadow.discrepancies,
        });
        break;
      }

      case 'proof': {
        const shadowResult = await client.query<ShadowRecord>(
          `SELECT * FROM iammai_shadow_records WHERE slice_ref = $1 ORDER BY created_at DESC LIMIT 1`,
          [sliceId]
        );
        const shadowRecord = shadowResult.rows[0];
        if (!shadowRecord) throw new Error(`No shadow record found for slice ${sliceId}`);

        const proofResults = runProofTests(sliceData, {
          shadow_data: shadowRecord.shadow_data as Record<string, unknown>,
          discrepancies: shadowRecord.discrepancies as Array<Record<string, unknown>>,
        });

        const proofRecords: ProofRecord[] = [];
        for (const proof of proofResults) {
          const proofRecord: ProofRecord = {
            proof_id: uuidv4(),
            slice_ref: sliceId,
            shadow_ref: shadowRecord.shadow_id,
            test_name: proof.test_name,
            test_result: proof.result,
            test_details: proof.details,
            checked_at: new Date(),
          };
          await insertProofRecord(client, proofRecord);
          proofRecords.push(proofRecord);
        }
        stageSpecificRecords.proofs = proofRecords;
        stageOutcome = buildStageOutcome('proof', {
          test_count: proofResults.length,
          pass_count: proofResults.filter(p => p.result === 'pass').length,
          fail_count: proofResults.filter(p => p.result === 'fail').length,
          tests: proofResults,
        });
        break;
      }

      case 'admission': {
        const proofsResult = await client.query<ProofRecord>(
          `SELECT * FROM iammai_proof_records WHERE slice_ref = $1 ORDER BY checked_at ASC`,
          [sliceId]
        );
        const proofs = proofsResult.rows;
        const decision = makeAdmissionDecision(
          proofs.map(p => ({ test_name: p.test_name, result: p.test_result, details: p.test_details as Record<string, unknown> }))
        );
        stageSpecificRecords.admissionDecision = decision;
        stageOutcome = buildStageOutcome('admission', {
          decision,
          proof_count: proofs.length,
          failed_proofs: proofs.filter(p => p.test_result === 'fail').map(p => p.test_name),
        });
        break;
      }

      case 'bound_vessel': {
        const admissionState = states.find(s => s.accession_stage === 'admission');
        const admissionOutcome = admissionState?.stage_outcome as Record<string, unknown> | undefined;
        if (admissionOutcome?.['decision'] !== 'admitted') {
          throw new Error(`Cannot create bound vessel: admission decision was ${admissionOutcome?.['decision']}, not 'admitted'`);
        }
        stageOutcome = buildStageOutcome('bound_vessel', {
          vessel_type: 'derivative',
          permissions: ['read'],
          constraints: ['non-native', 'no-standing-state', 'no-governance', 'no-canonical-source'],
        });
        break;
      }

      default:
        stageOutcome = buildStageOutcome(nextStage, {});
    }

    // 3. Govern — record governance action via shared table
    const governanceAction = await recordGovernanceAction(client, {
      action_type: 'authorize',
      authority_class: 'OPERATOR',
      actor_ref: actorRef,
      legitimacy_basis_ref: `accession:${currentStage}_to_${nextStage}`,
      matter_ref: matterRef,
    });

    // 4. Witness — emit with mandatory non-claims
    const witness = await emitIammaiWitness(client, {
      witness_type: 'transition',
      target_ref: matterRef,
      claims: [
        `accession_stage_transition:${currentStage}_to_${nextStage}`,
        `actor:${actorRef}`,
        `slice:${sliceId}`,
      ],
      actor_ref: actorRef,
      surface_ref: 'accession-coordinator',
    });

    // 5. Create new state record
    const newState: AccessionStateRecord = {
      state_id: uuidv4(),
      slice_ref: sliceId,
      accession_family: ACCESSION_STAGE_FAMILY[nextStage],
      accession_stage: nextStage,
      stage_outcome: stageOutcome,
      recorded_at: new Date(),
      predecessor_ref: currentState.state_id,
      related_governance_ref: governanceAction.governance_action_id,
      related_validation_ref: validationArtifactId,
      related_witness_ref: witness.witness_id,
    };
    await insertAccessionState(client, newState);

    // 6. Create transition record
    const transitionRecord: AccessionTransition = {
      transition_id: uuidv4(),
      slice_ref: sliceId,
      source_state_ref: currentState.state_id,
      target_state_ref: newState.state_id,
      transition_type: getTransitionType(currentStage, nextStage),
      occurred_at: new Date(),
    };
    await insertAccessionTransition(client, transitionRecord);

    return {
      stateRecord: newState,
      transitionRecord,
      governanceActionId: governanceAction.governance_action_id,
      witnessArtifactId: witness.witness_id,
      validationArtifactId,
      stageSpecificRecords,
    };
  });
}

// ============================================================================
// Seed Loading
// ============================================================================

/**
 * Load seed cases: create external source + exported slice + initial Contact state.
 */
export async function seedSlice(
  client: pg.PoolClient,
  source: ExternalSource,
  slice: ExportedSlice,
  sliceData: SessionSummarySlice,
  actorRef: string
): Promise<AccessionStateRecord> {
  await insertExternalSource(client, source);
  await insertExportedSlice(client, slice);

  const matterRef = sliceMatterRef(slice.slice_id);
  const contactOutcome = determineContactOutcome(sliceData);

  // Govern
  const governanceAction = await recordGovernanceAction(client, {
    action_type: 'authorize',
    authority_class: 'OPERATOR',
    actor_ref: actorRef,
    legitimacy_basis_ref: 'accession:initial_contact',
    matter_ref: matterRef,
  });

  // Witness
  const witness = await emitIammaiWitness(client, {
    witness_type: 'interaction',
    target_ref: matterRef,
    claims: [
      `contact_initiated:${slice.slice_id}`,
      `contact_outcome:${contactOutcome}`,
      `source:${source.source_name}`,
      `actor:${actorRef}`,
    ],
    actor_ref: actorRef,
    surface_ref: 'accession-coordinator',
  });

  // Create initial Contact state
  const contactState: AccessionStateRecord = {
    state_id: uuidv4(),
    slice_ref: slice.slice_id,
    accession_family: 'pre_admission',
    accession_stage: 'contact',
    stage_outcome: buildStageOutcome('contact', { contact_outcome: contactOutcome }),
    recorded_at: new Date(),
    predecessor_ref: null,
    related_governance_ref: governanceAction.governance_action_id,
    related_validation_ref: null,
    related_witness_ref: witness.witness_id,
  };
  await insertAccessionState(client, contactState);

  return contactState;
}
