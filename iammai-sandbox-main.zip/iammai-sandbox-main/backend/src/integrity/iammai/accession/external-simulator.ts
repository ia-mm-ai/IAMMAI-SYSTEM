/**
 * External Simulator — Generates ExternalSession + SessionSummarySlice
 *
 * Produces source objects for the two seed cases.
 * Not persisted in its own right — a data generator.
 */

import { v4 as uuidv4 } from 'uuid';
import type { ExternalSession, SessionSummarySlice } from './types.js';

export function generateCleanSession(): ExternalSession {
  return {
    session_id: uuidv4(),
    platform_name: 'Momacka',
    participants: [
      { id: 'u1', name: 'Mario', role: 'mladozenja', joined_at: '2026-06-01T20:00:00Z' },
      { id: 'u2', name: 'Marko', role: 'kum', joined_at: '2026-06-01T20:00:30Z' },
    ],
    started_at: '2026-06-01T20:00:00Z',
    ended_at: '2026-06-01T20:30:00Z',
    duration_seconds: 1800,
    messages: [
      { sender_id: 'u1', content: 'Brt, sta cemo za momacku?', sent_at: '2026-06-01T20:01:00Z' },
      { sender_id: 'u2', content: 'Brateee, kad je uopce vjencanje?', sent_at: '2026-06-01T20:02:30Z' },
      { sender_id: 'u1', content: 'Pa u osmom mjesecu', sent_at: '2026-06-01T20:03:00Z' },
      { sender_id: 'u2', content: 'Aaaaa pa kad je osmi mjesec', sent_at: '2026-06-01T20:04:00Z' },
      { sender_id: 'u1', content: 'Za dva mjeseca brt', sent_at: '2026-06-01T20:05:00Z' },
      { sender_id: 'u2', content: 'Dva mjeseca?? Ima jos vremena', sent_at: '2026-06-01T20:07:00Z' },
      { sender_id: 'u1', content: 'Ma dobro, ali moramo neso smisliti', sent_at: '2026-06-01T20:10:00Z' },
      { sender_id: 'u2', content: 'Joj dobro ja cu organizirat. Di bi isli?', sent_at: '2026-06-01T20:13:00Z' },
      { sender_id: 'u1', content: 'Ne znam brt, ti si kum, ti reci', sent_at: '2026-06-01T20:15:00Z' },
      { sender_id: 'u2', content: 'Aj znas sta, nadji ti mjesto', sent_at: '2026-06-01T20:18:00Z' },
      { sender_id: 'u1', content: 'Cekaj ti si kum. Ti organiziras.', sent_at: '2026-06-01T20:20:00Z' },
      { sender_id: 'u2', content: 'Dobro dobro. Javim ti sutra.', sent_at: '2026-06-01T20:24:00Z' },
      { sender_id: 'u1', content: 'Sutra?? Brt vrtimo se u krug.', sent_at: '2026-06-01T20:27:00Z' },
      { sender_id: 'u2', content: 'Aj rijeseno. Javim ti sutra. 100%.', sent_at: '2026-06-01T20:29:30Z' },
    ],
    topic: 'Dogovor za momacku',
    outcome: 'resolved',
    metadata: { channel: 'group_chat', language: 'hr' },
  };
}

export function generateMessySession(): ExternalSession {
  return {
    session_id: uuidv4(),
    platform_name: 'Seen',
    participants: [
      { id: 'u1', name: 'Mario', role: 'mladozenja', joined_at: '2026-06-10T21:00:00Z' },
      { id: 'u2', name: 'Marko', role: 'kum', joined_at: '2026-06-10T21:00:00Z' },
    ],
    started_at: '2026-06-10T21:00:00Z',
    ended_at: '2026-06-10T21:00:00Z',
    duration_seconds: 0,
    messages: [
      { sender_id: 'u1', content: 'Brt, reminder za momacku', sent_at: '2026-06-10T21:00:00Z' },
      { sender_id: 'u1', content: 'Brt?', sent_at: '2026-06-10T21:00:10Z' },
    ],
    topic: 'Momacka v2: sad stvarno',
    outcome: null,
    metadata: { channel: 'group_chat', language: 'hr' },
  };
}

export function exportSlice(session: ExternalSession): SessionSummarySlice {
  return {
    slice_id: uuidv4(),
    source_session_ref: session.session_id,
    platform_name: session.platform_name,
    participant_count: session.participants.length,
    duration_seconds: session.duration_seconds,
    topic: session.topic,
    outcome: session.outcome,
    has_explicit_end: session.ended_at !== session.started_at && session.ended_at !== '',
  };
}
