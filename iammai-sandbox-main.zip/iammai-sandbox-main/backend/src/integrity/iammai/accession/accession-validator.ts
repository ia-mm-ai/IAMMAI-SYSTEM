/**
 * Accession Validator — Stage transition validation, eligibility checks, proof tests
 *
 * Pure validation logic. Does NOT exercise governance force.
 */

import type {
  ExportedSlice,
  SessionSummarySlice,
  AdmissionDecision,
} from './types.js';

// ============================================================================
// Eligibility Check (Stage 2)
// ============================================================================

interface EligibilityCondition {
  name: string;
  description: string;
  passed: boolean;
}

interface EligibilityResult {
  passed: boolean;
  conditions: EligibilityCondition[];
}

/**
 * Check minimal candidacy conditions.
 * Eligibility checks that the slice EXISTS and is bounded — not quality.
 */
export function checkEligibility(slice: ExportedSlice): EligibilityResult {
  const conditions: EligibilityCondition[] = [
    {
      name: 'bounded_slice_named',
      description: 'One bounded slice is named (not whole-system)',
      passed: !!slice.slice_id && !!slice.slice_name,
    },
    {
      name: 'source_visibility',
      description: 'Source visibility is possible (can trace back to external session)',
      passed: !!slice.source_id,
    },
    {
      name: 'roles_distinguishable',
      description: 'Roles are distinguishable (source/exported/derived not fused)',
      passed: slice.data_role === 'exported',
    },
    {
      name: 'bounded_inspection_possible',
      description: 'Bounded inspection is possible',
      passed: slice.slice_data !== null && typeof slice.slice_data === 'object',
    },
  ];

  return {
    passed: conditions.every(c => c.passed),
    conditions,
  };
}

// ============================================================================
// Shadow Builder (Stage 3)
// ============================================================================

interface ShadowResult {
  shadow_data: Record<string, unknown>;
  discrepancies: Array<Record<string, unknown>>;
}

/**
 * Create a non-native mirror of the slice and compare against body standards.
 */
export function buildShadow(sliceData: SessionSummarySlice): ShadowResult {
  const shadow_data: Record<string, unknown> = { ...sliceData };
  const discrepancies: Array<Record<string, unknown>> = [];

  if (!sliceData.topic || sliceData.topic.trim() === '') {
    discrepancies.push({
      type: 'missing_value',
      field: 'topic',
      expected: 'non-empty string',
      actual: sliceData.topic,
    });
  }

  if (sliceData.outcome === null || sliceData.outcome === undefined) {
    discrepancies.push({
      type: 'missing_value',
      field: 'outcome',
      expected: 'one of: resolved, abandoned, escalated, expired',
      actual: null,
    });
  }

  if (sliceData.participant_count === 0) {
    discrepancies.push({
      type: 'out_of_range',
      field: 'participant_count',
      expected: '> 0',
      actual: 0,
    });
  }

  if (sliceData.duration_seconds <= 0) {
    discrepancies.push({
      type: 'out_of_range',
      field: 'duration_seconds',
      expected: '> 0 and < 86400',
      actual: sliceData.duration_seconds,
    });
  } else if (sliceData.duration_seconds >= 86400) {
    discrepancies.push({
      type: 'out_of_range',
      field: 'duration_seconds',
      expected: '> 0 and < 86400',
      actual: sliceData.duration_seconds,
    });
  }

  if (!sliceData.has_explicit_end) {
    discrepancies.push({
      type: 'structural_difference',
      field: 'has_explicit_end',
      expected: true,
      actual: false,
    });
  }

  return { shadow_data, discrepancies };
}

// ============================================================================
// Proof Tests (Stage 4)
// ============================================================================

const VALID_OUTCOMES = ['resolved', 'abandoned', 'escalated', 'expired'];

interface ProofTestResult {
  test_name: string;
  result: 'pass' | 'fail' | 'blocked' | 'indeterminate';
  details: Record<string, unknown>;
}

/**
 * Run bounded proof tests against the shadow.
 * Each test produces a typed result.
 */
export function runProofTests(
  sliceData: SessionSummarySlice,
  _shadow: ShadowResult
): ProofTestResult[] {
  return [
    {
      test_name: 'required_fields_present',
      result: (sliceData.participant_count > 0 && sliceData.topic.trim() !== '' && sliceData.outcome !== null)
        ? 'pass' : 'fail',
      details: {
        participant_count: sliceData.participant_count,
        topic_present: sliceData.topic.trim() !== '',
        outcome_present: sliceData.outcome !== null,
      },
    },
    {
      test_name: 'duration_plausible',
      result: (sliceData.duration_seconds > 0 && sliceData.duration_seconds < 86400)
        ? 'pass' : 'fail',
      details: {
        duration_seconds: sliceData.duration_seconds,
        min: 1,
        max: 86399,
      },
    },
    {
      test_name: 'explicit_end',
      result: sliceData.has_explicit_end ? 'pass' : 'fail',
      details: {
        has_explicit_end: sliceData.has_explicit_end,
      },
    },
    {
      test_name: 'outcome_valid',
      result: (sliceData.outcome !== null && VALID_OUTCOMES.includes(sliceData.outcome))
        ? 'pass' : 'fail',
      details: {
        outcome: sliceData.outcome,
        valid_outcomes: VALID_OUTCOMES,
      },
    },
  ];
}

// ============================================================================
// Admission Decision (Stage 5)
// ============================================================================

/**
 * Make admission decision based on proof results.
 */
export function makeAdmissionDecision(
  proofs: Array<{ test_name: string; result: 'pass' | 'fail' | 'blocked' | 'indeterminate'; details: Record<string, unknown> }>
): AdmissionDecision {
  const hasFail = proofs.some(p => p.result === 'fail');
  if (hasFail) return 'refused';

  const hasIndeterminate = proofs.some(p => p.result === 'indeterminate' || p.result === 'blocked');
  if (hasIndeterminate) return 'not_yet';

  return 'admitted';
}
