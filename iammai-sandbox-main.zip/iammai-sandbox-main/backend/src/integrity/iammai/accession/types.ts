/**
 * Accession Layer — Type Definitions
 *
 * 7-stage accession state machine for external system approach.
 * Parallel to (NOT merged with) the 9-phase canonical engine.
 */

export type AccessionStage =
  | 'contact' | 'eligibility' | 'shadow' | 'proof' | 'admission' | 'bound_vessel' | 'revoked';

export type AccessionFamily = 'pre_admission' | 'post_admission';

export type ContactOutcome =
  | 'accepted_for_observation' | 'out_of_scope' | 'insufficient_grounding' | 'refused';

export type AdmissionDecision = 'admitted' | 'not_yet' | 'refused';

export type DataRole = 'source' | 'exported' | 'derived' | 'display';

export const ACCESSION_STAGE_ORDINAL: Record<AccessionStage, number> = {
  contact: 1, eligibility: 2, shadow: 3, proof: 4, admission: 5, bound_vessel: 6, revoked: 7,
};

export const ACCESSION_STAGES_IN_ORDER: AccessionStage[] = [
  'contact', 'eligibility', 'shadow', 'proof', 'admission', 'bound_vessel', 'revoked',
];

export const ACCESSION_STAGE_FAMILY: Record<AccessionStage, AccessionFamily> = {
  contact: 'pre_admission', eligibility: 'pre_admission', shadow: 'pre_admission',
  proof: 'pre_admission', admission: 'pre_admission',
  bound_vessel: 'post_admission', revoked: 'post_admission',
};

export const VALID_ACCESSION_TRANSITIONS: Record<AccessionStage, AccessionStage[]> = {
  contact: ['eligibility', 'revoked'],
  eligibility: ['shadow', 'revoked'],
  shadow: ['proof', 'revoked'],
  proof: ['admission', 'revoked'],
  admission: ['bound_vessel', 'revoked'],
  bound_vessel: ['revoked'],
  revoked: [],
};

export const ACCESSION_TRANSITION_TYPES: Record<string, string> = {
  contact_to_eligibility: 'contact_to_eligibility',
  eligibility_to_shadow: 'eligibility_to_shadow',
  shadow_to_proof: 'shadow_to_proof',
  proof_to_admission: 'proof_to_admission',
  admission_to_bound_vessel: 'admission_to_bound_vessel',
  to_revoked: 'to_revoked',
};

export interface ExternalSource {
  source_id: string; source_name: string; source_system_ref: string;
  source_data: Record<string, unknown>; actor_ref: string; created_at: Date;
}

export interface ExportedSlice {
  slice_id: string; source_id: string; slice_name: string;
  slice_data: Record<string, unknown>; data_role: DataRole; created_at: Date;
}

export interface AccessionStateRecord {
  state_id: string; slice_ref: string; accession_family: AccessionFamily;
  accession_stage: AccessionStage; stage_outcome: Record<string, unknown>;
  recorded_at: Date; predecessor_ref: string | null;
  related_governance_ref: string | null; related_validation_ref: string | null;
  related_witness_ref: string | null;
}

export interface AccessionTransition {
  transition_id: string; slice_ref: string; source_state_ref: string;
  target_state_ref: string; transition_type: string; occurred_at: Date;
}

export interface ShadowRecord {
  shadow_id: string; slice_ref: string; shadow_data: Record<string, unknown>;
  discrepancies: Array<Record<string, unknown>>; data_role: DataRole;
  created_at: Date; governance_action_ref: string | null;
}

export interface ProofRecord {
  proof_id: string; slice_ref: string; shadow_ref: string; test_name: string;
  test_result: 'pass' | 'fail' | 'blocked' | 'indeterminate';
  test_details: Record<string, unknown>; checked_at: Date;
}

export interface ExternalSession {
  session_id: string; platform_name: string;
  participants: Array<{ id: string; name: string; role: string; joined_at: string; }>;
  started_at: string; ended_at: string; duration_seconds: number;
  messages: Array<{ sender_id: string; content: string; sent_at: string; }>;
  topic: string; outcome: string | null; metadata: Record<string, unknown>;
}

export interface SessionSummarySlice {
  slice_id: string; source_session_ref: string; platform_name: string;
  participant_count: number; duration_seconds: number; topic: string;
  outcome: string | null; has_explicit_end: boolean;
}

export function sliceMatterRef(sliceId: string): string {
  return `bnk:accession:slice:${sliceId}`;
}
