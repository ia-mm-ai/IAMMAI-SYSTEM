/**
 * Accession Registry — Insert/query for accession-specific tables
 *
 * All insert functions require a pg.PoolClient (transaction context).
 * All query functions use the shared pool.
 * Reuses existing IAMMAI canonical tables via matter_ref for
 * governance, witness, and validation records.
 */

import type pg from 'pg';
import { query } from '../../../lib/db.js';
import { iammaiEventBus } from '../event-bus.js';
import type {
  ExternalSource,
  ExportedSlice,
  AccessionStateRecord,
  AccessionTransition,
  ShadowRecord,
  ProofRecord,
  AccessionStage,
} from './types.js';

// ============================================================================
// Insert Functions
// ============================================================================

export async function insertExternalSource(
  client: pg.PoolClient,
  source: ExternalSource
): Promise<ExternalSource> {
  await client.query(
    `INSERT INTO iammai_external_sources
     (source_id, source_name, source_system_ref, source_data, actor_ref, created_at)
     VALUES ($1, $2, $3, $4, $5, $6)`,
    [source.source_id, source.source_name, source.source_system_ref,
     JSON.stringify(source.source_data), source.actor_ref, source.created_at]
  );
  return source;
}

export async function insertExportedSlice(
  client: pg.PoolClient,
  slice: ExportedSlice
): Promise<ExportedSlice> {
  await client.query(
    `INSERT INTO iammai_exported_slices
     (slice_id, source_id, slice_name, slice_data, data_role, created_at)
     VALUES ($1, $2, $3, $4, $5, $6)`,
    [slice.slice_id, slice.source_id, slice.slice_name,
     JSON.stringify(slice.slice_data), slice.data_role, slice.created_at]
  );
  return slice;
}

export async function insertAccessionState(
  client: pg.PoolClient,
  record: AccessionStateRecord
): Promise<AccessionStateRecord> {
  await client.query(
    `INSERT INTO iammai_accession_state_records
     (state_id, slice_ref, accession_family, accession_stage, stage_outcome,
      recorded_at, predecessor_ref, related_governance_ref, related_validation_ref, related_witness_ref)
     VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10)`,
    [record.state_id, record.slice_ref, record.accession_family, record.accession_stage,
     JSON.stringify(record.stage_outcome), record.recorded_at, record.predecessor_ref,
     record.related_governance_ref, record.related_validation_ref, record.related_witness_ref]
  );
  iammaiEventBus.emitRecord('accession_stage_change', record as unknown as Record<string, unknown>);
  return record;
}

export async function insertAccessionTransition(
  client: pg.PoolClient,
  transition: AccessionTransition
): Promise<AccessionTransition> {
  await client.query(
    `INSERT INTO iammai_accession_transitions
     (transition_id, slice_ref, source_state_ref, target_state_ref, transition_type, occurred_at)
     VALUES ($1, $2, $3, $4, $5, $6)`,
    [transition.transition_id, transition.slice_ref, transition.source_state_ref,
     transition.target_state_ref, transition.transition_type, transition.occurred_at]
  );
  return transition;
}

export async function insertShadowRecord(
  client: pg.PoolClient,
  shadow: ShadowRecord
): Promise<ShadowRecord> {
  await client.query(
    `INSERT INTO iammai_shadow_records
     (shadow_id, slice_ref, shadow_data, discrepancies, data_role, created_at, governance_action_ref)
     VALUES ($1, $2, $3, $4, $5, $6, $7)`,
    [shadow.shadow_id, shadow.slice_ref, JSON.stringify(shadow.shadow_data),
     JSON.stringify(shadow.discrepancies), shadow.data_role, shadow.created_at,
     shadow.governance_action_ref]
  );
  return shadow;
}

export async function insertProofRecord(
  client: pg.PoolClient,
  proof: ProofRecord
): Promise<ProofRecord> {
  await client.query(
    `INSERT INTO iammai_proof_records
     (proof_id, slice_ref, shadow_ref, test_name, test_result, test_details, checked_at)
     VALUES ($1, $2, $3, $4, $5, $6, $7)`,
    [proof.proof_id, proof.slice_ref, proof.shadow_ref, proof.test_name,
     proof.test_result, JSON.stringify(proof.test_details), proof.checked_at]
  );
  return proof;
}

// ============================================================================
// Query Functions
// ============================================================================

export async function getExternalSources(): Promise<ExternalSource[]> {
  const result = await query<ExternalSource>(
    `SELECT * FROM iammai_external_sources ORDER BY created_at ASC`
  );
  return result.rows;
}

export async function getExternalSourceBySliceId(sliceId: string): Promise<ExternalSource | null> {
  const result = await query<ExternalSource>(
    `SELECT xs.*
       FROM iammai_external_sources xs
       JOIN iammai_exported_slices es ON es.source_id = xs.source_id
      WHERE es.slice_id = $1`,
    [sliceId]
  );
  return result.rows[0] ?? null;
}

export async function getExportedSlices(): Promise<ExportedSlice[]> {
  const result = await query<ExportedSlice>(
    `SELECT * FROM iammai_exported_slices ORDER BY created_at ASC`
  );
  return result.rows;
}

export async function getExportedSlice(sliceId: string): Promise<ExportedSlice | null> {
  const result = await query<ExportedSlice>(
    `SELECT * FROM iammai_exported_slices WHERE slice_id = $1`,
    [sliceId]
  );
  return result.rows[0] ?? null;
}

export async function getAccessionStatesBySlice(sliceRef: string): Promise<AccessionStateRecord[]> {
  const result = await query<AccessionStateRecord>(
    `SELECT * FROM iammai_accession_state_records WHERE slice_ref = $1 ORDER BY recorded_at ASC`,
    [sliceRef]
  );
  return result.rows;
}

export async function getCurrentAccessionStage(sliceRef: string): Promise<AccessionStage | null> {
  const result = await query<{ accession_stage: AccessionStage }>(
    `SELECT accession_stage FROM iammai_accession_state_records
     WHERE slice_ref = $1 ORDER BY recorded_at DESC LIMIT 1`,
    [sliceRef]
  );
  return result.rows[0]?.accession_stage ?? null;
}

export async function getAccessionTransitionsBySlice(sliceRef: string): Promise<AccessionTransition[]> {
  const result = await query<AccessionTransition>(
    `SELECT * FROM iammai_accession_transitions WHERE slice_ref = $1 ORDER BY occurred_at ASC`,
    [sliceRef]
  );
  return result.rows;
}

export async function getShadowRecordsBySlice(sliceRef: string): Promise<ShadowRecord[]> {
  const result = await query<ShadowRecord>(
    `SELECT * FROM iammai_shadow_records WHERE slice_ref = $1 ORDER BY created_at ASC`,
    [sliceRef]
  );
  return result.rows;
}

export async function getProofRecordsBySlice(sliceRef: string): Promise<ProofRecord[]> {
  const result = await query<ProofRecord>(
    `SELECT * FROM iammai_proof_records WHERE slice_ref = $1 ORDER BY checked_at ASC`,
    [sliceRef]
  );
  return result.rows;
}

/**
 * Get full accession context for a slice — all records needed for inspection.
 */
export async function loadAccessionContext(sliceRef: string) {
  const [slice, source, states, transitions, shadows, proofs] = await Promise.all([
    getExportedSlice(sliceRef),
    getExternalSourceBySliceId(sliceRef),
    getAccessionStatesBySlice(sliceRef),
    getAccessionTransitionsBySlice(sliceRef),
    getShadowRecordsBySlice(sliceRef),
    getProofRecordsBySlice(sliceRef),
  ]);
  return { slice, source, states, transitions, shadows, proofs };
}

/**
 * List slices with their current accession stage.
 */
export async function listSlicesWithStage(): Promise<Array<ExportedSlice & { current_stage: AccessionStage | null; source_name: string }>> {
  const result = await query<ExportedSlice & { current_stage: AccessionStage | null; source_name: string }>(
    `SELECT es.*,
       (SELECT asr.accession_stage FROM iammai_accession_state_records asr
        WHERE asr.slice_ref = es.slice_id ORDER BY asr.recorded_at DESC LIMIT 1) AS current_stage,
       xs.source_name
     FROM iammai_exported_slices es
     JOIN iammai_external_sources xs ON xs.source_id = es.source_id
     ORDER BY es.created_at ASC`
  );
  return result.rows;
}

// ============================================================================
// Reset (for seed management — truncates accession tables only)
// ============================================================================

export async function resetAccessionTables(client: pg.PoolClient): Promise<void> {
  // Must disable triggers temporarily for truncation
  await client.query('SET session_replication_role = replica');
  await client.query('TRUNCATE iammai_proof_records CASCADE');
  await client.query('TRUNCATE iammai_shadow_records CASCADE');
  await client.query('TRUNCATE iammai_accession_transitions CASCADE');
  await client.query('TRUNCATE iammai_accession_state_records CASCADE');
  await client.query('TRUNCATE iammai_exported_slices CASCADE');
  await client.query('TRUNCATE iammai_external_sources CASCADE');
  await client.query('SET session_replication_role = DEFAULT');
}
