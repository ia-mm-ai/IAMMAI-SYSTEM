/**
 * Accession Stage Engine — 7-Stage State Machine
 *
 * Manages valid transitions, family mapping, and ordering for the
 * accession sequence. Separate from the 9-phase canonical engine.
 */

import {
  VALID_ACCESSION_TRANSITIONS,
  ACCESSION_STAGE_FAMILY,
  ACCESSION_STAGES_IN_ORDER,
} from './types.js';
import type { AccessionStage } from './types.js';

export function isValidAccessionTransition(from: AccessionStage, to: AccessionStage): boolean {
  return VALID_ACCESSION_TRANSITIONS[from].includes(to);
}

export function getNextStage(current: AccessionStage): AccessionStage | null {
  const idx = ACCESSION_STAGES_IN_ORDER.indexOf(current);
  if (idx >= 5 || idx < 0) return null;
  return ACCESSION_STAGES_IN_ORDER[idx + 1]!;
}

export function getTransitionType(from: AccessionStage, to: AccessionStage): string {
  if (to === 'revoked') return 'to_revoked';
  return `${from}_to_${to}`;
}

export function isPreAdmission(stage: AccessionStage): boolean {
  return ACCESSION_STAGE_FAMILY[stage] === 'pre_admission';
}

export function isPostAdmission(stage: AccessionStage): boolean {
  return ACCESSION_STAGE_FAMILY[stage] === 'post_admission';
}
