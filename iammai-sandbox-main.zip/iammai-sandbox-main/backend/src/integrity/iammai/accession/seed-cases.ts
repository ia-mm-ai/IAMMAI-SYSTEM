/**
 * Seed Cases — Runs clean + messy cases through the accession coordinator
 */

import { v4 as uuidv4 } from 'uuid';
import type pg from 'pg';
import { generateCleanSession, generateMessySession, exportSlice } from './external-simulator.js';
import { seedSlice } from './accession-coordinator.js';
import { resetAccessionTables } from './accession-registry.js';
import { systemActorRef } from '../types.js';
import type { ExternalSource, ExportedSlice } from './types.js';

const SEED_ACTOR = systemActorRef('accession-seeder');

/**
 * Load both seed cases into the database.
 * Creates external sources, exported slices, and initial Contact state for each.
 */
export async function loadSeedCases(client: pg.PoolClient): Promise<{
  cleanSliceId: string;
  messySliceId: string;
}> {
  // Clean case: Momacka
  const cleanSession = generateCleanSession();
  const cleanSummary = exportSlice(cleanSession);
  const cleanSourceId = uuidv4();
  const cleanSource: ExternalSource = {
    source_id: cleanSourceId,
    source_name: 'Momacka',
    source_system_ref: `ext:momacka:${cleanSession.session_id}`,
    source_data: cleanSession as unknown as Record<string, unknown>,
    actor_ref: SEED_ACTOR,
    created_at: new Date(),
  };
  const cleanSlice: ExportedSlice = {
    slice_id: cleanSummary.slice_id,
    source_id: cleanSourceId,
    slice_name: `Momacka — ${cleanSession.topic}`,
    slice_data: cleanSummary as unknown as Record<string, unknown>,
    data_role: 'exported',
    created_at: new Date(),
  };
  await seedSlice(client, cleanSource, cleanSlice, cleanSummary, SEED_ACTOR);

  // Messy case: Seen
  const messySession = generateMessySession();
  const messySummary = exportSlice(messySession);
  const messySourceId = uuidv4();
  const messySource: ExternalSource = {
    source_id: messySourceId,
    source_name: 'Seen',
    source_system_ref: `ext:seen:${messySession.session_id}`,
    source_data: messySession as unknown as Record<string, unknown>,
    actor_ref: SEED_ACTOR,
    created_at: new Date(),
  };
  const messySlice: ExportedSlice = {
    slice_id: messySummary.slice_id,
    source_id: messySourceId,
    slice_name: 'Seen — (left on seen)',
    slice_data: messySummary as unknown as Record<string, unknown>,
    data_role: 'exported',
    created_at: new Date(),
  };
  await seedSlice(client, messySource, messySlice, messySummary, SEED_ACTOR);

  return {
    cleanSliceId: cleanSummary.slice_id,
    messySliceId: messySummary.slice_id,
  };
}

/**
 * Reset all accession tables and reload seeds.
 */
export async function resetAndReseed(client: pg.PoolClient): Promise<{
  cleanSliceId: string;
  messySliceId: string;
}> {
  await resetAccessionTables(client);
  return loadSeedCases(client);
}
