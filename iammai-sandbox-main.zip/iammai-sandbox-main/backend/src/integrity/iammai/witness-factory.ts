/**
 * IAMMAI Witness Factory — Contact Preservation with Mandatory Non-Claims
 *
 * Builds IAMMAI-compliant witness artifacts. Every witness MUST include
 * all 5 non-claims. Witness preserves contact and trace — it does NOT
 * become semantic source, governance authority, or authorship claim.
 */

import { createWitnessArtifact } from './record-factory.js';
import { insertWitnessArtifact } from './registry.js';
import type pg from 'pg';
import type { WitnessType, IammaiWitnessArtifact } from './types.js';

/**
 * Build an IAMMAI-compliant witness artifact.
 * Non-claims are automatically included — they cannot be omitted.
 */
export function buildIammaiWitness(params: {
  witness_type: WitnessType;
  target_ref: string;
  claims: string[];
  actor_ref?: string | null;
  surface_ref?: string | null;
}): IammaiWitnessArtifact {
  return createWitnessArtifact(params);
}

/**
 * Build and persist an IAMMAI witness artifact in a single call.
 */
export async function emitIammaiWitness(
  client: pg.PoolClient,
  params: {
    witness_type: WitnessType;
    target_ref: string;
    claims: string[];
    actor_ref?: string | null;
    surface_ref?: string | null;
  }
): Promise<IammaiWitnessArtifact> {
  const artifact = buildIammaiWitness(params);
  await insertWitnessArtifact(client, artifact);
  return artifact;
}
