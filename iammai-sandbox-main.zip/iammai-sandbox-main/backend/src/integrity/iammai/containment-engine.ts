/**
 * IAMMAI Containment Engine — Orthogonal HOLD / RELEASE
 *
 * Containment is an orthogonal mechanism: it does NOT change phase identity.
 * A held state remains in its current phase — it is simply frozen from
 * participating in transitions or resolution until released.
 *
 * Constraints:
 * - HOLD requires a governance action (governor, not validator)
 * - RELEASE requires a governance action
 * - A state can only be held once at a time (no stacking)
 * - Held states cannot be resolved (resolution engine must check)
 * - Held states cannot transition to next phase
 * - Containment does NOT alter state_family or state_type
 */

import type pg from 'pg';
import type {
  IammaiContainmentRecord,
  IammaiGovernanceAction,
  IammaiStateRecord,
} from './types.js';
import { createContainmentRecord } from './record-factory.js';
import { insertContainmentRecord, getContainmentRecordsByMatter, getStateRecordsByMatter } from './registry.js';
import { recordGovernanceAction } from './governor.js';
import type { GovernanceActionParams } from './governor.js';

export interface HoldParams {
  matter_ref: string;
  target_state_ref: string;
  actor_ref: string;
  reason: string;
  legitimacy_basis_ref: string;
  authority_class: 'SYSTEM' | 'OPERATOR' | 'DELEGATED';
}

export interface ReleaseParams {
  matter_ref: string;
  target_state_ref: string;
  actor_ref: string;
  reason: string;
  legitimacy_basis_ref: string;
  authority_class: 'SYSTEM' | 'OPERATOR' | 'DELEGATED';
}

export interface ContainmentResult {
  containmentRecord: IammaiContainmentRecord;
  governanceAction: IammaiGovernanceAction;
}

/**
 * Check if a specific state is currently held.
 * A state is held if the latest containment action for it is HOLD.
 */
export function isStateHeld(
  containmentRecords: IammaiContainmentRecord[],
  targetStateRef: string
): boolean {
  const stateContainments = containmentRecords
    .filter(r => r.target_state_ref === targetStateRef)
    .sort((a, b) => a.recorded_at.getTime() - b.recorded_at.getTime());

  if (stateContainments.length === 0) return false;
  return stateContainments[stateContainments.length - 1].action === 'HOLD';
}

/**
 * Check if the current (latest) state of a matter is held.
 */
export async function isCurrentStateHeld(matterRef: string): Promise<boolean> {
  const [states, containments] = await Promise.all([
    getStateRecordsByMatter(matterRef),
    getContainmentRecordsByMatter(matterRef),
  ]);

  if (states.length === 0) return false;
  const currentState = states[states.length - 1];
  return isStateHeld(containments, currentState.state_id);
}

/**
 * Apply a HOLD to a state. Freezes the state from transitions/resolution.
 *
 * @throws Error if the state is already held
 * @throws Error if the target state does not exist in the matter
 */
export async function hold(
  client: pg.PoolClient,
  params: HoldParams
): Promise<ContainmentResult> {
  const { matter_ref, target_state_ref, actor_ref, reason, legitimacy_basis_ref, authority_class } = params;

  // Verify target state exists
  const stateResult = await client.query<{ state_id: string }>(
    'SELECT state_id FROM iammai_state_records WHERE state_id = $1 AND matter_ref = $2',
    [target_state_ref, matter_ref]
  );
  if (stateResult.rows.length === 0) {
    throw new Error('Target state ' + target_state_ref + ' not found in matter ' + matter_ref);
  }

  // Check not already held
  const containmentResult = await client.query<{ action: string; recorded_at: Date }>(
    'SELECT action, recorded_at FROM iammai_containment_records WHERE target_state_ref = $1 ORDER BY recorded_at DESC LIMIT 1',
    [target_state_ref]
  );
  if (containmentResult.rows.length > 0 && containmentResult.rows[0].action === 'HOLD') {
    throw new Error('State ' + target_state_ref + ' is already held');
  }

  // Record governance action
  const governanceAction = await recordGovernanceAction(client, {
    action_type: 'hold',
    authority_class,
    actor_ref,
    legitimacy_basis_ref,
    matter_ref,
    target_state_ref,
  });

  // Create containment record
  const containmentRecord = createContainmentRecord({
    matter_ref,
    target_state_ref,
    action: 'HOLD',
    actor_ref,
    reason,
    governance_action_ref: governanceAction.governance_action_id,
  });
  await insertContainmentRecord(client, containmentRecord);

  return { containmentRecord, governanceAction };
}

/**
 * Release a held state, allowing transitions/resolution to resume.
 *
 * @throws Error if the state is not currently held
 * @throws Error if the target state does not exist in the matter
 */
export async function release(
  client: pg.PoolClient,
  params: ReleaseParams
): Promise<ContainmentResult> {
  const { matter_ref, target_state_ref, actor_ref, reason, legitimacy_basis_ref, authority_class } = params;

  // Verify target state exists
  const stateResult = await client.query<{ state_id: string }>(
    'SELECT state_id FROM iammai_state_records WHERE state_id = $1 AND matter_ref = $2',
    [target_state_ref, matter_ref]
  );
  if (stateResult.rows.length === 0) {
    throw new Error('Target state ' + target_state_ref + ' not found in matter ' + matter_ref);
  }

  // Check currently held
  const containmentResult = await client.query<{ action: string; recorded_at: Date }>(
    'SELECT action, recorded_at FROM iammai_containment_records WHERE target_state_ref = $1 ORDER BY recorded_at DESC LIMIT 1',
    [target_state_ref]
  );
  if (containmentResult.rows.length === 0 || containmentResult.rows[0].action !== 'HOLD') {
    throw new Error('State ' + target_state_ref + ' is not currently held');
  }

  // Record governance action
  const governanceAction = await recordGovernanceAction(client, {
    action_type: 'release',
    authority_class,
    actor_ref,
    legitimacy_basis_ref,
    matter_ref,
    target_state_ref,
  });

  // Create containment record
  const containmentRecord = createContainmentRecord({
    matter_ref,
    target_state_ref,
    action: 'RELEASE',
    actor_ref,
    reason,
    governance_action_ref: governanceAction.governance_action_id,
  });
  await insertContainmentRecord(client, containmentRecord);

  return { containmentRecord, governanceAction };
}

/**
 * Get the containment history for a matter.
 */
export async function getContainmentHistory(
  matterRef: string
): Promise<IammaiContainmentRecord[]> {
  return getContainmentRecordsByMatter(matterRef);
}

/**
 * Get all currently held state refs for a matter.
 */
export function getHeldStateRefs(
  containmentRecords: IammaiContainmentRecord[]
): string[] {
  // Group by target_state_ref, check latest action
  const latestByState = new Map<string, IammaiContainmentRecord>();
  for (const record of containmentRecords) {
    const existing = latestByState.get(record.target_state_ref);
    if (!existing || record.recorded_at.getTime() > existing.recorded_at.getTime()) {
      latestByState.set(record.target_state_ref, record);
    }
  }

  return Array.from(latestByState.entries())
    .filter(([_, record]) => record.action === 'HOLD')
    .map(([stateRef]) => stateRef);
}
