/**
 * IAMMAI Coordinator — Orchestrates the canonical processing sequence
 *
 * Strict sequence: Interface → Validator → Witness → Governor → StateEngine → Registry
 *
 * The coordinator is the ONLY entry point for IAMMAI operations.
 * It enforces that:
 * 1. Validation happens BEFORE governance (validator checks, governor decides)
 * 2. Witness artifacts are emitted for all significant operations
 * 3. All records land in the same transaction
 * 4. Contribution roles are recorded for all actors
 */

import type pg from 'pg';
import type {
  IammaiPhase,
  IammaiStateRecord,
  IammaiTransitionRecord,
  IammaiGovernanceAction,
  IammaiWitnessArtifact,
  IammaiValidationArtifact,
  IammaiContributionRecord,
  IammaiContainmentRecord,
  ResolutionType,
  AuthorityClass,
  ContributionRole,
} from './types.js';
import { matterRef, actorRef, systemActorRef } from './types.js';
import { advancePhase, advancePhases } from './phase-engine.js';
import { recordGovernanceAction } from './governor.js';
import { emitIammaiWitness } from './witness-factory.js';
import { validateTransition, validateResolution } from './validator.js';
import { recordContributions } from './contribution-tracker.js';
import { resolve } from './resolution-engine.js';
import { hold, release } from './containment-engine.js';
import {
  getStateRecordsByMatter,
  getContainmentRecordsByMatter,
  getTransitionRecordsByMatter,
} from './registry.js';

// ============================================================================
// Coordination Results
// ============================================================================

export interface PhaseAdvanceResult {
  stateRecord: IammaiStateRecord;
  transitionRecord: IammaiTransitionRecord | null;
  governanceAction: IammaiGovernanceAction;
  validationArtifact: IammaiValidationArtifact;
  witnessArtifact: IammaiWitnessArtifact;
  contributionRecords: IammaiContributionRecord[];
}

export interface SessionCreateResult {
  phaseResults: PhaseAdvanceResult[];
}

export interface SessionStartResult {
  phaseResults: PhaseAdvanceResult[];
}

export interface SessionEndResult {
  governanceAction: IammaiGovernanceAction;
  transitionRecord: IammaiTransitionRecord;
  witnessArtifact: IammaiWitnessArtifact;
}

// ============================================================================
// Coordination Operations
// ============================================================================

/**
 * Coordinate session creation through IAMMAI phases: signal + acceptance.
 * Maps to: POST /admin/sessions
 */
export async function coordinateSessionCreate(
  client: pg.PoolClient,
  params: {
    sessionId: string;
    adminId: string;
  }
): Promise<SessionCreateResult> {
  const matter = matterRef(params.sessionId);
  const adminActor = actorRef(params.adminId);
  const systemActor = systemActorRef('coordinator');
  const phases: IammaiPhase[] = ['signal', 'acceptance'];
  const results: PhaseAdvanceResult[] = [];

  for (const phase of phases) {
    const result = await coordinatePhaseAdvance(client, {
      matter_ref: matter,
      target_phase: phase,
      actor_ref: adminActor,
      authority_class: 'OPERATOR',
      legitimacy_basis_ref: 'session_creation',
      contributions: [
        { matter_ref: matter, actor_ref: adminActor, role: 'ORIGIN' },
      ],
    });
    results.push(result);
  }

  return { phaseResults: results };
}

/**
 * Coordinate session claim through IAMMAI phase: scope.
 * Maps to: POST /sessions/:id/claim
 */
export async function coordinateSessionClaim(
  client: pg.PoolClient,
  params: {
    sessionId: string;
    adminId: string;
  }
): Promise<PhaseAdvanceResult> {
  const matter = matterRef(params.sessionId);
  const adminActor = actorRef(params.adminId);

  return coordinatePhaseAdvance(client, {
    matter_ref: matter,
    target_phase: 'scope',
    actor_ref: adminActor,
    authority_class: 'OPERATOR',
    legitimacy_basis_ref: 'session_claim',
    contributions: [
      { matter_ref: matter, actor_ref: adminActor, role: 'ELICITATION' },
    ],
  });
}

/**
 * Coordinate session join through IAMMAI phase: presence.
 * Maps to: POST /sessions/:id/join
 */
export async function coordinateSessionJoin(
  client: pg.PoolClient,
  params: {
    sessionId: string;
    participantRef: string;
  }
): Promise<PhaseAdvanceResult> {
  const matter = matterRef(params.sessionId);
  const systemActor = systemActorRef('coordinator');

  return coordinatePhaseAdvance(client, {
    matter_ref: matter,
    target_phase: 'presence',
    actor_ref: systemActor,
    authority_class: 'SYSTEM',
    legitimacy_basis_ref: 'participant_join',
    contributions: [],
  });
}

/**
 * Coordinate session start through IAMMAI phases: threshold + truth.
 * Maps to: POST /admin/sessions/:id/start
 */
export async function coordinateSessionStart(
  client: pg.PoolClient,
  params: {
    sessionId: string;
    adminId: string;
  }
): Promise<SessionStartResult> {
  const matter = matterRef(params.sessionId);
  const adminActor = actorRef(params.adminId);
  const phases: IammaiPhase[] = ['threshold', 'truth'];
  const results: PhaseAdvanceResult[] = [];

  for (const phase of phases) {
    const result = await coordinatePhaseAdvance(client, {
      matter_ref: matter,
      target_phase: phase,
      actor_ref: adminActor,
      authority_class: 'OPERATOR',
      legitimacy_basis_ref: 'session_start',
      contributions: [
        { matter_ref: matter, actor_ref: adminActor, role: 'AUTHORIZATION' },
      ],
    });
    results.push(result);
  }

  return { phaseResults: results };
}

/**
 * Coordinate session start with phase bridging — stops at threshold (preparation regime).
 * The threshold→truth boundary crossing is handled separately via coordinateThresholdToTruth().
 *
 * Maps to: POST /admin/sessions/:id/start
 */
export async function coordinateSessionStartFull(
  client: pg.PoolClient,
  params: {
    sessionId: string;
    adminId: string;
  }
): Promise<SessionStartResult> {
  const matter = matterRef(params.sessionId);
  const adminActor = actorRef(params.adminId);
  const systemActor = systemActorRef('coordinator');
  // Stop at threshold — truth requires explicit admin confirmation via coordinateThresholdToTruth()
  const phases: IammaiPhase[] = ['scope', 'presence', 'threshold'];
  const results: PhaseAdvanceResult[] = [];

  for (const phase of phases) {
    const isBridge = phase === 'scope' || phase === 'presence';
    const result = await coordinatePhaseAdvance(client, {
      matter_ref: matter,
      target_phase: phase,
      actor_ref: isBridge ? systemActor : adminActor,
      authority_class: isBridge ? 'SYSTEM' : 'OPERATOR',
      legitimacy_basis_ref: isBridge ? 'phase_bridge' : 'session_start',
      contributions: isBridge ? [] : [
        { matter_ref: matter, actor_ref: adminActor, role: 'AUTHORIZATION' },
      ],
    });
    results.push(result);
  }

  return { phaseResults: results };
}

/**
 * Coordinate the explicit threshold→truth boundary crossing.
 *
 * This is the most critical transition in the IAMMAI protocol — it moves
 * the matter from preparation regime to standing-state regime.
 * Requires explicit admin acknowledgment via POST /admin/sessions/:id/confirm-truth.
 *
 * Maps to: POST /admin/sessions/:id/confirm-truth
 */
export async function coordinateThresholdToTruth(
  client: pg.PoolClient,
  params: {
    sessionId: string;
    adminId: string;
    legitimacy_basis_ref?: string;
  }
): Promise<PhaseAdvanceResult> {
  const matter = matterRef(params.sessionId);
  const adminActor = actorRef(params.adminId);

  return coordinatePhaseAdvance(client, {
    matter_ref: matter,
    target_phase: 'truth',
    actor_ref: adminActor,
    authority_class: 'OPERATOR',
    legitimacy_basis_ref: params.legitimacy_basis_ref ?? 'truth_formation_confirmed',
    contributions: [
      { matter_ref: matter, actor_ref: adminActor, role: 'AUTHORIZATION' },
    ],
  });
}

/**
 * Coordinate message exchange through IAMMAI phase: continuity.
 * Maps to: WebSocket message (first message triggers continuity phase)
 */
export async function coordinateMessageExchange(
  client: pg.PoolClient,
  params: {
    sessionId: string;
    aiModel?: string;
  }
): Promise<PhaseAdvanceResult> {
  const matter = matterRef(params.sessionId);
  const systemActor = systemActorRef('message-handler');

  const contributions: Array<{ matter_ref: string; actor_ref: string; role: ContributionRole }> = [];
  if (params.aiModel) {
    const aiActor = `bnk:agent:${params.aiModel}`;
    contributions.push(
      { matter_ref: matter, actor_ref: aiActor, role: 'FORMALIZATION' },
      { matter_ref: matter, actor_ref: aiActor, role: 'RENDERING' },
    );
  }

  return coordinatePhaseAdvance(client, {
    matter_ref: matter,
    target_phase: 'continuity',
    actor_ref: systemActor,
    authority_class: 'SYSTEM',
    legitimacy_basis_ref: 'message_exchange',
    contributions,
  });
}

/**
 * Coordinate session end through IAMMAI phases: decision + consequence + FINALIZE.
 * Maps to: POST /admin/sessions/:id/end
 */
export async function coordinateSessionEnd(
  client: pg.PoolClient,
  params: {
    sessionId: string;
    adminId: string;
  }
): Promise<SessionEndResult> {
  const matter = matterRef(params.sessionId);
  const adminActor = actorRef(params.adminId);

  // Advance through decision + consequence
  for (const phase of ['decision', 'consequence'] as IammaiPhase[]) {
    await coordinatePhaseAdvance(client, {
      matter_ref: matter,
      target_phase: phase,
      actor_ref: adminActor,
      authority_class: 'OPERATOR',
      legitimacy_basis_ref: 'session_end',
      contributions: [
        { matter_ref: matter, actor_ref: adminActor, role: 'AUTHORIZATION' },
      ],
    });
  }

  // Resolve with FINALIZE
  const resolutionResult = await resolve(client, {
    matter_ref: matter,
    resolution_type: 'FINALIZE',
    actor_ref: adminActor,
    legitimacy_basis_ref: 'session_end',
    authority_class: 'OPERATOR',
  });

  // Emit witness for resolution
  const witnessArtifact = await emitIammaiWitness(client, {
    witness_type: 'transition',
    target_ref: matter,
    claims: [`matter resolved via FINALIZE`],
    actor_ref: adminActor,
  });

  return {
    governanceAction: resolutionResult.governanceAction,
    transitionRecord: resolutionResult.transitionRecord,
    witnessArtifact,
  };
}

// ============================================================================
// Internal: Core phase advance coordination
// ============================================================================

async function coordinatePhaseAdvance(
  client: pg.PoolClient,
  params: {
    matter_ref: string;
    target_phase: IammaiPhase;
    actor_ref: string;
    authority_class: AuthorityClass;
    legitimacy_basis_ref: string;
    contributions: Array<{ matter_ref: string; actor_ref: string; role: ContributionRole }>;
  }
): Promise<PhaseAdvanceResult> {
  const {
    matter_ref, target_phase, actor_ref,
    authority_class, legitimacy_basis_ref, contributions,
  } = params;

  // 1. Get current state + containment (use client to see uncommitted writes)
  const stateRecords = await getStateRecordsByMatter(matter_ref, client);
  const containmentRecords = await getContainmentRecordsByMatter(matter_ref, client);
  const currentState = stateRecords.length > 0 ? (stateRecords[stateRecords.length - 1] ?? null) : null;

  // 2. VALIDATE (validator checks — not governor)
  const validationArtifact = await validateTransition(client, {
    matter_ref,
    current_state: currentState,
    target_phase,
    containment_records: containmentRecords,
    actor_ref,
  });

  if (validationArtifact.outcome === 'fail') {
    throw new Error(
      `Validation failed for ${matter_ref} → ${target_phase}: ${validationArtifact.reason_refs?.join('; ')}`
    );
  }
  if (validationArtifact.outcome === 'blocked') {
    throw new Error(
      `Transition blocked for ${matter_ref} → ${target_phase}: ${validationArtifact.reason_refs?.join('; ')}`
    );
  }

  // 3. GOVERN (governor authorizes)
  const governanceAction = await recordGovernanceAction(client, {
    action_type: 'authorize',
    authority_class,
    actor_ref,
    legitimacy_basis_ref,
    matter_ref,
  });

  // 4. STATE ENGINE (advance phase)
  const { stateRecord, transitionRecord } = await advancePhase(
    client,
    matter_ref,
    target_phase,
    governanceAction.governance_action_id
  );

  // 5. WITNESS (emit witness artifact)
  const witnessArtifact = await emitIammaiWitness(client, {
    witness_type: 'transition',
    target_ref: stateRecord.state_id,
    claims: [`Phase advanced to ${target_phase}`],
    actor_ref,
  });

  // 6. CONTRIBUTION ROLES
  let contributionRecords: IammaiContributionRecord[] = [];
  if (contributions.length > 0) {
    contributionRecords = await recordContributions(client, contributions);
  }

  return {
    stateRecord,
    transitionRecord,
    governanceAction,
    validationArtifact,
    witnessArtifact,
    contributionRecords,
  };
}
