/**
 * IAMMAI Registry — Append-only canonical record persistence
 *
 * All insert functions require a pg.PoolClient (transaction context).
 * All query functions use the shared pool.
 */

import type pg from 'pg';
import { query } from '../../lib/db.js';
import { iammaiEventBus } from './event-bus.js';
import type {
  IammaiStateRecord,
  IammaiTransitionRecord,
  IammaiGovernanceAction,
  IammaiWitnessArtifact,
  IammaiValidationArtifact,
  IammaiContributionRecord,
  IammaiContainmentRecord,
  IammaiEvaluationContext,
  StateFamily,
  IammaiPhase,
} from './types.js';

// ============================================================================
// Row types (snake_case from DB)
// ============================================================================

interface StateRecordRow {
  state_id: string;
  matter_ref: string;
  state_family: StateFamily;
  state_type: IammaiPhase;
  recorded_at: Date;
  predecessor_ref: string | null;
  containment_ref: string | null;
  related_transition_ref: string | null;
  related_governance_ref: string | null;
  related_validation_ref: string | null;
  related_witness_ref: string | null;
}

// ============================================================================
// Insert Functions
// ============================================================================

export async function insertStateRecord(
  client: pg.PoolClient,
  record: IammaiStateRecord
): Promise<IammaiStateRecord> {
  await client.query(
    `INSERT INTO iammai_state_records
     (state_id, matter_ref, state_family, state_type, recorded_at,
      predecessor_ref, containment_ref, related_transition_ref,
      related_governance_ref, related_validation_ref, related_witness_ref)
     VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11)`,
    [
      record.state_id, record.matter_ref, record.state_family, record.state_type,
      record.recorded_at, record.predecessor_ref, record.containment_ref,
      record.related_transition_ref, record.related_governance_ref,
      record.related_validation_ref, record.related_witness_ref,
    ]
  );
  iammaiEventBus.emitRecord('phase_change', record as unknown as Record<string, unknown>);
  return record;
}

export async function insertTransitionRecord(
  client: pg.PoolClient,
  record: IammaiTransitionRecord
): Promise<IammaiTransitionRecord> {
  await client.query(
    `INSERT INTO iammai_transition_records
     (transition_id, matter_ref, source_ref, target_ref, transition_type,
      occurred_at, resolution_type, predecessor_ref)
     VALUES ($1, $2, $3, $4, $5, $6, $7, $8)`,
    [
      record.transition_id, record.matter_ref, record.source_ref,
      record.target_ref, record.transition_type, record.occurred_at,
      record.resolution_type, record.predecessor_ref,
    ]
  );
  iammaiEventBus.emitRecord('transition_occurred', record as unknown as Record<string, unknown>);
  return record;
}

export async function insertGovernanceAction(
  client: pg.PoolClient,
  record: IammaiGovernanceAction
): Promise<IammaiGovernanceAction> {
  await client.query(
    `INSERT INTO iammai_governance_actions
     (governance_action_id, action_type, authority_class, actor_ref,
      legitimacy_basis_ref, matter_ref, acted_at, delegated_from_ref,
      target_state_ref, target_transition_ref, contribution_role_map_ref)
     VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11)`,
    [
      record.governance_action_id, record.action_type, record.authority_class,
      record.actor_ref, record.legitimacy_basis_ref, record.matter_ref,
      record.acted_at, record.delegated_from_ref, record.target_state_ref,
      record.target_transition_ref, record.contribution_role_map_ref,
    ]
  );
  iammaiEventBus.emitRecord('governance_action', record as unknown as Record<string, unknown>);
  return record;
}

export async function insertWitnessArtifact(
  client: pg.PoolClient,
  record: IammaiWitnessArtifact
): Promise<IammaiWitnessArtifact> {
  await client.query(
    `INSERT INTO iammai_witness_artifacts
     (witness_id, witness_type, target_ref, observed_at, claims, non_claims,
      actor_ref, surface_ref)
     VALUES ($1, $2, $3, $4, $5, $6, $7, $8)`,
    [
      record.witness_id, record.witness_type, record.target_ref,
      record.observed_at, JSON.stringify(record.claims),
      JSON.stringify(record.non_claims), record.actor_ref, record.surface_ref,
    ]
  );
  iammaiEventBus.emitRecord('witness_emitted', record as unknown as Record<string, unknown>);
  return record;
}

export async function insertValidationArtifact(
  client: pg.PoolClient,
  record: IammaiValidationArtifact
): Promise<IammaiValidationArtifact> {
  await client.query(
    `INSERT INTO iammai_validation_artifacts
     (validation_id, validation_type, target_ref, condition_set_ref,
      outcome, checked_at, reason_refs, actor_ref)
     VALUES ($1, $2, $3, $4, $5, $6, $7, $8)`,
    [
      record.validation_id, record.validation_type, record.target_ref,
      record.condition_set_ref, record.outcome, record.checked_at,
      record.reason_refs ? JSON.stringify(record.reason_refs) : null,
      record.actor_ref,
    ]
  );
  iammaiEventBus.emitRecord('validation_completed', record as unknown as Record<string, unknown>);
  return record;
}

export async function insertContributionRecord(
  client: pg.PoolClient,
  record: IammaiContributionRecord
): Promise<IammaiContributionRecord> {
  await client.query(
    `INSERT INTO iammai_contribution_records
     (contribution_id, matter_ref, actor_ref, role, recorded_at, context_ref)
     VALUES ($1, $2, $3, $4, $5, $6)
     ON CONFLICT (matter_ref, actor_ref, role) DO NOTHING`,
    [
      record.contribution_id, record.matter_ref, record.actor_ref,
      record.role, record.recorded_at, record.context_ref,
    ]
  );
  iammaiEventBus.emitRecord('contribution_recorded', record as unknown as Record<string, unknown>);
  return record;
}

export async function insertContainmentRecord(
  client: pg.PoolClient,
  record: IammaiContainmentRecord
): Promise<IammaiContainmentRecord> {
  await client.query(
    `INSERT INTO iammai_containment_records
     (containment_id, matter_ref, target_state_ref, action, actor_ref,
      reason, recorded_at, governance_action_ref)
     VALUES ($1, $2, $3, $4, $5, $6, $7, $8)`,
    [
      record.containment_id, record.matter_ref, record.target_state_ref,
      record.action, record.actor_ref, record.reason, record.recorded_at,
      record.governance_action_ref,
    ]
  );
  iammaiEventBus.emitRecord('containment_change', record as unknown as Record<string, unknown>);
  return record;
}

// ============================================================================
// Query Functions
// ============================================================================

export async function getStateRecordsByMatter(matterRef: string, client?: pg.PoolClient): Promise<IammaiStateRecord[]> {
  const q = client ?? { query: (sql: string, params: unknown[]) => query<StateRecordRow>(sql, params) };
  const result = await q.query(
    'SELECT * FROM iammai_state_records WHERE matter_ref = $1 ORDER BY recorded_at ASC',
    [matterRef]
  );
  return result.rows;
}

export async function getTransitionRecordsByMatter(matterRef: string): Promise<IammaiTransitionRecord[]> {
  const result = await query<IammaiTransitionRecord>(
    'SELECT * FROM iammai_transition_records WHERE matter_ref = $1 ORDER BY occurred_at ASC',
    [matterRef]
  );
  return result.rows;
}

export async function getGovernanceActionsByMatter(matterRef: string): Promise<IammaiGovernanceAction[]> {
  const result = await query<IammaiGovernanceAction>(
    'SELECT * FROM iammai_governance_actions WHERE matter_ref = $1 ORDER BY acted_at ASC',
    [matterRef]
  );
  return result.rows;
}

export async function getWitnessArtifactsByTarget(targetRef: string): Promise<IammaiWitnessArtifact[]> {
  const result = await query<IammaiWitnessArtifact>(
    'SELECT * FROM iammai_witness_artifacts WHERE target_ref = $1 ORDER BY observed_at ASC',
    [targetRef]
  );
  return result.rows;
}

export async function getValidationArtifactsByTarget(targetRef: string): Promise<IammaiValidationArtifact[]> {
  const result = await query<IammaiValidationArtifact>(
    'SELECT * FROM iammai_validation_artifacts WHERE target_ref = $1 ORDER BY checked_at ASC',
    [targetRef]
  );
  return result.rows;
}

export async function getContributionRecordsByMatter(matterRef: string): Promise<IammaiContributionRecord[]> {
  const result = await query<IammaiContributionRecord>(
    'SELECT * FROM iammai_contribution_records WHERE matter_ref = $1 ORDER BY recorded_at ASC',
    [matterRef]
  );
  return result.rows;
}

export async function getContainmentRecordsByMatter(matterRef: string, client?: pg.PoolClient): Promise<IammaiContainmentRecord[]> {
  const q = client ?? { query: (sql: string, params: unknown[]) => query<IammaiContainmentRecord>(sql, params) };
  const result = await q.query(
    'SELECT * FROM iammai_containment_records WHERE matter_ref = $1 ORDER BY recorded_at ASC',
    [matterRef]
  );
  return result.rows;
}

// ============================================================================
// List Tracked Matters
// ============================================================================

interface TrackedMatterRow {
  matter_ref: string;
  latest_phase: IammaiPhase;
  state_family: StateFamily;
  state_count: string; // COUNT returns string from pg
  latest_recorded_at: Date;
}

export async function listTrackedMatters(): Promise<Array<{
  matter_ref: string;
  latest_phase: IammaiPhase;
  state_family: StateFamily;
  state_count: number;
  latest_recorded_at: Date;
}>> {
  const result = await query<TrackedMatterRow>(
    `SELECT DISTINCT ON (s1.matter_ref)
       s1.matter_ref,
       s1.state_type AS latest_phase,
       s1.state_family,
       (SELECT COUNT(*) FROM iammai_state_records s2 WHERE s2.matter_ref = s1.matter_ref) AS state_count,
       s1.recorded_at AS latest_recorded_at
     FROM iammai_state_records s1
     ORDER BY s1.matter_ref, s1.recorded_at DESC`
  );
  return result.rows.map(row => ({
    ...row,
    state_count: Number(row.state_count),
  }));
}

// ============================================================================
// Load Full IAMMAI Context (for evaluation)
// ============================================================================

export async function loadIammaiContext(matterRef: string): Promise<IammaiEvaluationContext> {
  const [
    stateRecords,
    transitionRecords,
    governanceActions,
    contributionRecords,
    containmentRecords,
  ] = await Promise.all([
    getStateRecordsByMatter(matterRef),
    getTransitionRecordsByMatter(matterRef),
    getGovernanceActionsByMatter(matterRef),
    getContributionRecordsByMatter(matterRef),
    getContainmentRecordsByMatter(matterRef),
  ]);

  // Witness and validation artifacts are queried by target_ref (matter_ref)
  const [witnessArtifacts, validationArtifacts] = await Promise.all([
    getWitnessArtifactsByTarget(matterRef),
    getValidationArtifactsByTarget(matterRef),
  ]);

  return {
    stateRecords,
    transitionRecords,
    governanceActions,
    witnessArtifacts,
    validationArtifacts,
    contributionRecords,
    containmentRecords,
  };
}
