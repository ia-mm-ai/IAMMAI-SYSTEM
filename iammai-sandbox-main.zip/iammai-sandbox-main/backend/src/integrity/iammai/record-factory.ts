/**
 * IAMMAI Record Factory
 *
 * Constructs canonical records with UUID generation and schema validation.
 * Every record is validated before being returned.
 */

import { v4 as uuidv4 } from 'uuid';
import {
  validateStateRecord,
  validateTransitionRecord,
  validateGovernanceAction,
  validateWitnessArtifact,
  validateValidationArtifact,
  validateContributionRecord,
  validateContainmentRecord,
} from './schema-validator.js';
import { PHASE_FAMILY, MANDATORY_NON_CLAIMS } from './types.js';
import type {
  IammaiPhase,
  TransitionType,
  ResolutionType,
  GovernanceActionType,
  AuthorityClass,
  WitnessType,
  ValidationType,
  ValidationOutcome,
  ContributionRole,
  IammaiStateRecord,
  IammaiTransitionRecord,
  IammaiGovernanceAction,
  IammaiWitnessArtifact,
  IammaiValidationArtifact,
  IammaiContributionRecord,
  IammaiContainmentRecord,
} from './types.js';

export function createStateRecord(params: {
  matter_ref: string;
  state_type: IammaiPhase;
  predecessor_ref?: string | null;
  containment_ref?: string | null;
  related_transition_ref?: string | null;
  related_governance_ref?: string | null;
  related_validation_ref?: string | null;
  related_witness_ref?: string | null;
}): IammaiStateRecord {
  const record: IammaiStateRecord = {
    state_id: uuidv4(),
    matter_ref: params.matter_ref,
    state_family: PHASE_FAMILY[params.state_type],
    state_type: params.state_type,
    recorded_at: new Date(),
    predecessor_ref: params.predecessor_ref ?? null,
    containment_ref: params.containment_ref ?? null,
    related_transition_ref: params.related_transition_ref ?? null,
    related_governance_ref: params.related_governance_ref ?? null,
    related_validation_ref: params.related_validation_ref ?? null,
    related_witness_ref: params.related_witness_ref ?? null,
  };
  const result = validateStateRecord(record);
  if (!result.valid) {
    throw new Error(`Invalid state record: ${result.errors?.join(', ')}`);
  }
  return record;
}

export function createTransitionRecord(params: {
  matter_ref: string;
  source_ref: string;
  target_ref: string;
  transition_type: TransitionType;
  resolution_type?: ResolutionType | null;
  predecessor_ref?: string | null;
}): IammaiTransitionRecord {
  const record: IammaiTransitionRecord = {
    transition_id: uuidv4(),
    matter_ref: params.matter_ref,
    source_ref: params.source_ref,
    target_ref: params.target_ref,
    transition_type: params.transition_type,
    occurred_at: new Date(),
    resolution_type: params.resolution_type ?? null,
    predecessor_ref: params.predecessor_ref ?? null,
  };
  const result = validateTransitionRecord(record);
  if (!result.valid) {
    throw new Error(`Invalid transition record: ${result.errors?.join(', ')}`);
  }
  return record;
}

export function createGovernanceAction(params: {
  action_type: GovernanceActionType;
  authority_class: AuthorityClass;
  actor_ref: string;
  legitimacy_basis_ref: string;
  matter_ref: string;
  delegated_from_ref?: string | null;
  target_state_ref?: string | null;
  target_transition_ref?: string | null;
  contribution_role_map_ref?: string | null;
}): IammaiGovernanceAction {
  const record: IammaiGovernanceAction = {
    governance_action_id: uuidv4(),
    action_type: params.action_type,
    authority_class: params.authority_class,
    actor_ref: params.actor_ref,
    legitimacy_basis_ref: params.legitimacy_basis_ref,
    matter_ref: params.matter_ref,
    acted_at: new Date(),
    delegated_from_ref: params.delegated_from_ref ?? null,
    target_state_ref: params.target_state_ref ?? null,
    target_transition_ref: params.target_transition_ref ?? null,
    contribution_role_map_ref: params.contribution_role_map_ref ?? null,
  };
  const result = validateGovernanceAction(record);
  if (!result.valid) {
    throw new Error(`Invalid governance action: ${result.errors?.join(', ')}`);
  }
  return record;
}

export function createWitnessArtifact(params: {
  witness_type: WitnessType;
  target_ref: string;
  claims: string[];
  actor_ref?: string | null;
  surface_ref?: string | null;
}): IammaiWitnessArtifact {
  const record: IammaiWitnessArtifact = {
    witness_id: uuidv4(),
    witness_type: params.witness_type,
    target_ref: params.target_ref,
    observed_at: new Date(),
    claims: params.claims,
    non_claims: { ...MANDATORY_NON_CLAIMS },
    actor_ref: params.actor_ref ?? null,
    surface_ref: params.surface_ref ?? null,
  };
  const result = validateWitnessArtifact(record);
  if (!result.valid) {
    throw new Error(`Invalid witness artifact: ${result.errors?.join(', ')}`);
  }
  return record;
}

export function createValidationArtifact(params: {
  validation_type: ValidationType;
  target_ref: string;
  condition_set_ref: string;
  outcome: ValidationOutcome;
  reason_refs?: string[] | null;
  actor_ref?: string | null;
}): IammaiValidationArtifact {
  const record: IammaiValidationArtifact = {
    validation_id: uuidv4(),
    validation_type: params.validation_type,
    target_ref: params.target_ref,
    condition_set_ref: params.condition_set_ref,
    outcome: params.outcome,
    checked_at: new Date(),
    reason_refs: params.reason_refs ?? null,
    actor_ref: params.actor_ref ?? null,
  };
  const result = validateValidationArtifact(record);
  if (!result.valid) {
    throw new Error(`Invalid validation artifact: ${result.errors?.join(', ')}`);
  }
  return record;
}

export function createContributionRecord(params: {
  matter_ref: string;
  actor_ref: string;
  role: ContributionRole;
  context_ref?: string | null;
}): IammaiContributionRecord {
  const record: IammaiContributionRecord = {
    contribution_id: uuidv4(),
    matter_ref: params.matter_ref,
    actor_ref: params.actor_ref,
    role: params.role,
    recorded_at: new Date(),
    context_ref: params.context_ref ?? null,
  };
  const result = validateContributionRecord(record);
  if (!result.valid) {
    throw new Error(`Invalid contribution record: ${result.errors?.join(', ')}`);
  }
  return record;
}

export function createContainmentRecord(params: {
  matter_ref: string;
  target_state_ref: string;
  action: 'HOLD' | 'RELEASE';
  actor_ref: string;
  reason: string;
  governance_action_ref?: string | null;
}): IammaiContainmentRecord {
  const record: IammaiContainmentRecord = {
    containment_id: uuidv4(),
    matter_ref: params.matter_ref,
    target_state_ref: params.target_state_ref,
    action: params.action,
    actor_ref: params.actor_ref,
    reason: params.reason,
    recorded_at: new Date(),
    governance_action_ref: params.governance_action_ref ?? null,
  };
  const result = validateContainmentRecord(record);
  if (!result.valid) {
    throw new Error(`Invalid containment record: ${result.errors?.join(', ')}`);
  }
  return record;
}
