/**
 * IAMMAI Event Bus — In-process event-driven push for canonical record events.
 *
 * Emitted after every successful insert into IAMMAI canonical tables.
 * SSE connections subscribe to this bus instead of polling.
 *
 * This is a DERIVATIVE notification mechanism — the canonical state lives
 * in the registry. Events carry the inserted record for convenience but
 * the authoritative source is always the database table.
 */

import { EventEmitter } from 'node:events';

export type IammaiEventType =
  | 'phase_change'
  | 'transition_occurred'
  | 'governance_action'
  | 'witness_emitted'
  | 'validation_completed'
  | 'contribution_recorded'
  | 'containment_change'
  | 'accession_stage_change';

class IammaiEventBus extends EventEmitter {
  /**
   * Emit an IAMMAI record event.
   * Called by registry insert functions immediately after persistence.
   */
  emitRecord(eventType: IammaiEventType, record: Record<string, unknown>): void {
    this.emit(eventType, record);
  }

  /**
   * Subscribe to a specific event type.
   */
  onRecord(eventType: IammaiEventType, handler: (record: Record<string, unknown>) => void): void {
    this.on(eventType, handler);
  }

  /**
   * Unsubscribe from all events (for SSE client cleanup).
   */
  offRecord(eventType: IammaiEventType, handler: (record: Record<string, unknown>) => void): void {
    this.off(eventType, handler);
  }
}

// Singleton — shared across all SSE connections in this process
export const iammaiEventBus = new IammaiEventBus();

// Increase max listeners for many concurrent SSE connections
iammaiEventBus.setMaxListeners(100);
