/**
 * IAMMAI Validator — Pure Validation (NOT Governor)
 *
 * Validates preconditions and constraints without exercising governance force.
 * The validator checks; the governor decides. They must remain strictly separated.
 *
 * Returns validation artifacts that are persisted in the registry.
 */

import type pg from 'pg';
import type {
  IammaiPhase,
  IammaiValidationArtifact,
  IammaiStateRecord,
  IammaiContainmentRecord,
  ValidationOutcome,
} from './types.js';
import { PHASE_FAMILY, PHASE_ORDINAL } from './types.js';
import { createValidationArtifact } from './record-factory.js';
import { insertValidationArtifact } from './registry.js';
import { isStateHeld } from './containment-engine.js';

/**
 * Validate that a phase transition is admissible.
 * Checks: valid target, correct ordering, no held state blocking transition.
 */
export async function validateTransition(
  client: pg.PoolClient,
  params: {
    matter_ref: string;
    current_state: IammaiStateRecord | null;
    target_phase: IammaiPhase;
    containment_records: IammaiContainmentRecord[];
    actor_ref?: string;
  }
): Promise<IammaiValidationArtifact> {
  const { matter_ref, current_state, target_phase, containment_records, actor_ref } = params;
  const reasons: string[] = [];
  let outcome: ValidationOutcome = 'pass';

  // No current state: only signal is valid
  if (!current_state) {
    if (target_phase !== 'signal') {
      outcome = 'fail';
      reasons.push('No current state — only signal is a valid entry point');
    }
  } else {
    // Check ordering
    const currentOrdinal = PHASE_ORDINAL[current_state.state_type];
    const targetOrdinal = PHASE_ORDINAL[target_phase];

    if (targetOrdinal !== currentOrdinal + 1) {
      outcome = 'fail';
      reasons.push(
        `Invalid transition: ${current_state.state_type} (${currentOrdinal}) to ${target_phase} (${targetOrdinal})`
      );
    }

    // Check containment
    if (isStateHeld(containment_records, current_state.state_id)) {
      outcome = 'blocked';
      reasons.push(`Current state ${current_state.state_id} is held — transition blocked`);
    }
  }

  const artifact = createValidationArtifact({
    validation_type: 'transition_legality',
    target_ref: matter_ref,
    condition_set_ref: `transition:${current_state?.state_type ?? 'none'}:${target_phase}`,
    outcome,
    reason_refs: reasons.length > 0 ? reasons : null,
    actor_ref: actor_ref ?? null,
  });

  await insertValidationArtifact(client, artifact);
  return artifact;
}

/**
 * Validate that a matter is eligible for resolution.
 * Checks: in standing-state regime, not already resolved, not held.
 */
export async function validateResolution(
  client: pg.PoolClient,
  params: {
    matter_ref: string;
    current_state: IammaiStateRecord | null;
    containment_records: IammaiContainmentRecord[];
    is_already_resolved: boolean;
    actor_ref?: string;
  }
): Promise<IammaiValidationArtifact> {
  const { matter_ref, current_state, containment_records, is_already_resolved, actor_ref } = params;
  const reasons: string[] = [];
  let outcome: ValidationOutcome = 'pass';

  if (!current_state) {
    outcome = 'fail';
    reasons.push('No state records — cannot resolve');
  } else {
    if (PHASE_FAMILY[current_state.state_type] !== 'standing') {
      outcome = 'fail';
      reasons.push(`Not in standing-state regime: phase is ${current_state.state_type}`);
    }

    if (is_already_resolved) {
      outcome = 'fail';
      reasons.push('Matter is already resolved');
    }

    if (isStateHeld(containment_records, current_state.state_id)) {
      outcome = 'blocked';
      reasons.push(`Current state ${current_state.state_id} is held — resolution blocked`);
    }
  }

  const artifact = createValidationArtifact({
    validation_type: 'governance_precondition',
    target_ref: matter_ref,
    condition_set_ref: 'resolution_eligibility',
    outcome,
    reason_refs: reasons.length > 0 ? reasons : null,
    actor_ref: actor_ref ?? null,
  });

  await insertValidationArtifact(client, artifact);
  return artifact;
}

/**
 * Validate governance action preconditions.
 * Checks: actor_ref, authority_class, legitimacy_basis_ref are present,
 * and matter_ref is scoped correctly.
 */
export async function validateGovernancePreconditions(
  client: pg.PoolClient,
  params: {
    matter_ref: string;
    actor_ref: string;
    authority_class: string;
    legitimacy_basis_ref: string;
  }
): Promise<IammaiValidationArtifact> {
  const { matter_ref, actor_ref, authority_class, legitimacy_basis_ref } = params;
  const reasons: string[] = [];
  let outcome: ValidationOutcome = 'pass';

  if (!actor_ref) {
    outcome = 'fail';
    reasons.push('Missing actor_ref');
  }
  if (!authority_class) {
    outcome = 'fail';
    reasons.push('Missing authority_class');
  }
  if (!legitimacy_basis_ref) {
    outcome = 'fail';
    reasons.push('Missing legitimacy_basis_ref');
  }
  if (!matter_ref) {
    outcome = 'fail';
    reasons.push('Missing matter_ref');
  }

  const artifact = createValidationArtifact({
    validation_type: 'governance_precondition',
    target_ref: matter_ref || 'unknown',
    condition_set_ref: 'governance_attribution_check',
    outcome,
    reason_refs: reasons.length > 0 ? reasons : null,
    actor_ref,
  });

  await insertValidationArtifact(client, artifact);
  return artifact;
}
