/**
 * IAMMAI Schema Validator
 *
 * Validates canonical records against JSON schemas using ajv.
 * Each validate function returns { valid, errors } where errors
 * is null on success or an array of error messages on failure.
 */

import AjvModule from 'ajv';
// eslint-disable-next-line @typescript-eslint/no-explicit-any
const Ajv = (AjvModule as any).default ?? AjvModule;
import {
  stateRecordSchema,
  transitionRecordSchema,
  governanceActionSchema,
  witnessArtifactSchema,
  validationArtifactSchema,
  contributionRecordSchema,
  containmentRecordSchema,
} from './schemas.js';

// ============================================================================
// Validator Setup
// ============================================================================

const ajv = new Ajv({ allErrors: true, strict: false });

const validateState = ajv.compile(stateRecordSchema);
const validateTransition = ajv.compile(transitionRecordSchema);
const validateGovernance = ajv.compile(governanceActionSchema);
const validateWitness = ajv.compile(witnessArtifactSchema);
const validateValidation = ajv.compile(validationArtifactSchema);
const validateContribution = ajv.compile(contributionRecordSchema);
const validateContainment = ajv.compile(containmentRecordSchema);

// ============================================================================
// Result Type
// ============================================================================

export interface SchemaValidationResult {
  valid: boolean;
  errors: string[] | null;
}

// ============================================================================
// Validation Functions
// ============================================================================

function toResult(valid: boolean, validate: { errors?: readonly { message?: string }[] | null }): SchemaValidationResult {
  if (valid) return { valid: true, errors: null };
  const errors = (validate.errors ?? []).map(e => e.message ?? 'Unknown validation error');
  return { valid: false, errors };
}

export function validateStateRecord(record: unknown): SchemaValidationResult {
  const valid = validateState(record);
  return toResult(valid, validateState);
}

export function validateTransitionRecord(record: unknown): SchemaValidationResult {
  const valid = validateTransition(record);
  return toResult(valid, validateTransition);
}

export function validateGovernanceAction(record: unknown): SchemaValidationResult {
  const valid = validateGovernance(record);
  return toResult(valid, validateGovernance);
}

export function validateWitnessArtifact(record: unknown): SchemaValidationResult {
  const valid = validateWitness(record);
  return toResult(valid, validateWitness);
}

export function validateValidationArtifact(record: unknown): SchemaValidationResult {
  const valid = validateValidation(record);
  return toResult(valid, validateValidation);
}

export function validateContributionRecord(record: unknown): SchemaValidationResult {
  const valid = validateContribution(record);
  return toResult(valid, validateContribution);
}

export function validateContainmentRecord(record: unknown): SchemaValidationResult {
  const valid = validateContainment(record);
  return toResult(valid, validateContainment);
}
