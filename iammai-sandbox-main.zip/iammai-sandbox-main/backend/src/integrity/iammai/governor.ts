/**
 * IAMMAI Governor — Typed Governance Actions with Attribution
 *
 * Exercises lawful force: authorize, deny, hold, release, finalize, invalidate, evolve.
 * Must NOT become: Validator, Witness, or semantic source.
 *
 * Every governance action requires: actor_ref, authority_class, legitimacy_basis_ref,
 * matter_ref (authority is matter-bounded).
 */

import type pg from 'pg';
import { createGovernanceAction } from './record-factory.js';
import { insertGovernanceAction, getGovernanceActionsByMatter } from './registry.js';
import { query } from '../../lib/db.js';
import type {
  GovernanceActionType,
  AuthorityClass,
  IammaiGovernanceAction,
} from './types.js';

export interface GovernanceActionParams {
  action_type: GovernanceActionType;
  authority_class: AuthorityClass;
  actor_ref: string;
  legitimacy_basis_ref: string;
  matter_ref: string;
  delegated_from_ref?: string | null;
  target_state_ref?: string | null;
  target_transition_ref?: string | null;
  contribution_role_map_ref?: string | null;
}

/**
 * Record a governance action in the canonical registry.
 * Creates and persists an IammaiGovernanceAction.
 */
export async function recordGovernanceAction(
  client: pg.PoolClient,
  params: GovernanceActionParams
): Promise<IammaiGovernanceAction> {
  const record = createGovernanceAction(params);
  await insertGovernanceAction(client, record);
  return record;
}

/**
 * Get all governance actions for a matter.
 */
export async function getActionsByMatter(matterRef: string): Promise<IammaiGovernanceAction[]> {
  return getGovernanceActionsByMatter(matterRef);
}

/**
 * Get governance actions by actor within a matter.
 */
export async function getActionsByActor(
  actorRef: string,
  matterRef: string
): Promise<IammaiGovernanceAction[]> {
  const result = await query<IammaiGovernanceAction>(
    `SELECT * FROM iammai_governance_actions
     WHERE actor_ref = $1 AND matter_ref = $2
     ORDER BY acted_at ASC`,
    [actorRef, matterRef]
  );
  return result.rows;
}

/**
 * Check if a governance action is authorized for a specific matter.
 * Authority is matter-bounded: authorization on matter A does NOT
 * grant authorization on matter B.
 */
export function isAuthorized(
  action: IammaiGovernanceAction,
  targetMatterRef: string
): boolean {
  return action.matter_ref === targetMatterRef;
}
