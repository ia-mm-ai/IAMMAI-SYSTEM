/**
 * IAMMAI Constitutional Protocol — Core Type Definitions
 *
 * Defines the 9-phase canonical sequence, resolution family,
 * governance actions, contribution roles, witness/validation types,
 * and all 7 canonical record interfaces.
 *
 * @see .claude/skills/iammai/SKILL.md
 * @see .claude/skills/iammai/references/canonical-schemas.md
 */

// ============================================================================
// State Families & Phases
// ============================================================================

/** Two-level state typing: preparation vs standing */
export type StateFamily = 'preparation' | 'standing';

/** The 9 canonical phases in fixed order */
export type IammaiPhase =
  | 'signal'
  | 'acceptance'
  | 'scope'
  | 'presence'
  | 'threshold'
  | 'truth'
  | 'continuity'
  | 'decision'
  | 'consequence';

/** Ordinal position of each phase (1-9, no gaps) */
export const PHASE_ORDINAL: Record<IammaiPhase, number> = {
  signal: 1,
  acceptance: 2,
  scope: 3,
  presence: 4,
  threshold: 5,
  truth: 6,
  continuity: 7,
  decision: 8,
  consequence: 9,
};

/** Which state family each phase belongs to */
export const PHASE_FAMILY: Record<IammaiPhase, StateFamily> = {
  signal: 'preparation',
  acceptance: 'preparation',
  scope: 'preparation',
  presence: 'preparation',
  threshold: 'preparation',
  truth: 'standing',
  continuity: 'standing',
  decision: 'standing',
  consequence: 'standing',
};

/** All phases in canonical order */
export const PHASES_IN_ORDER: IammaiPhase[] = [
  'signal', 'acceptance', 'scope', 'presence', 'threshold',
  'truth', 'continuity', 'decision', 'consequence',
];

/** Preparation-regime phases */
export const PREPARATION_PHASES: IammaiPhase[] = [
  'signal', 'acceptance', 'scope', 'presence', 'threshold',
];

/** Standing-state-regime phases */
export const STANDING_PHASES: IammaiPhase[] = [
  'truth', 'continuity', 'decision', 'consequence',
];

// ============================================================================
// Resolution Types
// ============================================================================

/** Closed set of exactly 3 resolution types */
export type ResolutionType = 'FINALIZE' | 'INVALIDATE' | 'EVOLVE';

// ============================================================================
// Transition Types
// ============================================================================

/** 9 bounded transition types + containment + resolution */
export type TransitionType =
  | 'preparation_progression'
  | 'threshold_eligibility'
  | 'truth_formation'
  | 'continuity_transition'
  | 'decision_transition'
  | 'consequence_transition'
  | 'containment_apply'
  | 'containment_release'
  | 'resolution_transition';

/**
 * Maps phase-to-phase transitions to their transition type.
 * Key format: `${fromPhase}_to_${toPhase}`
 */
export const PHASE_TRANSITION_TYPE: Record<string, TransitionType> = {
  'signal_to_acceptance': 'preparation_progression',
  'acceptance_to_scope': 'preparation_progression',
  'scope_to_presence': 'preparation_progression',
  'presence_to_threshold': 'threshold_eligibility',
  'threshold_to_truth': 'truth_formation',
  'truth_to_continuity': 'continuity_transition',
  'continuity_to_decision': 'decision_transition',
  'decision_to_consequence': 'consequence_transition',
};

// ============================================================================
// Governance Types
// ============================================================================

/** 7 typed governance actions */
export type GovernanceActionType =
  | 'authorize'
  | 'deny'
  | 'hold'
  | 'release'
  | 'finalize'
  | 'invalidate'
  | 'evolve';

/** Authority classification */
export type AuthorityClass = 'SYSTEM' | 'OPERATOR' | 'DELEGATED';

// ============================================================================
// Contribution Roles
// ============================================================================

/** 6 distinguishable contribution roles */
export type ContributionRole =
  | 'ORIGIN'
  | 'ELICITATION'
  | 'FORMALIZATION'
  | 'AUTHORIZATION'
  | 'RENDERING'
  | 'TRANSMISSION';

// ============================================================================
// Witness Types
// ============================================================================

/** 5 witness types */
export type WitnessType =
  | 'interaction'
  | 'validation'
  | 'transition'
  | 'publication'
  | 'state_observation';

/** 5 mandatory non-claims — every witness artifact MUST include all 5 */
export interface NonClaims {
  not_authorship: true;
  not_semantic_source: true;
  not_final_authority: true;
  not_automatic_truth_creation: true;
  not_governance_force: true;
}

/** The singleton non-claims object */
export const MANDATORY_NON_CLAIMS: NonClaims = {
  not_authorship: true,
  not_semantic_source: true,
  not_final_authority: true,
  not_automatic_truth_creation: true,
  not_governance_force: true,
};

// ============================================================================
// Validation Types
// ============================================================================

/** 5 validation types */
export type ValidationType =
  | 'admissibility'
  | 'threshold'
  | 'transition_legality'
  | 'governance_precondition'
  | 'bounded_consistency';

/** 4 validation outcomes — must NOT default blocked/indeterminate to pass/fail */
export type ValidationOutcome = 'pass' | 'fail' | 'blocked' | 'indeterminate';

// ============================================================================
// Canonical Record Interfaces
// ============================================================================

/** IAMMAI State Record — canonical phase state with two-level typing */
export interface IammaiStateRecord {
  state_id: string;
  matter_ref: string;
  state_family: StateFamily;
  state_type: IammaiPhase;
  recorded_at: Date;
  predecessor_ref: string | null;
  containment_ref: string | null;
  related_transition_ref: string | null;
  related_governance_ref: string | null;
  related_validation_ref: string | null;
  related_witness_ref: string | null;
}

/** IAMMAI Transition Record — typed phase-to-phase movement */
export interface IammaiTransitionRecord {
  transition_id: string;
  matter_ref: string;
  source_ref: string;
  target_ref: string;
  transition_type: TransitionType;
  occurred_at: Date;
  resolution_type: ResolutionType | null;
  predecessor_ref: string | null;
}

/** IAMMAI Governance Action Record — typed lawful force with attribution */
export interface IammaiGovernanceAction {
  governance_action_id: string;
  action_type: GovernanceActionType;
  authority_class: AuthorityClass;
  actor_ref: string;
  legitimacy_basis_ref: string;
  matter_ref: string;
  acted_at: Date;
  delegated_from_ref: string | null;
  target_state_ref: string | null;
  target_transition_ref: string | null;
  contribution_role_map_ref: string | null;
}

/** IAMMAI Witness Artifact — contact preservation with mandatory non-claims */
export interface IammaiWitnessArtifact {
  witness_id: string;
  witness_type: WitnessType;
  target_ref: string;
  observed_at: Date;
  claims: string[];
  non_claims: NonClaims;
  actor_ref: string | null;
  surface_ref: string | null;
}

/** IAMMAI Validation Artifact — typed condition checking */
export interface IammaiValidationArtifact {
  validation_id: string;
  validation_type: ValidationType;
  target_ref: string;
  condition_set_ref: string;
  outcome: ValidationOutcome;
  checked_at: Date;
  reason_refs: string[] | null;
  actor_ref: string | null;
}

/** IAMMAI Contribution Record — 6-role semantic participation */
export interface IammaiContributionRecord {
  contribution_id: string;
  matter_ref: string;
  actor_ref: string;
  role: ContributionRole;
  recorded_at: Date;
  context_ref: string | null;
}

/** IAMMAI Containment Record — orthogonal HOLD/RELEASE */
export interface IammaiContainmentRecord {
  containment_id: string;
  matter_ref: string;
  target_state_ref: string;
  action: 'HOLD' | 'RELEASE';
  actor_ref: string;
  reason: string;
  recorded_at: Date;
  governance_action_ref: string | null;
}

// ============================================================================
// Evaluation Context Extension
// ============================================================================

/** Extended context for IAMMAI-tracked sessions */
export interface IammaiEvaluationContext {
  stateRecords: IammaiStateRecord[];
  transitionRecords: IammaiTransitionRecord[];
  governanceActions: IammaiGovernanceAction[];
  witnessArtifacts: IammaiWitnessArtifact[];
  validationArtifacts: IammaiValidationArtifact[];
  contributionRecords: IammaiContributionRecord[];
  containmentRecords: IammaiContainmentRecord[];
}

// ============================================================================
// Helpers
// ============================================================================

/** Construct a matter reference from a session ID */
export function matterRef(sessionId: string): string {
  return `bnk:session:${sessionId}`;
}

/** Construct an actor reference from an admin ID */
export function actorRef(adminId: string): string {
  return `bnk:admin:${adminId}`;
}

/** Construct a system actor reference */
export function systemActorRef(component: string): string {
  return `bnk:system:${component}`;
}

/** Construct an agent actor reference */
export function agentActorRef(agentType: string): string {
  return `bnk:agent:${agentType}`;
}
