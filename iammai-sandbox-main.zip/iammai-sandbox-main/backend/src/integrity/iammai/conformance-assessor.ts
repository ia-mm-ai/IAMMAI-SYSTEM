/**
 * IAMMAI Conformance Assessor — 10-Category Assessment
 *
 * Evaluates a matter's IAMMAI conformance across 10 categories:
 * 1. Phase Integrity — all phases distinguishable, ordered, no skipping
 * 2. State Family — preparation/standing correctly assigned
 * 3. Lineage Preservation — every state has predecessor chain
 * 4. Resolution Legality — only FINALIZE/INVALIDATE/EVOLVE, from standing
 * 5. Containment Orthogonality — HOLD does not change phase identity
 * 6. Governance Attribution — actor_ref + authority_class + legitimacy_basis_ref
 * 7. Witness Coverage — witness artifacts exist for significant events
 * 8. Validation Coverage — validation precedes governance
 * 9. Contribution Completeness — roles recorded for participating actors
 * 10. Audit Answerability — all 8 audit questions answerable
 *
 * Returns a structured conformance report with per-category pass/fail.
 */

import type { IammaiEvaluationContext, ContributionRole } from './types.js';
import { PHASE_FAMILY, PHASE_ORDINAL } from './types.js';
import {
  queryCurrentPhase,
  queryAdmissibility,
  queryStanding,
  queryResolution,
  queryLineage,
  queryAttribution,
  queryContributions,
  queryPreservation,
} from './governance-query.js';

// ============================================================================
// Assessment Types
// ============================================================================

export type ConformanceCategory =
  | 'PHASE_INTEGRITY'
  | 'STATE_FAMILY'
  | 'LINEAGE_PRESERVATION'
  | 'RESOLUTION_LEGALITY'
  | 'CONTAINMENT_ORTHOGONALITY'
  | 'GOVERNANCE_ATTRIBUTION'
  | 'WITNESS_COVERAGE'
  | 'VALIDATION_COVERAGE'
  | 'CONTRIBUTION_COMPLETENESS'
  | 'AUDIT_ANSWERABILITY';

export interface CategoryAssessment {
  category: ConformanceCategory;
  result: 'PASS' | 'FAIL' | 'NOT_APPLICABLE';
  details: string;
  findings: string[];
}

export interface ConformanceReport {
  matter_ref: string;
  overall: 'CONFORMANT' | 'NON_CONFORMANT' | 'PARTIAL';
  assessed_at: Date;
  categories: CategoryAssessment[];
  pass_count: number;
  fail_count: number;
  na_count: number;
}

// ============================================================================
// Assessment Functions
// ============================================================================

function assessPhaseIntegrity(ctx: IammaiEvaluationContext): CategoryAssessment {
  const findings: string[] = [];
  const { stateRecords } = ctx;

  if (stateRecords.length === 0) {
    return { category: 'PHASE_INTEGRITY', result: 'FAIL', details: 'No state records', findings: ['No state records found'] };
  }

  const phases = stateRecords.map(r => r.state_type);

  // Check first phase is signal
  if (phases[0] !== 'signal') {
    findings.push(`First phase is '${phases[0]}', expected 'signal'`);
  }

  // Check no duplicates
  const uniquePhases = new Set(phases);
  if (uniquePhases.size !== phases.length) {
    findings.push('Duplicate phases detected');
  }

  // Check ordering
  for (let i = 1; i < phases.length; i++) {
    const prev = PHASE_ORDINAL[phases[i - 1]];
    const curr = PHASE_ORDINAL[phases[i]];
    if (curr !== prev + 1) {
      findings.push(`Phase order issue: '${phases[i - 1]}' → '${phases[i]}'`);
    }
  }

  return {
    category: 'PHASE_INTEGRITY',
    result: findings.length === 0 ? 'PASS' : 'FAIL',
    details: findings.length === 0 ? `${phases.length} phases in canonical order` : 'Phase integrity violations found',
    findings,
  };
}

function assessStateFamily(ctx: IammaiEvaluationContext): CategoryAssessment {
  const findings: string[] = [];
  const { stateRecords } = ctx;

  for (const record of stateRecords) {
    const expected = PHASE_FAMILY[record.state_type];
    if (record.state_family !== expected) {
      findings.push(`Phase '${record.state_type}' has family '${record.state_family}', expected '${expected}'`);
    }
  }

  return {
    category: 'STATE_FAMILY',
    result: findings.length === 0 ? 'PASS' : 'FAIL',
    details: findings.length === 0 ? 'All state families correct' : 'State family mismatches found',
    findings,
  };
}

function assessLineagePreservation(ctx: IammaiEvaluationContext): CategoryAssessment {
  const findings: string[] = [];
  const { stateRecords } = ctx;

  if (stateRecords.length <= 1) {
    return { category: 'LINEAGE_PRESERVATION', result: 'PASS', details: 'Single or no state — lineage trivially satisfied', findings: [] };
  }

  // Check every non-first state has a predecessor_ref
  for (let i = 1; i < stateRecords.length; i++) {
    if (!stateRecords[i].predecessor_ref) {
      findings.push(`State ${stateRecords[i].state_id} (${stateRecords[i].state_type}) missing predecessor_ref`);
    }
  }

  // Check predecessor chain points to previous state
  const stateIds = new Map(stateRecords.map(r => [r.state_id, r]));
  for (let i = 1; i < stateRecords.length; i++) {
    const pred = stateRecords[i].predecessor_ref;
    if (pred && !stateIds.has(pred)) {
      // Could be external predecessor (EVOLVE) — only flag for non-first state
      if (i > 0 && stateRecords[i].state_type !== 'signal') {
        findings.push(`State ${stateRecords[i].state_id} predecessor_ref '${pred}' not found in state records`);
      }
    }
  }

  return {
    category: 'LINEAGE_PRESERVATION',
    result: findings.length === 0 ? 'PASS' : 'FAIL',
    details: findings.length === 0 ? 'Lineage chain intact' : 'Lineage breaks found',
    findings,
  };
}

function assessResolutionLegality(ctx: IammaiEvaluationContext): CategoryAssessment {
  const findings: string[] = [];
  const { transitionRecords } = ctx;

  const resolutions = transitionRecords.filter(t => t.transition_type === 'resolution_transition');

  if (resolutions.length === 0) {
    return { category: 'RESOLUTION_LEGALITY', result: 'NOT_APPLICABLE', details: 'No resolutions to assess', findings: [] };
  }

  const validTypes = ['FINALIZE', 'INVALIDATE', 'EVOLVE'];
  for (const r of resolutions) {
    if (!r.resolution_type || !validTypes.includes(r.resolution_type)) {
      findings.push(`Invalid resolution type: '${r.resolution_type}'`);
    }
  }

  if (resolutions.length > 1) {
    findings.push(`Multiple resolutions found (${resolutions.length}) — expected at most 1`);
  }

  return {
    category: 'RESOLUTION_LEGALITY',
    result: findings.length === 0 ? 'PASS' : 'FAIL',
    details: findings.length === 0 ? `Resolution via ${resolutions[0].resolution_type}` : 'Resolution legality violations',
    findings,
  };
}

function assessContainmentOrthogonality(ctx: IammaiEvaluationContext): CategoryAssessment {
  const { containmentRecords, stateRecords } = ctx;

  if (containmentRecords.length === 0) {
    return { category: 'CONTAINMENT_ORTHOGONALITY', result: 'NOT_APPLICABLE', details: 'No containment records', findings: [] };
  }

  const findings: string[] = [];
  const stateMap = new Map(stateRecords.map(r => [r.state_id, r]));

  // Check each containment targets a valid state
  for (const c of containmentRecords) {
    if (!stateMap.has(c.target_state_ref)) {
      findings.push(`Containment ${c.containment_id} targets unknown state ${c.target_state_ref}`);
    }
  }

  return {
    category: 'CONTAINMENT_ORTHOGONALITY',
    result: findings.length === 0 ? 'PASS' : 'FAIL',
    details: findings.length === 0 ? `${containmentRecords.length} containment records valid` : 'Containment issues found',
    findings,
  };
}

function assessGovernanceAttribution(ctx: IammaiEvaluationContext): CategoryAssessment {
  const findings: string[] = [];
  const { governanceActions } = ctx;

  if (governanceActions.length === 0) {
    return { category: 'GOVERNANCE_ATTRIBUTION', result: 'FAIL', details: 'No governance actions recorded', findings: ['No governance actions'] };
  }

  for (const action of governanceActions) {
    if (!action.actor_ref) findings.push(`Action ${action.governance_action_id} missing actor_ref`);
    if (!action.authority_class) findings.push(`Action ${action.governance_action_id} missing authority_class`);
    if (!action.legitimacy_basis_ref) findings.push(`Action ${action.governance_action_id} missing legitimacy_basis_ref`);
    if (!action.matter_ref) findings.push(`Action ${action.governance_action_id} missing matter_ref`);
  }

  return {
    category: 'GOVERNANCE_ATTRIBUTION',
    result: findings.length === 0 ? 'PASS' : 'FAIL',
    details: findings.length === 0 ? `${governanceActions.length} actions with complete attribution` : 'Attribution gaps found',
    findings,
  };
}

function assessWitnessCoverage(ctx: IammaiEvaluationContext): CategoryAssessment {
  const { witnessArtifacts, stateRecords } = ctx;

  if (stateRecords.length === 0) {
    return { category: 'WITNESS_COVERAGE', result: 'NOT_APPLICABLE', details: 'No states to witness', findings: [] };
  }

  if (witnessArtifacts.length === 0) {
    return { category: 'WITNESS_COVERAGE', result: 'FAIL', details: 'No witness artifacts', findings: ['No witness artifacts emitted'] };
  }

  // Check non-claims present on all witnesses
  const findings: string[] = [];
  for (const w of witnessArtifacts) {
    if (!w.non_claims || !w.non_claims.not_authorship) {
      findings.push(`Witness ${w.witness_id} missing mandatory non-claims`);
    }
  }

  return {
    category: 'WITNESS_COVERAGE',
    result: findings.length === 0 ? 'PASS' : 'FAIL',
    details: findings.length === 0 ? `${witnessArtifacts.length} witness artifacts with complete non-claims` : 'Witness coverage issues',
    findings,
  };
}

function assessValidationCoverage(ctx: IammaiEvaluationContext): CategoryAssessment {
  const { validationArtifacts, stateRecords } = ctx;

  if (stateRecords.length === 0) {
    return { category: 'VALIDATION_COVERAGE', result: 'NOT_APPLICABLE', details: 'No states to validate', findings: [] };
  }

  if (validationArtifacts.length === 0) {
    return { category: 'VALIDATION_COVERAGE', result: 'FAIL', details: 'No validation artifacts', findings: ['No validation artifacts recorded'] };
  }

  return {
    category: 'VALIDATION_COVERAGE',
    result: 'PASS',
    details: `${validationArtifacts.length} validation artifacts recorded`,
    findings: [],
  };
}

function assessContributionCompleteness(ctx: IammaiEvaluationContext): CategoryAssessment {
  const { contributionRecords } = ctx;

  if (contributionRecords.length === 0) {
    return { category: 'CONTRIBUTION_COMPLETENESS', result: 'FAIL', details: 'No contribution records', findings: ['No contributions recorded'] };
  }

  const roles = new Set(contributionRecords.map(c => c.role));
  const findings: string[] = [];

  // At minimum, ORIGIN should be present
  if (!roles.has('ORIGIN')) {
    findings.push('Missing ORIGIN contribution role');
  }

  return {
    category: 'CONTRIBUTION_COMPLETENESS',
    result: findings.length === 0 ? 'PASS' : 'FAIL',
    details: findings.length === 0 ? `${contributionRecords.length} contributions across ${roles.size} role(s)` : 'Contribution gaps found',
    findings,
  };
}

function assessAuditAnswerability(ctx: IammaiEvaluationContext): CategoryAssessment {
  const findings: string[] = [];

  const q1 = queryCurrentPhase(ctx);
  if (q1.phase === null) findings.push('Q1 (current phase) unanswerable');

  const q2 = queryAdmissibility(ctx);
  if (!q2.admissible) findings.push('Q2 (admissibility) unanswerable');

  // Q3-Q8 are always answerable if records exist (they return structured data)
  const q6 = queryAttribution(ctx);
  if (q6.actions.length === 0) findings.push('Q6 (attribution) unanswerable — no governance actions');

  const q8 = queryPreservation(ctx);
  if (q8.totalRecords === 0) findings.push('Q8 (preservation) unanswerable — no records');

  return {
    category: 'AUDIT_ANSWERABILITY',
    result: findings.length === 0 ? 'PASS' : 'FAIL',
    details: findings.length === 0 ? 'All 8 audit questions answerable' : 'Some audit questions unanswerable',
    findings,
  };
}

// ============================================================================
// Main Assessment Function
// ============================================================================

/**
 * Run a full 10-category IAMMAI conformance assessment.
 */
export function assessConformance(
  matterRef: string,
  ctx: IammaiEvaluationContext
): ConformanceReport {
  const categories: CategoryAssessment[] = [
    assessPhaseIntegrity(ctx),
    assessStateFamily(ctx),
    assessLineagePreservation(ctx),
    assessResolutionLegality(ctx),
    assessContainmentOrthogonality(ctx),
    assessGovernanceAttribution(ctx),
    assessWitnessCoverage(ctx),
    assessValidationCoverage(ctx),
    assessContributionCompleteness(ctx),
    assessAuditAnswerability(ctx),
  ];

  const pass_count = categories.filter(c => c.result === 'PASS').length;
  const fail_count = categories.filter(c => c.result === 'FAIL').length;
  const na_count = categories.filter(c => c.result === 'NOT_APPLICABLE').length;

  let overall: ConformanceReport['overall'];
  if (fail_count === 0) {
    overall = 'CONFORMANT';
  } else if (pass_count > 0) {
    overall = 'PARTIAL';
  } else {
    overall = 'NON_CONFORMANT';
  }

  return {
    matter_ref: matterRef,
    overall,
    assessed_at: new Date(),
    categories,
    pass_count,
    fail_count,
    na_count,
  };
}
