/**
 * IAMMAI Resolution Engine — FINALIZE / INVALIDATE / EVOLVE
 *
 * Resolution is the typed mechanism by which a matter's standing state
 * reaches a terminal or successor state. The three resolution types
 * form a closed set — no other resolution mechanism is valid.
 *
 * Constraints:
 * - Resolution ONLY from standing-state regime (truth or later)
 * - FINALIZE: terminal — no successor state
 * - INVALIDATE: terminal — no successor state, marks matter as void
 * - EVOLVE: creates successor matter with predecessor_ref linkage
 * - Every resolution requires a governance action (governor, not validator)
 */

import type pg from 'pg';
import type {
  ResolutionType,
  IammaiStateRecord,
  IammaiTransitionRecord,
  IammaiGovernanceAction,
  IammaiPhase,
} from './types.js';
import { PHASE_FAMILY } from './types.js';
import { createStateRecord, createTransitionRecord } from './record-factory.js';
import {
  insertStateRecord,
  insertTransitionRecord,
  getStateRecordsByMatter,
  getTransitionRecordsByMatter,
} from './registry.js';
import { recordGovernanceAction } from './governor.js';
import type { GovernanceActionParams } from './governor.js';

// ============================================================================
// Resolution Parameters
// ============================================================================

export interface ResolveParams {
  matter_ref: string;
  resolution_type: ResolutionType;
  actor_ref: string;
  legitimacy_basis_ref: string;
  authority_class: 'SYSTEM' | 'OPERATOR' | 'DELEGATED';
  /** Required for EVOLVE — the successor matter reference */
  successor_matter_ref?: string;
}

export interface ResolutionResult {
  governanceAction: IammaiGovernanceAction;
  transitionRecord: IammaiTransitionRecord;
  /** For EVOLVE only — the initial state of the successor matter */
  successorStateRecord?: IammaiStateRecord;
}

// ============================================================================
// Resolution Operations
// ============================================================================

/**
 * Check if a matter is in standing-state regime (eligible for resolution).
 */
export async function isResolutionEligible(matterRef: string): Promise<boolean> {
  const records = await getStateRecordsByMatter(matterRef);
  if (records.length === 0) return false;
  const currentPhase = records[records.length - 1].state_type;
  return PHASE_FAMILY[currentPhase] === 'standing';
}

/**
 * Check if a matter has already been resolved.
 */
export async function isResolved(matterRef: string): Promise<boolean> {
  const transitions = await getTransitionRecordsByMatter(matterRef);
  return transitions.some(t => t.transition_type === 'resolution_transition');
}

/**
 * Resolve a matter with one of the three typed resolution mechanisms.
 *
 * @throws Error if not in standing-state regime
 * @throws Error if already resolved
 * @throws Error if EVOLVE without successor_matter_ref
 */
export async function resolve(
  client: pg.PoolClient,
  params: ResolveParams
): Promise<ResolutionResult> {
  const { matter_ref, resolution_type, actor_ref, legitimacy_basis_ref, authority_class } = params;

  // 1. Get current state records
  const result = await client.query<{ state_id: string; state_type: string; state_family: string }>(
    'SELECT state_id, state_type, state_family FROM iammai_state_records WHERE matter_ref = $1 ORDER BY recorded_at DESC LIMIT 1',
    [matter_ref]
  );
  const currentRecord = result.rows[0];

  if (!currentRecord) {
    throw new Error('Cannot resolve: no state records found for matter ' + matter_ref);
  }

  // 2. Verify standing-state regime
  if (currentRecord.state_family !== 'standing') {
    throw new Error(
      'Cannot resolve: matter is in preparation regime (phase: ' + currentRecord.state_type + '). ' +
      'Resolution requires standing-state regime.'
    );
  }

  // 3. Check not already resolved
  const existingTransitions = await client.query<{ transition_type: string }>(
    'SELECT transition_type FROM iammai_transition_records WHERE matter_ref = $1 AND transition_type = $2',
    [matter_ref, 'resolution_transition']
  );
  if (existingTransitions.rows.length > 0) {
    throw new Error('Cannot resolve: matter ' + matter_ref + ' is already resolved');
  }

  // 4. EVOLVE requires successor_matter_ref
  if (resolution_type === 'EVOLVE' && !params.successor_matter_ref) {
    throw new Error('EVOLVE resolution requires successor_matter_ref');
  }

  // 5. Map resolution type to governance action type
  const governanceActionType = resolution_type.toLowerCase() as 'finalize' | 'invalidate' | 'evolve';

  // 6. Record governance action
  const governanceAction = await recordGovernanceAction(client, {
    action_type: governanceActionType,
    authority_class,
    actor_ref,
    legitimacy_basis_ref,
    matter_ref,
    target_state_ref: currentRecord.state_id,
  });

  // 7. Create resolution transition record
  const transitionRecord = createTransitionRecord({
    matter_ref,
    source_ref: currentRecord.state_id,
    target_ref: currentRecord.state_id, // self-ref for FINALIZE/INVALIDATE, updated for EVOLVE
    transition_type: 'resolution_transition',
    resolution_type,
    predecessor_ref: null,
  });

  // 8. For EVOLVE, create the successor matter's initial signal state
  let successorStateRecord: IammaiStateRecord | undefined;
  if (resolution_type === 'EVOLVE' && params.successor_matter_ref) {
    successorStateRecord = createStateRecord({
      matter_ref: params.successor_matter_ref,
      state_type: 'signal',
      predecessor_ref: currentRecord.state_id, // lineage: predecessor is the resolved state
      related_governance_ref: governanceAction.governance_action_id,
    });

    // Update transition target_ref to point to successor
    (transitionRecord as { target_ref: string }).target_ref = successorStateRecord.state_id;

    await insertStateRecord(client, successorStateRecord);
  }

  await insertTransitionRecord(client, transitionRecord);

  return {
    governanceAction,
    transitionRecord,
    successorStateRecord,
  };
}

/**
 * Get the resolution transition for a matter, if any.
 */
export async function getResolution(
  matterRef: string
): Promise<IammaiTransitionRecord | null> {
  const transitions = await getTransitionRecordsByMatter(matterRef);
  return transitions.find(t => t.transition_type === 'resolution_transition') ?? null;
}

/**
 * Get the predecessor matter reference for an EVOLVE'd matter.
 * Returns null if the matter was not created via EVOLVE.
 */
export async function getPredecessorMatter(
  matterRef: string
): Promise<string | null> {
  const states = await getStateRecordsByMatter(matterRef);
  if (states.length === 0) return null;

  const firstState = states[0];
  // If the first state (signal) has a predecessor_ref, it was EVOLVE'd from another matter
  if (firstState.predecessor_ref) {
    // The predecessor_ref points to a state_id in the predecessor matter
    // We need to find which matter that state belongs to
    return firstState.predecessor_ref;
  }
  return null;
}
