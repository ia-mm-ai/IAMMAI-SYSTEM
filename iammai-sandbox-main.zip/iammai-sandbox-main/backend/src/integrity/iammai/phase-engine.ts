/**
 * IAMMAI Phase Engine - 9-Phase Canonical State Machine
 *
 * Maintains the fixed canonical phase order with preparation/standing distinction.
 * Phases must not be skipped, reordered, or absorbed into each other.
 * Signal is the only valid entry point.
 */

import type pg from 'pg';
import {
  PHASE_ORDINAL,
  PHASE_FAMILY,
  PHASE_TRANSITION_TYPE,
  PHASES_IN_ORDER,
} from './types.js';
import type {
  IammaiPhase,
  IammaiStateRecord,
  IammaiTransitionRecord,
} from './types.js';
import { createStateRecord, createTransitionRecord } from './record-factory.js';
import { insertStateRecord, insertTransitionRecord, getStateRecordsByMatter } from './registry.js';

// ============================================================================
// Valid Transitions (strict canonical order, no skipping)
// ============================================================================

const VALID_TRANSITIONS: Record<IammaiPhase, IammaiPhase | null> = {
  signal: 'acceptance',
  acceptance: 'scope',
  scope: 'presence',
  presence: 'threshold',
  threshold: 'truth',
  truth: 'continuity',
  continuity: 'decision',
  decision: 'consequence',
  consequence: null, // terminal
};

// ============================================================================
// Phase Operations
// ============================================================================

/**
 * Check if a phase transition is valid in the canonical order.
 */
export function isValidTransition(from: IammaiPhase, to: IammaiPhase): boolean {
  return VALID_TRANSITIONS[from] === to;
}

/**
 * Check if a phase is in the preparation regime.
 */
export function isPreparation(phase: IammaiPhase): boolean {
  return PHASE_FAMILY[phase] === 'preparation';
}

/**
 * Check if a phase is in the standing-state regime.
 */
export function isStanding(phase: IammaiPhase): boolean {
  return PHASE_FAMILY[phase] === 'standing';
}

/**
 * Get the current (latest) phase for a matter.
 */
export async function getCurrentPhase(matterRef: string): Promise<IammaiPhase | null> {
  const records = await getStateRecordsByMatter(matterRef);
  if (records.length === 0) return null;
  return records[records.length - 1].state_type;
}

/**
 * Get the full phase history for a matter.
 */
export async function getPhaseHistory(matterRef: string): Promise<IammaiStateRecord[]> {
  return getStateRecordsByMatter(matterRef);
}

/**
 * Advance a matter to the next phase.
 *
 * For the initial phase (signal), there is no predecessor.
 * For subsequent phases, the predecessor is the latest state record.
 *
 * @throws Error if the transition is invalid (skipped, backward, or terminal).
 */
export async function advancePhase(
  client: pg.PoolClient,
  matterRef: string,
  targetPhase: IammaiPhase,
  governanceActionId?: string | null
): Promise<{ stateRecord: IammaiStateRecord; transitionRecord: IammaiTransitionRecord | null }> {
  // Get current state
  const result = await client.query<{ state_id: string; state_type: string }>(
    'SELECT state_id, state_type FROM iammai_state_records WHERE matter_ref = $1 ORDER BY recorded_at DESC LIMIT 1',
    [matterRef]
  );
  const currentRecord = result.rows[0] ?? null;

  // If no current state, only 'signal' is valid entry
  if (!currentRecord) {
    if (targetPhase !== 'signal') {
      throw new Error('Cannot start at phase \'' + targetPhase + '\' - signal is the only valid entry point');
    }

    const stateRecord = createStateRecord({
      matter_ref: matterRef,
      state_type: 'signal',
      related_governance_ref: governanceActionId,
    });
    await insertStateRecord(client, stateRecord);
    return { stateRecord, transitionRecord: null };
  }

  const currentPhase = currentRecord.state_type as IammaiPhase;

  // Validate transition
  if (!isValidTransition(currentPhase, targetPhase)) {
    throw new Error(
      'Invalid phase transition: \'' + currentPhase + '\' => \'' + targetPhase + '\'. ' +
      'Expected: \'' + (VALID_TRANSITIONS[currentPhase] ?? 'none (terminal)') + '\''
    );
  }

  // Create new state record with predecessor
  const stateRecord = createStateRecord({
    matter_ref: matterRef,
    state_type: targetPhase,
    predecessor_ref: currentRecord.state_id,
    related_governance_ref: governanceActionId,
  });
  await insertStateRecord(client, stateRecord);

  // Create transition record
  const transitionKey = currentPhase + '_to_' + targetPhase;
  const transitionType = PHASE_TRANSITION_TYPE[transitionKey];

  if (!transitionType) {
    throw new Error('No transition type mapped for ' + transitionKey);
  }

  const transitionRecord = createTransitionRecord({
    matter_ref: matterRef,
    source_ref: currentRecord.state_id,
    target_ref: stateRecord.state_id,
    transition_type: transitionType,
  });
  await insertTransitionRecord(client, transitionRecord);

  return { stateRecord, transitionRecord };
}

/**
 * Advance through multiple phases in sequence.
 * Useful for operations that collapse multiple phases (e.g., create = signal + acceptance).
 */
export async function advancePhases(
  client: pg.PoolClient,
  matterRef: string,
  targetPhases: IammaiPhase[],
  governanceActionId?: string | null
): Promise<{ stateRecords: IammaiStateRecord[]; transitionRecords: IammaiTransitionRecord[] }> {
  const stateRecords: IammaiStateRecord[] = [];
  const transitionRecords: IammaiTransitionRecord[] = [];

  for (const phase of targetPhases) {
    const result = await advancePhase(client, matterRef, phase, governanceActionId);
    stateRecords.push(result.stateRecord);
    if (result.transitionRecord) {
      transitionRecords.push(result.transitionRecord);
    }
  }

  return { stateRecords, transitionRecords };
}
