/**
 * IAMMAI Canonical Record JSON Schemas
 *
 * Used by ajv for runtime validation of all 7 canonical record types.
 * @see .claude/skills/iammai/references/canonical-schemas.md
 */

import type { JSONSchemaType } from 'ajv';

// ============================================================================
// Shared enum values
// ============================================================================

const STATE_FAMILIES = ['preparation', 'standing'] as const;

const IAMMAI_PHASES = [
  'signal', 'acceptance', 'scope', 'presence', 'threshold',
  'truth', 'continuity', 'decision', 'consequence',
] as const;

const TRANSITION_TYPES = [
  'preparation_progression', 'threshold_eligibility', 'truth_formation',
  'continuity_transition', 'decision_transition', 'consequence_transition',
  'containment_apply', 'containment_release', 'resolution_transition',
] as const;

const RESOLUTION_TYPES = ['FINALIZE', 'INVALIDATE', 'EVOLVE'] as const;

const GOVERNANCE_ACTION_TYPES = [
  'authorize', 'deny', 'hold', 'release', 'finalize', 'invalidate', 'evolve',
] as const;

const AUTHORITY_CLASSES = ['SYSTEM', 'OPERATOR', 'DELEGATED'] as const;

const WITNESS_TYPES = [
  'interaction', 'validation', 'transition', 'publication', 'state_observation',
] as const;

const VALIDATION_TYPES = [
  'admissibility', 'threshold', 'transition_legality',
  'governance_precondition', 'bounded_consistency',
] as const;

const VALIDATION_OUTCOMES = ['pass', 'fail', 'blocked', 'indeterminate'] as const;

const CONTRIBUTION_ROLES = [
  'ORIGIN', 'ELICITATION', 'FORMALIZATION', 'AUTHORIZATION', 'RENDERING', 'TRANSMISSION',
] as const;

const CONTAINMENT_ACTIONS = ['HOLD', 'RELEASE'] as const;

// ============================================================================
// Schema definitions (plain objects for ajv)
// ============================================================================

/** State Record schema */
export const stateRecordSchema = {
  type: 'object' as const,
  properties: {
    state_id: { type: 'string' as const, minLength: 1 },
    matter_ref: { type: 'string' as const, minLength: 1 },
    state_family: { type: 'string' as const, enum: [...STATE_FAMILIES] },
    state_type: { type: 'string' as const, enum: [...IAMMAI_PHASES] },
    recorded_at: {},  // Date — validated separately
    predecessor_ref: { type: ['string', 'null'] as const },
    containment_ref: { type: ['string', 'null'] as const },
    related_transition_ref: { type: ['string', 'null'] as const },
    related_governance_ref: { type: ['string', 'null'] as const },
    related_validation_ref: { type: ['string', 'null'] as const },
    related_witness_ref: { type: ['string', 'null'] as const },
  },
  required: ['state_id', 'matter_ref', 'state_family', 'state_type', 'recorded_at'] as const,
  additionalProperties: true,
};

/** Transition Record schema */
export const transitionRecordSchema = {
  type: 'object' as const,
  properties: {
    transition_id: { type: 'string' as const, minLength: 1 },
    matter_ref: { type: 'string' as const, minLength: 1 },
    source_ref: { type: 'string' as const, minLength: 1 },
    target_ref: { type: 'string' as const, minLength: 1 },
    transition_type: { type: 'string' as const, enum: [...TRANSITION_TYPES] },
    occurred_at: {},
    resolution_type: { enum: [...RESOLUTION_TYPES, null] },
    predecessor_ref: { type: ['string', 'null'] as const },
  },
  required: ['transition_id', 'matter_ref', 'source_ref', 'target_ref', 'transition_type', 'occurred_at'] as const,
  additionalProperties: true,
};

/** Governance Action Record schema */
export const governanceActionSchema = {
  type: 'object' as const,
  properties: {
    governance_action_id: { type: 'string' as const, minLength: 1 },
    action_type: { type: 'string' as const, enum: [...GOVERNANCE_ACTION_TYPES] },
    authority_class: { type: 'string' as const, enum: [...AUTHORITY_CLASSES] },
    actor_ref: { type: 'string' as const, minLength: 1 },
    legitimacy_basis_ref: { type: 'string' as const, minLength: 1 },
    matter_ref: { type: 'string' as const, minLength: 1 },
    acted_at: {},
    delegated_from_ref: { type: ['string', 'null'] as const },
    target_state_ref: { type: ['string', 'null'] as const },
    target_transition_ref: { type: ['string', 'null'] as const },
    contribution_role_map_ref: { type: ['string', 'null'] as const },
  },
  required: [
    'governance_action_id', 'action_type', 'authority_class',
    'actor_ref', 'legitimacy_basis_ref', 'matter_ref', 'acted_at',
  ] as const,
  additionalProperties: true,
};

/** Witness Artifact schema */
export const witnessArtifactSchema = {
  type: 'object' as const,
  properties: {
    witness_id: { type: 'string' as const, minLength: 1 },
    witness_type: { type: 'string' as const, enum: [...WITNESS_TYPES] },
    target_ref: { type: 'string' as const, minLength: 1 },
    observed_at: {},
    claims: { type: 'array' as const, items: { type: 'string' as const } },
    non_claims: {
      type: 'object' as const,
      properties: {
        not_authorship: { type: 'boolean' as const, const: true },
        not_semantic_source: { type: 'boolean' as const, const: true },
        not_final_authority: { type: 'boolean' as const, const: true },
        not_automatic_truth_creation: { type: 'boolean' as const, const: true },
        not_governance_force: { type: 'boolean' as const, const: true },
      },
      required: [
        'not_authorship', 'not_semantic_source', 'not_final_authority',
        'not_automatic_truth_creation', 'not_governance_force',
      ] as const,
    },
    actor_ref: { type: ['string', 'null'] as const },
    surface_ref: { type: ['string', 'null'] as const },
  },
  required: ['witness_id', 'witness_type', 'target_ref', 'observed_at', 'claims', 'non_claims'] as const,
  additionalProperties: true,
};

/** Validation Artifact schema */
export const validationArtifactSchema = {
  type: 'object' as const,
  properties: {
    validation_id: { type: 'string' as const, minLength: 1 },
    validation_type: { type: 'string' as const, enum: [...VALIDATION_TYPES] },
    target_ref: { type: 'string' as const, minLength: 1 },
    condition_set_ref: { type: 'string' as const, minLength: 1 },
    outcome: { type: 'string' as const, enum: [...VALIDATION_OUTCOMES] },
    checked_at: {},
    reason_refs: { type: ['array', 'null'] as const, items: { type: 'string' as const } },
    actor_ref: { type: ['string', 'null'] as const },
  },
  required: ['validation_id', 'validation_type', 'target_ref', 'condition_set_ref', 'outcome', 'checked_at'] as const,
  additionalProperties: true,
};

/** Contribution Record schema */
export const contributionRecordSchema = {
  type: 'object' as const,
  properties: {
    contribution_id: { type: 'string' as const, minLength: 1 },
    matter_ref: { type: 'string' as const, minLength: 1 },
    actor_ref: { type: 'string' as const, minLength: 1 },
    role: { type: 'string' as const, enum: [...CONTRIBUTION_ROLES] },
    recorded_at: {},
    context_ref: { type: ['string', 'null'] as const },
  },
  required: ['contribution_id', 'matter_ref', 'actor_ref', 'role', 'recorded_at'] as const,
  additionalProperties: true,
};

/** Containment Record schema */
export const containmentRecordSchema = {
  type: 'object' as const,
  properties: {
    containment_id: { type: 'string' as const, minLength: 1 },
    matter_ref: { type: 'string' as const, minLength: 1 },
    target_state_ref: { type: 'string' as const, minLength: 1 },
    action: { type: 'string' as const, enum: [...CONTAINMENT_ACTIONS] },
    actor_ref: { type: 'string' as const, minLength: 1 },
    reason: { type: 'string' as const, minLength: 1 },
    recorded_at: {},
    governance_action_ref: { type: ['string', 'null'] as const },
  },
  required: ['containment_id', 'matter_ref', 'target_state_ref', 'action', 'actor_ref', 'reason', 'recorded_at'] as const,
  additionalProperties: true,
};
