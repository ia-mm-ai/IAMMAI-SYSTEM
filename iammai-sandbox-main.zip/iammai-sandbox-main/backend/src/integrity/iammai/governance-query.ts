/**
 * IAMMAI Governance Query — 8 Audit Questions
 *
 * All 8 questions must be answerable from canonical IAMMAI records alone.
 * This module provides structured answers from the registry data.
 *
 * The 8 questions:
 * 1. What phase is this matter in?
 * 2. What made it admissible?
 * 3. What stands (current standing-state)?
 * 4. What changed and how was it resolved?
 * 5. What is the predecessor/successor lineage?
 * 6. Who acted, with what authority, and on what basis?
 * 7. What contribution roles exist?
 * 8. What record preserves it?
 */

import type {
  IammaiEvaluationContext,
  IammaiStateRecord,
  IammaiTransitionRecord,
  IammaiGovernanceAction,
  IammaiContributionRecord,
  IammaiContainmentRecord,
  IammaiPhase,
  StateFamily,
  ResolutionType,
  ContributionRole,
  GovernanceActionType,
  AuthorityClass,
} from './types.js';
import { PHASE_FAMILY, PHASE_ORDINAL } from './types.js';

// ============================================================================
// Answer Types
// ============================================================================

export interface PhaseAnswer {
  question: 'Q1_CURRENT_PHASE';
  phase: IammaiPhase | null;
  family: StateFamily | null;
  ordinal: number | null;
  isHeld: boolean;
}

export interface AdmissibilityAnswer {
  question: 'Q2_ADMISSIBILITY';
  admissible: boolean;
  signalState: IammaiStateRecord | null;
  authorizingAction: IammaiGovernanceAction | null;
}

export interface StandingAnswer {
  question: 'Q3_STANDING';
  hasStanding: boolean;
  standingStates: IammaiStateRecord[];
  currentStandingPhase: IammaiPhase | null;
}

export interface ResolutionAnswer {
  question: 'Q4_RESOLUTION';
  resolved: boolean;
  resolutionType: ResolutionType | null;
  resolutionTransition: IammaiTransitionRecord | null;
  resolvingAction: IammaiGovernanceAction | null;
}

export interface LineageAnswer {
  question: 'Q5_LINEAGE';
  stateCount: number;
  firstState: IammaiStateRecord | null;
  lastState: IammaiStateRecord | null;
  hasExternalPredecessor: boolean;
  externalPredecessorRef: string | null;
}

export interface AttributionAnswer {
  question: 'Q6_ATTRIBUTION';
  actions: Array<{
    action_type: GovernanceActionType;
    actor_ref: string;
    authority_class: AuthorityClass;
    legitimacy_basis_ref: string;
    acted_at: Date;
  }>;
  uniqueActors: string[];
}

export interface ContributionAnswer {
  question: 'Q7_CONTRIBUTIONS';
  contributions: Array<{
    actor_ref: string;
    role: ContributionRole;
    recorded_at: Date;
  }>;
  rolesByActor: Record<string, ContributionRole[]>;
}

export interface PreservationAnswer {
  question: 'Q8_PRESERVATION';
  totalRecords: number;
  stateRecordCount: number;
  transitionRecordCount: number;
  governanceActionCount: number;
  witnessArtifactCount: number;
  validationArtifactCount: number;
  contributionRecordCount: number;
  containmentRecordCount: number;
}

export type AuditAnswer =
  | PhaseAnswer
  | AdmissibilityAnswer
  | StandingAnswer
  | ResolutionAnswer
  | LineageAnswer
  | AttributionAnswer
  | ContributionAnswer
  | PreservationAnswer;

// ============================================================================
// Query Functions
// ============================================================================

/**
 * Q1: What phase is this matter in?
 */
export function queryCurrentPhase(ctx: IammaiEvaluationContext): PhaseAnswer {
  const { stateRecords, containmentRecords } = ctx;

  if (stateRecords.length === 0) {
    return { question: 'Q1_CURRENT_PHASE', phase: null, family: null, ordinal: null, isHeld: false };
  }

  const latest = stateRecords[stateRecords.length - 1];
  const phase = latest.state_type;

  // Check if current state is held
  const stateContainments = containmentRecords
    .filter(r => r.target_state_ref === latest.state_id)
    .sort((a, b) => a.recorded_at.getTime() - b.recorded_at.getTime());
  const isHeld = stateContainments.length > 0 &&
    stateContainments[stateContainments.length - 1].action === 'HOLD';

  return {
    question: 'Q1_CURRENT_PHASE',
    phase,
    family: PHASE_FAMILY[phase],
    ordinal: PHASE_ORDINAL[phase],
    isHeld,
  };
}

/**
 * Q2: What made it admissible?
 */
export function queryAdmissibility(ctx: IammaiEvaluationContext): AdmissibilityAnswer {
  const { stateRecords, governanceActions } = ctx;

  const signalState = stateRecords.find(r => r.state_type === 'signal') ?? null;
  if (!signalState) {
    return { question: 'Q2_ADMISSIBILITY', admissible: false, signalState: null, authorizingAction: null };
  }

  // Find the authorizing governance action for the signal
  const authorizingAction = signalState.related_governance_ref
    ? governanceActions.find(a => a.governance_action_id === signalState.related_governance_ref) ?? null
    : governanceActions.find(a => a.action_type === 'authorize') ?? null;

  return {
    question: 'Q2_ADMISSIBILITY',
    admissible: true,
    signalState,
    authorizingAction,
  };
}

/**
 * Q3: What stands (current standing-state)?
 */
export function queryStanding(ctx: IammaiEvaluationContext): StandingAnswer {
  const { stateRecords } = ctx;

  const standingStates = stateRecords.filter(r => r.state_family === 'standing');
  const currentStandingPhase = standingStates.length > 0
    ? standingStates[standingStates.length - 1].state_type
    : null;

  return {
    question: 'Q3_STANDING',
    hasStanding: standingStates.length > 0,
    standingStates,
    currentStandingPhase,
  };
}

/**
 * Q4: What changed and how was it resolved?
 */
export function queryResolution(ctx: IammaiEvaluationContext): ResolutionAnswer {
  const { transitionRecords, governanceActions } = ctx;

  const resolutionTransition = transitionRecords.find(
    t => t.transition_type === 'resolution_transition'
  ) ?? null;

  if (!resolutionTransition) {
    return {
      question: 'Q4_RESOLUTION',
      resolved: false,
      resolutionType: null,
      resolutionTransition: null,
      resolvingAction: null,
    };
  }

  const resolutionType = resolutionTransition.resolution_type;
  const expectedActionType = resolutionType?.toLowerCase();
  const resolvingAction = governanceActions.find(
    a => a.action_type === expectedActionType
  ) ?? null;

  return {
    question: 'Q4_RESOLUTION',
    resolved: true,
    resolutionType,
    resolutionTransition,
    resolvingAction,
  };
}

/**
 * Q5: What is the predecessor/successor lineage?
 */
export function queryLineage(ctx: IammaiEvaluationContext): LineageAnswer {
  const { stateRecords } = ctx;

  if (stateRecords.length === 0) {
    return {
      question: 'Q5_LINEAGE',
      stateCount: 0,
      firstState: null,
      lastState: null,
      hasExternalPredecessor: false,
      externalPredecessorRef: null,
    };
  }

  const firstState = stateRecords[0];
  const lastState = stateRecords[stateRecords.length - 1];

  // Check if the first state has an external predecessor (EVOLVE'd matter)
  const stateIds = new Set(stateRecords.map(r => r.state_id));
  const hasExternalPredecessor = firstState.predecessor_ref !== null &&
    !stateIds.has(firstState.predecessor_ref);

  return {
    question: 'Q5_LINEAGE',
    stateCount: stateRecords.length,
    firstState,
    lastState,
    hasExternalPredecessor,
    externalPredecessorRef: hasExternalPredecessor ? firstState.predecessor_ref : null,
  };
}

/**
 * Q6: Who acted, with what authority, and on what basis?
 */
export function queryAttribution(ctx: IammaiEvaluationContext): AttributionAnswer {
  const { governanceActions } = ctx;

  const actions = governanceActions.map(a => ({
    action_type: a.action_type,
    actor_ref: a.actor_ref,
    authority_class: a.authority_class,
    legitimacy_basis_ref: a.legitimacy_basis_ref,
    acted_at: a.acted_at,
  }));

  const uniqueActors = [...new Set(governanceActions.map(a => a.actor_ref))];

  return {
    question: 'Q6_ATTRIBUTION',
    actions,
    uniqueActors,
  };
}

/**
 * Q7: What contribution roles exist?
 */
export function queryContributions(ctx: IammaiEvaluationContext): ContributionAnswer {
  const { contributionRecords } = ctx;

  const contributions = contributionRecords.map(c => ({
    actor_ref: c.actor_ref,
    role: c.role,
    recorded_at: c.recorded_at,
  }));

  const rolesByActor: Record<string, ContributionRole[]> = {};
  for (const c of contributionRecords) {
    if (!rolesByActor[c.actor_ref]) {
      rolesByActor[c.actor_ref] = [];
    }
    rolesByActor[c.actor_ref].push(c.role);
  }

  return {
    question: 'Q7_CONTRIBUTIONS',
    contributions,
    rolesByActor,
  };
}

/**
 * Q8: What record preserves it?
 */
export function queryPreservation(ctx: IammaiEvaluationContext): PreservationAnswer {
  return {
    question: 'Q8_PRESERVATION',
    totalRecords:
      ctx.stateRecords.length +
      ctx.transitionRecords.length +
      ctx.governanceActions.length +
      ctx.witnessArtifacts.length +
      ctx.validationArtifacts.length +
      ctx.contributionRecords.length +
      ctx.containmentRecords.length,
    stateRecordCount: ctx.stateRecords.length,
    transitionRecordCount: ctx.transitionRecords.length,
    governanceActionCount: ctx.governanceActions.length,
    witnessArtifactCount: ctx.witnessArtifacts.length,
    validationArtifactCount: ctx.validationArtifacts.length,
    contributionRecordCount: ctx.contributionRecords.length,
    containmentRecordCount: ctx.containmentRecords.length,
  };
}

/**
 * Run all 8 audit queries and return structured answers.
 */
export function auditMatter(ctx: IammaiEvaluationContext): AuditAnswer[] {
  return [
    queryCurrentPhase(ctx),
    queryAdmissibility(ctx),
    queryStanding(ctx),
    queryResolution(ctx),
    queryLineage(ctx),
    queryAttribution(ctx),
    queryContributions(ctx),
    queryPreservation(ctx),
  ];
}
