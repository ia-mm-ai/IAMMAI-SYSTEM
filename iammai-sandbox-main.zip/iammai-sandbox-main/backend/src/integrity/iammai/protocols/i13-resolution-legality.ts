/**
 * I.13 — Resolution Legality
 *
 * Checks that resolution actions comply with IAMMAI constitutional constraints:
 * 1. Only FINALIZE, INVALIDATE, or EVOLVE resolution types are used
 * 2. EVOLVE transitions have a predecessor_ref (lineage to successor)
 * 3. Resolution only occurs from standing-state regime phases
 * 4. Resolution governance action exists for each resolution transition
 *
 * Only applies to iammai_tracked sessions.
 */

import type { ProtocolEvaluator, EvaluationContext, ProtocolResult } from '../../types.js';
import { PHASE_FAMILY } from '../types.js';
import type { IammaiPhase, ResolutionType } from '../types.js';

const PROTOCOL_ID = 'I.13';
const PROTOCOL_VERSION = '1.0.0';
const VALID_RESOLUTION_TYPES: ResolutionType[] = ['FINALIZE', 'INVALIDATE', 'EVOLVE'];

export class I13ResolutionLegality implements ProtocolEvaluator {
  readonly id = PROTOCOL_ID;
  readonly version = PROTOCOL_VERSION;

  evaluate(context: EvaluationContext): ProtocolResult {
    // Skip non-IAMMAI sessions
    if (!context.session.iammaiTracked) {
      return { protocol: PROTOCOL_ID, result: 'PASS', details: 'Non-IAMMAI session — not evaluated' };
    }

    const iammaiCtx = context.iammaiContext;
    if (!iammaiCtx) {
      return { protocol: PROTOCOL_ID, result: 'FAIL', details: 'IAMMAI context not loaded' };
    }

    const { transitionRecords, governanceActions, stateRecords } = iammaiCtx;

    // Find all resolution transitions
    const resolutionTransitions = transitionRecords.filter(
      t => t.transition_type === 'resolution_transition'
    );

    // If no resolutions, nothing to check (session may still be active)
    if (resolutionTransitions.length === 0) {
      return {
        protocol: PROTOCOL_ID,
        result: 'PASS',
        details: 'No resolution transitions — nothing to validate',
      };
    }

    // Check each resolution transition
    for (const transition of resolutionTransitions) {
      // 1. Resolution type must be in the closed set
      if (!transition.resolution_type) {
        return {
          protocol: PROTOCOL_ID,
          result: 'FAIL',
          details: 'Resolution transition ' + transition.transition_id + ' has no resolution_type',
        };
      }

      if (!VALID_RESOLUTION_TYPES.includes(transition.resolution_type)) {
        return {
          protocol: PROTOCOL_ID,
          result: 'FAIL',
          details: 'Invalid resolution type: ' + transition.resolution_type +
            '. Must be FINALIZE, INVALIDATE, or EVOLVE',
        };
      }

      // 2. EVOLVE must have a target that differs from source (successor linkage)
      if (transition.resolution_type === 'EVOLVE') {
        if (transition.source_ref === transition.target_ref) {
          return {
            protocol: PROTOCOL_ID,
            result: 'FAIL',
            details: 'EVOLVE resolution must create a successor (target_ref must differ from source_ref)',
          };
        }
      }

      // 3. Source state must be in standing-state regime
      const sourceState = stateRecords.find(s => s.state_id === transition.source_ref);
      if (!sourceState) {
        return {
          protocol: PROTOCOL_ID,
          result: 'FAIL',
          details: 'Resolution source state ' + transition.source_ref + ' not found in state records',
        };
      }

      const sourceFamily = PHASE_FAMILY[sourceState.state_type as IammaiPhase];
      if (sourceFamily !== 'standing') {
        return {
          protocol: PROTOCOL_ID,
          result: 'FAIL',
          details: 'Resolution from preparation phase \'' + sourceState.state_type +
            '\' — resolution requires standing-state regime',
        };
      }

      // 4. Must have a matching governance action (finalize/invalidate/evolve)
      const expectedActionType = transition.resolution_type.toLowerCase();
      const matchingAction = governanceActions.find(
        a => a.action_type === expectedActionType && a.matter_ref === transition.matter_ref
      );
      if (!matchingAction) {
        return {
          protocol: PROTOCOL_ID,
          result: 'FAIL',
          details: 'No governance action of type \'' + expectedActionType +
            '\' found for resolution on matter ' + transition.matter_ref,
        };
      }
    }

    return {
      protocol: PROTOCOL_ID,
      result: 'PASS',
      details: resolutionTransitions.length + ' resolution transition(s) verified: ' +
        'types valid, standing-state confirmed, governance actions present',
    };
  }
}
