/**
 * I.12 — Containment Orthogonality
 *
 * Checks that containment (HOLD/RELEASE) is truly orthogonal:
 * 1. Every HOLD has a matching governance action
 * 2. Every RELEASE has a matching governance action
 * 3. Held states were not resolved (no resolution_transition on held states)
 * 4. Held states did not transition to next phase while held
 * 5. Containment does NOT change phase identity (state_type unchanged)
 * 6. No stacking — no double HOLD without intervening RELEASE
 *
 * Only applies to iammai_tracked sessions.
 */

import type { ProtocolEvaluator, EvaluationContext, ProtocolResult } from '../../types.js';
import type { IammaiContainmentRecord } from '../types.js';

const PROTOCOL_ID = 'I.12';
const PROTOCOL_VERSION = '1.0.0';

export class I12ContainmentOrthogonality implements ProtocolEvaluator {
  readonly id = PROTOCOL_ID;
  readonly version = PROTOCOL_VERSION;

  evaluate(context: EvaluationContext): ProtocolResult {
    // Skip non-IAMMAI sessions
    if (!context.session.iammaiTracked) {
      return { protocol: PROTOCOL_ID, result: 'PASS', details: 'Non-IAMMAI session — not evaluated' };
    }

    const iammaiCtx = context.iammaiContext;
    if (!iammaiCtx) {
      return { protocol: PROTOCOL_ID, result: 'FAIL', details: 'IAMMAI context not loaded' };
    }

    const { containmentRecords, governanceActions, stateRecords, transitionRecords } = iammaiCtx;

    // If no containment records, nothing to check
    if (containmentRecords.length === 0) {
      return {
        protocol: PROTOCOL_ID,
        result: 'PASS',
        details: 'No containment records — nothing to validate',
      };
    }

    // Build governance action ID set for quick lookup
    const governanceActionIds = new Set(governanceActions.map(a => a.governance_action_id));

    // Build state record lookup
    const stateById = new Map(stateRecords.map(s => [s.state_id, s]));

    // Track HOLD/RELEASE sequence per state
    const holdSequenceByState = new Map<string, IammaiContainmentRecord[]>();

    for (const record of containmentRecords) {
      // 1 & 2. Every containment action must have a governance action
      if (!record.governance_action_ref) {
        return {
          protocol: PROTOCOL_ID,
          result: 'FAIL',
          details: record.action + ' on state ' + record.target_state_ref +
            ' has no governance_action_ref',
        };
      }

      if (!governanceActionIds.has(record.governance_action_ref)) {
        return {
          protocol: PROTOCOL_ID,
          result: 'FAIL',
          details: record.action + ' on state ' + record.target_state_ref +
            ' references governance action ' + record.governance_action_ref +
            ' which does not exist',
        };
      }

      // Track sequence per state
      if (!holdSequenceByState.has(record.target_state_ref)) {
        holdSequenceByState.set(record.target_state_ref, []);
      }
      holdSequenceByState.get(record.target_state_ref)!.push(record);
    }

    // Check per-state constraints
    for (const [stateRef, records] of holdSequenceByState) {
      // Sort by recorded_at
      records.sort((a, b) => a.recorded_at.getTime() - b.recorded_at.getTime());

      // 6. No stacking — sequence must alternate HOLD/RELEASE, starting with HOLD
      for (let i = 0; i < records.length; i++) {
        const expected = i % 2 === 0 ? 'HOLD' : 'RELEASE';
        if (records[i].action !== expected) {
          return {
            protocol: PROTOCOL_ID,
            result: 'FAIL',
            details: 'Containment sequence violation on state ' + stateRef +
              ': expected ' + expected + ' but got ' + records[i].action +
              ' at position ' + i,
          };
        }
      }

      // 5. Containment does NOT change phase identity
      const state = stateById.get(stateRef);
      if (!state) {
        return {
          protocol: PROTOCOL_ID,
          result: 'FAIL',
          details: 'Containment target state ' + stateRef + ' not found in state records',
        };
      }

      // Determine held periods (HOLD time to RELEASE time, or HOLD to now if still held)
      const heldPeriods: Array<{ from: Date; to: Date | null }> = [];
      for (let i = 0; i < records.length; i += 2) {
        const holdRecord = records[i];
        const releaseRecord = records[i + 1] ?? null;
        heldPeriods.push({
          from: holdRecord.recorded_at,
          to: releaseRecord?.recorded_at ?? null,
        });
      }

      // 3. Held states must not have been resolved during held periods
      const resolutionTransitions = transitionRecords.filter(
        t => t.transition_type === 'resolution_transition' && t.source_ref === stateRef
      );
      for (const resolution of resolutionTransitions) {
        for (const period of heldPeriods) {
          const resolvedAt = resolution.occurred_at.getTime();
          const holdFrom = period.from.getTime();
          const holdTo = period.to?.getTime() ?? Infinity;
          if (resolvedAt >= holdFrom && resolvedAt <= holdTo) {
            return {
              protocol: PROTOCOL_ID,
              result: 'FAIL',
              details: 'Held state ' + stateRef + ' was resolved during containment period',
            };
          }
        }
      }

      // 4. Held states must not have transitioned to next phase during held periods
      const outgoingTransitions = transitionRecords.filter(
        t => t.source_ref === stateRef && t.transition_type !== 'resolution_transition'
      );
      for (const transition of outgoingTransitions) {
        for (const period of heldPeriods) {
          const transitionedAt = transition.occurred_at.getTime();
          const holdFrom = period.from.getTime();
          const holdTo = period.to?.getTime() ?? Infinity;
          if (transitionedAt >= holdFrom && transitionedAt <= holdTo) {
            return {
              protocol: PROTOCOL_ID,
              result: 'FAIL',
              details: 'Held state ' + stateRef + ' transitioned during containment period',
            };
          }
        }
      }
    }

    return {
      protocol: PROTOCOL_ID,
      result: 'PASS',
      details: containmentRecords.length + ' containment record(s) verified: ' +
        'governance actions present, orthogonality maintained, no held-state violations',
    };
  }
}
