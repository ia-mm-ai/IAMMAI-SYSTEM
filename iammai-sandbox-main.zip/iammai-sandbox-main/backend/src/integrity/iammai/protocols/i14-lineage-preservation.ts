/**
 * I.14 — Lineage Preservation
 *
 * Checks that every state record maintains a contiguous predecessor chain:
 * 1. First state record (signal) has predecessor_ref = null (unless EVOLVE'd)
 * 2. Every subsequent state record has a valid predecessor_ref
 * 3. Predecessor_ref points to an existing state record
 * 4. No orphan state records (disconnected from the chain)
 * 5. Predecessor chain forms a single linked list (no forks)
 *
 * Only applies to iammai_tracked sessions.
 */

import type { ProtocolEvaluator, EvaluationContext, ProtocolResult } from '../../types.js';

const PROTOCOL_ID = 'I.14';
const PROTOCOL_VERSION = '1.0.0';

export class I14LineagePreservation implements ProtocolEvaluator {
  readonly id = PROTOCOL_ID;
  readonly version = PROTOCOL_VERSION;

  evaluate(context: EvaluationContext): ProtocolResult {
    // Skip non-IAMMAI sessions
    if (!context.session.iammaiTracked) {
      return { protocol: PROTOCOL_ID, result: 'PASS', details: 'Non-IAMMAI session — not evaluated' };
    }

    const iammaiCtx = context.iammaiContext;
    if (!iammaiCtx) {
      return { protocol: PROTOCOL_ID, result: 'FAIL', details: 'IAMMAI context not loaded' };
    }

    const { stateRecords } = iammaiCtx;
    if (stateRecords.length === 0) {
      return { protocol: PROTOCOL_ID, result: 'FAIL', details: 'No state records found' };
    }

    // Build lookup set of all state IDs
    const stateIds = new Set(stateRecords.map(r => r.state_id));

    // 1. First record: predecessor_ref must be null OR point to an external state
    //    (EVOLVE'd matters have predecessor_ref pointing to predecessor matter's state)
    const firstRecord = stateRecords[0];
    if (firstRecord.predecessor_ref !== null && stateIds.has(firstRecord.predecessor_ref)) {
      // If the predecessor is within the same matter's records, that's a cycle error
      return {
        protocol: PROTOCOL_ID,
        result: 'FAIL',
        details: 'First state record has predecessor_ref pointing to own matter — potential cycle',
      };
    }

    // 2. Every subsequent record must have a predecessor_ref
    for (let i = 1; i < stateRecords.length; i++) {
      const record = stateRecords[i];
      if (record.predecessor_ref === null) {
        return {
          protocol: PROTOCOL_ID,
          result: 'FAIL',
          details: 'State record ' + record.state_id + ' (phase: ' + record.state_type +
            ') has no predecessor_ref — lineage broken',
        };
      }

      // 3. predecessor_ref must point to an existing state record in this matter
      if (!stateIds.has(record.predecessor_ref)) {
        return {
          protocol: PROTOCOL_ID,
          result: 'FAIL',
          details: 'State record ' + record.state_id + ' has predecessor_ref ' +
            record.predecessor_ref + ' which does not exist in this matter\'s state records',
        };
      }
    }

    // 4. Verify chain contiguity: each record's predecessor should be the previous record
    for (let i = 1; i < stateRecords.length; i++) {
      const record = stateRecords[i];
      const expectedPredecessor = stateRecords[i - 1].state_id;
      if (record.predecessor_ref !== expectedPredecessor) {
        return {
          protocol: PROTOCOL_ID,
          result: 'FAIL',
          details: 'Lineage gap: state record ' + record.state_id +
            ' (phase: ' + record.state_type + ') predecessor_ref is ' +
            record.predecessor_ref + ', expected ' + expectedPredecessor,
        };
      }
    }

    // 5. Check no duplicate predecessor references (no forks)
    const predecessorRefs = stateRecords
      .slice(1)
      .map(r => r.predecessor_ref)
      .filter((ref): ref is string => ref !== null);
    const uniquePredecessors = new Set(predecessorRefs);
    if (uniquePredecessors.size !== predecessorRefs.length) {
      return {
        protocol: PROTOCOL_ID,
        result: 'FAIL',
        details: 'Forked lineage detected: multiple state records share the same predecessor_ref',
      };
    }

    return {
      protocol: PROTOCOL_ID,
      result: 'PASS',
      details: stateRecords.length + ' state records form a contiguous predecessor chain',
    };
  }
}
