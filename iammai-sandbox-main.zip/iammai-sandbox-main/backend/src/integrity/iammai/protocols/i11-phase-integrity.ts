/**
 * I.11 — Phase Integrity
 *
 * Checks that all 9 IAMMAI phases are distinguishable in state records,
 * correct ordering, no skipped phases, preparation precedes standing.
 * Only applies to iammai_tracked sessions.
 */

import type { ProtocolEvaluator, EvaluationContext, ProtocolResult } from '../../types.js';
import { PHASE_ORDINAL, PHASE_FAMILY, PHASES_IN_ORDER } from '../types.js';
import type { IammaiPhase } from '../types.js';

const PROTOCOL_ID = 'I.11';
const PROTOCOL_VERSION = '1.0.0';

export class I11PhaseIntegrity implements ProtocolEvaluator {
  readonly id = PROTOCOL_ID;
  readonly version = PROTOCOL_VERSION;

  evaluate(context: EvaluationContext): ProtocolResult {
    // Skip non-IAMMAI sessions
    if (!context.session.iammaiTracked) {
      return { protocol: PROTOCOL_ID, result: 'PASS', details: 'Non-IAMMAI session — not evaluated' };
    }

    const iammaiCtx = context.iammaiContext;
    if (!iammaiCtx) {
      return { protocol: PROTOCOL_ID, result: 'FAIL', details: 'IAMMAI context not loaded' };
    }

    const { stateRecords } = iammaiCtx;
    if (stateRecords.length === 0) {
      return { protocol: PROTOCOL_ID, result: 'FAIL', details: 'No state records found' };
    }

    // Extract phases in order
    const phases = stateRecords.map(r => r.state_type);

    // Check for duplicate phases
    const uniquePhases = new Set(phases);
    if (uniquePhases.size !== phases.length) {
      return { protocol: PROTOCOL_ID, result: 'FAIL', details: 'Duplicate phases detected' };
    }

    // Check ordinals are monotonically increasing
    for (let i = 1; i < phases.length; i++) {
      const prevOrdinal = PHASE_ORDINAL[phases[i - 1]];
      const currOrdinal = PHASE_ORDINAL[phases[i]];
      if (currOrdinal <= prevOrdinal) {
        return {
          protocol: PROTOCOL_ID,
          result: 'FAIL',
          details: `Phase order violation: '${phases[i - 1]}' (${prevOrdinal}) followed by '${phases[i]}' (${currOrdinal})`,
        };
      }
    }

    // Check no phases skipped (consecutive ordinals)
    for (let i = 1; i < phases.length; i++) {
      const prevOrdinal = PHASE_ORDINAL[phases[i - 1]];
      const currOrdinal = PHASE_ORDINAL[phases[i]];
      if (currOrdinal !== prevOrdinal + 1) {
        return {
          protocol: PROTOCOL_ID,
          result: 'FAIL',
          details: `Phase skipped: '${phases[i - 1]}' (${prevOrdinal}) to '${phases[i]}' (${currOrdinal})`,
        };
      }
    }

    // Check preparation precedes standing
    let seenStanding = false;
    for (const phase of phases) {
      const family = PHASE_FAMILY[phase];
      if (family === 'standing') {
        seenStanding = true;
      } else if (seenStanding) {
        return {
          protocol: PROTOCOL_ID,
          result: 'FAIL',
          details: `Preparation phase '${phase}' found after standing-state phase`,
        };
      }
    }

    // Check state_family matches phase
    for (const record of stateRecords) {
      const expectedFamily = PHASE_FAMILY[record.state_type];
      if (record.state_family !== expectedFamily) {
        return {
          protocol: PROTOCOL_ID,
          result: 'FAIL',
          details: `State family mismatch: phase '${record.state_type}' has family '${record.state_family}', expected '${expectedFamily}'`,
        };
      }
    }

    // Check first phase is signal
    if (phases[0] !== 'signal') {
      return {
        protocol: PROTOCOL_ID,
        result: 'FAIL',
        details: `First phase is '${phases[0]}', expected 'signal'`,
      };
    }

    return {
      protocol: PROTOCOL_ID,
      result: 'PASS',
      details: `${phases.length} phases verified in canonical order`,
    };
  }
}
