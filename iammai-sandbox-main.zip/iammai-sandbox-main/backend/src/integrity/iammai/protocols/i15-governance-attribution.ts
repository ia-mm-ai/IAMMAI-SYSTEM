/**
 * I.15 — Governance Attribution
 *
 * Every governance action must have:
 * 1. actor_ref — who acted
 * 2. authority_class — under what authority (SYSTEM/OPERATOR/DELEGATED)
 * 3. legitimacy_basis_ref — on what basis
 * 4. matter_ref — authority is matter-scoped (authorization on matter A
 *    does NOT grant authorization on matter B)
 *
 * Only applies to iammai_tracked sessions.
 */

import type { ProtocolEvaluator, EvaluationContext, ProtocolResult } from '../../types.js';

const PROTOCOL_ID = 'I.15';
const PROTOCOL_VERSION = '1.0.0';

const VALID_AUTHORITY_CLASSES = ['SYSTEM', 'OPERATOR', 'DELEGATED'];

export class I15GovernanceAttribution implements ProtocolEvaluator {
  readonly id = PROTOCOL_ID;
  readonly version = PROTOCOL_VERSION;

  evaluate(context: EvaluationContext): ProtocolResult {
    // Skip non-IAMMAI sessions
    if (!context.session.iammaiTracked) {
      return { protocol: PROTOCOL_ID, result: 'PASS', details: 'Non-IAMMAI session — not evaluated' };
    }

    const iammaiCtx = context.iammaiContext;
    if (!iammaiCtx) {
      return { protocol: PROTOCOL_ID, result: 'FAIL', details: 'IAMMAI context not loaded' };
    }

    const { governanceActions } = iammaiCtx;
    if (governanceActions.length === 0) {
      return { protocol: PROTOCOL_ID, result: 'PASS', details: 'No governance actions to evaluate' };
    }

    // Check every governance action has complete attribution
    for (const action of governanceActions) {
      if (!action.actor_ref) {
        return {
          protocol: PROTOCOL_ID,
          result: 'FAIL',
          details: `Governance action ${action.governance_action_id} missing actor_ref`,
        };
      }

      if (!action.authority_class || !VALID_AUTHORITY_CLASSES.includes(action.authority_class)) {
        return {
          protocol: PROTOCOL_ID,
          result: 'FAIL',
          details: `Governance action ${action.governance_action_id} has invalid authority_class: '${action.authority_class}'`,
        };
      }

      if (!action.legitimacy_basis_ref) {
        return {
          protocol: PROTOCOL_ID,
          result: 'FAIL',
          details: `Governance action ${action.governance_action_id} missing legitimacy_basis_ref`,
        };
      }

      if (!action.matter_ref) {
        return {
          protocol: PROTOCOL_ID,
          result: 'FAIL',
          details: `Governance action ${action.governance_action_id} missing matter_ref`,
        };
      }
    }

    // Check matter-scoping: all actions should reference the same matter
    const matterRefs = new Set(governanceActions.map(a => a.matter_ref));
    // Multiple matters is fine (e.g., EVOLVE creates successor matter),
    // but each action must have its own matter_ref

    return {
      protocol: PROTOCOL_ID,
      result: 'PASS',
      details: `${governanceActions.length} governance actions verified with complete attribution across ${matterRefs.size} matter(s)`,
    };
  }
}
