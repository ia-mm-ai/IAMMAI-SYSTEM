/**
 * Append-only integrity ledger service.
 * Provides append and validation operations — no update or delete.
 * @see specs/005-structural-foundation/data-model.md
 * @see specs/005-structural-foundation/spec.md US2
 */

import type pg from 'pg';
import { query } from '../lib/db.js';
import type { SessionState } from '../lib/types.js';
import type {
  IntegrityEventType,
  MetadataSnapshot,
  LedgerEntry,
  HashChainValidationResult,
} from './types.js';
import { computeEntryHash, validateHashChain } from './hash.js';

interface LedgerRow {
  id: string;
  sequence_number: string; // BIGINT comes as string from pg
  session_id: string;
  event_type: IntegrityEventType;
  timestamp: Date;
  from_state: SessionState | null;
  to_state: string;
  metadata_snapshot: MetadataSnapshot;
  previous_hash: string | null;
  entry_hash: string;
}

function rowToEntry(row: LedgerRow): LedgerEntry {
  return {
    id: row.id,
    sequenceNumber: parseInt(row.sequence_number, 10),
    sessionId: row.session_id,
    eventType: row.event_type,
    timestamp: row.timestamp,
    fromState: row.from_state,
    toState: row.to_state,
    metadataSnapshot: row.metadata_snapshot,
    previousHash: row.previous_hash,
    entryHash: row.entry_hash,
  };
}

/**
 * Append a new entry to the integrity ledger.
 * Must be called within a transaction for atomicity with state changes.
 *
 * The entry's hash is computed from the previous entry's hash plus this entry's data,
 * forming a tamper-evident chain.
 */
export async function appendEntry(
  client: pg.PoolClient,
  sessionId: string,
  eventType: IntegrityEventType,
  fromState: SessionState | null,
  toState: string,
  metadataSnapshot: MetadataSnapshot
): Promise<LedgerEntry> {
  // Get the last entry's hash and sequence for chain linkage (lock for safety)
  const lastResult = await client.query<{ entry_hash: string; sequence_number: string }>(
    'SELECT entry_hash, sequence_number FROM integrity_ledger ORDER BY sequence_number DESC LIMIT 1 FOR UPDATE'
  );

  const previousHash = lastResult.rows[0]?.entry_hash ?? null;
  const nextSequence = lastResult.rows[0]
    ? parseInt(lastResult.rows[0].sequence_number, 10) + 1
    : 1;

  const timestamp = new Date();
  const entryHash = computeEntryHash(
    previousHash,
    nextSequence,
    sessionId,
    eventType,
    timestamp.toISOString(),
    metadataSnapshot
  );

  const result = await client.query<LedgerRow>(
    `INSERT INTO integrity_ledger
       (sequence_number, session_id, event_type, timestamp, from_state, to_state, metadata_snapshot, previous_hash, entry_hash)
     VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9)
     RETURNING *`,
    [
      nextSequence,
      sessionId,
      eventType,
      timestamp,
      fromState,
      toState,
      JSON.stringify(metadataSnapshot),
      previousHash,
      entryHash,
    ]
  );

  const row = result.rows[0];
  if (!row) {
    throw new Error('Failed to append ledger entry');
  }

  return rowToEntry(row);
}

/**
 * Get all ledger entries for a session, ordered by sequence number.
 */
export async function getEntriesBySession(sessionId: string): Promise<LedgerEntry[]> {
  const result = await query<LedgerRow>(
    'SELECT * FROM integrity_ledger WHERE session_id = $1 ORDER BY sequence_number ASC',
    [sessionId]
  );
  return result.rows.map(rowToEntry);
}

/**
 * Validate the hash chain integrity of the entire ledger.
 * Fetches all entries and recomputes each hash to verify the chain is intact.
 */
export async function validateChain(): Promise<HashChainValidationResult> {
  const result = await query<LedgerRow>(
    'SELECT * FROM integrity_ledger ORDER BY sequence_number ASC'
  );
  const entries = result.rows.map(rowToEntry);
  return validateHashChain(entries);
}
