/**
 * Acedia monitor — detects and resolves stalled sessions via timer-based polling.
 * Records acedia lifecycle events in the integrity ledger.
 * @see specs/008-governance-protocols/contracts/acedia-monitor.md
 */

import { query, transaction } from '../lib/db.js';
import * as sessionModel from '../models/session.js';
import { appendEntry } from './ledger.js';
import { buildMetadataSnapshot } from './state-observer.js';
import { logger } from '../lib/logger.js';
import type {
  AcediaThresholds,
  AcediaPhase,
  AcediaState,
  IntegrityEventType,
} from './types.js';
import type { Session, SessionState } from '../lib/types.js';

// Default thresholds from Framework Decision 6
const DEFAULT_THRESHOLDS: AcediaThresholds = {
  createdIdleMs: 15 * 60 * 1000,  // 15 minutes
  activeIdleMs: 30 * 60 * 1000,   // 30 minutes
  countdownMs: 10 * 60 * 1000,    // 10 minutes
  checkIntervalMs: 60 * 1000,     // 60 seconds
};

// In-memory acedia state per session
const acediaStates = new Map<string, AcediaState>();

let monitorInterval: ReturnType<typeof setInterval> | null = null;
let activeThresholds: AcediaThresholds = DEFAULT_THRESHOLDS;

/**
 * Start the background acedia monitoring process.
 * Idempotent — calling when already running has no effect.
 */
export function startMonitor(thresholds?: Partial<AcediaThresholds>): void {
  if (monitorInterval !== null) {
    return; // Already running
  }

  activeThresholds = { ...DEFAULT_THRESHOLDS, ...thresholds };

  monitorInterval = setInterval(() => {
    checkSessions().catch(err => {
      logger.error('Acedia monitor check failed', { error: err });
    });
  }, activeThresholds.checkIntervalMs);

  logger.info('Acedia monitor started', {
    checkIntervalMs: activeThresholds.checkIntervalMs,
    createdIdleMs: activeThresholds.createdIdleMs,
    activeIdleMs: activeThresholds.activeIdleMs,
    countdownMs: activeThresholds.countdownMs,
  });
}

/**
 * Stop the background acedia monitoring process.
 * Idempotent — calling when not running has no effect.
 */
export function stopMonitor(): void {
  if (monitorInterval !== null) {
    clearInterval(monitorInterval);
    monitorInterval = null;
    logger.info('Acedia monitor stopped');
  }
}

/**
 * Check all CREATED and ACTIVE sessions for acedia conditions.
 * Transitions acedia phases and force-releases sessions when needed.
 */
export async function checkSessions(): Promise<void> {
  const now = new Date();

  // Query all sessions in CREATED or ACTIVE state
  const result = await query<{
    id: string;
    state: SessionState;
    name: string;
    created_at: Date;
    started_at: Date | null;
    ended_at: Date | null;
    token_count: number;
    user_count: number;
    admin_id: string;
    context_descriptor: Session['contextDescriptor'];
    environmental_constraints: Session['environmentalConstraints'];
  }>(
    `SELECT id, state, name, created_at, started_at, ended_at,
            token_count, user_count, admin_id,
            context_descriptor, environmental_constraints
     FROM sessions
     WHERE state IN ('CREATED', 'ACTIVE')`,
    []
  );

  for (const row of result.rows) {
    try {
      await processSession(row.id, row.state, now, {
        id: row.id,
        name: row.name,
        state: row.state,
        createdAt: new Date(row.created_at),
        startedAt: row.started_at ? new Date(row.started_at) : null,
        endedAt: row.ended_at ? new Date(row.ended_at) : null,
        tokenCount: row.token_count,
        userCount: row.user_count,
        adminId: row.admin_id,
        contextDescriptor: row.context_descriptor,
        environmentalConstraints: row.environmental_constraints,
        iammaiTracked: false,
      });
    } catch (err) {
      logger.error('Acedia: error processing session', { sessionId: row.id, error: err });
    }
  }
}

/**
 * Process a single session for acedia conditions.
 */
async function processSession(
  sessionId: string,
  state: SessionState,
  now: Date,
  session: Session
): Promise<void> {
  // Get or initialize acedia state
  let acediaState = acediaStates.get(sessionId);
  if (!acediaState) {
    acediaState = {
      sessionId,
      phase: 'NORMAL',
      lastActivityAt: session.startedAt ?? session.createdAt,
      countdownStartedAt: null,
    };
    acediaStates.set(sessionId, acediaState);
  }

  const idleMs = now.getTime() - acediaState.lastActivityAt.getTime();

  if (acediaState.phase === 'COUNTDOWN') {
    // Check if countdown has expired
    const countdownMs = now.getTime() - acediaState.countdownStartedAt!.getTime();
    if (countdownMs >= activeThresholds.countdownMs) {
      await forceReleaseSession(sessionId, session, acediaState);
    }
    return;
  }

  if (state === 'CREATED' && acediaState.phase === 'NORMAL' && idleMs >= activeThresholds.createdIdleMs) {
    // CREATED session idle too long → WARNING
    await recordAcediaEvent(sessionId, session, 'ACEDIA_WARNING', state);
    acediaState.phase = 'WARNING';
    logger.info('Acedia WARNING recorded', { sessionId });
    return;
  }

  if (state === 'ACTIVE' && acediaState.phase !== 'DETECTION' && idleMs >= activeThresholds.activeIdleMs) {
    // ACTIVE session idle too long → DETECTION + start countdown
    await recordAcediaEvent(sessionId, session, 'ACEDIA_DETECTION', state);
    acediaState.phase = 'DETECTION';
    acediaState.countdownStartedAt = now;
    logger.info('Acedia DETECTION recorded, countdown started', { sessionId });
    return;
  }

  if (state === 'ACTIVE' && acediaState.phase === 'DETECTION') {
    // Already in DETECTION phase — check countdown
    const countdownMs = now.getTime() - acediaState.countdownStartedAt!.getTime();
    if (countdownMs >= activeThresholds.countdownMs) {
      acediaState.phase = 'COUNTDOWN';
      await forceReleaseSession(sessionId, session, acediaState);
    }
  }
}

/**
 * Record an acedia event in the integrity ledger.
 */
async function recordAcediaEvent(
  sessionId: string,
  session: Session,
  eventType: IntegrityEventType,
  state: SessionState
): Promise<void> {
  const snapshot = buildMetadataSnapshot(session);
  await transaction(async (client) => {
    await appendEntry(client, sessionId, eventType, state, state, snapshot);
  });
}

/**
 * Force-release a session due to acedia (unresolved idle timeout).
 */
async function forceReleaseSession(
  sessionId: string,
  session: Session,
  acediaState: AcediaState
): Promise<void> {
  logger.warn('Acedia FORCE RELEASE: ending stalled session', { sessionId });

  try {
    // Attempt state transition to ENDED
    const updated = await transaction(async (client) => {
      const result = await sessionModel.transitionState(sessionId, session.state, 'ENDED', client);
      if (!result) {
        // Session may have already been closed
        return null;
      }

      // Record ACEDIA_FORCE_RELEASE in ledger (atomic with state transition)
      const snapshot = buildMetadataSnapshot(result);
      await appendEntry(client, sessionId, 'ACEDIA_FORCE_RELEASE', session.state, 'ENDED', snapshot);
      return result;
    });

    if (!updated) {
      logger.warn('Acedia force-release: session already closed or transition failed', { sessionId });
    } else {
      logger.info('Acedia force-release complete', { sessionId });
    }
  } catch (err) {
    logger.error('Acedia force-release failed', { sessionId, error: err });
  } finally {
    // Remove from tracking regardless of outcome
    acediaStates.delete(sessionId);
    if (acediaState) {
      acediaState.phase = 'NORMAL'; // Reset in case it stays in map somehow
    }
  }
}

/**
 * Record participant or admin activity for a session, resetting acedia timers.
 * If in COUNTDOWN phase, cancels countdown and records ACEDIA_CANCELLED.
 */
export function recordActivity(sessionId: string): void {
  const acediaState = acediaStates.get(sessionId);
  const now = new Date();

  if (!acediaState) {
    // Initialize tracking on first activity
    acediaStates.set(sessionId, {
      sessionId,
      phase: 'NORMAL',
      lastActivityAt: now,
      countdownStartedAt: null,
    });
    return;
  }

  const previousPhase: AcediaPhase = acediaState.phase;
  acediaState.lastActivityAt = now;

  if (previousPhase === 'COUNTDOWN' || previousPhase === 'DETECTION') {
    // Cancel countdown — record ACEDIA_CANCELLED asynchronously
    acediaState.phase = 'NORMAL';
    acediaState.countdownStartedAt = null;

    // Fire-and-forget: record cancellation (non-blocking)
    sessionModel.findById(sessionId).then(session => {
      if (session && session.state !== 'ENDED') {
        recordAcediaEvent(sessionId, session, 'ACEDIA_CANCELLED', session.state).catch(err => {
          logger.error('Failed to record ACEDIA_CANCELLED', { sessionId, error: err });
        });
      }
    }).catch(err => {
      logger.error('Failed to find session for ACEDIA_CANCELLED', { sessionId, error: err });
    });

    logger.info('Acedia cancelled by activity', { sessionId, previousPhase });
  } else if (previousPhase === 'WARNING') {
    acediaState.phase = 'NORMAL';
    logger.info('Acedia WARNING cleared by activity', { sessionId });
  }
}

/**
 * Get the current acedia monitoring state for a session.
 */
export function getAcediaState(sessionId: string): AcediaState | undefined {
  return acediaStates.get(sessionId);
}

/**
 * Remove acedia tracking for a dissolved session.
 */
export function clearSession(sessionId: string): void {
  acediaStates.delete(sessionId);
}
