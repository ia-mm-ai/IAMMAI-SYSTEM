/**
 * Co-agency tracker — enforces balanced participation between HUMAN and MACHINE agents.
 * Prevents any agent type from executing more than 2 consecutive irreversible actions.
 * Uses in-memory state per session (same pattern as suppression-engine.ts).
 * @see specs/008-governance-protocols/contracts/co-agency-tracker.md
 */

import type {
  AgentType,
  IrreversibleActionType,
  IrreversibleAction,
  CoAgencyState,
} from './types.js';

// In-memory co-agency state per session
const coAgencyStates = new Map<string, CoAgencyState>();

/**
 * Check if an irreversible action by the given agent type is allowed.
 * Returns false if the agent has already performed 2 consecutive irreversible actions.
 * Does NOT modify state — pure read.
 */
export function canPerformAction(sessionId: string, agentType: AgentType): boolean {
  const state = coAgencyStates.get(sessionId);
  if (!state) {
    return true; // No history = no violation
  }
  return !(state.consecutiveCount >= 2 && state.lastAgentType === agentType);
}

/**
 * Record an irreversible action for co-agency tracking.
 * Increments or resets the consecutive counter based on agent type.
 */
export function trackAction(
  sessionId: string,
  agentType: AgentType,
  actionType: IrreversibleActionType
): void {
  let state = coAgencyStates.get(sessionId);

  if (!state) {
    state = {
      sessionId,
      consecutiveCount: 0,
      lastAgentType: null,
      history: [],
    };
    coAgencyStates.set(sessionId, state);
  }

  const action: IrreversibleAction = {
    sessionId,
    agentType,
    actionType,
    timestamp: new Date(),
  };

  if (state.lastAgentType === agentType) {
    state.consecutiveCount++;
  } else {
    state.consecutiveCount = 1;
    state.lastAgentType = agentType;
  }

  state.history.push(action);
}

/**
 * Get the full co-agency action history for a session in chronological order.
 * Used by I.09 protocol evaluator via EvaluationContext.coAgencyActions.
 */
export function getHistory(sessionId: string): IrreversibleAction[] {
  return coAgencyStates.get(sessionId)?.history ?? [];
}

/**
 * Get the current co-agency counter state for a session.
 */
export function getState(sessionId: string): CoAgencyState | undefined {
  return coAgencyStates.get(sessionId);
}

/**
 * Remove co-agency tracking for a dissolved session.
 * No-op if session is not tracked.
 */
export function clearSession(sessionId: string): void {
  coAgencyStates.delete(sessionId);
}
