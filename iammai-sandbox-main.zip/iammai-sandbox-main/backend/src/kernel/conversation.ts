/**
 * Conversation utilities and types
 * @see specs/001-ephemeral-kernel/data-model.md#Conversation
 *
 * Note: The Conversation interface is defined in lib/types.ts.
 * This file provides utility functions for conversation operations.
 */

import type { Conversation, Message, MessageRole } from '../lib/types.js';
import { v4 as uuidv4 } from 'uuid';

/**
 * Create a new conversation
 */
export function createConversation(
  tokenHash: string,
  presenceHash: string
): Conversation {
  return {
    tokenHash,
    presenceHash,
    messages: [],
    createdAt: new Date(),
    lastActivityAt: new Date(),
  };
}

/**
 * Add a message to a conversation
 * Returns the new message
 */
export function addMessageToConversation(
  conversation: Conversation,
  role: MessageRole,
  content: string
): Message {
  const message: Message = {
    id: uuidv4(),
    role,
    content,
    timestamp: new Date(),
  };

  conversation.messages.push(message);
  conversation.lastActivityAt = new Date();

  return message;
}

/**
 * Format conversation history for AI context
 * Returns messages in the format expected by OpenAI
 */
export function formatForAI(
  conversation: Conversation
): Array<{ role: MessageRole; content: string }> {
  return conversation.messages.map((msg) => ({
    role: msg.role,
    content: msg.content,
  }));
}

/**
 * Get message count in conversation
 */
export function getMessageCount(conversation: Conversation): number {
  return conversation.messages.length;
}

/**
 * Check if conversation is idle (no activity for specified duration)
 */
export function isIdle(
  conversation: Conversation,
  idleThresholdMs: number
): boolean {
  const now = Date.now();
  const lastActivity = conversation.lastActivityAt.getTime();
  return now - lastActivity > idleThresholdMs;
}
