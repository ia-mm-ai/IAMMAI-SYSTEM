/**
 * Kernel class - in-memory container for session conversations
 * @see specs/001-ephemeral-kernel/data-model.md#Kernel
 *
 * PRIVACY GUARANTEE: This class exists ONLY in memory.
 * No serialization, no persistence, no logging of content.
 */

import type { Conversation, Message } from '../lib/types.js';
import { v4 as uuidv4 } from 'uuid';

/**
 * Kernel - ephemeral container for all conversations in a session
 *
 * Lifecycle:
 * - Created when session transitions CREATED -> ACTIVE
 * - Destroyed when session transitions ACTIVE -> ENDED
 */
export class Kernel {
  readonly sessionId: string;
  readonly conversations: Map<string, Conversation>;
  readonly createdAt: Date;

  constructor(sessionId: string) {
    this.sessionId = sessionId;
    this.conversations = new Map();
    this.createdAt = new Date();
  }

  /**
   * Get or create a conversation for a token
   */
  getOrCreateConversation(
    tokenHash: string,
    presenceHash: string
  ): Conversation {
    let conversation = this.conversations.get(tokenHash);

    if (!conversation) {
      conversation = {
        tokenHash,
        presenceHash,
        messages: [],
        createdAt: new Date(),
        lastActivityAt: new Date(),
      };
      this.conversations.set(tokenHash, conversation);
    }

    return conversation;
  }

  /**
   * Get existing conversation by token hash
   */
  getConversation(tokenHash: string): Conversation | undefined {
    return this.conversations.get(tokenHash);
  }

  /**
   * Check if conversation exists
   */
  hasConversation(tokenHash: string): boolean {
    return this.conversations.has(tokenHash);
  }

  /**
   * Add a message to a conversation
   */
  addMessage(
    tokenHash: string,
    role: 'user' | 'assistant',
    content: string
  ): Message {
    const conversation = this.conversations.get(tokenHash);
    if (!conversation) {
      throw new Error('Conversation not found');
    }

    const message: Message = {
      id: uuidv4(),
      role,
      content,
      timestamp: new Date(),
    };

    conversation.messages.push(message);
    conversation.lastActivityAt = new Date();

    return message;
  }

  /**
   * Get conversation history for AI context
   */
  getConversationHistory(tokenHash: string): Message[] {
    const conversation = this.conversations.get(tokenHash);
    return conversation ? [...conversation.messages] : [];
  }

  /**
   * Get number of active conversations
   */
  getConversationCount(): number {
    return this.conversations.size;
  }

  /**
   * Clear all conversations (for dissolution)
   * This explicitly clears the Map before the object is garbage collected
   */
  dissolve(): void {
    // Explicitly clear each conversation's messages
    for (const conversation of this.conversations.values()) {
      conversation.messages.length = 0;
    }
    // Clear the conversations map
    this.conversations.clear();
  }
}
