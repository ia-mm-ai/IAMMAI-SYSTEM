/**
 * KernelManager singleton - manages kernel lifecycle
 * @see specs/001-ephemeral-kernel/implementation-guide.md#T005
 *
 * PRIVACY GUARANTEE:
 * - All kernels exist ONLY in memory
 * - Dissolution is immediate and complete
 * - No conversation data is ever persisted
 */

import { Kernel } from './kernel.js';
import type { Conversation, Message } from '../lib/types.js';

/**
 * KernelManager - singleton for managing all active kernels
 */
class KernelManagerImpl {
  private readonly kernels: Map<string, Kernel>;

  constructor() {
    this.kernels = new Map();
  }

  /**
   * Create a new kernel for a session
   * Called when session transitions CREATED -> ACTIVE
   */
  createKernel(sessionId: string): Kernel {
    if (this.kernels.has(sessionId)) {
      throw new Error(`Kernel already exists for session: ${sessionId}`);
    }

    const kernel = new Kernel(sessionId);
    this.kernels.set(sessionId, kernel);

    return kernel;
  }

  /**
   * Get existing kernel for a session
   */
  getKernel(sessionId: string): Kernel | undefined {
    return this.kernels.get(sessionId);
  }

  /**
   * Check if kernel exists for session
   */
  hasKernel(sessionId: string): boolean {
    return this.kernels.has(sessionId);
  }

  /**
   * Dissolve a kernel - IMMEDIATELY destroys all conversations
   * Called when session transitions ACTIVE -> ENDED
   *
   * @returns true if kernel was dissolved, false if it didn't exist
   */
  dissolveKernel(sessionId: string): boolean {
    const kernel = this.kernels.get(sessionId);

    if (!kernel) {
      return false;
    }

    // Explicitly clear all data before removing
    kernel.dissolve();

    // Remove from map
    this.kernels.delete(sessionId);

    return true;
  }

  /**
   * Get or create a conversation for a user in a session
   */
  getOrCreateConversation(
    sessionId: string,
    tokenHash: string,
    presenceHash: string
  ): Conversation | null {
    const kernel = this.kernels.get(sessionId);

    if (!kernel) {
      return null;
    }

    return kernel.getOrCreateConversation(tokenHash, presenceHash);
  }

  /**
   * Get existing conversation
   */
  getConversation(
    sessionId: string,
    tokenHash: string
  ): Conversation | undefined {
    const kernel = this.kernels.get(sessionId);
    return kernel?.getConversation(tokenHash);
  }

  /**
   * Add a message to a conversation
   */
  addMessage(
    sessionId: string,
    tokenHash: string,
    role: 'user' | 'assistant',
    content: string
  ): Message | null {
    const kernel = this.kernels.get(sessionId);

    if (!kernel) {
      return null;
    }

    try {
      return kernel.addMessage(tokenHash, role, content);
    } catch {
      return null;
    }
  }

  /**
   * Get conversation history for AI context
   */
  getConversationHistory(
    sessionId: string,
    tokenHash: string
  ): Message[] {
    const kernel = this.kernels.get(sessionId);
    return kernel?.getConversationHistory(tokenHash) ?? [];
  }

  /**
   * Get count of active kernels (for monitoring)
   */
  getKernelCount(): number {
    return this.kernels.size;
  }

  /**
   * Get total conversation count across all kernels (for monitoring)
   */
  getTotalConversationCount(): number {
    let count = 0;
    for (const kernel of this.kernels.values()) {
      count += kernel.getConversationCount();
    }
    return count;
  }

  /**
   * Get session IDs with active kernels (for monitoring)
   */
  getActiveSessionIds(): string[] {
    return Array.from(this.kernels.keys());
  }
}

// Export singleton instance
export const kernelManager = new KernelManagerImpl();

// Export type for testing
export type KernelManager = KernelManagerImpl;
