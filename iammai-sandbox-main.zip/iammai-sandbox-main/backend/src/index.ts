/**
 * Main server entry point
 * @see specs/001-ephemeral-kernel/quickstart.md#Development URLs
 */

import { createServer } from 'node:http';
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { WebSocketServer } from 'ws';
import pg from 'pg';
import bcrypt from 'bcrypt';
import { createApp } from './api/app.js';
import { config } from './lib/config.js';
import { checkConnection as checkDb, closePool } from './lib/db.js';
import { wsHub } from './api/websocket/hub.js';
import { handleConnection } from './api/websocket/handlers.js';
import { startMonitor, stopMonitor } from './integrity/acedia-monitor.js';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

/**
 * Run pending database migrations on startup.
 */
async function runMigrations(): Promise<void> {
  const databaseUrl = process.env['DATABASE_URL'];
  if (!databaseUrl) {
    console.warn('DATABASE_URL not set, skipping migrations');
    return;
  }

  const migrationsDir = path.join(__dirname, '..', 'migrations');
  if (!fs.existsSync(migrationsDir)) {
    console.warn('Migrations directory not found, skipping');
    return;
  }

  const pool = new pg.Pool({ connectionString: databaseUrl });
  try {
    const files = fs.readdirSync(migrationsDir)
      .filter(f => f.endsWith('.sql'))
      .sort();

    if (files.length === 0) return;

    const appliedResult = await pool.query(
      'SELECT name FROM migrations ORDER BY applied_at'
    ).catch(() => ({ rows: [] as { name: string }[] }));

    const applied = new Set(appliedResult.rows.map((r) => r.name));

    let count = 0;
    for (const file of files) {
      const name = file.replace('.sql', '');
      if (applied.has(name)) continue;

      console.log(`  Applying migration ${file}...`);
      const sql = fs.readFileSync(path.join(migrationsDir, file), 'utf-8');
      await pool.query(sql);
      await pool.query(
        `INSERT INTO migrations (name) VALUES ($1) ON CONFLICT (name) DO NOTHING`,
        [name]
      );
      count++;
      console.log(`  Applied ${file}`);
    }

    if (count > 0) {
      console.log(`Applied ${count} migration(s)`);
    } else {
      console.log('All migrations already applied');
    }
  } catch (error) {
    console.error('Migration failed:', error);
    throw error;
  } finally {
    await pool.end();
  }
}

/**
 * Seed the admin account on startup if ADMIN_EMAIL and ADMIN_PASSWORD are set.
 * Skips if the account already exists.
 */
async function runSeed(): Promise<void> {
  const adminEmail = process.env['ADMIN_EMAIL'];
  const adminPassword = process.env['ADMIN_PASSWORD'];

  if (!adminEmail || !adminPassword) return;

  const databaseUrl = process.env['DATABASE_URL'];
  if (!databaseUrl) return;

  const pool = new pg.Pool({ connectionString: databaseUrl });
  try {
    const existing = await pool.query(
      'SELECT id FROM admins WHERE email = $1',
      [adminEmail]
    );
    if (existing.rows.length > 0) return;

    const passwordHash = await bcrypt.hash(adminPassword, 10);
    await pool.query(
      'INSERT INTO admins (email, password_hash, created_at) VALUES ($1, $2, NOW())',
      [adminEmail, passwordHash]
    );
    console.log(`Seeded admin account: ${adminEmail}`);
  } catch (error) {
    console.error('Seed failed:', error);
  } finally {
    await pool.end();
  }
}

/**
 * Start the server
 */
async function main(): Promise<void> {
  console.log('Starting IAMMAI Sandbox API...');

  // Check database connection
  console.log('Checking database connection...');
  const dbOk = await checkDb();
  if (!dbOk) {
    console.error('Failed to connect to database');
    process.exit(1);
  }
  console.log('Database connection OK');

  // Run pending migrations
  await runMigrations();

  // Seed admin account if configured
  await runSeed();

  // Create Express app
  const app = createApp();

  // Create HTTP server (for WebSocket upgrade)
  const server = createServer(app);

  // Create WebSocket server
  const wss = new WebSocketServer({
    noServer: true, // Handle upgrade manually for path matching
  });

  // Handle WebSocket upgrade for /ws/sessions/:sessionId
  server.on('upgrade', (request, socket, head) => {
    if (request.url?.startsWith('/ws/sessions/')) {
      wss.handleUpgrade(request, socket, head, (ws) => {
        wss.emit('connection', ws, request);
      });
    } else {
      socket.destroy();
    }
  });

  // Initialize WebSocket hub
  wsHub.initialize();

  // Handle WebSocket connections
  wss.on('connection', handleConnection);

  // Start acedia monitor (Feature 008)
  startMonitor();

  // Start listening
  server.listen(config.port, config.host, () => {
    console.log(`Server running on http://${config.host}:${config.port}`);
    console.log(`Environment: ${config.nodeEnv}`);
  });

  // Graceful shutdown
  const shutdown = async (signal: string): Promise<void> => {
    console.log(`\nReceived ${signal}, shutting down gracefully...`);

    // Stop acedia monitor (Feature 008)
    stopMonitor();

    // Shutdown WebSocket hub
    wsHub.shutdown();
    console.log('WebSocket hub closed');

    server.close(async () => {
      console.log('HTTP server closed');

      // Close database pool
      await closePool();
      console.log('Database pool closed');

      process.exit(0);
    });

    // Force exit after 10 seconds
    setTimeout(() => {
      console.error('Forced shutdown after timeout');
      process.exit(1);
    }, 10000);
  };

  process.on('SIGTERM', () => shutdown('SIGTERM'));
  process.on('SIGINT', () => shutdown('SIGINT'));
}

// Run the server
main().catch((error) => {
  console.error('Failed to start server:', error);
  process.exit(1);
});
