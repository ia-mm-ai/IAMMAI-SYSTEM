import { describe, it, expect, beforeEach } from 'vitest';
import { kernelManager } from '../../src/kernel/manager.js';

beforeEach(() => {
  // Clear all kernels between tests
  for (const sessionId of Array.from(kernelManager['kernels'].keys())) {
    kernelManager.dissolveKernel(sessionId);
  }
});

describe('Privacy: Dissolution Timing Requirements', () => {
  it('should dissolve kernel with 1 conversation in <50ms', async () => {
    const sessionId = 'timing-test-1';

    kernelManager.createKernel(sessionId);
    kernelManager.getOrCreateConversation(sessionId, 'token-1', 'presence-1');

    // Add typical conversation (10 messages)
    for (let i = 0; i < 10; i++) {
      kernelManager.addMessage(
        sessionId,
        'token-1',
        i % 2 === 0 ? 'user' : 'assistant',
        'A'.repeat(100)
      );
    }

    const start = performance.now();
    kernelManager.dissolveKernel(sessionId);
    const duration = performance.now() - start;

    expect(duration).toBeLessThan(50);
  });

  it('should dissolve kernel with 10 conversations in <50ms', async () => {
    const sessionId = 'timing-test-10';

    kernelManager.createKernel(sessionId);

    // Create 10 conversations with realistic message counts
    for (let i = 0; i < 10; i++) {
      kernelManager.getOrCreateConversation(sessionId, `token-${i}`, `presence-${i}`);
      // 5-15 messages per conversation
      const messageCount = 5 + (i % 10);
      for (let j = 0; j < messageCount; j++) {
        kernelManager.addMessage(
          sessionId,
          `token-${i}`,
          j % 2 === 0 ? 'user' : 'assistant',
          'A'.repeat(200)
        );
      }
    }

    const start = performance.now();
    kernelManager.dissolveKernel(sessionId);
    const duration = performance.now() - start;

    // Constitution Principle IV: <50ms even with multiple conversations
    expect(duration).toBeLessThan(50);
  });

  it('should dissolve kernel with 100 conversations in <50ms (max capacity)', async () => {
    const sessionId = 'timing-test-100';

    kernelManager.createKernel(sessionId);

    // Max capacity: 100 concurrent users
    for (let i = 0; i < 100; i++) {
      kernelManager.getOrCreateConversation(sessionId, `token-${i}`, `presence-${i}`);
      // Minimal conversation (2 messages)
      kernelManager.addMessage(sessionId, `token-${i}`, 'user', 'Hello');
      kernelManager.addMessage(sessionId, `token-${i}`, 'assistant', 'Hi!');
    }

    const start = performance.now();
    kernelManager.dissolveKernel(sessionId);
    const duration = performance.now() - start;

    // Must still meet <50ms requirement at max capacity
    expect(duration).toBeLessThan(50);
  });

  it('should dissolve kernel with long conversations in <50ms', async () => {
    const sessionId = 'timing-test-long';

    kernelManager.createKernel(sessionId);
    kernelManager.getOrCreateConversation(sessionId, 'token-long', 'presence-long');

    // Create a very long conversation (100 messages with long content)
    for (let i = 0; i < 100; i++) {
      kernelManager.addMessage(
        sessionId,
        'token-long',
        i % 2 === 0 ? 'user' : 'assistant',
        'A'.repeat(1000)
      );
    }

    const start = performance.now();
    kernelManager.dissolveKernel(sessionId);
    const duration = performance.now() - start;

    // Even with long conversation, must complete quickly
    expect(duration).toBeLessThan(50);
  });

  it('should measure average dissolution time over multiple runs', async () => {
    const runs = 100;
    const times: number[] = [];

    for (let run = 0; run < runs; run++) {
      const sessionId = `timing-test-run-${run}`;

      kernelManager.createKernel(sessionId);

      // Create realistic scenario: 5 conversations, 10 messages each
      for (let i = 0; i < 5; i++) {
        kernelManager.getOrCreateConversation(sessionId, `token-${run}-${i}`, `presence-${run}-${i}`);
        for (let j = 0; j < 10; j++) {
          kernelManager.addMessage(
            sessionId,
            `token-${run}-${i}`,
            j % 2 === 0 ? 'user' : 'assistant',
            'Test message content'
          );
        }
      }

      const start = performance.now();
      kernelManager.dissolveKernel(sessionId);
      const duration = performance.now() - start;

      times.push(duration);
    }

    const average = times.reduce((sum, t) => sum + t, 0) / times.length;
    const max = Math.max(...times);
    const p95 = times.sort((a, b) => a - b)[Math.floor(runs * 0.95)];

    // Report statistics
    console.log('Dissolution timing statistics:');
    console.log(`  Average: ${average.toFixed(2)}ms`);
    console.log(`  Max: ${max.toFixed(2)}ms`);
    console.log(`  P95: ${p95.toFixed(2)}ms`);

    // All runs must meet requirement
    expect(max).toBeLessThan(50);
    expect(p95).toBeLessThan(50);
    expect(average).toBeLessThan(50);
  });

  it('should verify dissolution is synchronous (no async cleanup)', async () => {
    const sessionId = 'timing-test-sync';

    kernelManager.createKernel(sessionId);
    kernelManager.getOrCreateConversation(sessionId, 'token-sync', 'presence-sync');

    kernelManager.addMessage(sessionId, 'token-sync', 'user', 'Test message');

    // Dissolve should be synchronous
    kernelManager.dissolveKernel(sessionId);

    // Immediately after dissolution, data should be inaccessible
    const history = kernelManager.getConversationHistory(sessionId, 'token-sync');
    expect(history).toEqual([]);

    // No "await" or setTimeout should be needed
    const conv = kernelManager.getOrCreateConversation(sessionId, 'token-sync', 'presence-sync');
    expect(conv).toBeNull();
  });
});
