/**
 * Privacy tests for the integrity ledger.
 * Verifies that ledger entries contain ONLY session metadata — never
 * message content, token values, presence hashes, or ephemeral data.
 * @see specs/005-structural-foundation/spec.md US2
 * @see docs/framework/FRAMEWORK_DECISIONS.md Decision 10: Privacy Boundary
 */

import { describe, it, expect } from 'vitest';
import type { MetadataSnapshot } from '../../src/integrity/types.js';
import { buildMetadataSnapshot } from '../../src/integrity/state-observer.js';
import type { Session } from '../../src/lib/types.js';

const SESSION_ID = 'aaaaaaaa-bbbb-cccc-dddd-eeeeeeeeeeee';
const ADMIN_ID = '11111111-2222-3333-4444-555555555555';

function makeSession(overrides: Partial<Session> = {}): Session {
  return {
    id: SESSION_ID,
    name: 'Privacy Test Session',
    state: 'ACTIVE',
    createdAt: new Date('2026-02-14T10:00:00.000Z'),
    startedAt: new Date('2026-02-14T10:01:00.000Z'),
    endedAt: null,
    tokenCount: 5,
    userCount: 3,
    adminId: ADMIN_ID,
    contextDescriptor: { topic: 'Privacy testing', purpose: 'Ensure no content leaks' },
    environmentalConstraints: { max_participants: 20, ai_model: 'claude-sonnet-4-5-20250929' },
    ...overrides,
  };
}

// Sensitive fields that must NEVER appear in a metadata snapshot
const FORBIDDEN_FIELDS = [
  'content',
  'message',
  'messages',
  'messageContent',
  'message_content',
  'text',
  'token',
  'tokenValue',
  'token_value',
  'tokenRaw',
  'token_raw',
  'raw',
  'presenceHash',
  'presence_hash',
  'seed',
  'passwordHash',
  'password_hash',
  'password',
  'conversations',
  'conversation',
];

describe('Ledger privacy — MetadataSnapshot', () => {
  it('snapshot contains only approved metadata fields', () => {
    const session = makeSession();
    const snapshot = buildMetadataSnapshot(session);

    const allowedKeys = [
      'session_id',
      'session_name',
      'state',
      'framework_status',
      'admin_id',
      'token_count',
      'user_count',
      'created_at',
      'started_at',
      'ended_at',
      'context_descriptor',
      'environmental_constraints',
    ];

    const snapshotKeys = Object.keys(snapshot);
    expect(snapshotKeys.sort()).toEqual(allowedKeys.sort());
  });

  it('snapshot contains NO forbidden fields', () => {
    const session = makeSession();
    const snapshot = buildMetadataSnapshot(session);
    const snapshotKeys = Object.keys(snapshot);

    for (const forbidden of FORBIDDEN_FIELDS) {
      expect(snapshotKeys).not.toContain(forbidden);
    }
  });

  it('snapshot JSON representation contains no message content patterns', () => {
    const session = makeSession();
    const snapshot = buildMetadataSnapshot(session);
    const json = JSON.stringify(snapshot);

    // Should not contain typical message content markers
    expect(json).not.toContain('"content"');
    expect(json).not.toContain('"messages"');
    expect(json).not.toContain('"conversations"');
    expect(json).not.toContain('"presenceHash"');
    expect(json).not.toContain('"tokenRaw"');
    expect(json).not.toContain('"password"');
  });

  it('snapshot does not leak session data beyond metadata', () => {
    const session = makeSession();
    const snapshot = buildMetadataSnapshot(session);

    // Verify values are correct metadata
    expect(snapshot.session_id).toBe(SESSION_ID);
    expect(snapshot.session_name).toBe('Privacy Test Session');
    expect(snapshot.state).toBe('ACTIVE');
    expect(snapshot.framework_status).toBe('OPEN');
    expect(snapshot.admin_id).toBe(ADMIN_ID);
    expect(snapshot.token_count).toBe(5);
    expect(snapshot.user_count).toBe(3);
    expect(snapshot.context_descriptor).toEqual({ topic: 'Privacy testing', purpose: 'Ensure no content leaks' });
    expect(snapshot.environmental_constraints).toEqual({ max_participants: 20, ai_model: 'claude-sonnet-4-5-20250929' });
  });

  it('snapshot for ENDED session still contains no sensitive data', () => {
    const session = makeSession({
      state: 'ENDED',
      endedAt: new Date('2026-02-14T11:00:00.000Z'),
      tokenCount: 10,
      userCount: 8,
    });
    const snapshot = buildMetadataSnapshot(session);
    const snapshotKeys = Object.keys(snapshot);

    for (const forbidden of FORBIDDEN_FIELDS) {
      expect(snapshotKeys).not.toContain(forbidden);
    }

    expect(snapshot.framework_status).toBe('CLOSED');
    expect(snapshot.ended_at).toBe('2026-02-14T11:00:00.000Z');
  });
});
