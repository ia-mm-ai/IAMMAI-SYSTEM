/**
 * Privacy test ensuring admin cannot access conversation content
 * @see specs/001-ephemeral-kernel/tasks.md#T099
 * @see specs/001-ephemeral-kernel/spec.md#FR-013, Constitution Principle V
 */

import { describe, it, expect, beforeAll, afterAll, afterEach } from 'vitest';
import request from 'supertest';
import type { Express } from 'express';
import { createApp } from '../../src/api/app.js';
import { closePool, query } from '../../src/lib/db.js';
import { kernelManager } from '../../src/kernel/manager.js';
import { addMessageToConversation } from '../../src/kernel/conversation.js';
import bcrypt from 'bcrypt';
import WebSocket from 'ws';

describe('Privacy: Admin Access Control (FR-013)', () => {
  let app: Express;
  let authCookie: string;
  const testEmail = 'test-admin-privacy@example.com';
  const testPassword = 'testPassword123!';
  let testAdminId: string;
  const createdSessionIds: string[] = [];
  const claimedTokens: string[] = [];

  beforeAll(async () => {
    app = createApp();

    // Create test admin and login
    const passwordHash = await bcrypt.hash(testPassword, 10);
    const result = await query(
      `INSERT INTO admins (email, password_hash)
       VALUES ($1, $2)
       ON CONFLICT (email) DO UPDATE SET password_hash = $2
       RETURNING id`,
      [testEmail, passwordHash]
    );
    testAdminId = result.rows[0].id;

    // Login to get auth cookie
    const loginResponse = await request(app)
      .post('/api/v1/auth/login')
      .send({ email: testEmail, password: testPassword });

    const cookies = loginResponse.headers['set-cookie'];
    authCookie = Array.isArray(cookies) ? cookies[0] : cookies;
  });

  afterEach(async () => {
    // Clean up claimed tokens
    for (const token of claimedTokens) {
      await query('DELETE FROM tokens WHERE token_hash = $1', [token]);
    }
    claimedTokens.length = 0;

    // Clean up created sessions
    for (const sessionId of createdSessionIds) {
      // Dissolve any kernels
      kernelManager.dissolveKernel(sessionId);
      // Delete from database
      await query('DELETE FROM sessions WHERE id = $1', [sessionId]);
    }
    createdSessionIds.length = 0;
  });

  afterAll(async () => {
    await query('DELETE FROM admins WHERE id = $1', [testAdminId]);
    await closePool();
  });

  it('should not expose conversation messages in session details', async () => {
    // Create and start a session
    const createResponse = await request(app)
      .post('/api/v1/admin/sessions')
      .set('Cookie', authCookie)
      .send({ name: 'Privacy Test Session' })
      .expect(201);

    const sessionId = createResponse.body.id;
    createdSessionIds.push(sessionId);

    // Claim token and join
    const claimResponse = await request(app)
      .post(`/api/v1/sessions/${sessionId}/claim`)
      .expect(201);

    const token = claimResponse.body.token;
    claimedTokens.push(token);

    await request(app)
      .post(`/api/v1/admin/sessions/${sessionId}/start`)
      .set('Cookie', authCookie)
      .expect(200);

    await request(app)
      .post(`/api/v1/sessions/${sessionId}/join`)
      .send({ token })
      .expect(200);

    // Simulate user sending a message by directly adding to kernel
    const kernel = kernelManager.getKernel(sessionId);
    if (kernel) {
      const conversation = kernel.getOrCreateConversation(token, 'presence123');
      addMessageToConversation(conversation, 'user', 'Secret user message');
      addMessageToConversation(conversation, 'assistant', 'Secret AI response');
    }

    // Get session details as admin
    const detailsResponse = await request(app)
      .get(`/api/v1/admin/sessions/${sessionId}`)
      .set('Cookie', authCookie)
      .expect(200);

    // Verify no message content in response
    const responseStr = JSON.stringify(detailsResponse.body);
    expect(responseStr).not.toContain('Secret user message');
    expect(responseStr).not.toContain('Secret AI response');

    // Verify response only contains metadata
    expect(detailsResponse.body).toHaveProperty('id');
    expect(detailsResponse.body).toHaveProperty('name');
    expect(detailsResponse.body).toHaveProperty('state');
    expect(detailsResponse.body).toHaveProperty('tokenCount');
    expect(detailsResponse.body).toHaveProperty('userCount');
    expect(detailsResponse.body).toHaveProperty('kernelStatus');
    expect(detailsResponse.body).toHaveProperty('lifecycle');

    // Should not have any message-related properties
    expect(detailsResponse.body).not.toHaveProperty('messages');
    expect(detailsResponse.body).not.toHaveProperty('conversations');
    expect(detailsResponse.body).not.toHaveProperty('content');
  });

  it('should not expose conversation messages in session list', async () => {
    // Create session with conversations
    const createResponse = await request(app)
      .post('/api/v1/admin/sessions')
      .set('Cookie', authCookie)
      .send({ name: 'Privacy Test List Session' })
      .expect(201);

    const sessionId = createResponse.body.id;
    createdSessionIds.push(sessionId);

    const claimResponse = await request(app)
      .post(`/api/v1/sessions/${sessionId}/claim`)
      .expect(201);

    const token = claimResponse.body.token;
    claimedTokens.push(token);

    await request(app)
      .post(`/api/v1/admin/sessions/${sessionId}/start`)
      .set('Cookie', authCookie)
      .expect(200);

    await request(app)
      .post(`/api/v1/sessions/${sessionId}/join`)
      .send({ token })
      .expect(200);

    // Add messages to kernel
    const kernel = kernelManager.getKernel(sessionId);
    if (kernel) {
      const conversation = kernel.getOrCreateConversation(token, 'presence123');
      addMessageToConversation(conversation, 'user', 'Private message in list');
    }

    // Get session list as admin
    const listResponse = await request(app)
      .get('/api/v1/admin/sessions')
      .set('Cookie', authCookie)
      .expect(200);

    // Verify no message content in list
    const responseStr = JSON.stringify(listResponse.body);
    expect(responseStr).not.toContain('Private message in list');

    // Verify list contains only metadata
    const session = listResponse.body.sessions.find((s: any) => s.id === sessionId);
    expect(session).toBeDefined();
    expect(session).not.toHaveProperty('messages');
    expect(session).not.toHaveProperty('conversations');
  });

  it('should not provide any admin endpoint to access conversation data', async () => {
    // Create session with active conversation
    const createResponse = await request(app)
      .post('/api/v1/admin/sessions')
      .set('Cookie', authCookie)
      .send({ name: 'Endpoint Test Session' })
      .expect(201);

    const sessionId = createResponse.body.id;
    createdSessionIds.push(sessionId);

    const claimResponse = await request(app)
      .post(`/api/v1/sessions/${sessionId}/claim`)
      .expect(201);

    const token = claimResponse.body.token;
    claimedTokens.push(token);

    await request(app)
      .post(`/api/v1/admin/sessions/${sessionId}/start`)
      .set('Cookie', authCookie)
      .expect(200);

    await request(app)
      .post(`/api/v1/sessions/${sessionId}/join`)
      .send({ token })
      .expect(200);

    // Add conversation data
    const kernel = kernelManager.getKernel(sessionId);
    if (kernel) {
      const conversation = kernel.getOrCreateConversation(token, 'presence123');
      addMessageToConversation(conversation, 'user', 'Sensitive data');
    }

    // Try common endpoint patterns that should NOT exist
    const forbiddenEndpoints = [
      `/api/v1/admin/sessions/${sessionId}/messages`,
      `/api/v1/admin/sessions/${sessionId}/conversations`,
      `/api/v1/admin/sessions/${sessionId}/history`,
      `/api/v1/admin/sessions/${sessionId}/chat`,
      `/api/v1/admin/conversations`,
      `/api/v1/admin/messages`,
    ];

    for (const endpoint of forbiddenEndpoints) {
      const getResponse = await request(app)
        .get(endpoint)
        .set('Cookie', authCookie);

      // Should be 404 (not found) or 405 (method not allowed), NOT 200
      expect([404, 405]).toContain(getResponse.status);

      // If it somehow returns 200, verify no sensitive data
      if (getResponse.status === 200) {
        const responseStr = JSON.stringify(getResponse.body);
        expect(responseStr).not.toContain('Sensitive data');
      }
    }
  });

  it('should not expose presence hash mappings to tokens', async () => {
    // Create session and have user join
    const createResponse = await request(app)
      .post('/api/v1/admin/sessions')
      .set('Cookie', authCookie)
      .send({ name: 'Presence Privacy Test' })
      .expect(201);

    const sessionId = createResponse.body.id;
    createdSessionIds.push(sessionId);

    const claimResponse = await request(app)
      .post(`/api/v1/sessions/${sessionId}/claim`)
      .expect(201);

    const token = claimResponse.body.token;
    claimedTokens.push(token);

    await request(app)
      .post(`/api/v1/admin/sessions/${sessionId}/start`)
      .set('Cookie', authCookie)
      .expect(200);

    const joinResponse = await request(app)
      .post(`/api/v1/sessions/${sessionId}/join`)
      .send({ token })
      .expect(200);

    const presenceHash = joinResponse.body.presenceHash;

    // Get session details as admin
    const detailsResponse = await request(app)
      .get(`/api/v1/admin/sessions/${sessionId}`)
      .set('Cookie', authCookie)
      .expect(200);

    // Should not expose token value
    const responseStr = JSON.stringify(detailsResponse.body);
    expect(responseStr).not.toContain(token);

    // Should not expose presence hash (even though it's anonymous)
    expect(responseStr).not.toContain(presenceHash);

    // Should not have any user-identifying properties
    expect(detailsResponse.body).not.toHaveProperty('tokens');
    expect(detailsResponse.body).not.toHaveProperty('users');
    expect(detailsResponse.body).not.toHaveProperty('presenceHashes');
  });

  it('should only expose aggregate counts, not individual user data', async () => {
    // Create session with multiple users
    const createResponse = await request(app)
      .post('/api/v1/admin/sessions')
      .set('Cookie', authCookie)
      .send({ name: 'Aggregate Data Test' })
      .expect(201);

    const sessionId = createResponse.body.id;
    createdSessionIds.push(sessionId);

    // Claim 3 tokens
    const tokens: string[] = [];
    for (let i = 0; i < 3; i++) {
      const claimResponse = await request(app)
        .post(`/api/v1/sessions/${sessionId}/claim`)
        .expect(201);
      tokens.push(claimResponse.body.token);
      claimedTokens.push(claimResponse.body.token);
    }

    await request(app)
      .post(`/api/v1/admin/sessions/${sessionId}/start`)
      .set('Cookie', authCookie)
      .expect(200);

    // 2 users join
    for (let i = 0; i < 2; i++) {
      await request(app)
        .post(`/api/v1/sessions/${sessionId}/join`)
        .send({ token: tokens[i] })
        .expect(200);
    }

    // Get session details
    const detailsResponse = await request(app)
      .get(`/api/v1/admin/sessions/${sessionId}`)
      .set('Cookie', authCookie)
      .expect(200);

    // Should have aggregate counts
    expect(detailsResponse.body.tokenCount).toBe(3);
    expect(detailsResponse.body.userCount).toBe(2);

    // Should not have individual user lists or details
    expect(detailsResponse.body).not.toHaveProperty('tokenList');
    expect(detailsResponse.body).not.toHaveProperty('userList');
    expect(detailsResponse.body).not.toHaveProperty('participants');

    // Verify no token values in response
    const responseStr = JSON.stringify(detailsResponse.body);
    for (const token of tokens) {
      expect(responseStr).not.toContain(token);
    }
  });

  it('should not store conversation data in database', async () => {
    // Create session and add conversations
    const createResponse = await request(app)
      .post('/api/v1/admin/sessions')
      .set('Cookie', authCookie)
      .send({ name: 'Database Privacy Test' })
      .expect(201);

    const sessionId = createResponse.body.id;
    createdSessionIds.push(sessionId);

    const claimResponse = await request(app)
      .post(`/api/v1/sessions/${sessionId}/claim`)
      .expect(201);

    const token = claimResponse.body.token;
    claimedTokens.push(token);

    await request(app)
      .post(`/api/v1/admin/sessions/${sessionId}/start`)
      .set('Cookie', authCookie)
      .expect(200);

    await request(app)
      .post(`/api/v1/sessions/${sessionId}/join`)
      .send({ token })
      .expect(200);

    // Add conversation data to kernel
    const kernel = kernelManager.getKernel(sessionId);
    const testMessage = 'This should never be in the database';
    if (kernel) {
      const conversation = kernel.getOrCreateConversation(token, 'presence123');
      addMessageToConversation(conversation, 'user', testMessage);
    }

    // Query database for any trace of message content
    const dbResult = await query(
      `SELECT * FROM sessions WHERE id = $1`,
      [sessionId]
    );

    const sessionData = JSON.stringify(dbResult.rows[0]);
    expect(sessionData).not.toContain(testMessage);

    // Check tokens table doesn't store message data
    const tokenResult = await query(
      `SELECT * FROM tokens WHERE session_id = $1`,
      [sessionId]
    );

    if (tokenResult.rows.length > 0) {
      const tokenData = JSON.stringify(tokenResult.rows);
      expect(tokenData).not.toContain(testMessage);
    }
  });
});
