import { describe, it, expect, beforeEach } from 'vitest';
import { kernelManager } from '../../src/kernel/manager';

beforeEach(() => {
  // Clear all kernels between tests
  for (const sessionId of Array.from(kernelManager['kernels'].keys())) {
    kernelManager.dissolveKernel(sessionId);
  }
});

describe('Privacy: Complete Data Destruction on Dissolution', () => {
  it('should completely destroy all conversation data', async () => {
    const sessionId = 'privacy-test-destruction';
    const sensitiveMessages = [
      'My credit card is 1234-5678-9012-3456',
      'My password is SuperSecret123',
      'I live at 123 Main Street',
    ];

    kernelManager.createKernel(sessionId);
    kernelManager.getOrCreateConversation(sessionId, 'token-sensitive', 'presence-sensitive');

    // Add sensitive messages
    sensitiveMessages.forEach((content, i) => {
      kernelManager.addMessage(sessionId, 'token-sensitive', 'user', content);
    });

    // Verify messages exist before dissolution
    const before = kernelManager.getConversationHistory(sessionId, 'token-sensitive');
    expect(before).toHaveLength(3);

    // Dissolve kernel
    kernelManager.dissolveKernel(sessionId);

    // Verify all data is gone
    const after = kernelManager.getConversationHistory(sessionId, 'token-sensitive');
    expect(after).toEqual([]);

    // Verify kernel object is completely removed from memory
    const kernel = kernelManager['kernels'].get(sessionId);
    expect(kernel).toBeUndefined();
  });

  it('should destroy all conversations in kernel', async () => {
    const sessionId = 'privacy-test-multi-conv';

    kernelManager.createKernel(sessionId);

    // Create multiple conversations with sensitive data
    const conversationCount = 10;
    for (let i = 0; i < conversationCount; i++) {
      kernelManager.getOrCreateConversation(sessionId, `token-${i}`, `presence-${i}`);
      kernelManager.addMessage(sessionId, `token-${i}`, 'user', `Private conversation ${i}`);
    }

    // Verify all conversations exist
    for (let i = 0; i < conversationCount; i++) {
      const history = kernelManager.getConversationHistory(sessionId, `token-${i}`);
      expect(history).toHaveLength(1);
    }

    // Dissolve kernel
    kernelManager.dissolveKernel(sessionId);

    // Verify ALL conversations are destroyed
    for (let i = 0; i < conversationCount; i++) {
      const history = kernelManager.getConversationHistory(sessionId, `token-${i}`);
      expect(history).toEqual([]);
    }
  });

  it('should prevent access to conversation after dissolution', async () => {
    const sessionId = 'privacy-test-no-access';

    kernelManager.createKernel(sessionId);
    kernelManager.getOrCreateConversation(sessionId, 'token-private', 'presence-private');
    kernelManager.addMessage(sessionId, 'token-private', 'user', 'This should be inaccessible after dissolution');

    // Dissolve kernel
    kernelManager.dissolveKernel(sessionId);

    // Attempt to access conversation should return null
    const conv = kernelManager.getOrCreateConversation(sessionId, 'token-private', 'presence-private');
    expect(conv).toBeNull();

    // History should return empty
    const history = kernelManager.getConversationHistory(sessionId, 'token-private');
    expect(history).toEqual([]);
  });

  it('should prevent adding messages after dissolution', async () => {
    const sessionId = 'privacy-test-no-add';

    kernelManager.createKernel(sessionId);
    kernelManager.getOrCreateConversation(sessionId, 'token-test', 'presence-test');

    // Dissolve kernel
    kernelManager.dissolveKernel(sessionId);

    // Attempt to add message should return null (kernel doesn't exist)
    const result = kernelManager.addMessage(sessionId, 'token-test', 'user', 'This should not be added');
    expect(result).toBeNull();
  });

  it('should not leave any references to conversation objects', async () => {
    const sessionId = 'privacy-test-no-refs';

    kernelManager.createKernel(sessionId);
    const conv = kernelManager.getOrCreateConversation(sessionId, 'token-ref', 'presence-ref');

    // Add message
    kernelManager.addMessage(sessionId, 'token-ref', 'user', 'Test message');

    // Keep reference to conversation object
    const convRef = conv;
    expect(convRef.messages).toHaveLength(1);

    // Dissolve kernel
    kernelManager.dissolveKernel(sessionId);

    // Kernel should be completely removed
    const kernel = kernelManager['kernels'].get(sessionId);
    expect(kernel).toBeUndefined();

    // The conversation reference we kept might still exist in memory,
    // but it should not be accessible through the kernel manager
    const history = kernelManager.getConversationHistory(sessionId, 'token-ref');
    expect(history).toEqual([]);
  });

  it('should verify no conversation data in kernel manager after dissolution', async () => {
    const sessionId = 'privacy-test-verify-clean';

    kernelManager.createKernel(sessionId);

    // Create conversations
    for (let i = 0; i < 5; i++) {
      kernelManager.getOrCreateConversation(sessionId, `token-${i}`, `presence-${i}`);
      for (let j = 0; j < 3; j++) {
        kernelManager.addMessage(sessionId, `token-${i}`, 'user', `Message ${j}`);
      }
    }

    // Dissolve
    kernelManager.dissolveKernel(sessionId);

    // Check internal state - kernel should not exist
    const kernels = kernelManager['kernels'];
    expect(kernels.has(sessionId)).toBe(false);
    expect(kernels.get(sessionId)).toBeUndefined();

    // Verify kernel count
    const kernelCount = kernels.size;
    expect(kernelCount).toBe(0); // Assuming no other tests running
  });

  it('should handle dissolution of kernel with AI message history', async () => {
    const sessionId = 'privacy-test-ai-history';

    kernelManager.createKernel(sessionId);
    kernelManager.getOrCreateConversation(sessionId, 'token-ai', 'presence-ai');

    // Create realistic conversation with AI responses
    const conversation = [
      { role: 'user', content: 'What is the weather?' },
      { role: 'assistant', content: 'I cannot access real-time weather data.' },
      { role: 'user', content: 'Tell me a joke' },
      { role: 'assistant', content: 'Why did the chicken cross the road?' },
    ];

    conversation.forEach((msg) => {
      kernelManager.addMessage(sessionId, 'token-ai', msg.role as 'user' | 'assistant', msg.content);
    });

    // Verify conversation exists
    const before = kernelManager.getConversationHistory(sessionId, 'token-ai');
    expect(before).toHaveLength(4);

    // Dissolve
    kernelManager.dissolveKernel(sessionId);

    // Verify ALL messages destroyed (user and AI)
    const after = kernelManager.getConversationHistory(sessionId, 'token-ai');
    expect(after).toEqual([]);
  });

  it('should verify isolation between sessions during dissolution', async () => {
    const session1 = 'privacy-test-session-1';
    const session2 = 'privacy-test-session-2';

    // Create two kernels with data
    kernelManager.createKernel(session1);
    kernelManager.createKernel(session2);

    kernelManager.getOrCreateConversation(session1, 'token-1', 'presence-1');
    kernelManager.getOrCreateConversation(session2, 'token-2', 'presence-2');

    kernelManager.addMessage(session1, 'token-1', 'user', 'Session 1 private data');
    kernelManager.addMessage(session2, 'token-2', 'user', 'Session 2 private data');

    // Dissolve session 1
    kernelManager.dissolveKernel(session1);

    // Session 1 should be destroyed
    const history1 = kernelManager.getConversationHistory(session1, 'token-1');
    expect(history1).toEqual([]);

    // Session 2 should still exist and be intact
    const history2 = kernelManager.getConversationHistory(session2, 'token-2');
    expect(history2).toHaveLength(1);
    expect(history2[0].content).toBe('Session 2 private data');

    // Clean up
    kernelManager.dissolveKernel(session2);
  });
});
