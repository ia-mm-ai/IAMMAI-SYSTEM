/**
 * Privacy test for conversation isolation
 * @see specs/001-ephemeral-kernel/tasks.md#T069
 * @see specs/001-ephemeral-kernel/data-model.md#Privacy Enforcement Points
 *
 * CRITICAL: Verifies that users cannot see each other's messages
 *
 * NOTE: These tests should FAIL initially (TDD approach)
 */

import { describe, it, expect, beforeAll, afterAll } from 'vitest';
import { query } from '../../src/lib/db.js';
import bcrypt from 'bcrypt';
import { generateToken } from '../../src/services/token.js';
import { kernelManager } from '../../src/kernel/manager.js';
import type { Message } from '../../src/lib/types.js';

describe('Privacy - Conversation Isolation', () => {
  let testAdminId: string;
  let testSessionId: string;

  beforeAll(async () => {
    // Create test admin
    const passwordHash = await bcrypt.hash('testPassword123!', 10);
    const adminResult = await query(
      `INSERT INTO admins (email, password_hash)
       VALUES ($1, $2)
       ON CONFLICT (email) DO UPDATE SET password_hash = $2
       RETURNING id`,
      ['test-privacy@example.com', passwordHash]
    );
    testAdminId = adminResult.rows[0].id;

    // Create test session
    const sessionResult = await query(
      `INSERT INTO sessions (name, state, admin_id, started_at)
       VALUES ($1, $2, $3, NOW())
       RETURNING id`,
      ['Privacy Test Session', 'ACTIVE', testAdminId]
    );
    testSessionId = sessionResult.rows[0].id;

    // Create kernel
    kernelManager.createKernel(testSessionId);
  });

  afterAll(async () => {
    // Clean up kernel
    kernelManager.dissolveKernel(testSessionId);

    // Clean up database
    await query('DELETE FROM sessions WHERE id = $1', [testSessionId]);
    await query('DELETE FROM admins WHERE id = $1', [testAdminId]);
  });

  it('should isolate conversations by token hash', () => {
    // Generate two different tokens
    const token1 = generateToken();
    const token2 = generateToken();

    // Create conversations for both tokens
    const conv1 = kernelManager.getOrCreateConversation(
      testSessionId,
      token1.hash,
      'presence-hash-1'
    );
    const conv2 = kernelManager.getOrCreateConversation(
      testSessionId,
      token2.hash,
      'presence-hash-2'
    );

    expect(conv1).toBeTruthy();
    expect(conv2).toBeTruthy();
    expect(conv1).not.toBe(conv2);

    // Add message to conversation 1
    const msg1 = kernelManager.addMessage(
      testSessionId,
      token1.hash,
      'user',
      'This is a private message from user 1'
    );

    expect(msg1).toBeTruthy();

    // Verify conversation 1 has the message
    const history1 = kernelManager.getConversationHistory(testSessionId, token1.hash);
    expect(history1).toHaveLength(1);
    expect(history1[0].content).toBe('This is a private message from user 1');

    // Verify conversation 2 does NOT have the message
    const history2 = kernelManager.getConversationHistory(testSessionId, token2.hash);
    expect(history2).toHaveLength(0);
  });

  it('should maintain separate message histories per token', () => {
    const token1 = generateToken();
    const token2 = generateToken();

    // Create conversations
    kernelManager.getOrCreateConversation(
      testSessionId,
      token1.hash,
      'presence-hash-1'
    );
    kernelManager.getOrCreateConversation(
      testSessionId,
      token2.hash,
      'presence-hash-2'
    );

    // Add messages to both conversations
    kernelManager.addMessage(
      testSessionId,
      token1.hash,
      'user',
      'User 1 message 1'
    );
    kernelManager.addMessage(
      testSessionId,
      token1.hash,
      'assistant',
      'Assistant response to user 1'
    );

    kernelManager.addMessage(
      testSessionId,
      token2.hash,
      'user',
      'User 2 message 1'
    );
    kernelManager.addMessage(
      testSessionId,
      token2.hash,
      'assistant',
      'Assistant response to user 2'
    );

    // Verify separate histories
    const history1 = kernelManager.getConversationHistory(testSessionId, token1.hash);
    const history2 = kernelManager.getConversationHistory(testSessionId, token2.hash);

    expect(history1).toHaveLength(2);
    expect(history2).toHaveLength(2);

    expect(history1[0].content).toBe('User 1 message 1');
    expect(history1[1].content).toBe('Assistant response to user 1');

    expect(history2[0].content).toBe('User 2 message 1');
    expect(history2[1].content).toBe('Assistant response to user 2');

    // Verify no cross-contamination
    const allMessages1 = history1.map((m) => m.content).join(' ');
    const allMessages2 = history2.map((m) => m.content).join(' ');

    expect(allMessages1).not.toContain('User 2');
    expect(allMessages2).not.toContain('User 1');
  });

  it('should not allow accessing another tokens conversation', () => {
    const token1 = generateToken();
    const token2 = generateToken();

    // Create conversation for token1
    kernelManager.getOrCreateConversation(
      testSessionId,
      token1.hash,
      'presence-hash-1'
    );

    kernelManager.addMessage(
      testSessionId,
      token1.hash,
      'user',
      'Secret message'
    );

    // Try to access with wrong token hash
    const wrongHistory = kernelManager.getConversationHistory(
      testSessionId,
      token2.hash
    );

    // Should return empty history, not token1's messages
    expect(wrongHistory).toHaveLength(0);
  });

  it('should maintain presence hash isolation', () => {
    const token1 = generateToken();
    const token2 = generateToken();

    const conv1 = kernelManager.getOrCreateConversation(
      testSessionId,
      token1.hash,
      'presence-aaa'
    );
    const conv2 = kernelManager.getOrCreateConversation(
      testSessionId,
      token2.hash,
      'presence-bbb'
    );

    expect(conv1?.presenceHash).toBe('presence-aaa');
    expect(conv2?.presenceHash).toBe('presence-bbb');

    // Presence hashes should be different
    expect(conv1?.presenceHash).not.toBe(conv2?.presenceHash);
  });

  it('should support multiple concurrent conversations in same session', () => {
    // Simulate 10 concurrent users
    const tokens = Array.from({ length: 10 }, () => generateToken());

    // Create conversations for all
    tokens.forEach((token, index) => {
      kernelManager.getOrCreateConversation(
        testSessionId,
        token.hash,
        `presence-${index}`
      );

      kernelManager.addMessage(
        testSessionId,
        token.hash,
        'user',
        `Message from user ${index}`
      );
    });

    // Verify each has exactly one message
    tokens.forEach((token, index) => {
      const history = kernelManager.getConversationHistory(testSessionId, token.hash);
      expect(history).toHaveLength(1);
      expect(history[0].content).toBe(`Message from user ${index}`);
    });

    // Verify no cross-contamination
    tokens.forEach((token, index) => {
      const history = kernelManager.getConversationHistory(testSessionId, token.hash);
      const otherMessages = tokens
        .filter((_, i) => i !== index)
        .map((_, i) => `user ${i}`);

      const content = history.map((m) => m.content).join(' ');
      otherMessages.forEach((otherMsg) => {
        expect(content).not.toContain(otherMsg);
      });
    });
  });

  it('should destroy all conversations on kernel dissolution', async () => {
    // Create separate session for this test
    const sessionResult = await query(
      `INSERT INTO sessions (name, state, admin_id, started_at)
       VALUES ($1, $2, $3, NOW())
       RETURNING id`,
      ['Dissolution Test Session', 'ACTIVE', testAdminId]
    );
    const dissolutionSessionId = sessionResult.rows[0].id;

    kernelManager.createKernel(dissolutionSessionId);

    // Create multiple conversations
    const tokens = Array.from({ length: 5 }, () => generateToken());
    tokens.forEach((token, index) => {
      kernelManager.getOrCreateConversation(
        dissolutionSessionId,
        token.hash,
        `presence-${index}`
      );
      kernelManager.addMessage(
        dissolutionSessionId,
        token.hash,
        'user',
        `Message ${index}`
      );
    });

    // Verify conversations exist
    tokens.forEach((token) => {
      const history = kernelManager.getConversationHistory(
        dissolutionSessionId,
        token.hash
      );
      expect(history.length).toBeGreaterThan(0);
    });

    // Dissolve kernel
    const dissolved = kernelManager.dissolveKernel(dissolutionSessionId);
    expect(dissolved).toBe(true);

    // Verify all conversations are gone
    tokens.forEach((token) => {
      const history = kernelManager.getConversationHistory(
        dissolutionSessionId,
        token.hash
      );
      expect(history).toHaveLength(0);
    });

    // Verify conversation cannot be retrieved
    tokens.forEach((token) => {
      const conv = kernelManager.getConversation(dissolutionSessionId, token.hash);
      expect(conv).toBeUndefined();
    });

    // Clean up
    await query('DELETE FROM sessions WHERE id = $1', [dissolutionSessionId]);
  });

  it('should not persist messages to database', async () => {
    const token = generateToken();

    await query(
      `INSERT INTO tokens (session_id, token_hash, joined_at)
       VALUES ($1, $2, NOW())`,
      [testSessionId, token.hash]
    );

    // Add messages
    kernelManager.getOrCreateConversation(
      testSessionId,
      token.hash,
      'presence-test'
    );
    kernelManager.addMessage(testSessionId, token.hash, 'user', 'Test message');
    kernelManager.addMessage(
      testSessionId,
      token.hash,
      'assistant',
      'Test response'
    );

    // Verify no message table exists
    const tableCheck = await query(
      `SELECT EXISTS (
         SELECT FROM information_schema.tables
         WHERE table_schema = 'public'
         AND table_name = 'messages'
       )`
    );

    expect(tableCheck.rows[0].exists).toBe(false);

    // Clean up
    await query('DELETE FROM tokens WHERE token_hash = $1', [token.hash]);
  });

  it('should use token hash as key, not raw token', () => {
    const tokenData = generateToken();

    // Create conversation
    const conv = kernelManager.getOrCreateConversation(
      testSessionId,
      tokenData.hash,
      'presence-test'
    );

    expect(conv).toBeTruthy();
    expect(conv?.tokenHash).toBe(tokenData.hash);

    // Verify cannot access with raw token
    const wrongAccess = kernelManager.getConversation(testSessionId, tokenData.raw);
    expect(wrongAccess).toBeUndefined();

    // Verify can only access with correct hash
    const correctAccess = kernelManager.getConversation(
      testSessionId,
      tokenData.hash
    );
    expect(correctAccess).toBeTruthy();
  });

  it('should enforce conversation boundary across sessions', async () => {
    // Create second session
    const session2Result = await query(
      `INSERT INTO sessions (name, state, admin_id, started_at)
       VALUES ($1, $2, $3, NOW())
       RETURNING id`,
      ['Second Privacy Session', 'ACTIVE', testAdminId]
    );
    const session2Id = session2Result.rows[0].id;

    kernelManager.createKernel(session2Id);

    const token = generateToken();

    // Add message to session 1
    kernelManager.getOrCreateConversation(
      testSessionId,
      token.hash,
      'presence-s1'
    );
    kernelManager.addMessage(
      testSessionId,
      token.hash,
      'user',
      'Message in session 1'
    );

    // Try to access from session 2 with same token hash
    const session2History = kernelManager.getConversationHistory(
      session2Id,
      token.hash
    );

    // Should be empty - conversations are session-scoped
    expect(session2History).toHaveLength(0);

    // Clean up
    kernelManager.dissolveKernel(session2Id);
    await query('DELETE FROM sessions WHERE id = $1', [session2Id]);
  });
});
