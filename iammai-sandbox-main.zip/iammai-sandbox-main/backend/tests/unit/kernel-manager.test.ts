/**
 * Unit tests for KernelManager
 * @see specs/001-ephemeral-kernel/tasks.md#T038
 */

import { describe, it, expect, beforeEach } from 'vitest';

// We need to create a fresh instance for each test to avoid state pollution
// So we'll import the class and create instances manually
import { Kernel } from '../../src/kernel/kernel.js';
import type { Conversation, Message } from '../../src/lib/types.js';

// Create a test-specific KernelManager class to avoid singleton issues
class TestKernelManager {
  private readonly kernels: Map<string, Kernel>;

  constructor() {
    this.kernels = new Map();
  }

  createKernel(sessionId: string): Kernel {
    if (this.kernels.has(sessionId)) {
      throw new Error(`Kernel already exists for session: ${sessionId}`);
    }

    const kernel = new Kernel(sessionId);
    this.kernels.set(sessionId, kernel);

    return kernel;
  }

  getKernel(sessionId: string): Kernel | undefined {
    return this.kernels.get(sessionId);
  }

  hasKernel(sessionId: string): boolean {
    return this.kernels.has(sessionId);
  }

  dissolveKernel(sessionId: string): boolean {
    const kernel = this.kernels.get(sessionId);

    if (!kernel) {
      return false;
    }

    kernel.dissolve();
    this.kernels.delete(sessionId);

    return true;
  }

  getOrCreateConversation(
    sessionId: string,
    tokenHash: string,
    presenceHash: string
  ): Conversation | null {
    const kernel = this.kernels.get(sessionId);

    if (!kernel) {
      return null;
    }

    return kernel.getOrCreateConversation(tokenHash, presenceHash);
  }

  getConversation(
    sessionId: string,
    tokenHash: string
  ): Conversation | undefined {
    const kernel = this.kernels.get(sessionId);
    return kernel?.getConversation(tokenHash);
  }

  addMessage(
    sessionId: string,
    tokenHash: string,
    role: 'user' | 'assistant',
    content: string
  ): Message | null {
    const kernel = this.kernels.get(sessionId);

    if (!kernel) {
      return null;
    }

    try {
      return kernel.addMessage(tokenHash, role, content);
    } catch {
      return null;
    }
  }

  getConversationHistory(
    sessionId: string,
    tokenHash: string
  ): Message[] {
    const kernel = this.kernels.get(sessionId);
    return kernel?.getConversationHistory(tokenHash) ?? [];
  }

  getKernelCount(): number {
    return this.kernels.size;
  }

  getTotalConversationCount(): number {
    let count = 0;
    for (const kernel of this.kernels.values()) {
      count += kernel.getConversationCount();
    }
    return count;
  }

  getActiveSessionIds(): string[] {
    return Array.from(this.kernels.keys());
  }
}

describe('KernelManager', () => {
  let kernelManager: TestKernelManager;

  beforeEach(() => {
    kernelManager = new TestKernelManager();
  });

  describe('createKernel', () => {
    it('should create a kernel for a session', () => {
      const sessionId = 'test-session-1';
      const kernel = kernelManager.createKernel(sessionId);

      expect(kernel).toBeDefined();
      expect(kernel.sessionId).toBe(sessionId);
      expect(kernelManager.hasKernel(sessionId)).toBe(true);
    });

    it('should throw if kernel already exists for session', () => {
      const sessionId = 'test-session-2';
      kernelManager.createKernel(sessionId);

      expect(() => kernelManager.createKernel(sessionId)).toThrow(
        `Kernel already exists for session: ${sessionId}`
      );
    });

    it('should allow creating kernels for different sessions', () => {
      const session1 = 'session-1';
      const session2 = 'session-2';

      kernelManager.createKernel(session1);
      kernelManager.createKernel(session2);

      expect(kernelManager.hasKernel(session1)).toBe(true);
      expect(kernelManager.hasKernel(session2)).toBe(true);
      expect(kernelManager.getKernelCount()).toBe(2);
    });
  });

  describe('dissolveKernel', () => {
    it('should dissolve an existing kernel', () => {
      const sessionId = 'test-session-3';
      kernelManager.createKernel(sessionId);

      const result = kernelManager.dissolveKernel(sessionId);

      expect(result).toBe(true);
      expect(kernelManager.hasKernel(sessionId)).toBe(false);
    });

    it('should return false when dissolving non-existent kernel', () => {
      const result = kernelManager.dissolveKernel('non-existent');

      expect(result).toBe(false);
    });

    it('should destroy all conversations on dissolution', () => {
      const sessionId = 'test-session-4';
      kernelManager.createKernel(sessionId);

      // Create some conversations
      kernelManager.getOrCreateConversation(sessionId, 'hash1', 'presence1');
      kernelManager.getOrCreateConversation(sessionId, 'hash2', 'presence2');

      // Add messages
      kernelManager.addMessage(sessionId, 'hash1', 'user', 'Hello');
      kernelManager.addMessage(sessionId, 'hash1', 'assistant', 'Hi there!');

      expect(kernelManager.getTotalConversationCount()).toBe(2);

      // Dissolve
      kernelManager.dissolveKernel(sessionId);

      // Verify all data is gone
      expect(kernelManager.hasKernel(sessionId)).toBe(false);
      expect(kernelManager.getConversation(sessionId, 'hash1')).toBeUndefined();
      expect(kernelManager.getConversationHistory(sessionId, 'hash1')).toEqual([]);
    });

    it('should complete dissolution in <50ms for 100 conversations', () => {
      const sessionId = 'perf-test-session';
      kernelManager.createKernel(sessionId);

      // Create 100 conversations with 100 messages each
      for (let i = 0; i < 100; i++) {
        const tokenHash = `hash-${i}`;
        const presenceHash = `presence-${i}`;
        kernelManager.getOrCreateConversation(sessionId, tokenHash, presenceHash);

        for (let j = 0; j < 100; j++) {
          const role = j % 2 === 0 ? 'user' : 'assistant';
          kernelManager.addMessage(sessionId, tokenHash, role, 'x'.repeat(500));
        }
      }

      const startTime = performance.now();
      kernelManager.dissolveKernel(sessionId);
      const duration = performance.now() - startTime;

      expect(duration).toBeLessThan(50);
      expect(kernelManager.hasKernel(sessionId)).toBe(false);
    });
  });

  describe('getOrCreateConversation', () => {
    it('should create a new conversation', () => {
      const sessionId = 'test-session-5';
      kernelManager.createKernel(sessionId);

      const conversation = kernelManager.getOrCreateConversation(
        sessionId,
        'token-hash',
        'presence-hash'
      );

      expect(conversation).not.toBeNull();
      expect(conversation?.tokenHash).toBe('token-hash');
      expect(conversation?.presenceHash).toBe('presence-hash');
      expect(conversation?.messages).toEqual([]);
    });

    it('should return existing conversation', () => {
      const sessionId = 'test-session-6';
      kernelManager.createKernel(sessionId);

      const conv1 = kernelManager.getOrCreateConversation(
        sessionId,
        'token-hash',
        'presence-hash'
      );
      const conv2 = kernelManager.getOrCreateConversation(
        sessionId,
        'token-hash',
        'presence-hash'
      );

      expect(conv1).toBe(conv2);
    });

    it('should return null if kernel does not exist', () => {
      const conversation = kernelManager.getOrCreateConversation(
        'non-existent',
        'token-hash',
        'presence-hash'
      );

      expect(conversation).toBeNull();
    });
  });

  describe('addMessage', () => {
    it('should add a message to a conversation', () => {
      const sessionId = 'test-session-7';
      kernelManager.createKernel(sessionId);
      kernelManager.getOrCreateConversation(sessionId, 'hash', 'presence');

      const message = kernelManager.addMessage(
        sessionId,
        'hash',
        'user',
        'Hello!'
      );

      expect(message).not.toBeNull();
      expect(message?.role).toBe('user');
      expect(message?.content).toBe('Hello!');

      const history = kernelManager.getConversationHistory(sessionId, 'hash');
      expect(history).toHaveLength(1);
      expect(history[0].content).toBe('Hello!');
    });

    it('should return null if kernel does not exist', () => {
      const message = kernelManager.addMessage(
        'non-existent',
        'hash',
        'user',
        'Hello!'
      );

      expect(message).toBeNull();
    });
  });

  describe('getConversationHistory', () => {
    it('should return empty array if kernel does not exist', () => {
      const history = kernelManager.getConversationHistory('non-existent', 'hash');
      expect(history).toEqual([]);
    });

    it('should return empty array if conversation does not exist', () => {
      const sessionId = 'test-session-8';
      kernelManager.createKernel(sessionId);

      const history = kernelManager.getConversationHistory(sessionId, 'non-existent');
      expect(history).toEqual([]);
    });

    it('should return messages in order', () => {
      const sessionId = 'test-session-9';
      kernelManager.createKernel(sessionId);
      kernelManager.getOrCreateConversation(sessionId, 'hash', 'presence');

      kernelManager.addMessage(sessionId, 'hash', 'user', 'First');
      kernelManager.addMessage(sessionId, 'hash', 'assistant', 'Second');
      kernelManager.addMessage(sessionId, 'hash', 'user', 'Third');

      const history = kernelManager.getConversationHistory(sessionId, 'hash');

      expect(history).toHaveLength(3);
      expect(history[0].content).toBe('First');
      expect(history[1].content).toBe('Second');
      expect(history[2].content).toBe('Third');
    });
  });

  describe('monitoring methods', () => {
    it('should return correct kernel count', () => {
      expect(kernelManager.getKernelCount()).toBe(0);

      kernelManager.createKernel('session-1');
      expect(kernelManager.getKernelCount()).toBe(1);

      kernelManager.createKernel('session-2');
      expect(kernelManager.getKernelCount()).toBe(2);

      kernelManager.dissolveKernel('session-1');
      expect(kernelManager.getKernelCount()).toBe(1);
    });

    it('should return correct conversation count', () => {
      kernelManager.createKernel('session-1');
      kernelManager.createKernel('session-2');

      expect(kernelManager.getTotalConversationCount()).toBe(0);

      kernelManager.getOrCreateConversation('session-1', 'hash1', 'p1');
      kernelManager.getOrCreateConversation('session-1', 'hash2', 'p2');
      kernelManager.getOrCreateConversation('session-2', 'hash3', 'p3');

      expect(kernelManager.getTotalConversationCount()).toBe(3);
    });

    it('should return active session IDs', () => {
      kernelManager.createKernel('session-a');
      kernelManager.createKernel('session-b');

      const ids = kernelManager.getActiveSessionIds();

      expect(ids).toContain('session-a');
      expect(ids).toContain('session-b');
      expect(ids).toHaveLength(2);
    });
  });
});
