/**
 * Unit tests for Token service
 * @see specs/001-ephemeral-kernel/tasks.md#T055
 * @see specs/001-ephemeral-kernel/research.md#Token Generation
 */

import { describe, it, expect } from 'vitest';
import {
  generateToken,
  generateSeed,
  hashToken,
  createActiveToken,
  isValidTokenFormat,
  secureCompare,
} from '../../src/services/token.js';

describe('Token Service', () => {
  describe('generateToken', () => {
    it('should generate a base64url encoded token', () => {
      const token = generateToken();

      expect(token).toBeDefined();
      expect(typeof token).toBe('string');
      // Base64url characters only
      expect(token).toMatch(/^[A-Za-z0-9_-]+$/);
    });

    it('should generate 256-bit (32 bytes) tokens', () => {
      const token = generateToken();

      // 32 bytes in base64url = ~43 characters
      // Base64 encoding: 4 characters per 3 bytes
      // 32 bytes = ceil(32/3) * 4 = 11 * 4 = 44 chars (but base64url may have no padding)
      expect(token.length).toBeGreaterThanOrEqual(40);
      expect(token.length).toBeLessThanOrEqual(50);

      // Verify we can decode it back to 32 bytes
      const buffer = Buffer.from(token, 'base64url');
      expect(buffer.length).toBe(32);
    });

    it('should generate unique tokens each time', () => {
      const tokens = new Set<string>();
      const iterations = 1000;

      for (let i = 0; i < iterations; i++) {
        tokens.add(generateToken());
      }

      // All tokens should be unique
      expect(tokens.size).toBe(iterations);
    });

    it('should generate cryptographically random tokens', () => {
      // Generate many tokens and check for randomness patterns
      const tokens: string[] = [];
      for (let i = 0; i < 100; i++) {
        tokens.push(generateToken());
      }

      // No duplicates
      const uniqueTokens = new Set(tokens);
      expect(uniqueTokens.size).toBe(100);

      // Check that tokens don't share common prefixes (beyond what's expected)
      const prefixes = tokens.map((t) => t.substring(0, 4));
      const uniquePrefixes = new Set(prefixes);
      // With random data, we expect high diversity in prefixes
      expect(uniquePrefixes.size).toBeGreaterThan(50);
    });
  });

  describe('generateSeed', () => {
    it('should generate a base64url encoded seed', () => {
      const seed = generateSeed();

      expect(seed).toBeDefined();
      expect(typeof seed).toBe('string');
      expect(seed).toMatch(/^[A-Za-z0-9_-]+$/);
    });

    it('should generate 128-bit (16 bytes) seeds', () => {
      const seed = generateSeed();

      // 16 bytes in base64url = ~22 characters
      const buffer = Buffer.from(seed, 'base64url');
      expect(buffer.length).toBe(16);
    });

    it('should generate unique seeds each time', () => {
      const seeds = new Set<string>();

      for (let i = 0; i < 100; i++) {
        seeds.add(generateSeed());
      }

      expect(seeds.size).toBe(100);
    });
  });

  describe('hashToken', () => {
    it('should return a SHA-256 hash as hex string', () => {
      const token = 'test-token-value';
      const hash = hashToken(token);

      expect(typeof hash).toBe('string');
      // SHA-256 = 256 bits = 32 bytes = 64 hex characters
      expect(hash.length).toBe(64);
      expect(hash).toMatch(/^[0-9a-f]{64}$/);
    });

    it('should produce consistent hashes for same input', () => {
      const token = generateToken();
      const hash1 = hashToken(token);
      const hash2 = hashToken(token);

      expect(hash1).toBe(hash2);
    });

    it('should produce different hashes for different inputs', () => {
      const token1 = generateToken();
      const token2 = generateToken();

      const hash1 = hashToken(token1);
      const hash2 = hashToken(token2);

      expect(hash1).not.toBe(hash2);
    });

    it('should be one-way (not reversible)', () => {
      const token = 'sensitive-token-value';
      const hash = hashToken(token);

      // Hash should not contain any part of the original token
      expect(hash).not.toContain(token);
      expect(hash).not.toContain('sensitive');
      expect(hash).not.toContain('token');
    });
  });

  describe('createActiveToken', () => {
    it('should create a complete active token object', () => {
      const sessionId = 'test-session-123';
      const activeToken = createActiveToken(sessionId);

      expect(activeToken).toHaveProperty('raw');
      expect(activeToken).toHaveProperty('hash');
      expect(activeToken).toHaveProperty('seed');
      expect(activeToken).toHaveProperty('sessionId', sessionId);
      expect(activeToken).toHaveProperty('issuedAt');
      expect(activeToken.issuedAt).toBeInstanceOf(Date);
    });

    it('should have matching raw and hash values', () => {
      const activeToken = createActiveToken('session-1');

      // Hash should be derived from raw token
      const expectedHash = hashToken(activeToken.raw);
      expect(activeToken.hash).toBe(expectedHash);
    });

    it('should generate valid token and seed formats', () => {
      const activeToken = createActiveToken('session-2');

      expect(isValidTokenFormat(activeToken.raw)).toBe(true);
      // Seed should also be base64url
      expect(activeToken.seed).toMatch(/^[A-Za-z0-9_-]+$/);
    });

    it('should generate unique tokens for each call', () => {
      const token1 = createActiveToken('session-1');
      const token2 = createActiveToken('session-1');

      expect(token1.raw).not.toBe(token2.raw);
      expect(token1.hash).not.toBe(token2.hash);
      expect(token1.seed).not.toBe(token2.seed);
    });
  });

  describe('isValidTokenFormat', () => {
    it('should return true for valid tokens', () => {
      const token = generateToken();
      expect(isValidTokenFormat(token)).toBe(true);
    });

    it('should return false for too short tokens', () => {
      expect(isValidTokenFormat('short')).toBe(false);
      expect(isValidTokenFormat('a'.repeat(39))).toBe(false);
    });

    it('should return false for too long tokens', () => {
      expect(isValidTokenFormat('a'.repeat(51))).toBe(false);
    });

    it('should return false for tokens with invalid characters', () => {
      expect(isValidTokenFormat('a'.repeat(43) + '!')).toBe(false);
      expect(isValidTokenFormat('a'.repeat(43) + ' ')).toBe(false);
      expect(isValidTokenFormat('a'.repeat(43) + '=')).toBe(false);
      expect(isValidTokenFormat('a'.repeat(43) + '/')).toBe(false);
      expect(isValidTokenFormat('a'.repeat(43) + '+')).toBe(false);
    });

    it('should accept valid base64url characters', () => {
      // Valid base64url includes: A-Z, a-z, 0-9, _, -
      const validToken = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghij1234_-';
      expect(isValidTokenFormat(validToken)).toBe(true);
    });
  });

  describe('secureCompare', () => {
    it('should return true for equal strings', () => {
      expect(secureCompare('test', 'test')).toBe(true);
      expect(secureCompare('a'.repeat(64), 'a'.repeat(64))).toBe(true);
    });

    it('should return false for different strings', () => {
      expect(secureCompare('test1', 'test2')).toBe(false);
      expect(secureCompare('abc', 'abd')).toBe(false);
    });

    it('should return false for strings of different lengths', () => {
      expect(secureCompare('short', 'longer')).toBe(false);
      expect(secureCompare('abc', 'abcd')).toBe(false);
    });

    it('should be resistant to timing attacks', () => {
      // This is a basic check - true timing attack resistance requires
      // more sophisticated testing with timing measurements
      const hash1 = hashToken('token1');
      const hash2 = hashToken('token2');

      // Run comparison multiple times to warm up
      for (let i = 0; i < 100; i++) {
        secureCompare(hash1, hash1);
        secureCompare(hash1, hash2);
      }

      // Timing should be similar regardless of where strings differ
      // We're just verifying the function works correctly here
      expect(secureCompare(hash1, hash1)).toBe(true);
      expect(secureCompare(hash1, hash2)).toBe(false);
    });
  });

  describe('Token Privacy Guarantees', () => {
    it('should not embed any information in tokens', () => {
      const sessionId = 'session-with-secret-info';
      const activeToken = createActiveToken(sessionId);

      // Token should not contain session ID
      expect(activeToken.raw).not.toContain('session');
      expect(activeToken.raw).not.toContain(sessionId);

      // Hash should not contain any identifiable info
      expect(activeToken.hash).not.toContain('session');
    });

    it('should generate opaque tokens', () => {
      // Tokens should be indistinguishable from random data
      const tokens = Array.from({ length: 10 }, () =>
        createActiveToken(`session-${Math.random()}`)
      );

      // All tokens should look similar (same length, same character set)
      const lengths = tokens.map((t) => t.raw.length);
      expect(Math.max(...lengths) - Math.min(...lengths)).toBeLessThanOrEqual(2);
    });

    it('should have sufficient entropy', () => {
      // 256 bits = 2^256 possible values
      // With 1000 tokens, we should never see a collision
      const tokens = Array.from({ length: 1000 }, () => generateToken());
      const uniqueTokens = new Set(tokens);

      expect(uniqueTokens.size).toBe(1000);
    });
  });
});
