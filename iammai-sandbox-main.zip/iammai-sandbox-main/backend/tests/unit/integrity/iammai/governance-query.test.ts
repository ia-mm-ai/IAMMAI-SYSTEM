/**
 * Governance Query — Unit Tests (8 Audit Questions)
 */

import { describe, it, expect } from 'vitest';
import {
  queryCurrentPhase,
  queryAdmissibility,
  queryStanding,
  queryResolution,
  queryLineage,
  queryAttribution,
  queryContributions,
  queryPreservation,
  auditMatter,
} from '../../../../src/integrity/iammai/governance-query.js';
import type { IammaiEvaluationContext } from '../../../../src/integrity/iammai/types.js';

function makeCtx(overrides: Partial<IammaiEvaluationContext> = {}): IammaiEvaluationContext {
  return {
    stateRecords: [],
    transitionRecords: [],
    governanceActions: [],
    witnessArtifacts: [],
    validationArtifacts: [],
    contributionRecords: [],
    containmentRecords: [],
    ...overrides,
  };
}

describe('Q1: queryCurrentPhase', () => {
  it('returns null when no state records', () => {
    const result = queryCurrentPhase(makeCtx());
    expect(result.question).toBe('Q1_CURRENT_PHASE');
    expect(result.phase).toBeNull();
  });

  it('returns latest phase', () => {
    const result = queryCurrentPhase(makeCtx({
      stateRecords: [
        { state_id: 's1', matter_ref: 'm1', state_family: 'preparation', state_type: 'signal', recorded_at: new Date(), predecessor_ref: null, containment_ref: null, related_transition_ref: null, related_governance_ref: null, related_validation_ref: null, related_witness_ref: null },
        { state_id: 's2', matter_ref: 'm1', state_family: 'preparation', state_type: 'acceptance', recorded_at: new Date(), predecessor_ref: 's1', containment_ref: null, related_transition_ref: null, related_governance_ref: null, related_validation_ref: null, related_witness_ref: null },
      ],
    }));
    expect(result.phase).toBe('acceptance');
    expect(result.family).toBe('preparation');
    expect(result.ordinal).toBe(2);
  });

  it('detects held state', () => {
    const result = queryCurrentPhase(makeCtx({
      stateRecords: [
        { state_id: 's1', matter_ref: 'm1', state_family: 'standing', state_type: 'truth', recorded_at: new Date(), predecessor_ref: null, containment_ref: null, related_transition_ref: null, related_governance_ref: null, related_validation_ref: null, related_witness_ref: null },
      ],
      containmentRecords: [
        { containment_id: 'c1', matter_ref: 'm1', target_state_ref: 's1', action: 'HOLD', actor_ref: 'a1', reason: 'test', recorded_at: new Date(), governance_action_ref: 'g1' },
      ],
    }));
    expect(result.isHeld).toBe(true);
  });
});

describe('Q2: queryAdmissibility', () => {
  it('returns not admissible when no signal state', () => {
    const result = queryAdmissibility(makeCtx());
    expect(result.admissible).toBe(false);
  });

  it('returns admissible with signal state', () => {
    const result = queryAdmissibility(makeCtx({
      stateRecords: [
        { state_id: 's1', matter_ref: 'm1', state_family: 'preparation', state_type: 'signal', recorded_at: new Date(), predecessor_ref: null, containment_ref: null, related_transition_ref: null, related_governance_ref: 'gov-1', related_validation_ref: null, related_witness_ref: null },
      ],
      governanceActions: [
        { governance_action_id: 'gov-1', action_type: 'authorize', authority_class: 'OPERATOR', actor_ref: 'admin-1', legitimacy_basis_ref: 'basis-1', matter_ref: 'm1', acted_at: new Date(), delegated_from_ref: null, target_state_ref: null, target_transition_ref: null, contribution_role_map_ref: null },
      ],
    }));
    expect(result.admissible).toBe(true);
    expect(result.authorizingAction?.action_type).toBe('authorize');
  });
});

describe('Q3: queryStanding', () => {
  it('returns no standing when only preparation phases', () => {
    const result = queryStanding(makeCtx({
      stateRecords: [
        { state_id: 's1', matter_ref: 'm1', state_family: 'preparation', state_type: 'signal', recorded_at: new Date(), predecessor_ref: null, containment_ref: null, related_transition_ref: null, related_governance_ref: null, related_validation_ref: null, related_witness_ref: null },
      ],
    }));
    expect(result.hasStanding).toBe(false);
  });

  it('returns standing states', () => {
    const result = queryStanding(makeCtx({
      stateRecords: [
        { state_id: 's1', matter_ref: 'm1', state_family: 'preparation', state_type: 'signal', recorded_at: new Date(), predecessor_ref: null, containment_ref: null, related_transition_ref: null, related_governance_ref: null, related_validation_ref: null, related_witness_ref: null },
        { state_id: 's6', matter_ref: 'm1', state_family: 'standing', state_type: 'truth', recorded_at: new Date(), predecessor_ref: 's1', containment_ref: null, related_transition_ref: null, related_governance_ref: null, related_validation_ref: null, related_witness_ref: null },
      ],
    }));
    expect(result.hasStanding).toBe(true);
    expect(result.currentStandingPhase).toBe('truth');
    expect(result.standingStates).toHaveLength(1);
  });
});

describe('Q4: queryResolution', () => {
  it('returns not resolved when no resolution transitions', () => {
    const result = queryResolution(makeCtx());
    expect(result.resolved).toBe(false);
  });

  it('returns resolution details', () => {
    const result = queryResolution(makeCtx({
      transitionRecords: [
        { transition_id: 't1', matter_ref: 'm1', source_ref: 's1', target_ref: 's1', transition_type: 'resolution_transition', occurred_at: new Date(), resolution_type: 'FINALIZE', predecessor_ref: null },
      ],
      governanceActions: [
        { governance_action_id: 'gov-1', action_type: 'finalize', authority_class: 'OPERATOR', actor_ref: 'admin-1', legitimacy_basis_ref: 'basis-1', matter_ref: 'm1', acted_at: new Date(), delegated_from_ref: null, target_state_ref: null, target_transition_ref: null, contribution_role_map_ref: null },
      ],
    }));
    expect(result.resolved).toBe(true);
    expect(result.resolutionType).toBe('FINALIZE');
    expect(result.resolvingAction?.action_type).toBe('finalize');
  });
});

describe('Q5: queryLineage', () => {
  it('returns empty lineage when no states', () => {
    const result = queryLineage(makeCtx());
    expect(result.stateCount).toBe(0);
  });

  it('detects external predecessor (EVOLVE)', () => {
    const result = queryLineage(makeCtx({
      stateRecords: [
        { state_id: 's1', matter_ref: 'm2', state_family: 'preparation', state_type: 'signal', recorded_at: new Date(), predecessor_ref: 'external-state-from-m1', containment_ref: null, related_transition_ref: null, related_governance_ref: null, related_validation_ref: null, related_witness_ref: null },
      ],
    }));
    expect(result.hasExternalPredecessor).toBe(true);
    expect(result.externalPredecessorRef).toBe('external-state-from-m1');
  });
});

describe('Q6: queryAttribution', () => {
  it('returns empty actions when none exist', () => {
    const result = queryAttribution(makeCtx());
    expect(result.actions).toHaveLength(0);
    expect(result.uniqueActors).toHaveLength(0);
  });

  it('returns governance actions with unique actors', () => {
    const result = queryAttribution(makeCtx({
      governanceActions: [
        { governance_action_id: 'g1', action_type: 'authorize', authority_class: 'OPERATOR', actor_ref: 'admin-1', legitimacy_basis_ref: 'b1', matter_ref: 'm1', acted_at: new Date(), delegated_from_ref: null, target_state_ref: null, target_transition_ref: null, contribution_role_map_ref: null },
        { governance_action_id: 'g2', action_type: 'hold', authority_class: 'SYSTEM', actor_ref: 'system', legitimacy_basis_ref: 'b2', matter_ref: 'm1', acted_at: new Date(), delegated_from_ref: null, target_state_ref: null, target_transition_ref: null, contribution_role_map_ref: null },
      ],
    }));
    expect(result.actions).toHaveLength(2);
    expect(result.uniqueActors).toEqual(['admin-1', 'system']);
  });
});

describe('Q7: queryContributions', () => {
  it('groups roles by actor', () => {
    const result = queryContributions(makeCtx({
      contributionRecords: [
        { contribution_id: 'cr1', matter_ref: 'm1', actor_ref: 'admin-1', role: 'ORIGIN', recorded_at: new Date(), context_ref: null },
        { contribution_id: 'cr2', matter_ref: 'm1', actor_ref: 'admin-1', role: 'AUTHORIZATION', recorded_at: new Date(), context_ref: null },
        { contribution_id: 'cr3', matter_ref: 'm1', actor_ref: 'agent-1', role: 'FORMALIZATION', recorded_at: new Date(), context_ref: null },
      ],
    }));
    expect(result.rolesByActor['admin-1']).toEqual(['ORIGIN', 'AUTHORIZATION']);
    expect(result.rolesByActor['agent-1']).toEqual(['FORMALIZATION']);
  });
});

describe('Q8: queryPreservation', () => {
  it('counts all records', () => {
    const result = queryPreservation(makeCtx({
      stateRecords: [
        { state_id: 's1', matter_ref: 'm1', state_family: 'preparation', state_type: 'signal', recorded_at: new Date(), predecessor_ref: null, containment_ref: null, related_transition_ref: null, related_governance_ref: null, related_validation_ref: null, related_witness_ref: null },
      ],
      governanceActions: [
        { governance_action_id: 'g1', action_type: 'authorize', authority_class: 'OPERATOR', actor_ref: 'a1', legitimacy_basis_ref: 'b1', matter_ref: 'm1', acted_at: new Date(), delegated_from_ref: null, target_state_ref: null, target_transition_ref: null, contribution_role_map_ref: null },
      ],
    }));
    expect(result.totalRecords).toBe(2);
    expect(result.stateRecordCount).toBe(1);
    expect(result.governanceActionCount).toBe(1);
  });
});

describe('auditMatter', () => {
  it('returns all 8 answers', () => {
    const answers = auditMatter(makeCtx());
    expect(answers).toHaveLength(8);
    const questions = answers.map(a => a.question);
    expect(questions).toEqual([
      'Q1_CURRENT_PHASE',
      'Q2_ADMISSIBILITY',
      'Q3_STANDING',
      'Q4_RESOLUTION',
      'Q5_LINEAGE',
      'Q6_ATTRIBUTION',
      'Q7_CONTRIBUTIONS',
      'Q8_PRESERVATION',
    ]);
  });
});
