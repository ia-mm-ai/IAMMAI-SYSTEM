/**
 * IAMMAI Conformance Assessor — Unit Tests
 */

import { describe, it, expect } from 'vitest';
import { assessConformance } from '../../../../src/integrity/iammai/conformance-assessor.js';
import type { IammaiEvaluationContext, IammaiStateRecord, IammaiGovernanceAction, IammaiContributionRecord } from '../../../../src/integrity/iammai/types.js';
import { MANDATORY_NON_CLAIMS } from '../../../../src/integrity/iammai/types.js';

function makeFullContext(): IammaiEvaluationContext {
  const stateRecords: IammaiStateRecord[] = [
    { state_id: 's1', matter_ref: 'bnk:session:test', state_family: 'preparation', state_type: 'signal', recorded_at: new Date(), predecessor_ref: null, containment_ref: null, related_transition_ref: null, related_governance_ref: 'ga-1', related_validation_ref: null, related_witness_ref: null },
    { state_id: 's2', matter_ref: 'bnk:session:test', state_family: 'preparation', state_type: 'acceptance', recorded_at: new Date(), predecessor_ref: 's1', containment_ref: null, related_transition_ref: null, related_governance_ref: 'ga-2', related_validation_ref: null, related_witness_ref: null },
    { state_id: 's3', matter_ref: 'bnk:session:test', state_family: 'preparation', state_type: 'scope', recorded_at: new Date(), predecessor_ref: 's2', containment_ref: null, related_transition_ref: null, related_governance_ref: null, related_validation_ref: null, related_witness_ref: null },
    { state_id: 's4', matter_ref: 'bnk:session:test', state_family: 'preparation', state_type: 'presence', recorded_at: new Date(), predecessor_ref: 's3', containment_ref: null, related_transition_ref: null, related_governance_ref: null, related_validation_ref: null, related_witness_ref: null },
    { state_id: 's5', matter_ref: 'bnk:session:test', state_family: 'preparation', state_type: 'threshold', recorded_at: new Date(), predecessor_ref: 's4', containment_ref: null, related_transition_ref: null, related_governance_ref: null, related_validation_ref: null, related_witness_ref: null },
    { state_id: 's6', matter_ref: 'bnk:session:test', state_family: 'standing', state_type: 'truth', recorded_at: new Date(), predecessor_ref: 's5', containment_ref: null, related_transition_ref: null, related_governance_ref: null, related_validation_ref: null, related_witness_ref: null },
  ];

  const governanceActions: IammaiGovernanceAction[] = [
    { governance_action_id: 'ga-1', action_type: 'authorize', authority_class: 'OPERATOR', actor_ref: 'bnk:admin:a1', legitimacy_basis_ref: 'session_creation', matter_ref: 'bnk:session:test', acted_at: new Date(), delegated_from_ref: null, target_state_ref: null, target_transition_ref: null, contribution_role_map_ref: null },
    { governance_action_id: 'ga-2', action_type: 'authorize', authority_class: 'OPERATOR', actor_ref: 'bnk:admin:a1', legitimacy_basis_ref: 'session_creation', matter_ref: 'bnk:session:test', acted_at: new Date(), delegated_from_ref: null, target_state_ref: null, target_transition_ref: null, contribution_role_map_ref: null },
  ];

  const contributionRecords: IammaiContributionRecord[] = [
    { contribution_id: 'c1', matter_ref: 'bnk:session:test', actor_ref: 'bnk:admin:a1', role: 'ORIGIN', recorded_at: new Date(), context_ref: null },
    { contribution_id: 'c2', matter_ref: 'bnk:session:test', actor_ref: 'bnk:admin:a1', role: 'AUTHORIZATION', recorded_at: new Date(), context_ref: null },
  ];

  return {
    stateRecords,
    transitionRecords: [
      { transition_id: 't1', matter_ref: 'bnk:session:test', source_ref: 's1', target_ref: 's2', transition_type: 'preparation_progression', occurred_at: new Date(), resolution_type: null, predecessor_ref: null },
    ],
    governanceActions,
    witnessArtifacts: [
      { witness_id: 'w1', witness_type: 'transition', target_ref: 's1', observed_at: new Date(), claims: ['Phase advanced'], non_claims: { ...MANDATORY_NON_CLAIMS }, actor_ref: null, surface_ref: null },
    ],
    validationArtifacts: [
      { validation_id: 'v1', validation_type: 'transition_legality', target_ref: 'bnk:session:test', condition_set_ref: 'test', outcome: 'pass', checked_at: new Date(), reason_refs: null, actor_ref: null },
    ],
    contributionRecords,
    containmentRecords: [],
  };
}

function makeEmptyContext(): IammaiEvaluationContext {
  return {
    stateRecords: [],
    transitionRecords: [],
    governanceActions: [],
    witnessArtifacts: [],
    validationArtifacts: [],
    contributionRecords: [],
    containmentRecords: [],
  };
}

describe('ConformanceAssessor', () => {
  describe('assessConformance', () => {
    it('returns CONFORMANT for a well-formed context', () => {
      const report = assessConformance('bnk:session:test', makeFullContext());
      expect(report.overall).toBe('CONFORMANT');
      expect(report.fail_count).toBe(0);
    });

    it('returns all 10 categories', () => {
      const report = assessConformance('bnk:session:test', makeFullContext());
      expect(report.categories).toHaveLength(10);
    });

    it('returns NON_CONFORMANT or PARTIAL for empty context', () => {
      const report = assessConformance('bnk:session:test', makeEmptyContext());
      expect(['NON_CONFORMANT', 'PARTIAL']).toContain(report.overall);
      expect(report.fail_count).toBeGreaterThan(0);
    });

    it('reports PHASE_INTEGRITY pass for valid phases', () => {
      const report = assessConformance('bnk:session:test', makeFullContext());
      const phaseAssessment = report.categories.find(c => c.category === 'PHASE_INTEGRITY');
      expect(phaseAssessment?.result).toBe('PASS');
    });

    it('reports STATE_FAMILY pass for correct families', () => {
      const report = assessConformance('bnk:session:test', makeFullContext());
      const assessment = report.categories.find(c => c.category === 'STATE_FAMILY');
      expect(assessment?.result).toBe('PASS');
    });

    it('reports LINEAGE_PRESERVATION pass with predecessor chain', () => {
      const report = assessConformance('bnk:session:test', makeFullContext());
      const assessment = report.categories.find(c => c.category === 'LINEAGE_PRESERVATION');
      expect(assessment?.result).toBe('PASS');
    });

    it('reports RESOLUTION_LEGALITY as NOT_APPLICABLE when no resolution', () => {
      const report = assessConformance('bnk:session:test', makeFullContext());
      const assessment = report.categories.find(c => c.category === 'RESOLUTION_LEGALITY');
      expect(assessment?.result).toBe('NOT_APPLICABLE');
    });

    it('reports GOVERNANCE_ATTRIBUTION pass with attributed actions', () => {
      const report = assessConformance('bnk:session:test', makeFullContext());
      const assessment = report.categories.find(c => c.category === 'GOVERNANCE_ATTRIBUTION');
      expect(assessment?.result).toBe('PASS');
    });

    it('reports CONTRIBUTION_COMPLETENESS pass with ORIGIN role', () => {
      const report = assessConformance('bnk:session:test', makeFullContext());
      const assessment = report.categories.find(c => c.category === 'CONTRIBUTION_COMPLETENESS');
      expect(assessment?.result).toBe('PASS');
    });

    it('reports AUDIT_ANSWERABILITY pass', () => {
      const report = assessConformance('bnk:session:test', makeFullContext());
      const assessment = report.categories.find(c => c.category === 'AUDIT_ANSWERABILITY');
      expect(assessment?.result).toBe('PASS');
    });

    it('includes matter_ref and timestamp in report', () => {
      const report = assessConformance('bnk:session:test', makeFullContext());
      expect(report.matter_ref).toBe('bnk:session:test');
      expect(report.assessed_at).toBeInstanceOf(Date);
    });

    it('reports PARTIAL when some categories pass and some fail', () => {
      const ctx = makeFullContext();
      // Remove contributions to cause CONTRIBUTION_COMPLETENESS to fail
      ctx.contributionRecords = [];
      const report = assessConformance('bnk:session:test', ctx);
      expect(report.overall).toBe('PARTIAL');
      expect(report.pass_count).toBeGreaterThan(0);
      expect(report.fail_count).toBeGreaterThan(0);
    });

    it('detects phase integrity failure when first phase is not signal', () => {
      const ctx = makeFullContext();
      ctx.stateRecords[0] = { ...ctx.stateRecords[0], state_type: 'acceptance' };
      const report = assessConformance('bnk:session:test', ctx);
      const assessment = report.categories.find(c => c.category === 'PHASE_INTEGRITY');
      expect(assessment?.result).toBe('FAIL');
    });

    it('detects state family mismatch', () => {
      const ctx = makeFullContext();
      ctx.stateRecords[0] = { ...ctx.stateRecords[0], state_family: 'standing' };
      const report = assessConformance('bnk:session:test', ctx);
      const assessment = report.categories.find(c => c.category === 'STATE_FAMILY');
      expect(assessment?.result).toBe('FAIL');
    });
  });
});
