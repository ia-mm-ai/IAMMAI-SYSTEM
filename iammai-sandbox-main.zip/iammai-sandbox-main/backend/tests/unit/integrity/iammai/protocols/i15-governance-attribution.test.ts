/**
 * I.15 Governance Attribution — Unit Tests
 */

import { describe, it, expect } from 'vitest';
import { I15GovernanceAttribution } from '../../../../../src/integrity/iammai/protocols/i15-governance-attribution.js';
import type { EvaluationContext } from '../../../../../src/integrity/types.js';
import type { IammaiGovernanceAction, IammaiEvaluationContext } from '../../../../../src/integrity/iammai/types.js';

const evaluator = new I15GovernanceAttribution();

function makeAction(overrides: Partial<IammaiGovernanceAction> = {}): IammaiGovernanceAction {
  return {
    governance_action_id: 'ga-1',
    action_type: 'authorize',
    authority_class: 'OPERATOR',
    actor_ref: 'bnk:admin:test',
    legitimacy_basis_ref: 'session_creation',
    matter_ref: 'bnk:session:test',
    acted_at: new Date(),
    delegated_from_ref: null,
    target_state_ref: null,
    target_transition_ref: null,
    contribution_role_map_ref: null,
    ...overrides,
  };
}

function makeContext(
  iammaiTracked: boolean,
  actions: IammaiGovernanceAction[] = []
): EvaluationContext {
  const iammaiContext: IammaiEvaluationContext = {
    stateRecords: [],
    transitionRecords: [],
    governanceActions: actions,
    witnessArtifacts: [],
    validationArtifacts: [],
    contributionRecords: [],
    containmentRecords: [],
  };

  return {
    session: { iammaiTracked } as any,
    ledgerEntries: [],
    presenceRecords: [],
    adminActions: [],
    coAgencyActions: [],
    iammaiContext: iammaiTracked ? iammaiContext : undefined,
  };
}

describe('I15GovernanceAttribution', () => {
  it('has correct id and version', () => {
    expect(evaluator.id).toBe('I.15');
    expect(evaluator.version).toBe('1.0.0');
  });

  it('PASS for non-IAMMAI sessions', () => {
    const result = evaluator.evaluate(makeContext(false));
    expect(result.result).toBe('PASS');
    expect(result.details).toContain('Non-IAMMAI');
  });

  it('FAIL when no IAMMAI context loaded', () => {
    const ctx = makeContext(true);
    ctx.iammaiContext = undefined;
    const result = evaluator.evaluate(ctx);
    expect(result.result).toBe('FAIL');
  });

  it('PASS with no governance actions', () => {
    const result = evaluator.evaluate(makeContext(true, []));
    expect(result.result).toBe('PASS');
  });

  it('PASS with fully attributed governance action', () => {
    const result = evaluator.evaluate(makeContext(true, [makeAction()]));
    expect(result.result).toBe('PASS');
    expect(result.details).toContain('1 governance actions verified');
  });

  it('PASS with multiple fully attributed actions', () => {
    const result = evaluator.evaluate(makeContext(true, [
      makeAction({ governance_action_id: 'ga-1' }),
      makeAction({ governance_action_id: 'ga-2', action_type: 'hold' }),
    ]));
    expect(result.result).toBe('PASS');
    expect(result.details).toContain('2 governance actions verified');
  });

  it('FAIL when actor_ref is missing', () => {
    const result = evaluator.evaluate(makeContext(true, [
      makeAction({ actor_ref: '' }),
    ]));
    expect(result.result).toBe('FAIL');
    expect(result.details).toContain('missing actor_ref');
  });

  it('FAIL when authority_class is invalid', () => {
    const result = evaluator.evaluate(makeContext(true, [
      makeAction({ authority_class: 'INVALID' as any }),
    ]));
    expect(result.result).toBe('FAIL');
    expect(result.details).toContain('invalid authority_class');
  });

  it('FAIL when legitimacy_basis_ref is missing', () => {
    const result = evaluator.evaluate(makeContext(true, [
      makeAction({ legitimacy_basis_ref: '' }),
    ]));
    expect(result.result).toBe('FAIL');
    expect(result.details).toContain('missing legitimacy_basis_ref');
  });

  it('FAIL when matter_ref is missing', () => {
    const result = evaluator.evaluate(makeContext(true, [
      makeAction({ matter_ref: '' }),
    ]));
    expect(result.result).toBe('FAIL');
    expect(result.details).toContain('missing matter_ref');
  });

  it('PASS with SYSTEM authority class', () => {
    const result = evaluator.evaluate(makeContext(true, [
      makeAction({ authority_class: 'SYSTEM', actor_ref: 'bnk:system:coordinator' }),
    ]));
    expect(result.result).toBe('PASS');
  });

  it('PASS with DELEGATED authority class', () => {
    const result = evaluator.evaluate(makeContext(true, [
      makeAction({ authority_class: 'DELEGATED' }),
    ]));
    expect(result.result).toBe('PASS');
  });
});
