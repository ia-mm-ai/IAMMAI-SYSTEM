/**
 * I.11 Phase Integrity — Unit Tests
 */

import { describe, it, expect } from 'vitest';
import { I11PhaseIntegrity } from '../../../../../src/integrity/iammai/protocols/i11-phase-integrity.js';
import type { EvaluationContext } from '../../../../../src/integrity/types.js';
import type { IammaiStateRecord, IammaiEvaluationContext } from '../../../../../src/integrity/iammai/types.js';

const evaluator = new I11PhaseIntegrity();

function makeContext(
  iammaiTracked: boolean,
  stateRecords: Partial<IammaiStateRecord>[]
): EvaluationContext {
  const iammaiContext: IammaiEvaluationContext = {
    stateRecords: stateRecords.map((r, i) => ({
      state_id: `state-${i}`,
      matter_ref: 'bnk:session:abc',
      state_family: r.state_family ?? 'preparation',
      state_type: r.state_type ?? 'signal',
      recorded_at: new Date(),
      predecessor_ref: i > 0 ? `state-${i - 1}` : null,
      containment_ref: null,
      related_transition_ref: null,
      related_governance_ref: null,
      related_validation_ref: null,
      related_witness_ref: null,
      ...r,
    })),
    transitionRecords: [],
    governanceActions: [],
    witnessArtifacts: [],
    validationArtifacts: [],
    contributionRecords: [],
    containmentRecords: [],
  };

  return {
    session: { iammaiTracked } as any,
    ledgerEntries: [],
    presenceRecords: [],
    adminActions: [],
    coAgencyActions: [],
    iammaiContext: iammaiTracked ? iammaiContext : undefined,
  };
}

describe('I11PhaseIntegrity', () => {
  it('has correct id and version', () => {
    expect(evaluator.id).toBe('I.11');
    expect(evaluator.version).toBe('1.0.0');
  });

  it('PASS for non-IAMMAI sessions', () => {
    const result = evaluator.evaluate(makeContext(false, []));
    expect(result.result).toBe('PASS');
    expect(result.details).toContain('Non-IAMMAI');
  });

  it('FAIL when no IAMMAI context loaded', () => {
    const ctx = makeContext(true, []);
    ctx.iammaiContext = undefined;
    const result = evaluator.evaluate(ctx);
    expect(result.result).toBe('FAIL');
  });

  it('FAIL when no state records', () => {
    const result = evaluator.evaluate(makeContext(true, []));
    expect(result.result).toBe('FAIL');
  });

  it('PASS with all 9 phases in canonical order', () => {
    const records = [
      { state_type: 'signal' as const, state_family: 'preparation' as const },
      { state_type: 'acceptance' as const, state_family: 'preparation' as const },
      { state_type: 'scope' as const, state_family: 'preparation' as const },
      { state_type: 'presence' as const, state_family: 'preparation' as const },
      { state_type: 'threshold' as const, state_family: 'preparation' as const },
      { state_type: 'truth' as const, state_family: 'standing' as const },
      { state_type: 'continuity' as const, state_family: 'standing' as const },
      { state_type: 'decision' as const, state_family: 'standing' as const },
      { state_type: 'consequence' as const, state_family: 'standing' as const },
    ];
    const result = evaluator.evaluate(makeContext(true, records));
    expect(result.result).toBe('PASS');
    expect(result.details).toContain('9 phases verified');
  });

  it('PASS with partial phases in correct order', () => {
    const records = [
      { state_type: 'signal' as const, state_family: 'preparation' as const },
      { state_type: 'acceptance' as const, state_family: 'preparation' as const },
      { state_type: 'scope' as const, state_family: 'preparation' as const },
    ];
    const result = evaluator.evaluate(makeContext(true, records));
    expect(result.result).toBe('PASS');
  });

  it('FAIL when phases are out of order', () => {
    const records = [
      { state_type: 'acceptance' as const, state_family: 'preparation' as const },
      { state_type: 'signal' as const, state_family: 'preparation' as const },
    ];
    const result = evaluator.evaluate(makeContext(true, records));
    expect(result.result).toBe('FAIL');
    expect(result.details).toContain('Phase order violation');
  });

  it('FAIL when a phase is skipped', () => {
    const records = [
      { state_type: 'signal' as const, state_family: 'preparation' as const },
      { state_type: 'scope' as const, state_family: 'preparation' as const }, // skipped acceptance
    ];
    const result = evaluator.evaluate(makeContext(true, records));
    expect(result.result).toBe('FAIL');
    expect(result.details).toContain('Phase skipped');
  });

  it('FAIL when phases are duplicated', () => {
    const records = [
      { state_type: 'signal' as const, state_family: 'preparation' as const },
      { state_type: 'signal' as const, state_family: 'preparation' as const },
    ];
    const result = evaluator.evaluate(makeContext(true, records));
    expect(result.result).toBe('FAIL');
    expect(result.details).toContain('Duplicate');
  });

  it('FAIL when state_family mismatches phase', () => {
    const records = [
      { state_type: 'signal' as const, state_family: 'standing' as const }, // wrong family
    ];
    const result = evaluator.evaluate(makeContext(true, records));
    expect(result.result).toBe('FAIL');
    expect(result.details).toContain('State family mismatch');
  });

  it('FAIL when first phase is not signal', () => {
    const records = [
      { state_type: 'acceptance' as const, state_family: 'preparation' as const },
      { state_type: 'scope' as const, state_family: 'preparation' as const },
    ];
    const result = evaluator.evaluate(makeContext(true, records));
    expect(result.result).toBe('FAIL');
  });
});
