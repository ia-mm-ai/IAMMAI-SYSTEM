/**
 * I.12 Containment Orthogonality — Unit Tests
 */

import { describe, it, expect } from 'vitest';
import { I12ContainmentOrthogonality } from '../../../../../src/integrity/iammai/protocols/i12-containment-orthogonality.js';
import type { EvaluationContext } from '../../../../../src/integrity/types.js';
import type {
  IammaiStateRecord,
  IammaiTransitionRecord,
  IammaiGovernanceAction,
  IammaiContainmentRecord,
  IammaiEvaluationContext,
} from '../../../../../src/integrity/iammai/types.js';

const evaluator = new I12ContainmentOrthogonality();

function makeContext(
  iammaiTracked: boolean,
  overrides: Partial<IammaiEvaluationContext> = {}
): EvaluationContext {
  const iammaiContext: IammaiEvaluationContext = {
    stateRecords: [],
    transitionRecords: [],
    governanceActions: [],
    witnessArtifacts: [],
    validationArtifacts: [],
    contributionRecords: [],
    containmentRecords: [],
    ...overrides,
  };

  return {
    session: { iammaiTracked } as any,
    ledgerEntries: [],
    presenceRecords: [],
    adminActions: [],
    coAgencyActions: [],
    iammaiContext: iammaiTracked ? iammaiContext : undefined,
  };
}

const baseState: IammaiStateRecord = {
  state_id: 'state-1',
  matter_ref: 'bnk:session:abc',
  state_family: 'standing',
  state_type: 'truth',
  recorded_at: new Date('2026-01-01'),
  predecessor_ref: null,
  containment_ref: null,
  related_transition_ref: null,
  related_governance_ref: null,
  related_validation_ref: null,
  related_witness_ref: null,
};

const baseGovAction: IammaiGovernanceAction = {
  governance_action_id: 'gov-1',
  action_type: 'hold',
  authority_class: 'OPERATOR',
  actor_ref: 'admin-1',
  legitimacy_basis_ref: 'basis-1',
  matter_ref: 'bnk:session:abc',
  acted_at: new Date('2026-01-01'),
  delegated_from_ref: null,
  target_state_ref: 'state-1',
  target_transition_ref: null,
  contribution_role_map_ref: null,
};

describe('I12ContainmentOrthogonality', () => {
  it('has correct id and version', () => {
    expect(evaluator.id).toBe('I.12');
    expect(evaluator.version).toBe('1.0.0');
  });

  it('PASS for non-IAMMAI sessions', () => {
    const result = evaluator.evaluate(makeContext(false));
    expect(result.result).toBe('PASS');
    expect(result.details).toContain('Non-IAMMAI');
  });

  it('FAIL when no IAMMAI context loaded', () => {
    const ctx = makeContext(true);
    ctx.iammaiContext = undefined;
    const result = evaluator.evaluate(ctx);
    expect(result.result).toBe('FAIL');
  });

  it('PASS when no containment records', () => {
    const result = evaluator.evaluate(makeContext(true, {
      stateRecords: [baseState],
    }));
    expect(result.result).toBe('PASS');
    expect(result.details).toContain('No containment records');
  });

  it('PASS with valid HOLD + RELEASE cycle', () => {
    const releaseGov: IammaiGovernanceAction = {
      ...baseGovAction,
      governance_action_id: 'gov-2',
      action_type: 'release',
      acted_at: new Date('2026-01-02'),
    };

    const result = evaluator.evaluate(makeContext(true, {
      stateRecords: [baseState],
      governanceActions: [baseGovAction, releaseGov],
      containmentRecords: [
        {
          containment_id: 'c1', matter_ref: 'bnk:session:abc', target_state_ref: 'state-1',
          action: 'HOLD', actor_ref: 'admin-1', reason: 'review',
          recorded_at: new Date('2026-01-01'), governance_action_ref: 'gov-1',
        },
        {
          containment_id: 'c2', matter_ref: 'bnk:session:abc', target_state_ref: 'state-1',
          action: 'RELEASE', actor_ref: 'admin-1', reason: 'done',
          recorded_at: new Date('2026-01-02'), governance_action_ref: 'gov-2',
        },
      ],
    }));
    expect(result.result).toBe('PASS');
  });

  it('FAIL when containment has no governance_action_ref', () => {
    const result = evaluator.evaluate(makeContext(true, {
      stateRecords: [baseState],
      containmentRecords: [
        {
          containment_id: 'c1', matter_ref: 'bnk:session:abc', target_state_ref: 'state-1',
          action: 'HOLD', actor_ref: 'admin-1', reason: 'review',
          recorded_at: new Date('2026-01-01'), governance_action_ref: null,
        },
      ],
    }));
    expect(result.result).toBe('FAIL');
    expect(result.details).toContain('no governance_action_ref');
  });

  it('FAIL when governance action does not exist', () => {
    const result = evaluator.evaluate(makeContext(true, {
      stateRecords: [baseState],
      governanceActions: [], // empty — referenced gov action doesn't exist
      containmentRecords: [
        {
          containment_id: 'c1', matter_ref: 'bnk:session:abc', target_state_ref: 'state-1',
          action: 'HOLD', actor_ref: 'admin-1', reason: 'review',
          recorded_at: new Date('2026-01-01'), governance_action_ref: 'gov-nonexistent',
        },
      ],
    }));
    expect(result.result).toBe('FAIL');
    expect(result.details).toContain('does not exist');
  });

  it('FAIL when double HOLD without RELEASE (stacking)', () => {
    const govAction2: IammaiGovernanceAction = {
      ...baseGovAction,
      governance_action_id: 'gov-2',
      acted_at: new Date('2026-01-02'),
    };

    const result = evaluator.evaluate(makeContext(true, {
      stateRecords: [baseState],
      governanceActions: [baseGovAction, govAction2],
      containmentRecords: [
        {
          containment_id: 'c1', matter_ref: 'bnk:session:abc', target_state_ref: 'state-1',
          action: 'HOLD', actor_ref: 'admin-1', reason: 'first hold',
          recorded_at: new Date('2026-01-01'), governance_action_ref: 'gov-1',
        },
        {
          containment_id: 'c2', matter_ref: 'bnk:session:abc', target_state_ref: 'state-1',
          action: 'HOLD', actor_ref: 'admin-1', reason: 'second hold',
          recorded_at: new Date('2026-01-02'), governance_action_ref: 'gov-2',
        },
      ],
    }));
    expect(result.result).toBe('FAIL');
    expect(result.details).toContain('sequence violation');
  });

  it('FAIL when target state not found in state records', () => {
    const result = evaluator.evaluate(makeContext(true, {
      stateRecords: [], // no states
      governanceActions: [baseGovAction],
      containmentRecords: [
        {
          containment_id: 'c1', matter_ref: 'bnk:session:abc', target_state_ref: 'state-1',
          action: 'HOLD', actor_ref: 'admin-1', reason: 'review',
          recorded_at: new Date('2026-01-01'), governance_action_ref: 'gov-1',
        },
      ],
    }));
    expect(result.result).toBe('FAIL');
    expect(result.details).toContain('not found in state records');
  });

  it('FAIL when held state was resolved during containment', () => {
    const result = evaluator.evaluate(makeContext(true, {
      stateRecords: [baseState],
      governanceActions: [baseGovAction],
      containmentRecords: [
        {
          containment_id: 'c1', matter_ref: 'bnk:session:abc', target_state_ref: 'state-1',
          action: 'HOLD', actor_ref: 'admin-1', reason: 'review',
          recorded_at: new Date('2026-01-01'), governance_action_ref: 'gov-1',
        },
      ],
      transitionRecords: [
        {
          transition_id: 't1', matter_ref: 'bnk:session:abc', source_ref: 'state-1',
          target_ref: 'state-1', transition_type: 'resolution_transition',
          occurred_at: new Date('2026-01-01T12:00:00Z'), // during hold period
          resolution_type: 'FINALIZE', predecessor_ref: null,
        },
      ],
    }));
    expect(result.result).toBe('FAIL');
    expect(result.details).toContain('resolved during containment');
  });

  it('FAIL when held state transitioned during containment', () => {
    const result = evaluator.evaluate(makeContext(true, {
      stateRecords: [baseState],
      governanceActions: [baseGovAction],
      containmentRecords: [
        {
          containment_id: 'c1', matter_ref: 'bnk:session:abc', target_state_ref: 'state-1',
          action: 'HOLD', actor_ref: 'admin-1', reason: 'review',
          recorded_at: new Date('2026-01-01'), governance_action_ref: 'gov-1',
        },
      ],
      transitionRecords: [
        {
          transition_id: 't1', matter_ref: 'bnk:session:abc', source_ref: 'state-1',
          target_ref: 'state-2', transition_type: 'continuity_transition',
          occurred_at: new Date('2026-01-01T12:00:00Z'), // during hold period
          resolution_type: null, predecessor_ref: null,
        },
      ],
    }));
    expect(result.result).toBe('FAIL');
    expect(result.details).toContain('transitioned during containment');
  });

  it('PASS when transition occurs after RELEASE', () => {
    const releaseGov: IammaiGovernanceAction = {
      ...baseGovAction,
      governance_action_id: 'gov-2',
      action_type: 'release',
      acted_at: new Date('2026-01-02'),
    };

    const result = evaluator.evaluate(makeContext(true, {
      stateRecords: [baseState],
      governanceActions: [baseGovAction, releaseGov],
      containmentRecords: [
        {
          containment_id: 'c1', matter_ref: 'bnk:session:abc', target_state_ref: 'state-1',
          action: 'HOLD', actor_ref: 'admin-1', reason: 'review',
          recorded_at: new Date('2026-01-01'), governance_action_ref: 'gov-1',
        },
        {
          containment_id: 'c2', matter_ref: 'bnk:session:abc', target_state_ref: 'state-1',
          action: 'RELEASE', actor_ref: 'admin-1', reason: 'done',
          recorded_at: new Date('2026-01-02'), governance_action_ref: 'gov-2',
        },
      ],
      transitionRecords: [
        {
          transition_id: 't1', matter_ref: 'bnk:session:abc', source_ref: 'state-1',
          target_ref: 'state-2', transition_type: 'continuity_transition',
          occurred_at: new Date('2026-01-03'), // after release
          resolution_type: null, predecessor_ref: null,
        },
      ],
    }));
    expect(result.result).toBe('PASS');
  });
});
