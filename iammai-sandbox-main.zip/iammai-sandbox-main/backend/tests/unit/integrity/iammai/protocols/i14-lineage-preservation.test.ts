/**
 * I.14 Lineage Preservation — Unit Tests
 */

import { describe, it, expect } from 'vitest';
import { I14LineagePreservation } from '../../../../../src/integrity/iammai/protocols/i14-lineage-preservation.js';
import type { EvaluationContext } from '../../../../../src/integrity/types.js';
import type { IammaiStateRecord, IammaiEvaluationContext } from '../../../../../src/integrity/iammai/types.js';

const evaluator = new I14LineagePreservation();

function makeContext(
  iammaiTracked: boolean,
  stateRecords: Partial<IammaiStateRecord>[]
): EvaluationContext {
  const iammaiContext: IammaiEvaluationContext = {
    stateRecords: stateRecords.map((r, i) => ({
      state_id: r.state_id ?? `state-${i}`,
      matter_ref: r.matter_ref ?? 'bnk:session:abc',
      state_family: r.state_family ?? 'preparation',
      state_type: r.state_type ?? 'signal',
      recorded_at: new Date(),
      predecessor_ref: r.predecessor_ref !== undefined ? r.predecessor_ref : (i > 0 ? `state-${i - 1}` : null),
      containment_ref: null,
      related_transition_ref: null,
      related_governance_ref: null,
      related_validation_ref: null,
      related_witness_ref: null,
      ...r,
    })) as IammaiStateRecord[],
    transitionRecords: [],
    governanceActions: [],
    witnessArtifacts: [],
    validationArtifacts: [],
    contributionRecords: [],
    containmentRecords: [],
  };

  return {
    session: { iammaiTracked } as any,
    ledgerEntries: [],
    presenceRecords: [],
    adminActions: [],
    coAgencyActions: [],
    iammaiContext: iammaiTracked ? iammaiContext : undefined,
  };
}

describe('I14LineagePreservation', () => {
  it('has correct id and version', () => {
    expect(evaluator.id).toBe('I.14');
    expect(evaluator.version).toBe('1.0.0');
  });

  it('PASS for non-IAMMAI sessions', () => {
    const result = evaluator.evaluate(makeContext(false, []));
    expect(result.result).toBe('PASS');
    expect(result.details).toContain('Non-IAMMAI');
  });

  it('FAIL when IAMMAI context not loaded', () => {
    const ctx = makeContext(true, []);
    ctx.iammaiContext = undefined;
    const result = evaluator.evaluate(ctx);
    expect(result.result).toBe('FAIL');
  });

  it('FAIL when no state records', () => {
    const result = evaluator.evaluate(makeContext(true, []));
    expect(result.result).toBe('FAIL');
  });

  it('PASS with single state record (signal, no predecessor)', () => {
    const result = evaluator.evaluate(makeContext(true, [
      { state_id: 's0', state_type: 'signal', predecessor_ref: null },
    ]));
    expect(result.result).toBe('PASS');
    expect(result.details).toContain('1 state records');
  });

  it('PASS with contiguous predecessor chain', () => {
    const result = evaluator.evaluate(makeContext(true, [
      { state_id: 's0', state_type: 'signal', state_family: 'preparation', predecessor_ref: null },
      { state_id: 's1', state_type: 'acceptance', state_family: 'preparation', predecessor_ref: 's0' },
      { state_id: 's2', state_type: 'scope', state_family: 'preparation', predecessor_ref: 's1' },
    ]));
    expect(result.result).toBe('PASS');
    expect(result.details).toContain('3 state records');
  });

  it('PASS for EVOLVE d matter (first state has external predecessor)', () => {
    const result = evaluator.evaluate(makeContext(true, [
      { state_id: 's0', state_type: 'signal', predecessor_ref: 'external-predecessor-id' },
      { state_id: 's1', state_type: 'acceptance', predecessor_ref: 's0' },
    ]));
    expect(result.result).toBe('PASS');
  });

  it('FAIL when subsequent record has null predecessor_ref', () => {
    const result = evaluator.evaluate(makeContext(true, [
      { state_id: 's0', state_type: 'signal', predecessor_ref: null },
      { state_id: 's1', state_type: 'acceptance', predecessor_ref: null },
    ]));
    expect(result.result).toBe('FAIL');
    expect(result.details).toContain('no predecessor_ref');
  });

  it('FAIL when predecessor_ref points to nonexistent state', () => {
    const result = evaluator.evaluate(makeContext(true, [
      { state_id: 's0', state_type: 'signal', predecessor_ref: null },
      { state_id: 's1', state_type: 'acceptance', predecessor_ref: 'nonexistent' },
    ]));
    expect(result.result).toBe('FAIL');
    expect(result.details).toContain('does not exist');
  });

  it('FAIL when predecessor chain is not contiguous', () => {
    const result = evaluator.evaluate(makeContext(true, [
      { state_id: 's0', state_type: 'signal', predecessor_ref: null },
      { state_id: 's1', state_type: 'acceptance', predecessor_ref: 's0' },
      { state_id: 's2', state_type: 'scope', predecessor_ref: 's0' },  // should be s1
    ]));
    expect(result.result).toBe('FAIL');
    expect(result.details).toContain('Lineage gap');
  });

  it('FAIL when first state has predecessor pointing to own matter (cycle)', () => {
    const result = evaluator.evaluate(makeContext(true, [
      { state_id: 's0', state_type: 'signal', predecessor_ref: 's1' },
      { state_id: 's1', state_type: 'acceptance', predecessor_ref: 's0' },
    ]));
    expect(result.result).toBe('FAIL');
    expect(result.details).toContain('cycle');
  });

  it('FAIL with forked lineage (duplicate predecessor refs)', () => {
    // Two records claim the same predecessor
    const result = evaluator.evaluate(makeContext(true, [
      { state_id: 's0', state_type: 'signal', predecessor_ref: null },
      { state_id: 's1', state_type: 'acceptance', predecessor_ref: 's0' },
      { state_id: 's2', state_type: 'scope', predecessor_ref: 's1' },
      { state_id: 's3', state_type: 'presence', predecessor_ref: 's1' },  // fork! same as s2
    ]));
    expect(result.result).toBe('FAIL');
    // Will fail on contiguity check (s3 predecessor should be s2)
  });
});
