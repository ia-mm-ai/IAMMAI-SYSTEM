/**
 * I.13 Resolution Legality — Unit Tests
 */

import { describe, it, expect } from 'vitest';
import { I13ResolutionLegality } from '../../../../../src/integrity/iammai/protocols/i13-resolution-legality.js';
import type { EvaluationContext } from '../../../../../src/integrity/types.js';
import type {
  IammaiStateRecord,
  IammaiTransitionRecord,
  IammaiGovernanceAction,
  IammaiEvaluationContext,
} from '../../../../../src/integrity/iammai/types.js';

const evaluator = new I13ResolutionLegality();

function makeContext(opts: {
  iammaiTracked: boolean;
  stateRecords?: Partial<IammaiStateRecord>[];
  transitionRecords?: Partial<IammaiTransitionRecord>[];
  governanceActions?: Partial<IammaiGovernanceAction>[];
}): EvaluationContext {
  const iammaiContext: IammaiEvaluationContext = {
    stateRecords: (opts.stateRecords ?? []).map((r, i) => ({
      state_id: r.state_id ?? `state-${i}`,
      matter_ref: r.matter_ref ?? 'bnk:session:abc',
      state_family: r.state_family ?? 'standing',
      state_type: r.state_type ?? 'decision',
      recorded_at: new Date(),
      predecessor_ref: null,
      containment_ref: null,
      related_transition_ref: null,
      related_governance_ref: null,
      related_validation_ref: null,
      related_witness_ref: null,
      ...r,
    })) as IammaiStateRecord[],
    transitionRecords: (opts.transitionRecords ?? []).map((t, i) => ({
      transition_id: t.transition_id ?? `trans-${i}`,
      matter_ref: t.matter_ref ?? 'bnk:session:abc',
      source_ref: t.source_ref ?? 'state-0',
      target_ref: t.target_ref ?? 'state-0',
      transition_type: t.transition_type ?? 'resolution_transition',
      occurred_at: new Date(),
      resolution_type: t.resolution_type ?? null,
      predecessor_ref: null,
      ...t,
    })) as IammaiTransitionRecord[],
    governanceActions: (opts.governanceActions ?? []).map((g, i) => ({
      governance_action_id: g.governance_action_id ?? `gov-${i}`,
      action_type: g.action_type ?? 'finalize',
      authority_class: g.authority_class ?? 'OPERATOR',
      actor_ref: g.actor_ref ?? 'bnk:admin:a1',
      legitimacy_basis_ref: g.legitimacy_basis_ref ?? 'basis',
      matter_ref: g.matter_ref ?? 'bnk:session:abc',
      acted_at: new Date(),
      delegated_from_ref: null,
      target_state_ref: null,
      target_transition_ref: null,
      contribution_role_map_ref: null,
      ...g,
    })) as IammaiGovernanceAction[],
    witnessArtifacts: [],
    validationArtifacts: [],
    contributionRecords: [],
    containmentRecords: [],
  };

  return {
    session: { iammaiTracked: opts.iammaiTracked } as any,
    ledgerEntries: [],
    presenceRecords: [],
    adminActions: [],
    coAgencyActions: [],
    iammaiContext: opts.iammaiTracked ? iammaiContext : undefined,
  };
}

describe('I13ResolutionLegality', () => {
  it('has correct id and version', () => {
    expect(evaluator.id).toBe('I.13');
    expect(evaluator.version).toBe('1.0.0');
  });

  it('PASS for non-IAMMAI sessions', () => {
    const result = evaluator.evaluate(makeContext({ iammaiTracked: false }));
    expect(result.result).toBe('PASS');
    expect(result.details).toContain('Non-IAMMAI');
  });

  it('FAIL when IAMMAI context not loaded', () => {
    const ctx = makeContext({ iammaiTracked: true });
    ctx.iammaiContext = undefined;
    const result = evaluator.evaluate(ctx);
    expect(result.result).toBe('FAIL');
  });

  it('PASS when no resolution transitions exist', () => {
    const result = evaluator.evaluate(makeContext({
      iammaiTracked: true,
      stateRecords: [{ state_type: 'continuity', state_family: 'standing' }],
      transitionRecords: [],
    }));
    expect(result.result).toBe('PASS');
    expect(result.details).toContain('No resolution transitions');
  });

  it('PASS for valid FINALIZE resolution', () => {
    const result = evaluator.evaluate(makeContext({
      iammaiTracked: true,
      stateRecords: [{ state_id: 's1', state_type: 'decision', state_family: 'standing' }],
      transitionRecords: [{
        transition_type: 'resolution_transition',
        resolution_type: 'FINALIZE',
        source_ref: 's1',
        target_ref: 's1',
      }],
      governanceActions: [{ action_type: 'finalize' }],
    }));
    expect(result.result).toBe('PASS');
  });

  it('PASS for valid INVALIDATE resolution', () => {
    const result = evaluator.evaluate(makeContext({
      iammaiTracked: true,
      stateRecords: [{ state_id: 's1', state_type: 'truth', state_family: 'standing' }],
      transitionRecords: [{
        transition_type: 'resolution_transition',
        resolution_type: 'INVALIDATE',
        source_ref: 's1',
        target_ref: 's1',
      }],
      governanceActions: [{ action_type: 'invalidate' }],
    }));
    expect(result.result).toBe('PASS');
  });

  it('PASS for valid EVOLVE resolution', () => {
    const result = evaluator.evaluate(makeContext({
      iammaiTracked: true,
      stateRecords: [{ state_id: 's1', state_type: 'continuity', state_family: 'standing' }],
      transitionRecords: [{
        transition_type: 'resolution_transition',
        resolution_type: 'EVOLVE',
        source_ref: 's1',
        target_ref: 'successor-s1',  // different from source
      }],
      governanceActions: [{ action_type: 'evolve' }],
    }));
    expect(result.result).toBe('PASS');
  });

  it('FAIL when resolution_type is missing', () => {
    const result = evaluator.evaluate(makeContext({
      iammaiTracked: true,
      stateRecords: [{ state_id: 's1', state_type: 'decision', state_family: 'standing' }],
      transitionRecords: [{
        transition_type: 'resolution_transition',
        resolution_type: null,
        source_ref: 's1',
      }],
    }));
    expect(result.result).toBe('FAIL');
    expect(result.details).toContain('no resolution_type');
  });

  it('FAIL for invalid resolution type', () => {
    const result = evaluator.evaluate(makeContext({
      iammaiTracked: true,
      stateRecords: [{ state_id: 's1', state_type: 'decision', state_family: 'standing' }],
      transitionRecords: [{
        transition_type: 'resolution_transition',
        resolution_type: 'CANCEL' as any,
        source_ref: 's1',
      }],
    }));
    expect(result.result).toBe('FAIL');
    expect(result.details).toContain('Invalid resolution type');
  });

  it('FAIL when EVOLVE source_ref equals target_ref', () => {
    const result = evaluator.evaluate(makeContext({
      iammaiTracked: true,
      stateRecords: [{ state_id: 's1', state_type: 'decision', state_family: 'standing' }],
      transitionRecords: [{
        transition_type: 'resolution_transition',
        resolution_type: 'EVOLVE',
        source_ref: 's1',
        target_ref: 's1',
      }],
      governanceActions: [{ action_type: 'evolve' }],
    }));
    expect(result.result).toBe('FAIL');
    expect(result.details).toContain('successor');
  });

  it('FAIL when resolution from preparation phase', () => {
    const result = evaluator.evaluate(makeContext({
      iammaiTracked: true,
      stateRecords: [{ state_id: 's1', state_type: 'threshold', state_family: 'preparation' }],
      transitionRecords: [{
        transition_type: 'resolution_transition',
        resolution_type: 'FINALIZE',
        source_ref: 's1',
      }],
      governanceActions: [{ action_type: 'finalize' }],
    }));
    expect(result.result).toBe('FAIL');
    expect(result.details).toContain('preparation phase');
  });

  it('FAIL when source state not found', () => {
    const result = evaluator.evaluate(makeContext({
      iammaiTracked: true,
      stateRecords: [{ state_id: 's1', state_type: 'decision', state_family: 'standing' }],
      transitionRecords: [{
        transition_type: 'resolution_transition',
        resolution_type: 'FINALIZE',
        source_ref: 'nonexistent',
      }],
    }));
    expect(result.result).toBe('FAIL');
    expect(result.details).toContain('not found');
  });

  it('FAIL when no matching governance action', () => {
    const result = evaluator.evaluate(makeContext({
      iammaiTracked: true,
      stateRecords: [{ state_id: 's1', state_type: 'decision', state_family: 'standing' }],
      transitionRecords: [{
        transition_type: 'resolution_transition',
        resolution_type: 'FINALIZE',
        source_ref: 's1',
      }],
      governanceActions: [],  // no governance action
    }));
    expect(result.result).toBe('FAIL');
    expect(result.details).toContain('No governance action');
  });
});
