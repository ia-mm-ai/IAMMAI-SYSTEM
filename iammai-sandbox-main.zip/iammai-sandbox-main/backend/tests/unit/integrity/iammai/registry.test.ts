/**
 * IAMMAI Registry — Unit Tests
 *
 * Tests insert functions with mocked DB, and verifies query construction.
 */

import { describe, it, expect, vi, beforeEach } from 'vitest';
import type pg from 'pg';
import {
  createStateRecord,
  createTransitionRecord,
  createGovernanceAction,
  createWitnessArtifact,
  createValidationArtifact,
  createContributionRecord,
  createContainmentRecord,
} from '../../../../src/integrity/iammai/record-factory.js';

// Mock the db module
vi.mock('../../../../src/lib/db.js', () => ({
  query: vi.fn().mockResolvedValue({ rows: [] }),
  transaction: vi.fn(),
}));

import {
  insertStateRecord,
  insertTransitionRecord,
  insertGovernanceAction,
  insertWitnessArtifact,
  insertValidationArtifact,
  insertContributionRecord,
  insertContainmentRecord,
  getStateRecordsByMatter,
  getTransitionRecordsByMatter,
  getGovernanceActionsByMatter,
  getContributionRecordsByMatter,
  getContainmentRecordsByMatter,
  loadIammaiContext,
} from '../../../../src/integrity/iammai/registry.js';
import { query } from '../../../../src/lib/db.js';

// ============================================================================
// Setup
// ============================================================================

function mockClient(): pg.PoolClient {
  return {
    query: vi.fn().mockResolvedValue({ rows: [] }),
  } as unknown as pg.PoolClient;
}

beforeEach(() => {
  vi.clearAllMocks();
});

// ============================================================================
// Insert Functions
// ============================================================================

describe('insertStateRecord', () => {
  it('inserts a state record via client.query', async () => {
    const client = mockClient();
    const record = createStateRecord({ matter_ref: 'bnk:session:abc', state_type: 'signal' });
    const result = await insertStateRecord(client, record);
    expect(result).toBe(record);
    expect(client.query).toHaveBeenCalledOnce();
    const call = (client.query as ReturnType<typeof vi.fn>).mock.calls[0];
    expect(call[0]).toContain('INSERT INTO iammai_state_records');
    expect(call[1]).toContain(record.state_id);
  });
});

describe('insertTransitionRecord', () => {
  it('inserts a transition record via client.query', async () => {
    const client = mockClient();
    const record = createTransitionRecord({
      matter_ref: 'ref', source_ref: 's1', target_ref: 's2',
      transition_type: 'preparation_progression',
    });
    const result = await insertTransitionRecord(client, record);
    expect(result).toBe(record);
    expect(client.query).toHaveBeenCalledOnce();
  });
});

describe('insertGovernanceAction', () => {
  it('inserts a governance action via client.query', async () => {
    const client = mockClient();
    const record = createGovernanceAction({
      action_type: 'authorize', authority_class: 'OPERATOR',
      actor_ref: 'actor', legitimacy_basis_ref: 'basis', matter_ref: 'matter',
    });
    const result = await insertGovernanceAction(client, record);
    expect(result).toBe(record);
    expect(client.query).toHaveBeenCalledOnce();
  });
});

describe('insertWitnessArtifact', () => {
  it('inserts a witness artifact with JSON-serialized claims and non_claims', async () => {
    const client = mockClient();
    const record = createWitnessArtifact({
      witness_type: 'transition', target_ref: 'ref', claims: ['observed'],
    });
    await insertWitnessArtifact(client, record);
    const call = (client.query as ReturnType<typeof vi.fn>).mock.calls[0];
    // claims and non_claims should be JSON-stringified
    expect(call[1]).toContain(JSON.stringify(['observed']));
  });
});

describe('insertValidationArtifact', () => {
  it('inserts a validation artifact via client.query', async () => {
    const client = mockClient();
    const record = createValidationArtifact({
      validation_type: 'transition_legality', target_ref: 'ref',
      condition_set_ref: 'cond', outcome: 'pass',
    });
    const result = await insertValidationArtifact(client, record);
    expect(result).toBe(record);
  });
});

describe('insertContributionRecord', () => {
  it('inserts with ON CONFLICT DO NOTHING for idempotency', async () => {
    const client = mockClient();
    const record = createContributionRecord({
      matter_ref: 'ref', actor_ref: 'actor', role: 'ORIGIN',
    });
    await insertContributionRecord(client, record);
    const call = (client.query as ReturnType<typeof vi.fn>).mock.calls[0];
    expect(call[0]).toContain('ON CONFLICT');
    expect(call[0]).toContain('DO NOTHING');
  });
});

describe('insertContainmentRecord', () => {
  it('inserts a containment record via client.query', async () => {
    const client = mockClient();
    const record = createContainmentRecord({
      matter_ref: 'ref', target_state_ref: 'state-5',
      action: 'HOLD', actor_ref: 'actor', reason: 'Pending',
    });
    const result = await insertContainmentRecord(client, record);
    expect(result).toBe(record);
  });
});

// ============================================================================
// Query Functions
// ============================================================================

describe('getStateRecordsByMatter', () => {
  it('queries by matter_ref ordered by recorded_at', async () => {
    await getStateRecordsByMatter('bnk:session:abc');
    expect(query).toHaveBeenCalledWith(
      expect.stringContaining('WHERE matter_ref = $1'),
      ['bnk:session:abc']
    );
  });
});

describe('getTransitionRecordsByMatter', () => {
  it('queries by matter_ref ordered by occurred_at', async () => {
    await getTransitionRecordsByMatter('bnk:session:abc');
    expect(query).toHaveBeenCalledWith(
      expect.stringContaining('iammai_transition_records'),
      ['bnk:session:abc']
    );
  });
});

describe('getGovernanceActionsByMatter', () => {
  it('queries by matter_ref', async () => {
    await getGovernanceActionsByMatter('bnk:session:abc');
    expect(query).toHaveBeenCalledWith(
      expect.stringContaining('iammai_governance_actions'),
      ['bnk:session:abc']
    );
  });
});

describe('getContributionRecordsByMatter', () => {
  it('queries by matter_ref', async () => {
    await getContributionRecordsByMatter('bnk:session:abc');
    expect(query).toHaveBeenCalledWith(
      expect.stringContaining('iammai_contribution_records'),
      ['bnk:session:abc']
    );
  });
});

describe('getContainmentRecordsByMatter', () => {
  it('queries by matter_ref', async () => {
    await getContainmentRecordsByMatter('bnk:session:abc');
    expect(query).toHaveBeenCalledWith(
      expect.stringContaining('iammai_containment_records'),
      ['bnk:session:abc']
    );
  });
});

// ============================================================================
// Load Full Context
// ============================================================================

describe('loadIammaiContext', () => {
  it('returns all 7 record arrays', async () => {
    const ctx = await loadIammaiContext('bnk:session:abc');
    expect(ctx).toHaveProperty('stateRecords');
    expect(ctx).toHaveProperty('transitionRecords');
    expect(ctx).toHaveProperty('governanceActions');
    expect(ctx).toHaveProperty('witnessArtifacts');
    expect(ctx).toHaveProperty('validationArtifacts');
    expect(ctx).toHaveProperty('contributionRecords');
    expect(ctx).toHaveProperty('containmentRecords');
    expect(Array.isArray(ctx.stateRecords)).toBe(true);
  });
});
