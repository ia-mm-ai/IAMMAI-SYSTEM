/**
 * Resolution Engine — Unit Tests
 */

import { describe, it, expect, vi, beforeEach } from 'vitest';

// Mock registry before imports
vi.mock('../../../../src/integrity/iammai/registry.js', () => ({
  getStateRecordsByMatter: vi.fn(),
  getTransitionRecordsByMatter: vi.fn(),
  insertStateRecord: vi.fn(),
  insertTransitionRecord: vi.fn(),
}));

// Mock governor
vi.mock('../../../../src/integrity/iammai/governor.js', () => ({
  recordGovernanceAction: vi.fn(),
}));

// Mock db
vi.mock('../../../../src/lib/db.js', () => ({
  query: vi.fn(),
}));

import {
  isResolutionEligible,
  isResolved,
  resolve,
} from '../../../../src/integrity/iammai/resolution-engine.js';
import {
  getStateRecordsByMatter,
  getTransitionRecordsByMatter,
  insertStateRecord,
  insertTransitionRecord,
} from '../../../../src/integrity/iammai/registry.js';
import { recordGovernanceAction } from '../../../../src/integrity/iammai/governor.js';

const mockGetStates = vi.mocked(getStateRecordsByMatter);
const mockGetTransitions = vi.mocked(getTransitionRecordsByMatter);
const mockInsertState = vi.mocked(insertStateRecord);
const mockInsertTransition = vi.mocked(insertTransitionRecord);
const mockRecordGov = vi.mocked(recordGovernanceAction);

function makeClient() {
  return {
    query: vi.fn(),
  } as any;
}

beforeEach(() => {
  vi.clearAllMocks();
});

describe('isResolutionEligible', () => {
  it('returns false for no state records', async () => {
    mockGetStates.mockResolvedValue([]);
    expect(await isResolutionEligible('bnk:session:123')).toBe(false);
  });

  it('returns false for preparation-regime phase', async () => {
    mockGetStates.mockResolvedValue([
      { state_id: 's1', matter_ref: 'bnk:session:123', state_family: 'preparation', state_type: 'threshold' } as any,
    ]);
    expect(await isResolutionEligible('bnk:session:123')).toBe(false);
  });

  it('returns true for standing-state phase', async () => {
    mockGetStates.mockResolvedValue([
      { state_id: 's1', matter_ref: 'bnk:session:123', state_family: 'standing', state_type: 'continuity' } as any,
    ]);
    expect(await isResolutionEligible('bnk:session:123')).toBe(true);
  });
});

describe('isResolved', () => {
  it('returns false when no resolution transitions', async () => {
    mockGetTransitions.mockResolvedValue([]);
    expect(await isResolved('bnk:session:123')).toBe(false);
  });

  it('returns true when resolution transition exists', async () => {
    mockGetTransitions.mockResolvedValue([
      { transition_type: 'resolution_transition' } as any,
    ]);
    expect(await isResolved('bnk:session:123')).toBe(true);
  });
});

describe('resolve', () => {
  it('throws when no state records exist', async () => {
    const client = makeClient();
    client.query.mockResolvedValue({ rows: [] });

    await expect(resolve(client, {
      matter_ref: 'bnk:session:123',
      resolution_type: 'FINALIZE',
      actor_ref: 'bnk:admin:a1',
      legitimacy_basis_ref: 'session-end',
      authority_class: 'OPERATOR',
    })).rejects.toThrow('no state records found');
  });

  it('throws when in preparation regime', async () => {
    const client = makeClient();
    client.query
      .mockResolvedValueOnce({ rows: [{ state_id: 's1', state_type: 'threshold', state_family: 'preparation' }] })
      .mockResolvedValue({ rows: [] });

    await expect(resolve(client, {
      matter_ref: 'bnk:session:123',
      resolution_type: 'FINALIZE',
      actor_ref: 'bnk:admin:a1',
      legitimacy_basis_ref: 'session-end',
      authority_class: 'OPERATOR',
    })).rejects.toThrow('preparation regime');
  });

  it('throws when already resolved', async () => {
    const client = makeClient();
    client.query
      .mockResolvedValueOnce({ rows: [{ state_id: 's1', state_type: 'decision', state_family: 'standing' }] })
      .mockResolvedValueOnce({ rows: [{ transition_type: 'resolution_transition' }] });

    await expect(resolve(client, {
      matter_ref: 'bnk:session:123',
      resolution_type: 'FINALIZE',
      actor_ref: 'bnk:admin:a1',
      legitimacy_basis_ref: 'session-end',
      authority_class: 'OPERATOR',
    })).rejects.toThrow('already resolved');
  });

  it('throws when EVOLVE without successor_matter_ref', async () => {
    const client = makeClient();
    client.query
      .mockResolvedValueOnce({ rows: [{ state_id: 's1', state_type: 'decision', state_family: 'standing' }] })
      .mockResolvedValueOnce({ rows: [] });

    await expect(resolve(client, {
      matter_ref: 'bnk:session:123',
      resolution_type: 'EVOLVE',
      actor_ref: 'bnk:admin:a1',
      legitimacy_basis_ref: 'session-evolve',
      authority_class: 'OPERATOR',
    })).rejects.toThrow('successor_matter_ref');
  });

  it('FINALIZE creates governance action and transition', async () => {
    const client = makeClient();
    client.query
      .mockResolvedValueOnce({ rows: [{ state_id: 's1', state_type: 'decision', state_family: 'standing' }] })
      .mockResolvedValueOnce({ rows: [] });

    const mockGov = { governance_action_id: 'gov-1', action_type: 'finalize' } as any;
    mockRecordGov.mockResolvedValue(mockGov);
    mockInsertTransition.mockResolvedValue({} as any);

    const result = await resolve(client, {
      matter_ref: 'bnk:session:123',
      resolution_type: 'FINALIZE',
      actor_ref: 'bnk:admin:a1',
      legitimacy_basis_ref: 'session-end',
      authority_class: 'OPERATOR',
    });

    expect(result.governanceAction).toBe(mockGov);
    expect(result.transitionRecord.transition_type).toBe('resolution_transition');
    expect(result.transitionRecord.resolution_type).toBe('FINALIZE');
    expect(result.successorStateRecord).toBeUndefined();
    expect(mockRecordGov).toHaveBeenCalledWith(client, expect.objectContaining({
      action_type: 'finalize',
      matter_ref: 'bnk:session:123',
    }));
  });

  it('INVALIDATE creates governance action and transition', async () => {
    const client = makeClient();
    client.query
      .mockResolvedValueOnce({ rows: [{ state_id: 's1', state_type: 'truth', state_family: 'standing' }] })
      .mockResolvedValueOnce({ rows: [] });

    mockRecordGov.mockResolvedValue({ governance_action_id: 'gov-2', action_type: 'invalidate' } as any);
    mockInsertTransition.mockResolvedValue({} as any);

    const result = await resolve(client, {
      matter_ref: 'bnk:session:123',
      resolution_type: 'INVALIDATE',
      actor_ref: 'bnk:admin:a1',
      legitimacy_basis_ref: 'session-void',
      authority_class: 'OPERATOR',
    });

    expect(result.transitionRecord.resolution_type).toBe('INVALIDATE');
    expect(result.successorStateRecord).toBeUndefined();
  });

  it('EVOLVE creates governance action, transition, and successor state', async () => {
    const client = makeClient();
    client.query
      .mockResolvedValueOnce({ rows: [{ state_id: 's1', state_type: 'continuity', state_family: 'standing' }] })
      .mockResolvedValueOnce({ rows: [] });

    mockRecordGov.mockResolvedValue({ governance_action_id: 'gov-3', action_type: 'evolve' } as any);
    mockInsertState.mockResolvedValue({} as any);
    mockInsertTransition.mockResolvedValue({} as any);

    const result = await resolve(client, {
      matter_ref: 'bnk:session:123',
      resolution_type: 'EVOLVE',
      actor_ref: 'bnk:admin:a1',
      legitimacy_basis_ref: 'session-evolve',
      authority_class: 'OPERATOR',
      successor_matter_ref: 'bnk:session:456',
    });

    expect(result.transitionRecord.resolution_type).toBe('EVOLVE');
    expect(result.successorStateRecord).toBeDefined();
    expect(result.successorStateRecord!.matter_ref).toBe('bnk:session:456');
    expect(result.successorStateRecord!.state_type).toBe('signal');
    expect(result.successorStateRecord!.predecessor_ref).toBe('s1');
    expect(mockInsertState).toHaveBeenCalled();
  });
});
