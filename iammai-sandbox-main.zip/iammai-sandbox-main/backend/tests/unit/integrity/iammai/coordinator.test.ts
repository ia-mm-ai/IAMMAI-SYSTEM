/**
 * IAMMAI Coordinator — Unit Tests
 *
 * Tests the coordination sequence: Validate → Govern → State → Witness → Contribute.
 * Uses mock pg client and mocked registry functions.
 */

import { describe, it, expect, vi, beforeEach } from 'vitest';

// Track inserted records across all operations
const insertedRecords: {
  stateRecords: any[];
  transitionRecords: any[];
  governanceActions: any[];
  witnessArtifacts: any[];
  validationArtifacts: any[];
  contributionRecords: any[];
  containmentRecords: any[];
} = {
  stateRecords: [],
  transitionRecords: [],
  governanceActions: [],
  witnessArtifacts: [],
  validationArtifacts: [],
  contributionRecords: [],
  containmentRecords: [],
};

vi.mock('../../../../src/integrity/iammai/registry.js', () => ({
  insertStateRecord: vi.fn(async (_client: any, record: any) => {
    insertedRecords.stateRecords.push(record);
    return record;
  }),
  insertTransitionRecord: vi.fn(async (_client: any, record: any) => {
    insertedRecords.transitionRecords.push(record);
    return record;
  }),
  insertGovernanceAction: vi.fn(async (_client: any, record: any) => {
    insertedRecords.governanceActions.push(record);
    return record;
  }),
  insertWitnessArtifact: vi.fn(async (_client: any, record: any) => {
    insertedRecords.witnessArtifacts.push(record);
    return record;
  }),
  insertValidationArtifact: vi.fn(async (_client: any, record: any) => {
    insertedRecords.validationArtifacts.push(record);
    return record;
  }),
  insertContributionRecord: vi.fn(async (_client: any, record: any) => {
    insertedRecords.contributionRecords.push(record);
    return record;
  }),
  insertContainmentRecord: vi.fn(async (_client: any, record: any) => {
    insertedRecords.containmentRecords.push(record);
    return record;
  }),
  getStateRecordsByMatter: vi.fn(async (matterRef: string) => {
    return insertedRecords.stateRecords.filter(r => r.matter_ref === matterRef);
  }),
  getTransitionRecordsByMatter: vi.fn(async (matterRef: string) => {
    return insertedRecords.transitionRecords.filter(r => r.matter_ref === matterRef);
  }),
  getGovernanceActionsByMatter: vi.fn(async (matterRef: string) => {
    return insertedRecords.governanceActions.filter(r => r.matter_ref === matterRef);
  }),
  getContainmentRecordsByMatter: vi.fn(async () => []),
  getContributionRecordsByMatter: vi.fn(async () => []),
  getWitnessArtifactsByTarget: vi.fn(async () => []),
  getValidationArtifactsByTarget: vi.fn(async () => []),
}));

vi.mock('../../../../src/lib/db.js', () => ({
  query: vi.fn(),
}));

import {
  coordinateSessionCreate,
  coordinateSessionClaim,
  coordinateSessionJoin,
  coordinateSessionStart,
  coordinateMessageExchange,
  coordinateSessionEnd,
} from '../../../../src/integrity/iammai/coordinator.js';

// Mock pg client — phase-engine reads current state from DB
const mockClient = {
  query: vi.fn(async (sql: string, params: any[]) => {
    // phase-engine queries current state
    if (sql.includes('iammai_state_records') && sql.includes('ORDER BY recorded_at DESC LIMIT 1')) {
      const matter = params[0];
      const records = insertedRecords.stateRecords.filter(r => r.matter_ref === matter);
      if (records.length === 0) return { rows: [] };
      const last = records[records.length - 1];
      return { rows: [{ state_id: last.state_id, state_type: last.state_type, state_family: last.state_family }] };
    }
    // resolution-engine queries for existing resolution transitions
    if (sql.includes('iammai_transition_records') && sql.includes('resolution_transition')) {
      const matter = params[0];
      const resolutions = insertedRecords.transitionRecords.filter(
        r => r.matter_ref === matter && r.transition_type === 'resolution_transition'
      );
      return { rows: resolutions };
    }
    // containment-engine queries
    if (sql.includes('iammai_containment_records')) {
      return { rows: [] };
    }
    // state existence check (containment engine)
    if (sql.includes('iammai_state_records') && sql.includes('state_id = $1')) {
      const stateId = params[0];
      const found = insertedRecords.stateRecords.filter(r => r.state_id === stateId);
      return { rows: found };
    }
    return { rows: [] };
  }),
} as any;

function resetRecords() {
  insertedRecords.stateRecords = [];
  insertedRecords.transitionRecords = [];
  insertedRecords.governanceActions = [];
  insertedRecords.witnessArtifacts = [];
  insertedRecords.validationArtifacts = [];
  insertedRecords.contributionRecords = [];
  insertedRecords.containmentRecords = [];
}

describe('IAMMAI Coordinator', () => {
  beforeEach(() => {
    vi.clearAllMocks();
    resetRecords();
  });

  describe('coordinateSessionCreate', () => {
    it('advances through signal and acceptance phases', async () => {
      const result = await coordinateSessionCreate(mockClient, {
        sessionId: 'sess-1',
        adminId: 'admin-1',
      });

      expect(result.phaseResults).toHaveLength(2);
      expect(result.phaseResults[0].stateRecord.state_type).toBe('signal');
      expect(result.phaseResults[1].stateRecord.state_type).toBe('acceptance');
    });

    it('records governance actions for each phase', async () => {
      const result = await coordinateSessionCreate(mockClient, {
        sessionId: 'sess-1',
        adminId: 'admin-1',
      });

      expect(result.phaseResults[0].governanceAction.action_type).toBe('authorize');
      expect(result.phaseResults[1].governanceAction.action_type).toBe('authorize');
    });

    it('emits witness artifacts for each phase', async () => {
      const result = await coordinateSessionCreate(mockClient, {
        sessionId: 'sess-1',
        adminId: 'admin-1',
      });

      expect(result.phaseResults[0].witnessArtifact.witness_type).toBe('transition');
      expect(result.phaseResults[1].witnessArtifact.witness_type).toBe('transition');
    });

    it('records ORIGIN contribution for admin', async () => {
      const result = await coordinateSessionCreate(mockClient, {
        sessionId: 'sess-1',
        adminId: 'admin-1',
      });

      const contributions = result.phaseResults.flatMap(r => r.contributionRecords);
      expect(contributions.some(c => c.role === 'ORIGIN')).toBe(true);
      expect(contributions.some(c => c.actor_ref === 'bnk:admin:admin-1')).toBe(true);
    });

    it('creates validation artifacts before governance', async () => {
      const result = await coordinateSessionCreate(mockClient, {
        sessionId: 'sess-1',
        adminId: 'admin-1',
      });

      for (const phaseResult of result.phaseResults) {
        expect(phaseResult.validationArtifact.outcome).toBe('pass');
      }
    });
  });

  describe('coordinateSessionClaim', () => {
    it('advances to scope phase', async () => {
      // Set up: create session first (signal + acceptance)
      await coordinateSessionCreate(mockClient, { sessionId: 'sess-1', adminId: 'admin-1' });

      const result = await coordinateSessionClaim(mockClient, {
        sessionId: 'sess-1',
        adminId: 'admin-1',
      });

      expect(result.stateRecord.state_type).toBe('scope');
    });
  });

  describe('coordinateSessionJoin', () => {
    it('advances to presence phase', async () => {
      await coordinateSessionCreate(mockClient, { sessionId: 'sess-1', adminId: 'admin-1' });
      await coordinateSessionClaim(mockClient, { sessionId: 'sess-1', adminId: 'admin-1' });

      const result = await coordinateSessionJoin(mockClient, {
        sessionId: 'sess-1',
        participantRef: 'user-1',
      });

      expect(result.stateRecord.state_type).toBe('presence');
    });
  });

  describe('coordinateSessionStart', () => {
    it('advances through threshold and truth phases', async () => {
      await coordinateSessionCreate(mockClient, { sessionId: 'sess-1', adminId: 'admin-1' });
      await coordinateSessionClaim(mockClient, { sessionId: 'sess-1', adminId: 'admin-1' });
      await coordinateSessionJoin(mockClient, { sessionId: 'sess-1', participantRef: 'user-1' });

      const result = await coordinateSessionStart(mockClient, {
        sessionId: 'sess-1',
        adminId: 'admin-1',
      });

      expect(result.phaseResults).toHaveLength(2);
      expect(result.phaseResults[0].stateRecord.state_type).toBe('threshold');
      expect(result.phaseResults[1].stateRecord.state_type).toBe('truth');
      expect(result.phaseResults[1].stateRecord.state_family).toBe('standing');
    });

    it('records AUTHORIZATION contribution for admin', async () => {
      await coordinateSessionCreate(mockClient, { sessionId: 'sess-1', adminId: 'admin-1' });
      await coordinateSessionClaim(mockClient, { sessionId: 'sess-1', adminId: 'admin-1' });
      await coordinateSessionJoin(mockClient, { sessionId: 'sess-1', participantRef: 'user-1' });

      const result = await coordinateSessionStart(mockClient, {
        sessionId: 'sess-1',
        adminId: 'admin-1',
      });

      const contributions = result.phaseResults.flatMap(r => r.contributionRecords);
      expect(contributions.some(c => c.role === 'AUTHORIZATION')).toBe(true);
    });
  });

  describe('coordinateMessageExchange', () => {
    it('advances to continuity phase with AI contributions', async () => {
      await coordinateSessionCreate(mockClient, { sessionId: 'sess-1', adminId: 'admin-1' });
      await coordinateSessionClaim(mockClient, { sessionId: 'sess-1', adminId: 'admin-1' });
      await coordinateSessionJoin(mockClient, { sessionId: 'sess-1', participantRef: 'user-1' });
      await coordinateSessionStart(mockClient, { sessionId: 'sess-1', adminId: 'admin-1' });

      const result = await coordinateMessageExchange(mockClient, {
        sessionId: 'sess-1',
        aiModel: 'gpt-4o',
      });

      expect(result.stateRecord.state_type).toBe('continuity');
      expect(result.contributionRecords.some(c => c.role === 'FORMALIZATION')).toBe(true);
      expect(result.contributionRecords.some(c => c.role === 'RENDERING')).toBe(true);
    });
  });

  describe('coordinateSessionEnd', () => {
    it('advances through decision + consequence and resolves with FINALIZE', async () => {
      await coordinateSessionCreate(mockClient, { sessionId: 'sess-1', adminId: 'admin-1' });
      await coordinateSessionClaim(mockClient, { sessionId: 'sess-1', adminId: 'admin-1' });
      await coordinateSessionJoin(mockClient, { sessionId: 'sess-1', participantRef: 'user-1' });
      await coordinateSessionStart(mockClient, { sessionId: 'sess-1', adminId: 'admin-1' });
      await coordinateMessageExchange(mockClient, { sessionId: 'sess-1' });

      const result = await coordinateSessionEnd(mockClient, {
        sessionId: 'sess-1',
        adminId: 'admin-1',
      });

      expect(result.governanceAction.action_type).toBe('finalize');
      expect(result.transitionRecord.transition_type).toBe('resolution_transition');
      expect(result.transitionRecord.resolution_type).toBe('FINALIZE');
      expect(result.witnessArtifact.witness_type).toBe('transition');
    });
  });

  describe('full lifecycle', () => {
    it('walks through all 9 phases in correct canonical order', async () => {
      await coordinateSessionCreate(mockClient, { sessionId: 'sess-1', adminId: 'admin-1' });
      await coordinateSessionClaim(mockClient, { sessionId: 'sess-1', adminId: 'admin-1' });
      await coordinateSessionJoin(mockClient, { sessionId: 'sess-1', participantRef: 'user-1' });
      await coordinateSessionStart(mockClient, { sessionId: 'sess-1', adminId: 'admin-1' });
      await coordinateMessageExchange(mockClient, { sessionId: 'sess-1', aiModel: 'gpt-4o' });
      await coordinateSessionEnd(mockClient, { sessionId: 'sess-1', adminId: 'admin-1' });

      const phases = insertedRecords.stateRecords.map(r => r.state_type);
      expect(phases).toEqual([
        'signal', 'acceptance', 'scope', 'presence',
        'threshold', 'truth', 'continuity', 'decision', 'consequence',
      ]);
    });

    it('records validate → govern → state → witness for every phase', async () => {
      await coordinateSessionCreate(mockClient, { sessionId: 'sess-1', adminId: 'admin-1' });

      // 2 phases (signal + acceptance), each producing validation + governance + witness
      expect(insertedRecords.validationArtifacts).toHaveLength(2);
      expect(insertedRecords.governanceActions).toHaveLength(2);
      expect(insertedRecords.witnessArtifacts).toHaveLength(2);
      expect(insertedRecords.stateRecords).toHaveLength(2);
    });
  });
});
