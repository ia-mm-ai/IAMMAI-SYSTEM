/**
 * Contribution Tracker — Unit Tests
 */

import { describe, it, expect } from 'vitest';
import type { IammaiContributionRecord, ContributionRole } from '../../../../src/integrity/iammai/types.js';
import {
  getActorRoles,
  hasRole,
  hasAdminRoles,
  hasAiRoles,
  getRoleMap,
} from '../../../../src/integrity/iammai/contribution-tracker.js';

function makeContribution(
  actor_ref: string,
  role: ContributionRole,
  matter_ref = 'bnk:session:test'
): IammaiContributionRecord {
  return {
    contribution_id: `contrib-${actor_ref}-${role}`,
    matter_ref,
    actor_ref,
    role,
    recorded_at: new Date(),
    context_ref: null,
  };
}

describe('ContributionTracker', () => {
  describe('getActorRoles', () => {
    it('returns roles for a specific actor', () => {
      const contributions = [
        makeContribution('bnk:admin:a1', 'ORIGIN'),
        makeContribution('bnk:admin:a1', 'AUTHORIZATION'),
        makeContribution('bnk:agent:gpt4', 'FORMALIZATION'),
      ];
      const roles = getActorRoles(contributions, 'bnk:admin:a1');
      expect(roles).toEqual(['ORIGIN', 'AUTHORIZATION']);
    });

    it('returns empty array for unknown actor', () => {
      const contributions = [makeContribution('bnk:admin:a1', 'ORIGIN')];
      expect(getActorRoles(contributions, 'bnk:admin:unknown')).toEqual([]);
    });
  });

  describe('hasRole', () => {
    it('returns true when actor has the role', () => {
      const contributions = [makeContribution('bnk:admin:a1', 'ORIGIN')];
      expect(hasRole(contributions, 'bnk:admin:a1', 'ORIGIN')).toBe(true);
    });

    it('returns false when actor does not have the role', () => {
      const contributions = [makeContribution('bnk:admin:a1', 'ORIGIN')];
      expect(hasRole(contributions, 'bnk:admin:a1', 'AUTHORIZATION')).toBe(false);
    });
  });

  describe('hasAdminRoles', () => {
    it('detects ORIGIN role', () => {
      const contributions = [makeContribution('bnk:admin:a1', 'ORIGIN')];
      const result = hasAdminRoles(contributions, 'bnk:admin:a1');
      expect(result.hasOrigin).toBe(true);
      expect(result.hasAuthorization).toBe(false);
    });

    it('detects AUTHORIZATION role', () => {
      const contributions = [makeContribution('bnk:admin:a1', 'AUTHORIZATION')];
      const result = hasAdminRoles(contributions, 'bnk:admin:a1');
      expect(result.hasOrigin).toBe(false);
      expect(result.hasAuthorization).toBe(true);
    });

    it('detects both roles', () => {
      const contributions = [
        makeContribution('bnk:admin:a1', 'ORIGIN'),
        makeContribution('bnk:admin:a1', 'AUTHORIZATION'),
      ];
      const result = hasAdminRoles(contributions, 'bnk:admin:a1');
      expect(result.hasOrigin).toBe(true);
      expect(result.hasAuthorization).toBe(true);
    });

    it('returns false for no roles', () => {
      const result = hasAdminRoles([], 'bnk:admin:a1');
      expect(result.hasOrigin).toBe(false);
      expect(result.hasAuthorization).toBe(false);
    });
  });

  describe('hasAiRoles', () => {
    it('detects FORMALIZATION role', () => {
      const contributions = [makeContribution('bnk:agent:gpt4', 'FORMALIZATION')];
      const result = hasAiRoles(contributions, 'bnk:agent:gpt4');
      expect(result.hasFormalization).toBe(true);
      expect(result.hasRendering).toBe(false);
    });

    it('detects RENDERING role', () => {
      const contributions = [makeContribution('bnk:agent:gpt4', 'RENDERING')];
      const result = hasAiRoles(contributions, 'bnk:agent:gpt4');
      expect(result.hasFormalization).toBe(false);
      expect(result.hasRendering).toBe(true);
    });

    it('detects both roles', () => {
      const contributions = [
        makeContribution('bnk:agent:gpt4', 'FORMALIZATION'),
        makeContribution('bnk:agent:gpt4', 'RENDERING'),
      ];
      const result = hasAiRoles(contributions, 'bnk:agent:gpt4');
      expect(result.hasFormalization).toBe(true);
      expect(result.hasRendering).toBe(true);
    });
  });

  describe('getRoleMap', () => {
    it('builds a map of actors to their roles', () => {
      const contributions = [
        makeContribution('bnk:admin:a1', 'ORIGIN'),
        makeContribution('bnk:admin:a1', 'AUTHORIZATION'),
        makeContribution('bnk:agent:gpt4', 'FORMALIZATION'),
        makeContribution('bnk:agent:gpt4', 'RENDERING'),
        makeContribution('bnk:admin:a1', 'ELICITATION'),
      ];
      const map = getRoleMap(contributions);
      expect(map['bnk:admin:a1']).toEqual(['ORIGIN', 'AUTHORIZATION', 'ELICITATION']);
      expect(map['bnk:agent:gpt4']).toEqual(['FORMALIZATION', 'RENDERING']);
    });

    it('deduplicates roles', () => {
      const contributions = [
        makeContribution('bnk:admin:a1', 'ORIGIN'),
        makeContribution('bnk:admin:a1', 'ORIGIN'), // duplicate
      ];
      const map = getRoleMap(contributions);
      expect(map['bnk:admin:a1']).toEqual(['ORIGIN']);
    });

    it('returns empty map for no contributions', () => {
      expect(getRoleMap([])).toEqual({});
    });
  });
});
