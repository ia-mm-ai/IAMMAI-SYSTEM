/**
 * IAMMAI Schema Validator — Unit Tests
 */

import { describe, it, expect } from 'vitest';
import {
  validateStateRecord,
  validateTransitionRecord,
  validateGovernanceAction,
  validateWitnessArtifact,
  validateValidationArtifact,
  validateContributionRecord,
  validateContainmentRecord,
} from '../../../../src/integrity/iammai/schema-validator.js';
import { MANDATORY_NON_CLAIMS } from '../../../../src/integrity/iammai/types.js';

// ============================================================================
// Helpers — valid record factories
// ============================================================================

function validStateRecord() {
  return {
    state_id: 'state-001',
    matter_ref: 'bnk:session:abc',
    state_family: 'preparation',
    state_type: 'signal',
    recorded_at: new Date(),
    predecessor_ref: null,
    containment_ref: null,
    related_transition_ref: null,
    related_governance_ref: null,
    related_validation_ref: null,
    related_witness_ref: null,
  };
}

function validTransitionRecord() {
  return {
    transition_id: 'trans-001',
    matter_ref: 'bnk:session:abc',
    source_ref: 'state-001',
    target_ref: 'state-002',
    transition_type: 'preparation_progression',
    occurred_at: new Date(),
    resolution_type: null,
    predecessor_ref: null,
  };
}

function validGovernanceAction() {
  return {
    governance_action_id: 'gov-001',
    action_type: 'authorize',
    authority_class: 'OPERATOR',
    actor_ref: 'bnk:admin:admin-1',
    legitimacy_basis_ref: 'bnk:protocol:session-creation',
    matter_ref: 'bnk:session:abc',
    acted_at: new Date(),
    delegated_from_ref: null,
    target_state_ref: null,
    target_transition_ref: null,
    contribution_role_map_ref: null,
  };
}

function validWitnessArtifact() {
  return {
    witness_id: 'wit-001',
    witness_type: 'transition',
    target_ref: 'state-001',
    observed_at: new Date(),
    claims: ['phase_transition_observed'],
    non_claims: { ...MANDATORY_NON_CLAIMS },
    actor_ref: null,
    surface_ref: null,
  };
}

function validValidationArtifact() {
  return {
    validation_id: 'val-001',
    validation_type: 'transition_legality',
    target_ref: 'state-002',
    condition_set_ref: 'bnk:protocol:phase-order',
    outcome: 'pass',
    checked_at: new Date(),
    reason_refs: null,
    actor_ref: null,
  };
}

function validContributionRecord() {
  return {
    contribution_id: 'contrib-001',
    matter_ref: 'bnk:session:abc',
    actor_ref: 'bnk:admin:admin-1',
    role: 'ORIGIN',
    recorded_at: new Date(),
    context_ref: null,
  };
}

function validContainmentRecord() {
  return {
    containment_id: 'contain-001',
    matter_ref: 'bnk:session:abc',
    target_state_ref: 'state-005',
    action: 'HOLD',
    actor_ref: 'bnk:admin:admin-1',
    reason: 'Pending review',
    recorded_at: new Date(),
    governance_action_ref: null,
  };
}

// ============================================================================
// State Record Validation
// ============================================================================

describe('validateStateRecord', () => {
  it('accepts a valid state record', () => {
    const result = validateStateRecord(validStateRecord());
    expect(result.valid).toBe(true);
    expect(result.errors).toBeNull();
  });

  it('rejects missing state_id', () => {
    const record = { ...validStateRecord(), state_id: undefined };
    delete (record as Record<string, unknown>).state_id;
    const result = validateStateRecord(record);
    expect(result.valid).toBe(false);
    expect(result.errors).not.toBeNull();
  });

  it('rejects empty state_id', () => {
    const result = validateStateRecord({ ...validStateRecord(), state_id: '' });
    expect(result.valid).toBe(false);
  });

  it('rejects invalid state_family', () => {
    const result = validateStateRecord({ ...validStateRecord(), state_family: 'invalid' });
    expect(result.valid).toBe(false);
  });

  it('rejects invalid state_type', () => {
    const result = validateStateRecord({ ...validStateRecord(), state_type: 'invalid_phase' });
    expect(result.valid).toBe(false);
  });

  it('accepts all 9 phase types', () => {
    const phases = ['signal', 'acceptance', 'scope', 'presence', 'threshold',
      'truth', 'continuity', 'decision', 'consequence'];
    for (const phase of phases) {
      const family = ['signal', 'acceptance', 'scope', 'presence', 'threshold'].includes(phase)
        ? 'preparation' : 'standing';
      const result = validateStateRecord({ ...validStateRecord(), state_type: phase, state_family: family });
      expect(result.valid).toBe(true);
    }
  });

  it('accepts both state families', () => {
    expect(validateStateRecord({ ...validStateRecord(), state_family: 'preparation' }).valid).toBe(true);
    expect(validateStateRecord({ ...validStateRecord(), state_family: 'standing', state_type: 'truth' }).valid).toBe(true);
  });
});

// ============================================================================
// Transition Record Validation
// ============================================================================

describe('validateTransitionRecord', () => {
  it('accepts a valid transition record', () => {
    const result = validateTransitionRecord(validTransitionRecord());
    expect(result.valid).toBe(true);
    expect(result.errors).toBeNull();
  });

  it('rejects missing transition_id', () => {
    const record = { ...validTransitionRecord() };
    delete (record as Record<string, unknown>).transition_id;
    const result = validateTransitionRecord(record);
    expect(result.valid).toBe(false);
  });

  it('rejects invalid transition_type', () => {
    const result = validateTransitionRecord({ ...validTransitionRecord(), transition_type: 'invalid' });
    expect(result.valid).toBe(false);
  });

  it('accepts all transition types', () => {
    const types = [
      'preparation_progression', 'threshold_eligibility', 'truth_formation',
      'continuity_transition', 'decision_transition', 'consequence_transition',
      'containment_apply', 'containment_release', 'resolution_transition',
    ];
    for (const type of types) {
      const result = validateTransitionRecord({ ...validTransitionRecord(), transition_type: type });
      expect(result.valid).toBe(true);
    }
  });

  it('accepts resolution_type when transition_type is resolution_transition', () => {
    const result = validateTransitionRecord({
      ...validTransitionRecord(),
      transition_type: 'resolution_transition',
      resolution_type: 'FINALIZE',
    });
    expect(result.valid).toBe(true);
  });

  it('accepts all 3 resolution types', () => {
    for (const rt of ['FINALIZE', 'INVALIDATE', 'EVOLVE']) {
      const result = validateTransitionRecord({
        ...validTransitionRecord(),
        transition_type: 'resolution_transition',
        resolution_type: rt,
      });
      expect(result.valid).toBe(true);
    }
  });

  it('rejects invalid resolution_type', () => {
    const result = validateTransitionRecord({
      ...validTransitionRecord(),
      transition_type: 'resolution_transition',
      resolution_type: 'CLOSE',
    });
    expect(result.valid).toBe(false);
  });
});

// ============================================================================
// Governance Action Validation
// ============================================================================

describe('validateGovernanceAction', () => {
  it('accepts a valid governance action', () => {
    const result = validateGovernanceAction(validGovernanceAction());
    expect(result.valid).toBe(true);
    expect(result.errors).toBeNull();
  });

  it('rejects missing actor_ref', () => {
    const record = { ...validGovernanceAction() };
    delete (record as Record<string, unknown>).actor_ref;
    const result = validateGovernanceAction(record);
    expect(result.valid).toBe(false);
  });

  it('rejects missing legitimacy_basis_ref', () => {
    const record = { ...validGovernanceAction() };
    delete (record as Record<string, unknown>).legitimacy_basis_ref;
    const result = validateGovernanceAction(record);
    expect(result.valid).toBe(false);
  });

  it('accepts all 7 action types', () => {
    for (const at of ['authorize', 'deny', 'hold', 'release', 'finalize', 'invalidate', 'evolve']) {
      const result = validateGovernanceAction({ ...validGovernanceAction(), action_type: at });
      expect(result.valid).toBe(true);
    }
  });

  it('rejects invalid action_type', () => {
    const result = validateGovernanceAction({ ...validGovernanceAction(), action_type: 'update' });
    expect(result.valid).toBe(false);
  });

  it('accepts all 3 authority classes', () => {
    for (const ac of ['SYSTEM', 'OPERATOR', 'DELEGATED']) {
      const result = validateGovernanceAction({ ...validGovernanceAction(), authority_class: ac });
      expect(result.valid).toBe(true);
    }
  });

  it('rejects invalid authority_class', () => {
    const result = validateGovernanceAction({ ...validGovernanceAction(), authority_class: 'UNKNOWN' });
    expect(result.valid).toBe(false);
  });
});

// ============================================================================
// Witness Artifact Validation
// ============================================================================

describe('validateWitnessArtifact', () => {
  it('accepts a valid witness artifact', () => {
    const result = validateWitnessArtifact(validWitnessArtifact());
    expect(result.valid).toBe(true);
    expect(result.errors).toBeNull();
  });

  it('rejects missing non_claims', () => {
    const record = { ...validWitnessArtifact() };
    delete (record as Record<string, unknown>).non_claims;
    const result = validateWitnessArtifact(record);
    expect(result.valid).toBe(false);
  });

  it('rejects incomplete non_claims (missing not_authorship)', () => {
    const nonClaims = { ...MANDATORY_NON_CLAIMS };
    delete (nonClaims as Record<string, unknown>).not_authorship;
    const result = validateWitnessArtifact({ ...validWitnessArtifact(), non_claims: nonClaims });
    expect(result.valid).toBe(false);
  });

  it('rejects incomplete non_claims (missing not_governance_force)', () => {
    const nonClaims = { ...MANDATORY_NON_CLAIMS };
    delete (nonClaims as Record<string, unknown>).not_governance_force;
    const result = validateWitnessArtifact({ ...validWitnessArtifact(), non_claims: nonClaims });
    expect(result.valid).toBe(false);
  });

  it('accepts all 5 witness types', () => {
    for (const wt of ['interaction', 'validation', 'transition', 'publication', 'state_observation']) {
      const result = validateWitnessArtifact({ ...validWitnessArtifact(), witness_type: wt });
      expect(result.valid).toBe(true);
    }
  });

  it('rejects invalid witness_type', () => {
    const result = validateWitnessArtifact({ ...validWitnessArtifact(), witness_type: 'audit' });
    expect(result.valid).toBe(false);
  });

  it('accepts empty claims array', () => {
    const result = validateWitnessArtifact({ ...validWitnessArtifact(), claims: [] });
    expect(result.valid).toBe(true);
  });

  it('accepts multiple claims', () => {
    const result = validateWitnessArtifact({
      ...validWitnessArtifact(),
      claims: ['claim_a', 'claim_b', 'claim_c'],
    });
    expect(result.valid).toBe(true);
  });
});

// ============================================================================
// Validation Artifact Validation
// ============================================================================

describe('validateValidationArtifact', () => {
  it('accepts a valid validation artifact', () => {
    const result = validateValidationArtifact(validValidationArtifact());
    expect(result.valid).toBe(true);
    expect(result.errors).toBeNull();
  });

  it('accepts all 4 outcomes', () => {
    for (const outcome of ['pass', 'fail', 'blocked', 'indeterminate']) {
      const result = validateValidationArtifact({ ...validValidationArtifact(), outcome });
      expect(result.valid).toBe(true);
    }
  });

  it('rejects invalid outcome', () => {
    const result = validateValidationArtifact({ ...validValidationArtifact(), outcome: 'success' });
    expect(result.valid).toBe(false);
  });

  it('accepts all 5 validation types', () => {
    for (const vt of ['admissibility', 'threshold', 'transition_legality', 'governance_precondition', 'bounded_consistency']) {
      const result = validateValidationArtifact({ ...validValidationArtifact(), validation_type: vt });
      expect(result.valid).toBe(true);
    }
  });

  it('rejects invalid validation_type', () => {
    const result = validateValidationArtifact({ ...validValidationArtifact(), validation_type: 'custom' });
    expect(result.valid).toBe(false);
  });

  it('rejects missing condition_set_ref', () => {
    const record = { ...validValidationArtifact() };
    delete (record as Record<string, unknown>).condition_set_ref;
    const result = validateValidationArtifact(record);
    expect(result.valid).toBe(false);
  });
});

// ============================================================================
// Contribution Record Validation
// ============================================================================

describe('validateContributionRecord', () => {
  it('accepts a valid contribution record', () => {
    const result = validateContributionRecord(validContributionRecord());
    expect(result.valid).toBe(true);
    expect(result.errors).toBeNull();
  });

  it('accepts all 6 contribution roles', () => {
    for (const role of ['ORIGIN', 'ELICITATION', 'FORMALIZATION', 'AUTHORIZATION', 'RENDERING', 'TRANSMISSION']) {
      const result = validateContributionRecord({ ...validContributionRecord(), role });
      expect(result.valid).toBe(true);
    }
  });

  it('rejects invalid role', () => {
    const result = validateContributionRecord({ ...validContributionRecord(), role: 'AUTHOR' });
    expect(result.valid).toBe(false);
  });

  it('rejects missing matter_ref', () => {
    const record = { ...validContributionRecord() };
    delete (record as Record<string, unknown>).matter_ref;
    const result = validateContributionRecord(record);
    expect(result.valid).toBe(false);
  });
});

// ============================================================================
// Containment Record Validation
// ============================================================================

describe('validateContainmentRecord', () => {
  it('accepts a valid containment record', () => {
    const result = validateContainmentRecord(validContainmentRecord());
    expect(result.valid).toBe(true);
    expect(result.errors).toBeNull();
  });

  it('accepts HOLD action', () => {
    const result = validateContainmentRecord({ ...validContainmentRecord(), action: 'HOLD' });
    expect(result.valid).toBe(true);
  });

  it('accepts RELEASE action', () => {
    const result = validateContainmentRecord({ ...validContainmentRecord(), action: 'RELEASE' });
    expect(result.valid).toBe(true);
  });

  it('rejects invalid action', () => {
    const result = validateContainmentRecord({ ...validContainmentRecord(), action: 'PAUSE' });
    expect(result.valid).toBe(false);
  });

  it('rejects missing reason', () => {
    const record = { ...validContainmentRecord() };
    delete (record as Record<string, unknown>).reason;
    const result = validateContainmentRecord(record);
    expect(result.valid).toBe(false);
  });

  it('rejects empty reason', () => {
    const result = validateContainmentRecord({ ...validContainmentRecord(), reason: '' });
    expect(result.valid).toBe(false);
  });
});
