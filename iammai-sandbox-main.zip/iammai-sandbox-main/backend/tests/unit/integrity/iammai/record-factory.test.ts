/**
 * IAMMAI Record Factory — Unit Tests
 */

import { describe, it, expect } from 'vitest';
import {
  createStateRecord,
  createTransitionRecord,
  createGovernanceAction,
  createWitnessArtifact,
  createValidationArtifact,
  createContributionRecord,
  createContainmentRecord,
} from '../../../../src/integrity/iammai/record-factory.js';

// ============================================================================
// State Record
// ============================================================================

describe('createStateRecord', () => {
  it('creates a valid preparation state record', () => {
    const record = createStateRecord({
      matter_ref: 'bnk:session:abc',
      state_type: 'signal',
    });
    expect(record.state_id).toBeTruthy();
    expect(record.matter_ref).toBe('bnk:session:abc');
    expect(record.state_family).toBe('preparation');
    expect(record.state_type).toBe('signal');
    expect(record.recorded_at).toBeInstanceOf(Date);
    expect(record.predecessor_ref).toBeNull();
  });

  it('creates a valid standing state record', () => {
    const record = createStateRecord({
      matter_ref: 'bnk:session:abc',
      state_type: 'truth',
    });
    expect(record.state_family).toBe('standing');
  });

  it('auto-assigns state_family based on phase', () => {
    const prep = createStateRecord({ matter_ref: 'ref', state_type: 'threshold' });
    expect(prep.state_family).toBe('preparation');

    const stand = createStateRecord({ matter_ref: 'ref', state_type: 'decision' });
    expect(stand.state_family).toBe('standing');
  });

  it('links predecessor_ref', () => {
    const first = createStateRecord({ matter_ref: 'ref', state_type: 'signal' });
    const second = createStateRecord({
      matter_ref: 'ref',
      state_type: 'acceptance',
      predecessor_ref: first.state_id,
    });
    expect(second.predecessor_ref).toBe(first.state_id);
  });

  it('generates unique state_ids', () => {
    const a = createStateRecord({ matter_ref: 'ref', state_type: 'signal' });
    const b = createStateRecord({ matter_ref: 'ref', state_type: 'signal' });
    expect(a.state_id).not.toBe(b.state_id);
  });

  it('creates all 9 phase types', () => {
    const phases = ['signal', 'acceptance', 'scope', 'presence', 'threshold',
      'truth', 'continuity', 'decision', 'consequence'] as const;
    for (const phase of phases) {
      const record = createStateRecord({ matter_ref: 'ref', state_type: phase });
      expect(record.state_type).toBe(phase);
    }
  });
});

// ============================================================================
// Transition Record
// ============================================================================

describe('createTransitionRecord', () => {
  it('creates a valid transition record', () => {
    const record = createTransitionRecord({
      matter_ref: 'bnk:session:abc',
      source_ref: 'state-1',
      target_ref: 'state-2',
      transition_type: 'preparation_progression',
    });
    expect(record.transition_id).toBeTruthy();
    expect(record.matter_ref).toBe('bnk:session:abc');
    expect(record.source_ref).toBe('state-1');
    expect(record.target_ref).toBe('state-2');
    expect(record.transition_type).toBe('preparation_progression');
    expect(record.resolution_type).toBeNull();
    expect(record.predecessor_ref).toBeNull();
  });

  it('creates a resolution transition with type', () => {
    const record = createTransitionRecord({
      matter_ref: 'ref',
      source_ref: 's1',
      target_ref: 's2',
      transition_type: 'resolution_transition',
      resolution_type: 'FINALIZE',
    });
    expect(record.resolution_type).toBe('FINALIZE');
  });

  it('creates EVOLVE transition with predecessor_ref', () => {
    const record = createTransitionRecord({
      matter_ref: 'ref',
      source_ref: 's1',
      target_ref: 's2',
      transition_type: 'resolution_transition',
      resolution_type: 'EVOLVE',
      predecessor_ref: 'prev-trans',
    });
    expect(record.resolution_type).toBe('EVOLVE');
    expect(record.predecessor_ref).toBe('prev-trans');
  });
});

// ============================================================================
// Governance Action
// ============================================================================

describe('createGovernanceAction', () => {
  it('creates a valid governance action', () => {
    const record = createGovernanceAction({
      action_type: 'authorize',
      authority_class: 'OPERATOR',
      actor_ref: 'bnk:admin:admin-1',
      legitimacy_basis_ref: 'bnk:protocol:session-creation',
      matter_ref: 'bnk:session:abc',
    });
    expect(record.governance_action_id).toBeTruthy();
    expect(record.action_type).toBe('authorize');
    expect(record.authority_class).toBe('OPERATOR');
    expect(record.actor_ref).toBe('bnk:admin:admin-1');
    expect(record.legitimacy_basis_ref).toBe('bnk:protocol:session-creation');
    expect(record.matter_ref).toBe('bnk:session:abc');
  });

  it('creates all 7 action types', () => {
    const types = ['authorize', 'deny', 'hold', 'release', 'finalize', 'invalidate', 'evolve'] as const;
    for (const actionType of types) {
      const record = createGovernanceAction({
        action_type: actionType,
        authority_class: 'SYSTEM',
        actor_ref: 'actor',
        legitimacy_basis_ref: 'basis',
        matter_ref: 'matter',
      });
      expect(record.action_type).toBe(actionType);
    }
  });
});

// ============================================================================
// Witness Artifact
// ============================================================================

describe('createWitnessArtifact', () => {
  it('creates a witness with mandatory non-claims', () => {
    const record = createWitnessArtifact({
      witness_type: 'transition',
      target_ref: 'state-1',
      claims: ['phase_transition_observed'],
    });
    expect(record.witness_id).toBeTruthy();
    expect(record.non_claims.not_authorship).toBe(true);
    expect(record.non_claims.not_semantic_source).toBe(true);
    expect(record.non_claims.not_final_authority).toBe(true);
    expect(record.non_claims.not_automatic_truth_creation).toBe(true);
    expect(record.non_claims.not_governance_force).toBe(true);
  });

  it('includes all 5 non-claims automatically', () => {
    const record = createWitnessArtifact({
      witness_type: 'validation',
      target_ref: 'val-1',
      claims: [],
    });
    expect(Object.keys(record.non_claims)).toHaveLength(5);
  });

  it('preserves claims array', () => {
    const claims = ['claim_a', 'claim_b'];
    const record = createWitnessArtifact({
      witness_type: 'interaction',
      target_ref: 'ref',
      claims,
    });
    expect(record.claims).toEqual(claims);
  });
});

// ============================================================================
// Validation Artifact
// ============================================================================

describe('createValidationArtifact', () => {
  it('creates a valid validation artifact', () => {
    const record = createValidationArtifact({
      validation_type: 'transition_legality',
      target_ref: 'state-2',
      condition_set_ref: 'bnk:protocol:phase-order',
      outcome: 'pass',
    });
    expect(record.validation_id).toBeTruthy();
    expect(record.outcome).toBe('pass');
  });

  it('creates all 4 outcome types', () => {
    for (const outcome of ['pass', 'fail', 'blocked', 'indeterminate'] as const) {
      const record = createValidationArtifact({
        validation_type: 'admissibility',
        target_ref: 'ref',
        condition_set_ref: 'cond',
        outcome,
      });
      expect(record.outcome).toBe(outcome);
    }
  });
});

// ============================================================================
// Contribution Record
// ============================================================================

describe('createContributionRecord', () => {
  it('creates a valid contribution record', () => {
    const record = createContributionRecord({
      matter_ref: 'bnk:session:abc',
      actor_ref: 'bnk:admin:admin-1',
      role: 'ORIGIN',
    });
    expect(record.contribution_id).toBeTruthy();
    expect(record.role).toBe('ORIGIN');
  });

  it('creates all 6 roles', () => {
    const roles = ['ORIGIN', 'ELICITATION', 'FORMALIZATION', 'AUTHORIZATION', 'RENDERING', 'TRANSMISSION'] as const;
    for (const role of roles) {
      const record = createContributionRecord({
        matter_ref: 'ref', actor_ref: 'actor', role,
      });
      expect(record.role).toBe(role);
    }
  });
});

// ============================================================================
// Containment Record
// ============================================================================

describe('createContainmentRecord', () => {
  it('creates a HOLD record', () => {
    const record = createContainmentRecord({
      matter_ref: 'bnk:session:abc',
      target_state_ref: 'state-5',
      action: 'HOLD',
      actor_ref: 'bnk:admin:admin-1',
      reason: 'Pending review',
    });
    expect(record.containment_id).toBeTruthy();
    expect(record.action).toBe('HOLD');
  });

  it('creates a RELEASE record', () => {
    const record = createContainmentRecord({
      matter_ref: 'ref',
      target_state_ref: 'state-5',
      action: 'RELEASE',
      actor_ref: 'actor',
      reason: 'Review complete',
    });
    expect(record.action).toBe('RELEASE');
  });
});
