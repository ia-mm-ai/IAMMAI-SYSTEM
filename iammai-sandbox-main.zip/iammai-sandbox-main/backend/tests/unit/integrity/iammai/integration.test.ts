/**
 * IAMMAI Integration Tests — Full Lifecycle
 *
 * Tests the complete IAMMAI coordination sequence from session creation
 * through resolution, verifying all canonical records, evaluators, and
 * conformance assessment work together.
 */

import { describe, it, expect, vi, beforeEach } from 'vitest';

// Track all inserted records
const insertedRecords: Record<string, any[]> = {
  stateRecords: [],
  transitionRecords: [],
  governanceActions: [],
  witnessArtifacts: [],
  validationArtifacts: [],
  contributionRecords: [],
  containmentRecords: [],
};

vi.mock('../../../../src/integrity/iammai/registry.js', () => ({
  insertStateRecord: vi.fn(async (_c: any, r: any) => { insertedRecords.stateRecords.push(r); return r; }),
  insertTransitionRecord: vi.fn(async (_c: any, r: any) => { insertedRecords.transitionRecords.push(r); return r; }),
  insertGovernanceAction: vi.fn(async (_c: any, r: any) => { insertedRecords.governanceActions.push(r); return r; }),
  insertWitnessArtifact: vi.fn(async (_c: any, r: any) => { insertedRecords.witnessArtifacts.push(r); return r; }),
  insertValidationArtifact: vi.fn(async (_c: any, r: any) => { insertedRecords.validationArtifacts.push(r); return r; }),
  insertContributionRecord: vi.fn(async (_c: any, r: any) => { insertedRecords.contributionRecords.push(r); return r; }),
  insertContainmentRecord: vi.fn(async (_c: any, r: any) => { insertedRecords.containmentRecords.push(r); return r; }),
  getStateRecordsByMatter: vi.fn(async (m: string) => insertedRecords.stateRecords.filter(r => r.matter_ref === m)),
  getTransitionRecordsByMatter: vi.fn(async (m: string) => insertedRecords.transitionRecords.filter(r => r.matter_ref === m)),
  getGovernanceActionsByMatter: vi.fn(async (m: string) => insertedRecords.governanceActions.filter(r => r.matter_ref === m)),
  getContainmentRecordsByMatter: vi.fn(async () => []),
  getContributionRecordsByMatter: vi.fn(async (m: string) => insertedRecords.contributionRecords.filter(r => r.matter_ref === m)),
  getWitnessArtifactsByTarget: vi.fn(async () => []),
  getValidationArtifactsByTarget: vi.fn(async () => []),
}));

vi.mock('../../../../src/lib/db.js', () => ({
  query: vi.fn(),
}));

import {
  coordinateSessionCreate,
  coordinateSessionClaim,
  coordinateSessionJoin,
  coordinateSessionStart,
  coordinateMessageExchange,
  coordinateSessionEnd,
} from '../../../../src/integrity/iammai/coordinator.js';
import { assessConformance } from '../../../../src/integrity/iammai/conformance-assessor.js';
import { auditMatter } from '../../../../src/integrity/iammai/governance-query.js';
import { I11PhaseIntegrity } from '../../../../src/integrity/iammai/protocols/i11-phase-integrity.js';
import { I13ResolutionLegality } from '../../../../src/integrity/iammai/protocols/i13-resolution-legality.js';
import { I14LineagePreservation } from '../../../../src/integrity/iammai/protocols/i14-lineage-preservation.js';
import { I15GovernanceAttribution } from '../../../../src/integrity/iammai/protocols/i15-governance-attribution.js';
import type { IammaiEvaluationContext } from '../../../../src/integrity/iammai/types.js';

const mockClient = {
  query: vi.fn(async (sql: string, params: any[]) => {
    if (sql.includes('iammai_state_records') && sql.includes('ORDER BY recorded_at DESC LIMIT 1')) {
      const matter = params[0];
      const records = insertedRecords.stateRecords.filter(r => r.matter_ref === matter);
      if (records.length === 0) return { rows: [] };
      const last = records[records.length - 1];
      return { rows: [{ state_id: last.state_id, state_type: last.state_type, state_family: last.state_family }] };
    }
    if (sql.includes('iammai_transition_records') && sql.includes('resolution_transition')) {
      const matter = params[0];
      const resolutions = insertedRecords.transitionRecords.filter(
        r => r.matter_ref === matter && r.transition_type === 'resolution_transition'
      );
      return { rows: resolutions };
    }
    if (sql.includes('iammai_containment_records')) return { rows: [] };
    if (sql.includes('iammai_state_records') && sql.includes('state_id = $1')) {
      return { rows: insertedRecords.stateRecords.filter(r => r.state_id === params[0]) };
    }
    return { rows: [] };
  }),
} as any;

function resetRecords() {
  for (const key of Object.keys(insertedRecords)) {
    insertedRecords[key] = [];
  }
}

function buildIammaiContext(): IammaiEvaluationContext {
  return {
    stateRecords: insertedRecords.stateRecords,
    transitionRecords: insertedRecords.transitionRecords,
    governanceActions: insertedRecords.governanceActions,
    witnessArtifacts: insertedRecords.witnessArtifacts,
    validationArtifacts: insertedRecords.validationArtifacts,
    contributionRecords: insertedRecords.contributionRecords,
    containmentRecords: insertedRecords.containmentRecords,
  };
}

describe('IAMMAI Integration', () => {
  beforeEach(() => {
    vi.clearAllMocks();
    resetRecords();
  });

  it('full lifecycle produces all 9 phases with resolution', async () => {
    await coordinateSessionCreate(mockClient, { sessionId: 'sess-1', adminId: 'admin-1' });
    await coordinateSessionClaim(mockClient, { sessionId: 'sess-1', adminId: 'admin-1' });
    await coordinateSessionJoin(mockClient, { sessionId: 'sess-1', participantRef: 'user-1' });
    await coordinateSessionStart(mockClient, { sessionId: 'sess-1', adminId: 'admin-1' });
    await coordinateMessageExchange(mockClient, { sessionId: 'sess-1', aiModel: 'gpt-4o' });
    await coordinateSessionEnd(mockClient, { sessionId: 'sess-1', adminId: 'admin-1' });

    // Verify all 9 phases created
    const phases = insertedRecords.stateRecords.map(r => r.state_type);
    expect(phases).toEqual([
      'signal', 'acceptance', 'scope', 'presence',
      'threshold', 'truth', 'continuity', 'decision', 'consequence',
    ]);

    // Verify resolution exists
    const resolutions = insertedRecords.transitionRecords.filter(
      t => t.transition_type === 'resolution_transition'
    );
    expect(resolutions).toHaveLength(1);
    expect(resolutions[0].resolution_type).toBe('FINALIZE');
  });

  it('all 8 audit questions are answerable after full lifecycle', async () => {
    await coordinateSessionCreate(mockClient, { sessionId: 'sess-1', adminId: 'admin-1' });
    await coordinateSessionClaim(mockClient, { sessionId: 'sess-1', adminId: 'admin-1' });
    await coordinateSessionJoin(mockClient, { sessionId: 'sess-1', participantRef: 'user-1' });
    await coordinateSessionStart(mockClient, { sessionId: 'sess-1', adminId: 'admin-1' });
    await coordinateMessageExchange(mockClient, { sessionId: 'sess-1', aiModel: 'gpt-4o' });
    await coordinateSessionEnd(mockClient, { sessionId: 'sess-1', adminId: 'admin-1' });

    const ctx = buildIammaiContext();
    const answers = auditMatter(ctx);
    expect(answers).toHaveLength(8);

    // Q1: Current phase
    const q1 = answers[0] as any;
    expect(q1.question).toBe('Q1_CURRENT_PHASE');
    expect(q1.phase).toBe('consequence');

    // Q2: Admissibility
    const q2 = answers[1] as any;
    expect(q2.question).toBe('Q2_ADMISSIBILITY');
    expect(q2.admissible).toBe(true);

    // Q3: Standing
    const q3 = answers[2] as any;
    expect(q3.question).toBe('Q3_STANDING');
    expect(q3.hasStanding).toBe(true);

    // Q4: Resolution
    const q4 = answers[3] as any;
    expect(q4.question).toBe('Q4_RESOLUTION');
    expect(q4.resolved).toBe(true);
    expect(q4.resolutionType).toBe('FINALIZE');

    // Q6: Attribution
    const q6 = answers[5] as any;
    expect(q6.question).toBe('Q6_ATTRIBUTION');
    expect(q6.actions.length).toBeGreaterThan(0);

    // Q7: Contributions
    const q7 = answers[6] as any;
    expect(q7.question).toBe('Q7_CONTRIBUTIONS');
    expect(q7.contributions.length).toBeGreaterThan(0);

    // Q8: Preservation
    const q8 = answers[7] as any;
    expect(q8.question).toBe('Q8_PRESERVATION');
    expect(q8.totalRecords).toBeGreaterThan(0);
  });

  it('I.11 evaluator passes after full lifecycle', async () => {
    await coordinateSessionCreate(mockClient, { sessionId: 'sess-1', adminId: 'admin-1' });
    await coordinateSessionClaim(mockClient, { sessionId: 'sess-1', adminId: 'admin-1' });
    await coordinateSessionJoin(mockClient, { sessionId: 'sess-1', participantRef: 'user-1' });
    await coordinateSessionStart(mockClient, { sessionId: 'sess-1', adminId: 'admin-1' });
    await coordinateMessageExchange(mockClient, { sessionId: 'sess-1' });
    await coordinateSessionEnd(mockClient, { sessionId: 'sess-1', adminId: 'admin-1' });

    const ctx = buildIammaiContext();
    const evaluator = new I11PhaseIntegrity();
    const result = evaluator.evaluate({
      session: { iammaiTracked: true } as any,
      ledgerEntries: [],
      presenceRecords: [],
      adminActions: [],
      coAgencyActions: [],
      iammaiContext: ctx,
    });
    expect(result.result).toBe('PASS');
  });

  it('I.14 evaluator passes — lineage chain intact', async () => {
    await coordinateSessionCreate(mockClient, { sessionId: 'sess-1', adminId: 'admin-1' });
    await coordinateSessionClaim(mockClient, { sessionId: 'sess-1', adminId: 'admin-1' });
    await coordinateSessionJoin(mockClient, { sessionId: 'sess-1', participantRef: 'user-1' });
    await coordinateSessionStart(mockClient, { sessionId: 'sess-1', adminId: 'admin-1' });

    const ctx = buildIammaiContext();
    const evaluator = new I14LineagePreservation();
    const result = evaluator.evaluate({
      session: { iammaiTracked: true } as any,
      ledgerEntries: [],
      presenceRecords: [],
      adminActions: [],
      coAgencyActions: [],
      iammaiContext: ctx,
    });
    expect(result.result).toBe('PASS');
  });

  it('I.15 evaluator passes — all governance actions attributed', async () => {
    await coordinateSessionCreate(mockClient, { sessionId: 'sess-1', adminId: 'admin-1' });

    const ctx = buildIammaiContext();
    const evaluator = new I15GovernanceAttribution();
    const result = evaluator.evaluate({
      session: { iammaiTracked: true } as any,
      ledgerEntries: [],
      presenceRecords: [],
      adminActions: [],
      coAgencyActions: [],
      iammaiContext: ctx,
    });
    expect(result.result).toBe('PASS');
  });

  it('conformance assessment is CONFORMANT after full lifecycle', async () => {
    await coordinateSessionCreate(mockClient, { sessionId: 'sess-1', adminId: 'admin-1' });
    await coordinateSessionClaim(mockClient, { sessionId: 'sess-1', adminId: 'admin-1' });
    await coordinateSessionJoin(mockClient, { sessionId: 'sess-1', participantRef: 'user-1' });
    await coordinateSessionStart(mockClient, { sessionId: 'sess-1', adminId: 'admin-1' });
    await coordinateMessageExchange(mockClient, { sessionId: 'sess-1', aiModel: 'gpt-4o' });
    await coordinateSessionEnd(mockClient, { sessionId: 'sess-1', adminId: 'admin-1' });

    const ctx = buildIammaiContext();
    const report = assessConformance('bnk:session:sess-1', ctx);
    expect(report.overall).toBe('CONFORMANT');
    expect(report.fail_count).toBe(0);
  });

  it('non-IAMMAI sessions are grandfathered — evaluators pass with iammaiTracked=false', () => {
    const evaluators = [
      new I11PhaseIntegrity(),
      new I13ResolutionLegality(),
      new I14LineagePreservation(),
      new I15GovernanceAttribution(),
    ];

    for (const evaluator of evaluators) {
      const result = evaluator.evaluate({
        session: { iammaiTracked: false } as any,
        ledgerEntries: [],
        presenceRecords: [],
        adminActions: [],
        coAgencyActions: [],
      });
      expect(result.result).toBe('PASS');
      expect(result.details).toContain('Non-IAMMAI');
    }
  });

  it('contribution roles tracked correctly across lifecycle', async () => {
    await coordinateSessionCreate(mockClient, { sessionId: 'sess-1', adminId: 'admin-1' });
    await coordinateSessionClaim(mockClient, { sessionId: 'sess-1', adminId: 'admin-1' });
    await coordinateSessionJoin(mockClient, { sessionId: 'sess-1', participantRef: 'user-1' });
    await coordinateSessionStart(mockClient, { sessionId: 'sess-1', adminId: 'admin-1' });
    await coordinateMessageExchange(mockClient, { sessionId: 'sess-1', aiModel: 'gpt-4o' });

    const contributions = insertedRecords.contributionRecords;
    const adminContributions = contributions.filter(c => c.actor_ref === 'bnk:admin:admin-1');
    const aiContributions = contributions.filter(c => c.actor_ref === 'bnk:agent:gpt-4o');

    // Admin should have ORIGIN, ELICITATION, AUTHORIZATION
    const adminRoles = adminContributions.map(c => c.role);
    expect(adminRoles).toContain('ORIGIN');
    expect(adminRoles).toContain('ELICITATION');
    expect(adminRoles).toContain('AUTHORIZATION');

    // AI should have FORMALIZATION, RENDERING
    const aiRoles = aiContributions.map(c => c.role);
    expect(aiRoles).toContain('FORMALIZATION');
    expect(aiRoles).toContain('RENDERING');
  });

  it('validation artifacts precede governance actions for each phase', async () => {
    await coordinateSessionCreate(mockClient, { sessionId: 'sess-1', adminId: 'admin-1' });

    // For the 2 phases (signal, acceptance), we should have 2 validation artifacts
    expect(insertedRecords.validationArtifacts).toHaveLength(2);
    expect(insertedRecords.validationArtifacts.every(v => v.outcome === 'pass')).toBe(true);
  });

  it('witness artifacts emitted for all phase transitions', async () => {
    await coordinateSessionCreate(mockClient, { sessionId: 'sess-1', adminId: 'admin-1' });
    await coordinateSessionClaim(mockClient, { sessionId: 'sess-1', adminId: 'admin-1' });
    await coordinateSessionJoin(mockClient, { sessionId: 'sess-1', participantRef: 'user-1' });
    await coordinateSessionStart(mockClient, { sessionId: 'sess-1', adminId: 'admin-1' });
    await coordinateMessageExchange(mockClient, { sessionId: 'sess-1' });
    await coordinateSessionEnd(mockClient, { sessionId: 'sess-1', adminId: 'admin-1' });

    // 9 phase transitions + 1 resolution witness = 10 witnesses
    expect(insertedRecords.witnessArtifacts.length).toBeGreaterThanOrEqual(10);

    // All witnesses have mandatory non-claims
    for (const w of insertedRecords.witnessArtifacts) {
      expect(w.non_claims.not_authorship).toBe(true);
      expect(w.non_claims.not_semantic_source).toBe(true);
      expect(w.non_claims.not_final_authority).toBe(true);
      expect(w.non_claims.not_automatic_truth_creation).toBe(true);
      expect(w.non_claims.not_governance_force).toBe(true);
    }
  });
});
