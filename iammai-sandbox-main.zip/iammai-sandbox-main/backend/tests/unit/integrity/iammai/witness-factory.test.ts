/**
 * IAMMAI Witness Factory — Unit Tests
 */

import { describe, it, expect, vi, beforeEach } from 'vitest';
import type pg from 'pg';

vi.mock('../../../../src/integrity/iammai/registry.js', () => ({
  insertWitnessArtifact: vi.fn().mockImplementation((_c, r) => Promise.resolve(r)),
}));

import { buildIammaiWitness, emitIammaiWitness } from '../../../../src/integrity/iammai/witness-factory.js';
import { insertWitnessArtifact } from '../../../../src/integrity/iammai/registry.js';

function mockClient(): pg.PoolClient {
  return { query: vi.fn().mockResolvedValue({ rows: [] }) } as unknown as pg.PoolClient;
}

beforeEach(() => vi.clearAllMocks());

describe('buildIammaiWitness', () => {
  it('creates a witness with all 5 mandatory non-claims', () => {
    const witness = buildIammaiWitness({
      witness_type: 'transition',
      target_ref: 'state-1',
      claims: ['phase_transition_observed'],
    });
    expect(witness.witness_id).toBeTruthy();
    expect(witness.witness_type).toBe('transition');
    expect(witness.target_ref).toBe('state-1');
    expect(witness.claims).toEqual(['phase_transition_observed']);
    expect(witness.non_claims).toEqual({
      not_authorship: true,
      not_semantic_source: true,
      not_final_authority: true,
      not_automatic_truth_creation: true,
      not_governance_force: true,
    });
  });

  it('includes actor_ref when provided', () => {
    const witness = buildIammaiWitness({
      witness_type: 'interaction',
      target_ref: 'ref',
      claims: [],
      actor_ref: 'bnk:admin:admin-1',
    });
    expect(witness.actor_ref).toBe('bnk:admin:admin-1');
  });

  it('includes surface_ref when provided', () => {
    const witness = buildIammaiWitness({
      witness_type: 'state_observation',
      target_ref: 'ref',
      claims: [],
      surface_ref: 'bnk:route:sessions',
    });
    expect(witness.surface_ref).toBe('bnk:route:sessions');
  });

  it('creates all 5 witness types', () => {
    const types = ['interaction', 'validation', 'transition', 'publication', 'state_observation'] as const;
    for (const wt of types) {
      const witness = buildIammaiWitness({
        witness_type: wt,
        target_ref: 'ref',
        claims: [],
      });
      expect(witness.witness_type).toBe(wt);
      expect(Object.keys(witness.non_claims)).toHaveLength(5);
    }
  });

  it('preserves multiple claims', () => {
    const claims = ['claim_a', 'claim_b', 'claim_c'];
    const witness = buildIammaiWitness({
      witness_type: 'validation',
      target_ref: 'ref',
      claims,
    });
    expect(witness.claims).toEqual(claims);
  });
});

describe('emitIammaiWitness', () => {
  it('builds and persists a witness artifact', async () => {
    const client = mockClient();
    const witness = await emitIammaiWitness(client, {
      witness_type: 'transition',
      target_ref: 'state-1',
      claims: ['observed'],
    });
    expect(witness.witness_id).toBeTruthy();
    expect(witness.non_claims.not_authorship).toBe(true);
    expect(insertWitnessArtifact).toHaveBeenCalledOnce();
  });
});
