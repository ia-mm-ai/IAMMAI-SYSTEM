/**
 * IAMMAI Validator — Unit Tests
 *
 * Tests pure validation logic using mock pg client.
 */

import { describe, it, expect, vi, beforeEach } from 'vitest';

// Mock the registry and containment-engine modules
vi.mock('../../../../src/integrity/iammai/registry.js', () => ({
  insertValidationArtifact: vi.fn().mockResolvedValue(undefined),
}));

vi.mock('../../../../src/lib/db.js', () => ({
  query: vi.fn(),
}));

import {
  validateTransition,
  validateResolution,
  validateGovernancePreconditions,
} from '../../../../src/integrity/iammai/validator.js';
import type { IammaiStateRecord, IammaiContainmentRecord } from '../../../../src/integrity/iammai/types.js';

const mockClient = { query: vi.fn() } as any;

function makeState(
  state_type: string,
  state_id = 'state-1',
  state_family?: string
): IammaiStateRecord {
  const families: Record<string, string> = {
    signal: 'preparation', acceptance: 'preparation', scope: 'preparation',
    presence: 'preparation', threshold: 'preparation',
    truth: 'standing', continuity: 'standing', decision: 'standing', consequence: 'standing',
  };
  return {
    state_id,
    matter_ref: 'bnk:session:test',
    state_family: (state_family ?? families[state_type] ?? 'preparation') as any,
    state_type: state_type as any,
    recorded_at: new Date(),
    predecessor_ref: null,
    containment_ref: null,
    related_transition_ref: null,
    related_governance_ref: null,
    related_validation_ref: null,
    related_witness_ref: null,
  };
}

function makeHoldRecord(target_state_ref: string): IammaiContainmentRecord {
  return {
    containment_id: 'hold-1',
    matter_ref: 'bnk:session:test',
    target_state_ref,
    action: 'HOLD',
    actor_ref: 'bnk:admin:test',
    reason: 'test hold',
    recorded_at: new Date(),
    governance_action_ref: null,
  };
}

describe('IAMMAI Validator', () => {
  beforeEach(() => {
    vi.clearAllMocks();
  });

  describe('validateTransition', () => {
    it('pass when no current state and target is signal', async () => {
      const result = await validateTransition(mockClient, {
        matter_ref: 'bnk:session:test',
        current_state: null,
        target_phase: 'signal',
        containment_records: [],
      });
      expect(result.outcome).toBe('pass');
    });

    it('fail when no current state and target is not signal', async () => {
      const result = await validateTransition(mockClient, {
        matter_ref: 'bnk:session:test',
        current_state: null,
        target_phase: 'acceptance',
        containment_records: [],
      });
      expect(result.outcome).toBe('fail');
      expect(result.reason_refs).toContain('No current state — only signal is a valid entry point');
    });

    it('pass for valid sequential transition', async () => {
      const result = await validateTransition(mockClient, {
        matter_ref: 'bnk:session:test',
        current_state: makeState('signal'),
        target_phase: 'acceptance',
        containment_records: [],
      });
      expect(result.outcome).toBe('pass');
    });

    it('fail for non-sequential transition', async () => {
      const result = await validateTransition(mockClient, {
        matter_ref: 'bnk:session:test',
        current_state: makeState('signal'),
        target_phase: 'scope',
        containment_records: [],
      });
      expect(result.outcome).toBe('fail');
    });

    it('blocked when current state is held', async () => {
      const state = makeState('signal');
      const result = await validateTransition(mockClient, {
        matter_ref: 'bnk:session:test',
        current_state: state,
        target_phase: 'acceptance',
        containment_records: [makeHoldRecord(state.state_id)],
      });
      expect(result.outcome).toBe('blocked');
    });
  });

  describe('validateResolution', () => {
    it('pass for standing-state, not resolved, not held', async () => {
      const result = await validateResolution(mockClient, {
        matter_ref: 'bnk:session:test',
        current_state: makeState('truth'),
        containment_records: [],
        is_already_resolved: false,
      });
      expect(result.outcome).toBe('pass');
    });

    it('fail when no state records', async () => {
      const result = await validateResolution(mockClient, {
        matter_ref: 'bnk:session:test',
        current_state: null,
        containment_records: [],
        is_already_resolved: false,
      });
      expect(result.outcome).toBe('fail');
    });

    it('fail when not in standing-state regime', async () => {
      const result = await validateResolution(mockClient, {
        matter_ref: 'bnk:session:test',
        current_state: makeState('scope'),
        containment_records: [],
        is_already_resolved: false,
      });
      expect(result.outcome).toBe('fail');
    });

    it('fail when already resolved', async () => {
      const result = await validateResolution(mockClient, {
        matter_ref: 'bnk:session:test',
        current_state: makeState('truth'),
        containment_records: [],
        is_already_resolved: true,
      });
      expect(result.outcome).toBe('fail');
    });

    it('blocked when current state is held', async () => {
      const state = makeState('truth');
      const result = await validateResolution(mockClient, {
        matter_ref: 'bnk:session:test',
        current_state: state,
        containment_records: [makeHoldRecord(state.state_id)],
        is_already_resolved: false,
      });
      expect(result.outcome).toBe('blocked');
    });
  });

  describe('validateGovernancePreconditions', () => {
    it('pass with all fields present', async () => {
      const result = await validateGovernancePreconditions(mockClient, {
        matter_ref: 'bnk:session:test',
        actor_ref: 'bnk:admin:test',
        authority_class: 'OPERATOR',
        legitimacy_basis_ref: 'test_basis',
      });
      expect(result.outcome).toBe('pass');
    });

    it('fail with missing actor_ref', async () => {
      const result = await validateGovernancePreconditions(mockClient, {
        matter_ref: 'bnk:session:test',
        actor_ref: '',
        authority_class: 'OPERATOR',
        legitimacy_basis_ref: 'test_basis',
      });
      expect(result.outcome).toBe('fail');
    });

    it('fail with missing authority_class', async () => {
      const result = await validateGovernancePreconditions(mockClient, {
        matter_ref: 'bnk:session:test',
        actor_ref: 'bnk:admin:test',
        authority_class: '',
        legitimacy_basis_ref: 'test_basis',
      });
      expect(result.outcome).toBe('fail');
    });

    it('fail with missing legitimacy_basis_ref', async () => {
      const result = await validateGovernancePreconditions(mockClient, {
        matter_ref: 'bnk:session:test',
        actor_ref: 'bnk:admin:test',
        authority_class: 'OPERATOR',
        legitimacy_basis_ref: '',
      });
      expect(result.outcome).toBe('fail');
    });
  });
});
