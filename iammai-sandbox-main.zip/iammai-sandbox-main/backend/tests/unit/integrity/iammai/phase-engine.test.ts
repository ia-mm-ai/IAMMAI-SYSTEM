/**
 * IAMMAI Phase Engine — Unit Tests
 */

import { describe, it, expect, vi, beforeEach } from 'vitest';
import type pg from 'pg';

// Mock db and registry
vi.mock('../../../../src/lib/db.js', () => ({
  query: vi.fn().mockResolvedValue({ rows: [] }),
  transaction: vi.fn(),
}));

vi.mock('../../../../src/integrity/iammai/registry.js', () => ({
  insertStateRecord: vi.fn().mockImplementation((_c, r) => Promise.resolve(r)),
  insertTransitionRecord: vi.fn().mockImplementation((_c, r) => Promise.resolve(r)),
  getStateRecordsByMatter: vi.fn().mockResolvedValue([]),
}));

import {
  isValidTransition,
  isPreparation,
  isStanding,
  getCurrentPhase,
  getPhaseHistory,
  advancePhase,
  advancePhases,
} from '../../../../src/integrity/iammai/phase-engine.js';
import { insertStateRecord, insertTransitionRecord, getStateRecordsByMatter } from '../../../../src/integrity/iammai/registry.js';
import type { IammaiPhase } from '../../../../src/integrity/iammai/types.js';

function mockClient(currentState?: { state_id: string; state_type: string }): pg.PoolClient {
  return {
    query: vi.fn().mockResolvedValue({ rows: currentState ? [currentState] : [] }),
  } as unknown as pg.PoolClient;
}

beforeEach(() => vi.clearAllMocks());

// ============================================================================
// isValidTransition
// ============================================================================

describe('isValidTransition', () => {
  it('allows all canonical forward transitions', () => {
    const pairs: [IammaiPhase, IammaiPhase][] = [
      ['signal', 'acceptance'],
      ['acceptance', 'scope'],
      ['scope', 'presence'],
      ['presence', 'threshold'],
      ['threshold', 'truth'],
      ['truth', 'continuity'],
      ['continuity', 'decision'],
      ['decision', 'consequence'],
    ];
    for (const [from, to] of pairs) {
      expect(isValidTransition(from, to)).toBe(true);
    }
  });

  it('rejects backward transitions', () => {
    expect(isValidTransition('truth', 'threshold')).toBe(false);
    expect(isValidTransition('consequence', 'decision')).toBe(false);
  });

  it('rejects skipped transitions', () => {
    expect(isValidTransition('signal', 'scope')).toBe(false);
    expect(isValidTransition('threshold', 'continuity')).toBe(false);
  });

  it('rejects transitions from terminal phase', () => {
    expect(isValidTransition('consequence', 'signal')).toBe(false);
  });
});

// ============================================================================
// isPreparation / isStanding
// ============================================================================

describe('isPreparation', () => {
  it('returns true for preparation phases', () => {
    expect(isPreparation('signal')).toBe(true);
    expect(isPreparation('threshold')).toBe(true);
  });

  it('returns false for standing phases', () => {
    expect(isPreparation('truth')).toBe(false);
    expect(isPreparation('consequence')).toBe(false);
  });
});

describe('isStanding', () => {
  it('returns true for standing phases', () => {
    expect(isStanding('truth')).toBe(true);
    expect(isStanding('decision')).toBe(true);
  });

  it('returns false for preparation phases', () => {
    expect(isStanding('signal')).toBe(false);
    expect(isStanding('scope')).toBe(false);
  });
});

// ============================================================================
// getCurrentPhase
// ============================================================================

describe('getCurrentPhase', () => {
  it('returns null when no records exist', async () => {
    const result = await getCurrentPhase('bnk:session:abc');
    expect(result).toBeNull();
  });

  it('returns the latest phase', async () => {
    vi.mocked(getStateRecordsByMatter).mockResolvedValueOnce([
      { state_type: 'signal' } as any,
      { state_type: 'acceptance' } as any,
    ]);
    const result = await getCurrentPhase('bnk:session:abc');
    expect(result).toBe('acceptance');
  });
});

// ============================================================================
// advancePhase
// ============================================================================

describe('advancePhase', () => {
  it('creates initial signal state with no predecessor', async () => {
    const client = mockClient(); // no current state
    const { stateRecord, transitionRecord } = await advancePhase(client, 'bnk:session:abc', 'signal');

    expect(stateRecord.state_type).toBe('signal');
    expect(stateRecord.state_family).toBe('preparation');
    expect(stateRecord.predecessor_ref).toBeNull();
    expect(transitionRecord).toBeNull(); // no transition for initial state
    expect(insertStateRecord).toHaveBeenCalledOnce();
  });

  it('rejects non-signal as initial phase', async () => {
    const client = mockClient();
    await expect(advancePhase(client, 'bnk:session:abc', 'acceptance'))
      .rejects.toThrow('signal is the only valid entry point');
  });

  it('advances from signal to acceptance with transition record', async () => {
    const client = mockClient({ state_id: 'prev-state', state_type: 'signal' });
    const { stateRecord, transitionRecord } = await advancePhase(client, 'ref', 'acceptance');

    expect(stateRecord.state_type).toBe('acceptance');
    expect(stateRecord.predecessor_ref).toBe('prev-state');
    expect(transitionRecord).not.toBeNull();
    expect(transitionRecord!.transition_type).toBe('preparation_progression');
    expect(transitionRecord!.source_ref).toBe('prev-state');
    expect(transitionRecord!.target_ref).toBe(stateRecord.state_id);
  });

  it('creates truth_formation transition for threshold→truth', async () => {
    const client = mockClient({ state_id: 'threshold-state', state_type: 'threshold' });
    const { transitionRecord } = await advancePhase(client, 'ref', 'truth');
    expect(transitionRecord!.transition_type).toBe('truth_formation');
  });

  it('rejects invalid transition', async () => {
    const client = mockClient({ state_id: 's1', state_type: 'signal' });
    await expect(advancePhase(client, 'ref', 'truth'))
      .rejects.toThrow('Invalid phase transition');
  });

  it('rejects backward transition', async () => {
    const client = mockClient({ state_id: 's1', state_type: 'truth' });
    await expect(advancePhase(client, 'ref', 'threshold'))
      .rejects.toThrow('Invalid phase transition');
  });

  it('passes governance action ID to state record', async () => {
    const client = mockClient();
    const { stateRecord } = await advancePhase(client, 'ref', 'signal', 'gov-123');
    expect(stateRecord.related_governance_ref).toBe('gov-123');
  });
});

// ============================================================================
// advancePhases
// ============================================================================

describe('advancePhases', () => {
  it('advances through multiple phases', async () => {
    // First call: no current state (signal); second call: signal exists
    const client = {
      query: vi.fn()
        .mockResolvedValueOnce({ rows: [] }) // no state for signal
        .mockResolvedValueOnce({ rows: [{ state_id: 'auto-id', state_type: 'signal' }] }), // signal exists for acceptance
    } as unknown as pg.PoolClient;

    const { stateRecords, transitionRecords } = await advancePhases(
      client, 'ref', ['signal', 'acceptance']
    );

    expect(stateRecords).toHaveLength(2);
    expect(stateRecords[0].state_type).toBe('signal');
    expect(stateRecords[1].state_type).toBe('acceptance');
    expect(transitionRecords).toHaveLength(1); // signal has no transition
  });
});
