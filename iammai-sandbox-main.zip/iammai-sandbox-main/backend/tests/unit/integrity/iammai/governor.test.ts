/**
 * IAMMAI Governor — Unit Tests
 */

import { describe, it, expect, vi, beforeEach } from 'vitest';
import type pg from 'pg';

// Mock db and registry
vi.mock('../../../../src/lib/db.js', () => ({
  query: vi.fn().mockResolvedValue({ rows: [] }),
  transaction: vi.fn(),
}));

vi.mock('../../../../src/integrity/iammai/registry.js', () => ({
  insertGovernanceAction: vi.fn().mockImplementation((_c, r) => Promise.resolve(r)),
  getGovernanceActionsByMatter: vi.fn().mockResolvedValue([]),
}));

import {
  recordGovernanceAction,
  getActionsByMatter,
  getActionsByActor,
  isAuthorized,
} from '../../../../src/integrity/iammai/governor.js';
import { insertGovernanceAction, getGovernanceActionsByMatter } from '../../../../src/integrity/iammai/registry.js';
import { query } from '../../../../src/lib/db.js';
import type { IammaiGovernanceAction } from '../../../../src/integrity/iammai/types.js';

function mockClient(): pg.PoolClient {
  return { query: vi.fn().mockResolvedValue({ rows: [] }) } as unknown as pg.PoolClient;
}

beforeEach(() => vi.clearAllMocks());

describe('recordGovernanceAction', () => {
  it('creates and persists a governance action', async () => {
    const client = mockClient();
    const result = await recordGovernanceAction(client, {
      action_type: 'authorize',
      authority_class: 'OPERATOR',
      actor_ref: 'bnk:admin:admin-1',
      legitimacy_basis_ref: 'bnk:protocol:session-creation',
      matter_ref: 'bnk:session:abc',
    });
    expect(result.governance_action_id).toBeTruthy();
    expect(result.action_type).toBe('authorize');
    expect(result.authority_class).toBe('OPERATOR');
    expect(result.actor_ref).toBe('bnk:admin:admin-1');
    expect(result.legitimacy_basis_ref).toBe('bnk:protocol:session-creation');
    expect(result.matter_ref).toBe('bnk:session:abc');
    expect(insertGovernanceAction).toHaveBeenCalledOnce();
  });

  it('records all 7 action types', async () => {
    const client = mockClient();
    const types = ['authorize', 'deny', 'hold', 'release', 'finalize', 'invalidate', 'evolve'] as const;
    for (const actionType of types) {
      const result = await recordGovernanceAction(client, {
        action_type: actionType,
        authority_class: 'SYSTEM',
        actor_ref: 'actor',
        legitimacy_basis_ref: 'basis',
        matter_ref: 'matter',
      });
      expect(result.action_type).toBe(actionType);
    }
  });

  it('records delegated actions', async () => {
    const client = mockClient();
    const result = await recordGovernanceAction(client, {
      action_type: 'authorize',
      authority_class: 'DELEGATED',
      actor_ref: 'delegate',
      legitimacy_basis_ref: 'delegation-chain',
      matter_ref: 'matter',
      delegated_from_ref: 'original-action-id',
    });
    expect(result.delegated_from_ref).toBe('original-action-id');
  });
});

describe('getActionsByMatter', () => {
  it('delegates to registry', async () => {
    await getActionsByMatter('bnk:session:abc');
    expect(getGovernanceActionsByMatter).toHaveBeenCalledWith('bnk:session:abc');
  });
});

describe('getActionsByActor', () => {
  it('queries by actor and matter', async () => {
    await getActionsByActor('bnk:admin:admin-1', 'bnk:session:abc');
    expect(query).toHaveBeenCalledWith(
      expect.stringContaining('actor_ref = $1 AND matter_ref = $2'),
      ['bnk:admin:admin-1', 'bnk:session:abc']
    );
  });
});

describe('isAuthorized', () => {
  const action: IammaiGovernanceAction = {
    governance_action_id: 'gov-1',
    action_type: 'authorize',
    authority_class: 'OPERATOR',
    actor_ref: 'actor',
    legitimacy_basis_ref: 'basis',
    matter_ref: 'bnk:session:abc',
    acted_at: new Date(),
    delegated_from_ref: null,
    target_state_ref: null,
    target_transition_ref: null,
    contribution_role_map_ref: null,
  };

  it('returns true when matter matches', () => {
    expect(isAuthorized(action, 'bnk:session:abc')).toBe(true);
  });

  it('returns false for cross-matter authorization', () => {
    expect(isAuthorized(action, 'bnk:session:different')).toBe(false);
  });
});
