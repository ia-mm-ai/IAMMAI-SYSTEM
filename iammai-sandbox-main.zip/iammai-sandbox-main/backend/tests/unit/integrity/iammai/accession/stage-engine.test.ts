/**
 * Accession Stage Engine — Unit Tests
 */

import { describe, it, expect } from 'vitest';
import {
  isValidAccessionTransition,
  getNextStage,
  getTransitionType,
  isPreAdmission,
  isPostAdmission,
} from '../../../../../src/integrity/iammai/accession/stage-engine.js';

describe('isValidAccessionTransition', () => {
  it('allows forward progression', () => {
    expect(isValidAccessionTransition('contact', 'eligibility')).toBe(true);
    expect(isValidAccessionTransition('eligibility', 'shadow')).toBe(true);
    expect(isValidAccessionTransition('shadow', 'proof')).toBe(true);
    expect(isValidAccessionTransition('proof', 'admission')).toBe(true);
    expect(isValidAccessionTransition('admission', 'bound_vessel')).toBe(true);
  });
  it('allows revocation from any post-contact stage', () => {
    expect(isValidAccessionTransition('contact', 'revoked')).toBe(true);
    expect(isValidAccessionTransition('eligibility', 'revoked')).toBe(true);
    expect(isValidAccessionTransition('shadow', 'revoked')).toBe(true);
    expect(isValidAccessionTransition('proof', 'revoked')).toBe(true);
    expect(isValidAccessionTransition('admission', 'revoked')).toBe(true);
    expect(isValidAccessionTransition('bound_vessel', 'revoked')).toBe(true);
  });
  it('rejects backward transitions', () => {
    expect(isValidAccessionTransition('eligibility', 'contact')).toBe(false);
    expect(isValidAccessionTransition('shadow', 'eligibility')).toBe(false);
    expect(isValidAccessionTransition('admission', 'proof')).toBe(false);
  });
  it('rejects skipping stages', () => {
    expect(isValidAccessionTransition('contact', 'shadow')).toBe(false);
    expect(isValidAccessionTransition('eligibility', 'proof')).toBe(false);
    expect(isValidAccessionTransition('contact', 'admission')).toBe(false);
  });
  it('rejects transitions from revoked', () => {
    expect(isValidAccessionTransition('revoked', 'contact')).toBe(false);
    expect(isValidAccessionTransition('revoked', 'eligibility')).toBe(false);
  });
});

describe('getNextStage', () => {
  it('returns the next forward stage', () => {
    expect(getNextStage('contact')).toBe('eligibility');
    expect(getNextStage('eligibility')).toBe('shadow');
    expect(getNextStage('shadow')).toBe('proof');
    expect(getNextStage('proof')).toBe('admission');
    expect(getNextStage('admission')).toBe('bound_vessel');
  });
  it('returns null for bound_vessel (terminal)', () => {
    expect(getNextStage('bound_vessel')).toBeNull();
  });
  it('returns null for revoked (terminal)', () => {
    expect(getNextStage('revoked')).toBeNull();
  });
});

describe('getTransitionType', () => {
  it('returns typed transition names', () => {
    expect(getTransitionType('contact', 'eligibility')).toBe('contact_to_eligibility');
    expect(getTransitionType('eligibility', 'shadow')).toBe('eligibility_to_shadow');
    expect(getTransitionType('shadow', 'proof')).toBe('shadow_to_proof');
    expect(getTransitionType('proof', 'admission')).toBe('proof_to_admission');
    expect(getTransitionType('admission', 'bound_vessel')).toBe('admission_to_bound_vessel');
  });
  it('returns to_revoked for any revocation', () => {
    expect(getTransitionType('contact', 'revoked')).toBe('to_revoked');
    expect(getTransitionType('bound_vessel', 'revoked')).toBe('to_revoked');
  });
});

describe('isPreAdmission / isPostAdmission', () => {
  it('identifies pre-admission stages', () => {
    expect(isPreAdmission('contact')).toBe(true);
    expect(isPreAdmission('eligibility')).toBe(true);
    expect(isPreAdmission('shadow')).toBe(true);
    expect(isPreAdmission('proof')).toBe(true);
    expect(isPreAdmission('admission')).toBe(true);
  });
  it('identifies post-admission stages', () => {
    expect(isPostAdmission('bound_vessel')).toBe(true);
    expect(isPostAdmission('revoked')).toBe(true);
  });
  it('pre and post are mutually exclusive', () => {
    expect(isPreAdmission('bound_vessel')).toBe(false);
    expect(isPostAdmission('contact')).toBe(false);
  });
});
