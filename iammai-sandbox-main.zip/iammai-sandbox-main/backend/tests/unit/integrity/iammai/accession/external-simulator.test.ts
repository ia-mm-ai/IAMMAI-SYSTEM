/**
 * External Simulator — Unit Tests
 */

import { describe, it, expect } from 'vitest';
import {
  generateCleanSession,
  generateMessySession,
  exportSlice,
} from '../../../../../src/integrity/iammai/accession/external-simulator.js';

describe('generateCleanSession', () => {
  it('returns a well-formed Momacka session', () => {
    const session = generateCleanSession();
    expect(session.platform_name).toBe('Momacka');
    expect(session.participants.length).toBe(2);
    expect(session.duration_seconds).toBe(1800);
    expect(session.topic).toBe('Dogovor za momacku');
    expect(session.outcome).toBe('resolved');
    expect(session.messages.length).toBeGreaterThan(0);
    expect(session.ended_at).not.toBe(session.started_at);
  });
});

describe('generateMessySession', () => {
  it('returns a degenerate Seen session (left on seen)', () => {
    const session = generateMessySession();
    expect(session.platform_name).toBe('Seen');
    expect(session.participants.length).toBe(2);
    expect(session.duration_seconds).toBe(0);
    expect(session.topic).toBe('Momacka v2: sad stvarno');
    expect(session.outcome).toBeNull();
    expect(session.messages.length).toBe(2);
    expect(session.messages.every(m => m.sender_id === 'u1')).toBe(true);
    expect(session.ended_at).toBe(session.started_at);
  });
});

describe('exportSlice', () => {
  it('exports a summary slice from a clean session', () => {
    const session = generateCleanSession();
    const slice = exportSlice(session);
    expect(slice.platform_name).toBe('Momacka');
    expect(slice.participant_count).toBe(2);
    expect(slice.duration_seconds).toBe(1800);
    expect(slice.topic).toBe('Dogovor za momacku');
    expect(slice.outcome).toBe('resolved');
    expect(slice.has_explicit_end).toBe(true);
    expect(slice.source_session_ref).toBe(session.session_id);
  });
  it('exports a summary slice from a messy session — no messages cross boundary', () => {
    const session = generateMessySession();
    const slice = exportSlice(session);
    expect(slice.platform_name).toBe('Seen');
    expect(slice.participant_count).toBe(2);
    expect(slice.duration_seconds).toBe(0);
    expect(slice.topic).toBe('Momacka v2: sad stvarno');
    expect(slice.outcome).toBeNull();
    expect(slice.has_explicit_end).toBe(false);
  });
  it('never includes raw messages in the slice', () => {
    const session = generateCleanSession();
    const slice = exportSlice(session);
    const sliceStr = JSON.stringify(slice);
    for (const msg of session.messages) {
      expect(sliceStr).not.toContain(msg.content);
    }
  });
});
