/**
 * Accession Validator — Unit Tests
 */

import { describe, it, expect } from 'vitest';
import {
  checkEligibility,
  buildShadow,
  runProofTests,
  makeAdmissionDecision,
} from '../../../../../src/integrity/iammai/accession/accession-validator.js';
import type { SessionSummarySlice, ExportedSlice } from '../../../../../src/integrity/iammai/accession/types.js';

const cleanSliceData: SessionSummarySlice = {
  slice_id: 'clean-slice',
  source_session_ref: 'clean-session',
  platform_name: 'Momacka',
  participant_count: 2,
  duration_seconds: 1800,
  topic: 'Dogovor za momacku',
  outcome: 'resolved',
  has_explicit_end: true,
};

const messySliceData: SessionSummarySlice = {
  slice_id: 'messy-slice',
  source_session_ref: 'messy-session',
  platform_name: 'Seen',
  participant_count: 2,
  duration_seconds: 0,
  topic: 'Momacka v2: sad stvarno',
  outcome: null,
  has_explicit_end: false,
};

const makeExportedSlice = (data: SessionSummarySlice): ExportedSlice => ({
  slice_id: data.slice_id,
  source_id: 'source-1',
  slice_name: data.platform_name,
  slice_data: data as unknown as Record<string, unknown>,
  data_role: 'exported',
  created_at: new Date(),
});

describe('checkEligibility', () => {
  it('passes for clean slice', () => {
    const result = checkEligibility(makeExportedSlice(cleanSliceData));
    expect(result.passed).toBe(true);
    expect(result.conditions.every(c => c.passed)).toBe(true);
  });
  it('passes for messy slice (eligibility only checks existence, not quality)', () => {
    const result = checkEligibility(makeExportedSlice(messySliceData));
    expect(result.passed).toBe(true);
  });
});

describe('buildShadow', () => {
  it('returns no discrepancies for clean slice', () => {
    const shadow = buildShadow(cleanSliceData);
    expect(shadow.discrepancies).toHaveLength(0);
  });
  it('identifies discrepancies for messy slice', () => {
    const shadow = buildShadow(messySliceData);
    expect(shadow.discrepancies.length).toBeGreaterThan(0);
    const types = shadow.discrepancies.map(d => d['type']);
    expect(types).toContain('missing_value');
    expect(types).toContain('out_of_range');
  });
});

describe('runProofTests', () => {
  it('all pass for clean slice', () => {
    const shadow = buildShadow(cleanSliceData);
    const proofs = runProofTests(cleanSliceData, shadow);
    expect(proofs.every(p => p.result === 'pass')).toBe(true);
    expect(proofs.length).toBe(4);
  });
  it('some fail for messy slice', () => {
    const shadow = buildShadow(messySliceData);
    const proofs = runProofTests(messySliceData, shadow);
    expect(proofs.some(p => p.result === 'fail')).toBe(true);
  });
  it('checks required_fields_present', () => {
    const shadow = buildShadow(messySliceData);
    const proofs = runProofTests(messySliceData, shadow);
    const reqFields = proofs.find(p => p.test_name === 'required_fields_present');
    expect(reqFields).toBeDefined();
    expect(reqFields!.result).toBe('fail');
  });
  it('checks duration_plausible', () => {
    const shadow = buildShadow(messySliceData);
    const proofs = runProofTests(messySliceData, shadow);
    const dur = proofs.find(p => p.test_name === 'duration_plausible');
    expect(dur).toBeDefined();
    expect(dur!.result).toBe('fail');
  });
  it('checks explicit_end', () => {
    const shadow = buildShadow(messySliceData);
    const proofs = runProofTests(messySliceData, shadow);
    const end = proofs.find(p => p.test_name === 'explicit_end');
    expect(end).toBeDefined();
    expect(end!.result).toBe('fail');
  });
  it('checks outcome_valid', () => {
    const shadow = buildShadow(messySliceData);
    const proofs = runProofTests(messySliceData, shadow);
    const out = proofs.find(p => p.test_name === 'outcome_valid');
    expect(out).toBeDefined();
    expect(out!.result).toBe('fail');
  });
});

describe('makeAdmissionDecision', () => {
  it('admits when all proofs pass', () => {
    const proofs = [
      { test_name: 'a', result: 'pass' as const, details: {} },
      { test_name: 'b', result: 'pass' as const, details: {} },
    ];
    expect(makeAdmissionDecision(proofs)).toBe('admitted');
  });
  it('refuses when any proof fails', () => {
    const proofs = [
      { test_name: 'a', result: 'pass' as const, details: {} },
      { test_name: 'b', result: 'fail' as const, details: {} },
    ];
    expect(makeAdmissionDecision(proofs)).toBe('refused');
  });
  it('defers when any proof is indeterminate and none fail', () => {
    const proofs = [
      { test_name: 'a', result: 'pass' as const, details: {} },
      { test_name: 'b', result: 'indeterminate' as const, details: {} },
    ];
    expect(makeAdmissionDecision(proofs)).toBe('not_yet');
  });
});
