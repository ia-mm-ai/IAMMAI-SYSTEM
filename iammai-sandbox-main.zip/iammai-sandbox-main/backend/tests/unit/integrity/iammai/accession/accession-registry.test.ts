/**
 * Accession Registry — Unit Tests
 *
 * Covers the source-aware context loading added so the admin UI can display
 * the external source payload alongside the exported slice.
 */

import { describe, it, expect, vi, beforeEach } from 'vitest';

vi.mock('../../../../../src/lib/db.js', () => ({
  query: vi.fn(),
  transaction: vi.fn(),
}));

import {
  getExternalSourceBySliceId,
  loadAccessionContext,
} from '../../../../../src/integrity/iammai/accession/accession-registry.js';
import { query } from '../../../../../src/lib/db.js';

const mockedQuery = query as unknown as ReturnType<typeof vi.fn>;

const SAMPLE_SOURCE = {
  source_id: 'src-1',
  source_name: 'Momacka',
  source_system_ref: 'momacka:session:123',
  source_data: { platform_name: 'momacka', messages: [{ sender_id: 'u1', content: 'hi' }] },
  actor_ref: 'actor:admin',
  created_at: new Date('2026-04-10T00:00:00Z'),
};

const SAMPLE_SLICE = {
  slice_id: 'slice-1',
  source_id: 'src-1',
  slice_name: 'summary',
  slice_data: { topic: 'Q2', participant_count: 4 },
  data_role: 'exported',
  created_at: new Date('2026-04-10T00:00:01Z'),
};

beforeEach(() => {
  vi.clearAllMocks();
});

describe('getExternalSourceBySliceId', () => {
  it('returns the joined source row when the slice exists', async () => {
    mockedQuery.mockResolvedValueOnce({ rows: [SAMPLE_SOURCE] });

    const result = await getExternalSourceBySliceId('slice-1');

    expect(result).toEqual(SAMPLE_SOURCE);
    expect(mockedQuery).toHaveBeenCalledTimes(1);
    const [sql, params] = mockedQuery.mock.calls[0]!;
    expect(sql).toContain('iammai_external_sources');
    expect(sql).toContain('iammai_exported_slices');
    expect(sql).toContain('es.slice_id = $1');
    expect(params).toEqual(['slice-1']);
  });

  it('returns null when no source is found for the slice id', async () => {
    mockedQuery.mockResolvedValueOnce({ rows: [] });

    const result = await getExternalSourceBySliceId('missing');

    expect(result).toBeNull();
  });
});

describe('loadAccessionContext', () => {
  it('includes the source alongside slice/states/shadows/proofs', async () => {
    // Order matches the Promise.all sequence:
    // slice, source, states, transitions, shadows, proofs
    mockedQuery
      .mockResolvedValueOnce({ rows: [SAMPLE_SLICE] })   // getExportedSlice
      .mockResolvedValueOnce({ rows: [SAMPLE_SOURCE] })  // getExternalSourceBySliceId
      .mockResolvedValueOnce({ rows: [] })               // states
      .mockResolvedValueOnce({ rows: [] })               // transitions
      .mockResolvedValueOnce({ rows: [] })               // shadows
      .mockResolvedValueOnce({ rows: [] });              // proofs

    const ctx = await loadAccessionContext('slice-1');

    expect(ctx.slice).toEqual(SAMPLE_SLICE);
    expect(ctx.source).toEqual(SAMPLE_SOURCE);
    expect(ctx.states).toEqual([]);
    expect(ctx.shadows).toEqual([]);
    expect(ctx.proofs).toEqual([]);
    expect(mockedQuery).toHaveBeenCalledTimes(6);
  });

  it('returns null slice and null source when nothing is found', async () => {
    mockedQuery
      .mockResolvedValueOnce({ rows: [] })
      .mockResolvedValueOnce({ rows: [] })
      .mockResolvedValueOnce({ rows: [] })
      .mockResolvedValueOnce({ rows: [] })
      .mockResolvedValueOnce({ rows: [] })
      .mockResolvedValueOnce({ rows: [] });

    const ctx = await loadAccessionContext('missing');

    expect(ctx.slice).toBeNull();
    expect(ctx.source).toBeNull();
  });
});
