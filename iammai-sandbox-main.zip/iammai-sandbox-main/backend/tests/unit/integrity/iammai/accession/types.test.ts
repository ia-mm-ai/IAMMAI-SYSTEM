/**
 * Accession Types — Unit Tests
 */

import { describe, it, expect } from 'vitest';
import {
  ACCESSION_STAGE_ORDINAL,
  ACCESSION_STAGES_IN_ORDER,
  ACCESSION_STAGE_FAMILY,
  VALID_ACCESSION_TRANSITIONS,
  sliceMatterRef,
} from '../../../../../src/integrity/iammai/accession/types.js';
import type {
  AccessionStage,
  AccessionFamily,
  ContactOutcome,
  AdmissionDecision,
  DataRole,
} from '../../../../../src/integrity/iammai/accession/types.js';

describe('ACCESSION_STAGE_ORDINAL', () => {
  it('assigns ordinals 1-7 with no gaps', () => {
    const ordinals = Object.values(ACCESSION_STAGE_ORDINAL).sort((a, b) => a - b);
    expect(ordinals).toEqual([1, 2, 3, 4, 5, 6, 7]);
  });
  it('has exactly 7 stages', () => {
    expect(Object.keys(ACCESSION_STAGE_ORDINAL)).toHaveLength(7);
  });
  it('assigns correct ordinals', () => {
    expect(ACCESSION_STAGE_ORDINAL.contact).toBe(1);
    expect(ACCESSION_STAGE_ORDINAL.eligibility).toBe(2);
    expect(ACCESSION_STAGE_ORDINAL.shadow).toBe(3);
    expect(ACCESSION_STAGE_ORDINAL.proof).toBe(4);
    expect(ACCESSION_STAGE_ORDINAL.admission).toBe(5);
    expect(ACCESSION_STAGE_ORDINAL.bound_vessel).toBe(6);
    expect(ACCESSION_STAGE_ORDINAL.revoked).toBe(7);
  });
});

describe('ACCESSION_STAGES_IN_ORDER', () => {
  it('lists all 7 stages in canonical order', () => {
    expect(ACCESSION_STAGES_IN_ORDER).toEqual([
      'contact', 'eligibility', 'shadow', 'proof', 'admission', 'bound_vessel', 'revoked',
    ]);
  });
});

describe('ACCESSION_STAGE_FAMILY', () => {
  it('maps contact through admission to pre_admission', () => {
    expect(ACCESSION_STAGE_FAMILY.contact).toBe('pre_admission');
    expect(ACCESSION_STAGE_FAMILY.eligibility).toBe('pre_admission');
    expect(ACCESSION_STAGE_FAMILY.shadow).toBe('pre_admission');
    expect(ACCESSION_STAGE_FAMILY.proof).toBe('pre_admission');
    expect(ACCESSION_STAGE_FAMILY.admission).toBe('pre_admission');
  });
  it('maps bound_vessel and revoked to post_admission', () => {
    expect(ACCESSION_STAGE_FAMILY.bound_vessel).toBe('post_admission');
    expect(ACCESSION_STAGE_FAMILY.revoked).toBe('post_admission');
  });
});

describe('VALID_ACCESSION_TRANSITIONS', () => {
  it('allows forward progression plus revocation from each stage', () => {
    expect(VALID_ACCESSION_TRANSITIONS.contact).toContain('eligibility');
    expect(VALID_ACCESSION_TRANSITIONS.contact).toContain('revoked');
    expect(VALID_ACCESSION_TRANSITIONS.eligibility).toContain('shadow');
    expect(VALID_ACCESSION_TRANSITIONS.shadow).toContain('proof');
    expect(VALID_ACCESSION_TRANSITIONS.proof).toContain('admission');
    expect(VALID_ACCESSION_TRANSITIONS.admission).toContain('bound_vessel');
  });
  it('allows no transitions from revoked', () => {
    expect(VALID_ACCESSION_TRANSITIONS.revoked).toEqual([]);
  });
  it('allows no transitions from bound_vessel except revoked', () => {
    expect(VALID_ACCESSION_TRANSITIONS.bound_vessel).toEqual(['revoked']);
  });
});

describe('sliceMatterRef', () => {
  it('generates matter ref with bnk:accession:slice: prefix', () => {
    expect(sliceMatterRef('abc-123')).toBe('bnk:accession:slice:abc-123');
  });
});
