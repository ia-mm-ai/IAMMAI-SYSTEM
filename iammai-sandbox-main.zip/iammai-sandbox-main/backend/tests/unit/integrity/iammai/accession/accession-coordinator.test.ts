/**
 * Accession Coordinator — Unit Tests
 *
 * Tests the stage advancement orchestration logic without DB.
 * Verifies the coordinator calls the right sequence: Validate -> Witness -> Govern -> Advance.
 */

import { describe, it, expect } from 'vitest';
import {
  determineContactOutcome,
  buildStageOutcome,
} from '../../../../../src/integrity/iammai/accession/accession-coordinator.js';
import type { SessionSummarySlice } from '../../../../../src/integrity/iammai/accession/types.js';

const cleanSliceData: SessionSummarySlice = {
  slice_id: 'clean-slice',
  source_session_ref: 'clean-session',
  platform_name: 'Momacka',
  participant_count: 2,
  duration_seconds: 1800,
  topic: 'Dogovor za momacku',
  outcome: 'resolved',
  has_explicit_end: true,
};

const messySliceData: SessionSummarySlice = {
  slice_id: 'messy-slice',
  source_session_ref: 'messy-session',
  platform_name: 'Seen',
  participant_count: 2,
  duration_seconds: 0,
  topic: 'Momacka v2: sad stvarno',
  outcome: null,
  has_explicit_end: false,
};

describe('determineContactOutcome', () => {
  it('accepts well-formed slices for observation', () => {
    expect(determineContactOutcome(cleanSliceData)).toBe('accepted_for_observation');
  });

  it('accepts degenerate slices for observation (contact does not judge quality)', () => {
    expect(determineContactOutcome(messySliceData)).toBe('accepted_for_observation');
  });
});

describe('buildStageOutcome', () => {
  it('builds contact outcome', () => {
    const outcome = buildStageOutcome('contact', { contact_outcome: 'accepted_for_observation' });
    expect(outcome['contact_outcome']).toBe('accepted_for_observation');
  });

  it('builds eligibility outcome with conditions', () => {
    const outcome = buildStageOutcome('eligibility', {
      passed: true,
      conditions: [{ name: 'test', passed: true }],
    });
    expect(outcome['passed']).toBe(true);
  });

  it('builds admission outcome with decision', () => {
    const outcome = buildStageOutcome('admission', { decision: 'admitted' });
    expect(outcome['decision']).toBe('admitted');
  });
});
