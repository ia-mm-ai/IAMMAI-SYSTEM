/**
 * Containment Engine — Unit Tests
 */

import { describe, it, expect, vi, beforeEach } from 'vitest';

// Mock registry before imports
vi.mock('../../../../src/integrity/iammai/registry.js', () => ({
  getStateRecordsByMatter: vi.fn(),
  getContainmentRecordsByMatter: vi.fn(),
  insertContainmentRecord: vi.fn(),
}));

// Mock governor
vi.mock('../../../../src/integrity/iammai/governor.js', () => ({
  recordGovernanceAction: vi.fn(),
}));

// Mock db
vi.mock('../../../../src/lib/db.js', () => ({
  query: vi.fn(),
}));

import {
  hold,
  release,
  isStateHeld,
  isCurrentStateHeld,
  getHeldStateRefs,
} from '../../../../src/integrity/iammai/containment-engine.js';
import {
  getStateRecordsByMatter,
  getContainmentRecordsByMatter,
} from '../../../../src/integrity/iammai/registry.js';
import { recordGovernanceAction } from '../../../../src/integrity/iammai/governor.js';
import type { IammaiContainmentRecord } from '../../../../src/integrity/iammai/types.js';

const mockGetStates = vi.mocked(getStateRecordsByMatter);
const mockGetContainments = vi.mocked(getContainmentRecordsByMatter);
const mockRecordGov = vi.mocked(recordGovernanceAction);

function makeClient() {
  return {
    query: vi.fn(),
  } as any;
}

beforeEach(() => {
  vi.clearAllMocks();
});

describe('isStateHeld', () => {
  it('returns false when no containment records', () => {
    expect(isStateHeld([], 'state-1')).toBe(false);
  });

  it('returns true when latest action is HOLD', () => {
    const records: IammaiContainmentRecord[] = [
      {
        containment_id: 'c1', matter_ref: 'bnk:session:abc', target_state_ref: 'state-1',
        action: 'HOLD', actor_ref: 'actor-1', reason: 'test',
        recorded_at: new Date('2026-01-01'), governance_action_ref: 'gov-1',
      },
    ];
    expect(isStateHeld(records, 'state-1')).toBe(true);
  });

  it('returns false when latest action is RELEASE', () => {
    const records: IammaiContainmentRecord[] = [
      {
        containment_id: 'c1', matter_ref: 'bnk:session:abc', target_state_ref: 'state-1',
        action: 'HOLD', actor_ref: 'actor-1', reason: 'test',
        recorded_at: new Date('2026-01-01'), governance_action_ref: 'gov-1',
      },
      {
        containment_id: 'c2', matter_ref: 'bnk:session:abc', target_state_ref: 'state-1',
        action: 'RELEASE', actor_ref: 'actor-1', reason: 'done',
        recorded_at: new Date('2026-01-02'), governance_action_ref: 'gov-2',
      },
    ];
    expect(isStateHeld(records, 'state-1')).toBe(false);
  });

  it('ignores containment records for other states', () => {
    const records: IammaiContainmentRecord[] = [
      {
        containment_id: 'c1', matter_ref: 'bnk:session:abc', target_state_ref: 'state-2',
        action: 'HOLD', actor_ref: 'actor-1', reason: 'test',
        recorded_at: new Date('2026-01-01'), governance_action_ref: 'gov-1',
      },
    ];
    expect(isStateHeld(records, 'state-1')).toBe(false);
  });
});

describe('isCurrentStateHeld', () => {
  it('returns false when no states', async () => {
    mockGetStates.mockResolvedValue([]);
    mockGetContainments.mockResolvedValue([]);
    expect(await isCurrentStateHeld('bnk:session:abc')).toBe(false);
  });

  it('returns true when current state is held', async () => {
    mockGetStates.mockResolvedValue([
      {
        state_id: 'state-1', matter_ref: 'bnk:session:abc', state_family: 'standing',
        state_type: 'truth', recorded_at: new Date(), predecessor_ref: null,
        containment_ref: null, related_transition_ref: null, related_governance_ref: null,
        related_validation_ref: null, related_witness_ref: null,
      },
    ]);
    mockGetContainments.mockResolvedValue([
      {
        containment_id: 'c1', matter_ref: 'bnk:session:abc', target_state_ref: 'state-1',
        action: 'HOLD', actor_ref: 'actor-1', reason: 'test',
        recorded_at: new Date(), governance_action_ref: 'gov-1',
      },
    ]);
    expect(await isCurrentStateHeld('bnk:session:abc')).toBe(true);
  });
});

describe('getHeldStateRefs', () => {
  it('returns empty array when no containments', () => {
    expect(getHeldStateRefs([])).toEqual([]);
  });

  it('returns only currently held states', () => {
    const records: IammaiContainmentRecord[] = [
      {
        containment_id: 'c1', matter_ref: 'm1', target_state_ref: 'state-1',
        action: 'HOLD', actor_ref: 'a1', reason: 'r1',
        recorded_at: new Date('2026-01-01'), governance_action_ref: 'g1',
      },
      {
        containment_id: 'c2', matter_ref: 'm1', target_state_ref: 'state-2',
        action: 'HOLD', actor_ref: 'a1', reason: 'r2',
        recorded_at: new Date('2026-01-01'), governance_action_ref: 'g2',
      },
      {
        containment_id: 'c3', matter_ref: 'm1', target_state_ref: 'state-1',
        action: 'RELEASE', actor_ref: 'a1', reason: 'r3',
        recorded_at: new Date('2026-01-02'), governance_action_ref: 'g3',
      },
    ];
    const held = getHeldStateRefs(records);
    expect(held).toEqual(['state-2']);
  });
});

describe('hold', () => {
  it('creates governance action and containment record', async () => {
    const client = makeClient();
    client.query
      .mockResolvedValueOnce({ rows: [{ state_id: 'state-1' }] }) // state exists
      .mockResolvedValueOnce({ rows: [] }); // not already held

    mockRecordGov.mockResolvedValue({
      governance_action_id: 'gov-1', action_type: 'hold', authority_class: 'OPERATOR',
      actor_ref: 'actor-1', legitimacy_basis_ref: 'basis-1', matter_ref: 'bnk:session:abc',
      acted_at: new Date(), delegated_from_ref: null, target_state_ref: 'state-1',
      target_transition_ref: null, contribution_role_map_ref: null,
    });

    const result = await hold(client, {
      matter_ref: 'bnk:session:abc',
      target_state_ref: 'state-1',
      actor_ref: 'actor-1',
      reason: 'compliance review',
      legitimacy_basis_ref: 'basis-1',
      authority_class: 'OPERATOR',
    });

    expect(result.governanceAction.action_type).toBe('hold');
    expect(result.containmentRecord.action).toBe('HOLD');
    expect(result.containmentRecord.target_state_ref).toBe('state-1');
  });

  it('throws if state does not exist', async () => {
    const client = makeClient();
    client.query.mockResolvedValueOnce({ rows: [] });

    await expect(hold(client, {
      matter_ref: 'bnk:session:abc',
      target_state_ref: 'state-999',
      actor_ref: 'actor-1',
      reason: 'test',
      legitimacy_basis_ref: 'basis-1',
      authority_class: 'OPERATOR',
    })).rejects.toThrow('not found');
  });

  it('throws if state is already held', async () => {
    const client = makeClient();
    client.query
      .mockResolvedValueOnce({ rows: [{ state_id: 'state-1' }] })
      .mockResolvedValueOnce({ rows: [{ action: 'HOLD', recorded_at: new Date() }] });

    await expect(hold(client, {
      matter_ref: 'bnk:session:abc',
      target_state_ref: 'state-1',
      actor_ref: 'actor-1',
      reason: 'test',
      legitimacy_basis_ref: 'basis-1',
      authority_class: 'OPERATOR',
    })).rejects.toThrow('already held');
  });
});

describe('release', () => {
  it('creates governance action and containment record', async () => {
    const client = makeClient();
    client.query
      .mockResolvedValueOnce({ rows: [{ state_id: 'state-1' }] }) // state exists
      .mockResolvedValueOnce({ rows: [{ action: 'HOLD', recorded_at: new Date() }] }); // currently held

    mockRecordGov.mockResolvedValue({
      governance_action_id: 'gov-2', action_type: 'release', authority_class: 'OPERATOR',
      actor_ref: 'actor-1', legitimacy_basis_ref: 'basis-1', matter_ref: 'bnk:session:abc',
      acted_at: new Date(), delegated_from_ref: null, target_state_ref: 'state-1',
      target_transition_ref: null, contribution_role_map_ref: null,
    });

    const result = await release(client, {
      matter_ref: 'bnk:session:abc',
      target_state_ref: 'state-1',
      actor_ref: 'actor-1',
      reason: 'review complete',
      legitimacy_basis_ref: 'basis-1',
      authority_class: 'OPERATOR',
    });

    expect(result.governanceAction.action_type).toBe('release');
    expect(result.containmentRecord.action).toBe('RELEASE');
  });

  it('throws if state is not held', async () => {
    const client = makeClient();
    client.query
      .mockResolvedValueOnce({ rows: [{ state_id: 'state-1' }] })
      .mockResolvedValueOnce({ rows: [] }); // not held

    await expect(release(client, {
      matter_ref: 'bnk:session:abc',
      target_state_ref: 'state-1',
      actor_ref: 'actor-1',
      reason: 'test',
      legitimacy_basis_ref: 'basis-1',
      authority_class: 'OPERATOR',
    })).rejects.toThrow('not currently held');
  });

  it('throws if state does not exist', async () => {
    const client = makeClient();
    client.query.mockResolvedValueOnce({ rows: [] });

    await expect(release(client, {
      matter_ref: 'bnk:session:abc',
      target_state_ref: 'state-999',
      actor_ref: 'actor-1',
      reason: 'test',
      legitimacy_basis_ref: 'basis-1',
      authority_class: 'OPERATOR',
    })).rejects.toThrow('not found');
  });
});
