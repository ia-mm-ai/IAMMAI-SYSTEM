/**
 * IAMMAI Types — Unit Tests
 */

import { describe, it, expect } from 'vitest';
import {
  PHASE_ORDINAL,
  PHASE_FAMILY,
  PHASES_IN_ORDER,
  PREPARATION_PHASES,
  STANDING_PHASES,
  PHASE_TRANSITION_TYPE,
  MANDATORY_NON_CLAIMS,
  matterRef,
  actorRef,
  systemActorRef,
  agentActorRef,
} from '../../../../src/integrity/iammai/types.js';
import type {
  IammaiPhase,
  StateFamily,
  ResolutionType,
  TransitionType,
  GovernanceActionType,
  AuthorityClass,
  ContributionRole,
  WitnessType,
  ValidationType,
  ValidationOutcome,
  NonClaims,
} from '../../../../src/integrity/iammai/types.js';

// ============================================================================
// Phase Ordinals
// ============================================================================

describe('PHASE_ORDINAL', () => {
  it('assigns ordinals 1-9 with no gaps', () => {
    const ordinals = Object.values(PHASE_ORDINAL).sort((a, b) => a - b);
    expect(ordinals).toEqual([1, 2, 3, 4, 5, 6, 7, 8, 9]);
  });

  it('has exactly 9 phases', () => {
    expect(Object.keys(PHASE_ORDINAL)).toHaveLength(9);
  });

  it('assigns correct ordinals', () => {
    expect(PHASE_ORDINAL.signal).toBe(1);
    expect(PHASE_ORDINAL.acceptance).toBe(2);
    expect(PHASE_ORDINAL.scope).toBe(3);
    expect(PHASE_ORDINAL.presence).toBe(4);
    expect(PHASE_ORDINAL.threshold).toBe(5);
    expect(PHASE_ORDINAL.truth).toBe(6);
    expect(PHASE_ORDINAL.continuity).toBe(7);
    expect(PHASE_ORDINAL.decision).toBe(8);
    expect(PHASE_ORDINAL.consequence).toBe(9);
  });
});

// ============================================================================
// Phase Families
// ============================================================================

describe('PHASE_FAMILY', () => {
  it('has exactly 9 entries', () => {
    expect(Object.keys(PHASE_FAMILY)).toHaveLength(9);
  });

  it('assigns 5 phases to preparation', () => {
    const prepPhases = Object.entries(PHASE_FAMILY)
      .filter(([, family]) => family === 'preparation')
      .map(([phase]) => phase);
    expect(prepPhases).toHaveLength(5);
    expect(prepPhases).toEqual(['signal', 'acceptance', 'scope', 'presence', 'threshold']);
  });

  it('assigns 4 phases to standing', () => {
    const standingPhases = Object.entries(PHASE_FAMILY)
      .filter(([, family]) => family === 'standing')
      .map(([phase]) => phase);
    expect(standingPhases).toHaveLength(4);
    expect(standingPhases).toEqual(['truth', 'continuity', 'decision', 'consequence']);
  });

  it('preparation phases are ordinals 1-5', () => {
    for (const [phase, family] of Object.entries(PHASE_FAMILY)) {
      if (family === 'preparation') {
        expect(PHASE_ORDINAL[phase as IammaiPhase]).toBeLessThanOrEqual(5);
      }
    }
  });

  it('standing phases are ordinals 6-9', () => {
    for (const [phase, family] of Object.entries(PHASE_FAMILY)) {
      if (family === 'standing') {
        expect(PHASE_ORDINAL[phase as IammaiPhase]).toBeGreaterThanOrEqual(6);
      }
    }
  });
});

// ============================================================================
// Phase Lists
// ============================================================================

describe('PHASES_IN_ORDER', () => {
  it('contains all 9 phases in canonical order', () => {
    expect(PHASES_IN_ORDER).toHaveLength(9);
    for (let i = 0; i < PHASES_IN_ORDER.length; i++) {
      expect(PHASE_ORDINAL[PHASES_IN_ORDER[i]]).toBe(i + 1);
    }
  });
});

describe('PREPARATION_PHASES', () => {
  it('contains exactly 5 preparation phases', () => {
    expect(PREPARATION_PHASES).toHaveLength(5);
    for (const phase of PREPARATION_PHASES) {
      expect(PHASE_FAMILY[phase]).toBe('preparation');
    }
  });
});

describe('STANDING_PHASES', () => {
  it('contains exactly 4 standing phases', () => {
    expect(STANDING_PHASES).toHaveLength(4);
    for (const phase of STANDING_PHASES) {
      expect(PHASE_FAMILY[phase]).toBe('standing');
    }
  });
});

// ============================================================================
// Transition Type Mapping
// ============================================================================

describe('PHASE_TRANSITION_TYPE', () => {
  it('maps all 8 consecutive phase pairs', () => {
    expect(Object.keys(PHASE_TRANSITION_TYPE)).toHaveLength(8);
  });

  it('maps preparation progressions correctly', () => {
    expect(PHASE_TRANSITION_TYPE['signal_to_acceptance']).toBe('preparation_progression');
    expect(PHASE_TRANSITION_TYPE['acceptance_to_scope']).toBe('preparation_progression');
    expect(PHASE_TRANSITION_TYPE['scope_to_presence']).toBe('preparation_progression');
  });

  it('maps threshold eligibility correctly', () => {
    expect(PHASE_TRANSITION_TYPE['presence_to_threshold']).toBe('threshold_eligibility');
  });

  it('maps truth formation correctly — the critical preparation/standing boundary', () => {
    expect(PHASE_TRANSITION_TYPE['threshold_to_truth']).toBe('truth_formation');
  });

  it('maps standing-state transitions correctly', () => {
    expect(PHASE_TRANSITION_TYPE['truth_to_continuity']).toBe('continuity_transition');
    expect(PHASE_TRANSITION_TYPE['continuity_to_decision']).toBe('decision_transition');
    expect(PHASE_TRANSITION_TYPE['decision_to_consequence']).toBe('consequence_transition');
  });
});

// ============================================================================
// Non-Claims
// ============================================================================

describe('MANDATORY_NON_CLAIMS', () => {
  it('has all 5 required non-claims set to true', () => {
    expect(MANDATORY_NON_CLAIMS.not_authorship).toBe(true);
    expect(MANDATORY_NON_CLAIMS.not_semantic_source).toBe(true);
    expect(MANDATORY_NON_CLAIMS.not_final_authority).toBe(true);
    expect(MANDATORY_NON_CLAIMS.not_automatic_truth_creation).toBe(true);
    expect(MANDATORY_NON_CLAIMS.not_governance_force).toBe(true);
  });

  it('has exactly 5 keys', () => {
    expect(Object.keys(MANDATORY_NON_CLAIMS)).toHaveLength(5);
  });
});

// ============================================================================
// Reference Helpers
// ============================================================================

describe('matterRef', () => {
  it('formats session ID as matter reference', () => {
    const id = '550e8400-e29b-41d4-a716-446655440000';
    expect(matterRef(id)).toBe(`bnk:session:${id}`);
  });
});

describe('actorRef', () => {
  it('formats admin ID as actor reference', () => {
    const id = 'admin-123';
    expect(actorRef(id)).toBe('bnk:admin:admin-123');
  });
});

describe('systemActorRef', () => {
  it('formats system component as actor reference', () => {
    expect(systemActorRef('token-service')).toBe('bnk:system:token-service');
  });
});

describe('agentActorRef', () => {
  it('formats agent type as actor reference', () => {
    expect(agentActorRef('ai')).toBe('bnk:agent:ai');
  });
});

// ============================================================================
// Type Safety (compile-time checks — these just confirm types exist)
// ============================================================================

describe('type enumerations', () => {
  it('StateFamily has correct values', () => {
    const families: StateFamily[] = ['preparation', 'standing'];
    expect(families).toHaveLength(2);
  });

  it('ResolutionType has exactly 3 values', () => {
    const types: ResolutionType[] = ['FINALIZE', 'INVALIDATE', 'EVOLVE'];
    expect(types).toHaveLength(3);
  });

  it('TransitionType has 9 values', () => {
    const types: TransitionType[] = [
      'preparation_progression', 'threshold_eligibility', 'truth_formation',
      'continuity_transition', 'decision_transition', 'consequence_transition',
      'containment_apply', 'containment_release', 'resolution_transition',
    ];
    expect(types).toHaveLength(9);
  });

  it('GovernanceActionType has 7 values', () => {
    const types: GovernanceActionType[] = [
      'authorize', 'deny', 'hold', 'release', 'finalize', 'invalidate', 'evolve',
    ];
    expect(types).toHaveLength(7);
  });

  it('AuthorityClass has 3 values', () => {
    const classes: AuthorityClass[] = ['SYSTEM', 'OPERATOR', 'DELEGATED'];
    expect(classes).toHaveLength(3);
  });

  it('ContributionRole has 6 values', () => {
    const roles: ContributionRole[] = [
      'ORIGIN', 'ELICITATION', 'FORMALIZATION', 'AUTHORIZATION', 'RENDERING', 'TRANSMISSION',
    ];
    expect(roles).toHaveLength(6);
  });

  it('WitnessType has 5 values', () => {
    const types: WitnessType[] = [
      'interaction', 'validation', 'transition', 'publication', 'state_observation',
    ];
    expect(types).toHaveLength(5);
  });

  it('ValidationType has 5 values', () => {
    const types: ValidationType[] = [
      'admissibility', 'threshold', 'transition_legality',
      'governance_precondition', 'bounded_consistency',
    ];
    expect(types).toHaveLength(5);
  });

  it('ValidationOutcome has 4 values', () => {
    const outcomes: ValidationOutcome[] = ['pass', 'fail', 'blocked', 'indeterminate'];
    expect(outcomes).toHaveLength(4);
  });
});
