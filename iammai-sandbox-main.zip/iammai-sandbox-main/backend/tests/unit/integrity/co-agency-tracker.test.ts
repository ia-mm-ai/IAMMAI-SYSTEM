/**
 * Unit tests for the co-agency tracker.
 * @see specs/008-governance-protocols/contracts/co-agency-tracker.md
 */

import { describe, it, expect, beforeEach } from 'vitest';
import {
  canPerformAction,
  trackAction,
  getHistory,
  getState,
  clearSession,
} from '../../../src/integrity/co-agency-tracker.js';

const SESSION_ID = 'aaaaaaaa-bbbb-cccc-dddd-eeeeeeeeeeee';
const OTHER_SESSION = 'ffffffff-0000-1111-2222-333333333333';

beforeEach(() => {
  clearSession(SESSION_ID);
  clearSession(OTHER_SESSION);
});

describe('canPerformAction', () => {
  it('returns true for unknown session (no history = no violation)', () => {
    expect(canPerformAction(SESSION_ID, 'HUMAN')).toBe(true);
    expect(canPerformAction(SESSION_ID, 'MACHINE')).toBe(true);
  });

  it('allows first action by HUMAN', () => {
    trackAction(SESSION_ID, 'HUMAN', 'SESSION_END');
    expect(canPerformAction(SESSION_ID, 'HUMAN')).toBe(true);
  });

  it('allows second consecutive action by HUMAN', () => {
    trackAction(SESSION_ID, 'HUMAN', 'SESSION_END');
    trackAction(SESSION_ID, 'HUMAN', 'SESSION_END');
    // consecutiveCount is now 2, so next HUMAN action is blocked
    expect(canPerformAction(SESSION_ID, 'HUMAN')).toBe(false);
  });

  it('blocks third consecutive action by same agent type', () => {
    trackAction(SESSION_ID, 'MACHINE', 'PRESENCE_FINALIZATION');
    trackAction(SESSION_ID, 'MACHINE', 'VERIFICATION_EXECUTION');
    expect(canPerformAction(SESSION_ID, 'MACHINE')).toBe(false);
  });

  it('allows action after agent type switch resets the counter', () => {
    trackAction(SESSION_ID, 'HUMAN', 'SESSION_END');
    trackAction(SESSION_ID, 'HUMAN', 'SESSION_END');
    // HUMAN is at 2, blocked for HUMAN
    expect(canPerformAction(SESSION_ID, 'HUMAN')).toBe(false);
    // But MACHINE is still allowed
    expect(canPerformAction(SESSION_ID, 'MACHINE')).toBe(true);
    // After MACHINE acts, HUMAN counter resets
    trackAction(SESSION_ID, 'MACHINE', 'PRESENCE_FINALIZATION');
    expect(canPerformAction(SESSION_ID, 'HUMAN')).toBe(true);
  });

  it('allows exactly 1 consecutive action (below limit)', () => {
    trackAction(SESSION_ID, 'MACHINE', 'PRESENCE_FINALIZATION');
    expect(canPerformAction(SESSION_ID, 'MACHINE')).toBe(true);
  });
});

describe('trackAction', () => {
  it('creates new state for unknown session', () => {
    trackAction(SESSION_ID, 'HUMAN', 'SESSION_END');
    const state = getState(SESSION_ID);
    expect(state).toBeDefined();
    expect(state!.consecutiveCount).toBe(1);
    expect(state!.lastAgentType).toBe('HUMAN');
  });

  it('increments consecutiveCount when same agent type acts consecutively', () => {
    trackAction(SESSION_ID, 'MACHINE', 'PRESENCE_FINALIZATION');
    trackAction(SESSION_ID, 'MACHINE', 'VERIFICATION_EXECUTION');
    expect(getState(SESSION_ID)!.consecutiveCount).toBe(2);
    expect(getState(SESSION_ID)!.lastAgentType).toBe('MACHINE');
  });

  it('resets consecutiveCount to 1 when agent type switches', () => {
    trackAction(SESSION_ID, 'HUMAN', 'SESSION_END');
    trackAction(SESSION_ID, 'HUMAN', 'SESSION_END');
    expect(getState(SESSION_ID)!.consecutiveCount).toBe(2);
    trackAction(SESSION_ID, 'MACHINE', 'PRESENCE_FINALIZATION');
    expect(getState(SESSION_ID)!.consecutiveCount).toBe(1);
    expect(getState(SESSION_ID)!.lastAgentType).toBe('MACHINE');
  });

  it('appends action to history in chronological order', () => {
    trackAction(SESSION_ID, 'HUMAN', 'SESSION_END');
    trackAction(SESSION_ID, 'MACHINE', 'PRESENCE_FINALIZATION');
    trackAction(SESSION_ID, 'MACHINE', 'VERIFICATION_EXECUTION');

    const history = getHistory(SESSION_ID);
    expect(history).toHaveLength(3);
    expect(history[0].agentType).toBe('HUMAN');
    expect(history[0].actionType).toBe('SESSION_END');
    expect(history[1].agentType).toBe('MACHINE');
    expect(history[1].actionType).toBe('PRESENCE_FINALIZATION');
    expect(history[2].agentType).toBe('MACHINE');
    expect(history[2].actionType).toBe('VERIFICATION_EXECUTION');
  });

  it('includes sessionId and timestamp in recorded actions', () => {
    const before = new Date();
    trackAction(SESSION_ID, 'HUMAN', 'SESSION_END');
    const after = new Date();
    const history = getHistory(SESSION_ID);
    expect(history[0].sessionId).toBe(SESSION_ID);
    expect(history[0].timestamp.getTime()).toBeGreaterThanOrEqual(before.getTime());
    expect(history[0].timestamp.getTime()).toBeLessThanOrEqual(after.getTime());
  });

  it('does not affect other sessions', () => {
    trackAction(SESSION_ID, 'HUMAN', 'SESSION_END');
    trackAction(SESSION_ID, 'HUMAN', 'SESSION_END');
    // OTHER_SESSION is unaffected
    expect(canPerformAction(OTHER_SESSION, 'HUMAN')).toBe(true);
    expect(getHistory(OTHER_SESSION)).toHaveLength(0);
  });
});

describe('getHistory', () => {
  it('returns empty array for unknown session', () => {
    expect(getHistory(SESSION_ID)).toEqual([]);
  });

  it('returns chronological history', () => {
    trackAction(SESSION_ID, 'HUMAN', 'SESSION_END');
    trackAction(SESSION_ID, 'MACHINE', 'PRESENCE_FINALIZATION');

    const history = getHistory(SESSION_ID);
    expect(history[0].agentType).toBe('HUMAN');
    expect(history[1].agentType).toBe('MACHINE');
    expect(history[0].timestamp <= history[1].timestamp).toBe(true);
  });
});

describe('getState', () => {
  it('returns undefined for unknown session', () => {
    expect(getState(SESSION_ID)).toBeUndefined();
  });

  it('returns current state after tracking', () => {
    trackAction(SESSION_ID, 'MACHINE', 'VERIFICATION_EXECUTION');
    const state = getState(SESSION_ID);
    expect(state).toBeDefined();
    expect(state!.sessionId).toBe(SESSION_ID);
    expect(state!.consecutiveCount).toBe(1);
    expect(state!.lastAgentType).toBe('MACHINE');
    expect(state!.history).toHaveLength(1);
  });
});

describe('clearSession', () => {
  it('removes co-agency tracking for a session', () => {
    trackAction(SESSION_ID, 'HUMAN', 'SESSION_END');
    expect(getState(SESSION_ID)).toBeDefined();
    clearSession(SESSION_ID);
    expect(getState(SESSION_ID)).toBeUndefined();
    expect(getHistory(SESSION_ID)).toEqual([]);
    expect(canPerformAction(SESSION_ID, 'HUMAN')).toBe(true);
  });

  it('is a no-op for unknown session', () => {
    clearSession(SESSION_ID); // Should not throw
    expect(true).toBe(true);
  });
});
