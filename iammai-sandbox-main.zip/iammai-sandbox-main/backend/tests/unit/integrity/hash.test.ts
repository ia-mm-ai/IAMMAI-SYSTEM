import { describe, it, expect } from 'vitest';
import { computeEntryHash, validateHashChain } from '../../../src/integrity/hash.js';
import type { LedgerEntry, MetadataSnapshot } from '../../../src/integrity/types.js';

const SESSION_ID = 'aaaaaaaa-bbbb-cccc-dddd-eeeeeeeeeeee';
const ADMIN_ID = '11111111-2222-3333-4444-555555555555';

function makeSnapshot(overrides: Partial<MetadataSnapshot> = {}): MetadataSnapshot {
  return {
    session_id: SESSION_ID,
    session_name: 'Test Session',
    state: 'CREATED',
    framework_status: 'OPEN',
    admin_id: ADMIN_ID,
    token_count: 0,
    user_count: 0,
    created_at: '2026-02-14T10:00:00.000Z',
    started_at: null,
    ended_at: null,
    context_descriptor: { topic: 'Test topic' },
    environmental_constraints: { max_participants: 10 },
    ...overrides,
  };
}

function makeEntry(overrides: Partial<LedgerEntry> & { sequenceNumber: number; entryHash: string }): LedgerEntry {
  return {
    id: 'entry-id',
    sessionId: SESSION_ID,
    eventType: 'SESSION_CREATED',
    timestamp: new Date('2026-02-14T10:00:00.000Z'),
    fromState: null,
    toState: 'CREATED',
    metadataSnapshot: makeSnapshot(),
    previousHash: null,
    ...overrides,
  };
}

describe('computeEntryHash', () => {
  it('returns a 64-char lowercase hex string', () => {
    const hash = computeEntryHash(
      null, 1, SESSION_ID, 'SESSION_CREATED',
      '2026-02-14T10:00:00.000Z', makeSnapshot()
    );
    expect(hash).toMatch(/^[a-f0-9]{64}$/);
  });

  it('is deterministic — same inputs produce same hash', () => {
    const snapshot = makeSnapshot();
    const hash1 = computeEntryHash(null, 1, SESSION_ID, 'SESSION_CREATED', '2026-02-14T10:00:00.000Z', snapshot);
    const hash2 = computeEntryHash(null, 1, SESSION_ID, 'SESSION_CREATED', '2026-02-14T10:00:00.000Z', snapshot);
    expect(hash1).toBe(hash2);
  });

  it('produces different hashes for different inputs', () => {
    const snapshot = makeSnapshot();
    const hash1 = computeEntryHash(null, 1, SESSION_ID, 'SESSION_CREATED', '2026-02-14T10:00:00.000Z', snapshot);
    const hash2 = computeEntryHash(null, 2, SESSION_ID, 'SESSION_CREATED', '2026-02-14T10:00:00.000Z', snapshot);
    expect(hash1).not.toBe(hash2);
  });

  it('incorporates previousHash into the result', () => {
    const snapshot = makeSnapshot();
    const genesis = computeEntryHash(null, 1, SESSION_ID, 'SESSION_CREATED', '2026-02-14T10:00:00.000Z', snapshot);
    const chained = computeEntryHash(genesis, 2, SESSION_ID, 'SESSION_ACTIVATED', '2026-02-14T10:01:00.000Z', snapshot);
    const unchained = computeEntryHash(null, 2, SESSION_ID, 'SESSION_ACTIVATED', '2026-02-14T10:01:00.000Z', snapshot);
    expect(chained).not.toBe(unchained);
  });
});

describe('validateHashChain', () => {
  it('returns valid for empty chain', () => {
    const result = validateHashChain([]);
    expect(result.valid).toBe(true);
    expect(result.totalEntries).toBe(0);
    expect(result.errors).toHaveLength(0);
  });

  it('validates a single genesis entry', () => {
    const snapshot = makeSnapshot();
    const hash = computeEntryHash(null, 1, SESSION_ID, 'SESSION_CREATED', '2026-02-14T10:00:00.000Z', snapshot);

    const entry = makeEntry({
      sequenceNumber: 1,
      previousHash: null,
      entryHash: hash,
    });

    const result = validateHashChain([entry]);
    expect(result.valid).toBe(true);
    expect(result.totalEntries).toBe(1);
    expect(result.validatedEntries).toBe(1);
  });

  it('validates a chain of multiple entries', () => {
    const snapshot1 = makeSnapshot();
    const hash1 = computeEntryHash(null, 1, SESSION_ID, 'SESSION_CREATED', '2026-02-14T10:00:00.000Z', snapshot1);

    const snapshot2 = makeSnapshot({ state: 'ACTIVE', started_at: '2026-02-14T10:01:00.000Z' });
    const hash2 = computeEntryHash(hash1, 2, SESSION_ID, 'SESSION_ACTIVATED', '2026-02-14T10:01:00.000Z', snapshot2);

    const snapshot3 = makeSnapshot({ state: 'ENDED', started_at: '2026-02-14T10:01:00.000Z', ended_at: '2026-02-14T10:30:00.000Z', framework_status: 'CLOSED' });
    const hash3 = computeEntryHash(hash2, 3, SESSION_ID, 'SESSION_CLOSED', '2026-02-14T10:30:00.000Z', snapshot3);

    const entries: LedgerEntry[] = [
      makeEntry({ sequenceNumber: 1, previousHash: null, entryHash: hash1 }),
      makeEntry({ sequenceNumber: 2, previousHash: hash1, entryHash: hash2, eventType: 'SESSION_ACTIVATED', timestamp: new Date('2026-02-14T10:01:00.000Z'), metadataSnapshot: snapshot2 }),
      makeEntry({ sequenceNumber: 3, previousHash: hash2, entryHash: hash3, eventType: 'SESSION_CLOSED', timestamp: new Date('2026-02-14T10:30:00.000Z'), metadataSnapshot: snapshot3 }),
    ];

    const result = validateHashChain(entries);
    expect(result.valid).toBe(true);
    expect(result.totalEntries).toBe(3);
  });

  it('detects tampered entry hash', () => {
    const snapshot = makeSnapshot();
    const correctHash = computeEntryHash(null, 1, SESSION_ID, 'SESSION_CREATED', '2026-02-14T10:00:00.000Z', snapshot);

    const entry = makeEntry({
      sequenceNumber: 1,
      previousHash: null,
      entryHash: 'tampered_hash_that_does_not_match_at_all_1234567890abcdef12345678',
    });

    const result = validateHashChain([entry]);
    expect(result.valid).toBe(false);
    expect(result.firstBrokenEntry).toBe(1);
    expect(result.errors).toHaveLength(1);
    expect(result.errors[0].expectedHash).toBe(correctHash);
  });

  it('detects broken chain link (wrong previousHash)', () => {
    const snapshot1 = makeSnapshot();
    const hash1 = computeEntryHash(null, 1, SESSION_ID, 'SESSION_CREATED', '2026-02-14T10:00:00.000Z', snapshot1);

    const snapshot2 = makeSnapshot({ state: 'ACTIVE', started_at: '2026-02-14T10:01:00.000Z' });
    const wrongPrev = 'aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa';
    const hash2WithWrongPrev = computeEntryHash(wrongPrev, 2, SESSION_ID, 'SESSION_ACTIVATED', '2026-02-14T10:01:00.000Z', snapshot2);

    const entries: LedgerEntry[] = [
      makeEntry({ sequenceNumber: 1, previousHash: null, entryHash: hash1 }),
      makeEntry({ sequenceNumber: 2, previousHash: wrongPrev, entryHash: hash2WithWrongPrev, eventType: 'SESSION_ACTIVATED', timestamp: new Date('2026-02-14T10:01:00.000Z'), metadataSnapshot: snapshot2 }),
    ];

    const result = validateHashChain(entries);
    expect(result.valid).toBe(false);
    expect(result.firstBrokenEntry).toBe(2);
  });
});
