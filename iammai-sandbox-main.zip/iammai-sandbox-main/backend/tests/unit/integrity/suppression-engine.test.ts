/**
 * Unit tests for the suppression engine.
 * @see specs/007-presence-suppression/contracts/suppression-engine.md
 */

import { describe, it, expect, beforeEach, vi } from 'vitest';
import {
  logAdminAction,
  getAdminActions,
  clearAdminActions,
  checkSignalCoherence,
  evaluateAction,
} from '../../../src/integrity/suppression-engine.js';
import type { AdminAction } from '../../../src/integrity/types.js';
import type { Session } from '../../../src/lib/types.js';

// Mock dependencies for evaluateAction
vi.mock('../../../src/models/session.js', () => ({
  findById: vi.fn(),
}));

vi.mock('../../../src/integrity/ledger.js', () => ({
  getEntriesBySession: vi.fn(),
  appendEntry: vi.fn(),
}));

vi.mock('../../../src/integrity/presence-tracker.js', () => ({
  getPresenceRecords: vi.fn(),
}));

vi.mock('../../../src/integrity/state-observer.js', () => ({
  buildMetadataSnapshot: vi.fn(),
}));

// Spy on verify to inspect which protocols are passed
import * as verificationEngine from '../../../src/integrity/verification-engine.js';
const verifySpy = vi.spyOn(verificationEngine, 'verify');

import * as sessionModel from '../../../src/models/session.js';
import * as ledgerModule from '../../../src/integrity/ledger.js';
import * as presenceTracker from '../../../src/integrity/presence-tracker.js';
import { I05ProtocolSupremacy } from '../../../src/integrity/protocols/i05-protocol-supremacy.js';
import { I08SignalCoherence as I08SignalCoherenceProtocol } from '../../../src/integrity/protocols/i08-signal-coherence.js';

const SESSION_ID = 'aaaaaaaa-bbbb-cccc-dddd-eeeeeeeeeeee';

function makeAdminAction(overrides: Partial<AdminAction> = {}): AdminAction {
  return {
    sessionId: SESSION_ID,
    actionType: 'SESSION_CREATE',
    timestamp: new Date('2026-02-14T10:00:00.000Z'),
    outcome: 'EXECUTED',
    ...overrides,
  };
}

function makeSession(overrides: Partial<Session> = {}): Session {
  return {
    id: SESSION_ID,
    name: 'Test Session',
    state: 'CREATED',
    createdAt: new Date('2026-02-14T10:00:00.000Z'),
    startedAt: null,
    endedAt: null,
    tokenCount: 0,
    userCount: 0,
    adminId: 'admin-1',
    contextDescriptor: { topic: 'Test' },
    environmentalConstraints: { max_participants: 10 },
    ...overrides,
  };
}

describe('Suppression engine — admin action tracking', () => {
  beforeEach(() => {
    clearAdminActions(SESSION_ID);
  });

  it('logs and retrieves admin actions', () => {
    const action = makeAdminAction();
    logAdminAction(action);

    const actions = getAdminActions(SESSION_ID);
    expect(actions).toHaveLength(1);
    expect(actions[0]).toEqual(action);
  });

  it('returns empty array for unknown session', () => {
    expect(getAdminActions('unknown-session')).toEqual([]);
  });

  it('accumulates multiple actions', () => {
    logAdminAction(makeAdminAction({ actionType: 'SESSION_CREATE' }));
    logAdminAction(makeAdminAction({ actionType: 'SESSION_START', timestamp: new Date('2026-02-14T10:01:00.000Z') }));

    const actions = getAdminActions(SESSION_ID);
    expect(actions).toHaveLength(2);
    expect(actions[0]!.actionType).toBe('SESSION_CREATE');
    expect(actions[1]!.actionType).toBe('SESSION_START');
  });

  it('clears actions for a session', () => {
    logAdminAction(makeAdminAction());
    clearAdminActions(SESSION_ID);

    expect(getAdminActions(SESSION_ID)).toEqual([]);
  });
});

describe('Suppression engine — checkSignalCoherence', () => {
  beforeEach(() => {
    clearAdminActions(SESSION_ID);
  });

  it('returns coherent=true with no prior actions', () => {
    const result = checkSignalCoherence(SESSION_ID, 'SESSION_CREATE');
    expect(result.coherent).toBe(true);
    expect(result.conflicts).toBeUndefined();
  });

  it('returns coherent=true for non-contradictory actions', () => {
    logAdminAction(makeAdminAction({ actionType: 'SESSION_CREATE' }));
    logAdminAction(makeAdminAction({ actionType: 'SESSION_START' }));

    const result = checkSignalCoherence(SESSION_ID, 'SESSION_END');
    expect(result.coherent).toBe(true);
  });

  it('returns coherent=false for SESSION_START after SESSION_END', () => {
    logAdminAction(makeAdminAction({ actionType: 'SESSION_CREATE' }));
    logAdminAction(makeAdminAction({ actionType: 'SESSION_START' }));
    logAdminAction(makeAdminAction({ actionType: 'SESSION_END' }));

    const result = checkSignalCoherence(SESSION_ID, 'SESSION_START');
    expect(result.coherent).toBe(false);
    expect(result.conflicts).toBeDefined();
    expect(result.conflicts!.length).toBeGreaterThan(0);
    expect(result.conflicts![0]!.action).toBe('SESSION_START');
  });

  it('ignores suppressed actions in coherence check', () => {
    logAdminAction(makeAdminAction({ actionType: 'SESSION_END', outcome: 'SUPPRESSED' }));

    const result = checkSignalCoherence(SESSION_ID, 'SESSION_START');
    expect(result.coherent).toBe(true);
  });
});

describe('Suppression engine — evaluateAction (scoped protocols)', () => {
  beforeEach(() => {
    clearAdminActions(SESSION_ID);
    vi.clearAllMocks();
  });

  it('passes only I.05, I.08 to verify (not I.01-I.04)', async () => {
    const session = makeSession({ state: 'CREATED' });
    vi.mocked(sessionModel.findById).mockResolvedValue(session);
    vi.mocked(ledgerModule.getEntriesBySession).mockResolvedValue([]);
    vi.mocked(presenceTracker.getPresenceRecords).mockResolvedValue([]);

    verifySpy.mockReturnValue({
      pass: true,
      protocolResults: [],
      timestamp: new Date(),
    });

    await evaluateAction(SESSION_ID, 'SESSION_START');

    expect(verifySpy).toHaveBeenCalledOnce();
    const protocols = verifySpy.mock.calls[0]![2];
    expect(protocols).toHaveLength(2);
    expect(protocols![0]).toBeInstanceOf(I05ProtocolSupremacy);
    expect(protocols![1]).toBeInstanceOf(I08SignalCoherenceProtocol);
  });

  it('allows SESSION_START on a CREATED session when protocols pass', async () => {
    const session = makeSession({ state: 'CREATED' });
    vi.mocked(sessionModel.findById).mockResolvedValue(session);
    vi.mocked(ledgerModule.getEntriesBySession).mockResolvedValue([]);
    vi.mocked(presenceTracker.getPresenceRecords).mockResolvedValue([]);

    verifySpy.mockReturnValue({
      pass: true,
      protocolResults: [],
      timestamp: new Date(),
    });

    const result = await evaluateAction(SESSION_ID, 'SESSION_START');
    expect(result.allowed).toBe(true);
    expect(result.suppression).toBeUndefined();
  });

  it('allows SESSION_END on an ACTIVE session when protocols pass', async () => {
    const session = makeSession({ state: 'ACTIVE', startedAt: new Date() });
    vi.mocked(sessionModel.findById).mockResolvedValue(session);
    vi.mocked(ledgerModule.getEntriesBySession).mockResolvedValue([]);
    vi.mocked(presenceTracker.getPresenceRecords).mockResolvedValue([]);

    verifySpy.mockReturnValue({
      pass: true,
      protocolResults: [],
      timestamp: new Date(),
    });

    const result = await evaluateAction(SESSION_ID, 'SESSION_END');
    expect(result.allowed).toBe(true);
  });

  it('blocks action when scoped protocols fail', async () => {
    const session = makeSession({ state: 'ACTIVE', startedAt: new Date() });
    vi.mocked(sessionModel.findById).mockResolvedValue(session);
    vi.mocked(ledgerModule.getEntriesBySession).mockResolvedValue([]);
    vi.mocked(presenceTracker.getPresenceRecords).mockResolvedValue([]);

    verifySpy.mockReturnValue({
      pass: false,
      protocolResults: [
        { protocol: 'I.05', result: 'FAIL', details: 'Admin override blocked' },
      ],
      timestamp: new Date(),
    });

    const result = await evaluateAction(SESSION_ID, 'SESSION_START');
    expect(result.allowed).toBe(false);
    expect(result.suppression).toBeDefined();
    expect(result.suppression!.reason).toContain('I.05');
    expect(result.suppression!.reason).toContain('Admin override blocked');
  });

  it('throws when session not found', async () => {
    vi.mocked(sessionModel.findById).mockResolvedValue(null);

    await expect(evaluateAction('nonexistent', 'SESSION_START'))
      .rejects.toThrow('Session not found: nonexistent');
  });

  it('blocks on signal coherence before protocol check', async () => {
    const session = makeSession({ state: 'ACTIVE', startedAt: new Date() });
    vi.mocked(sessionModel.findById).mockResolvedValue(session);
    vi.mocked(ledgerModule.getEntriesBySession).mockResolvedValue([]);
    vi.mocked(presenceTracker.getPresenceRecords).mockResolvedValue([]);

    // Log SESSION_END so SESSION_START is incoherent
    logAdminAction(makeAdminAction({ actionType: 'SESSION_END' }));

    const result = await evaluateAction(SESSION_ID, 'SESSION_START');
    expect(result.allowed).toBe(false);
    expect(result.suppression!.reason).toContain('Signal coherence violation');
    // verify() should NOT have been called since coherence check failed first
    expect(verifySpy).not.toHaveBeenCalled();
  });
});
