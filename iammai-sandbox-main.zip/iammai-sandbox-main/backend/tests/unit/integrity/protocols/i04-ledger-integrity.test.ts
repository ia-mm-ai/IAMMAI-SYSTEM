/**
 * Unit tests for I.04 Ledger Non-Erasure protocol evaluator.
 * @see specs/006-verification-witness
 */

import { describe, it, expect } from 'vitest';
import { I04LedgerIntegrity } from '../../../../src/integrity/protocols/i04-ledger-integrity.js';
import type { EvaluationContext, LedgerEntry, MetadataSnapshot } from '../../../../src/integrity/types.js';
import type { Session } from '../../../../src/lib/types.js';
import { computeEntryHash } from '../../../../src/integrity/hash.js';

const SESSION_ID = 'aaaaaaaa-bbbb-cccc-dddd-eeeeeeeeeeee';
const ADMIN_ID = '11111111-2222-3333-4444-555555555555';

function makeSnapshot(overrides: Partial<MetadataSnapshot> = {}): MetadataSnapshot {
  return {
    session_id: SESSION_ID,
    session_name: 'Test Session',
    state: 'CREATED',
    framework_status: 'OPEN',
    admin_id: ADMIN_ID,
    token_count: 0,
    user_count: 0,
    created_at: '2026-02-14T10:00:00.000Z',
    started_at: null,
    ended_at: null,
    context_descriptor: { topic: 'Test topic' },
    environmental_constraints: { max_participants: 10 },
    ...overrides,
  };
}

function makeSession(): Session {
  return {
    id: SESSION_ID,
    name: 'Test Session',
    state: 'ENDED',
    createdAt: new Date('2026-02-14T10:00:00.000Z'),
    startedAt: new Date('2026-02-14T10:01:00.000Z'),
    endedAt: new Date('2026-02-14T10:30:00.000Z'),
    tokenCount: 1,
    userCount: 1,
    adminId: ADMIN_ID,
    contextDescriptor: { topic: 'Test topic' },
    environmentalConstraints: { max_participants: 10 },
  };
}

function buildValidChain(count: number): LedgerEntry[] {
  const snapshots = [
    makeSnapshot(),
    makeSnapshot({ state: 'ACTIVE', started_at: '2026-02-14T10:01:00.000Z' }),
    makeSnapshot({ state: 'ENDED', started_at: '2026-02-14T10:01:00.000Z', ended_at: '2026-02-14T10:30:00.000Z', framework_status: 'CLOSED' }),
  ];
  const eventTypes = ['SESSION_CREATED', 'SESSION_ACTIVATED', 'SESSION_CLOSED'] as const;
  const timestamps = [
    '2026-02-14T10:00:00.000Z',
    '2026-02-14T10:01:00.000Z',
    '2026-02-14T10:30:00.000Z',
  ];

  const entries: LedgerEntry[] = [];
  let previousHash: string | null = null;

  for (let i = 0; i < Math.min(count, 3); i++) {
    const seq = i + 1;
    const hash = computeEntryHash(previousHash, seq, SESSION_ID, eventTypes[i], timestamps[i]!, snapshots[i]!);
    entries.push({
      id: `entry-${seq}`,
      sequenceNumber: seq,
      sessionId: SESSION_ID,
      eventType: eventTypes[i],
      timestamp: new Date(timestamps[i]!),
      fromState: i === 0 ? null : (['CREATED', 'ACTIVE'] as const)[i - 1],
      toState: snapshots[i]!.state,
      metadataSnapshot: snapshots[i]!,
      previousHash,
      entryHash: hash,
    });
    previousHash = hash;
  }

  return entries;
}

const evaluator = new I04LedgerIntegrity();

describe('I.04 Ledger Non-Erasure evaluator', () => {
  it('has correct protocol id', () => {
    expect(evaluator.id).toBe('I.04');
  });

  it('PASS for valid hash chain with no sequence gaps', () => {
    const context: EvaluationContext = {
      session: makeSession(),
      ledgerEntries: buildValidChain(3),
    };
    const result = evaluator.evaluate(context);
    expect(result.result).toBe('PASS');
    expect(result.protocol).toBe('I.04');
  });

  it('FAIL when no ledger entries exist', () => {
    const context: EvaluationContext = {
      session: makeSession(),
      ledgerEntries: [],
    };
    const result = evaluator.evaluate(context);
    expect(result.result).toBe('FAIL');
    expect(result.details).toContain('No ledger entries');
  });

  it('FAIL when hash chain is broken (tampered hash)', () => {
    const entries = buildValidChain(3);
    entries[1] = {
      ...entries[1]!,
      entryHash: 'aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa',
    };

    const context: EvaluationContext = {
      session: makeSession(),
      ledgerEntries: entries,
    };
    const result = evaluator.evaluate(context);
    expect(result.result).toBe('FAIL');
    expect(result.details).toContain('Hash chain broken');
  });

  it('FAIL when sequence numbers have gaps', () => {
    const entries = buildValidChain(3);
    // Create a gap by changing sequence 2 to 5
    entries[1] = { ...entries[1]!, sequenceNumber: 5 };

    const context: EvaluationContext = {
      session: makeSession(),
      ledgerEntries: entries,
    };
    const result = evaluator.evaluate(context);
    expect(result.result).toBe('FAIL');
    expect(result.details).toContain('Sequence gap');
  });

  it('PASS for single entry chain', () => {
    const context: EvaluationContext = {
      session: makeSession(),
      ledgerEntries: buildValidChain(1),
    };
    const result = evaluator.evaluate(context);
    expect(result.result).toBe('PASS');
  });
});
