/**
 * Unit tests for I.02 Event Boundary protocol evaluator.
 * @see specs/006-verification-witness
 */

import { describe, it, expect } from 'vitest';
import { I02EventBoundary } from '../../../../src/integrity/protocols/i02-event-boundary.js';
import type { EvaluationContext } from '../../../../src/integrity/types.js';
import type { Session } from '../../../../src/lib/types.js';

function makeSession(overrides: Partial<Session> = {}): Session {
  return {
    id: 'aaaaaaaa-bbbb-cccc-dddd-eeeeeeeeeeee',
    name: 'Test Session',
    state: 'ENDED',
    createdAt: new Date('2026-02-14T10:00:00.000Z'),
    startedAt: new Date('2026-02-14T10:01:00.000Z'),
    endedAt: new Date('2026-02-14T10:30:00.000Z'),
    tokenCount: 1,
    userCount: 1,
    adminId: '11111111-2222-3333-4444-555555555555',
    contextDescriptor: { topic: 'Test topic' },
    environmentalConstraints: { max_participants: 10 },
    ...overrides,
  };
}

function makeContext(sessionOverrides: Partial<Session> = {}): EvaluationContext {
  return {
    session: makeSession(sessionOverrides),
    ledgerEntries: [],
    presenceRecords: [],
    adminActions: [],
    coAgencyActions: [],
  };
}

const evaluator = new I02EventBoundary();

describe('I.02 Event Boundary evaluator', () => {
  it('has correct protocol id and version', () => {
    expect(evaluator.id).toBe('I.02');
    expect(evaluator.version).toBeDefined();
  });

  it('PASS for valid ended session with all boundaries', () => {
    const result = evaluator.evaluate(makeContext());
    expect(result.result).toBe('PASS');
    expect(result.protocol).toBe('I.02');
  });

  it('FAIL when createdAt is missing', () => {
    const result = evaluator.evaluate(makeContext({
      createdAt: null as unknown as Date,
    }));
    expect(result.result).toBe('FAIL');
    expect(result.details).toContain('t_open');
  });

  it('FAIL when endedAt is missing', () => {
    const result = evaluator.evaluate(makeContext({
      endedAt: null,
    }));
    expect(result.result).toBe('FAIL');
    expect(result.details).toContain('t_close');
  });

  it('FAIL when t_close <= t_open', () => {
    const result = evaluator.evaluate(makeContext({
      createdAt: new Date('2026-02-14T10:30:00.000Z'),
      endedAt: new Date('2026-02-14T10:00:00.000Z'),
    }));
    expect(result.result).toBe('FAIL');
    expect(result.details).toContain('t_close must be after t_open');
  });

  it('FAIL when t_close equals t_open', () => {
    const sameTime = new Date('2026-02-14T10:00:00.000Z');
    const result = evaluator.evaluate(makeContext({
      createdAt: sameTime,
      endedAt: sameTime,
    }));
    expect(result.result).toBe('FAIL');
  });

  it('FAIL when session is not ENDED', () => {
    const result = evaluator.evaluate(makeContext({
      state: 'ACTIVE',
    }));
    expect(result.result).toBe('FAIL');
    expect(result.details).toContain('ACTIVE');
    expect(result.details).toContain('ENDED');
  });

  it('FAIL when context_descriptor.topic is missing', () => {
    const result = evaluator.evaluate(makeContext({
      contextDescriptor: { topic: '' },
    }));
    expect(result.result).toBe('FAIL');
    expect(result.details).toContain('context_descriptor.topic');
  });

  it('FAIL when environmental_constraints.max_participants is missing', () => {
    const result = evaluator.evaluate(makeContext({
      environmentalConstraints: { max_participants: undefined as unknown as number },
    }));
    expect(result.result).toBe('FAIL');
    expect(result.details).toContain('max_participants');
  });

  it('collects multiple failures in details', () => {
    const result = evaluator.evaluate(makeContext({
      state: 'ACTIVE',
      endedAt: null,
      contextDescriptor: { topic: '' },
    }));
    expect(result.result).toBe('FAIL');
    // Should contain multiple failure reasons
    const reasons = result.details.split('; ');
    expect(reasons.length).toBeGreaterThanOrEqual(2);
  });

  // IAMMAI branch tests
  describe('IAMMAI extension', () => {
    function makeIammaiContext(
      sessionOverrides: Partial<Session>,
      stateRecords: any[],
      transitionRecords: any[]
    ): EvaluationContext {
      return {
        session: makeSession({ iammaiTracked: true, ...sessionOverrides } as any),
        ledgerEntries: [],
        presenceRecords: [],
        adminActions: [],
        coAgencyActions: [],
        iammaiContext: {
          stateRecords,
          transitionRecords,
          governanceActions: [],
          witnessArtifacts: [],
          validationArtifacts: [],
          contributionRecords: [],
          containmentRecords: [],
        },
      };
    }

    it('PASS for IAMMAI session with valid resolution from standing', () => {
      const result = evaluator.evaluate(makeIammaiContext(
        {},
        [{ state_id: 's1', state_type: 'decision', state_family: 'standing' }],
        [{ transition_type: 'resolution_transition', source_ref: 's1', resolution_type: 'FINALIZE' }],
      ));
      expect(result.result).toBe('PASS');
      expect(result.details).toContain('IAMMAI standing-state verified');
    });

    it('FAIL for IAMMAI session ended without resolution transition', () => {
      const result = evaluator.evaluate(makeIammaiContext(
        {},
        [{ state_id: 's1', state_type: 'continuity', state_family: 'standing' }],
        [],  // no resolution transitions
      ));
      expect(result.result).toBe('FAIL');
      expect(result.details).toContain('without resolution transition');
    });

    it('FAIL for IAMMAI resolution from preparation phase', () => {
      const result = evaluator.evaluate(makeIammaiContext(
        {},
        [{ state_id: 's1', state_type: 'threshold', state_family: 'preparation' }],
        [{ transition_type: 'resolution_transition', source_ref: 's1', resolution_type: 'FINALIZE' }],
      ));
      expect(result.result).toBe('FAIL');
      expect(result.details).toContain('preparation phase');
    });

    it('PASS for non-IAMMAI session (no IAMMAI checks)', () => {
      const ctx = makeContext({});
      // session.iammaiTracked is undefined/falsy
      const result = evaluator.evaluate(ctx);
      expect(result.result).toBe('PASS');
      expect(result.details).not.toContain('IAMMAI');
    });
  });
});
