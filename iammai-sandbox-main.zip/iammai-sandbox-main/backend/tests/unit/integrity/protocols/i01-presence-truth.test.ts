/**
 * Unit tests for I.01 Presence Truth protocol evaluator.
 * @see specs/007-presence-suppression/contracts/protocol-evaluators.md
 */

import { describe, it, expect } from 'vitest';
import { I01PresenceTruth } from '../../../../src/integrity/protocols/i01-presence-truth.js';
import type { EvaluationContext, PresenceRecord } from '../../../../src/integrity/types.js';
import type { Session } from '../../../../src/lib/types.js';

function makeSession(): Session {
  return {
    id: 'aaaaaaaa-bbbb-cccc-dddd-eeeeeeeeeeee',
    name: 'Test Session',
    state: 'ENDED',
    createdAt: new Date('2026-02-14T10:00:00.000Z'),
    startedAt: new Date('2026-02-14T10:01:00.000Z'),
    endedAt: new Date('2026-02-14T10:30:00.000Z'),
    tokenCount: 1,
    userCount: 1,
    adminId: '11111111-2222-3333-4444-555555555555',
    contextDescriptor: { topic: 'Test topic' },
    environmentalConstraints: { max_participants: 10 },
  };
}

function makeRecord(overrides: Partial<PresenceRecord> = {}): PresenceRecord {
  return {
    id: 'rec-1',
    sessionId: 'aaaaaaaa-bbbb-cccc-dddd-eeeeeeeeeeee',
    role: 'CREATOR',
    presenceHash: 'a1b2c3d4',
    attestationMethod: 'AUTH_EVENT',
    attested: true,
    finalized: true,
    createdAt: new Date('2026-02-14T10:00:00.000Z'),
    finalizedAt: new Date('2026-02-14T10:30:00.000Z'),
    ...overrides,
  };
}

function makeContext(presenceRecords: PresenceRecord[]): EvaluationContext {
  return {
    session: makeSession(),
    ledgerEntries: [],
    presenceRecords,
    adminActions: [],
  };
}

const evaluator = new I01PresenceTruth();

describe('I.01 Presence Truth evaluator', () => {
  it('has correct protocol id and version', () => {
    expect(evaluator.id).toBe('I.01');
    expect(evaluator.version).toBe('1.0.0');
  });

  it('PASS with 2+ attestation methods (AUTH_EVENT + JOIN_TOKEN)', () => {
    const records = [
      makeRecord({ role: 'CREATOR', attestationMethod: 'AUTH_EVENT' }),
      makeRecord({ id: 'rec-2', role: 'PARTICIPANT', attestationMethod: 'JOIN_TOKEN', presenceHash: 'user1234' }),
    ];
    const result = evaluator.evaluate(makeContext(records));
    expect(result.result).toBe('PASS');
    expect(result.protocol).toBe('I.01');
  });

  it('PASS with 3 attestation methods', () => {
    const records = [
      makeRecord({ role: 'CREATOR', attestationMethod: 'AUTH_EVENT' }),
      makeRecord({ id: 'rec-2', role: 'PARTICIPANT', attestationMethod: 'JOIN_TOKEN', presenceHash: 'user1' }),
      makeRecord({ id: 'rec-3', role: 'AGENT', attestationMethod: 'MESSAGE_PROCESSING', presenceHash: 'ai-agent' }),
    ];
    const result = evaluator.evaluate(makeContext(records));
    expect(result.result).toBe('PASS');
    expect(result.details).toContain('3 attestation methods');
  });

  it('FAIL with 1 method (admin-only session)', () => {
    const records = [
      makeRecord({ role: 'CREATOR', attestationMethod: 'AUTH_EVENT' }),
    ];
    const result = evaluator.evaluate(makeContext(records));
    expect(result.result).toBe('FAIL');
    expect(result.details).toContain('1 attestation method(s)');
    expect(result.details).toContain('requires 2+');
  });

  it('FAIL with 0 records', () => {
    const result = evaluator.evaluate(makeContext([]));
    expect(result.result).toBe('FAIL');
    expect(result.details).toContain('0 attestation method(s)');
  });

  it('FAIL if records not finalized', () => {
    const records = [
      makeRecord({ role: 'CREATOR', attestationMethod: 'AUTH_EVENT', finalized: false, finalizedAt: null }),
      makeRecord({ id: 'rec-2', role: 'PARTICIPANT', attestationMethod: 'JOIN_TOKEN', presenceHash: 'user1' }),
    ];
    const result = evaluator.evaluate(makeContext(records));
    expect(result.result).toBe('FAIL');
    expect(result.details).toContain('not finalized');
  });

  it('is deterministic — same input produces same output', () => {
    const records = [
      makeRecord({ role: 'CREATOR', attestationMethod: 'AUTH_EVENT' }),
      makeRecord({ id: 'rec-2', role: 'PARTICIPANT', attestationMethod: 'JOIN_TOKEN', presenceHash: 'u1' }),
    ];

    const result1 = evaluator.evaluate(makeContext(records));
    const result2 = evaluator.evaluate(makeContext(records));

    expect(result1.result).toBe(result2.result);
    expect(result1.details).toBe(result2.details);
    expect(result1.protocol).toBe(result2.protocol);
  });

  it('counts distinct methods not distinct records', () => {
    // Two JOIN_TOKEN participants + admin = 2 methods, not 3
    const records = [
      makeRecord({ role: 'CREATOR', attestationMethod: 'AUTH_EVENT' }),
      makeRecord({ id: 'rec-2', role: 'PARTICIPANT', attestationMethod: 'JOIN_TOKEN', presenceHash: 'u1' }),
      makeRecord({ id: 'rec-3', role: 'PARTICIPANT', attestationMethod: 'JOIN_TOKEN', presenceHash: 'u2' }),
    ];
    const result = evaluator.evaluate(makeContext(records));
    expect(result.result).toBe('PASS');
    expect(result.details).toContain('2 attestation methods');
  });
});
