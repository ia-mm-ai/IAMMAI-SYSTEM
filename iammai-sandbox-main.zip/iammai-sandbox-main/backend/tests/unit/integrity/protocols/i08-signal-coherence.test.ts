/**
 * Unit tests for I.08 Signal Coherence evaluator.
 * @see specs/007-presence-suppression/contracts/protocol-evaluators.md
 */

import { describe, it, expect } from 'vitest';
import { I08SignalCoherence } from '../../../../src/integrity/protocols/i08-signal-coherence.js';
import type { EvaluationContext, AdminAction } from '../../../../src/integrity/types.js';
import type { Session } from '../../../../src/lib/types.js';

function makeSession(): Session {
  return {
    id: 'aaaaaaaa-bbbb-cccc-dddd-eeeeeeeeeeee',
    name: 'Test Session',
    state: 'ENDED',
    createdAt: new Date('2026-02-14T10:00:00.000Z'),
    startedAt: new Date('2026-02-14T10:01:00.000Z'),
    endedAt: new Date('2026-02-14T10:30:00.000Z'),
    tokenCount: 1,
    userCount: 1,
    adminId: '11111111-2222-3333-4444-555555555555',
    contextDescriptor: { topic: 'Test topic' },
    environmentalConstraints: { max_participants: 10 },
  };
}

function makeContext(adminActions: AdminAction[]): EvaluationContext {
  return {
    session: makeSession(),
    ledgerEntries: [],
    presenceRecords: [],
    adminActions,
  };
}

const evaluator = new I08SignalCoherence();

describe('I.08 Signal Coherence evaluator', () => {
  it('has correct protocol id and version', () => {
    expect(evaluator.id).toBe('I.08');
    expect(evaluator.version).toBe('1.0.0');
  });

  it('PASS with no admin actions', () => {
    const result = evaluator.evaluate(makeContext([]));
    expect(result.result).toBe('PASS');
  });

  it('PASS with single admin action', () => {
    const actions: AdminAction[] = [
      { sessionId: 'test', actionType: 'SESSION_CREATE', timestamp: new Date(), outcome: 'EXECUTED' },
    ];
    const result = evaluator.evaluate(makeContext(actions));
    expect(result.result).toBe('PASS');
  });

  it('PASS with normal sequential actions', () => {
    const actions: AdminAction[] = [
      { sessionId: 'test', actionType: 'SESSION_CREATE', timestamp: new Date('2026-02-14T10:00:00.000Z'), outcome: 'EXECUTED' },
      { sessionId: 'test', actionType: 'SESSION_START', timestamp: new Date('2026-02-14T10:01:00.000Z'), outcome: 'EXECUTED' },
      { sessionId: 'test', actionType: 'SESSION_END', timestamp: new Date('2026-02-14T10:30:00.000Z'), outcome: 'EXECUTED' },
    ];
    const result = evaluator.evaluate(makeContext(actions));
    expect(result.result).toBe('PASS');
  });

  it('FAIL with contradictory action pair (START after END)', () => {
    const actions: AdminAction[] = [
      { sessionId: 'test', actionType: 'SESSION_CREATE', timestamp: new Date('2026-02-14T10:00:00.000Z'), outcome: 'EXECUTED' },
      { sessionId: 'test', actionType: 'SESSION_START', timestamp: new Date('2026-02-14T10:01:00.000Z'), outcome: 'EXECUTED' },
      { sessionId: 'test', actionType: 'SESSION_END', timestamp: new Date('2026-02-14T10:30:00.000Z'), outcome: 'EXECUTED' },
      { sessionId: 'test', actionType: 'SESSION_START', timestamp: new Date('2026-02-14T10:31:00.000Z'), outcome: 'EXECUTED' },
    ];
    const result = evaluator.evaluate(makeContext(actions));
    expect(result.result).toBe('FAIL');
    expect(result.details).toContain('Contradictory');
    expect(result.details).toContain('SESSION_START');
  });

  it('does not evaluate chat messages', () => {
    // Chat content is never included in adminActions (Framework Decision 5)
    // AdminActionType only includes SESSION_CREATE, SESSION_START, SESSION_END
    const actions: AdminAction[] = [
      { sessionId: 'test', actionType: 'SESSION_CREATE', timestamp: new Date(), outcome: 'EXECUTED' },
    ];
    const result = evaluator.evaluate(makeContext(actions));
    expect(result.result).toBe('PASS');
  });

  it('ignores suppressed actions in coherence check', () => {
    const actions: AdminAction[] = [
      { sessionId: 'test', actionType: 'SESSION_END', timestamp: new Date('2026-02-14T10:30:00.000Z'), outcome: 'SUPPRESSED' },
      { sessionId: 'test', actionType: 'SESSION_START', timestamp: new Date('2026-02-14T10:31:00.000Z'), outcome: 'EXECUTED' },
    ];
    const result = evaluator.evaluate(makeContext(actions));
    expect(result.result).toBe('PASS');
  });

  it('is deterministic — same input produces same output', () => {
    const actions: AdminAction[] = [
      { sessionId: 'test', actionType: 'SESSION_CREATE', timestamp: new Date(), outcome: 'EXECUTED' },
      { sessionId: 'test', actionType: 'SESSION_START', timestamp: new Date(), outcome: 'EXECUTED' },
    ];
    const r1 = evaluator.evaluate(makeContext(actions));
    const r2 = evaluator.evaluate(makeContext(actions));
    expect(r1.result).toBe(r2.result);
    expect(r1.details).toBe(r2.details);
  });
});
