/**
 * Unit tests for I.06 Presence-Derived Identity protocol evaluator.
 * @see specs/008-governance-protocols/contracts/protocol-evaluators.md
 */

import { describe, it, expect } from 'vitest';
import { I06PresenceIdentity } from '../../../../src/integrity/protocols/i06-presence-identity.js';
import type { EvaluationContext, PresenceRecord } from '../../../../src/integrity/types.js';
import type { Session } from '../../../../src/lib/types.js';

function makeSession(): Session {
  return {
    id: 'aaaaaaaa-bbbb-cccc-dddd-eeeeeeeeeeee',
    name: 'Test Session',
    state: 'ENDED',
    createdAt: new Date('2026-02-14T10:00:00.000Z'),
    startedAt: new Date('2026-02-14T10:01:00.000Z'),
    endedAt: new Date('2026-02-14T10:30:00.000Z'),
    tokenCount: 1,
    userCount: 1,
    adminId: '11111111-2222-3333-4444-555555555555',
    contextDescriptor: { topic: 'Test topic' },
    environmentalConstraints: { max_participants: 10 },
  };
}

function makeAdminRecord(overrides: Partial<PresenceRecord> = {}): PresenceRecord {
  return {
    id: 'pres-001',
    sessionId: 'aaaaaaaa-bbbb-cccc-dddd-eeeeeeeeeeee',
    role: 'CREATOR',
    presenceHash: 'sha256:abcdef1234567890abcdef1234567890abcdef1234567890abcdef1234567890',
    attestationMethod: 'AUTH_EVENT',
    attested: true,
    finalized: true,
    createdAt: new Date('2026-02-14T10:00:00.000Z'),
    finalizedAt: new Date('2026-02-14T10:30:00.000Z'),
    ...overrides,
  };
}

function makeContext(presenceRecords: PresenceRecord[]): EvaluationContext {
  return {
    session: makeSession(),
    ledgerEntries: [],
    presenceRecords,
    adminActions: [],
    coAgencyActions: [],
  };
}

const evaluator = new I06PresenceIdentity();

describe('I.06 Presence-Derived Identity evaluator', () => {
  it('has correct protocol id and version', () => {
    expect(evaluator.id).toBe('I.06');
    expect(evaluator.version).toBe('1.1.0');
  });

  it('PASS with valid admin presence (CREATOR role, non-empty hash, AUTH_EVENT, attested=true)', () => {
    const result = evaluator.evaluate(makeContext([makeAdminRecord()]));
    expect(result.result).toBe('PASS');
    expect(result.protocol).toBe('I.06');
    expect(result.details).toBe('Admin identity derived from presence set via anonymous hash');
  });

  it('PASS with additional participant records alongside valid admin', () => {
    const participant: PresenceRecord = {
      id: 'pres-002',
      sessionId: 'aaaaaaaa-bbbb-cccc-dddd-eeeeeeeeeeee',
      role: 'PARTICIPANT',
      presenceHash: 'sha256:participant-hash',
      attestationMethod: 'JOIN_TOKEN',
      attested: true,
      finalized: true,
      createdAt: new Date('2026-02-14T10:05:00.000Z'),
      finalizedAt: new Date('2026-02-14T10:30:00.000Z'),
    };
    const result = evaluator.evaluate(makeContext([makeAdminRecord(), participant]));
    expect(result.result).toBe('PASS');
  });

  it('FAIL with no admin presence record (empty records)', () => {
    const result = evaluator.evaluate(makeContext([]));
    expect(result.result).toBe('FAIL');
    expect(result.protocol).toBe('I.06');
    expect(result.details).toBe(
      'No admin presence record for session — identity cannot be derived from presence set'
    );
  });

  it('FAIL with no admin presence record (only non-CREATOR records)', () => {
    const participant: PresenceRecord = {
      id: 'pres-002',
      sessionId: 'aaaaaaaa-bbbb-cccc-dddd-eeeeeeeeeeee',
      role: 'PARTICIPANT',
      presenceHash: 'sha256:some-hash',
      attestationMethod: 'JOIN_TOKEN',
      attested: true,
      finalized: true,
      createdAt: new Date('2026-02-14T10:05:00.000Z'),
      finalizedAt: null,
    };
    const result = evaluator.evaluate(makeContext([participant]));
    expect(result.result).toBe('FAIL');
    expect(result.details).toBe(
      'No admin presence record for session — identity cannot be derived from presence set'
    );
  });

  it('FAIL with empty presenceHash', () => {
    const result = evaluator.evaluate(makeContext([makeAdminRecord({ presenceHash: '' })]));
    expect(result.result).toBe('FAIL');
    expect(result.protocol).toBe('I.06');
    expect(result.details).toBe(
      'Admin presence hash is empty — identity requires non-empty anonymous hash'
    );
  });

  it('FAIL with admin not attested', () => {
    const result = evaluator.evaluate(makeContext([makeAdminRecord({ attested: false })]));
    expect(result.result).toBe('FAIL');
    expect(result.protocol).toBe('I.06');
    expect(result.details).toBe(
      'Admin presence not attested — identity requires verified presence'
    );
  });

  it('checks presenceHash before attested — empty hash fails on hash check', () => {
    const result = evaluator.evaluate(
      makeContext([makeAdminRecord({ presenceHash: '', attested: false })])
    );
    expect(result.result).toBe('FAIL');
    expect(result.details).toBe(
      'Admin presence hash is empty — identity requires non-empty anonymous hash'
    );
  });

  it('is deterministic — same input produces same output', () => {
    const ctx = makeContext([makeAdminRecord()]);
    const r1 = evaluator.evaluate(ctx);
    const r2 = evaluator.evaluate(ctx);
    expect(r1.result).toBe(r2.result);
    expect(r1.details).toBe(r2.details);
  });

  describe('IAMMAI contribution role checks', () => {
    function makeIammaiContext(
      presenceRecords: PresenceRecord[],
      contributionRecords: Array<{ actor_ref: string; role: string }> = []
    ): EvaluationContext {
      const session = { ...makeSession(), iammaiTracked: true };
      return {
        session,
        ledgerEntries: [],
        presenceRecords,
        adminActions: [],
        coAgencyActions: [],
        iammaiContext: {
          stateRecords: [],
          transitionRecords: [],
          governanceActions: [],
          witnessArtifacts: [],
          validationArtifacts: [],
          contributionRecords: contributionRecords.map((c, i) => ({
            contribution_id: `contrib-${i}`,
            matter_ref: 'bnk:session:test',
            actor_ref: c.actor_ref,
            role: c.role as any,
            recorded_at: new Date(),
            context_ref: null,
          })),
          containmentRecords: [],
        },
      };
    }

    it('PASS when admin has ORIGIN role in IAMMAI session', () => {
      const ctx = makeIammaiContext([makeAdminRecord()], [
        { actor_ref: 'bnk:admin:11111111-2222-3333-4444-555555555555', role: 'ORIGIN' },
      ]);
      const result = evaluator.evaluate(ctx);
      expect(result.result).toBe('PASS');
      expect(result.details).toContain('IAMMAI contribution roles verified');
    });

    it('PASS when admin has AUTHORIZATION role in IAMMAI session', () => {
      const ctx = makeIammaiContext([makeAdminRecord()], [
        { actor_ref: 'bnk:admin:11111111-2222-3333-4444-555555555555', role: 'AUTHORIZATION' },
      ]);
      const result = evaluator.evaluate(ctx);
      expect(result.result).toBe('PASS');
    });

    it('FAIL when admin has no ORIGIN or AUTHORIZATION role in IAMMAI session', () => {
      const ctx = makeIammaiContext([makeAdminRecord()], [
        { actor_ref: 'bnk:admin:11111111-2222-3333-4444-555555555555', role: 'ELICITATION' },
      ]);
      const result = evaluator.evaluate(ctx);
      expect(result.result).toBe('FAIL');
      expect(result.details).toContain('IAMMAI');
      expect(result.details).toContain('ORIGIN or AUTHORIZATION');
    });

    it('FAIL when no contribution records exist for admin in IAMMAI session', () => {
      const ctx = makeIammaiContext([makeAdminRecord()], []);
      const result = evaluator.evaluate(ctx);
      expect(result.result).toBe('FAIL');
    });
  });
});
