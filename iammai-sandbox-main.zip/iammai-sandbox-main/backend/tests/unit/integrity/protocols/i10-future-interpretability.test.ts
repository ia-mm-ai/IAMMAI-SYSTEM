/**
 * Unit tests for I.10 Future Interpretability protocol evaluator.
 * @see specs/008-governance-protocols/contracts/protocol-evaluators.md
 */

import { describe, it, expect } from 'vitest';
import { I10FutureInterpretability } from '../../../../src/integrity/protocols/i10-future-interpretability.js';
import type { EvaluationContext, PresenceRecord } from '../../../../src/integrity/types.js';
import type { Session } from '../../../../src/lib/types.js';

function makeSession(aiModel?: string): Session {
  return {
    id: 'aaaaaaaa-bbbb-cccc-dddd-eeeeeeeeeeee',
    name: 'Test Session',
    state: 'ENDED',
    createdAt: new Date('2026-02-14T10:00:00.000Z'),
    startedAt: new Date('2026-02-14T10:01:00.000Z'),
    endedAt: new Date('2026-02-14T10:30:00.000Z'),
    tokenCount: 1,
    userCount: 1,
    adminId: '11111111-2222-3333-4444-555555555555',
    contextDescriptor: { topic: 'Test topic' },
    environmentalConstraints: {
      max_participants: 10,
      ...(aiModel !== undefined ? { ai_model: aiModel } : {}),
    },
  };
}

function makePresenceRecord(role: PresenceRecord['role']): PresenceRecord {
  return {
    id: `pr-${role}`,
    sessionId: 'aaaaaaaa-bbbb-cccc-dddd-eeeeeeeeeeee',
    role,
    presenceHash: 'hash-abc',
    attestationMethod: role === 'CREATOR' ? 'AUTH_EVENT' : role === 'AGENT' ? 'MESSAGE_PROCESSING' : 'JOIN_TOKEN',
    attested: true,
    finalized: true,
    createdAt: new Date('2026-02-14T10:00:00.000Z'),
    finalizedAt: new Date('2026-02-14T10:30:00.000Z'),
  };
}

function makeContext(
  presenceRecords: PresenceRecord[],
  session: Session
): EvaluationContext {
  return {
    session,
    ledgerEntries: [],
    presenceRecords,
    adminActions: [],
    coAgencyActions: [],
  };
}

const evaluator = new I10FutureInterpretability();

describe('I.10 Future Interpretability evaluator', () => {
  it('has correct protocol id and version', () => {
    expect(evaluator.id).toBe('I.10');
    expect(evaluator.version).toBe('1.1.0');
  });

  it('PASS with no AI participation (no AGENT records)', () => {
    const records = [makePresenceRecord('CREATOR'), makePresenceRecord('PARTICIPANT')];
    const result = evaluator.evaluate(makeContext(records, makeSession()));
    expect(result.result).toBe('PASS');
    expect(result.details).toBe('Future interpretability satisfied — no AI participation; AI metadata not required');
  });

  it('PASS with no presence records at all', () => {
    const result = evaluator.evaluate(makeContext([], makeSession()));
    expect(result.result).toBe('PASS');
    expect(result.details).toBe('Future interpretability satisfied — no AI participation; AI metadata not required');
  });

  it('PASS with AI participation and ai_model declared', () => {
    const records = [makePresenceRecord('CREATOR'), makePresenceRecord('AGENT')];
    const result = evaluator.evaluate(makeContext(records, makeSession('gpt-4o-mini')));
    expect(result.result).toBe('PASS');
    expect(result.details).toBe("Future interpretability satisfied — AI model 'gpt-4o-mini' declared for witness");
  });

  it('PASS detail message includes model name', () => {
    const records = [makePresenceRecord('AGENT')];
    const result = evaluator.evaluate(makeContext(records, makeSession('claude-3-opus')));
    expect(result.result).toBe('PASS');
    expect(result.details).toContain('claude-3-opus');
  });

  it('FAIL with AI participation but no ai_model in constraints', () => {
    const records = [makePresenceRecord('AGENT')];
    const result = evaluator.evaluate(makeContext(records, makeSession()));
    expect(result.result).toBe('FAIL');
    expect(result.details).toBe(
      'AI agent participated but no ai_model declared in environmental constraints — witness cannot describe AI involvement'
    );
  });

  it('FAIL with AI participation and empty string ai_model', () => {
    const records = [makePresenceRecord('AGENT')];
    const result = evaluator.evaluate(makeContext(records, makeSession('')));
    expect(result.result).toBe('FAIL');
    expect(result.details).toBe(
      'AI agent participated but no ai_model declared in environmental constraints — witness cannot describe AI involvement'
    );
  });

  it('protocol field matches I.10', () => {
    const result = evaluator.evaluate(makeContext([], makeSession()));
    expect(result.protocol).toBe('I.10');
  });

  it('is deterministic — same input produces same output', () => {
    const records = [makePresenceRecord('AGENT')];
    const session = makeSession('gpt-4o');
    const r1 = evaluator.evaluate(makeContext(records, session));
    const r2 = evaluator.evaluate(makeContext(records, session));
    expect(r1.result).toBe(r2.result);
    expect(r1.details).toBe(r2.details);
  });

  describe('IAMMAI contribution role checks', () => {
    function makeIammaiContext(
      presenceRecords: PresenceRecord[],
      aiModel: string,
      contributionRecords: Array<{ actor_ref: string; role: string }> = []
    ): EvaluationContext {
      const session = { ...makeSession(aiModel), iammaiTracked: true };
      return {
        session,
        ledgerEntries: [],
        presenceRecords,
        adminActions: [],
        coAgencyActions: [],
        iammaiContext: {
          stateRecords: [],
          transitionRecords: [],
          governanceActions: [],
          witnessArtifacts: [],
          validationArtifacts: [],
          contributionRecords: contributionRecords.map((c, i) => ({
            contribution_id: `contrib-${i}`,
            matter_ref: 'bnk:session:test',
            actor_ref: c.actor_ref,
            role: c.role as any,
            recorded_at: new Date(),
            context_ref: null,
          })),
          containmentRecords: [],
        },
      };
    }

    it('PASS when AI has FORMALIZATION role in IAMMAI session', () => {
      const ctx = makeIammaiContext(
        [makePresenceRecord('AGENT')],
        'gpt-4o',
        [{ actor_ref: 'bnk:agent:gpt-4o', role: 'FORMALIZATION' }]
      );
      const result = evaluator.evaluate(ctx);
      expect(result.result).toBe('PASS');
      expect(result.details).toContain('IAMMAI contribution roles verified');
    });

    it('PASS when AI has RENDERING role in IAMMAI session', () => {
      const ctx = makeIammaiContext(
        [makePresenceRecord('AGENT')],
        'gpt-4o',
        [{ actor_ref: 'bnk:agent:gpt-4o', role: 'RENDERING' }]
      );
      const result = evaluator.evaluate(ctx);
      expect(result.result).toBe('PASS');
    });

    it('FAIL when AI has no FORMALIZATION or RENDERING role in IAMMAI session', () => {
      const ctx = makeIammaiContext(
        [makePresenceRecord('AGENT')],
        'gpt-4o',
        [{ actor_ref: 'bnk:agent:gpt-4o', role: 'TRANSMISSION' }]
      );
      const result = evaluator.evaluate(ctx);
      expect(result.result).toBe('FAIL');
      expect(result.details).toContain('IAMMAI');
      expect(result.details).toContain('FORMALIZATION or RENDERING');
    });

    it('FAIL when no contribution records exist for AI in IAMMAI session', () => {
      const ctx = makeIammaiContext([makePresenceRecord('AGENT')], 'gpt-4o', []);
      const result = evaluator.evaluate(ctx);
      expect(result.result).toBe('FAIL');
    });
  });
});
