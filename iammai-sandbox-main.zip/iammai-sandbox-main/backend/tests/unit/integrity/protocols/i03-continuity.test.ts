/**
 * Unit tests for I.03 Continuity Non-Regression protocol evaluator.
 * @see specs/006-verification-witness
 */

import { describe, it, expect } from 'vitest';
import { I03Continuity } from '../../../../src/integrity/protocols/i03-continuity.js';
import type { EvaluationContext, LedgerEntry, MetadataSnapshot } from '../../../../src/integrity/types.js';
import type { Session } from '../../../../src/lib/types.js';
import { computeEntryHash } from '../../../../src/integrity/hash.js';

const SESSION_ID = 'aaaaaaaa-bbbb-cccc-dddd-eeeeeeeeeeee';
const ADMIN_ID = '11111111-2222-3333-4444-555555555555';

function makeSnapshot(overrides: Partial<MetadataSnapshot> = {}): MetadataSnapshot {
  return {
    session_id: SESSION_ID,
    session_name: 'Test Session',
    state: 'CREATED',
    framework_status: 'OPEN',
    admin_id: ADMIN_ID,
    token_count: 0,
    user_count: 0,
    created_at: '2026-02-14T10:00:00.000Z',
    started_at: null,
    ended_at: null,
    context_descriptor: { topic: 'Test topic' },
    environmental_constraints: { max_participants: 10 },
    ...overrides,
  };
}

function makeSession(): Session {
  return {
    id: SESSION_ID,
    name: 'Test Session',
    state: 'ENDED',
    createdAt: new Date('2026-02-14T10:00:00.000Z'),
    startedAt: new Date('2026-02-14T10:01:00.000Z'),
    endedAt: new Date('2026-02-14T10:30:00.000Z'),
    tokenCount: 1,
    userCount: 1,
    adminId: ADMIN_ID,
    contextDescriptor: { topic: 'Test topic' },
    environmentalConstraints: { max_participants: 10 },
  };
}

function buildMonotonicEntries(): LedgerEntry[] {
  const snapshots = [
    makeSnapshot(),
    makeSnapshot({ state: 'ACTIVE', started_at: '2026-02-14T10:01:00.000Z' }),
    makeSnapshot({ state: 'ENDED', started_at: '2026-02-14T10:01:00.000Z', ended_at: '2026-02-14T10:30:00.000Z', framework_status: 'CLOSED' }),
  ];
  const eventTypes = ['SESSION_CREATED', 'SESSION_ACTIVATED', 'SESSION_CLOSED'] as const;
  const timestamps = [
    '2026-02-14T10:00:00.000Z',
    '2026-02-14T10:01:00.000Z',
    '2026-02-14T10:30:00.000Z',
  ];

  const entries: LedgerEntry[] = [];
  let previousHash: string | null = null;

  for (let i = 0; i < 3; i++) {
    const seq = i + 1;
    const hash = computeEntryHash(previousHash, seq, SESSION_ID, eventTypes[i], timestamps[i]!, snapshots[i]!);
    entries.push({
      id: `entry-${seq}`,
      sequenceNumber: seq,
      sessionId: SESSION_ID,
      eventType: eventTypes[i],
      timestamp: new Date(timestamps[i]!),
      fromState: i === 0 ? null : (['CREATED', 'ACTIVE'] as const)[i - 1],
      toState: snapshots[i]!.state,
      metadataSnapshot: snapshots[i]!,
      previousHash,
      entryHash: hash,
    });
    previousHash = hash;
  }

  return entries;
}

const evaluator = new I03Continuity();

describe('I.03 Continuity Non-Regression evaluator', () => {
  it('has correct protocol id', () => {
    expect(evaluator.id).toBe('I.03');
  });

  it('PASS for monotonic state progression CREATED -> ACTIVE -> ENDED', () => {
    const context: EvaluationContext = {
      session: makeSession(),
      ledgerEntries: buildMonotonicEntries(),
    };
    const result = evaluator.evaluate(context);
    expect(result.result).toBe('PASS');
    expect(result.protocol).toBe('I.03');
  });

  it('FAIL when no transition entries exist', () => {
    const context: EvaluationContext = {
      session: makeSession(),
      ledgerEntries: [],
    };
    const result = evaluator.evaluate(context);
    expect(result.result).toBe('FAIL');
    expect(result.details).toContain('No state transition entries');
  });

  it('FAIL for backward state regression (ACTIVE -> CREATED)', () => {
    const entries = buildMonotonicEntries();
    // Replace the third entry with a backward transition
    entries[2] = {
      ...entries[2]!,
      eventType: 'SESSION_ACTIVATED',
      toState: 'CREATED',
      metadataSnapshot: makeSnapshot({ state: 'CREATED' }),
    };

    const context: EvaluationContext = {
      session: makeSession(),
      ledgerEntries: entries,
    };
    const result = evaluator.evaluate(context);
    expect(result.result).toBe('FAIL');
    expect(result.details).toContain('Non-monotonic');
  });

  it('FAIL when metadata field is erased between entries', () => {
    const entries = buildMonotonicEntries();
    // Erase started_at in the third entry (was set in second)
    entries[2] = {
      ...entries[2]!,
      metadataSnapshot: makeSnapshot({
        state: 'ENDED',
        started_at: null, // was '2026-02-14T10:01:00.000Z' in entry 2
        ended_at: '2026-02-14T10:30:00.000Z',
        framework_status: 'CLOSED',
      }),
    };

    const context: EvaluationContext = {
      session: makeSession(),
      ledgerEntries: entries,
    };
    const result = evaluator.evaluate(context);
    expect(result.result).toBe('FAIL');
    expect(result.details).toContain('Metadata erasure');
    expect(result.details).toContain('started_at');
  });

  it('ignores TRANSITION_REJECTED entries', () => {
    const entries = buildMonotonicEntries();
    // Insert a TRANSITION_REJECTED entry (should be ignored)
    const rejectedEntry: LedgerEntry = {
      id: 'entry-rejected',
      sequenceNumber: 4,
      sessionId: SESSION_ID,
      eventType: 'TRANSITION_REJECTED',
      timestamp: new Date('2026-02-14T10:31:00.000Z'),
      fromState: 'ENDED',
      toState: 'ACTIVE',
      metadataSnapshot: makeSnapshot({ state: 'ENDED' }),
      previousHash: entries[2]!.entryHash,
      entryHash: 'dummy-hash',
    };
    entries.push(rejectedEntry);

    const context: EvaluationContext = {
      session: makeSession(),
      ledgerEntries: entries,
    };
    const result = evaluator.evaluate(context);
    expect(result.result).toBe('PASS');
  });

  it('ignores VERIFICATION_WITNESS entries', () => {
    const entries = buildMonotonicEntries();
    const witnessEntry: LedgerEntry = {
      id: 'entry-witness',
      sequenceNumber: 4,
      sessionId: SESSION_ID,
      eventType: 'VERIFICATION_WITNESS',
      timestamp: new Date('2026-02-14T10:31:00.000Z'),
      fromState: 'ENDED',
      toState: 'ENDED',
      metadataSnapshot: makeSnapshot({ state: 'ENDED' }),
      previousHash: entries[2]!.entryHash,
      entryHash: 'dummy-hash',
    };
    entries.push(witnessEntry);

    const context: EvaluationContext = {
      session: makeSession(),
      ledgerEntries: entries,
    };
    const result = evaluator.evaluate(context);
    expect(result.result).toBe('PASS');
  });
});
