/**
 * Unit tests for I.07 Anti-Acedia protocol evaluator.
 * @see specs/008-governance-protocols/contracts/protocol-evaluators.md
 */

import { describe, it, expect } from 'vitest';
import { I07AntiAcedia } from '../../../../src/integrity/protocols/i07-anti-acedia.js';
import type { EvaluationContext, LedgerEntry } from '../../../../src/integrity/types.js';
import type { Session } from '../../../../src/lib/types.js';

function makeSession(): Session {
  return {
    id: 'aaaaaaaa-bbbb-cccc-dddd-eeeeeeeeeeee',
    name: 'Test Session',
    state: 'ENDED',
    createdAt: new Date('2026-02-14T10:00:00.000Z'),
    startedAt: new Date('2026-02-14T10:01:00.000Z'),
    endedAt: new Date('2026-02-14T10:30:00.000Z'),
    tokenCount: 1,
    userCount: 1,
    adminId: '11111111-2222-3333-4444-555555555555',
    contextDescriptor: { topic: 'Test topic' },
    environmentalConstraints: { max_participants: 10 },
  };
}

function makeEntry(eventType: string, seqNum: number = 1): LedgerEntry {
  return {
    id: `entry-${seqNum}`,
    sequenceNumber: seqNum,
    sessionId: 'aaaaaaaa-bbbb-cccc-dddd-eeeeeeeeeeee',
    eventType: eventType as LedgerEntry['eventType'],
    timestamp: new Date('2026-02-14T10:00:00.000Z'),
    fromState: 'ACTIVE',
    toState: 'ACTIVE',
    metadataSnapshot: {} as LedgerEntry['metadataSnapshot'],
    previousHash: null,
    entryHash: `hash-${seqNum}`,
  };
}

function makeContext(ledgerEntries: LedgerEntry[]): EvaluationContext {
  return {
    session: makeSession(),
    ledgerEntries,
    presenceRecords: [],
    adminActions: [],
    coAgencyActions: [],
  };
}

const evaluator = new I07AntiAcedia();

describe('I.07 Anti-Acedia evaluator', () => {
  it('has correct protocol id and version', () => {
    expect(evaluator.id).toBe('I.07');
    expect(evaluator.version).toBe('1.0.0');
  });

  it('PASS with empty ledger', () => {
    const result = evaluator.evaluate(makeContext([]));
    expect(result.result).toBe('PASS');
    expect(result.details).toBe('No acedia force-release detected — session resolved normally');
  });

  it('PASS with no acedia events', () => {
    const entries = [
      makeEntry('SESSION_CREATED', 1),
      makeEntry('SESSION_ACTIVATED', 2),
      makeEntry('SESSION_CLOSED', 3),
    ];
    const result = evaluator.evaluate(makeContext(entries));
    expect(result.result).toBe('PASS');
    expect(result.details).toBe('No acedia force-release detected — session resolved normally');
  });

  it('PASS with ACEDIA_WARNING only (transient, resolved)', () => {
    const entries = [
      makeEntry('SESSION_CREATED', 1),
      makeEntry('ACEDIA_WARNING', 2),
      makeEntry('SESSION_CLOSED', 3),
    ];
    const result = evaluator.evaluate(makeContext(entries));
    expect(result.result).toBe('PASS');
    expect(result.details).toBe('No acedia force-release detected — session resolved normally');
  });

  it('PASS with ACEDIA_WARNING + ACEDIA_CANCELLED (transient)', () => {
    const entries = [
      makeEntry('SESSION_CREATED', 1),
      makeEntry('ACEDIA_WARNING', 2),
      makeEntry('ACEDIA_CANCELLED', 3),
      makeEntry('SESSION_CLOSED', 4),
    ];
    const result = evaluator.evaluate(makeContext(entries));
    expect(result.result).toBe('PASS');
    expect(result.details).toBe('No acedia force-release detected — session resolved normally');
  });

  it('PASS with ACEDIA_DETECTION + ACEDIA_CANCELLED (countdown cancelled)', () => {
    const entries = [
      makeEntry('SESSION_ACTIVATED', 1),
      makeEntry('ACEDIA_DETECTION', 2),
      makeEntry('ACEDIA_CANCELLED', 3),
      makeEntry('SESSION_CLOSED', 4),
    ];
    const result = evaluator.evaluate(makeContext(entries));
    expect(result.result).toBe('PASS');
  });

  it('FAIL with ACEDIA_FORCE_RELEASE', () => {
    const entries = [
      makeEntry('SESSION_ACTIVATED', 1),
      makeEntry('ACEDIA_DETECTION', 2),
      makeEntry('ACEDIA_FORCE_RELEASE', 3),
    ];
    const result = evaluator.evaluate(makeContext(entries));
    expect(result.result).toBe('FAIL');
    expect(result.details).toBe('Session was force-released due to unresolved acedia — anti-acedia protocol violated');
  });

  it('FAIL detail message matches contract exactly', () => {
    const entries = [makeEntry('ACEDIA_FORCE_RELEASE', 1)];
    const result = evaluator.evaluate(makeContext(entries));
    expect(result.protocol).toBe('I.07');
    expect(result.result).toBe('FAIL');
    expect(result.details).toBe('Session was force-released due to unresolved acedia — anti-acedia protocol violated');
  });

  it('is deterministic — same input produces same output', () => {
    const entries = [makeEntry('SESSION_CREATED', 1)];
    const r1 = evaluator.evaluate(makeContext(entries));
    const r2 = evaluator.evaluate(makeContext(entries));
    expect(r1.result).toBe(r2.result);
    expect(r1.details).toBe(r2.details);
  });
});
