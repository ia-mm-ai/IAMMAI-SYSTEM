/**
 * Unit tests for participant presence attestation on token join.
 * @see specs/007-presence-suppression/tasks.md T012
 */

import { describe, it, expect } from 'vitest';
import { derivePresenceHash, isValidPresenceHash } from '../../../../src/services/presence.js';

describe('Participant presence on token join', () => {
  it('derives valid presence hash from seed', () => {
    const hash = derivePresenceHash('test-seed-1234');
    expect(isValidPresenceHash(hash)).toBe(true);
    expect(hash).toHaveLength(8);
    expect(hash).toMatch(/^[0-9a-f]{8}$/);
  });

  it('different seeds produce different presence hashes', () => {
    const hash1 = derivePresenceHash('seed-user-1');
    const hash2 = derivePresenceHash('seed-user-2');
    const hash3 = derivePresenceHash('seed-user-3');

    expect(hash1).not.toBe(hash2);
    expect(hash2).not.toBe(hash3);
    expect(hash1).not.toBe(hash3);
  });

  it('same seed produces same presence hash (idempotent join)', () => {
    const hash1 = derivePresenceHash('same-seed');
    const hash2 = derivePresenceHash('same-seed');
    expect(hash1).toBe(hash2);
  });

  it('PARTICIPANT role is used for user presence', () => {
    const role = 'PARTICIPANT';
    expect(role).toBe('PARTICIPANT');
  });

  it('JOIN_TOKEN method is used for participant presence', () => {
    const method = 'JOIN_TOKEN';
    expect(method).toBe('JOIN_TOKEN');
  });
});
