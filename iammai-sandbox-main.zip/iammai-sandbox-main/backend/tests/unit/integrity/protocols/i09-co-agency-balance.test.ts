/**
 * Unit tests for I.09 Co-Agency Balance protocol evaluator.
 * @see specs/008-governance-protocols/contracts/protocol-evaluators.md
 */

import { describe, it, expect } from 'vitest';
import { I09CoAgencyBalance } from '../../../../src/integrity/protocols/i09-co-agency-balance.js';
import type { EvaluationContext, IrreversibleAction } from '../../../../src/integrity/types.js';

const evaluator = new I09CoAgencyBalance();

function makeContext(actions: IrreversibleAction[]): EvaluationContext {
  return {
    session: {} as EvaluationContext['session'],
    ledgerEntries: [],
    presenceRecords: [],
    adminActions: [],
    coAgencyActions: actions,
  };
}

function makeAction(
  agentType: 'HUMAN' | 'MACHINE',
  actionType: 'SESSION_END' | 'PRESENCE_FINALIZATION' | 'VERIFICATION_EXECUTION',
  offsetMs = 0
): IrreversibleAction {
  return {
    sessionId: 'test-session',
    agentType,
    actionType,
    timestamp: new Date(Date.now() + offsetMs),
  };
}

describe('I09CoAgencyBalance', () => {
  it('has correct id and version', () => {
    expect(evaluator.id).toBe('I.09');
    expect(evaluator.version).toBe('1.0.0');
  });

  it('PASS with empty history', () => {
    const result = evaluator.evaluate(makeContext([]));
    expect(result.result).toBe('PASS');
    expect(result.details).toBe('Co-agency balance maintained — no irreversible actions recorded');
    expect(result.protocol).toBe('I.09');
  });

  it('PASS with single HUMAN action', () => {
    const result = evaluator.evaluate(makeContext([
      makeAction('HUMAN', 'SESSION_END'),
    ]));
    expect(result.result).toBe('PASS');
  });

  it('PASS with exactly 2 consecutive HUMAN actions (limit not exceeded)', () => {
    const result = evaluator.evaluate(makeContext([
      makeAction('HUMAN', 'SESSION_END', 0),
      makeAction('HUMAN', 'SESSION_END', 1),
    ]));
    expect(result.result).toBe('PASS');
    expect(result.details).toBe('Co-agency balance maintained — no agent type exceeded 2 consecutive irreversible actions');
  });

  it('FAIL with 3 consecutive MACHINE actions', () => {
    const result = evaluator.evaluate(makeContext([
      makeAction('MACHINE', 'PRESENCE_FINALIZATION', 0),
      makeAction('MACHINE', 'VERIFICATION_EXECUTION', 1),
      makeAction('MACHINE', 'PRESENCE_FINALIZATION', 2),
    ]));
    expect(result.result).toBe('FAIL');
    expect(result.details).toBe('Co-agency balance violated: MACHINE performed 3 consecutive irreversible actions (max 2)');
  });

  it('FAIL with 3 consecutive HUMAN actions', () => {
    const result = evaluator.evaluate(makeContext([
      makeAction('HUMAN', 'SESSION_END', 0),
      makeAction('HUMAN', 'SESSION_END', 1),
      makeAction('HUMAN', 'SESSION_END', 2),
    ]));
    expect(result.result).toBe('FAIL');
    expect(result.details).toContain('HUMAN performed 3 consecutive irreversible actions');
  });

  it('PASS with alternating HUMAN and MACHINE actions', () => {
    const result = evaluator.evaluate(makeContext([
      makeAction('HUMAN', 'SESSION_END', 0),
      makeAction('MACHINE', 'PRESENCE_FINALIZATION', 1),
      makeAction('MACHINE', 'VERIFICATION_EXECUTION', 2),
      makeAction('HUMAN', 'SESSION_END', 3),
    ]));
    expect(result.result).toBe('PASS');
  });

  it('PASS with typical session close sequence (HUMAN×1, MACHINE×2)', () => {
    const result = evaluator.evaluate(makeContext([
      makeAction('HUMAN', 'SESSION_END', 0),
      makeAction('MACHINE', 'PRESENCE_FINALIZATION', 1),
      makeAction('MACHINE', 'VERIFICATION_EXECUTION', 2),
    ]));
    expect(result.result).toBe('PASS');
  });

  it('FAIL detail message includes agent type and count', () => {
    const result = evaluator.evaluate(makeContext([
      makeAction('MACHINE', 'PRESENCE_FINALIZATION', 0),
      makeAction('MACHINE', 'VERIFICATION_EXECUTION', 1),
      makeAction('MACHINE', 'PRESENCE_FINALIZATION', 2),
    ]));
    expect(result.result).toBe('FAIL');
    expect(result.details).toContain('MACHINE');
    expect(result.details).toContain('3');
    expect(result.details).toContain('max 2');
  });

  it('FAIL stops at first violation found in history', () => {
    const result = evaluator.evaluate(makeContext([
      makeAction('HUMAN', 'SESSION_END', 0),
      makeAction('HUMAN', 'SESSION_END', 1),
      makeAction('HUMAN', 'SESSION_END', 2), // violation here
      makeAction('MACHINE', 'PRESENCE_FINALIZATION', 3),
    ]));
    expect(result.result).toBe('FAIL');
    expect(result.details).toContain('HUMAN');
  });

  it('PASS with coAgencyActions undefined treated as empty', () => {
    const context = makeContext([]);
    // Simulate undefined by casting (edge case robustness)
    (context as any).coAgencyActions = undefined;
    const result = evaluator.evaluate(context);
    expect(result.result).toBe('PASS');
  });
});
