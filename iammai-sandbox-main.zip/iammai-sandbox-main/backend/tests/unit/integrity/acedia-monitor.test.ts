/**
 * Unit tests for the acedia monitor.
 * @see specs/008-governance-protocols/contracts/acedia-monitor.md
 */

import { describe, it, expect, beforeEach, afterEach, vi } from 'vitest';

// Mock all DB/model dependencies before importing the module
vi.mock('../../../src/lib/db.js', () => ({
  query: vi.fn(),
  transaction: vi.fn(),
}));

vi.mock('../../../src/models/session.js', () => ({
  transitionState: vi.fn(),
  findById: vi.fn(),
}));

vi.mock('../../../src/integrity/ledger.js', () => ({
  appendEntry: vi.fn(),
}));

vi.mock('../../../src/integrity/state-observer.js', () => ({
  buildMetadataSnapshot: vi.fn().mockReturnValue({}),
}));

vi.mock('../../../src/lib/logger.js', () => ({
  logger: {
    info: vi.fn(),
    warn: vi.fn(),
    error: vi.fn(),
  },
}));

import {
  startMonitor,
  stopMonitor,
  checkSessions,
  recordActivity,
  getAcediaState,
  clearSession,
} from '../../../src/integrity/acedia-monitor.js';

import * as db from '../../../src/lib/db.js';
import * as sessionModel from '../../../src/models/session.js';

const SESSION_ID = 'aaaaaaaa-bbbb-cccc-dddd-eeeeeeeeeeee';

function makeSessionRow(state: 'CREATED' | 'ACTIVE' = 'ACTIVE') {
  return {
    id: SESSION_ID,
    state,
    name: 'Test Session',
    created_at: new Date('2026-02-14T10:00:00.000Z'),
    started_at: state === 'ACTIVE' ? new Date('2026-02-14T10:01:00.000Z') : null,
    ended_at: null,
    token_count: 0,
    user_count: 1,
    admin_id: 'admin-1',
    context_descriptor: { topic: 'Test' },
    environmental_constraints: { max_participants: 10 },
  };
}

function makeSession(state: 'CREATED' | 'ACTIVE' | 'ENDED' = 'ACTIVE') {
  return {
    id: SESSION_ID,
    name: 'Test Session',
    state,
    createdAt: new Date('2026-02-14T10:00:00.000Z'),
    startedAt: state !== 'CREATED' ? new Date('2026-02-14T10:01:00.000Z') : null,
    endedAt: state === 'ENDED' ? new Date('2026-02-14T10:30:00.000Z') : null,
    tokenCount: 0,
    userCount: 1,
    adminId: 'admin-1',
    contextDescriptor: { topic: 'Test' },
    environmentalConstraints: { max_participants: 10 },
  };
}

describe('Acedia monitor — startMonitor/stopMonitor', () => {
  afterEach(() => {
    stopMonitor();
    clearSession(SESSION_ID);
    vi.clearAllMocks();
  });

  it('startMonitor is idempotent — second call has no effect', () => {
    const SHORT_THRESHOLDS = {
      checkIntervalMs: 60 * 60 * 1000, // 1 hour (won't fire in test)
    };
    startMonitor(SHORT_THRESHOLDS);
    startMonitor(SHORT_THRESHOLDS); // Should not throw or create second interval
    stopMonitor();
    // No assertion needed — just verifying no error thrown
    expect(true).toBe(true);
  });

  it('stopMonitor is idempotent — calling when not running is safe', () => {
    stopMonitor(); // Should not throw
    expect(true).toBe(true);
  });
});

describe('Acedia monitor — checkSessions', () => {
  beforeEach(() => {
    clearSession(SESSION_ID);
    vi.clearAllMocks();

    // Default: transaction executes callback
    vi.mocked(db.transaction).mockImplementation(async (cb) => {
      const mockClient = { query: vi.fn().mockResolvedValue({ rows: [] }) };
      return cb(mockClient as unknown as Parameters<typeof cb>[0]);
    });
  });

  afterEach(() => {
    clearSession(SESSION_ID);
    stopMonitor();
  });

  it('NORMAL → WARNING for CREATED session idle > 15min', async () => {
    const now = new Date();
    const createdAt = new Date(now.getTime() - 16 * 60 * 1000); // 16 minutes ago

    const row = {
      ...makeSessionRow('CREATED'),
      created_at: createdAt,
      started_at: null,
    };

    vi.mocked(db.query).mockResolvedValueOnce({ rows: [row] } as Awaited<ReturnType<typeof db.query>>);

    // Short thresholds for test
    startMonitor({ createdIdleMs: 15 * 60 * 1000, activeIdleMs: 30 * 60 * 1000, countdownMs: 10 * 60 * 1000, checkIntervalMs: 60 * 60 * 1000 });

    await checkSessions();

    const state = getAcediaState(SESSION_ID);
    expect(state?.phase).toBe('WARNING');
    expect(db.transaction).toHaveBeenCalled();
  });

  it('NORMAL → DETECTION for ACTIVE session idle > 30min', async () => {
    const now = new Date();
    const startedAt = new Date(now.getTime() - 31 * 60 * 1000); // 31 minutes ago

    const row = {
      ...makeSessionRow('ACTIVE'),
      started_at: startedAt,
    };

    vi.mocked(db.query).mockResolvedValueOnce({ rows: [row] } as Awaited<ReturnType<typeof db.query>>);

    startMonitor({ createdIdleMs: 15 * 60 * 1000, activeIdleMs: 30 * 60 * 1000, countdownMs: 10 * 60 * 1000, checkIntervalMs: 60 * 60 * 1000 });

    await checkSessions();

    const state = getAcediaState(SESSION_ID);
    expect(state?.phase).toBe('DETECTION');
    expect(state?.countdownStartedAt).not.toBeNull();
    expect(db.transaction).toHaveBeenCalled();
  });

  it('COUNTDOWN → FORCE_RELEASE when countdown expired', async () => {
    // Pre-set session in COUNTDOWN phase with expired countdown
    const now = new Date();
    const countdownStartedAt = new Date(now.getTime() - 11 * 60 * 1000); // 11 minutes ago

    // Manually set acedia state to COUNTDOWN phase
    recordActivity(SESSION_ID); // Initialize state
    const state = getAcediaState(SESSION_ID)!;
    state.phase = 'DETECTION';
    state.countdownStartedAt = countdownStartedAt;

    const row = makeSessionRow('ACTIVE');
    vi.mocked(db.query).mockResolvedValueOnce({ rows: [row] } as Awaited<ReturnType<typeof db.query>>);

    // transitionState returns the updated session
    vi.mocked(sessionModel.transitionState).mockResolvedValueOnce(makeSession('ENDED') as Awaited<ReturnType<typeof sessionModel.transitionState>>);

    startMonitor({ createdIdleMs: 15 * 60 * 1000, activeIdleMs: 30 * 60 * 1000, countdownMs: 10 * 60 * 1000, checkIntervalMs: 60 * 60 * 1000 });

    await checkSessions();

    // Session should be cleared from tracking after force-release
    expect(getAcediaState(SESSION_ID)).toBeUndefined();
    expect(sessionModel.transitionState).toHaveBeenCalledWith(SESSION_ID, 'ACTIVE', 'ENDED', expect.anything());
  });

  it('skips sessions not in query results (already closed)', async () => {
    vi.mocked(db.query).mockResolvedValueOnce({ rows: [] } as Awaited<ReturnType<typeof db.query>>);

    startMonitor({ checkIntervalMs: 60 * 60 * 1000 });
    await checkSessions();

    expect(sessionModel.transitionState).not.toHaveBeenCalled();
    expect(db.transaction).not.toHaveBeenCalled();
  });
});

describe('Acedia monitor — recordActivity', () => {
  beforeEach(() => {
    clearSession(SESSION_ID);
    vi.clearAllMocks();

    vi.mocked(db.transaction).mockImplementation(async (cb) => {
      const mockClient = { query: vi.fn().mockResolvedValue({ rows: [] }) };
      return cb(mockClient as unknown as Parameters<typeof cb>[0]);
    });

    vi.mocked(sessionModel.findById).mockResolvedValue(makeSession('ACTIVE') as Awaited<ReturnType<typeof sessionModel.findById>>);
  });

  afterEach(() => {
    clearSession(SESSION_ID);
  });

  it('initializes tracking on first call', () => {
    recordActivity(SESSION_ID);
    const state = getAcediaState(SESSION_ID);
    expect(state).toBeDefined();
    expect(state?.phase).toBe('NORMAL');
    expect(state?.sessionId).toBe(SESSION_ID);
  });

  it('updates lastActivityAt on activity', () => {
    recordActivity(SESSION_ID);
    const before = getAcediaState(SESSION_ID)?.lastActivityAt.getTime();

    // Small delay to ensure time changes
    const later = new Date(Date.now() + 1000);
    const state = getAcediaState(SESSION_ID)!;
    state.lastActivityAt = new Date(Date.now() - 5000); // Set to 5s ago

    recordActivity(SESSION_ID);
    const after = getAcediaState(SESSION_ID)?.lastActivityAt.getTime();
    expect(after).toBeGreaterThanOrEqual(before! - 5000);
  });

  it('resets DETECTION phase to NORMAL and records ACEDIA_CANCELLED', async () => {
    recordActivity(SESSION_ID);
    const state = getAcediaState(SESSION_ID)!;
    state.phase = 'DETECTION';
    state.countdownStartedAt = new Date();

    recordActivity(SESSION_ID);

    expect(state.phase).toBe('NORMAL');
    expect(state.countdownStartedAt).toBeNull();
  });

  it('resets COUNTDOWN phase to NORMAL', () => {
    recordActivity(SESSION_ID);
    const state = getAcediaState(SESSION_ID)!;
    state.phase = 'COUNTDOWN';
    state.countdownStartedAt = new Date();

    recordActivity(SESSION_ID);

    expect(state.phase).toBe('NORMAL');
    expect(state.countdownStartedAt).toBeNull();
  });

  it('resets WARNING phase to NORMAL', () => {
    recordActivity(SESSION_ID);
    const state = getAcediaState(SESSION_ID)!;
    state.phase = 'WARNING';

    recordActivity(SESSION_ID);

    expect(state.phase).toBe('NORMAL');
  });

  it('NORMAL phase remains NORMAL on activity', () => {
    recordActivity(SESSION_ID);
    recordActivity(SESSION_ID);
    const state = getAcediaState(SESSION_ID);
    expect(state?.phase).toBe('NORMAL');
  });
});

describe('Acedia monitor — getAcediaState / clearSession', () => {
  it('returns undefined for unknown session', () => {
    expect(getAcediaState('unknown-session')).toBeUndefined();
  });

  it('clearSession removes tracking', () => {
    recordActivity(SESSION_ID);
    expect(getAcediaState(SESSION_ID)).toBeDefined();
    clearSession(SESSION_ID);
    expect(getAcediaState(SESSION_ID)).toBeUndefined();
  });

  it('clearSession for unknown session is a no-op', () => {
    clearSession('nonexistent'); // Should not throw
    expect(true).toBe(true);
  });
});
