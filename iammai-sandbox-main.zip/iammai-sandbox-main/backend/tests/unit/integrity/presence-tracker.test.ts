/**
 * Unit tests for the presence tracker.
 * @see specs/007-presence-suppression/contracts/presence-tracker.md
 */

import { describe, it, expect, vi, beforeEach } from 'vitest';
import { buildPresenceSummaryFromRecords } from '../../../src/integrity/presence-tracker.js';
import type { PresenceRecord, PresenceSummary } from '../../../src/integrity/types.js';

function makeRecord(overrides: Partial<PresenceRecord> = {}): PresenceRecord {
  return {
    id: 'rec-1',
    sessionId: 'session-1',
    role: 'CREATOR',
    presenceHash: 'a1b2c3d4',
    attestationMethod: 'AUTH_EVENT',
    attested: true,
    finalized: false,
    createdAt: new Date('2026-02-14T10:00:00.000Z'),
    finalizedAt: null,
    ...overrides,
  };
}

describe('Presence tracker — buildPresenceSummaryFromRecords', () => {
  it('builds summary with admin only', () => {
    const records = [makeRecord()];
    const summary = buildPresenceSummaryFromRecords(records);

    expect(summary.admin.attested).toBe(true);
    expect(summary.admin.method).toBe('AUTH_EVENT');
    expect(summary.admin.hash).toBe('a1b2c3d4');
    expect(summary.participants).toHaveLength(0);
    expect(summary.agents).toHaveLength(0);
    expect(summary.total_attestation_methods).toBe(1);
    expect(summary.finalized).toBe(false);
  });

  it('builds summary with all three actor types', () => {
    const records = [
      makeRecord({ role: 'CREATOR', attestationMethod: 'AUTH_EVENT', presenceHash: 'admin123' }),
      makeRecord({ id: 'rec-2', role: 'PARTICIPANT', attestationMethod: 'JOIN_TOKEN', presenceHash: 'user1234' }),
      makeRecord({ id: 'rec-3', role: 'AGENT', attestationMethod: 'MESSAGE_PROCESSING', presenceHash: 'ai-agent' }),
    ];
    const summary = buildPresenceSummaryFromRecords(records);

    expect(summary.admin.attested).toBe(true);
    expect(summary.participants).toHaveLength(1);
    expect(summary.participants[0]!.hash).toBe('user1234');
    expect(summary.agents).toHaveLength(1);
    expect(summary.agents[0]!.hash).toBe('ai-agent');
    expect(summary.total_attestation_methods).toBe(3);
  });

  it('counts distinct attestation methods correctly', () => {
    const records = [
      makeRecord({ role: 'CREATOR', attestationMethod: 'AUTH_EVENT', presenceHash: 'admin1' }),
      makeRecord({ id: 'rec-2', role: 'PARTICIPANT', attestationMethod: 'JOIN_TOKEN', presenceHash: 'user1' }),
      makeRecord({ id: 'rec-3', role: 'PARTICIPANT', attestationMethod: 'JOIN_TOKEN', presenceHash: 'user2' }),
    ];
    const summary = buildPresenceSummaryFromRecords(records);

    // AUTH_EVENT + JOIN_TOKEN = 2 distinct methods (not 3)
    expect(summary.total_attestation_methods).toBe(2);
  });

  it('groups multiple participants', () => {
    const records = [
      makeRecord({ role: 'PARTICIPANT', attestationMethod: 'JOIN_TOKEN', presenceHash: 'u1' }),
      makeRecord({ id: 'rec-2', role: 'PARTICIPANT', attestationMethod: 'JOIN_TOKEN', presenceHash: 'u2' }),
      makeRecord({ id: 'rec-3', role: 'PARTICIPANT', attestationMethod: 'JOIN_TOKEN', presenceHash: 'u3' }),
    ];
    const summary = buildPresenceSummaryFromRecords(records);

    expect(summary.participants).toHaveLength(3);
    expect(summary.admin.attested).toBe(false);
  });

  it('reports finalized=true when all records are finalized', () => {
    const records = [
      makeRecord({ finalized: true, finalizedAt: new Date() }),
      makeRecord({ id: 'rec-2', role: 'PARTICIPANT', attestationMethod: 'JOIN_TOKEN', presenceHash: 'u1', finalized: true, finalizedAt: new Date() }),
    ];
    const summary = buildPresenceSummaryFromRecords(records);

    expect(summary.finalized).toBe(true);
  });

  it('reports finalized=false when any record is not finalized', () => {
    const records = [
      makeRecord({ finalized: true, finalizedAt: new Date() }),
      makeRecord({ id: 'rec-2', role: 'PARTICIPANT', attestationMethod: 'JOIN_TOKEN', presenceHash: 'u1', finalized: false }),
    ];
    const summary = buildPresenceSummaryFromRecords(records);

    expect(summary.finalized).toBe(false);
  });

  it('handles empty records', () => {
    const summary = buildPresenceSummaryFromRecords([]);

    expect(summary.admin.attested).toBe(false);
    expect(summary.participants).toHaveLength(0);
    expect(summary.agents).toHaveLength(0);
    expect(summary.total_attestation_methods).toBe(0);
    expect(summary.finalized).toBe(false);
  });

  it('is deterministic — same input produces same output', () => {
    const records = [
      makeRecord({ role: 'CREATOR', attestationMethod: 'AUTH_EVENT', presenceHash: 'admin1' }),
      makeRecord({ id: 'rec-2', role: 'PARTICIPANT', attestationMethod: 'JOIN_TOKEN', presenceHash: 'user1' }),
    ];

    const summary1 = buildPresenceSummaryFromRecords(records);
    const summary2 = buildPresenceSummaryFromRecords(records);

    expect(summary1).toEqual(summary2);
  });
});
