import { describe, it, expect, vi, beforeEach } from 'vitest';
import { buildMetadataSnapshot } from '../../../src/integrity/state-observer.js';
import { frameworkStatus } from '../../../src/integrity/types.js';
import type { Session, SessionState } from '../../../src/lib/types.js';

function makeSession(overrides: Partial<Session> = {}): Session {
  return {
    id: 'aaaaaaaa-bbbb-cccc-dddd-eeeeeeeeeeee',
    name: 'Test Session',
    state: 'CREATED',
    createdAt: new Date('2026-02-14T10:00:00.000Z'),
    startedAt: null,
    endedAt: null,
    tokenCount: 0,
    userCount: 0,
    adminId: '11111111-2222-3333-4444-555555555555',
    contextDescriptor: { topic: 'Test topic' },
    environmentalConstraints: { max_participants: 10 },
    ...overrides,
  };
}

describe('buildMetadataSnapshot', () => {
  it('captures all session metadata fields', () => {
    const session = makeSession();
    const snapshot = buildMetadataSnapshot(session);

    expect(snapshot.session_id).toBe(session.id);
    expect(snapshot.session_name).toBe(session.name);
    expect(snapshot.state).toBe('CREATED');
    expect(snapshot.framework_status).toBe('OPEN');
    expect(snapshot.admin_id).toBe(session.adminId);
    expect(snapshot.token_count).toBe(0);
    expect(snapshot.user_count).toBe(0);
    expect(snapshot.created_at).toBe('2026-02-14T10:00:00.000Z');
    expect(snapshot.started_at).toBeNull();
    expect(snapshot.ended_at).toBeNull();
    expect(snapshot.context_descriptor).toEqual({ topic: 'Test topic' });
    expect(snapshot.environmental_constraints).toEqual({ max_participants: 10 });
  });

  it('preserves all prior state data when session is ACTIVE (additive)', () => {
    const session = makeSession({
      state: 'ACTIVE',
      startedAt: new Date('2026-02-14T10:05:00.000Z'),
    });
    const snapshot = buildMetadataSnapshot(session);

    expect(snapshot.state).toBe('ACTIVE');
    expect(snapshot.framework_status).toBe('OPEN');
    expect(snapshot.created_at).toBe('2026-02-14T10:00:00.000Z');
    expect(snapshot.started_at).toBe('2026-02-14T10:05:00.000Z');
    expect(snapshot.ended_at).toBeNull();
  });

  it('preserves all prior state data when session is ENDED (additive)', () => {
    const session = makeSession({
      state: 'ENDED',
      startedAt: new Date('2026-02-14T10:05:00.000Z'),
      endedAt: new Date('2026-02-14T10:30:00.000Z'),
      tokenCount: 5,
      userCount: 3,
    });
    const snapshot = buildMetadataSnapshot(session);

    expect(snapshot.state).toBe('ENDED');
    expect(snapshot.framework_status).toBe('CLOSED');
    expect(snapshot.created_at).toBe('2026-02-14T10:00:00.000Z');
    expect(snapshot.started_at).toBe('2026-02-14T10:05:00.000Z');
    expect(snapshot.ended_at).toBe('2026-02-14T10:30:00.000Z');
    expect(snapshot.token_count).toBe(5);
    expect(snapshot.user_count).toBe(3);
  });

  it('does not include any message content or ephemeral data', () => {
    const session = makeSession();
    const snapshot = buildMetadataSnapshot(session);

    const snapshotStr = JSON.stringify(snapshot);
    // Ensure no ephemeral data fields exist
    expect(snapshot).not.toHaveProperty('messages');
    expect(snapshot).not.toHaveProperty('conversations');
    expect(snapshot).not.toHaveProperty('content');
    expect(snapshot).not.toHaveProperty('tokenHash');
    expect(snapshot).not.toHaveProperty('presenceHash');
  });
});

describe('frameworkStatus', () => {
  it('maps CREATED to OPEN', () => {
    expect(frameworkStatus('CREATED')).toBe('OPEN');
  });

  it('maps ACTIVE to OPEN', () => {
    expect(frameworkStatus('ACTIVE')).toBe('OPEN');
  });

  it('maps ENDED to CLOSED', () => {
    expect(frameworkStatus('ENDED')).toBe('CLOSED');
  });
});
