/**
 * Unit tests for the compliance checker module.
 * @see specs/009-compliance-test/spec.md
 * @see specs/009-compliance-test/contracts/compliance-module.ts
 */

import { describe, it, expect, vi, beforeEach } from 'vitest';
import type {
  LedgerEntry,
  PresenceRecord,
  ConditionEvaluation,
} from '../../../src/integrity/types.js';
import type { Session } from '../../../src/lib/types.js';

// ============================================================================
// Mocks
// ============================================================================

vi.mock('../../../src/lib/db.js', () => ({
  query: vi.fn(),
}));

vi.mock('../../../src/integrity/ledger.js', () => ({
  getEntriesBySession: vi.fn(),
  validateChain: vi.fn(),
}));

vi.mock('../../../src/integrity/presence-tracker.js', () => ({
  getPresenceRecords: vi.fn(),
}));

vi.mock('../../../src/integrity/verification-engine.js', () => ({
  verify: vi.fn(),
}));

import { query } from '../../../src/lib/db.js';
import { getEntriesBySession, validateChain } from '../../../src/integrity/ledger.js';
import { getPresenceRecords } from '../../../src/integrity/presence-tracker.js';
import { verify } from '../../../src/integrity/verification-engine.js';

import {
  evaluateTruthFinalization,
  evaluateDeterministicVerification,
  evaluateMandatorySuppression,
  evaluateHistoryNonRegression,
  evaluateAuthorityNonAssertion,
  runComplianceCheck,
  runConditionCheck,
} from '../../../src/integrity/compliance-checker.js';

const mockQuery = vi.mocked(query);
const mockGetEntriesBySession = vi.mocked(getEntriesBySession);
const mockValidateChain = vi.mocked(validateChain);
const mockGetPresenceRecords = vi.mocked(getPresenceRecords);
const mockVerify = vi.mocked(verify);

// ============================================================================
// Test Factories
// ============================================================================

function makeSession(overrides: Partial<Session> = {}): Session {
  return {
    id: 'sess-001',
    name: 'Test Session',
    state: 'ENDED',
    adminId: 'admin-001',
    createdAt: new Date('2026-01-01T10:00:00Z'),
    startedAt: new Date('2026-01-01T10:01:00Z'),
    endedAt: new Date('2026-01-01T11:00:00Z'),
    contextDescriptor: { topic: 'test' },
    environmentalConstraints: { max_participants: 5 },
    tokenCount: 10,
    userCount: 2,
    ...overrides,
  } as unknown as Session;
}

function makePresenceRecord(overrides: Partial<PresenceRecord> = {}): PresenceRecord {
  return {
    id: 'pr-001',
    sessionId: 'sess-001',
    role: 'CREATOR',
    presenceHash: 'hash-abc',
    attestationMethod: 'AUTH_EVENT',
    attested: true,
    finalized: true,
    createdAt: new Date('2026-01-01T10:01:00Z'),
    finalizedAt: new Date('2026-01-01T11:01:00Z'),
    ...overrides,
  };
}

function makeLedgerEntry(overrides: Partial<LedgerEntry> = {}): LedgerEntry {
  return {
    id: 'entry-001',
    sequenceNumber: 1,
    sessionId: 'sess-001',
    eventType: 'SESSION_CREATED',
    timestamp: new Date('2026-01-01T10:00:00Z'),
    fromState: null,
    toState: 'CREATED',
    metadataSnapshot: {} as LedgerEntry['metadataSnapshot'],
    previousHash: null,
    entryHash: 'hash-001',
    ...overrides,
  };
}

function makeWitnessEntry(passFail: 'PASS' | 'FAIL', seq = 5): LedgerEntry {
  return makeLedgerEntry({
    id: `witness-${seq}`,
    sequenceNumber: seq,
    eventType: 'VERIFICATION_WITNESS',
    toState: 'ENDED',
    metadataSnapshot: { pass_fail: passFail } as unknown as LedgerEntry['metadataSnapshot'],
  });
}

function makeSuppressionEntry(seq = 6): LedgerEntry {
  return makeLedgerEntry({
    id: `suppression-${seq}`,
    sequenceNumber: seq,
    eventType: 'SUPPRESSION_EVENT',
    toState: 'ENDED',
  });
}

function makeValidChainResult() {
  return {
    valid: true,
    totalEntries: 0,
    validatedEntries: 0,
    firstBrokenEntry: null,
    errors: [],
  };
}

// ============================================================================
// Condition 1: Truth Finalization
// ============================================================================

describe('evaluateTruthFinalization', () => {
  it('returns PASS when all records finalized after session closure', async () => {
    const session = makeSession();
    const record = makePresenceRecord({
      finalized: true,
      finalizedAt: new Date('2026-01-01T11:01:00Z'), // after endedAt
    });

    const result = await evaluateTruthFinalization([
      { session, ledgerEntries: [], presenceRecords: [record] },
    ]);

    expect(result.condition).toBe('TRUTH_FINALIZATION');
    expect(result.result).toBe('PASS');
    expect(result.evidence).toHaveLength(0);
  });

  it('returns FAIL when unfinalized records exist on ENDED session', async () => {
    const session = makeSession();
    const record = makePresenceRecord({ finalized: false, finalizedAt: null });

    const result = await evaluateTruthFinalization([
      { session, ledgerEntries: [], presenceRecords: [record] },
    ]);

    expect(result.result).toBe('FAIL');
    expect(result.evidence).toHaveLength(1);
    expect(result.evidence[0].type).toBe('PRESENCE_RECORD');
  });

  it('returns FAIL when finalizedAt precedes session endedAt', async () => {
    const session = makeSession({ endedAt: new Date('2026-01-01T11:00:00Z') });
    const record = makePresenceRecord({
      finalized: true,
      finalizedAt: new Date('2026-01-01T10:30:00Z'), // BEFORE endedAt
    });

    const result = await evaluateTruthFinalization([
      { session, ledgerEntries: [], presenceRecords: [record] },
    ]);

    expect(result.result).toBe('FAIL');
    expect(result.evidence[0].description).toMatch(/before session closure/);
  });

  it('returns vacuous PASS when no ENDED sessions exist', async () => {
    const result = await evaluateTruthFinalization([]);

    expect(result.result).toBe('PASS');
    expect(result.evidence).toHaveLength(0);
  });
});

// ============================================================================
// Condition 2: Deterministic Witnessed Verification
// ============================================================================

describe('evaluateDeterministicVerification', () => {
  beforeEach(() => {
    mockVerify.mockReturnValue({
      pass: true,
      protocolResults: [],
      timestamp: new Date(),
    });
  });

  it('returns PASS when all sessions have witness entries and re-verification matches', async () => {
    const session = makeSession();
    const witness = makeWitnessEntry('PASS');

    const result = await evaluateDeterministicVerification([
      { session, ledgerEntries: [witness], presenceRecords: [] },
    ]);

    expect(result.result).toBe('PASS');
    expect(result.evidence).toHaveLength(0);
  });

  it('returns FAIL when a session lacks VERIFICATION_WITNESS entry', async () => {
    const session = makeSession();

    const result = await evaluateDeterministicVerification([
      { session, ledgerEntries: [], presenceRecords: [] },
    ]);

    expect(result.result).toBe('FAIL');
    expect(result.evidence[0].type).toBe('WITNESS_ARTIFACT');
    expect(result.evidence[0].description).toMatch(/no VERIFICATION_WITNESS/);
  });

  it('returns FAIL when re-verification produces different result than stored witness', async () => {
    const session = makeSession();
    const witness = makeWitnessEntry('PASS'); // stored says PASS

    // But re-run returns FAIL
    mockVerify.mockReturnValueOnce({ pass: false, protocolResults: [], timestamp: new Date() });

    const result = await evaluateDeterministicVerification([
      { session, ledgerEntries: [witness], presenceRecords: [] },
    ]);

    expect(result.result).toBe('FAIL');
    expect(result.evidence[0].description).toMatch(/differs from stored witness/);
  });

  it('returns vacuous PASS when no ENDED sessions exist', async () => {
    const result = await evaluateDeterministicVerification([]);
    expect(result.result).toBe('PASS');
  });
});

// ============================================================================
// Condition 3: Mandatory Suppression
// ============================================================================

describe('evaluateMandatorySuppression', () => {
  it('returns PASS when all FAILs have suppression events and no post-suppression mutations', async () => {
    const session = makeSession();
    const witness = makeWitnessEntry('FAIL', 5);
    const suppression = makeSuppressionEntry(6);
    const sessionClosed = makeLedgerEntry({
      id: 'close-7',
      sequenceNumber: 7,
      eventType: 'SESSION_CLOSED',
    });

    const result = await evaluateMandatorySuppression([
      { session, ledgerEntries: [witness, suppression, sessionClosed], presenceRecords: [] },
    ]);

    expect(result.result).toBe('PASS');
    expect(result.evidence).toHaveLength(0);
  });

  it('returns FAIL when FAIL witness has no suppression event', async () => {
    const session = makeSession();
    const witness = makeWitnessEntry('FAIL', 5);

    const result = await evaluateMandatorySuppression([
      { session, ledgerEntries: [witness], presenceRecords: [] },
    ]);

    expect(result.result).toBe('FAIL');
    expect(result.evidence[0].type).toBe('SUPPRESSION_RECORD');
    expect(result.evidence[0].description).toMatch(/no corresponding SUPPRESSION_EVENT/);
  });

  it('returns FAIL when mutating action succeeded after suppression', async () => {
    const session = makeSession();
    const witness = makeWitnessEntry('FAIL', 5);
    const suppression = makeSuppressionEntry(6);
    const mutatingAction = makeLedgerEntry({
      id: 'activate-7',
      sequenceNumber: 7,
      eventType: 'SESSION_ACTIVATED',
    });

    const result = await evaluateMandatorySuppression([
      { session, ledgerEntries: [witness, suppression, mutatingAction], presenceRecords: [] },
    ]);

    expect(result.result).toBe('FAIL');
    expect(result.evidence[0].type).toBe('LEDGER_ENTRY');
    expect(result.evidence[0].description).toMatch(/Mutating action succeeded after SUPPRESSION_EVENT/);
  });

  it('returns vacuous PASS when no FAIL witnesses exist', async () => {
    const session = makeSession();
    const witness = makeWitnessEntry('PASS', 5);

    const result = await evaluateMandatorySuppression([
      { session, ledgerEntries: [witness], presenceRecords: [] },
    ]);

    expect(result.result).toBe('PASS');
  });
});

// ============================================================================
// Condition 4: History Non-Regression
// ============================================================================

describe('evaluateHistoryNonRegression', () => {
  beforeEach(() => {
    mockValidateChain.mockResolvedValue(makeValidChainResult());
    // Default: triggers exist
    mockQuery.mockResolvedValue({
      rows: [
        { tgname: 'trg_integrity_ledger_no_update' },
        { tgname: 'trg_integrity_ledger_no_delete' },
      ],
      rowCount: 2,
      command: 'SELECT',
      oid: 0,
      fields: [],
    });
  });

  it('returns PASS when chain valid, transitions forward-only, and triggers exist', async () => {
    const session = makeSession();
    const entries = [
      makeLedgerEntry({ sequenceNumber: 1, toState: 'CREATED' }),
      makeLedgerEntry({ id: 'e2', sequenceNumber: 2, toState: 'ACTIVE' }),
      makeLedgerEntry({ id: 'e3', sequenceNumber: 3, toState: 'ENDED' }),
    ];

    const result = await evaluateHistoryNonRegression([
      { session, ledgerEntries: entries, presenceRecords: [] },
    ]);

    expect(result.result).toBe('PASS');
    expect(result.evidence).toHaveLength(0);
  });

  it('returns FAIL when hash chain is broken', async () => {
    mockValidateChain.mockResolvedValue({
      valid: false,
      totalEntries: 5,
      validatedEntries: 3,
      firstBrokenEntry: 4,
      errors: [{ sequenceNumber: 4, expectedHash: 'abc', actualHash: 'xyz' }],
    });

    const result = await evaluateHistoryNonRegression([]);

    expect(result.result).toBe('FAIL');
    expect(result.evidence[0].type).toBe('HASH_CHAIN');
  });

  it('returns FAIL when backward state transition detected', async () => {
    const session = makeSession();
    const entries = [
      makeLedgerEntry({ sequenceNumber: 1, toState: 'CREATED' }),
      makeLedgerEntry({ id: 'e2', sequenceNumber: 2, toState: 'ACTIVE' }),
      makeLedgerEntry({ id: 'e3', sequenceNumber: 3, toState: 'ENDED' }),
      makeLedgerEntry({ id: 'e4', sequenceNumber: 4, toState: 'CREATED' }), // backward!
    ];

    const result = await evaluateHistoryNonRegression([
      { session, ledgerEntries: entries, presenceRecords: [] },
    ]);

    expect(result.result).toBe('FAIL');
    expect(result.evidence.some((e) => e.type === 'STATE_TRANSITION')).toBe(true);
  });

  it('returns FAIL when protective triggers are missing', async () => {
    mockQuery.mockResolvedValue({
      rows: [], // no triggers found
      rowCount: 0,
      command: 'SELECT',
      oid: 0,
      fields: [],
    });

    const result = await evaluateHistoryNonRegression([]);

    expect(result.result).toBe('FAIL');
    expect(result.evidence.every((e) => e.type === 'SCHEMA_CHECK')).toBe(true);
    expect(result.evidence).toHaveLength(2);
  });
});

// ============================================================================
// Condition 5: Authority Non-Assertion
// ============================================================================

describe('evaluateAuthorityNonAssertion', () => {
  it('returns PASS when no override attempts exist', async () => {
    const session = makeSession();
    const entries = [
      makeLedgerEntry({ sequenceNumber: 1, toState: 'CREATED' }),
      makeLedgerEntry({ id: 'e2', sequenceNumber: 2, toState: 'ACTIVE' }),
      makeLedgerEntry({ id: 'e3', sequenceNumber: 3, toState: 'ENDED', eventType: 'SESSION_CLOSED' }),
    ];

    const result = await evaluateAuthorityNonAssertion([
      { session, ledgerEntries: entries, presenceRecords: [] },
    ]);

    expect(result.result).toBe('PASS');
  });

  it('returns PASS when override attempted but itself suppressed', async () => {
    const session = makeSession();
    const suppression = makeSuppressionEntry(5);
    const adminAction = makeLedgerEntry({
      id: 'admin-6',
      sequenceNumber: 6,
      eventType: 'SESSION_ACTIVATED',
    });
    const secondSuppression = makeLedgerEntry({
      id: 'sup2-7',
      sequenceNumber: 7,
      eventType: 'SUPPRESSION_EVENT',
    });

    const result = await evaluateAuthorityNonAssertion([
      { session, ledgerEntries: [suppression, adminAction, secondSuppression], presenceRecords: [] },
    ]);

    expect(result.result).toBe('PASS');
  });

  it('returns FAIL when admin action succeeded after suppression', async () => {
    const session = makeSession();
    const suppression = makeSuppressionEntry(5);
    const adminAction = makeLedgerEntry({
      id: 'admin-6',
      sequenceNumber: 6,
      eventType: 'SESSION_ACTIVATED',
    });
    const closedEntry = makeLedgerEntry({
      id: 'closed-7',
      sequenceNumber: 7,
      eventType: 'SESSION_CLOSED', // not a suppression — override succeeded
    });

    const result = await evaluateAuthorityNonAssertion([
      { session, ledgerEntries: [suppression, adminAction, closedEntry], presenceRecords: [] },
    ]);

    expect(result.result).toBe('FAIL');
    expect(result.evidence[0].type).toBe('ADMIN_ACTION');
  });

  it('returns PASS when normal admin actions (non-conflicting) proceed', async () => {
    const session = makeSession();
    // SESSION_CREATED is not in ADMIN_OVERRIDE_EVENT_TYPES
    const suppression = makeSuppressionEntry(3);
    const normalAction = makeLedgerEntry({
      id: 'create-4',
      sequenceNumber: 4,
      eventType: 'SESSION_CREATED',
    });

    const result = await evaluateAuthorityNonAssertion([
      { session, ledgerEntries: [suppression, normalAction], presenceRecords: [] },
    ]);

    expect(result.result).toBe('PASS');
  });
});

// ============================================================================
// Orchestrator: runComplianceCheck
// ============================================================================

describe('runComplianceCheck', () => {
  beforeEach(() => {
    // Default: no sessions, no triggers needed, valid chain
    mockQuery
      .mockResolvedValueOnce({ rows: [], rowCount: 0, command: 'SELECT', oid: 0, fields: [] }) // loadEndedSessions
      .mockResolvedValueOnce({
        // triggers query
        rows: [
          { tgname: 'trg_integrity_ledger_no_update' },
          { tgname: 'trg_integrity_ledger_no_delete' },
        ],
        rowCount: 2,
        command: 'SELECT',
        oid: 0,
        fields: [],
      });

    mockValidateChain.mockResolvedValue(makeValidChainResult());
  });

  it('returns COMPLIANT when all conditions PASS', async () => {
    const result = await runComplianceCheck();

    expect(result.overall).toBe('COMPLIANT');
    expect(result.conditions).toHaveLength(5);
    expect(result.conditions.every((c) => c.result === 'PASS')).toBe(true);
    expect(result.sessionsEvaluated).toBe(0);
    expect(result.systemVersion).toBe('009');
  });

  it('returns NON_COMPLIANT with failing condition identified', async () => {
    // One session with no witness entry → DETERMINISTIC_VERIFICATION fails
    mockQuery
      .mockReset()
      .mockResolvedValueOnce({
        rows: [
          {
            id: 'sess-001',
            name: 'S1',
            state: 'ENDED',
            admin_id: 'admin-1',
            created_at: new Date('2026-01-01T10:00:00Z'),
            started_at: new Date('2026-01-01T10:01:00Z'),
            ended_at: new Date('2026-01-01T11:00:00Z'),
            context_descriptor: { topic: 'test' },
            environmental_constraints: { max_participants: 5 },
            token_count: 0,
            user_count: 1,
          },
        ],
        rowCount: 1,
        command: 'SELECT',
        oid: 0,
        fields: [],
      }) // sessions
      .mockResolvedValueOnce({
        rows: [{ tgname: 'trg_integrity_ledger_no_update' }, { tgname: 'trg_integrity_ledger_no_delete' }],
        rowCount: 2,
        command: 'SELECT',
        oid: 0,
        fields: [],
      }); // triggers

    mockGetEntriesBySession.mockResolvedValue([]); // no witness
    mockGetPresenceRecords.mockResolvedValue([
      makePresenceRecord({
        finalized: true,
        finalizedAt: new Date('2026-01-01T11:01:00Z'),
      }),
    ]);
    mockValidateChain.mockResolvedValue(makeValidChainResult());
    mockVerify.mockReturnValue({ pass: true, protocolResults: [], timestamp: new Date() });

    const result = await runComplianceCheck();

    expect(result.overall).toBe('NON_COMPLIANT');
    const failedCondition = result.conditions.find((c) => c.result === 'FAIL');
    expect(failedCondition?.condition).toBe('DETERMINISTIC_VERIFICATION');
  });

  it('returns ERROR on infrastructure failure', async () => {
    mockQuery.mockReset().mockRejectedValueOnce(new Error('DB connection lost'));

    const result = await runComplianceCheck();

    expect(result.overall).toBe('ERROR');
    expect(result.error).toMatch(/DB connection lost/);
    expect(result.conditions).toHaveLength(0);
  });

  it('returns COMPLIANT on empty system (no ENDED sessions)', async () => {
    const result = await runComplianceCheck();

    expect(result.overall).toBe('COMPLIANT');
    expect(result.sessionsEvaluated).toBe(0);
  });

  it('active sessions are excluded — only ENDED sessions appear in sessionsEvaluated', async () => {
    // The loadEndedSessions() query uses WHERE state = 'ENDED', so ACTIVE/CREATED
    // sessions are never loaded. We validate this by returning zero ENDED sessions
    // (simulating a system where only in-progress sessions exist) and confirming
    // sessionsEvaluated is 0 and the result is COMPLIANT (vacuous satisfaction).
    const result = await runComplianceCheck();

    expect(result.overall).toBe('COMPLIANT');
    expect(result.sessionsEvaluated).toBe(0);
  });

  it('acedia force-released sessions are included in evaluation', async () => {
    // Acedia force-released sessions transition to state=ENDED, so they are
    // picked up by loadEndedSessions() (WHERE state = 'ENDED') and evaluated
    // against all five conditions like any other closed session.
    mockQuery
      .mockReset()
      .mockResolvedValueOnce({
        rows: [
          {
            id: 'sess-acedia',
            name: 'Acedia Force-Released Session',
            state: 'ENDED',
            admin_id: 'admin-1',
            created_at: new Date('2026-01-01T10:00:00Z'),
            started_at: new Date('2026-01-01T10:01:00Z'),
            ended_at: new Date('2026-01-01T11:00:00Z'),
            context_descriptor: { topic: 'acedia test' },
            environmental_constraints: { max_participants: 5 },
            token_count: 0,
            user_count: 1,
          },
        ],
        rowCount: 1,
        command: 'SELECT',
        oid: 0,
        fields: [],
      }) // sessions
      .mockResolvedValueOnce({
        rows: [
          { tgname: 'trg_integrity_ledger_no_update' },
          { tgname: 'trg_integrity_ledger_no_delete' },
        ],
        rowCount: 2,
        command: 'SELECT',
        oid: 0,
        fields: [],
      }); // triggers

    // Ledger contains ACEDIA_FORCE_RELEASE entry followed by VERIFICATION_WITNESS
    mockGetEntriesBySession.mockResolvedValue([
      makeLedgerEntry({ id: 'e1', sequenceNumber: 1, eventType: 'SESSION_CREATED', toState: 'CREATED' }),
      makeLedgerEntry({ id: 'e2', sequenceNumber: 2, eventType: 'SESSION_ACTIVATED', toState: 'ACTIVE' }),
      makeLedgerEntry({ id: 'e3', sequenceNumber: 3, eventType: 'ACEDIA_WARNING', toState: 'ACTIVE' }),
      makeLedgerEntry({ id: 'e4', sequenceNumber: 4, eventType: 'ACEDIA_DETECTION', toState: 'ACTIVE' }),
      makeLedgerEntry({ id: 'e5', sequenceNumber: 5, eventType: 'ACEDIA_FORCE_RELEASE', toState: 'ENDED' }),
      makeWitnessEntry('PASS', 6),
    ]);
    mockGetPresenceRecords.mockResolvedValue([
      makePresenceRecord({ finalized: true, finalizedAt: new Date('2026-01-01T11:01:00Z') }),
    ]);
    mockValidateChain.mockResolvedValue(makeValidChainResult());
    mockVerify.mockReturnValue({ pass: true, protocolResults: [], timestamp: new Date() });

    const result = await runComplianceCheck();

    // The acedia force-released session is evaluated (included, not skipped)
    expect(result.sessionsEvaluated).toBe(1);
    // All conditions pass for a properly closed acedia session
    expect(result.overall).toBe('COMPLIANT');
    expect(result.conditions.every((c) => c.result === 'PASS')).toBe(true);
  });

  it('is deterministic — same mock state produces identical results on repeated runs', async () => {
    const r1 = await runComplianceCheck();

    // Re-setup same mocks
    mockQuery
      .mockResolvedValueOnce({ rows: [], rowCount: 0, command: 'SELECT', oid: 0, fields: [] })
      .mockResolvedValueOnce({
        rows: [
          { tgname: 'trg_integrity_ledger_no_update' },
          { tgname: 'trg_integrity_ledger_no_delete' },
        ],
        rowCount: 2,
        command: 'SELECT',
        oid: 0,
        fields: [],
      });
    mockValidateChain.mockResolvedValue(makeValidChainResult());

    const r2 = await runComplianceCheck();

    expect(r1.overall).toBe(r2.overall);
    expect(r1.conditions.map((c) => c.result)).toEqual(r2.conditions.map((c) => c.result));
    expect(r1.sessionsEvaluated).toBe(r2.sessionsEvaluated);
  });
});

// ============================================================================
// runConditionCheck
// ============================================================================

describe('runConditionCheck', () => {
  beforeEach(() => {
    mockQuery
      .mockResolvedValueOnce({ rows: [], rowCount: 0, command: 'SELECT', oid: 0, fields: [] })
      .mockResolvedValueOnce({
        rows: [
          { tgname: 'trg_integrity_ledger_no_update' },
          { tgname: 'trg_integrity_ledger_no_delete' },
        ],
        rowCount: 2,
        command: 'SELECT',
        oid: 0,
        fields: [],
      });
    mockValidateChain.mockResolvedValue(makeValidChainResult());
  });

  it('returns COMPLIANT with single condition when TRUTH_FINALIZATION passes', async () => {
    const result = await runConditionCheck('TRUTH_FINALIZATION');

    expect(result.overall).toBe('COMPLIANT');
    expect(result.conditions).toHaveLength(1);
    expect(result.conditions[0].condition).toBe('TRUTH_FINALIZATION');
    expect(result.conditions[0].result).toBe('PASS');
  });

  it('returns same result as full check for the same condition', async () => {
    const singleResult = await runConditionCheck('HISTORY_NON_REGRESSION');

    // Re-setup for full check
    mockQuery
      .mockResolvedValueOnce({ rows: [], rowCount: 0, command: 'SELECT', oid: 0, fields: [] })
      .mockResolvedValueOnce({
        rows: [
          { tgname: 'trg_integrity_ledger_no_update' },
          { tgname: 'trg_integrity_ledger_no_delete' },
        ],
        rowCount: 2,
        command: 'SELECT',
        oid: 0,
        fields: [],
      });
    mockValidateChain.mockResolvedValue(makeValidChainResult());

    const fullResult = await runComplianceCheck();
    const fullCondition = fullResult.conditions.find((c) => c.condition === 'HISTORY_NON_REGRESSION');

    expect(singleResult.conditions[0].result).toBe(fullCondition?.result);
  });
});
