/**
 * Unit tests for the append-only ledger service.
 * Tests hash chain construction, query ordering, and validation.
 * @see specs/005-structural-foundation/spec.md US2
 */

import { describe, it, expect, vi, beforeEach } from 'vitest';
import type { MetadataSnapshot, LedgerEntry } from '../../../src/integrity/types.js';
import { computeEntryHash, validateHashChain } from '../../../src/integrity/hash.js';

const SESSION_ID = 'aaaaaaaa-bbbb-cccc-dddd-eeeeeeeeeeee';
const ADMIN_ID = '11111111-2222-3333-4444-555555555555';

function makeSnapshot(overrides: Partial<MetadataSnapshot> = {}): MetadataSnapshot {
  return {
    session_id: SESSION_ID,
    session_name: 'Test Session',
    state: 'CREATED',
    framework_status: 'OPEN',
    admin_id: ADMIN_ID,
    token_count: 0,
    user_count: 0,
    created_at: '2026-02-14T10:00:00.000Z',
    started_at: null,
    ended_at: null,
    context_descriptor: { topic: 'Test topic' },
    environmental_constraints: { max_participants: 10 },
    ...overrides,
  };
}

// ---------------------------------------------------------------------------
// We test the ledger's append logic by simulating what appendEntry does:
// build sequential entries with proper hash chaining and then validate.
// The actual DB layer is tested in integration tests.
// ---------------------------------------------------------------------------

function buildChainedEntries(count: number): LedgerEntry[] {
  const snapshots: MetadataSnapshot[] = [
    makeSnapshot(),
    makeSnapshot({ state: 'ACTIVE', started_at: '2026-02-14T10:01:00.000Z' }),
    makeSnapshot({ state: 'ENDED', started_at: '2026-02-14T10:01:00.000Z', ended_at: '2026-02-14T10:30:00.000Z', framework_status: 'CLOSED' }),
  ];
  const eventTypes = ['SESSION_CREATED', 'SESSION_ACTIVATED', 'SESSION_CLOSED'] as const;
  const timestamps = [
    '2026-02-14T10:00:00.000Z',
    '2026-02-14T10:01:00.000Z',
    '2026-02-14T10:30:00.000Z',
  ];

  const entries: LedgerEntry[] = [];
  let previousHash: string | null = null;

  for (let i = 0; i < Math.min(count, 3); i++) {
    const seq = i + 1;
    const hash = computeEntryHash(previousHash, seq, SESSION_ID, eventTypes[i], timestamps[i], snapshots[i]);
    entries.push({
      id: `entry-${seq}`,
      sequenceNumber: seq,
      sessionId: SESSION_ID,
      eventType: eventTypes[i],
      timestamp: new Date(timestamps[i]),
      fromState: i === 0 ? null : (['CREATED', 'ACTIVE'] as const)[i - 1],
      toState: snapshots[i].state,
      metadataSnapshot: snapshots[i],
      previousHash,
      entryHash: hash,
    });
    previousHash = hash;
  }

  return entries;
}

describe('Ledger service — hash chain construction', () => {
  it('creates sequential entries with correct hash chain linkage', () => {
    const entries = buildChainedEntries(3);

    // First entry is genesis
    expect(entries[0].previousHash).toBeNull();
    expect(entries[0].sequenceNumber).toBe(1);

    // Each subsequent entry references the previous hash
    expect(entries[1].previousHash).toBe(entries[0].entryHash);
    expect(entries[2].previousHash).toBe(entries[1].entryHash);

    // All hashes are valid 64-char hex
    for (const entry of entries) {
      expect(entry.entryHash).toMatch(/^[a-f0-9]{64}$/);
    }
  });

  it('each entry has a unique hash', () => {
    const entries = buildChainedEntries(3);
    const hashes = entries.map(e => e.entryHash);
    expect(new Set(hashes).size).toBe(3);
  });
});

describe('Ledger service — getEntriesBySession ordering', () => {
  it('entries are ordered by sequence number ascending', () => {
    const entries = buildChainedEntries(3);
    for (let i = 1; i < entries.length; i++) {
      expect(entries[i].sequenceNumber).toBeGreaterThan(entries[i - 1].sequenceNumber);
    }
  });
});

describe('Ledger service — validateChain', () => {
  it('returns valid for intact chain', () => {
    const entries = buildChainedEntries(3);
    const result = validateHashChain(entries);
    expect(result.valid).toBe(true);
    expect(result.totalEntries).toBe(3);
    expect(result.validatedEntries).toBe(3);
    expect(result.errors).toHaveLength(0);
  });

  it('detects tampered metadata in a chain', () => {
    const entries = buildChainedEntries(3);
    // Tamper with the second entry's metadata
    entries[1] = {
      ...entries[1],
      metadataSnapshot: makeSnapshot({ state: 'ACTIVE', session_name: 'TAMPERED' }),
    };

    const result = validateHashChain(entries);
    expect(result.valid).toBe(false);
    expect(result.firstBrokenEntry).toBe(2);
  });

  it('detects broken previousHash linkage', () => {
    const entries = buildChainedEntries(3);
    // Break the chain by setting wrong previousHash on entry 2
    entries[1] = {
      ...entries[1],
      previousHash: 'aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa',
    };

    const result = validateHashChain(entries);
    expect(result.valid).toBe(false);
  });

  it('detects tampered entryHash', () => {
    const entries = buildChainedEntries(2);
    entries[0] = {
      ...entries[0],
      entryHash: 'bbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbb',
    };

    const result = validateHashChain(entries);
    expect(result.valid).toBe(false);
    expect(result.firstBrokenEntry).toBe(1);
  });
});

describe('Ledger service — no update/delete methods', () => {
  it('ledger module exports only append, query, and validate functions', async () => {
    const ledger = await import('../../../src/integrity/ledger.js');
    const exportedNames = Object.keys(ledger);

    // Must have append, query, validate
    expect(exportedNames).toContain('appendEntry');
    expect(exportedNames).toContain('getEntriesBySession');
    expect(exportedNames).toContain('validateChain');

    // Must NOT have update or delete
    expect(exportedNames).not.toContain('updateEntry');
    expect(exportedNames).not.toContain('deleteEntry');
    expect(exportedNames).not.toContain('update');
    expect(exportedNames).not.toContain('delete');
    expect(exportedNames).not.toContain('remove');
  });
});
