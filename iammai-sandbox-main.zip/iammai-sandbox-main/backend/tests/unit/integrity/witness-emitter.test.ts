/**
 * Unit tests for the witness emitter.
 * Tests witness artifact construction and field completeness.
 * @see specs/006-verification-witness
 */

import { describe, it, expect } from 'vitest';
import { buildWitnessArtifact } from '../../../src/integrity/witness-emitter.js';
import type { VerificationResult, ProtocolResult } from '../../../src/integrity/types.js';
import type { Session } from '../../../src/lib/types.js';

const SESSION_ID = 'aaaaaaaa-bbbb-cccc-dddd-eeeeeeeeeeee';
const ADMIN_ID = '11111111-2222-3333-4444-555555555555';

function makeSession(overrides: Partial<Session> = {}): Session {
  return {
    id: SESSION_ID,
    name: 'Test Session',
    state: 'ENDED',
    createdAt: new Date('2026-02-14T10:00:00.000Z'),
    startedAt: new Date('2026-02-14T10:01:00.000Z'),
    endedAt: new Date('2026-02-14T10:30:00.000Z'),
    tokenCount: 1,
    userCount: 2,
    adminId: ADMIN_ID,
    contextDescriptor: { topic: 'Test topic' },
    environmentalConstraints: { max_participants: 10 },
    ...overrides,
  };
}

function makeVerificationResult(pass: boolean, protocolResults?: ProtocolResult[]): VerificationResult {
  return {
    pass,
    protocolResults: protocolResults ?? [
      { protocol: 'I.02', result: 'PASS', details: 'OK' },
      { protocol: 'I.03', result: 'PASS', details: 'OK' },
      { protocol: 'I.04', result: pass ? 'PASS' : 'FAIL', details: pass ? 'OK' : 'Chain broken' },
    ],
    timestamp: new Date('2026-02-14T10:30:01.000Z'),
  };
}

describe('Witness emitter — buildWitnessArtifact', () => {
  it('builds a complete witness artifact with all required fields', () => {
    const artifact = buildWitnessArtifact(makeVerificationResult(true), makeSession());

    expect(artifact.artifact_type).toBe('SESSION_WITNESS');
    expect(artifact.artifact_version).toBe('1.0');
    expect(artifact.system).toBe('iammai-sandbox');
    expect(artifact.event_id).toBeDefined();
    expect(artifact.event_id).toMatch(/^[0-9a-f-]{36}$/);
    expect(artifact.t_open).toBe('2026-02-14T10:00:00.000Z');
    expect(artifact.t_close).toBe('2026-02-14T10:30:00.000Z');
    expect(artifact.presence).toBeDefined();
    expect(artifact.protocols_evaluated).toEqual(['I.02', 'I.03', 'I.04']);
    expect(artifact.pass_fail).toBe('PASS');
    expect(artifact.protocol_results).toHaveLength(3);
    expect(artifact.suppression_triggered).toBe(false);
    expect(artifact.timestamp_utc).toBe('2026-02-14T10:30:01.000Z');
    expect(artifact.protocol_versions).toBeDefined();
    expect(artifact.metadata).toBeDefined();
  });

  it('sets pass_fail to FAIL when verification fails', () => {
    const artifact = buildWitnessArtifact(makeVerificationResult(false), makeSession());
    expect(artifact.pass_fail).toBe('FAIL');
  });

  it('includes correct metadata', () => {
    const session = makeSession({ name: 'My Session', userCount: 5 });
    const artifact = buildWitnessArtifact(makeVerificationResult(true), session);

    expect(artifact.metadata.session_name).toBe('My Session');
    expect(artifact.metadata.participant_count).toBe(5);
    expect(artifact.metadata.duration_ms).toBe(
      new Date('2026-02-14T10:30:00.000Z').getTime() - new Date('2026-02-14T10:00:00.000Z').getTime()
    );
  });

  it('calculates duration from createdAt to endedAt', () => {
    const session = makeSession();
    const artifact = buildWitnessArtifact(makeVerificationResult(true), session);
    // 30 minutes = 1,800,000 ms
    expect(artifact.metadata.duration_ms).toBe(1800000);
  });

  it('includes default presence when no presence provided', () => {
    const artifact = buildWitnessArtifact(makeVerificationResult(true), makeSession());

    expect(artifact.presence.admin).toEqual({ attested: true, method: 'auth_event', hash: '' });
    expect(artifact.presence.participants).toEqual([]);
    expect(artifact.presence.agents).toEqual([]);
  });

  it('includes real presence when provided', () => {
    const presence = {
      admin: { attested: true, method: 'AUTH_EVENT', hash: 'admin123' },
      participants: [{ attested: true, method: 'JOIN_TOKEN', hash: 'user1' }],
      agents: [{ attested: true, method: 'MESSAGE_PROCESSING', hash: 'ai-agent' }],
      total_attestation_methods: 3,
      finalized: true,
    };
    const artifact = buildWitnessArtifact(makeVerificationResult(true), makeSession(), presence);

    expect(artifact.presence.admin.hash).toBe('admin123');
    expect(artifact.presence.participants).toHaveLength(1);
    expect(artifact.presence.agents).toHaveLength(1);
    expect(artifact.presence.total_attestation_methods).toBe(3);
  });

  it('includes protocol versions', () => {
    const artifact = buildWitnessArtifact(makeVerificationResult(true), makeSession());
    expect(artifact.protocol_versions['I.02']).toBeDefined();
    expect(artifact.protocol_versions['I.03']).toBeDefined();
    expect(artifact.protocol_versions['I.04']).toBeDefined();
  });

  it('generates unique event_ids', () => {
    const a1 = buildWitnessArtifact(makeVerificationResult(true), makeSession());
    const a2 = buildWitnessArtifact(makeVerificationResult(true), makeSession());
    expect(a1.event_id).not.toBe(a2.event_id);
  });

  it('does not contain message content or user identity data', () => {
    const artifact = buildWitnessArtifact(makeVerificationResult(true), makeSession());
    const json = JSON.stringify(artifact);
    // Should not contain any message content
    expect(json).not.toContain('password');
    expect(json).not.toContain('token');
    expect(json).not.toContain('email');
  });

  it('suppression_triggered defaults to false', () => {
    const artifact = buildWitnessArtifact(makeVerificationResult(true), makeSession());
    expect(artifact.suppression_triggered).toBe(false);
  });

  it('suppression_triggered can be set to true', () => {
    const artifact = buildWitnessArtifact(makeVerificationResult(false), makeSession(), undefined, true);
    expect(artifact.suppression_triggered).toBe(true);
  });
});
