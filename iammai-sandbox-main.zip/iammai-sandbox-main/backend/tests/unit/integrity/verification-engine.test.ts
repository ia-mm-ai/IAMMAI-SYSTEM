/**
 * Unit tests for the verification engine.
 * @see specs/006-verification-witness
 */

import { describe, it, expect } from 'vitest';
import { verify } from '../../../src/integrity/verification-engine.js';
import type { ProtocolEvaluator, EvaluationContext, ProtocolResult, LedgerEntry, MetadataSnapshot } from '../../../src/integrity/types.js';
import type { Session } from '../../../src/lib/types.js';
import { computeEntryHash } from '../../../src/integrity/hash.js';

const SESSION_ID = 'aaaaaaaa-bbbb-cccc-dddd-eeeeeeeeeeee';
const ADMIN_ID = '11111111-2222-3333-4444-555555555555';

function makeSnapshot(overrides: Partial<MetadataSnapshot> = {}): MetadataSnapshot {
  return {
    session_id: SESSION_ID,
    session_name: 'Test Session',
    state: 'CREATED',
    framework_status: 'OPEN',
    admin_id: ADMIN_ID,
    token_count: 0,
    user_count: 0,
    created_at: '2026-02-14T10:00:00.000Z',
    started_at: null,
    ended_at: null,
    context_descriptor: { topic: 'Test topic' },
    environmental_constraints: { max_participants: 10 },
    ...overrides,
  };
}

function makeSession(overrides: Partial<Session> = {}): Session {
  return {
    id: SESSION_ID,
    name: 'Test Session',
    state: 'ENDED',
    createdAt: new Date('2026-02-14T10:00:00.000Z'),
    startedAt: new Date('2026-02-14T10:01:00.000Z'),
    endedAt: new Date('2026-02-14T10:30:00.000Z'),
    tokenCount: 1,
    userCount: 1,
    adminId: ADMIN_ID,
    contextDescriptor: { topic: 'Test topic' },
    environmentalConstraints: { max_participants: 10 },
    ...overrides,
  };
}

function buildChainedEntries(): LedgerEntry[] {
  const snapshots = [
    makeSnapshot(),
    makeSnapshot({ state: 'ACTIVE', started_at: '2026-02-14T10:01:00.000Z' }),
    makeSnapshot({ state: 'ENDED', started_at: '2026-02-14T10:01:00.000Z', ended_at: '2026-02-14T10:30:00.000Z', framework_status: 'CLOSED' }),
  ];
  const eventTypes = ['SESSION_CREATED', 'SESSION_ACTIVATED', 'SESSION_CLOSED'] as const;
  const timestamps = [
    '2026-02-14T10:00:00.000Z',
    '2026-02-14T10:01:00.000Z',
    '2026-02-14T10:30:00.000Z',
  ];

  const entries: LedgerEntry[] = [];
  let previousHash: string | null = null;

  for (let i = 0; i < 3; i++) {
    const seq = i + 1;
    const hash = computeEntryHash(previousHash, seq, SESSION_ID, eventTypes[i], timestamps[i]!, snapshots[i]!);
    entries.push({
      id: `entry-${seq}`,
      sequenceNumber: seq,
      sessionId: SESSION_ID,
      eventType: eventTypes[i],
      timestamp: new Date(timestamps[i]!),
      fromState: i === 0 ? null : (['CREATED', 'ACTIVE'] as const)[i - 1],
      toState: snapshots[i]!.state,
      metadataSnapshot: snapshots[i]!,
      previousHash,
      entryHash: hash,
    });
    previousHash = hash;
  }

  return entries;
}

// Mock protocol evaluators for testing
class PassingProtocol implements ProtocolEvaluator {
  readonly id = 'TEST.PASS';
  readonly version = '1.0.0';
  evaluate(): ProtocolResult {
    return { protocol: this.id, result: 'PASS', details: 'Test passed' };
  }
}

class FailingProtocol implements ProtocolEvaluator {
  readonly id = 'TEST.FAIL';
  readonly version = '1.0.0';
  evaluate(): ProtocolResult {
    return { protocol: this.id, result: 'FAIL', details: 'Test failed' };
  }
}

describe('Verification engine', () => {
  it('returns PASS when all protocols pass', () => {
    const result = verify(
      makeSession(),
      buildChainedEntries(),
      [new PassingProtocol(), new PassingProtocol()]
    );
    expect(result.pass).toBe(true);
    expect(result.protocolResults).toHaveLength(2);
    expect(result.protocolResults.every(r => r.result === 'PASS')).toBe(true);
  });

  it('returns FAIL when any protocol fails (conjunctive AND)', () => {
    const result = verify(
      makeSession(),
      buildChainedEntries(),
      [new PassingProtocol(), new FailingProtocol()]
    );
    expect(result.pass).toBe(false);
    expect(result.protocolResults).toHaveLength(2);
  });

  it('returns FAIL when all protocols fail', () => {
    const result = verify(
      makeSession(),
      buildChainedEntries(),
      [new FailingProtocol(), new FailingProtocol()]
    );
    expect(result.pass).toBe(false);
  });

  it('includes timestamp in result', () => {
    const before = new Date();
    const result = verify(makeSession(), buildChainedEntries(), [new PassingProtocol()]);
    const after = new Date();
    expect(result.timestamp.getTime()).toBeGreaterThanOrEqual(before.getTime());
    expect(result.timestamp.getTime()).toBeLessThanOrEqual(after.getTime());
  });

  it('passes session and entries to protocol evaluators', () => {
    const session = makeSession();
    const entries = buildChainedEntries();
    let capturedContext: EvaluationContext | null = null;

    const spy: ProtocolEvaluator = {
      id: 'TEST.SPY',
      version: '1.0.0',
      evaluate(ctx: EvaluationContext) {
        capturedContext = ctx;
        return { protocol: 'TEST.SPY', result: 'PASS', details: 'ok' };
      },
    };

    verify(session, entries, [spy]);
    expect(capturedContext).not.toBeNull();
    expect(capturedContext!.session).toBe(session);
    expect(capturedContext!.ledgerEntries).toBe(entries);
  });

  it('uses default protocols when none specified', () => {
    const result = verify(makeSession(), buildChainedEntries());
    // Should run all 15 default protocols (I.01-I.05, I.08, I.06, I.07, I.09, I.10, I.11-I.15)
    expect(result.protocolResults).toHaveLength(15);
    expect(result.protocolResults.map(r => r.protocol)).toEqual([
      'I.01', 'I.02', 'I.03', 'I.04', 'I.05', 'I.08',
      'I.06', 'I.07', 'I.09', 'I.10', 'I.11', 'I.12', 'I.13', 'I.14', 'I.15',
    ]);
  });

  it('handles empty protocol set', () => {
    const result = verify(makeSession(), buildChainedEntries(), []);
    expect(result.pass).toBe(true);
    expect(result.protocolResults).toHaveLength(0);
  });
});
