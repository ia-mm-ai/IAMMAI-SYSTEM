/**
 * Unit tests for presence finalization.
 * Tests buildPresenceSummaryFromRecords with finalized records.
 * @see specs/007-presence-suppression/tasks.md T021
 */

import { describe, it, expect } from 'vitest';
import { buildPresenceSummaryFromRecords } from '../../../src/integrity/presence-tracker.js';
import type { PresenceRecord } from '../../../src/integrity/types.js';

function makeRecord(overrides: Partial<PresenceRecord> = {}): PresenceRecord {
  return {
    id: 'rec-1',
    sessionId: 'session-1',
    role: 'CREATOR',
    presenceHash: 'a1b2c3d4',
    attestationMethod: 'AUTH_EVENT',
    attested: true,
    finalized: false,
    createdAt: new Date('2026-02-14T10:00:00.000Z'),
    finalizedAt: null,
    ...overrides,
  };
}

describe('Presence tracker — finalization summary', () => {
  it('reports finalized=true when all records are finalized', () => {
    const now = new Date();
    const records = [
      makeRecord({ finalized: true, finalizedAt: now }),
      makeRecord({
        id: 'rec-2',
        role: 'PARTICIPANT',
        attestationMethod: 'JOIN_TOKEN',
        presenceHash: 'user1',
        finalized: true,
        finalizedAt: now,
      }),
      makeRecord({
        id: 'rec-3',
        role: 'AGENT',
        attestationMethod: 'MESSAGE_PROCESSING',
        presenceHash: 'ai-agent',
        finalized: true,
        finalizedAt: now,
      }),
    ];

    const summary = buildPresenceSummaryFromRecords(records);
    expect(summary.finalized).toBe(true);
    expect(summary.total_attestation_methods).toBe(3);
  });

  it('reports finalized=false when any record is not finalized', () => {
    const records = [
      makeRecord({ finalized: true, finalizedAt: new Date() }),
      makeRecord({
        id: 'rec-2',
        role: 'PARTICIPANT',
        attestationMethod: 'JOIN_TOKEN',
        presenceHash: 'user1',
        finalized: false,
      }),
    ];

    const summary = buildPresenceSummaryFromRecords(records);
    expect(summary.finalized).toBe(false);
  });

  it('preserves attestation details after finalization', () => {
    const now = new Date();
    const records = [
      makeRecord({
        role: 'CREATOR',
        attestationMethod: 'AUTH_EVENT',
        presenceHash: 'admin1',
        finalized: true,
        finalizedAt: now,
      }),
    ];

    const summary = buildPresenceSummaryFromRecords(records);
    expect(summary.admin.attested).toBe(true);
    expect(summary.admin.method).toBe('AUTH_EVENT');
    expect(summary.admin.hash).toBe('admin1');
  });

  it('handles empty records after finalization attempt', () => {
    const summary = buildPresenceSummaryFromRecords([]);
    expect(summary.finalized).toBe(false);
    expect(summary.total_attestation_methods).toBe(0);
  });
});
