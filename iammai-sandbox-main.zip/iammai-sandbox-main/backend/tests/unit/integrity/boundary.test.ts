/**
 * Unit tests for boundary validation functions.
 * @see specs/005-structural-foundation/spec.md US3
 */

import { describe, it, expect } from 'vitest';
import {
  validateContextDescriptor,
  validateEnvironmentalConstraints,
  isFinalizationPermitted,
} from '../../../src/integrity/boundary.js';
import type { Session } from '../../../src/lib/types.js';

const SESSION_ID = 'aaaaaaaa-bbbb-cccc-dddd-eeeeeeeeeeee';
const ADMIN_ID = '11111111-2222-3333-4444-555555555555';

function makeSession(state: 'CREATED' | 'ACTIVE' | 'ENDED'): Session {
  return {
    id: SESSION_ID,
    name: 'Boundary Test',
    state,
    createdAt: new Date('2026-02-14T10:00:00.000Z'),
    startedAt: state !== 'CREATED' ? new Date('2026-02-14T10:01:00.000Z') : null,
    endedAt: state === 'ENDED' ? new Date('2026-02-14T10:30:00.000Z') : null,
    tokenCount: 0,
    userCount: 0,
    adminId: ADMIN_ID,
    contextDescriptor: { topic: 'test' },
    environmentalConstraints: { max_participants: 10 },
  };
}

// ============================================================================
// validateContextDescriptor
// ============================================================================

describe('validateContextDescriptor', () => {
  it('accepts valid {topic} descriptor', () => {
    const result = validateContextDescriptor({ topic: 'Unit testing' });
    expect(result.ok).toBe(true);
    if (result.ok) {
      expect(result.value.topic).toBe('Unit testing');
      expect(result.value.purpose).toBeUndefined();
    }
  });

  it('accepts valid {topic, purpose} descriptor', () => {
    const result = validateContextDescriptor({ topic: 'Testing', purpose: 'Verify boundaries' });
    expect(result.ok).toBe(true);
    if (result.ok) {
      expect(result.value.topic).toBe('Testing');
      expect(result.value.purpose).toBe('Verify boundaries');
    }
  });

  it('rejects null input', () => {
    const result = validateContextDescriptor(null);
    expect(result.ok).toBe(false);
  });

  it('rejects undefined input', () => {
    const result = validateContextDescriptor(undefined);
    expect(result.ok).toBe(false);
  });

  it('rejects missing topic', () => {
    const result = validateContextDescriptor({ purpose: 'no topic' });
    expect(result.ok).toBe(false);
  });

  it('rejects empty topic', () => {
    const result = validateContextDescriptor({ topic: '   ' });
    expect(result.ok).toBe(false);
  });

  it('rejects topic > 500 chars', () => {
    const result = validateContextDescriptor({ topic: 'x'.repeat(501) });
    expect(result.ok).toBe(false);
    if (!result.ok) {
      expect(result.error.message).toContain('500');
    }
  });

  it('accepts topic exactly 500 chars', () => {
    const result = validateContextDescriptor({ topic: 'x'.repeat(500) });
    expect(result.ok).toBe(true);
  });

  it('rejects non-string purpose', () => {
    const result = validateContextDescriptor({ topic: 'ok', purpose: 123 });
    expect(result.ok).toBe(false);
  });

  it('rejects purpose > 1000 chars', () => {
    const result = validateContextDescriptor({ topic: 'ok', purpose: 'y'.repeat(1001) });
    expect(result.ok).toBe(false);
  });
});

// ============================================================================
// validateEnvironmentalConstraints
// ============================================================================

describe('validateEnvironmentalConstraints', () => {
  it('accepts valid {max_participants}', () => {
    const result = validateEnvironmentalConstraints({ max_participants: 10 });
    expect(result.ok).toBe(true);
    if (result.ok) {
      expect(result.value.max_participants).toBe(10);
    }
  });

  it('accepts valid with all optional fields', () => {
    const result = validateEnvironmentalConstraints({
      max_participants: 50,
      time_limit_minutes: 60,
      ai_model: 'claude-sonnet-4-5-20250929',
    });
    expect(result.ok).toBe(true);
    if (result.ok) {
      expect(result.value.max_participants).toBe(50);
      expect(result.value.time_limit_minutes).toBe(60);
      expect(result.value.ai_model).toBe('claude-sonnet-4-5-20250929');
    }
  });

  it('rejects null input', () => {
    const result = validateEnvironmentalConstraints(null);
    expect(result.ok).toBe(false);
  });

  it('rejects missing max_participants', () => {
    const result = validateEnvironmentalConstraints({ time_limit_minutes: 30 });
    expect(result.ok).toBe(false);
  });

  it('rejects zero max_participants', () => {
    const result = validateEnvironmentalConstraints({ max_participants: 0 });
    expect(result.ok).toBe(false);
  });

  it('rejects negative max_participants', () => {
    const result = validateEnvironmentalConstraints({ max_participants: -5 });
    expect(result.ok).toBe(false);
  });

  it('rejects max_participants > 1000', () => {
    const result = validateEnvironmentalConstraints({ max_participants: 1001 });
    expect(result.ok).toBe(false);
  });

  it('accepts max_participants = 1 (minimum)', () => {
    const result = validateEnvironmentalConstraints({ max_participants: 1 });
    expect(result.ok).toBe(true);
  });

  it('accepts max_participants = 1000 (maximum)', () => {
    const result = validateEnvironmentalConstraints({ max_participants: 1000 });
    expect(result.ok).toBe(true);
  });

  it('rejects non-integer max_participants', () => {
    const result = validateEnvironmentalConstraints({ max_participants: 5.5 });
    expect(result.ok).toBe(false);
  });

  it('rejects non-integer time_limit_minutes', () => {
    const result = validateEnvironmentalConstraints({ max_participants: 10, time_limit_minutes: 30.5 });
    expect(result.ok).toBe(false);
  });

  it('rejects time_limit_minutes < 1', () => {
    const result = validateEnvironmentalConstraints({ max_participants: 10, time_limit_minutes: 0 });
    expect(result.ok).toBe(false);
  });

  it('rejects time_limit_minutes > 1440', () => {
    const result = validateEnvironmentalConstraints({ max_participants: 10, time_limit_minutes: 1441 });
    expect(result.ok).toBe(false);
  });

  it('rejects empty ai_model string', () => {
    const result = validateEnvironmentalConstraints({ max_participants: 10, ai_model: '  ' });
    expect(result.ok).toBe(false);
  });
});

// ============================================================================
// isFinalizationPermitted
// ============================================================================

describe('isFinalizationPermitted', () => {
  it('returns false for CREATED session', () => {
    expect(isFinalizationPermitted(makeSession('CREATED'))).toBe(false);
  });

  it('returns false for ACTIVE session', () => {
    expect(isFinalizationPermitted(makeSession('ACTIVE'))).toBe(false);
  });

  it('returns true for ENDED session', () => {
    expect(isFinalizationPermitted(makeSession('ENDED'))).toBe(true);
  });
});
