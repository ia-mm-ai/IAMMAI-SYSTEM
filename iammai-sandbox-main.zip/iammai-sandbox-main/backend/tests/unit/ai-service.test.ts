/**
 * Unit test for AI service streamChat function
 * @see specs/001-ephemeral-kernel/tasks.md#T068
 *
 * NOTE: These tests should FAIL initially (TDD approach)
 */

import { describe, it, expect, vi, beforeEach } from 'vitest';
import { streamChat, chat } from '../../src/services/ai.js';
import type { Message } from '../../src/lib/types.js';

// Mock OpenAI
vi.mock('openai', () => {
  return {
    default: class MockOpenAI {
      chat = {
        completions: {
          create: vi.fn(),
        },
      };
    },
  };
});

describe('AI Service - streamChat', () => {
  beforeEach(() => {
    vi.clearAllMocks();
  });

  it('should yield chunks from streaming response', async () => {
    // Mock streaming response
    const mockChunks = [
      { choices: [{ delta: { content: 'Hello' } }] },
      { choices: [{ delta: { content: ' there' } }] },
      { choices: [{ delta: { content: '!' } }] },
      { choices: [{ delta: {} }] }, // Empty delta
    ];

    const mockStream = {
      async *[Symbol.asyncIterator]() {
        for (const chunk of mockChunks) {
          yield chunk;
        }
      },
    };

    // Get OpenAI mock instance
    const OpenAI = (await import('openai')).default;
    const openai = new OpenAI({ apiKey: 'test-key' });
    vi.mocked(openai.chat.completions.create).mockResolvedValue(mockStream as any);

    // Test streaming
    const history: Message[] = [
      {
        id: 'msg-1',
        role: 'user',
        content: 'Hi',
        timestamp: new Date(),
      },
    ];

    const chunks: string[] = [];
    for await (const chunk of streamChat(history, 'How are you?')) {
      chunks.push(chunk);
    }

    expect(chunks).toEqual(['Hello', ' there', '!']);
  });

  it('should include conversation history in API call', async () => {
    const mockStream = {
      async *[Symbol.asyncIterator]() {
        yield { choices: [{ delta: { content: 'Response' } }] };
      },
    };

    const OpenAI = (await import('openai')).default;
    const openai = new OpenAI({ apiKey: 'test-key' });
    const createMock = vi.mocked(openai.chat.completions.create);
    createMock.mockResolvedValue(mockStream as any);

    const history: Message[] = [
      {
        id: 'msg-1',
        role: 'user',
        content: 'First message',
        timestamp: new Date(),
      },
      {
        id: 'msg-2',
        role: 'assistant',
        content: 'First response',
        timestamp: new Date(),
      },
    ];

    const chunks: string[] = [];
    for await (const chunk of streamChat(history, 'Second message')) {
      chunks.push(chunk);
    }

    // Verify API was called with history
    expect(createMock).toHaveBeenCalledWith(
      expect.objectContaining({
        messages: expect.arrayContaining([
          expect.objectContaining({ role: 'system' }),
          expect.objectContaining({ role: 'user', content: 'First message' }),
          expect.objectContaining({ role: 'assistant', content: 'First response' }),
          expect.objectContaining({ role: 'user', content: 'Second message' }),
        ]),
        stream: true,
      })
    );
  });

  it('should include system prompt in messages', async () => {
    const mockStream = {
      async *[Symbol.asyncIterator]() {
        yield { choices: [{ delta: { content: 'Response' } }] };
      },
    };

    const OpenAI = (await import('openai')).default;
    const openai = new OpenAI({ apiKey: 'test-key' });
    const createMock = vi.mocked(openai.chat.completions.create);
    createMock.mockResolvedValue(mockStream as any);

    const history: Message[] = [];

    for await (const chunk of streamChat(history, 'Hello')) {
      // Consume stream
    }

    // Verify system prompt is first message
    const callArgs = createMock.mock.calls[0][0];
    expect(callArgs.messages[0]).toEqual(
      expect.objectContaining({
        role: 'system',
        content: expect.stringContaining('helpful AI assistant'),
      })
    );
  });

  it('should handle empty chunks gracefully', async () => {
    const mockChunks = [
      { choices: [{ delta: { content: 'Start' } }] },
      { choices: [{ delta: {} }] }, // Empty delta
      { choices: [{ delta: { content: undefined } }] }, // Undefined content
      { choices: [{ delta: { content: '' } }] }, // Empty content
      { choices: [{ delta: { content: 'End' } }] },
    ];

    const mockStream = {
      async *[Symbol.asyncIterator]() {
        for (const chunk of mockChunks) {
          yield chunk;
        }
      },
    };

    const OpenAI = (await import('openai')).default;
    const openai = new OpenAI({ apiKey: 'test-key' });
    vi.mocked(openai.chat.completions.create).mockResolvedValue(mockStream as any);

    const chunks: string[] = [];
    for await (const chunk of streamChat([], 'Test')) {
      chunks.push(chunk);
    }

    // Should only yield non-empty chunks
    expect(chunks).toEqual(['Start', 'End']);
  });

  it('should use correct model and parameters', async () => {
    const mockStream = {
      async *[Symbol.asyncIterator]() {
        yield { choices: [{ delta: { content: 'Response' } }] };
      },
    };

    const OpenAI = (await import('openai')).default;
    const openai = new OpenAI({ apiKey: 'test-key' });
    const createMock = vi.mocked(openai.chat.completions.create);
    createMock.mockResolvedValue(mockStream as any);

    for await (const chunk of streamChat([], 'Test')) {
      // Consume stream
    }

    expect(createMock).toHaveBeenCalledWith(
      expect.objectContaining({
        model: expect.any(String),
        stream: true,
        max_tokens: 2048,
        temperature: 0.7,
      })
    );
  });

  it('should throw error on API failure', async () => {
    const OpenAI = (await import('openai')).default;
    const openai = new OpenAI({ apiKey: 'test-key' });
    vi.mocked(openai.chat.completions.create).mockRejectedValue(
      new Error('API Error')
    );

    await expect(async () => {
      for await (const chunk of streamChat([], 'Test')) {
        // Should not reach here
      }
    }).rejects.toThrow('API Error');
  });
});

describe('AI Service - chat (non-streaming)', () => {
  beforeEach(() => {
    vi.clearAllMocks();
  });

  it('should return complete response', async () => {
    const mockResponse = {
      choices: [
        {
          message: {
            content: 'Complete response text',
          },
        },
      ],
    };

    const OpenAI = (await import('openai')).default;
    const openai = new OpenAI({ apiKey: 'test-key' });
    vi.mocked(openai.chat.completions.create).mockResolvedValue(mockResponse as any);

    const response = await chat([], 'Test message');

    expect(response).toBe('Complete response text');
  });

  it('should include conversation history', async () => {
    const mockResponse = {
      choices: [{ message: { content: 'Response' } }],
    };

    const OpenAI = (await import('openai')).default;
    const openai = new OpenAI({ apiKey: 'test-key' });
    const createMock = vi.mocked(openai.chat.completions.create);
    createMock.mockResolvedValue(mockResponse as any);

    const history: Message[] = [
      {
        id: 'msg-1',
        role: 'user',
        content: 'Previous message',
        timestamp: new Date(),
      },
    ];

    await chat(history, 'New message');

    expect(createMock).toHaveBeenCalledWith(
      expect.objectContaining({
        messages: expect.arrayContaining([
          expect.objectContaining({ role: 'system' }),
          expect.objectContaining({ role: 'user', content: 'Previous message' }),
          expect.objectContaining({ role: 'user', content: 'New message' }),
        ]),
      })
    );
  });

  it('should return empty string if no content in response', async () => {
    const mockResponse = {
      choices: [{ message: {} }],
    };

    const OpenAI = (await import('openai')).default;
    const openai = new OpenAI({ apiKey: 'test-key' });
    vi.mocked(openai.chat.completions.create).mockResolvedValue(mockResponse as any);

    const response = await chat([], 'Test');

    expect(response).toBe('');
  });

  it('should not use streaming', async () => {
    const mockResponse = {
      choices: [{ message: { content: 'Response' } }],
    };

    const OpenAI = (await import('openai')).default;
    const openai = new OpenAI({ apiKey: 'test-key' });
    const createMock = vi.mocked(openai.chat.completions.create);
    createMock.mockResolvedValue(mockResponse as any);

    await chat([], 'Test');

    // Verify stream is not set (or explicitly false)
    const callArgs = createMock.mock.calls[0][0];
    expect(callArgs.stream).toBeUndefined();
  });
});
