/**
 * Performance benchmark for kernel dissolution
 * @see specs/001-ephemeral-kernel/tasks.md#T109
 * @see specs/001-ephemeral-kernel/spec.md Constitution Principle IV
 *
 * REQUIREMENT: Dissolution must complete in <50ms
 */

import { describe, it, expect, beforeEach } from 'vitest';
import { kernelManager } from '../../src/kernel/manager.js';
import { generateToken } from '../../src/services/token.js';

beforeEach(() => {
  // Clear all kernels between tests
  for (const sessionId of Array.from(kernelManager['kernels'].keys())) {
    kernelManager.dissolveKernel(sessionId);
  }
});

describe('Performance: Kernel Dissolution (<50ms requirement)', () => {
  it('should dissolve kernel with 1 conversation in <50ms', () => {
    const sessionId = 'perf-test-1-conv';
    kernelManager.createKernel(sessionId);

    const token = generateToken();
    kernelManager.getOrCreateConversation(sessionId, token.hash, 'presence-1');

    // Add realistic conversation (10 messages, ~200 chars each)
    for (let i = 0; i < 10; i++) {
      kernelManager.addMessage(
        sessionId,
        token.hash,
        i % 2 === 0 ? 'user' : 'assistant',
        'A'.repeat(200)
      );
    }

    const start = performance.now();
    kernelManager.dissolveKernel(sessionId);
    const duration = performance.now() - start;

    expect(duration).toBeLessThan(50);
  });

  it('should dissolve kernel with 10 conversations in <50ms', () => {
    const sessionId = 'perf-test-10-conv';
    kernelManager.createKernel(sessionId);

    // Create 10 conversations with realistic message counts
    for (let i = 0; i < 10; i++) {
      const token = generateToken();
      kernelManager.getOrCreateConversation(sessionId, token.hash, `presence-${i}`);

      // 5-15 messages per conversation
      const messageCount = 5 + (i % 10);
      for (let j = 0; j < messageCount; j++) {
        kernelManager.addMessage(
          sessionId,
          token.hash,
          j % 2 === 0 ? 'user' : 'assistant',
          'A'.repeat(200)
        );
      }
    }

    const start = performance.now();
    kernelManager.dissolveKernel(sessionId);
    const duration = performance.now() - start;

    // Constitution Principle IV: <50ms even with multiple conversations
    expect(duration).toBeLessThan(50);
  });

  it('should dissolve kernel with 100 conversations in <50ms (max capacity)', () => {
    const sessionId = 'perf-test-100-conv';
    kernelManager.createKernel(sessionId);

    // Max capacity: 100 concurrent users
    for (let i = 0; i < 100; i++) {
      const token = generateToken();
      kernelManager.getOrCreateConversation(sessionId, token.hash, `presence-${i}`);

      // Minimal conversation (2 messages)
      kernelManager.addMessage(sessionId, token.hash, 'user', 'Hello');
      kernelManager.addMessage(sessionId, token.hash, 'assistant', 'Hi!');
    }

    const start = performance.now();
    kernelManager.dissolveKernel(sessionId);
    const duration = performance.now() - start;

    // Must still meet <50ms requirement at max capacity
    expect(duration).toBeLessThan(50);
  });

  it('should dissolve kernel with long conversations in <50ms', () => {
    const sessionId = 'perf-test-long-conv';
    kernelManager.createKernel(sessionId);

    const token = generateToken();
    kernelManager.getOrCreateConversation(sessionId, token.hash, 'presence-long');

    // Create a very long conversation (100 messages with long content)
    for (let i = 0; i < 100; i++) {
      kernelManager.addMessage(
        sessionId,
        token.hash,
        i % 2 === 0 ? 'user' : 'assistant',
        'A'.repeat(1000)
      );
    }

    const start = performance.now();
    kernelManager.dissolveKernel(sessionId);
    const duration = performance.now() - start;

    // Even with long conversation, must complete quickly
    expect(duration).toBeLessThan(50);
  });

  it('should measure average dissolution time over multiple runs', () => {
    const runs = 100;
    const times: number[] = [];

    for (let run = 0; run < runs; run++) {
      const sessionId = `perf-test-run-${run}`;
      kernelManager.createKernel(sessionId);

      // Create realistic scenario: 5 conversations, 10 messages each
      for (let i = 0; i < 5; i++) {
        const token = generateToken();
        kernelManager.getOrCreateConversation(sessionId, token.hash, `presence-${run}-${i}`);

        for (let j = 0; j < 10; j++) {
          kernelManager.addMessage(
            sessionId,
            token.hash,
            j % 2 === 0 ? 'user' : 'assistant',
            'Test message content'
          );
        }
      }

      const start = performance.now();
      kernelManager.dissolveKernel(sessionId);
      const duration = performance.now() - start;

      times.push(duration);
    }

    const average = times.reduce((sum, t) => sum + t, 0) / times.length;
    const max = Math.max(...times);
    const sortedTimes = [...times].sort((a, b) => a - b);
    const p95 = sortedTimes[Math.floor(runs * 0.95)];
    const p99 = sortedTimes[Math.floor(runs * 0.99)];

    // Report statistics
    console.log('\n=== Dissolution Performance Benchmark ===');
    console.log(`Runs:    ${runs}`);
    console.log(`Average: ${average.toFixed(2)}ms`);
    console.log(`Max:     ${max.toFixed(2)}ms`);
    console.log(`P95:     ${p95.toFixed(2)}ms`);
    console.log(`P99:     ${p99.toFixed(2)}ms`);
    console.log('=========================================\n');

    // All runs must meet requirement
    expect(max).toBeLessThan(50);
    expect(p95).toBeLessThan(50);
    expect(p99).toBeLessThan(50);
    expect(average).toBeLessThan(50);
  });

  it('should verify dissolution is synchronous (no async cleanup)', () => {
    const sessionId = 'perf-test-sync';
    kernelManager.createKernel(sessionId);

    const token = generateToken();
    kernelManager.getOrCreateConversation(sessionId, token.hash, 'presence-sync');
    kernelManager.addMessage(sessionId, token.hash, 'user', 'Test message');

    // Dissolve should be synchronous
    kernelManager.dissolveKernel(sessionId);

    // Immediately after dissolution, data should be inaccessible
    const history = kernelManager.getConversationHistory(sessionId, token.hash);
    expect(history).toEqual([]);

    // No "await" or setTimeout should be needed
    const conv = kernelManager.getOrCreateConversation(sessionId, token.hash, 'presence-sync');
    expect(conv).toBeNull();
  });

  it('should benchmark realistic mixed workload', () => {
    const sessionId = 'perf-test-mixed';
    kernelManager.createKernel(sessionId);

    // Simulate realistic mixed scenario:
    // - 20 users with varying conversation lengths
    // - Some have long conversations, some short
    // - Varying message sizes

    const tokens = Array.from({ length: 20 }, () => generateToken());

    tokens.forEach((token, i) => {
      kernelManager.getOrCreateConversation(sessionId, token.hash, `presence-${i}`);

      // Varying conversation lengths (1-50 messages)
      const messageCount = 1 + Math.floor(Math.random() * 50);

      for (let j = 0; j < messageCount; j++) {
        // Varying message sizes (50-500 chars)
        const messageSize = 50 + Math.floor(Math.random() * 450);
        kernelManager.addMessage(
          sessionId,
          token.hash,
          j % 2 === 0 ? 'user' : 'assistant',
          'A'.repeat(messageSize)
        );
      }
    });

    const start = performance.now();
    kernelManager.dissolveKernel(sessionId);
    const duration = performance.now() - start;

    console.log(`Mixed workload dissolution: ${duration.toFixed(2)}ms`);
    expect(duration).toBeLessThan(50);
  });

  it('should benchmark worst-case scenario', () => {
    const sessionId = 'perf-test-worst-case';
    kernelManager.createKernel(sessionId);

    // Worst case:
    // - 100 users (max capacity)
    // - Each with maximum realistic conversation (50 messages)
    // - Maximum message sizes (2000 chars)

    for (let i = 0; i < 100; i++) {
      const token = generateToken();
      kernelManager.getOrCreateConversation(sessionId, token.hash, `presence-${i}`);

      for (let j = 0; j < 50; j++) {
        kernelManager.addMessage(
          sessionId,
          token.hash,
          j % 2 === 0 ? 'user' : 'assistant',
          'A'.repeat(2000)
        );
      }
    }

    const start = performance.now();
    kernelManager.dissolveKernel(sessionId);
    const duration = performance.now() - start;

    console.log(`Worst-case dissolution: ${duration.toFixed(2)}ms`);
    expect(duration).toBeLessThan(50);
  });
});
