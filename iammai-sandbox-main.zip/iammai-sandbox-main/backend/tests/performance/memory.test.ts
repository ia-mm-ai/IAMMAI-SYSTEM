/**
 * Memory profiling test for kernel manager
 * @see specs/001-ephemeral-kernel/tasks.md#T110
 * @see specs/001-ephemeral-kernel/plan.md Performance Constraints
 *
 * REQUIREMENT: 100 concurrent users < 512MB memory
 */

import { describe, it, expect, beforeEach } from 'vitest';
import { kernelManager } from '../../src/kernel/manager.js';
import { generateToken } from '../../src/services/token.js';

beforeEach(() => {
  // Clear all kernels between tests
  for (const sessionId of Array.from(kernelManager['kernels'].keys())) {
    kernelManager.dissolveKernel(sessionId);
  }
  // Force garbage collection if available
  if (global.gc) {
    global.gc();
  }
});

/**
 * Get current memory usage in MB
 */
function getMemoryUsageMB(): number {
  const usage = process.memoryUsage();
  return usage.heapUsed / 1024 / 1024;
}

describe('Performance: Memory Usage (<512MB for 100 users)', () => {
  it('should use minimal memory for empty kernel', () => {
    const sessionId = 'memory-test-empty';

    const beforeMB = getMemoryUsageMB();
    kernelManager.createKernel(sessionId);
    const afterMB = getMemoryUsageMB();

    const usedMB = afterMB - beforeMB;

    // Empty kernel should use < 1MB
    expect(usedMB).toBeLessThan(1);

    kernelManager.dissolveKernel(sessionId);
  });

  it('should handle 10 users with conversations efficiently', () => {
    const sessionId = 'memory-test-10-users';

    const beforeMB = getMemoryUsageMB();
    kernelManager.createKernel(sessionId);

    // Create 10 conversations
    for (let i = 0; i < 10; i++) {
      const token = generateToken();
      kernelManager.getOrCreateConversation(sessionId, token.hash, `presence-${i}`);

      // 10 messages per conversation
      for (let j = 0; j < 10; j++) {
        kernelManager.addMessage(
          sessionId,
          token.hash,
          j % 2 === 0 ? 'user' : 'assistant',
          'A'.repeat(200)
        );
      }
    }

    const afterMB = getMemoryUsageMB();
    const usedMB = afterMB - beforeMB;

    console.log(`10 users memory usage: ${usedMB.toFixed(2)}MB`);

    // 10 users with 10 messages each (200 chars) should use < 10MB
    expect(usedMB).toBeLessThan(10);

    kernelManager.dissolveKernel(sessionId);
  });

  it('should handle 100 users within 512MB memory limit', () => {
    const sessionId = 'memory-test-100-users';

    const beforeMB = getMemoryUsageMB();
    kernelManager.createKernel(sessionId);

    // Create 100 conversations (max capacity)
    for (let i = 0; i < 100; i++) {
      const token = generateToken();
      kernelManager.getOrCreateConversation(sessionId, token.hash, `presence-${i}`);

      // Realistic conversation: 20 messages, varying sizes
      for (let j = 0; j < 20; j++) {
        const messageSize = 100 + Math.floor(Math.random() * 400);
        kernelManager.addMessage(
          sessionId,
          token.hash,
          j % 2 === 0 ? 'user' : 'assistant',
          'A'.repeat(messageSize)
        );
      }
    }

    const afterMB = getMemoryUsageMB();
    const usedMB = afterMB - beforeMB;

    console.log(`100 users memory usage: ${usedMB.toFixed(2)}MB`);
    console.log(`Remaining headroom: ${(512 - usedMB).toFixed(2)}MB`);

    // CRITICAL: Must stay under 512MB for 100 users
    expect(usedMB).toBeLessThan(512);

    // Additionally verify reasonable usage (should be well under limit)
    expect(usedMB).toBeLessThan(100); // Should use < 100MB in practice

    kernelManager.dissolveKernel(sessionId);
  });

  it('should verify memory is freed after dissolution', async () => {
    const sessionId = 'memory-test-cleanup';

    kernelManager.createKernel(sessionId);

    // Create 50 conversations
    for (let i = 0; i < 50; i++) {
      const token = generateToken();
      kernelManager.getOrCreateConversation(sessionId, token.hash, `presence-${i}`);

      for (let j = 0; j < 20; j++) {
        kernelManager.addMessage(
          sessionId,
          token.hash,
          j % 2 === 0 ? 'user' : 'assistant',
          'A'.repeat(500)
        );
      }
    }

    const withDataMB = getMemoryUsageMB();

    // Dissolve kernel
    kernelManager.dissolveKernel(sessionId);

    // Force GC if available
    if (global.gc) {
      global.gc();
    }

    // Wait a bit for GC
    await new Promise(resolve => setTimeout(resolve, 100));

    const afterDissolveMB = getMemoryUsageMB();
    const freedMB = withDataMB - afterDissolveMB;

    console.log(`Memory freed after dissolution: ${freedMB.toFixed(2)}MB`);
    console.log(`Memory before: ${withDataMB.toFixed(2)}MB, after: ${afterDissolveMB.toFixed(2)}MB`);

    // Note: GC is non-deterministic and may not run immediately
    // The important thing is that the data is no longer accessible
    // Memory will be freed eventually by GC
    // We just verify dissolution completed without error
    expect(kernelManager.hasKernel(sessionId)).toBe(false);
  });

  it('should profile memory usage per conversation', () => {
    const sessionId = 'memory-test-per-conv';
    kernelManager.createKernel(sessionId);

    const beforeMB = getMemoryUsageMB();

    // Add one conversation
    const token = generateToken();
    kernelManager.getOrCreateConversation(sessionId, token.hash, 'presence-test');

    // Add 10 messages
    for (let i = 0; i < 10; i++) {
      kernelManager.addMessage(
        sessionId,
        token.hash,
        i % 2 === 0 ? 'user' : 'assistant',
        'A'.repeat(200)
      );
    }

    const afterMB = getMemoryUsageMB();
    const perConvMB = afterMB - beforeMB;

    console.log(`Memory per conversation (10 messages): ${perConvMB.toFixed(2)}MB`);

    // Single conversation should use minimal memory
    expect(perConvMB).toBeLessThan(1);

    kernelManager.dissolveKernel(sessionId);
  });

  it('should measure memory usage with varying message sizes', () => {
    const sessionId = 'memory-test-message-sizes';
    kernelManager.createKernel(sessionId);

    const results: Array<{ size: number; memoryMB: number }> = [];

    // Test different message sizes
    const sizes = [100, 500, 1000, 2000, 5000];

    for (const size of sizes) {
      const token = generateToken();
      kernelManager.getOrCreateConversation(sessionId, token.hash, `presence-${size}`);

      const beforeMB = getMemoryUsageMB();

      // Add 10 messages of this size
      for (let i = 0; i < 10; i++) {
        kernelManager.addMessage(
          sessionId,
          token.hash,
          i % 2 === 0 ? 'user' : 'assistant',
          'A'.repeat(size)
        );
      }

      const afterMB = getMemoryUsageMB();
      const usedMB = afterMB - beforeMB;

      results.push({ size, memoryMB: usedMB });
    }

    console.log('\nMemory usage by message size (10 messages):');
    results.forEach(r => {
      console.log(`  ${r.size} chars: ${r.memoryMB.toFixed(2)}MB`);
    });

    // Even large messages should stay reasonable
    results.forEach(r => {
      expect(r.memoryMB).toBeLessThan(10);
    });

    kernelManager.dissolveKernel(sessionId);
  });

  it('should measure total memory for realistic production scenario', () => {
    const sessionId = 'memory-test-production';

    const beforeMB = getMemoryUsageMB();
    kernelManager.createKernel(sessionId);

    // Production scenario:
    // - 50 active users (typical load)
    // - Average 15 messages per conversation
    // - Average message size 300 chars

    for (let i = 0; i < 50; i++) {
      const token = generateToken();
      kernelManager.getOrCreateConversation(sessionId, token.hash, `presence-${i}`);

      const messageCount = 10 + Math.floor(Math.random() * 10); // 10-20 messages

      for (let j = 0; j < messageCount; j++) {
        const messageSize = 100 + Math.floor(Math.random() * 400); // 100-500 chars
        kernelManager.addMessage(
          sessionId,
          token.hash,
          j % 2 === 0 ? 'user' : 'assistant',
          'A'.repeat(messageSize)
        );
      }
    }

    const afterMB = getMemoryUsageMB();
    const usedMB = afterMB - beforeMB;

    console.log(`\nProduction scenario (50 users):`);
    console.log(`  Total memory: ${usedMB.toFixed(2)}MB`);
    console.log(`  Per user: ${(usedMB / 50).toFixed(2)}MB`);
    console.log(`  Projected for 100 users: ${(usedMB * 2).toFixed(2)}MB`);

    // 50 users should use well under 256MB
    expect(usedMB).toBeLessThan(256);

    // Projected 100 users should still be under 512MB
    expect(usedMB * 2).toBeLessThan(512);

    kernelManager.dissolveKernel(sessionId);
  });
});
