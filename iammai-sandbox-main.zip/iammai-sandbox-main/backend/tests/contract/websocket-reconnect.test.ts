/**
 * Contract Test: WebSocket Reconnection Protocol
 *
 * Tests CONNECTION_ACK includes conversation history when reconnecting
 *
 * Verifies contracts/websocket.md CONNECTION_ACK payload structure
 */

import { describe, it, expect, beforeAll, afterAll, beforeEach } from 'vitest';
import WebSocket from 'ws';
import { Session } from '../../src/models/session';
import { Token as TokenModel } from '../../src/models/token';
import { kernelManager } from '../../src/kernel/manager';
import { generateToken, hashToken } from '../../src/services/token';
import { derivePresenceHash } from '../../src/services/presence';
import { pool } from '../../src/lib/db';

describe('Contract: WebSocket Reconnection (CONNECTION_ACK)', () => {
  let sessionId: string;
  let token: string;
  let tokenHash: string;
  let presenceHash: string;
  let wsUrl: string;

  beforeAll(async () => {
    wsUrl = process.env.WS_TEST_URL || 'ws://localhost:3001';
  });

  afterAll(async () => {
    await pool.end();
  });

  beforeEach(async () => {
    await pool.query('DELETE FROM tokens');
    await pool.query('DELETE FROM sessions');

    const session = await Session.create('Reconnect Protocol Test');
    sessionId = session.id;
    await Session.transitionState(sessionId, 'ACTIVE');

    kernelManager.createKernel(sessionId);

    token = generateToken();
    tokenHash = hashToken(token);
    const seed = token.substring(0, 16);
    presenceHash = derivePresenceHash(seed);

    await TokenModel.create(sessionId, tokenHash);
    await TokenModel.markJoined(tokenHash);
  });

  it('should send CONNECTION_ACK with empty history for new connection', async () => {
    return new Promise<void>((resolve, reject) => {
      const ws = new WebSocket(wsUrl, {
        headers: { 'Authorization': `Bearer ${token}` }
      });

      ws.on('message', (data: Buffer) => {
        const msg = JSON.parse(data.toString());

        if (msg.type === 'CONNECTION_ACK') {
          // Verify payload structure per contracts/websocket.md
          expect(msg.type).toBe('CONNECTION_ACK');
          expect(msg.payload).toBeDefined();
          expect(msg.payload.sessionId).toBe(sessionId);
          expect(msg.payload.presenceHash).toBe(presenceHash);
          expect(msg.payload.conversationHistory).toBeDefined();
          expect(Array.isArray(msg.payload.conversationHistory)).toBe(true);
          expect(msg.payload.conversationHistory.length).toBe(0);

          ws.close();
          resolve();
        }
      });

      ws.on('error', reject);
    });
  });

  it('should send CONNECTION_ACK with history after conversation exists', async () => {
    return new Promise<void>(async (resolve, reject) => {
      try {
        // First connection: establish conversation
        const ws1 = new WebSocket(wsUrl, {
          headers: { 'Authorization': `Bearer ${token}` }
        });

        await new Promise<void>((connectResolve) => {
          ws1.on('open', () => connectResolve());
        });

        await new Promise<void>((ackResolve) => {
          ws1.on('message', (data: Buffer) => {
            const msg = JSON.parse(data.toString());
            if (msg.type === 'CONNECTION_ACK') ackResolve();
          });
        });

        // Send message
        ws1.send(JSON.stringify({
          type: 'USER_MESSAGE',
          payload: { content: 'Test message for history' }
        }));

        await new Promise<void>((completeResolve) => {
          ws1.on('message', (data: Buffer) => {
            const msg = JSON.parse(data.toString());
            if (msg.type === 'MESSAGE_COMPLETE') completeResolve();
          });
        });

        ws1.close();
        await new Promise<void>((closeResolve) => {
          ws1.on('close', () => closeResolve());
        });

        // Second connection: verify history in CONNECTION_ACK
        const ws2 = new WebSocket(wsUrl, {
          headers: { 'Authorization': `Bearer ${token}` }
        });

        ws2.on('message', (data: Buffer) => {
          const msg = JSON.parse(data.toString());

          if (msg.type === 'CONNECTION_ACK') {
            // Verify payload with history
            expect(msg.type).toBe('CONNECTION_ACK');
            expect(msg.payload).toBeDefined();
            expect(msg.payload.sessionId).toBe(sessionId);
            expect(msg.payload.presenceHash).toBe(presenceHash);
            expect(msg.payload.conversationHistory).toBeDefined();
            expect(Array.isArray(msg.payload.conversationHistory)).toBe(true);
            expect(msg.payload.conversationHistory.length).toBeGreaterThanOrEqual(2);

            // Verify message structure per contracts/websocket.md
            const userMessage = msg.payload.conversationHistory.find(
              (m: any) => m.role === 'user'
            );
            expect(userMessage).toBeDefined();
            expect(userMessage.id).toBeDefined();
            expect(userMessage.role).toBe('user');
            expect(userMessage.content).toBe('Test message for history');
            expect(userMessage.timestamp).toBeDefined();

            const assistantMessage = msg.payload.conversationHistory.find(
              (m: any) => m.role === 'assistant'
            );
            expect(assistantMessage).toBeDefined();
            expect(assistantMessage.id).toBeDefined();
            expect(assistantMessage.role).toBe('assistant');
            expect(assistantMessage.content).toBeDefined();
            expect(assistantMessage.timestamp).toBeDefined();

            ws2.close();
            resolve();
          }
        });

        ws2.on('error', reject);

      } catch (error) {
        reject(error);
      }
    });
  });

  it('should maintain conversation history across multiple reconnections', async () => {
    return new Promise<void>(async (resolve, reject) => {
      try {
        const messageContents: string[] = [];

        // Connection 1: Send message 1
        let ws = new WebSocket(wsUrl, {
          headers: { 'Authorization': `Bearer ${token}` }
        });

        await new Promise<void>((connectResolve) => {
          ws.on('open', () => connectResolve());
        });

        await new Promise<void>((ackResolve) => {
          ws.on('message', (data: Buffer) => {
            const msg = JSON.parse(data.toString());
            if (msg.type === 'CONNECTION_ACK') ackResolve();
          });
        });

        const msg1 = 'First message';
        messageContents.push(msg1);
        ws.send(JSON.stringify({
          type: 'USER_MESSAGE',
          payload: { content: msg1 }
        }));

        await new Promise<void>((completeResolve) => {
          ws.on('message', (data: Buffer) => {
            const msg = JSON.parse(data.toString());
            if (msg.type === 'MESSAGE_COMPLETE') completeResolve();
          });
        });

        ws.close();
        await new Promise<void>((closeResolve) => {
          ws.on('close', () => closeResolve());
        });

        // Connection 2: Send message 2
        ws = new WebSocket(wsUrl, {
          headers: { 'Authorization': `Bearer ${token}` }
        });

        await new Promise<void>((connectResolve) => {
          ws.on('open', () => connectResolve());
        });

        await new Promise<void>((ackResolve) => {
          ws.on('message', (data: Buffer) => {
            const msg = JSON.parse(data.toString());
            if (msg.type === 'CONNECTION_ACK') ackResolve();
          });
        });

        const msg2 = 'Second message';
        messageContents.push(msg2);
        ws.send(JSON.stringify({
          type: 'USER_MESSAGE',
          payload: { content: msg2 }
        }));

        await new Promise<void>((completeResolve) => {
          ws.on('message', (data: Buffer) => {
            const msg = JSON.parse(data.toString());
            if (msg.type === 'MESSAGE_COMPLETE') completeResolve();
          });
        });

        ws.close();
        await new Promise<void>((closeResolve) => {
          ws.on('close', () => closeResolve());
        });

        // Connection 3: Verify all history present
        ws = new WebSocket(wsUrl, {
          headers: { 'Authorization': `Bearer ${token}` }
        });

        ws.on('message', (data: Buffer) => {
          const msg = JSON.parse(data.toString());

          if (msg.type === 'CONNECTION_ACK') {
            expect(msg.payload.conversationHistory.length).toBeGreaterThanOrEqual(4);

            // Verify both user messages are present
            const userMessages = msg.payload.conversationHistory.filter(
              (m: any) => m.role === 'user'
            );
            expect(userMessages.length).toBe(2);
            expect(userMessages[0].content).toBe(msg1);
            expect(userMessages[1].content).toBe(msg2);

            // Verify both AI responses are present
            const aiMessages = msg.payload.conversationHistory.filter(
              (m: any) => m.role === 'assistant'
            );
            expect(aiMessages.length).toBe(2);

            ws.close();
            resolve();
          }
        });

        ws.on('error', reject);

      } catch (error) {
        reject(error);
      }
    });
  });
});
