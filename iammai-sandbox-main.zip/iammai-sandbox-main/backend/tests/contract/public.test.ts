/**
 * Contract tests for public session endpoints
 * @see specs/001-ephemeral-kernel/tasks.md#T051
 * @see specs/001-ephemeral-kernel/contracts/api.yaml lines 233-257
 */

import { describe, it, expect, beforeAll, afterAll, afterEach } from 'vitest';
import request from 'supertest';
import type { Express } from 'express';
import { createApp } from '../../src/api/app.js';
import { query } from '../../src/lib/db.js';
import bcrypt from 'bcrypt';

describe('GET /api/v1/sessions (Public Browse)', () => {
  let app: Express;
  const testEmail = 'test-public@example.com';
  const testPassword = 'testPassword123!';
  let testAdminId: string;
  const createdSessionIds: string[] = [];

  beforeAll(async () => {
    app = createApp();

    // Create test admin (needed to create sessions)
    const passwordHash = await bcrypt.hash(testPassword, 10);
    const result = await query(
      `INSERT INTO admins (email, password_hash)
       VALUES ($1, $2)
       ON CONFLICT (email) DO UPDATE SET password_hash = $2
       RETURNING id`,
      [testEmail, passwordHash]
    );
    testAdminId = result.rows[0].id;
  });

  afterEach(async () => {
    // Clean up created sessions
    for (const sessionId of createdSessionIds) {
      await query('DELETE FROM sessions WHERE id = $1', [sessionId]);
    }
    createdSessionIds.length = 0;
  });

  afterAll(async () => {
    await query('DELETE FROM admins WHERE id = $1', [testAdminId]);
  });

  it('should return list of public sessions without authentication', async () => {
    // Create test sessions
    const createdSession = await query(
      `INSERT INTO sessions (name, admin_id, state)
       VALUES ($1, $2, 'CREATED') RETURNING id`,
      ['Public Created Session', testAdminId]
    );
    createdSessionIds.push(createdSession.rows[0].id);

    const activeSession = await query(
      `INSERT INTO sessions (name, admin_id, state, started_at)
       VALUES ($1, $2, 'ACTIVE', NOW()) RETURNING id`,
      ['Public Active Session', testAdminId]
    );
    createdSessionIds.push(activeSession.rows[0].id);

    const response = await request(app)
      .get('/api/v1/sessions')
      .expect('Content-Type', /json/)
      .expect(200);

    // Verify response structure per api.yaml#PublicSessionList
    expect(response.body).toHaveProperty('sessions');
    expect(Array.isArray(response.body.sessions)).toBe(true);
    expect(response.body.sessions.length).toBeGreaterThanOrEqual(2);
  });

  it('should return sessions with canClaim and canJoin flags', async () => {
    // Create a CREATED session
    const createdSession = await query(
      `INSERT INTO sessions (name, admin_id, state)
       VALUES ($1, $2, 'CREATED') RETURNING id`,
      ['Claimable Session', testAdminId]
    );
    createdSessionIds.push(createdSession.rows[0].id);

    // Create an ACTIVE session
    const activeSession = await query(
      `INSERT INTO sessions (name, admin_id, state, started_at)
       VALUES ($1, $2, 'ACTIVE', NOW()) RETURNING id`,
      ['Joinable Session', testAdminId]
    );
    createdSessionIds.push(activeSession.rows[0].id);

    const response = await request(app)
      .get('/api/v1/sessions')
      .expect(200);

    // Find the CREATED session - should have canClaim: true, canJoin: false
    const createdSessionResult = response.body.sessions.find(
      (s: { id: string }) => s.id === createdSession.rows[0].id
    );
    expect(createdSessionResult).toBeDefined();
    expect(createdSessionResult.canClaim).toBe(true);
    expect(createdSessionResult.canJoin).toBe(false);

    // Find the ACTIVE session - should have canClaim: false, canJoin: true
    const activeSessionResult = response.body.sessions.find(
      (s: { id: string }) => s.id === activeSession.rows[0].id
    );
    expect(activeSessionResult).toBeDefined();
    expect(activeSessionResult.canClaim).toBe(false);
    expect(activeSessionResult.canJoin).toBe(true);
  });

  it('should NOT return ENDED sessions', async () => {
    // Create an ENDED session
    const endedSession = await query(
      `INSERT INTO sessions (name, admin_id, state, started_at, ended_at)
       VALUES ($1, $2, 'ENDED', NOW(), NOW()) RETURNING id`,
      ['Ended Session', testAdminId]
    );
    createdSessionIds.push(endedSession.rows[0].id);

    const response = await request(app)
      .get('/api/v1/sessions')
      .expect(200);

    // Should not contain the ENDED session
    const endedSessionResult = response.body.sessions.find(
      (s: { id: string }) => s.id === endedSession.rows[0].id
    );
    expect(endedSessionResult).toBeUndefined();
  });

  it('should support filtering by state=CREATED', async () => {
    // Create sessions of different states
    const createdSession = await query(
      `INSERT INTO sessions (name, admin_id, state)
       VALUES ($1, $2, 'CREATED') RETURNING id`,
      ['Filter CREATED Session', testAdminId]
    );
    createdSessionIds.push(createdSession.rows[0].id);

    const activeSession = await query(
      `INSERT INTO sessions (name, admin_id, state, started_at)
       VALUES ($1, $2, 'ACTIVE', NOW()) RETURNING id`,
      ['Filter ACTIVE Session', testAdminId]
    );
    createdSessionIds.push(activeSession.rows[0].id);

    const response = await request(app)
      .get('/api/v1/sessions')
      .query({ state: 'CREATED' })
      .expect(200);

    // All returned sessions should be CREATED
    for (const session of response.body.sessions) {
      expect(session.state).toBe('CREATED');
    }
  });

  it('should support filtering by state=ACTIVE', async () => {
    // Create sessions of different states
    const createdSession = await query(
      `INSERT INTO sessions (name, admin_id, state)
       VALUES ($1, $2, 'CREATED') RETURNING id`,
      ['Filter2 CREATED Session', testAdminId]
    );
    createdSessionIds.push(createdSession.rows[0].id);

    const activeSession = await query(
      `INSERT INTO sessions (name, admin_id, state, started_at)
       VALUES ($1, $2, 'ACTIVE', NOW()) RETURNING id`,
      ['Filter2 ACTIVE Session', testAdminId]
    );
    createdSessionIds.push(activeSession.rows[0].id);

    const response = await request(app)
      .get('/api/v1/sessions')
      .query({ state: 'ACTIVE' })
      .expect(200);

    // All returned sessions should be ACTIVE
    for (const session of response.body.sessions) {
      expect(session.state).toBe('ACTIVE');
    }
  });

  it('should support limit parameter', async () => {
    // Create multiple sessions
    for (let i = 0; i < 5; i++) {
      const result = await query(
        `INSERT INTO sessions (name, admin_id, state)
         VALUES ($1, $2, 'CREATED') RETURNING id`,
        [`Limit Test Session ${i}`, testAdminId]
      );
      createdSessionIds.push(result.rows[0].id);
    }

    const response = await request(app)
      .get('/api/v1/sessions')
      .query({ limit: 3 })
      .expect(200);

    expect(response.body.sessions.length).toBeLessThanOrEqual(3);
  });

  it('should reject invalid state filter', async () => {
    const response = await request(app)
      .get('/api/v1/sessions')
      .query({ state: 'ENDED' }) // ENDED is not a valid filter for public endpoint
      .expect(400);

    expect(response.body).toHaveProperty('code', 'BAD_REQUEST');
  });
});

describe('GET /api/v1/sessions/{sessionId} (Public Session Info)', () => {
  let app: Express;
  const testEmail = 'test-public-detail@example.com';
  const testPassword = 'testPassword123!';
  let testAdminId: string;
  const createdSessionIds: string[] = [];

  beforeAll(async () => {
    app = createApp();

    const passwordHash = await bcrypt.hash(testPassword, 10);
    const result = await query(
      `INSERT INTO admins (email, password_hash)
       VALUES ($1, $2)
       ON CONFLICT (email) DO UPDATE SET password_hash = $2
       RETURNING id`,
      [testEmail, passwordHash]
    );
    testAdminId = result.rows[0].id;
  });

  afterEach(async () => {
    for (const sessionId of createdSessionIds) {
      await query('DELETE FROM sessions WHERE id = $1', [sessionId]);
    }
    createdSessionIds.length = 0;
  });

  afterAll(async () => {
    await query('DELETE FROM admins WHERE id = $1', [testAdminId]);
  });

  it('should return public session info for CREATED session', async () => {
    const result = await query(
      `INSERT INTO sessions (name, admin_id, state)
       VALUES ($1, $2, 'CREATED') RETURNING id`,
      ['Detail CREATED Session', testAdminId]
    );
    const sessionId = result.rows[0].id;
    createdSessionIds.push(sessionId);

    const response = await request(app)
      .get(`/api/v1/sessions/${sessionId}`)
      .expect('Content-Type', /json/)
      .expect(200);

    // Verify response structure per api.yaml#PublicSession
    expect(response.body).toHaveProperty('id', sessionId);
    expect(response.body).toHaveProperty('name', 'Detail CREATED Session');
    expect(response.body).toHaveProperty('state', 'CREATED');
    expect(response.body).toHaveProperty('canClaim', true);
    expect(response.body).toHaveProperty('canJoin', false);

    // Should NOT expose admin-only fields
    expect(response.body).not.toHaveProperty('tokenCount');
    expect(response.body).not.toHaveProperty('userCount');
    expect(response.body).not.toHaveProperty('adminId');
  });

  it('should return public session info for ACTIVE session', async () => {
    const result = await query(
      `INSERT INTO sessions (name, admin_id, state, started_at)
       VALUES ($1, $2, 'ACTIVE', NOW()) RETURNING id`,
      ['Detail ACTIVE Session', testAdminId]
    );
    const sessionId = result.rows[0].id;
    createdSessionIds.push(sessionId);

    const response = await request(app)
      .get(`/api/v1/sessions/${sessionId}`)
      .expect(200);

    expect(response.body).toHaveProperty('id', sessionId);
    expect(response.body).toHaveProperty('state', 'ACTIVE');
    expect(response.body).toHaveProperty('canClaim', false);
    expect(response.body).toHaveProperty('canJoin', true);
  });

  it('should return 404 for ENDED session', async () => {
    const result = await query(
      `INSERT INTO sessions (name, admin_id, state, started_at, ended_at)
       VALUES ($1, $2, 'ENDED', NOW(), NOW()) RETURNING id`,
      ['Detail ENDED Session', testAdminId]
    );
    const sessionId = result.rows[0].id;
    createdSessionIds.push(sessionId);

    const response = await request(app)
      .get(`/api/v1/sessions/${sessionId}`)
      .expect(404);

    expect(response.body).toHaveProperty('code', 'NOT_FOUND');
  });

  it('should return 404 for non-existent session', async () => {
    const fakeId = '00000000-0000-0000-0000-000000000000';

    const response = await request(app)
      .get(`/api/v1/sessions/${fakeId}`)
      .expect(404);

    expect(response.body).toHaveProperty('code', 'NOT_FOUND');
  });
});
