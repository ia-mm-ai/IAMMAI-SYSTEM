/**
 * Contract tests for chat endpoints
 * @see specs/001-ephemeral-kernel/tasks.md#T065
 * @see specs/001-ephemeral-kernel/contracts/api.yaml lines 341-376
 *
 * NOTE: These tests should FAIL initially (TDD approach)
 */

import { describe, it, expect, beforeAll, afterAll, beforeEach } from 'vitest';
import request from 'supertest';
import type { Express } from 'express';
import { createApp } from '../../src/api/app.js';
import { query } from '../../src/lib/db.js';
import bcrypt from 'bcrypt';
import { generateToken } from '../../src/services/token.js';
import { kernelManager } from '../../src/kernel/manager.js';

describe('POST /api/v1/sessions/{id}/messages', () => {
  let app: Express;
  let testAdminId: string;
  let testSessionId: string;
  let testToken: string;
  let testTokenHash: string;

  beforeAll(async () => {
    app = createApp();

    // Create test admin
    const passwordHash = await bcrypt.hash('testPassword123!', 10);
    const adminResult = await query(
      `INSERT INTO admins (email, password_hash)
       VALUES ($1, $2)
       ON CONFLICT (email) DO UPDATE SET password_hash = $2
       RETURNING id`,
      ['test-chat@example.com', passwordHash]
    );
    testAdminId = adminResult.rows[0].id;

    // Create test session
    const sessionResult = await query(
      `INSERT INTO sessions (name, state, admin_id)
       VALUES ($1, $2, $3)
       RETURNING id`,
      ['Test Chat Session', 'ACTIVE', testAdminId]
    );
    testSessionId = sessionResult.rows[0].id;

    // Generate and claim a token
    const tokenData = generateToken();
    testToken = tokenData.raw;
    testTokenHash = tokenData.hash;

    await query(
      `INSERT INTO tokens (session_id, token_hash)
       VALUES ($1, $2)`,
      [testSessionId, testTokenHash]
    );

    // Mark token as joined
    await query(
      `UPDATE tokens SET joined_at = NOW() WHERE token_hash = $1`,
      [testTokenHash]
    );

    // Create kernel for session
    kernelManager.createKernel(testSessionId);
  });

  afterAll(async () => {
    // Clean up kernel
    kernelManager.dissolveKernel(testSessionId);

    // Clean up database
    await query('DELETE FROM tokens WHERE session_id = $1', [testSessionId]);
    await query('DELETE FROM sessions WHERE id = $1', [testSessionId]);
    await query('DELETE FROM admins WHERE id = $1', [testAdminId]);
  });

  it('should return 202 with messageId on valid message', async () => {
    const messageId = 'test-message-' + Date.now();

    const response = await request(app)
      .post(`/api/v1/sessions/${testSessionId}/messages`)
      .set('Authorization', `Bearer ${testToken}`)
      .send({
        content: 'Hello, AI!',
        messageId,
      })
      .expect('Content-Type', /json/)
      .expect(202);

    // Verify response structure per api.yaml#MessageAccepted
    expect(response.body).toHaveProperty('messageId', messageId);
    expect(response.body).toHaveProperty('status', 'ACCEPTED');
  });

  it('should accept message without client messageId', async () => {
    const response = await request(app)
      .post(`/api/v1/sessions/${testSessionId}/messages`)
      .set('Authorization', `Bearer ${testToken}`)
      .send({
        content: 'Hello without messageId',
      })
      .expect('Content-Type', /json/)
      .expect(202);

    expect(response.body).toHaveProperty('messageId');
    expect(response.body).toHaveProperty('status', 'ACCEPTED');
  });

  it('should return 401 without authorization token', async () => {
    const response = await request(app)
      .post(`/api/v1/sessions/${testSessionId}/messages`)
      .send({
        content: 'Hello, AI!',
      })
      .expect('Content-Type', /json/)
      .expect(401);

    expect(response.body).toHaveProperty('code');
    expect(response.body.code).toBe('UNAUTHORIZED');
  });

  it('should return 401 with invalid token', async () => {
    const response = await request(app)
      .post(`/api/v1/sessions/${testSessionId}/messages`)
      .set('Authorization', 'Bearer invalid-token-123')
      .send({
        content: 'Hello, AI!',
      })
      .expect('Content-Type', /json/)
      .expect(401);

    expect(response.body).toHaveProperty('code', 'UNAUTHORIZED');
  });

  it('should return 401 when token does not match session', async () => {
    // Create another session
    const otherSessionResult = await query(
      `INSERT INTO sessions (name, state, admin_id)
       VALUES ($1, $2, $3)
       RETURNING id`,
      ['Other Session', 'ACTIVE', testAdminId]
    );
    const otherSessionId = otherSessionResult.rows[0].id;

    const response = await request(app)
      .post(`/api/v1/sessions/${otherSessionId}/messages`)
      .set('Authorization', `Bearer ${testToken}`)
      .send({
        content: 'Hello, AI!',
      })
      .expect('Content-Type', /json/)
      .expect(401);

    expect(response.body).toHaveProperty('code', 'UNAUTHORIZED');

    // Clean up
    await query('DELETE FROM sessions WHERE id = $1', [otherSessionId]);
  });

  it('should return 400 on empty message content', async () => {
    const response = await request(app)
      .post(`/api/v1/sessions/${testSessionId}/messages`)
      .set('Authorization', `Bearer ${testToken}`)
      .send({
        content: '',
      })
      .expect('Content-Type', /json/)
      .expect(400);

    expect(response.body).toHaveProperty('code', 'BAD_REQUEST');
  });

  it('should return 400 on message content exceeding 10000 characters', async () => {
    const longContent = 'a'.repeat(10001);

    const response = await request(app)
      .post(`/api/v1/sessions/${testSessionId}/messages`)
      .set('Authorization', `Bearer ${testToken}`)
      .send({
        content: longContent,
      })
      .expect('Content-Type', /json/)
      .expect(400);

    expect(response.body).toHaveProperty('code', 'BAD_REQUEST');
  });

  it('should return 400 when session is not ACTIVE', async () => {
    // Create CREATED session
    const createdSessionResult = await query(
      `INSERT INTO sessions (name, state, admin_id)
       VALUES ($1, $2, $3)
       RETURNING id`,
      ['Created Session', 'CREATED', testAdminId]
    );
    const createdSessionId = createdSessionResult.rows[0].id;

    // Create and join token for this session
    const tokenData = generateToken();
    await query(
      `INSERT INTO tokens (session_id, token_hash, joined_at)
       VALUES ($1, $2, NOW())`,
      [createdSessionId, tokenData.hash]
    );

    const response = await request(app)
      .post(`/api/v1/sessions/${createdSessionId}/messages`)
      .set('Authorization', `Bearer ${tokenData.raw}`)
      .send({
        content: 'Hello, AI!',
      })
      .expect('Content-Type', /json/)
      .expect(400);

    expect(response.body).toHaveProperty('code');
    expect(response.body.code).toBe('BAD_REQUEST');

    // Clean up
    await query('DELETE FROM tokens WHERE session_id = $1', [createdSessionId]);
    await query('DELETE FROM sessions WHERE id = $1', [createdSessionId]);
  });

  it('should return 404 when session does not exist', async () => {
    const nonexistentSessionId = '00000000-0000-0000-0000-000000000000';

    const response = await request(app)
      .post(`/api/v1/sessions/${nonexistentSessionId}/messages`)
      .set('Authorization', `Bearer ${testToken}`)
      .send({
        content: 'Hello, AI!',
      })
      .expect('Content-Type', /json/)
      .expect(404);

    expect(response.body).toHaveProperty('code', 'NOT_FOUND');
  });

  it('should return 400 when kernel does not exist for ACTIVE session', async () => {
    // Create ACTIVE session without kernel
    const activeSessionResult = await query(
      `INSERT INTO sessions (name, state, admin_id, started_at)
       VALUES ($1, $2, $3, NOW())
       RETURNING id`,
      ['Active No Kernel Session', 'ACTIVE', testAdminId]
    );
    const activeSessionId = activeSessionResult.rows[0].id;

    // Create and join token
    const tokenData = generateToken();
    await query(
      `INSERT INTO tokens (session_id, token_hash, joined_at)
       VALUES ($1, $2, NOW())`,
      [activeSessionId, tokenData.hash]
    );

    const response = await request(app)
      .post(`/api/v1/sessions/${activeSessionId}/messages`)
      .set('Authorization', `Bearer ${tokenData.raw}`)
      .send({
        content: 'Hello, AI!',
      })
      .expect('Content-Type', /json/)
      .expect(400);

    expect(response.body).toHaveProperty('code');

    // Clean up
    await query('DELETE FROM tokens WHERE session_id = $1', [activeSessionId]);
    await query('DELETE FROM sessions WHERE id = $1', [activeSessionId]);
  });
});
