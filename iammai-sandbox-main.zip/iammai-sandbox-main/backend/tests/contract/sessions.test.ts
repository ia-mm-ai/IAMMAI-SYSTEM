/**
 * Contract tests for admin session endpoints
 * @see specs/001-ephemeral-kernel/tasks.md#T034-T036
 * @see specs/001-ephemeral-kernel/contracts/api.yaml lines 124-228
 */

import { describe, it, expect, beforeAll, afterAll, beforeEach, afterEach } from 'vitest';
import request from 'supertest';
import type { Express } from 'express';
import { createApp } from '../../src/api/app.js';
import { closePool, query } from '../../src/lib/db.js';
import { kernelManager } from '../../src/kernel/manager.js';
import bcrypt from 'bcrypt';

describe('Admin Sessions API', () => {
  let app: Express;
  let authCookie: string;
  const testEmail = 'test-sessions@example.com';
  const testPassword = 'testPassword123!';
  let testAdminId: string;
  const createdSessionIds: string[] = [];

  beforeAll(async () => {
    app = createApp();

    // Create test admin and login
    const passwordHash = await bcrypt.hash(testPassword, 10);
    const result = await query(
      `INSERT INTO admins (email, password_hash)
       VALUES ($1, $2)
       ON CONFLICT (email) DO UPDATE SET password_hash = $2
       RETURNING id`,
      [testEmail, passwordHash]
    );
    testAdminId = result.rows[0].id;

    // Login to get auth cookie
    const loginResponse = await request(app)
      .post('/api/v1/auth/login')
      .send({ email: testEmail, password: testPassword });

    const cookies = loginResponse.headers['set-cookie'];
    authCookie = Array.isArray(cookies) ? cookies[0] : cookies;
  });

  afterEach(async () => {
    // Clean up created sessions
    for (const sessionId of createdSessionIds) {
      // Dissolve any kernels
      kernelManager.dissolveKernel(sessionId);
      // Delete from database
      await query('DELETE FROM sessions WHERE id = $1', [sessionId]);
    }
    createdSessionIds.length = 0;
  });

  afterAll(async () => {
    await query('DELETE FROM admins WHERE id = $1', [testAdminId]);
    await closePool();
  });

  describe('POST /api/v1/admin/sessions', () => {
    it('should create a session with valid name', async () => {
      const response = await request(app)
        .post('/api/v1/admin/sessions')
        .set('Cookie', authCookie)
        .send({ name: 'Test Session' })
        .expect('Content-Type', /json/)
        .expect(201);

      createdSessionIds.push(response.body.id);

      // Verify response structure per api.yaml#Session
      expect(response.body).toHaveProperty('id');
      expect(response.body).toHaveProperty('name', 'Test Session');
      expect(response.body).toHaveProperty('state', 'CREATED');
      expect(response.body).toHaveProperty('createdAt');
      expect(response.body).toHaveProperty('startedAt', null);
      expect(response.body).toHaveProperty('endedAt', null);
      expect(response.body).toHaveProperty('tokenCount', 0);
      expect(response.body).toHaveProperty('userCount', 0);
    });

    it('should return 400 on missing name', async () => {
      const response = await request(app)
        .post('/api/v1/admin/sessions')
        .set('Cookie', authCookie)
        .send({})
        .expect('Content-Type', /json/)
        .expect(400);

      expect(response.body).toHaveProperty('code', 'BAD_REQUEST');
    });

    it('should return 400 on empty name', async () => {
      const response = await request(app)
        .post('/api/v1/admin/sessions')
        .set('Cookie', authCookie)
        .send({ name: '' })
        .expect('Content-Type', /json/)
        .expect(400);

      expect(response.body).toHaveProperty('code', 'BAD_REQUEST');
    });

    it('should return 400 on name exceeding 255 characters', async () => {
      const response = await request(app)
        .post('/api/v1/admin/sessions')
        .set('Cookie', authCookie)
        .send({ name: 'x'.repeat(256) })
        .expect('Content-Type', /json/)
        .expect(400);

      expect(response.body).toHaveProperty('code', 'BAD_REQUEST');
    });

    it('should return 401 without authentication', async () => {
      await request(app)
        .post('/api/v1/admin/sessions')
        .send({ name: 'Test Session' })
        .expect(401);
    });
  });

  describe('GET /api/v1/admin/sessions', () => {
    beforeEach(async () => {
      // Create some test sessions
      for (let i = 1; i <= 3; i++) {
        const result = await query(
          `INSERT INTO sessions (name, admin_id) VALUES ($1, $2) RETURNING id`,
          [`Test Session ${i}`, testAdminId]
        );
        createdSessionIds.push(result.rows[0].id);
      }
    });

    it('should return list of sessions', async () => {
      const response = await request(app)
        .get('/api/v1/admin/sessions')
        .set('Cookie', authCookie)
        .expect('Content-Type', /json/)
        .expect(200);

      // Verify response structure per api.yaml#SessionList
      expect(response.body).toHaveProperty('sessions');
      expect(response.body).toHaveProperty('total');
      expect(response.body).toHaveProperty('limit');
      expect(response.body).toHaveProperty('offset');
      expect(Array.isArray(response.body.sessions)).toBe(true);
      expect(response.body.sessions.length).toBeGreaterThanOrEqual(3);
    });

    it('should support filtering by state', async () => {
      // Start one session to change its state
      await query(
        `UPDATE sessions SET state = 'ACTIVE', started_at = NOW() WHERE id = $1`,
        [createdSessionIds[0]]
      );

      const response = await request(app)
        .get('/api/v1/admin/sessions')
        .query({ state: 'CREATED' })
        .set('Cookie', authCookie)
        .expect(200);

      // All returned sessions should be CREATED
      for (const session of response.body.sessions) {
        if (createdSessionIds.includes(session.id)) {
          expect(session.state).toBe('CREATED');
        }
      }
    });

    it('should support pagination with limit and offset', async () => {
      const response = await request(app)
        .get('/api/v1/admin/sessions')
        .query({ limit: 2, offset: 0 })
        .set('Cookie', authCookie)
        .expect(200);

      expect(response.body.sessions.length).toBeLessThanOrEqual(2);
      expect(response.body.limit).toBe(2);
      expect(response.body.offset).toBe(0);
    });

    it('should return 401 without authentication', async () => {
      await request(app)
        .get('/api/v1/admin/sessions')
        .expect(401);
    });
  });

  describe('GET /api/v1/admin/sessions/{sessionId}', () => {
    let sessionId: string;

    beforeEach(async () => {
      const result = await query(
        `INSERT INTO sessions (name, admin_id) VALUES ($1, $2) RETURNING id`,
        ['Detail Test Session', testAdminId]
      );
      sessionId = result.rows[0].id;
      createdSessionIds.push(sessionId);
    });

    it('should return session details', async () => {
      const response = await request(app)
        .get(`/api/v1/admin/sessions/${sessionId}`)
        .set('Cookie', authCookie)
        .expect('Content-Type', /json/)
        .expect(200);

      // Verify response structure per api.yaml#SessionDetails
      expect(response.body).toHaveProperty('id', sessionId);
      expect(response.body).toHaveProperty('name', 'Detail Test Session');
      expect(response.body).toHaveProperty('state', 'CREATED');
      expect(response.body).toHaveProperty('kernelStatus', 'NOT_CREATED');
      expect(response.body).toHaveProperty('lifecycle');
      expect(Array.isArray(response.body.lifecycle)).toBe(true);
    });

    it('should return 404 for non-existent session', async () => {
      const fakeId = '00000000-0000-0000-0000-000000000000';
      const response = await request(app)
        .get(`/api/v1/admin/sessions/${fakeId}`)
        .set('Cookie', authCookie)
        .expect('Content-Type', /json/)
        .expect(404);

      expect(response.body).toHaveProperty('code', 'NOT_FOUND');
    });

    it('should return 401 without authentication', async () => {
      await request(app)
        .get(`/api/v1/admin/sessions/${sessionId}`)
        .expect(401);
    });
  });

  describe('POST /api/v1/admin/sessions/{sessionId}/start', () => {
    let sessionId: string;

    beforeEach(async () => {
      const result = await query(
        `INSERT INTO sessions (name, admin_id) VALUES ($1, $2) RETURNING id`,
        ['Start Test Session', testAdminId]
      );
      sessionId = result.rows[0].id;
      createdSessionIds.push(sessionId);
    });

    it('should start a session (CREATED -> ACTIVE)', async () => {
      const response = await request(app)
        .post(`/api/v1/admin/sessions/${sessionId}/start`)
        .set('Cookie', authCookie)
        .expect('Content-Type', /json/)
        .expect(200);

      // Verify state transition
      expect(response.body).toHaveProperty('id', sessionId);
      expect(response.body).toHaveProperty('state', 'ACTIVE');
      expect(response.body).toHaveProperty('startedAt');
      expect(response.body.startedAt).not.toBeNull();

      // Verify kernel was created
      expect(kernelManager.hasKernel(sessionId)).toBe(true);
    });

    it('should return 400 when starting already ACTIVE session', async () => {
      // First start
      await request(app)
        .post(`/api/v1/admin/sessions/${sessionId}/start`)
        .set('Cookie', authCookie)
        .expect(200);

      // Second start should fail
      const response = await request(app)
        .post(`/api/v1/admin/sessions/${sessionId}/start`)
        .set('Cookie', authCookie)
        .expect('Content-Type', /json/)
        .expect(400);

      expect(response.body).toHaveProperty('code', 'BAD_REQUEST');
      expect(response.body.message).toMatch(/invalid.*transition|state/i);
    });

    it('should return 400 when starting ENDED session', async () => {
      // Transition to ACTIVE then ENDED
      await query(
        `UPDATE sessions SET state = 'ACTIVE', started_at = NOW() WHERE id = $1`,
        [sessionId]
      );
      await query(
        `UPDATE sessions SET state = 'ENDED', ended_at = NOW() WHERE id = $1`,
        [sessionId]
      );

      const response = await request(app)
        .post(`/api/v1/admin/sessions/${sessionId}/start`)
        .set('Cookie', authCookie)
        .expect('Content-Type', /json/)
        .expect(400);

      expect(response.body).toHaveProperty('code', 'BAD_REQUEST');
    });

    it('should return 404 for non-existent session', async () => {
      const fakeId = '00000000-0000-0000-0000-000000000000';
      await request(app)
        .post(`/api/v1/admin/sessions/${fakeId}/start`)
        .set('Cookie', authCookie)
        .expect(404);
    });

    it('should return 401 without authentication', async () => {
      await request(app)
        .post(`/api/v1/admin/sessions/${sessionId}/start`)
        .expect(401);
    });
  });

  describe('POST /api/v1/admin/sessions/{sessionId}/end', () => {
    let sessionId: string;

    beforeEach(async () => {
      // Create and start a session
      const result = await query(
        `INSERT INTO sessions (name, admin_id, state, started_at)
         VALUES ($1, $2, 'ACTIVE', NOW()) RETURNING id`,
        ['End Test Session', testAdminId]
      );
      sessionId = result.rows[0].id;
      createdSessionIds.push(sessionId);

      // Create kernel
      kernelManager.createKernel(sessionId);
    });

    it('should end a session (ACTIVE -> ENDED)', async () => {
      // Add a conversation to verify dissolution
      kernelManager.getOrCreateConversation(sessionId, 'hash', 'presence');
      kernelManager.addMessage(sessionId, 'hash', 'user', 'Hello');

      const response = await request(app)
        .post(`/api/v1/admin/sessions/${sessionId}/end`)
        .set('Cookie', authCookie)
        .expect('Content-Type', /json/)
        .expect(200);

      // Verify state transition
      expect(response.body).toHaveProperty('id', sessionId);
      expect(response.body).toHaveProperty('state', 'ENDED');
      expect(response.body).toHaveProperty('endedAt');
      expect(response.body.endedAt).not.toBeNull();

      // Verify kernel was dissolved
      expect(kernelManager.hasKernel(sessionId)).toBe(false);
    });

    it('should return 400 when ending CREATED session', async () => {
      // Create a fresh CREATED session
      const result = await query(
        `INSERT INTO sessions (name, admin_id) VALUES ($1, $2) RETURNING id`,
        ['Created Session', testAdminId]
      );
      const createdSessionId = result.rows[0].id;
      createdSessionIds.push(createdSessionId);

      const response = await request(app)
        .post(`/api/v1/admin/sessions/${createdSessionId}/end`)
        .set('Cookie', authCookie)
        .expect('Content-Type', /json/)
        .expect(400);

      expect(response.body).toHaveProperty('code', 'BAD_REQUEST');
      expect(response.body.message).toMatch(/invalid.*transition|state/i);
    });

    it('should return 400 when ending already ENDED session', async () => {
      // End the session first
      await request(app)
        .post(`/api/v1/admin/sessions/${sessionId}/end`)
        .set('Cookie', authCookie)
        .expect(200);

      // Try to end again
      const response = await request(app)
        .post(`/api/v1/admin/sessions/${sessionId}/end`)
        .set('Cookie', authCookie)
        .expect('Content-Type', /json/)
        .expect(400);

      expect(response.body).toHaveProperty('code', 'BAD_REQUEST');
    });

    it('should return 404 for non-existent session', async () => {
      const fakeId = '00000000-0000-0000-0000-000000000000';
      await request(app)
        .post(`/api/v1/admin/sessions/${fakeId}/end`)
        .set('Cookie', authCookie)
        .expect(404);
    });

    it('should return 401 without authentication', async () => {
      await request(app)
        .post(`/api/v1/admin/sessions/${sessionId}/end`)
        .expect(401);
    });
  });
});
