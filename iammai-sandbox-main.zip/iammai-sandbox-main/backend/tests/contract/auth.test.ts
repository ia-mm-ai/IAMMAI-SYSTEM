/**
 * Contract tests for auth endpoints
 * @see specs/001-ephemeral-kernel/tasks.md#T033
 * @see specs/001-ephemeral-kernel/contracts/api.yaml lines 32-56
 */

import { describe, it, expect, beforeAll, afterAll, beforeEach } from 'vitest';
import request from 'supertest';
import type { Express } from 'express';
import { createApp } from '../../src/api/app.js';
import { closePool, query } from '../../src/lib/db.js';
import bcrypt from 'bcrypt';

describe('POST /api/v1/auth/login', () => {
  let app: Express;
  const testEmail = 'test-auth@example.com';
  const testPassword = 'testPassword123!';
  let testAdminId: string;

  beforeAll(async () => {
    app = createApp();

    // Create test admin
    const passwordHash = await bcrypt.hash(testPassword, 10);
    const result = await query(
      `INSERT INTO admins (email, password_hash)
       VALUES ($1, $2)
       ON CONFLICT (email) DO UPDATE SET password_hash = $2
       RETURNING id`,
      [testEmail, passwordHash]
    );
    testAdminId = result.rows[0].id;
  });

  afterAll(async () => {
    // Clean up test admin
    await query('DELETE FROM admins WHERE id = $1', [testAdminId]);
    // Pool cleanup handled by vitest globalTeardown
  });

  it('should return 200 and admin profile on valid credentials', async () => {
    const response = await request(app)
      .post('/api/v1/auth/login')
      .send({
        email: testEmail,
        password: testPassword,
      })
      .expect('Content-Type', /json/)
      .expect(200);

    // Verify response structure per api.yaml#AdminProfile
    expect(response.body).toHaveProperty('id');
    expect(response.body).toHaveProperty('email', testEmail);
    expect(response.body).toHaveProperty('lastLoginAt');

    // Should not return password hash
    expect(response.body).not.toHaveProperty('passwordHash');
    expect(response.body).not.toHaveProperty('password_hash');

    // Should set HTTP-only auth cookie
    const cookies = response.headers['set-cookie'];
    expect(cookies).toBeDefined();
    expect(Array.isArray(cookies) ? cookies[0] : cookies).toMatch(/auth_token=/);
    expect(Array.isArray(cookies) ? cookies[0] : cookies).toMatch(/HttpOnly/i);
  });

  it('should return 401 on invalid password', async () => {
    const response = await request(app)
      .post('/api/v1/auth/login')
      .send({
        email: testEmail,
        password: 'wrongPassword123!',
      })
      .expect('Content-Type', /json/)
      .expect(401);

    // Verify error structure per api.yaml#Error
    expect(response.body).toHaveProperty('code');
    expect(response.body).toHaveProperty('message');
    expect(response.body.code).toBe('UNAUTHORIZED');
  });

  it('should return 401 on non-existent email', async () => {
    const response = await request(app)
      .post('/api/v1/auth/login')
      .send({
        email: 'nonexistent@example.com',
        password: 'anyPassword123!',
      })
      .expect('Content-Type', /json/)
      .expect(401);

    expect(response.body).toHaveProperty('code', 'UNAUTHORIZED');
  });

  it('should return 400 on missing email', async () => {
    const response = await request(app)
      .post('/api/v1/auth/login')
      .send({
        password: testPassword,
      })
      .expect('Content-Type', /json/)
      .expect(400);

    expect(response.body).toHaveProperty('code', 'BAD_REQUEST');
  });

  it('should return 400 on missing password', async () => {
    const response = await request(app)
      .post('/api/v1/auth/login')
      .send({
        email: testEmail,
      })
      .expect('Content-Type', /json/)
      .expect(400);

    expect(response.body).toHaveProperty('code', 'BAD_REQUEST');
  });

  it('should return 400 on invalid email format', async () => {
    const response = await request(app)
      .post('/api/v1/auth/login')
      .send({
        email: 'not-an-email',
        password: testPassword,
      })
      .expect('Content-Type', /json/)
      .expect(400);

    expect(response.body).toHaveProperty('code', 'BAD_REQUEST');
  });

  it('should return 400 on password shorter than 8 characters', async () => {
    const response = await request(app)
      .post('/api/v1/auth/login')
      .send({
        email: testEmail,
        password: 'short',
      })
      .expect('Content-Type', /json/)
      .expect(400);

    expect(response.body).toHaveProperty('code', 'BAD_REQUEST');
  });
});

describe('POST /api/v1/auth/logout', () => {
  let app: Express;
  let authCookie: string;
  const testEmail = 'test-logout@example.com';
  const testPassword = 'testPassword123!';
  let testAdminId: string;

  beforeAll(async () => {
    app = createApp();

    // Create test admin and login
    const passwordHash = await bcrypt.hash(testPassword, 10);
    const result = await query(
      `INSERT INTO admins (email, password_hash)
       VALUES ($1, $2)
       ON CONFLICT (email) DO UPDATE SET password_hash = $2
       RETURNING id`,
      [testEmail, passwordHash]
    );
    testAdminId = result.rows[0].id;
  });

  beforeEach(async () => {
    // Login to get auth cookie
    const loginResponse = await request(app)
      .post('/api/v1/auth/login')
      .send({ email: testEmail, password: testPassword });

    const cookies = loginResponse.headers['set-cookie'];
    authCookie = Array.isArray(cookies) ? cookies[0] : cookies;
  });

  afterAll(async () => {
    await query('DELETE FROM admins WHERE id = $1', [testAdminId]);
    // Pool cleanup handled by vitest globalTeardown
  });

  it('should return 204 on successful logout', async () => {
    await request(app)
      .post('/api/v1/auth/logout')
      .set('Cookie', authCookie)
      .expect(204);
  });

  it('should clear the auth cookie', async () => {
    const response = await request(app)
      .post('/api/v1/auth/logout')
      .set('Cookie', authCookie)
      .expect(204);

    const cookies = response.headers['set-cookie'];
    if (cookies) {
      const cookieStr = Array.isArray(cookies) ? cookies[0] : cookies;
      // Cookie should be cleared (empty or expired)
      expect(cookieStr).toMatch(/auth_token=/);
    }
  });

  it('should return 401 without auth cookie', async () => {
    await request(app)
      .post('/api/v1/auth/logout')
      .expect(401);
  });
});

describe('GET /api/v1/auth/me', () => {
  let app: Express;
  let authCookie: string;
  const testEmail = 'test-me@example.com';
  const testPassword = 'testPassword123!';
  let testAdminId: string;

  beforeAll(async () => {
    app = createApp();

    // Create test admin
    const passwordHash = await bcrypt.hash(testPassword, 10);
    const result = await query(
      `INSERT INTO admins (email, password_hash)
       VALUES ($1, $2)
       ON CONFLICT (email) DO UPDATE SET password_hash = $2
       RETURNING id`,
      [testEmail, passwordHash]
    );
    testAdminId = result.rows[0].id;

    // Login to get auth cookie
    const loginResponse = await request(app)
      .post('/api/v1/auth/login')
      .send({ email: testEmail, password: testPassword });

    const cookies = loginResponse.headers['set-cookie'];
    authCookie = Array.isArray(cookies) ? cookies[0] : cookies;
  });

  afterAll(async () => {
    await query('DELETE FROM admins WHERE id = $1', [testAdminId]);
    // Pool cleanup handled by vitest globalTeardown
  });

  it('should return 200 and admin profile when authenticated', async () => {
    const response = await request(app)
      .get('/api/v1/auth/me')
      .set('Cookie', authCookie)
      .expect('Content-Type', /json/)
      .expect(200);

    expect(response.body).toHaveProperty('id', testAdminId);
    expect(response.body).toHaveProperty('email', testEmail);
    expect(response.body).not.toHaveProperty('passwordHash');
  });

  it('should return 401 without auth cookie', async () => {
    await request(app)
      .get('/api/v1/auth/me')
      .expect(401);
  });

  it('should return 401 with invalid auth cookie', async () => {
    await request(app)
      .get('/api/v1/auth/me')
      .set('Cookie', 'auth_token=invalid-token')
      .expect(401);
  });
});
