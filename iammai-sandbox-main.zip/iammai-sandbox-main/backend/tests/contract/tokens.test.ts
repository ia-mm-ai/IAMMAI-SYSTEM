/**
 * Contract tests for token endpoints (claim and join)
 * @see specs/001-ephemeral-kernel/tasks.md#T052-T053
 * @see specs/001-ephemeral-kernel/contracts/api.yaml lines 279-336
 */

import { describe, it, expect, beforeAll, afterAll, afterEach } from 'vitest';
import request from 'supertest';
import type { Express } from 'express';
import { createApp } from '../../src/api/app.js';
import { query } from '../../src/lib/db.js';
import { kernelManager } from '../../src/kernel/manager.js';
import bcrypt from 'bcrypt';

describe('POST /api/v1/sessions/{sessionId}/claim (Token Claim)', () => {
  let app: Express;
  const testEmail = 'test-claim@example.com';
  const testPassword = 'testPassword123!';
  let testAdminId: string;
  const createdSessionIds: string[] = [];

  beforeAll(async () => {
    app = createApp();

    const passwordHash = await bcrypt.hash(testPassword, 10);
    const result = await query(
      `INSERT INTO admins (email, password_hash)
       VALUES ($1, $2)
       ON CONFLICT (email) DO UPDATE SET password_hash = $2
       RETURNING id`,
      [testEmail, passwordHash]
    );
    testAdminId = result.rows[0].id;
  });

  afterEach(async () => {
    for (const sessionId of createdSessionIds) {
      // Clean up tokens first (foreign key constraint)
      await query('DELETE FROM tokens WHERE session_id = $1', [sessionId]);
      await query('DELETE FROM sessions WHERE id = $1', [sessionId]);
    }
    createdSessionIds.length = 0;
  });

  afterAll(async () => {
    await query('DELETE FROM admins WHERE id = $1', [testAdminId]);
  });

  it('should claim a token for CREATED session', async () => {
    const result = await query(
      `INSERT INTO sessions (name, admin_id, state)
       VALUES ($1, $2, 'CREATED') RETURNING id`,
      ['Claim Test Session', testAdminId]
    );
    const sessionId = result.rows[0].id;
    createdSessionIds.push(sessionId);

    const response = await request(app)
      .post(`/api/v1/sessions/${sessionId}/claim`)
      .expect('Content-Type', /json/)
      .expect(201);

    // Verify response structure per api.yaml#TokenClaim
    expect(response.body).toHaveProperty('token');
    expect(response.body).toHaveProperty('sessionId', sessionId);
    expect(response.body).toHaveProperty('claimedAt');

    // Token should be a base64url string of sufficient length (256-bit = ~43 chars)
    expect(typeof response.body.token).toBe('string');
    expect(response.body.token.length).toBeGreaterThanOrEqual(40);
    expect(response.body.token).toMatch(/^[A-Za-z0-9_-]+$/);

    // Verify token was recorded in database
    const tokenResult = await query(
      'SELECT COUNT(*) as count FROM tokens WHERE session_id = $1',
      [sessionId]
    );
    expect(parseInt(tokenResult.rows[0].count, 10)).toBe(1);

    // Verify session token_count was incremented
    const sessionResult = await query(
      'SELECT token_count FROM sessions WHERE id = $1',
      [sessionId]
    );
    expect(sessionResult.rows[0].token_count).toBe(1);
  });

  it('should allow multiple token claims for same session', async () => {
    const result = await query(
      `INSERT INTO sessions (name, admin_id, state)
       VALUES ($1, $2, 'CREATED') RETURNING id`,
      ['Multi-Claim Session', testAdminId]
    );
    const sessionId = result.rows[0].id;
    createdSessionIds.push(sessionId);

    // Claim multiple tokens
    const response1 = await request(app)
      .post(`/api/v1/sessions/${sessionId}/claim`)
      .expect(201);

    const response2 = await request(app)
      .post(`/api/v1/sessions/${sessionId}/claim`)
      .expect(201);

    // Tokens should be different
    expect(response1.body.token).not.toBe(response2.body.token);

    // Session should have 2 tokens
    const sessionResult = await query(
      'SELECT token_count FROM sessions WHERE id = $1',
      [sessionId]
    );
    expect(sessionResult.rows[0].token_count).toBe(2);
  });

  it('should return 400 when claiming token for ACTIVE session', async () => {
    const result = await query(
      `INSERT INTO sessions (name, admin_id, state, started_at)
       VALUES ($1, $2, 'ACTIVE', NOW()) RETURNING id`,
      ['Active Session', testAdminId]
    );
    const sessionId = result.rows[0].id;
    createdSessionIds.push(sessionId);

    const response = await request(app)
      .post(`/api/v1/sessions/${sessionId}/claim`)
      .expect('Content-Type', /json/)
      .expect(400);

    expect(response.body).toHaveProperty('code', 'BAD_REQUEST');
    expect(response.body.message).toMatch(/CREATED|not available|cannot claim/i);
  });

  it('should return 400 when claiming token for ENDED session', async () => {
    const result = await query(
      `INSERT INTO sessions (name, admin_id, state, started_at, ended_at)
       VALUES ($1, $2, 'ENDED', NOW(), NOW()) RETURNING id`,
      ['Ended Session', testAdminId]
    );
    const sessionId = result.rows[0].id;
    createdSessionIds.push(sessionId);

    const response = await request(app)
      .post(`/api/v1/sessions/${sessionId}/claim`)
      .expect(400);

    expect(response.body).toHaveProperty('code', 'BAD_REQUEST');
  });

  it('should return 404 for non-existent session', async () => {
    const fakeId = '00000000-0000-0000-0000-000000000000';

    const response = await request(app)
      .post(`/api/v1/sessions/${fakeId}/claim`)
      .expect(404);

    expect(response.body).toHaveProperty('code', 'NOT_FOUND');
  });
});

describe('POST /api/v1/sessions/{sessionId}/join (Session Join)', () => {
  let app: Express;
  const testEmail = 'test-join@example.com';
  const testPassword = 'testPassword123!';
  let testAdminId: string;
  const createdSessionIds: string[] = [];

  beforeAll(async () => {
    app = createApp();

    const passwordHash = await bcrypt.hash(testPassword, 10);
    const result = await query(
      `INSERT INTO admins (email, password_hash)
       VALUES ($1, $2)
       ON CONFLICT (email) DO UPDATE SET password_hash = $2
       RETURNING id`,
      [testEmail, passwordHash]
    );
    testAdminId = result.rows[0].id;
  });

  afterEach(async () => {
    for (const sessionId of createdSessionIds) {
      kernelManager.dissolveKernel(sessionId);
      await query('DELETE FROM tokens WHERE session_id = $1', [sessionId]);
      await query('DELETE FROM sessions WHERE id = $1', [sessionId]);
    }
    createdSessionIds.length = 0;
  });

  afterAll(async () => {
    await query('DELETE FROM admins WHERE id = $1', [testAdminId]);
  });

  it('should join an ACTIVE session with valid token', async () => {
    // Create CREATED session and claim token
    const sessionResult = await query(
      `INSERT INTO sessions (name, admin_id, state)
       VALUES ($1, $2, 'CREATED') RETURNING id`,
      ['Join Test Session', testAdminId]
    );
    const sessionId = sessionResult.rows[0].id;
    createdSessionIds.push(sessionId);

    // Claim token
    const claimResponse = await request(app)
      .post(`/api/v1/sessions/${sessionId}/claim`)
      .expect(201);
    const token = claimResponse.body.token;

    // Start session (transition to ACTIVE)
    await query(
      `UPDATE sessions SET state = 'ACTIVE', started_at = NOW() WHERE id = $1`,
      [sessionId]
    );
    kernelManager.createKernel(sessionId);

    // Join with token
    const response = await request(app)
      .post(`/api/v1/sessions/${sessionId}/join`)
      .send({ token })
      .expect('Content-Type', /json/)
      .expect(200);

    // Verify response structure per api.yaml#JoinResponse
    expect(response.body).toHaveProperty('presenceHash');
    expect(response.body).toHaveProperty('kernelStatus', 'ACTIVE');
    expect(response.body).toHaveProperty('websocketUrl');

    // Presence hash should be 8 hex characters
    expect(response.body.presenceHash).toMatch(/^[0-9a-f]{8}$/);

    // WebSocket URL should be valid format
    expect(response.body.websocketUrl).toMatch(/^wss?:\/\//);

    // Token should be marked as joined
    const tokenResult = await query(
      'SELECT joined_at FROM tokens WHERE session_id = $1',
      [sessionId]
    );
    expect(tokenResult.rows[0].joined_at).not.toBeNull();

    // Session user_count should be incremented
    const updatedSession = await query(
      'SELECT user_count FROM sessions WHERE id = $1',
      [sessionId]
    );
    expect(updatedSession.rows[0].user_count).toBe(1);
  });

  it('should allow rejoining with same token (idempotent)', async () => {
    // Setup: Create, claim, start session
    const sessionResult = await query(
      `INSERT INTO sessions (name, admin_id, state)
       VALUES ($1, $2, 'CREATED') RETURNING id`,
      ['Rejoin Test Session', testAdminId]
    );
    const sessionId = sessionResult.rows[0].id;
    createdSessionIds.push(sessionId);

    const claimResponse = await request(app)
      .post(`/api/v1/sessions/${sessionId}/claim`)
      .expect(201);
    const token = claimResponse.body.token;

    await query(
      `UPDATE sessions SET state = 'ACTIVE', started_at = NOW() WHERE id = $1`,
      [sessionId]
    );
    kernelManager.createKernel(sessionId);

    // First join
    const response1 = await request(app)
      .post(`/api/v1/sessions/${sessionId}/join`)
      .send({ token })
      .expect(200);

    // Second join with same token
    const response2 = await request(app)
      .post(`/api/v1/sessions/${sessionId}/join`)
      .send({ token })
      .expect(200);

    // Both should return same presence hash
    expect(response1.body.presenceHash).toBe(response2.body.presenceHash);

    // User count should still be 1 (not incremented on rejoin)
    const sessionCheck = await query(
      'SELECT user_count FROM sessions WHERE id = $1',
      [sessionId]
    );
    expect(sessionCheck.rows[0].user_count).toBe(1);
  });

  it('should return 400 when joining with invalid token', async () => {
    // Create and start a session
    const sessionResult = await query(
      `INSERT INTO sessions (name, admin_id, state, started_at)
       VALUES ($1, $2, 'ACTIVE', NOW()) RETURNING id`,
      ['Invalid Token Session', testAdminId]
    );
    const sessionId = sessionResult.rows[0].id;
    createdSessionIds.push(sessionId);
    kernelManager.createKernel(sessionId);

    const response = await request(app)
      .post(`/api/v1/sessions/${sessionId}/join`)
      .send({ token: 'invalid-token-that-does-not-exist' })
      .expect('Content-Type', /json/)
      .expect(400);

    expect(response.body).toHaveProperty('code', 'BAD_REQUEST');
    expect(response.body.message).toMatch(/invalid|token|not found/i);
  });

  it('should return 400 when joining with token from different session', async () => {
    // Create two sessions
    const session1Result = await query(
      `INSERT INTO sessions (name, admin_id, state)
       VALUES ($1, $2, 'CREATED') RETURNING id`,
      ['Session One', testAdminId]
    );
    const sessionId1 = session1Result.rows[0].id;
    createdSessionIds.push(sessionId1);

    const session2Result = await query(
      `INSERT INTO sessions (name, admin_id, state, started_at)
       VALUES ($1, $2, 'ACTIVE', NOW()) RETURNING id`,
      ['Session Two', testAdminId]
    );
    const sessionId2 = session2Result.rows[0].id;
    createdSessionIds.push(sessionId2);
    kernelManager.createKernel(sessionId2);

    // Claim token from session 1
    const claimResponse = await request(app)
      .post(`/api/v1/sessions/${sessionId1}/claim`)
      .expect(201);
    const token = claimResponse.body.token;

    // Try to join session 2 with session 1's token
    const response = await request(app)
      .post(`/api/v1/sessions/${sessionId2}/join`)
      .send({ token })
      .expect(400);

    expect(response.body).toHaveProperty('code', 'BAD_REQUEST');
  });

  it('should return 400 when joining CREATED session', async () => {
    const sessionResult = await query(
      `INSERT INTO sessions (name, admin_id, state)
       VALUES ($1, $2, 'CREATED') RETURNING id`,
      ['Not Started Session', testAdminId]
    );
    const sessionId = sessionResult.rows[0].id;
    createdSessionIds.push(sessionId);

    // Claim a token
    const claimResponse = await request(app)
      .post(`/api/v1/sessions/${sessionId}/claim`)
      .expect(201);
    const token = claimResponse.body.token;

    // Try to join before session is started
    const response = await request(app)
      .post(`/api/v1/sessions/${sessionId}/join`)
      .send({ token })
      .expect(400);

    expect(response.body).toHaveProperty('code', 'BAD_REQUEST');
    expect(response.body.message).toMatch(/not active|not started|ACTIVE/i);
  });

  it('should return 400 when joining ENDED session', async () => {
    const sessionResult = await query(
      `INSERT INTO sessions (name, admin_id, state, started_at, ended_at)
       VALUES ($1, $2, 'ENDED', NOW(), NOW()) RETURNING id`,
      ['Ended Join Session', testAdminId]
    );
    const sessionId = sessionResult.rows[0].id;
    createdSessionIds.push(sessionId);

    const response = await request(app)
      .post(`/api/v1/sessions/${sessionId}/join`)
      .send({ token: 'any-token' })
      .expect(400);

    expect(response.body).toHaveProperty('code', 'BAD_REQUEST');
  });

  it('should return 400 when token is missing from request', async () => {
    const sessionResult = await query(
      `INSERT INTO sessions (name, admin_id, state, started_at)
       VALUES ($1, $2, 'ACTIVE', NOW()) RETURNING id`,
      ['Missing Token Session', testAdminId]
    );
    const sessionId = sessionResult.rows[0].id;
    createdSessionIds.push(sessionId);
    kernelManager.createKernel(sessionId);

    const response = await request(app)
      .post(`/api/v1/sessions/${sessionId}/join`)
      .send({})
      .expect(400);

    expect(response.body).toHaveProperty('code', 'BAD_REQUEST');
  });

  it('should return 404 for non-existent session', async () => {
    const fakeId = '00000000-0000-0000-0000-000000000000';

    const response = await request(app)
      .post(`/api/v1/sessions/${fakeId}/join`)
      .send({ token: 'any-token' })
      .expect(404);

    expect(response.body).toHaveProperty('code', 'NOT_FOUND');
  });
});
