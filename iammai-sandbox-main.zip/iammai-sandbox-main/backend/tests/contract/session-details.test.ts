/**
 * Contract tests for GET /admin/sessions/{id} endpoint (SessionDetails)
 * @see specs/001-ephemeral-kernel/tasks.md#T097
 * @see specs/001-ephemeral-kernel/contracts/api.yaml lines 148-167
 */

import { describe, it, expect, beforeAll, afterAll, afterEach } from 'vitest';
import request from 'supertest';
import type { Express } from 'express';
import { createApp } from '../../src/api/app.js';
import { closePool, query } from '../../src/lib/db.js';
import { kernelManager } from '../../src/kernel/manager.js';
import bcrypt from 'bcrypt';

describe('GET /admin/sessions/{id} - SessionDetails', () => {
  let app: Express;
  let authCookie: string;
  const testEmail = 'test-session-details@example.com';
  const testPassword = 'testPassword123!';
  let testAdminId: string;
  const createdSessionIds: string[] = [];

  beforeAll(async () => {
    app = createApp();

    // Create test admin and login
    const passwordHash = await bcrypt.hash(testPassword, 10);
    const result = await query(
      `INSERT INTO admins (email, password_hash)
       VALUES ($1, $2)
       ON CONFLICT (email) DO UPDATE SET password_hash = $2
       RETURNING id`,
      [testEmail, passwordHash]
    );
    testAdminId = result.rows[0].id;

    // Login to get auth cookie
    const loginResponse = await request(app)
      .post('/api/v1/auth/login')
      .send({ email: testEmail, password: testPassword });

    const cookies = loginResponse.headers['set-cookie'];
    authCookie = Array.isArray(cookies) ? cookies[0] : cookies;
  });

  afterEach(async () => {
    // Clean up created sessions
    for (const sessionId of createdSessionIds) {
      // Dissolve any kernels
      kernelManager.dissolveKernel(sessionId);
      // Delete from database
      await query('DELETE FROM sessions WHERE id = $1', [sessionId]);
    }
    createdSessionIds.length = 0;
  });

  afterAll(async () => {
    await query('DELETE FROM admins WHERE id = $1', [testAdminId]);
    await closePool();
  });

  it('should return SessionDetails with kernelStatus and lifecycle for CREATED session', async () => {
    // Create a session
    const createResponse = await request(app)
      .post('/api/v1/admin/sessions')
      .set('Cookie', authCookie)
      .send({ name: 'Test Session for Details' })
      .expect(201);

    const sessionId = createResponse.body.id;
    createdSessionIds.push(sessionId);

    // Get session details
    const response = await request(app)
      .get(`/api/v1/admin/sessions/${sessionId}`)
      .set('Cookie', authCookie)
      .expect('Content-Type', /json/)
      .expect(200);

    // Verify SessionDetails structure (extends Session)
    expect(response.body).toHaveProperty('id', sessionId);
    expect(response.body).toHaveProperty('name', 'Test Session for Details');
    expect(response.body).toHaveProperty('state', 'CREATED');
    expect(response.body).toHaveProperty('createdAt');
    expect(response.body).toHaveProperty('startedAt', null);
    expect(response.body).toHaveProperty('endedAt', null);
    expect(response.body).toHaveProperty('tokenCount', 0);
    expect(response.body).toHaveProperty('userCount', 0);

    // Verify SessionDetails extensions
    expect(response.body).toHaveProperty('kernelStatus');
    expect(response.body.kernelStatus).toBe('NOT_CREATED');

    expect(response.body).toHaveProperty('lifecycle');
    expect(Array.isArray(response.body.lifecycle)).toBe(true);
    expect(response.body.lifecycle).toHaveLength(1);

    // Verify first lifecycle event
    const createdEvent = response.body.lifecycle[0];
    expect(createdEvent).toHaveProperty('event', 'CREATED');
    expect(createdEvent).toHaveProperty('timestamp');
    expect(new Date(createdEvent.timestamp).getTime()).toBeGreaterThan(0);
  });

  it('should return kernelStatus ACTIVE and lifecycle with STARTED event for active session', async () => {
    // Create and start a session
    const createResponse = await request(app)
      .post('/api/v1/admin/sessions')
      .set('Cookie', authCookie)
      .send({ name: 'Active Session for Details' })
      .expect(201);

    const sessionId = createResponse.body.id;
    createdSessionIds.push(sessionId);

    await request(app)
      .post(`/api/v1/admin/sessions/${sessionId}/start`)
      .set('Cookie', authCookie)
      .expect(200);

    // Get session details
    const response = await request(app)
      .get(`/api/v1/admin/sessions/${sessionId}`)
      .set('Cookie', authCookie)
      .expect('Content-Type', /json/)
      .expect(200);

    // Verify state and kernel status
    expect(response.body.state).toBe('ACTIVE');
    expect(response.body.kernelStatus).toBe('ACTIVE');
    expect(response.body.startedAt).not.toBe(null);

    // Verify lifecycle has two events
    expect(response.body.lifecycle).toHaveLength(2);

    const createdEvent = response.body.lifecycle[0];
    expect(createdEvent.event).toBe('CREATED');

    const startedEvent = response.body.lifecycle[1];
    expect(startedEvent.event).toBe('STARTED');
    expect(startedEvent.timestamp).toBe(response.body.startedAt);
  });

  it('should return kernelStatus DISSOLVED and lifecycle with ENDED event for ended session', async () => {
    // Create, start, and end a session
    const createResponse = await request(app)
      .post('/api/v1/admin/sessions')
      .set('Cookie', authCookie)
      .send({ name: 'Ended Session for Details' })
      .expect(201);

    const sessionId = createResponse.body.id;
    createdSessionIds.push(sessionId);

    await request(app)
      .post(`/api/v1/admin/sessions/${sessionId}/start`)
      .set('Cookie', authCookie)
      .expect(200);

    await request(app)
      .post(`/api/v1/admin/sessions/${sessionId}/end`)
      .set('Cookie', authCookie)
      .expect(200);

    // Get session details
    const response = await request(app)
      .get(`/api/v1/admin/sessions/${sessionId}`)
      .set('Cookie', authCookie)
      .expect('Content-Type', /json/)
      .expect(200);

    // Verify state and kernel status
    expect(response.body.state).toBe('ENDED');
    expect(response.body.kernelStatus).toBe('DISSOLVED');
    expect(response.body.endedAt).not.toBe(null);

    // Verify lifecycle has three events
    expect(response.body.lifecycle).toHaveLength(3);

    const createdEvent = response.body.lifecycle[0];
    expect(createdEvent.event).toBe('CREATED');

    const startedEvent = response.body.lifecycle[1];
    expect(startedEvent.event).toBe('STARTED');

    const endedEvent = response.body.lifecycle[2];
    expect(endedEvent.event).toBe('ENDED');
    expect(endedEvent.timestamp).toBe(response.body.endedAt);
  });

  it('should return 401 Unauthorized without authentication', async () => {
    // Create a session first
    const createResponse = await request(app)
      .post('/api/v1/admin/sessions')
      .set('Cookie', authCookie)
      .send({ name: 'Test Session' })
      .expect(201);

    const sessionId = createResponse.body.id;
    createdSessionIds.push(sessionId);

    // Try to get details without auth
    await request(app)
      .get(`/api/v1/admin/sessions/${sessionId}`)
      .expect(401);
  });

  it('should return 404 Not Found for non-existent session', async () => {
    const fakeSessionId = '00000000-0000-0000-0000-000000000000';

    await request(app)
      .get(`/api/v1/admin/sessions/${fakeSessionId}`)
      .set('Cookie', authCookie)
      .expect('Content-Type', /json/)
      .expect(404);
  });

  it('should return error for invalid UUID format', async () => {
    // Database will reject invalid UUID format with 500
    // In a production system, we'd add UUID validation middleware
    await request(app)
      .get('/api/v1/admin/sessions/invalid-uuid')
      .set('Cookie', authCookie)
      .expect(500);
  });
});
