/**
 * Integration Test: Orphaned Conversation
 *
 * Tests FR-022, FR-023: New token creates new conversation, old conversation orphaned
 *
 * Given a user has an active conversation with token A
 * When they claim a new token B for the same session
 * Then the old conversation (token A) is orphaned
 * And the new token B creates a fresh conversation
 */

import { describe, it, expect, beforeAll, afterAll, beforeEach } from 'vitest';
import WebSocket from 'ws';
import { Session } from '../../src/models/session';
import { Token as TokenModel } from '../../src/models/token';
import { kernelManager } from '../../src/kernel/manager';
import { generateToken, hashToken } from '../../src/services/token';
import { pool } from '../../src/lib/db';

describe('Integration: Orphaned Conversation', () => {
  let sessionId: string;
  let wsUrl: string;

  beforeAll(async () => {
    wsUrl = process.env.WS_TEST_URL || 'ws://localhost:3001';
  });

  afterAll(async () => {
    await pool.end();
  });

  beforeEach(async () => {
    // Clean up database
    await pool.query('DELETE FROM tokens');
    await pool.query('DELETE FROM sessions');

    // Create an ACTIVE session
    const session = await Session.create('Orphaned Test Session');
    sessionId = session.id;
    await Session.transitionState(sessionId, 'ACTIVE');

    // Create kernel
    kernelManager.createKernel(sessionId);
  });

  it('should create new conversation for new token, leaving old one orphaned', async () => {
    return new Promise<void>(async (resolve, reject) => {
      try {
        // Token A: Create conversation with history
        const tokenA = generateToken();
        const tokenHashA = hashToken(tokenA);
        await TokenModel.create(sessionId, tokenHashA);
        await TokenModel.markJoined(tokenHashA);

        const wsA = new WebSocket(wsUrl, {
          headers: { 'Authorization': `Bearer ${tokenA}` }
        });

        await new Promise<void>((connectResolve) => {
          wsA.on('open', () => connectResolve());
        });

        await new Promise<void>((ackResolve) => {
          wsA.on('message', (data: Buffer) => {
            const msg = JSON.parse(data.toString());
            if (msg.type === 'CONNECTION_ACK') ackResolve();
          });
        });

        // Send message with token A
        wsA.send(JSON.stringify({
          type: 'USER_MESSAGE',
          payload: { content: 'Message from token A' }
        }));

        await new Promise<void>((responseResolve) => {
          wsA.on('message', (data: Buffer) => {
            const msg = JSON.parse(data.toString());
            if (msg.type === 'MESSAGE_COMPLETE') responseResolve();
          });
        });

        // Get kernel conversation count before claiming token B
        const kernel = kernelManager.getKernel(sessionId);
        expect(kernel).toBeDefined();
        const conversationsCountBefore = kernel!.conversations.size;
        expect(conversationsCountBefore).toBe(1);

        // Token B: Claim new token
        const tokenB = generateToken();
        const tokenHashB = hashToken(tokenB);
        await TokenModel.create(sessionId, tokenHashB);
        await TokenModel.markJoined(tokenHashB);

        const wsB = new WebSocket(wsUrl, {
          headers: { 'Authorization': `Bearer ${tokenB}` }
        });

        await new Promise<void>((connectResolve) => {
          wsB.on('open', () => connectResolve());
        });

        wsB.on('message', (data: Buffer) => {
          const msg = JSON.parse(data.toString());

          if (msg.type === 'CONNECTION_ACK') {
            // Token B should have NO conversation history (fresh start)
            expect(msg.payload.conversationHistory).toBeDefined();
            expect(msg.payload.conversationHistory.length).toBe(0);

            // Verify kernel now has 2 conversations
            const conversationsCountAfter = kernel!.conversations.size;
            expect(conversationsCountAfter).toBe(2);

            // Verify old conversation still exists (orphaned)
            const conversationA = kernel!.conversations.get(tokenHashA);
            expect(conversationA).toBeDefined();
            expect(conversationA!.messages.length).toBeGreaterThanOrEqual(2);

            // Verify new conversation is empty
            const conversationB = kernel!.conversations.get(tokenHashB);
            expect(conversationB).toBeDefined();
            expect(conversationB!.messages.length).toBe(0);

            wsA.close();
            wsB.close();
            resolve();
          }
        });

        wsB.on('error', reject);

      } catch (error) {
        reject(error);
      }
    });
  });

  it('should not allow token A to access token B conversation', async () => {
    return new Promise<void>(async (resolve, reject) => {
      try {
        // Create two tokens
        const tokenA = generateToken();
        const tokenHashA = hashToken(tokenA);
        await TokenModel.create(sessionId, tokenHashA);
        await TokenModel.markJoined(tokenHashA);

        const tokenB = generateToken();
        const tokenHashB = hashToken(tokenB);
        await TokenModel.create(sessionId, tokenHashB);
        await TokenModel.markJoined(tokenHashB);

        // Token B sends a message
        const wsB = new WebSocket(wsUrl, {
          headers: { 'Authorization': `Bearer ${tokenB}` }
        });

        await new Promise<void>((connectResolve) => {
          wsB.on('open', () => connectResolve());
        });

        await new Promise<void>((ackResolve) => {
          wsB.on('message', (data: Buffer) => {
            const msg = JSON.parse(data.toString());
            if (msg.type === 'CONNECTION_ACK') ackResolve();
          });
        });

        wsB.send(JSON.stringify({
          type: 'USER_MESSAGE',
          payload: { content: 'Secret message from token B' }
        }));

        await new Promise<void>((responseResolve) => {
          wsB.on('message', (data: Buffer) => {
            const msg = JSON.parse(data.toString());
            if (msg.type === 'MESSAGE_COMPLETE') responseResolve();
          });
        });

        wsB.close();

        // Token A connects and checks history
        const wsA = new WebSocket(wsUrl, {
          headers: { 'Authorization': `Bearer ${tokenA}` }
        });

        await new Promise<void>((connectResolve) => {
          wsA.on('open', () => connectResolve());
        });

        wsA.on('message', (data: Buffer) => {
          const msg = JSON.parse(data.toString());

          if (msg.type === 'CONNECTION_ACK') {
            // Token A should have empty history (no access to B's conversation)
            expect(msg.payload.conversationHistory).toBeDefined();
            expect(msg.payload.conversationHistory.length).toBe(0);

            // Verify conversation isolation at kernel level
            const kernel = kernelManager.getKernel(sessionId);
            const conversationA = kernel!.conversations.get(tokenHashA);
            const conversationB = kernel!.conversations.get(tokenHashB);

            expect(conversationA).toBeDefined();
            expect(conversationB).toBeDefined();
            expect(conversationA!.messages.length).toBe(0);
            expect(conversationB!.messages.length).toBeGreaterThanOrEqual(2);

            wsA.close();
            resolve();
          }
        });

        wsA.on('error', reject);

      } catch (error) {
        reject(error);
      }
    });
  });
});
