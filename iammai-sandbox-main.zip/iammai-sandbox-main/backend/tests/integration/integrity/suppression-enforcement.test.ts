/**
 * Integration test for suppression enforcement.
 * Requires PostgreSQL database.
 * @see specs/007-presence-suppression/tasks.md T026
 */

import { describe, it, expect, beforeAll, afterAll, beforeEach } from 'vitest';
import { pool, query, transaction } from '../../../src/lib/db.js';
import * as sessionModel from '../../../src/models/session.js';
import * as presenceTracker from '../../../src/integrity/presence-tracker.js';
import { observeTransition } from '../../../src/integrity/state-observer.js';
import * as ledger from '../../../src/integrity/ledger.js';
import { verify } from '../../../src/integrity/verification-engine.js';
import { buildWitnessArtifact } from '../../../src/integrity/witness-emitter.js';
import { derivePresenceHash } from '../../../src/services/presence.js';
import {
  logAdminAction,
  getAdminActions,
  clearAdminActions,
  evaluateAction,
} from '../../../src/integrity/suppression-engine.js';
import type { Session } from '../../../src/lib/types.js';

const DB_URL = process.env.DATABASE_URL;
const describeWithDb = DB_URL ? describe : describe.skip;

describeWithDb('Suppression Enforcement Integration', () => {
  let adminId: string;

  beforeAll(async () => {
    const result = await query<{ id: string }>(
      `INSERT INTO admins (email, password_hash)
       VALUES ('test-suppression@example.com', 'test-hash')
       ON CONFLICT (email) DO UPDATE SET email = EXCLUDED.email
       RETURNING id`
    );
    adminId = result.rows[0].id;
  });

  afterAll(async () => {
    await query('DELETE FROM presence_records WHERE session_id IN (SELECT id FROM sessions WHERE admin_id = $1)', [adminId]);
    await query('DELETE FROM integrity_ledger WHERE session_id IN (SELECT id FROM sessions WHERE admin_id = $1)', [adminId]);
    await query('DELETE FROM tokens WHERE session_id IN (SELECT id FROM sessions WHERE admin_id = $1)', [adminId]);
    await query('DELETE FROM sessions WHERE admin_id = $1', [adminId]);
    await query("DELETE FROM admins WHERE email = 'test-suppression@example.com'");
    await pool.end();
  });

  it('session close with FAIL verification → session still closes, FAIL witness emitted', async () => {
    // Create admin-only session (will FAIL I.01 — only 1 attestation method)
    const session = await sessionModel.create('Suppression FAIL Test', adminId, {
      topic: 'Suppression test',
    }, {
      max_participants: 5,
    });

    await transaction(async (client) => {
      await observeTransition(client, session, null, 'CREATED', 'SESSION_CREATED');
      await presenceTracker.attestPresence(client, session.id, 'CREATOR', derivePresenceHash(adminId), 'AUTH_EVENT');
    });

    const started = await sessionModel.transitionState(session.id, 'CREATED', 'ACTIVE');
    await transaction(async (client) => {
      await observeTransition(client, started!, 'CREATED', 'ACTIVE', 'SESSION_ACTIVATED');
    });

    const ended = await sessionModel.transitionState(session.id, 'ACTIVE', 'ENDED');
    await transaction(async (client) => {
      await observeTransition(client, ended!, 'ACTIVE', 'ENDED', 'SESSION_CLOSED');
      await presenceTracker.finalizePresence(client, session.id);
    });

    const records = await presenceTracker.getPresenceRecords(session.id);
    const entries = await ledger.getEntriesBySession(session.id);
    const result = verify(ended!, entries, undefined, records);

    // Should FAIL due to I.01 (only 1 method)
    expect(result.pass).toBe(false);

    // Witness still emitted with FAIL and suppression_triggered=true
    const summary = await presenceTracker.getPresenceSummary(session.id);
    const witness = buildWitnessArtifact(result, ended!, summary, true);
    expect(witness.pass_fail).toBe('FAIL');
    expect(witness.suppression_triggered).toBe(true);
  });

  it('action with PASS verification → proceeds normally', async () => {
    // Create session with admin + participant (2 methods)
    const session = await sessionModel.create('Suppression PASS Test', adminId, {
      topic: 'Suppression pass test',
    }, {
      max_participants: 10,
    });

    await transaction(async (client) => {
      await observeTransition(client, session, null, 'CREATED', 'SESSION_CREATED');
      await presenceTracker.attestPresence(client, session.id, 'CREATOR', derivePresenceHash(adminId), 'AUTH_EVENT');
    });

    const started = await sessionModel.transitionState(session.id, 'CREATED', 'ACTIVE');
    await transaction(async (client) => {
      await observeTransition(client, started!, 'CREATED', 'ACTIVE', 'SESSION_ACTIVATED');
    });

    // Add participant
    await presenceTracker.attestPresence(null, session.id, 'PARTICIPANT', 'user1234', 'JOIN_TOKEN');

    const ended = await sessionModel.transitionState(session.id, 'ACTIVE', 'ENDED');
    await transaction(async (client) => {
      await observeTransition(client, ended!, 'ACTIVE', 'ENDED', 'SESSION_CLOSED');
      await presenceTracker.finalizePresence(client, session.id);
    });

    const records = await presenceTracker.getPresenceRecords(session.id);
    const entries = await ledger.getEntriesBySession(session.id);
    const result = verify(ended!, entries, undefined, records);

    // Should PASS with 2 methods
    const i01Result = result.protocolResults.find(r => r.protocol === 'I.01');
    expect(i01Result!.result).toBe('PASS');

    const summary = await presenceTracker.getPresenceSummary(session.id);
    const witness = buildWitnessArtifact(result, ended!, summary, false);
    expect(witness.suppression_triggered).toBe(false);
  });
});
