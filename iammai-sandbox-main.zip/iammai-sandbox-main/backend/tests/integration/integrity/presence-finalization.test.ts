/**
 * Integration test for full lifecycle with all 6 protocols.
 * End-to-end: create → start → join → message → end → verify all protocols → witness.
 * Requires PostgreSQL database.
 * @see specs/007-presence-suppression/tasks.md T037
 */

import { describe, it, expect, beforeAll, afterAll } from 'vitest';
import { pool, query, transaction } from '../../../src/lib/db.js';
import * as sessionModel from '../../../src/models/session.js';
import * as presenceTracker from '../../../src/integrity/presence-tracker.js';
import { observeTransition } from '../../../src/integrity/state-observer.js';
import * as ledger from '../../../src/integrity/ledger.js';
import { verify } from '../../../src/integrity/verification-engine.js';
import { buildWitnessArtifact } from '../../../src/integrity/witness-emitter.js';
import { derivePresenceHash } from '../../../src/services/presence.js';
import { computeEntryHash } from '../../../src/integrity/hash.js';
import type { Session } from '../../../src/lib/types.js';
import type { AdminAction } from '../../../src/integrity/types.js';

const DB_URL = process.env.DATABASE_URL;
const describeWithDb = DB_URL ? describe : describe.skip;

describeWithDb('Full Lifecycle with All Protocols', () => {
  let adminId: string;

  beforeAll(async () => {
    const result = await query<{ id: string }>(
      `INSERT INTO admins (email, password_hash)
       VALUES ('test-finalization@example.com', 'test-hash')
       ON CONFLICT (email) DO UPDATE SET email = EXCLUDED.email
       RETURNING id`
    );
    adminId = result.rows[0].id;
  });

  afterAll(async () => {
    await query('DELETE FROM presence_records WHERE session_id IN (SELECT id FROM sessions WHERE admin_id = $1)', [adminId]);
    await query('DELETE FROM integrity_ledger WHERE session_id IN (SELECT id FROM sessions WHERE admin_id = $1)', [adminId]);
    await query('DELETE FROM tokens WHERE session_id IN (SELECT id FROM sessions WHERE admin_id = $1)', [adminId]);
    await query('DELETE FROM sessions WHERE admin_id = $1', [adminId]);
    await query("DELETE FROM admins WHERE email = 'test-finalization@example.com'");
    await pool.end();
  });

  it('verifies all 6 protocols with full session lifecycle', async () => {
    // Admin actions log for this test
    const adminActions: AdminAction[] = [];

    // 1. Create session
    const session = await sessionModel.create('Full Protocol Test', adminId, {
      topic: 'Full protocol lifecycle test',
    }, {
      max_participants: 10,
    });

    await transaction(async (client) => {
      await observeTransition(client, session, null, 'CREATED', 'SESSION_CREATED');
      await presenceTracker.attestPresence(client, session.id, 'CREATOR', derivePresenceHash(adminId), 'AUTH_EVENT');
    });

    adminActions.push({
      sessionId: session.id,
      actionType: 'SESSION_CREATE',
      timestamp: new Date(),
      outcome: 'EXECUTED',
    });

    // 2. Start session
    const started = await sessionModel.transitionState(session.id, 'CREATED', 'ACTIVE');
    expect(started).not.toBeNull();
    await transaction(async (client) => {
      await observeTransition(client, started!, 'CREATED', 'ACTIVE', 'SESSION_ACTIVATED');
    });

    adminActions.push({
      sessionId: session.id,
      actionType: 'SESSION_START',
      timestamp: new Date(),
      outcome: 'EXECUTED',
    });

    // 3. Participant joins
    await presenceTracker.attestPresence(null, session.id, 'PARTICIPANT', 'user5678', 'JOIN_TOKEN');

    // 4. AI processes message
    await presenceTracker.attestPresence(null, session.id, 'AGENT', 'ai-agent', 'MESSAGE_PROCESSING');

    // 5. End session
    const ended = await sessionModel.transitionState(session.id, 'ACTIVE', 'ENDED');
    expect(ended).not.toBeNull();
    await transaction(async (client) => {
      await observeTransition(client, ended!, 'ACTIVE', 'ENDED', 'SESSION_CLOSED');
      await presenceTracker.finalizePresence(client, session.id);
    });

    adminActions.push({
      sessionId: session.id,
      actionType: 'SESSION_END',
      timestamp: new Date(),
      outcome: 'EXECUTED',
    });

    // 6. Verify all 6 protocols
    const presenceRecords = await presenceTracker.getPresenceRecords(session.id);
    const entries = await ledger.getEntriesBySession(session.id);
    const result = verify(ended!, entries, undefined, presenceRecords, adminActions);

    // Check all 6 protocols evaluated
    expect(result.protocolResults).toHaveLength(6);
    expect(result.protocolResults.map(r => r.protocol)).toEqual([
      'I.01', 'I.02', 'I.03', 'I.04', 'I.05', 'I.08',
    ]);

    // I.01 PASS: 3 attestation methods
    expect(result.protocolResults.find(r => r.protocol === 'I.01')!.result).toBe('PASS');

    // I.02 PASS: valid boundaries
    expect(result.protocolResults.find(r => r.protocol === 'I.02')!.result).toBe('PASS');

    // I.03 PASS: monotonic progression
    expect(result.protocolResults.find(r => r.protocol === 'I.03')!.result).toBe('PASS');

    // I.04 PASS: hash chain intact
    expect(result.protocolResults.find(r => r.protocol === 'I.04')!.result).toBe('PASS');

    // I.05 PASS: no admin overrides
    expect(result.protocolResults.find(r => r.protocol === 'I.05')!.result).toBe('PASS');

    // I.08 PASS: no contradictory commands
    expect(result.protocolResults.find(r => r.protocol === 'I.08')!.result).toBe('PASS');

    // Overall PASS
    expect(result.pass).toBe(true);

    // 7. Witness with real presence
    const summary = await presenceTracker.getPresenceSummary(session.id);
    const witness = buildWitnessArtifact(result, ended!, summary, false);

    expect(witness.pass_fail).toBe('PASS');
    expect(witness.suppression_triggered).toBe(false);
    expect(witness.presence.admin.attested).toBe(true);
    expect(witness.presence.participants).toHaveLength(1);
    expect(witness.presence.agents).toHaveLength(1);
    expect(witness.presence.total_attestation_methods).toBe(3);
    expect(witness.presence.finalized).toBe(true);
    expect(witness.protocols_evaluated).toEqual(['I.01', 'I.02', 'I.03', 'I.04', 'I.05', 'I.08']);
  });

  it('admin-only session → I.01 FAIL witness with all other protocols passing', async () => {
    const session = await sessionModel.create('Admin Only Protocol Test', adminId, {
      topic: 'Admin-only protocol test',
    }, {
      max_participants: 5,
    });

    await transaction(async (client) => {
      await observeTransition(client, session, null, 'CREATED', 'SESSION_CREATED');
      await presenceTracker.attestPresence(client, session.id, 'CREATOR', derivePresenceHash(adminId), 'AUTH_EVENT');
    });

    const started = await sessionModel.transitionState(session.id, 'CREATED', 'ACTIVE');
    await transaction(async (client) => {
      await observeTransition(client, started!, 'CREATED', 'ACTIVE', 'SESSION_ACTIVATED');
    });

    const ended = await sessionModel.transitionState(session.id, 'ACTIVE', 'ENDED');
    await transaction(async (client) => {
      await observeTransition(client, ended!, 'ACTIVE', 'ENDED', 'SESSION_CLOSED');
      await presenceTracker.finalizePresence(client, session.id);
    });

    const records = await presenceTracker.getPresenceRecords(session.id);
    const entries = await ledger.getEntriesBySession(session.id);
    const adminActions: AdminAction[] = [
      { sessionId: session.id, actionType: 'SESSION_CREATE', timestamp: new Date(), outcome: 'EXECUTED' },
      { sessionId: session.id, actionType: 'SESSION_START', timestamp: new Date(), outcome: 'EXECUTED' },
      { sessionId: session.id, actionType: 'SESSION_END', timestamp: new Date(), outcome: 'EXECUTED' },
    ];
    const result = verify(ended!, entries, undefined, records, adminActions);

    // I.01 FAIL (only 1 method), all others PASS
    expect(result.pass).toBe(false);
    expect(result.protocolResults.find(r => r.protocol === 'I.01')!.result).toBe('FAIL');
    expect(result.protocolResults.find(r => r.protocol === 'I.02')!.result).toBe('PASS');
    expect(result.protocolResults.find(r => r.protocol === 'I.03')!.result).toBe('PASS');
    expect(result.protocolResults.find(r => r.protocol === 'I.04')!.result).toBe('PASS');
    expect(result.protocolResults.find(r => r.protocol === 'I.05')!.result).toBe('PASS');
    expect(result.protocolResults.find(r => r.protocol === 'I.08')!.result).toBe('PASS');

    const summary = await presenceTracker.getPresenceSummary(session.id);
    const witness = buildWitnessArtifact(result, ended!, summary, true);
    expect(witness.pass_fail).toBe('FAIL');
    expect(witness.suppression_triggered).toBe(true);
  });
});
