/**
 * Integration test: Co-agency balance enforcement in session close flow.
 * Tests that co-agency tracking integrates correctly with I.09 protocol evaluation.
 * @see specs/008-governance-protocols/contracts/co-agency-tracker.md
 * @see specs/008-governance-protocols/contracts/protocol-evaluators.md
 * @see specs/008-governance-protocols/tasks.md#T026
 */

import { describe, it, expect, beforeEach } from 'vitest';
import {
  canPerformAction,
  trackAction,
  getHistory,
  clearSession,
} from '../../../src/integrity/co-agency-tracker.js';
import { I09CoAgencyBalance } from '../../../src/integrity/protocols/i09-co-agency-balance.js';
import { verify } from '../../../src/integrity/verification-engine.js';
import { computeEntryHash } from '../../../src/integrity/hash.js';
import type { LedgerEntry, MetadataSnapshot, PresenceRecord, IrreversibleAction } from '../../../src/integrity/types.js';
import type { Session } from '../../../src/lib/types.js';

const SESSION_ID = 'cccccccc-dddd-eeee-ffff-000000000000';
const ADMIN_ID = '11111111-2222-3333-4444-555555555555';

beforeEach(() => {
  clearSession(SESSION_ID);
});

// ============================================================================
// Helpers
// ============================================================================

function makeAction(agentType: 'HUMAN' | 'MACHINE', actionType: 'SESSION_END' | 'PRESENCE_FINALIZATION' | 'VERIFICATION_EXECUTION'): IrreversibleAction {
  return { sessionId: SESSION_ID, agentType, actionType, timestamp: new Date() };
}

function makeSession(overrides: Partial<Session> = {}): Session {
  return {
    id: SESSION_ID,
    name: 'Co-Agency Test Session',
    state: 'ENDED',
    createdAt: new Date('2026-02-14T10:00:00.000Z'),
    startedAt: new Date('2026-02-14T10:01:00.000Z'),
    endedAt: new Date('2026-02-14T10:30:00.000Z'),
    tokenCount: 2,
    userCount: 2,
    adminId: ADMIN_ID,
    contextDescriptor: { topic: 'Co-agency test' },
    environmentalConstraints: { max_participants: 10 },
    ...overrides,
  };
}

function makePresenceRecords(): PresenceRecord[] {
  return [
    {
      id: 'presence-creator',
      sessionId: SESSION_ID,
      role: 'CREATOR',
      presenceHash: 'hash-admin',
      attestationMethod: 'AUTH_EVENT',
      attested: true,
      finalized: true,
      createdAt: new Date('2026-02-14T10:00:00.000Z'),
      finalizedAt: new Date('2026-02-14T10:30:00.000Z'),
    },
  ];
}

function makeLedgerEntries(): LedgerEntry[] {
  const snapshots: MetadataSnapshot[] = [
    {
      session_id: SESSION_ID, session_name: 'Co-Agency Test Session',
      state: 'CREATED', framework_status: 'OPEN', admin_id: ADMIN_ID,
      token_count: 0, user_count: 0,
      created_at: '2026-02-14T10:00:00.000Z', started_at: null, ended_at: null,
      context_descriptor: { topic: 'Co-agency test' },
      environmental_constraints: { max_participants: 10 },
    },
    {
      session_id: SESSION_ID, session_name: 'Co-Agency Test Session',
      state: 'ACTIVE', framework_status: 'OPEN', admin_id: ADMIN_ID,
      token_count: 2, user_count: 2,
      created_at: '2026-02-14T10:00:00.000Z',
      started_at: '2026-02-14T10:01:00.000Z', ended_at: null,
      context_descriptor: { topic: 'Co-agency test' },
      environmental_constraints: { max_participants: 10 },
    },
    {
      session_id: SESSION_ID, session_name: 'Co-Agency Test Session',
      state: 'ENDED', framework_status: 'CLOSED', admin_id: ADMIN_ID,
      token_count: 2, user_count: 2,
      created_at: '2026-02-14T10:00:00.000Z',
      started_at: '2026-02-14T10:01:00.000Z',
      ended_at: '2026-02-14T10:30:00.000Z',
      context_descriptor: { topic: 'Co-agency test' },
      environmental_constraints: { max_participants: 10 },
    },
  ];
  const eventTypes = ['SESSION_CREATED', 'SESSION_ACTIVATED', 'SESSION_CLOSED'] as const;
  const timestamps = [
    '2026-02-14T10:00:00.000Z',
    '2026-02-14T10:01:00.000Z',
    '2026-02-14T10:30:00.000Z',
  ];
  const entries: LedgerEntry[] = [];
  let previousHash: string | null = null;
  for (let i = 0; i < 3; i++) {
    const seq = i + 1;
    const hash = computeEntryHash(previousHash, seq, SESSION_ID, eventTypes[i], timestamps[i]!, snapshots[i]!);
    entries.push({
      id: `entry-${seq}`,
      sequenceNumber: seq,
      sessionId: SESSION_ID,
      eventType: eventTypes[i],
      timestamp: new Date(timestamps[i]!),
      fromState: i === 0 ? null : (['CREATED', 'ACTIVE'] as const)[i - 1],
      toState: snapshots[i]!.state,
      metadataSnapshot: snapshots[i]!,
      previousHash,
      entryHash: hash,
    });
    previousHash = hash;
  }
  return entries;
}

// ============================================================================
// I.09 Protocol: direct evaluation
// ============================================================================

describe('I.09 co-agency balance — direct protocol evaluation', () => {
  const evaluator = new I09CoAgencyBalance();

  it('PASS with empty co-agency history', () => {
    const result = evaluator.evaluate({
      session: makeSession(),
      ledgerEntries: [],
      presenceRecords: [],
      adminActions: [],
      coAgencyActions: [],
    });
    expect(result.result).toBe('PASS');
    expect(result.details).toContain('no irreversible actions recorded');
  });

  it('PASS when HUMAN and MACHINE alternate (balanced)', () => {
    const actions: IrreversibleAction[] = [
      makeAction('HUMAN', 'SESSION_END'),
      makeAction('MACHINE', 'PRESENCE_FINALIZATION'),
      makeAction('MACHINE', 'VERIFICATION_EXECUTION'),
    ];
    const result = evaluator.evaluate({
      session: makeSession(),
      ledgerEntries: [],
      presenceRecords: [],
      adminActions: [],
      coAgencyActions: actions,
    });
    expect(result.result).toBe('PASS');
    expect(result.details).toContain('Co-agency balance maintained');
  });

  it('PASS with exactly 2 consecutive same-type actions (at limit, not exceeded)', () => {
    const actions: IrreversibleAction[] = [
      makeAction('MACHINE', 'PRESENCE_FINALIZATION'),
      makeAction('MACHINE', 'VERIFICATION_EXECUTION'),
    ];
    const result = evaluator.evaluate({
      session: makeSession(),
      ledgerEntries: [],
      presenceRecords: [],
      adminActions: [],
      coAgencyActions: actions,
    });
    expect(result.result).toBe('PASS');
  });

  it('FAIL when 3 consecutive MACHINE actions detected', () => {
    const actions: IrreversibleAction[] = [
      makeAction('MACHINE', 'PRESENCE_FINALIZATION'),
      makeAction('MACHINE', 'VERIFICATION_EXECUTION'),
      makeAction('MACHINE', 'PRESENCE_FINALIZATION'),
    ];
    const result = evaluator.evaluate({
      session: makeSession(),
      ledgerEntries: [],
      presenceRecords: [],
      adminActions: [],
      coAgencyActions: actions,
    });
    expect(result.result).toBe('FAIL');
    expect(result.details).toContain('MACHINE');
    expect(result.details).toContain('3');
    expect(result.details).toContain('max 2');
  });

  it('FAIL when 3 consecutive HUMAN actions detected', () => {
    const actions: IrreversibleAction[] = [
      makeAction('HUMAN', 'SESSION_END'),
      makeAction('HUMAN', 'SESSION_END'),
      makeAction('HUMAN', 'SESSION_END'),
    ];
    const result = evaluator.evaluate({
      session: makeSession(),
      ledgerEntries: [],
      presenceRecords: [],
      adminActions: [],
      coAgencyActions: actions,
    });
    expect(result.result).toBe('FAIL');
    expect(result.details).toContain('HUMAN');
    expect(result.details).toContain('3');
  });
});

// ============================================================================
// Co-agency tracker: standard session close flow
// ============================================================================

describe('Co-agency enforcement — normal session close flow', () => {
  it('standard close flow (HUMAN:SESSION_END + MACHINE:FINALIZATION + MACHINE:VERIFICATION) stays within limits', () => {
    // Simulate the session close flow from quickstart.md steps 2, 5, 8
    trackAction(SESSION_ID, 'HUMAN', 'SESSION_END');
    trackAction(SESSION_ID, 'MACHINE', 'PRESENCE_FINALIZATION');
    trackAction(SESSION_ID, 'MACHINE', 'VERIFICATION_EXECUTION');

    const history = getHistory(SESSION_ID);
    expect(history).toHaveLength(3);

    // I.09 should PASS (MACHINE streak is exactly 2 — at limit)
    const evaluator = new I09CoAgencyBalance();
    const result = evaluator.evaluate({
      session: makeSession(),
      ledgerEntries: [],
      presenceRecords: [],
      adminActions: [],
      coAgencyActions: history,
    });
    expect(result.result).toBe('PASS');
  });

  it('canPerformAction blocks 3rd consecutive MACHINE action', () => {
    trackAction(SESSION_ID, 'MACHINE', 'PRESENCE_FINALIZATION');
    trackAction(SESSION_ID, 'MACHINE', 'VERIFICATION_EXECUTION');
    // Machine has done 2 consecutive; third should be blocked
    expect(canPerformAction(SESSION_ID, 'MACHINE')).toBe(false);
    // But HUMAN is still allowed
    expect(canPerformAction(SESSION_ID, 'HUMAN')).toBe(true);
  });

  it('agent type switch resets consecutive counter', () => {
    trackAction(SESSION_ID, 'MACHINE', 'PRESENCE_FINALIZATION');
    trackAction(SESSION_ID, 'MACHINE', 'VERIFICATION_EXECUTION');
    expect(canPerformAction(SESSION_ID, 'MACHINE')).toBe(false);

    // HUMAN acts, resetting the MACHINE counter
    trackAction(SESSION_ID, 'HUMAN', 'SESSION_END');
    expect(canPerformAction(SESSION_ID, 'MACHINE')).toBe(true);
  });
});

// ============================================================================
// Verify() integration: coAgencyActions in EvaluationContext
// ============================================================================

describe('Co-agency enforcement — verify() integration with I.09', () => {
  it('verify() passes I.09 for standard close flow co-agency history', () => {
    // Provide the standard close-flow history to verify()
    const coAgencyActions: IrreversibleAction[] = [
      makeAction('HUMAN', 'SESSION_END'),
      makeAction('MACHINE', 'PRESENCE_FINALIZATION'),
      makeAction('MACHINE', 'VERIFICATION_EXECUTION'),
    ];

    const session = makeSession();
    const entries = makeLedgerEntries();
    const presenceRecords = makePresenceRecords();

    // Run only I.09 to isolate the test
    const result = verify(session, entries, [new I09CoAgencyBalance()], presenceRecords, [], coAgencyActions);

    expect(result.pass).toBe(true);
    const i09 = result.protocolResults.find(r => r.protocol === 'I.09');
    expect(i09?.result).toBe('PASS');
  });

  it('verify() fails I.09 when 3 consecutive MACHINE actions in history', () => {
    const coAgencyActions: IrreversibleAction[] = [
      makeAction('MACHINE', 'PRESENCE_FINALIZATION'),
      makeAction('MACHINE', 'VERIFICATION_EXECUTION'),
      makeAction('MACHINE', 'PRESENCE_FINALIZATION'), // 3rd consecutive — violation
    ];

    const session = makeSession();
    const entries = makeLedgerEntries();
    const presenceRecords = makePresenceRecords();

    const result = verify(session, entries, [new I09CoAgencyBalance()], presenceRecords, [], coAgencyActions);

    expect(result.pass).toBe(false);
    const i09 = result.protocolResults.find(r => r.protocol === 'I.09');
    expect(i09?.result).toBe('FAIL');
    expect(i09?.details).toContain('MACHINE');
  });

  it('verify() PASS when coAgencyActions is empty (no actions recorded)', () => {
    const session = makeSession();
    const entries = makeLedgerEntries();
    const presenceRecords = makePresenceRecords();

    const result = verify(session, entries, [new I09CoAgencyBalance()], presenceRecords, [], []);

    expect(result.pass).toBe(true);
    const i09 = result.protocolResults.find(r => r.protocol === 'I.09');
    expect(i09?.result).toBe('PASS');
    expect(i09?.details).toContain('no irreversible actions recorded');
  });
});

// ============================================================================
// Co-agency tracker: state isolation across sessions
// ============================================================================

describe('Co-agency enforcement — session state isolation', () => {
  const OTHER_SESSION = 'eeeeeeee-ffff-0000-1111-222222222222';

  beforeEach(() => {
    clearSession(OTHER_SESSION);
  });

  it('co-agency state is isolated per session', () => {
    trackAction(SESSION_ID, 'MACHINE', 'PRESENCE_FINALIZATION');
    trackAction(SESSION_ID, 'MACHINE', 'VERIFICATION_EXECUTION');
    // SESSION_ID is at limit; OTHER_SESSION has no history
    expect(canPerformAction(SESSION_ID, 'MACHINE')).toBe(false);
    expect(canPerformAction(OTHER_SESSION, 'MACHINE')).toBe(true);
  });

  it('clearSession removes tracking without affecting other sessions', () => {
    trackAction(SESSION_ID, 'MACHINE', 'PRESENCE_FINALIZATION');
    trackAction(OTHER_SESSION, 'MACHINE', 'PRESENCE_FINALIZATION');

    clearSession(SESSION_ID);

    expect(getHistory(SESSION_ID)).toHaveLength(0);
    expect(getHistory(OTHER_SESSION)).toHaveLength(1);

    clearSession(OTHER_SESSION);
  });
});
