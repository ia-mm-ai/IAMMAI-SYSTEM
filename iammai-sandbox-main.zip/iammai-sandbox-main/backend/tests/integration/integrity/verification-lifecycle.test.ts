/**
 * Integration test: Full create -> start -> end -> verify -> witness lifecycle.
 * Tests the complete verification flow using real protocol evaluators.
 * @see specs/006-verification-witness
 */

import { describe, it, expect } from 'vitest';
import { verify } from '../../../src/integrity/verification-engine.js';
import { buildWitnessArtifact } from '../../../src/integrity/witness-emitter.js';
import { computeEntryHash } from '../../../src/integrity/hash.js';
import type { LedgerEntry, MetadataSnapshot, PresenceRecord } from '../../../src/integrity/types.js';
import type { Session } from '../../../src/lib/types.js';

const SESSION_ID = 'aaaaaaaa-bbbb-cccc-dddd-eeeeeeeeeeee';
const ADMIN_ID = '11111111-2222-3333-4444-555555555555';

function makeSnapshot(overrides: Partial<MetadataSnapshot> = {}): MetadataSnapshot {
  return {
    session_id: SESSION_ID,
    session_name: 'Integration Test Session',
    state: 'CREATED',
    framework_status: 'OPEN',
    admin_id: ADMIN_ID,
    token_count: 0,
    user_count: 0,
    created_at: '2026-02-14T10:00:00.000Z',
    started_at: null,
    ended_at: null,
    context_descriptor: { topic: 'Integration test' },
    environmental_constraints: { max_participants: 10 },
    ...overrides,
  };
}

/**
 * Simulate a full session lifecycle producing ledger entries.
 */
function simulateLifecycle(): { session: Session; entries: LedgerEntry[] } {
  const snapshots: MetadataSnapshot[] = [
    makeSnapshot(),
    makeSnapshot({
      state: 'ACTIVE',
      started_at: '2026-02-14T10:01:00.000Z',
      user_count: 2,
      token_count: 2,
    }),
    makeSnapshot({
      state: 'ENDED',
      framework_status: 'CLOSED',
      started_at: '2026-02-14T10:01:00.000Z',
      ended_at: '2026-02-14T10:30:00.000Z',
      user_count: 2,
      token_count: 2,
    }),
  ];
  const eventTypes = ['SESSION_CREATED', 'SESSION_ACTIVATED', 'SESSION_CLOSED'] as const;
  const timestamps = [
    '2026-02-14T10:00:00.000Z',
    '2026-02-14T10:01:00.000Z',
    '2026-02-14T10:30:00.000Z',
  ];

  const entries: LedgerEntry[] = [];
  let previousHash: string | null = null;

  for (let i = 0; i < 3; i++) {
    const seq = i + 1;
    const hash = computeEntryHash(previousHash, seq, SESSION_ID, eventTypes[i], timestamps[i]!, snapshots[i]!);
    entries.push({
      id: `entry-${seq}`,
      sequenceNumber: seq,
      sessionId: SESSION_ID,
      eventType: eventTypes[i],
      timestamp: new Date(timestamps[i]!),
      fromState: i === 0 ? null : (['CREATED', 'ACTIVE'] as const)[i - 1],
      toState: snapshots[i]!.state,
      metadataSnapshot: snapshots[i]!,
      previousHash,
      entryHash: hash,
    });
    previousHash = hash;
  }

  const session: Session = {
    id: SESSION_ID,
    name: 'Integration Test Session',
    state: 'ENDED',
    createdAt: new Date('2026-02-14T10:00:00.000Z'),
    startedAt: new Date('2026-02-14T10:01:00.000Z'),
    endedAt: new Date('2026-02-14T10:30:00.000Z'),
    tokenCount: 2,
    userCount: 2,
    adminId: ADMIN_ID,
    contextDescriptor: { topic: 'Integration test' },
    environmentalConstraints: { max_participants: 10 },
  };

  return { session, entries };
}

function makePresenceRecords(): PresenceRecord[] {
  return [
    {
      id: 'presence-1',
      sessionId: SESSION_ID,
      role: 'CREATOR',
      presenceHash: 'hash-admin',
      attestationMethod: 'AUTH_EVENT',
      attested: true,
      finalized: true,
      createdAt: new Date('2026-02-14T10:00:00.000Z'),
      finalizedAt: new Date('2026-02-14T10:30:00.000Z'),
    },
    {
      id: 'presence-2',
      sessionId: SESSION_ID,
      role: 'PARTICIPANT',
      presenceHash: 'hash-participant',
      attestationMethod: 'JOIN_TOKEN',
      attested: true,
      finalized: true,
      createdAt: new Date('2026-02-14T10:02:00.000Z'),
      finalizedAt: new Date('2026-02-14T10:30:00.000Z'),
    },
  ];
}

describe('Verification lifecycle — full flow', () => {
  it('passes all protocols for a valid session lifecycle', () => {
    const { session, entries } = simulateLifecycle();
    const presenceRecords = makePresenceRecords();

    const result = verify(session, entries, undefined, presenceRecords);

    expect(result.pass).toBe(true);
    expect(result.protocolResults).toHaveLength(10);
    // Structural + operational protocols
    expect(result.protocolResults[0]!.protocol).toBe('I.01');
    expect(result.protocolResults[0]!.result).toBe('PASS');
    expect(result.protocolResults[1]!.protocol).toBe('I.02');
    expect(result.protocolResults[1]!.result).toBe('PASS');
    expect(result.protocolResults[2]!.protocol).toBe('I.03');
    expect(result.protocolResults[2]!.result).toBe('PASS');
    expect(result.protocolResults[3]!.protocol).toBe('I.04');
    expect(result.protocolResults[3]!.result).toBe('PASS');
    expect(result.protocolResults[4]!.protocol).toBe('I.05');
    expect(result.protocolResults[4]!.result).toBe('PASS');
    expect(result.protocolResults[5]!.protocol).toBe('I.08');
    expect(result.protocolResults[5]!.result).toBe('PASS');
    // Governance protocols (Feature 008)
    expect(result.protocolResults[6]!.protocol).toBe('I.06');
    expect(result.protocolResults[6]!.result).toBe('PASS');
    expect(result.protocolResults[7]!.protocol).toBe('I.07');
    expect(result.protocolResults[7]!.result).toBe('PASS');
    expect(result.protocolResults[8]!.protocol).toBe('I.09');
    expect(result.protocolResults[8]!.result).toBe('PASS');
    expect(result.protocolResults[9]!.protocol).toBe('I.10');
    expect(result.protocolResults[9]!.result).toBe('PASS');
  });

  it('produces a complete witness artifact from verification', () => {
    const { session, entries } = simulateLifecycle();
    const presenceRecords = makePresenceRecords();

    const result = verify(session, entries, undefined, presenceRecords);
    const artifact = buildWitnessArtifact(result, session);

    expect(artifact.artifact_type).toBe('SESSION_WITNESS');
    expect(artifact.pass_fail).toBe('PASS');
    expect(artifact.protocols_evaluated).toEqual([
      'I.01', 'I.02', 'I.03', 'I.04', 'I.05', 'I.08',
      'I.06', 'I.07', 'I.09', 'I.10',
    ]);
    expect(artifact.t_open).toBe('2026-02-14T10:00:00.000Z');
    expect(artifact.t_close).toBe('2026-02-14T10:30:00.000Z');
    expect(artifact.metadata.participant_count).toBe(2);
    expect(artifact.metadata.session_name).toBe('Integration Test Session');
    expect(artifact.metadata.duration_ms).toBe(1800000);
  });

  it('records FAIL when session has broken hash chain', () => {
    const { session, entries } = simulateLifecycle();

    // Tamper with hash chain
    entries[1] = {
      ...entries[1]!,
      entryHash: 'aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa',
    };

    const result = verify(session, entries);
    expect(result.pass).toBe(false);

    const artifact = buildWitnessArtifact(result, session);
    expect(artifact.pass_fail).toBe('FAIL');
    // I.04 should fail, others may pass
    const i04 = result.protocolResults.find(r => r.protocol === 'I.04');
    expect(i04?.result).toBe('FAIL');
  });

  it('records FAIL when session is not properly ended', () => {
    const { session, entries } = simulateLifecycle();
    const activeSession = { ...session, state: 'ACTIVE' as const, endedAt: null };

    const result = verify(activeSession, entries);
    expect(result.pass).toBe(false);

    const i02 = result.protocolResults.find(r => r.protocol === 'I.02');
    expect(i02?.result).toBe('FAIL');
  });

  it('records FAIL when backward state regression detected', () => {
    const { session, entries } = simulateLifecycle();

    // Replace third entry with backward regression
    entries[2] = {
      ...entries[2]!,
      toState: 'CREATED',
      metadataSnapshot: makeSnapshot({ state: 'CREATED' }),
    };

    const result = verify(session, entries);
    expect(result.pass).toBe(false);

    const i03 = result.protocolResults.find(r => r.protocol === 'I.03');
    expect(i03?.result).toBe('FAIL');
  });
});
