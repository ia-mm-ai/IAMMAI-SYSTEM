/**
 * Active probing integration test: Mandatory Suppression compliance condition.
 *
 * Tests that the compliance checker correctly identifies whether FAIL witnesses
 * have corresponding SUPPRESSION_EVENTs and that no unsuppressed mutations
 * follow a suppression on real DB data.
 *
 * @see specs/009-compliance-test/tasks.md T010
 * @see specs/009-compliance-test/spec.md §11 Condition 3
 */

import { describe, it, expect, beforeAll, afterAll } from 'vitest';
import { pool, query, transaction } from '../../../src/lib/db.js';
import * as sessionModel from '../../../src/models/session.js';
import * as presenceTracker from '../../../src/integrity/presence-tracker.js';
import { observeTransition } from '../../../src/integrity/state-observer.js';
import { appendEntry, getEntriesBySession } from '../../../src/integrity/ledger.js';
import { buildMetadataSnapshot } from '../../../src/integrity/state-observer.js';
import { evaluateAction, recordSuppression, logAdminAction } from '../../../src/integrity/suppression-engine.js';
import { runConditionCheck, evaluateMandatorySuppression } from '../../../src/integrity/compliance-checker.js';
import { derivePresenceHash } from '../../../src/services/presence.js';
import type { Session } from '../../../src/lib/types.js';
import type { MetadataSnapshot } from '../../../src/integrity/types.js';

const DB_URL = process.env.DATABASE_URL;
const describeWithDb = DB_URL ? describe : describe.skip;

describeWithDb('Compliance Suppression Enforcement — Active Probing', () => {
  let adminId: string;

  beforeAll(async () => {
    const result = await query<{ id: string }>(
      `INSERT INTO admins (email, password_hash)
       VALUES ('compliance-suppression-test@example.com', 'test-hash')
       ON CONFLICT (email) DO UPDATE SET email = EXCLUDED.email
       RETURNING id`
    );
    adminId = result.rows[0].id;
  });

  afterAll(async () => {
    await query(
      `DELETE FROM presence_records
         WHERE session_id IN (SELECT id FROM sessions WHERE admin_id = $1)`,
      [adminId]
    );
    await query(
      `DELETE FROM integrity_ledger
         WHERE session_id IN (SELECT id FROM sessions WHERE admin_id = $1)`,
      [adminId]
    );
    await query(
      `DELETE FROM tokens
         WHERE session_id IN (SELECT id FROM sessions WHERE admin_id = $1)`,
      [adminId]
    );
    await query('DELETE FROM sessions WHERE admin_id = $1', [adminId]);
    await query("DELETE FROM admins WHERE email = 'compliance-suppression-test@example.com'");
    await pool.end();
  });

  // --------------------------------------------------------------------------
  // Scenario 1: FAIL witness + SUPPRESSION_EVENT → compliance PASS
  // --------------------------------------------------------------------------

  it('PASS — FAIL witness followed by SUPPRESSION_EVENT satisfies mandatory suppression', async () => {
    // Create and run a minimal session through ENDED state
    const session = await sessionModel.create(
      'Compliance Suppression PASS Test',
      adminId,
      { topic: 'compliance test' },
      { max_participants: 5 }
    );

    // Record transitions
    await transaction(async (client) => {
      await observeTransition(client, session, null, 'CREATED', 'SESSION_CREATED');
      await presenceTracker.attestPresence(
        client,
        session.id,
        'CREATOR',
        derivePresenceHash(adminId),
        'AUTH_EVENT'
      );
    });

    const started = await sessionModel.transitionState(session.id, 'CREATED', 'ACTIVE');
    await transaction(async (client) => {
      await observeTransition(client, started!, 'CREATED', 'ACTIVE', 'SESSION_ACTIVATED');
    });

    const ended = await sessionModel.transitionState(session.id, 'ACTIVE', 'ENDED');
    await transaction(async (client) => {
      await observeTransition(client, ended!, 'ACTIVE', 'ENDED', 'SESSION_CLOSED');
      await presenceTracker.finalizePresence(client, session.id);
    });

    // Append a VERIFICATION_WITNESS with pass_fail='FAIL'
    const snapshot = buildMetadataSnapshot(ended!) as MetadataSnapshot & { pass_fail: string; suppression_triggered: boolean };
    snapshot.pass_fail = 'FAIL';
    snapshot.suppression_triggered = true;

    await transaction(async (client) => {
      await appendEntry(client, session.id, 'VERIFICATION_WITNESS', 'ENDED', 'ENDED', snapshot);
    });

    // Append SUPPRESSION_EVENT (mandatory after FAIL)
    await transaction(async (client) => {
      const suppressionSnapshot = {
        ...buildMetadataSnapshot(ended!),
        suppression: {
          sessionId: session.id,
          actionType: 'POST_FAIL_MUTATION',
          failedProtocols: [],
          reason: 'Verification FAIL — all subsequent mutations suppressed',
          timestamp: new Date().toISOString(),
        },
      } as unknown as MetadataSnapshot;
      await appendEntry(client, session.id, 'SUPPRESSION_EVENT', 'ENDED', 'ENDED', suppressionSnapshot);
    });

    // Run compliance check — should PASS (suppression was enforced)
    const result = await runConditionCheck('MANDATORY_SUPPRESSION');

    expect(result.overall).toBe('COMPLIANT');
    const condition = result.conditions[0];
    expect(condition.condition).toBe('MANDATORY_SUPPRESSION');
    expect(condition.result).toBe('PASS');
  });

  // --------------------------------------------------------------------------
  // Scenario 2: Attempt mutating action after FAIL — confirm suppression blocks it
  // --------------------------------------------------------------------------

  it('Mutation attempt after FAIL is blocked by suppression engine', async () => {
    const session = await sessionModel.create(
      'Compliance Mutation Block Test',
      adminId,
      { topic: 'mutation test' },
      { max_participants: 5 }
    );

    await transaction(async (client) => {
      await observeTransition(client, session, null, 'CREATED', 'SESSION_CREATED');
    });

    const started = await sessionModel.transitionState(session.id, 'CREATED', 'ACTIVE');
    await transaction(async (client) => {
      await observeTransition(client, started!, 'CREATED', 'ACTIVE', 'SESSION_ACTIVATED');
    });

    // Log an admin action that simulates a contradictory command
    logAdminAction({
      sessionId: session.id,
      actionType: 'SESSION_END',
      outcome: 'EXECUTED',
      timestamp: new Date(),
    });

    // Now attempt SESSION_START — contradicts SESSION_END → incoherent signal
    const suppressionResult = await evaluateAction(session.id, 'SESSION_START');

    // The suppression engine should block the action
    expect(suppressionResult.allowed).toBe(false);
    expect(suppressionResult.suppression).toBeDefined();
    expect(suppressionResult.suppression!.sessionId).toBe(session.id);

    // Record the suppression in the ledger to prove it was captured
    await transaction(async (client) => {
      const entry = await recordSuppression(client, session.id, suppressionResult.suppression!);
      expect(entry.eventType).toBe('SUPPRESSION_EVENT');
      expect(entry.sessionId).toBe(session.id);
    });

    // Verify the suppression event is now in the ledger
    const entries = await getEntriesBySession(session.id);
    const suppressionEntries = entries.filter((e) => e.eventType === 'SUPPRESSION_EVENT');
    expect(suppressionEntries).toHaveLength(1);
  });

});

// --------------------------------------------------------------------------
// Scenario 3: FAIL witness without SUPPRESSION_EVENT → compliance FAIL
// (No DB needed — evaluator runs against in-memory data to probe violation)
// --------------------------------------------------------------------------

describe('Compliance Suppression — Violation Detection (evaluator probe)', () => {
  it('FAIL — FAIL witness with no SUPPRESSION_EVENT is detected as violation', async () => {
    const session = {
      id: 'compliance-test-violation-session',
      name: 'Violation Test',
      state: 'ENDED',
      adminId: 'admin-probe',
      createdAt: new Date('2026-01-01T10:00:00Z'),
      startedAt: new Date('2026-01-01T10:01:00Z'),
      endedAt: new Date('2026-01-01T11:00:00Z'),
      contextDescriptor: { topic: 'test' },
      environmentalConstraints: { max_participants: 5 },
      tokenCount: 0,
      userCount: 1,
    } as unknown as Session;

    const failWitness = {
      id: 'witness-seq-10',
      sequenceNumber: 10,
      sessionId: session.id,
      eventType: 'VERIFICATION_WITNESS' as const,
      timestamp: new Date('2026-01-01T11:01:00Z'),
      fromState: null,
      toState: 'ENDED',
      metadataSnapshot: { pass_fail: 'FAIL' } as unknown as MetadataSnapshot,
      previousHash: null,
      entryHash: 'hash-witness',
    };

    // No SUPPRESSION_EVENT follows — this is the violation being probed
    const result = await evaluateMandatorySuppression([
      { session, ledgerEntries: [failWitness], presenceRecords: [] },
    ]);

    expect(result.result).toBe('FAIL');
    expect(result.condition).toBe('MANDATORY_SUPPRESSION');
    expect(result.evidence).toHaveLength(1);
    expect(result.evidence[0].type).toBe('SUPPRESSION_RECORD');
    expect(result.evidence[0].description).toMatch(/no corresponding SUPPRESSION_EVENT/);
    expect(result.evidence[0].sessionId).toBe(session.id);
  });
});
