/**
 * Integration test: Acedia lifecycle — detect → warn → force-release flow.
 * Uses shortened thresholds via startMonitor() for fast test execution.
 * @see specs/008-governance-protocols/contracts/acedia-monitor.md
 * @see specs/008-governance-protocols/tasks.md#T025
 */

import { describe, it, expect, beforeEach, afterEach, vi } from 'vitest';

// Mock all DB/model dependencies before importing the module
vi.mock('../../../src/lib/db.js', () => ({
  query: vi.fn(),
  transaction: vi.fn((fn: (client: unknown) => unknown) => fn({})),
}));

vi.mock('../../../src/models/session.js', () => ({
  transitionState: vi.fn(),
  findById: vi.fn(),
}));

vi.mock('../../../src/integrity/ledger.js', () => ({
  appendEntry: vi.fn().mockResolvedValue({ id: 'entry-1' }),
}));

vi.mock('../../../src/integrity/state-observer.js', () => ({
  buildMetadataSnapshot: vi.fn().mockReturnValue({}),
  observeTransition: vi.fn().mockResolvedValue({ id: 'entry-1' }),
}));

vi.mock('../../../src/lib/logger.js', () => ({
  logger: {
    info: vi.fn(),
    warn: vi.fn(),
    error: vi.fn(),
  },
}));

import {
  startMonitor,
  stopMonitor,
  checkSessions,
  recordActivity,
  getAcediaState,
  clearSession,
} from '../../../src/integrity/acedia-monitor.js';

import * as db from '../../../src/lib/db.js';
import * as sessionModel from '../../../src/models/session.js';
import * as ledger from '../../../src/integrity/ledger.js';

const SESSION_ID = 'aaaaaaaa-bbbb-cccc-dddd-eeeeeeeeeeee';

// Short thresholds for tests (100ms each so session rows in past trigger them)
const SHORT_THRESHOLDS = {
  createdIdleMs: 100,
  activeIdleMs: 100,
  countdownMs: 100,
  checkIntervalMs: 9999999, // Very long — prevent auto-firing in tests
};

function makeSessionRow(state: 'CREATED' | 'ACTIVE', msSinceCreated: number, msSinceActivity?: number) {
  const now = Date.now();
  return {
    id: SESSION_ID,
    state,
    name: 'Acedia Test Session',
    created_at: new Date(now - msSinceCreated),
    started_at: state === 'ACTIVE' ? new Date(now - (msSinceActivity ?? msSinceCreated)) : null,
    ended_at: null,
    token_count: 0,
    user_count: 1,
    admin_id: 'admin-1',
    context_descriptor: { topic: 'Test' },
    environmental_constraints: { max_participants: 10 },
  };
}

function makeSession(state: 'CREATED' | 'ACTIVE' | 'ENDED') {
  return {
    id: SESSION_ID,
    name: 'Acedia Test Session',
    state,
    createdAt: new Date(Date.now() - 500),
    startedAt: state !== 'CREATED' ? new Date(Date.now() - 400) : null,
    endedAt: state === 'ENDED' ? new Date() : null,
    tokenCount: 0,
    userCount: 1,
    adminId: 'admin-1',
    contextDescriptor: { topic: 'Test' },
    environmentalConstraints: { max_participants: 10 },
  };
}

beforeEach(() => {
  clearSession(SESSION_ID);
  vi.clearAllMocks();
  vi.mocked(db.transaction).mockImplementation((fn) => fn({} as never));
  // Reset monitor with short thresholds for each test
  stopMonitor();
  startMonitor(SHORT_THRESHOLDS);
});

afterEach(() => {
  stopMonitor();
  clearSession(SESSION_ID);
});

describe('Acedia lifecycle — CREATED session idle detection', () => {
  it('records ACEDIA_WARNING for CREATED session idle past threshold', async () => {
    // Session created 200ms ago; threshold is 100ms
    vi.mocked(db.query).mockResolvedValueOnce({
      rows: [makeSessionRow('CREATED', 200)],
    } as never);

    await checkSessions();

    const state = getAcediaState(SESSION_ID);
    expect(state).toBeDefined();
    expect(state!.phase).toBe('WARNING');
    expect(ledger.appendEntry).toHaveBeenCalledWith(
      expect.anything(),
      SESSION_ID,
      'ACEDIA_WARNING',
      expect.any(String),
      expect.any(String),
      expect.anything()
    );
  });

  it('does not re-warn a session already in WARNING phase', async () => {
    // First check: transitions to WARNING
    vi.mocked(db.query).mockResolvedValueOnce({
      rows: [makeSessionRow('CREATED', 200)],
    } as never);
    await checkSessions();
    expect(getAcediaState(SESSION_ID)!.phase).toBe('WARNING');

    // Second check: should not emit another WARNING
    vi.clearAllMocks();
    vi.mocked(db.transaction).mockImplementation((fn) => fn({} as never));
    vi.mocked(db.query).mockResolvedValueOnce({
      rows: [makeSessionRow('CREATED', 200)],
    } as never);
    await checkSessions();

    expect(ledger.appendEntry).not.toHaveBeenCalledWith(
      expect.anything(), SESSION_ID, 'ACEDIA_WARNING',
      expect.any(String), expect.any(String), expect.anything()
    );
  });
});

describe('Acedia lifecycle — ACTIVE session idle detection', () => {
  it('records ACEDIA_DETECTION for ACTIVE session idle past threshold', async () => {
    // Session last active 200ms ago; threshold is 100ms
    vi.mocked(db.query).mockResolvedValueOnce({
      rows: [makeSessionRow('ACTIVE', 500, 200)],
    } as never);

    await checkSessions();

    const state = getAcediaState(SESSION_ID);
    expect(state).toBeDefined();
    expect(state!.phase).toBe('DETECTION');
    expect(state!.countdownStartedAt).not.toBeNull();
    expect(ledger.appendEntry).toHaveBeenCalledWith(
      expect.anything(),
      SESSION_ID,
      'ACEDIA_DETECTION',
      expect.any(String),
      expect.any(String),
      expect.anything()
    );
  });

  it('does not re-detect a session already in DETECTION phase', async () => {
    // First check: transitions to DETECTION
    vi.mocked(db.query).mockResolvedValueOnce({
      rows: [makeSessionRow('ACTIVE', 500, 200)],
    } as never);
    await checkSessions();
    expect(getAcediaState(SESSION_ID)!.phase).toBe('DETECTION');

    // Second check: countdown not yet expired; no new DETECTION event
    vi.clearAllMocks();
    vi.mocked(db.transaction).mockImplementation((fn) => fn({} as never));

    // Manually set countdownStartedAt to now (fresh) so countdown has not expired
    getAcediaState(SESSION_ID)!.countdownStartedAt = new Date();

    vi.mocked(db.query).mockResolvedValueOnce({
      rows: [makeSessionRow('ACTIVE', 500, 200)],
    } as never);
    await checkSessions();

    expect(ledger.appendEntry).not.toHaveBeenCalledWith(
      expect.anything(), SESSION_ID, 'ACEDIA_DETECTION',
      expect.any(String), expect.any(String), expect.anything()
    );
  });
});

describe('Acedia lifecycle — COUNTDOWN → FORCE_RELEASE', () => {
  it('force-releases a session when countdown has expired', async () => {
    // 1. First check: put session into DETECTION
    vi.mocked(db.query).mockResolvedValueOnce({
      rows: [makeSessionRow('ACTIVE', 500, 200)],
    } as never);
    await checkSessions();
    expect(getAcediaState(SESSION_ID)!.phase).toBe('DETECTION');

    // 2. Manually backdate countdown start so countdown has expired
    getAcediaState(SESSION_ID)!.countdownStartedAt = new Date(Date.now() - 200);

    // 3. Mock findById for forceReleaseSession
    vi.mocked(sessionModel.findById).mockResolvedValueOnce(makeSession('ACTIVE') as never);
    vi.mocked(sessionModel.transitionState).mockResolvedValueOnce(makeSession('ENDED') as never);

    vi.mocked(db.query).mockResolvedValueOnce({
      rows: [makeSessionRow('ACTIVE', 500, 200)],
    } as never);
    await checkSessions();

    expect(ledger.appendEntry).toHaveBeenCalledWith(
      expect.anything(),
      SESSION_ID,
      'ACEDIA_FORCE_RELEASE',
      expect.any(String),
      expect.any(String),
      expect.anything()
    );
  });
});

describe('Acedia lifecycle — activity cancels countdown', () => {
  it('recordActivity resets DETECTION phase to NORMAL and records ACEDIA_CANCELLED', async () => {
    // Put session into DETECTION
    vi.mocked(db.query).mockResolvedValueOnce({
      rows: [makeSessionRow('ACTIVE', 500, 200)],
    } as never);
    await checkSessions();
    expect(getAcediaState(SESSION_ID)!.phase).toBe('DETECTION');

    // Mock findById for ACEDIA_CANCELLED recording (fire-and-forget)
    vi.mocked(sessionModel.findById).mockResolvedValueOnce(makeSession('ACTIVE') as never);

    // Activity recorded during countdown cancels acedia
    recordActivity(SESSION_ID);

    const state = getAcediaState(SESSION_ID);
    expect(state).toBeDefined();
    expect(state!.phase).toBe('NORMAL');
    expect(state!.countdownStartedAt).toBeNull();

    // Wait for async ACEDIA_CANCELLED recording (fire-and-forget promise)
    // Flush microtask queue: findById resolves → recordAcediaEvent fires → appendEntry called
    await new Promise(resolve => setTimeout(resolve, 0));

    expect(ledger.appendEntry).toHaveBeenCalledWith(
      expect.anything(),
      SESSION_ID,
      'ACEDIA_CANCELLED',
      expect.any(String),
      expect.any(String),
      expect.anything()
    );
  });

  it('recordActivity on NORMAL session updates lastActivity without side effects', () => {
    recordActivity(SESSION_ID);

    const state = getAcediaState(SESSION_ID);
    expect(state).toBeDefined();
    expect(state!.phase).toBe('NORMAL');
    // No ledger entries for NORMAL → NORMAL
    expect(ledger.appendEntry).not.toHaveBeenCalled();
  });
});

describe('Acedia lifecycle — session close clears state', () => {
  it('clearSession removes all acedia state for a dissolved session', async () => {
    vi.mocked(db.query).mockResolvedValueOnce({
      rows: [makeSessionRow('ACTIVE', 500, 200)],
    } as never);
    await checkSessions();

    expect(getAcediaState(SESSION_ID)).toBeDefined();
    clearSession(SESSION_ID);
    expect(getAcediaState(SESSION_ID)).toBeUndefined();
  });
});

describe('Acedia monitor — lifecycle idempotency', () => {
  it('startMonitor is idempotent (double-start does not error)', () => {
    // startMonitor was called in beforeEach; calling again should be a no-op
    startMonitor(SHORT_THRESHOLDS);
    // No error expected
  });

  it('stopMonitor is idempotent (double-stop does not error)', () => {
    stopMonitor();
    stopMonitor(); // second call: no error
  });
});
