/**
 * Integration test for presence lifecycle.
 * Full flow: create → join → message → end → verify all finalized → witness with real presence.
 * Requires PostgreSQL database.
 * @see specs/007-presence-suppression/tasks.md T022
 */

import { describe, it, expect, beforeAll, afterAll } from 'vitest';
import { pool, query, transaction } from '../../../src/lib/db.js';
import * as sessionModel from '../../../src/models/session.js';
import * as presenceTracker from '../../../src/integrity/presence-tracker.js';
import { observeTransition } from '../../../src/integrity/state-observer.js';
import * as ledger from '../../../src/integrity/ledger.js';
import { verify } from '../../../src/integrity/verification-engine.js';
import { buildWitnessArtifact } from '../../../src/integrity/witness-emitter.js';
import { derivePresenceHash } from '../../../src/services/presence.js';
import type { Session } from '../../../src/lib/types.js';

const DB_URL = process.env.DATABASE_URL;
const describeWithDb = DB_URL ? describe : describe.skip;

describeWithDb('Presence Lifecycle Integration', () => {
  let adminId: string;

  beforeAll(async () => {
    const result = await query<{ id: string }>(
      `INSERT INTO admins (email, password_hash)
       VALUES ('test-presence@example.com', 'test-hash')
       ON CONFLICT (email) DO UPDATE SET email = EXCLUDED.email
       RETURNING id`
    );
    adminId = result.rows[0].id;
  });

  afterAll(async () => {
    await query('DELETE FROM presence_records WHERE session_id IN (SELECT id FROM sessions WHERE admin_id = $1)', [adminId]);
    await query('DELETE FROM integrity_ledger WHERE session_id IN (SELECT id FROM sessions WHERE admin_id = $1)', [adminId]);
    await query('DELETE FROM tokens WHERE session_id IN (SELECT id FROM sessions WHERE admin_id = $1)', [adminId]);
    await query('DELETE FROM sessions WHERE admin_id = $1', [adminId]);
    await query("DELETE FROM admins WHERE email = 'test-presence@example.com'");
    await pool.end();
  });

  it('full lifecycle: admin + participant + agent → finalize → I.01 PASS', async () => {
    // 1. Create session
    const session = await sessionModel.create('Presence Test', adminId, {
      topic: 'Presence lifecycle test',
    }, {
      max_participants: 10,
    });

    await transaction(async (client) => {
      await observeTransition(client, session, null, 'CREATED', 'SESSION_CREATED');
      // Admin presence
      await presenceTracker.attestPresence(client, session.id, 'CREATOR', derivePresenceHash(adminId), 'AUTH_EVENT');
    });

    // 2. Start session
    const started = await sessionModel.transitionState(session.id, 'CREATED', 'ACTIVE');
    expect(started).not.toBeNull();
    await transaction(async (client) => {
      await observeTransition(client, started!, 'CREATED', 'ACTIVE', 'SESSION_ACTIVATED');
    });

    // 3. Participant joins
    await presenceTracker.attestPresence(null, session.id, 'PARTICIPANT', 'user1234', 'JOIN_TOKEN');

    // 4. AI processes message
    await presenceTracker.attestPresence(null, session.id, 'AGENT', 'ai-agent', 'MESSAGE_PROCESSING');

    // Verify 3 records exist before finalization
    const recordsBefore = await presenceTracker.getPresenceRecords(session.id);
    expect(recordsBefore).toHaveLength(3);
    expect(recordsBefore.every(r => r.finalized === false)).toBe(true);

    // 5. End session
    const ended = await sessionModel.transitionState(session.id, 'ACTIVE', 'ENDED');
    expect(ended).not.toBeNull();
    await transaction(async (client) => {
      await observeTransition(client, ended!, 'ACTIVE', 'ENDED', 'SESSION_CLOSED');
      await presenceTracker.finalizePresence(client, session.id);
    });

    // 6. Verify all finalized
    const recordsAfter = await presenceTracker.getPresenceRecords(session.id);
    expect(recordsAfter).toHaveLength(3);
    expect(recordsAfter.every(r => r.finalized === true)).toBe(true);
    expect(recordsAfter.every(r => r.finalizedAt !== null)).toBe(true);

    // 7. Verify I.01 PASS with 3 methods
    const entries = await ledger.getEntriesBySession(session.id);
    const result = verify(ended!, entries, undefined, recordsAfter);
    const i01Result = result.protocolResults.find(r => r.protocol === 'I.01');
    expect(i01Result).toBeDefined();
    expect(i01Result!.result).toBe('PASS');

    // 8. Witness with real presence
    const summary = await presenceTracker.getPresenceSummary(session.id);
    const witness = buildWitnessArtifact(result, ended!, summary);
    expect(witness.presence.admin.attested).toBe(true);
    expect(witness.presence.admin.method).toBe('AUTH_EVENT');
    expect(witness.presence.participants).toHaveLength(1);
    expect(witness.presence.agents).toHaveLength(1);
    expect(witness.presence.total_attestation_methods).toBe(3);
    expect(witness.presence.finalized).toBe(true);
  });

  it('admin-only session → I.01 FAIL → session still closes with FAIL witness', async () => {
    // Create and start session with only admin presence
    const session = await sessionModel.create('Admin Only Test', adminId, {
      topic: 'Admin-only test',
    }, {
      max_participants: 5,
    });

    await transaction(async (client) => {
      await observeTransition(client, session, null, 'CREATED', 'SESSION_CREATED');
      await presenceTracker.attestPresence(client, session.id, 'CREATOR', derivePresenceHash(adminId), 'AUTH_EVENT');
    });

    const started = await sessionModel.transitionState(session.id, 'CREATED', 'ACTIVE');
    await transaction(async (client) => {
      await observeTransition(client, started!, 'CREATED', 'ACTIVE', 'SESSION_ACTIVATED');
    });

    const ended = await sessionModel.transitionState(session.id, 'ACTIVE', 'ENDED');
    await transaction(async (client) => {
      await observeTransition(client, ended!, 'ACTIVE', 'ENDED', 'SESSION_CLOSED');
      await presenceTracker.finalizePresence(client, session.id);
    });

    const records = await presenceTracker.getPresenceRecords(session.id);
    expect(records).toHaveLength(1);

    const entries = await ledger.getEntriesBySession(session.id);
    const result = verify(ended!, entries, undefined, records);

    const i01Result = result.protocolResults.find(r => r.protocol === 'I.01');
    expect(i01Result!.result).toBe('FAIL');
    expect(i01Result!.details).toContain('1 attestation method(s)');

    // Witness still emitted with FAIL
    const summary = await presenceTracker.getPresenceSummary(session.id);
    const witness = buildWitnessArtifact(result, ended!, summary);
    expect(witness.pass_fail).toBe('FAIL');
  });

  it('rejects attestation after session is ENDED', async () => {
    const session = await sessionModel.create('Reject Test', adminId, {
      topic: 'Rejection test',
    }, {
      max_participants: 5,
    });

    await transaction(async (client) => {
      await observeTransition(client, session, null, 'CREATED', 'SESSION_CREATED');
    });

    const started = await sessionModel.transitionState(session.id, 'CREATED', 'ACTIVE');
    await transaction(async (client) => {
      await observeTransition(client, started!, 'CREATED', 'ACTIVE', 'SESSION_ACTIVATED');
    });

    const ended = await sessionModel.transitionState(session.id, 'ACTIVE', 'ENDED');
    await transaction(async (client) => {
      await observeTransition(client, ended!, 'ACTIVE', 'ENDED', 'SESSION_CLOSED');
    });

    // Attempt to attest after ENDED — should throw
    await expect(
      presenceTracker.attestPresence(null, session.id, 'PARTICIPANT', 'late-user', 'JOIN_TOKEN')
    ).rejects.toThrow('Cannot attest presence for ended session');
  });
});
