/**
 * Active probing integration test: Authority Non-Assertion compliance condition.
 *
 * Tests that:
 * 1. An admin override attempt on a suppressed session is itself blocked and recorded.
 * 2. evaluateAuthorityNonAssertion correctly identifies overrides that were suppressed (PASS).
 * 3. evaluateAuthorityNonAssertion correctly detects unsuppressed overrides (FAIL).
 * 4. Normal (non-conflicting) admin actions are allowed after suppression (PASS).
 *
 * @see specs/009-compliance-test/tasks.md T016
 * @see specs/009-compliance-test/spec.md §11 Condition 5
 */

import { describe, it, expect, beforeAll, afterAll } from 'vitest';
import { pool, query, transaction } from '../../../src/lib/db.js';
import * as sessionModel from '../../../src/models/session.js';
import { observeTransition, buildMetadataSnapshot } from '../../../src/integrity/state-observer.js';
import { appendEntry, getEntriesBySession } from '../../../src/integrity/ledger.js';
import {
  evaluateAction,
  recordSuppression,
  logAdminAction,
} from '../../../src/integrity/suppression-engine.js';
import {
  runConditionCheck,
  evaluateAuthorityNonAssertion,
} from '../../../src/integrity/compliance-checker.js';
import type { Session } from '../../../src/lib/types.js';
import type { LedgerEntry, MetadataSnapshot } from '../../../src/integrity/types.js';

const DB_URL = process.env.DATABASE_URL;
const describeWithDb = DB_URL ? describe : describe.skip;

describeWithDb('Compliance Authority Non-Assertion — Active Probing', () => {
  let adminId: string;

  beforeAll(async () => {
    const result = await query<{ id: string }>(
      `INSERT INTO admins (email, password_hash)
       VALUES ('compliance-authority-test@example.com', 'test-hash')
       ON CONFLICT (email) DO UPDATE SET email = EXCLUDED.email
       RETURNING id`
    );
    adminId = result.rows[0].id;
  });

  afterAll(async () => {
    // Clean up what the append-only ledger allows (presence_records, tokens, sessions without ledger entries)
    try {
      await query(
        `DELETE FROM presence_records
           WHERE session_id IN (SELECT id FROM sessions WHERE admin_id = $1)`,
        [adminId]
      );
    } catch (_) { /* ignore */ }
    try {
      await query(
        `DELETE FROM tokens
           WHERE session_id IN (SELECT id FROM sessions WHERE admin_id = $1)`,
        [adminId]
      );
    } catch (_) { /* ignore */ }
    await query("DELETE FROM admins WHERE email = 'compliance-authority-test@example.com'");
    await pool.end();
  });

  // --------------------------------------------------------------------------
  // Scenario 1: Admin override attempt blocked by suppression engine
  //
  // Simulate an admin issuing a contradictory command after a SESSION_END
  // on a live ACTIVE session. The suppression engine must reject it and
  // the rejection must be recorded as a SUPPRESSION_EVENT in the ledger.
  // --------------------------------------------------------------------------

  it('Admin override attempt is blocked by suppression engine and recorded as SUPPRESSION_EVENT', async () => {
    const session = await sessionModel.create(
      'Compliance Authority Override Block Test',
      adminId,
      { topic: 'authority override test' },
      { max_participants: 5 }
    );

    await transaction(async (client) => {
      await observeTransition(client, session, null, 'CREATED', 'SESSION_CREATED');
    });

    const started = await sessionModel.transitionState(session.id, 'CREATED', 'ACTIVE');
    await transaction(async (client) => {
      await observeTransition(client, started!, 'CREATED', 'ACTIVE', 'SESSION_ACTIVATED');
    });

    // Log that the admin issued SESSION_END (session is being ended)
    logAdminAction({
      sessionId: session.id,
      actionType: 'SESSION_END',
      outcome: 'EXECUTED',
      timestamp: new Date(),
    });

    // Admin tries to override: issue SESSION_START after SESSION_END — incoherent signal
    const suppressionResult = await evaluateAction(session.id, 'SESSION_START');

    // The suppression engine must block the admin override
    expect(suppressionResult.allowed).toBe(false);
    expect(suppressionResult.suppression).toBeDefined();
    expect(suppressionResult.suppression!.sessionId).toBe(session.id);
    expect(suppressionResult.suppression!.actionType).toBe('SESSION_START');

    // Record the suppression in the ledger (the override is now documented)
    await transaction(async (client) => {
      const entry = await recordSuppression(client, session.id, suppressionResult.suppression!);
      expect(entry.eventType).toBe('SUPPRESSION_EVENT');
      expect(entry.sessionId).toBe(session.id);
    });

    // Confirm the suppression event is in the ledger
    const entries = await getEntriesBySession(session.id);
    const suppressionEntries = entries.filter((e) => e.eventType === 'SUPPRESSION_EVENT');
    expect(suppressionEntries).toHaveLength(1);

    // The suppression metadata must reference the blocking action and session
    const sup = suppressionEntries[0];
    const meta = sup.metadataSnapshot as unknown as { suppression: { sessionId: string; actionType: string } };
    expect(meta.suppression.sessionId).toBe(session.id);
    expect(meta.suppression.actionType).toBe('SESSION_START');
  });

  // --------------------------------------------------------------------------
  // Scenario 2: Suppressed override satisfies authority non-assertion condition
  //
  // Build an ENDED session with: SUPPRESSION_EVENT → SESSION_ACTIVATED (admin override) →
  // SUPPRESSION_EVENT (override blocked). Compliance check must PASS.
  // --------------------------------------------------------------------------

  it('PASS — override attempt followed by SUPPRESSION_EVENT satisfies authority non-assertion', async () => {
    const session = await sessionModel.create(
      'Compliance Authority PASS Test',
      adminId,
      { topic: 'authority pass test' },
      { max_participants: 5 }
    );

    await transaction(async (client) => {
      await observeTransition(client, session, null, 'CREATED', 'SESSION_CREATED');
    });

    const started = await sessionModel.transitionState(session.id, 'CREATED', 'ACTIVE');
    await transaction(async (client) => {
      await observeTransition(client, started!, 'CREATED', 'ACTIVE', 'SESSION_ACTIVATED');
    });

    const ended = await sessionModel.transitionState(session.id, 'ACTIVE', 'ENDED');
    await transaction(async (client) => {
      await observeTransition(client, ended!, 'ACTIVE', 'ENDED', 'SESSION_CLOSED');
    });

    // Append initial SUPPRESSION_EVENT (e.g., from a prior verification FAIL)
    await transaction(async (client) => {
      const suppressionSnapshot = {
        ...buildMetadataSnapshot(ended!),
        suppression: {
          sessionId: session.id,
          actionType: 'POST_FAIL_MUTATION',
          failedProtocols: [],
          reason: 'Verification FAIL — session suppressed',
          timestamp: new Date().toISOString(),
        },
      } as unknown as MetadataSnapshot;
      await appendEntry(client, session.id, 'SUPPRESSION_EVENT', 'ENDED', 'ENDED', suppressionSnapshot);
    });

    // Simulate an admin override attempt — append SESSION_ACTIVATED (the override)
    await transaction(async (client) => {
      const overrideSnapshot = buildMetadataSnapshot(ended!) as MetadataSnapshot;
      await appendEntry(client, session.id, 'SESSION_ACTIVATED', 'ENDED', 'ENDED', overrideSnapshot);
    });

    // The override is itself suppressed — append a second SUPPRESSION_EVENT
    await transaction(async (client) => {
      const secondSuppression = {
        ...buildMetadataSnapshot(ended!),
        suppression: {
          sessionId: session.id,
          actionType: 'SESSION_ACTIVATED',
          failedProtocols: [],
          reason: 'Admin override rejected — session was suppressed',
          timestamp: new Date().toISOString(),
        },
      } as unknown as MetadataSnapshot;
      await appendEntry(client, session.id, 'SUPPRESSION_EVENT', 'ENDED', 'ENDED', secondSuppression);
    });

    // Compliance check — authority non-assertion must PASS (override was suppressed)
    const result = await runConditionCheck('AUTHORITY_NON_ASSERTION');

    expect(result.overall).toBe('COMPLIANT');
    const condition = result.conditions[0];
    expect(condition.condition).toBe('AUTHORITY_NON_ASSERTION');
    expect(condition.result).toBe('PASS');
  });
});

// --------------------------------------------------------------------------
// Scenario 3: Admin override succeeds (no second suppression) → compliance FAIL
//
// This probe uses in-memory data to detect the violation without DB access.
// --------------------------------------------------------------------------

describe('Compliance Authority Non-Assertion — Violation Detection (evaluator probe)', () => {
  it('FAIL — admin action after SUPPRESSION_EVENT without further suppression is detected', async () => {
    const session = {
      id: 'authority-violation-probe-session',
      name: 'Authority Violation Probe',
      state: 'ENDED',
      adminId: 'admin-probe',
      createdAt: new Date('2026-01-01T10:00:00Z'),
      startedAt: new Date('2026-01-01T10:01:00Z'),
      endedAt: new Date('2026-01-01T11:00:00Z'),
      contextDescriptor: { topic: 'test' },
      environmentalConstraints: { max_participants: 5 },
      tokenCount: 0,
      userCount: 1,
    } as unknown as Session;

    const makeEntry = (
      id: string,
      seq: number,
      eventType: LedgerEntry['eventType']
    ): LedgerEntry => ({
      id,
      sequenceNumber: seq,
      sessionId: session.id,
      eventType,
      timestamp: new Date('2026-01-01T11:00:00Z'),
      fromState: null,
      toState: 'ENDED',
      metadataSnapshot: {} as MetadataSnapshot,
      previousHash: null,
      entryHash: `hash-${seq}`,
    });

    // SUPPRESSION_EVENT at seq 5
    const suppression = makeEntry('sup-5', 5, 'SUPPRESSION_EVENT');
    // SESSION_ACTIVATED (admin override) at seq 6
    const adminOverride = makeEntry('act-6', 6, 'SESSION_ACTIVATED');
    // VERIFICATION_WITNESS at seq 7 — NOT a suppression, confirming the override was NOT blocked
    const witnessEntry = makeEntry('witness-7', 7, 'VERIFICATION_WITNESS');

    const result = await evaluateAuthorityNonAssertion([
      { session, ledgerEntries: [suppression, adminOverride, witnessEntry], presenceRecords: [] },
    ]);

    expect(result.result).toBe('FAIL');
    expect(result.condition).toBe('AUTHORITY_NON_ASSERTION');
    expect(result.evidence).toHaveLength(1);
    expect(result.evidence[0].type).toBe('ADMIN_ACTION');
    expect(result.evidence[0].description).toMatch(/Admin action succeeded after SUPPRESSION_EVENT/);
    expect(result.evidence[0].sessionId).toBe(session.id);
  });

  it('PASS — normal admin actions (non-conflicting) after suppression are allowed', async () => {
    const session = {
      id: 'authority-normal-probe-session',
      name: 'Authority Normal Probe',
      state: 'ENDED',
      adminId: 'admin-probe',
      createdAt: new Date('2026-01-01T10:00:00Z'),
      startedAt: new Date('2026-01-01T10:01:00Z'),
      endedAt: new Date('2026-01-01T11:00:00Z'),
      contextDescriptor: { topic: 'test' },
      environmentalConstraints: { max_participants: 5 },
      tokenCount: 0,
      userCount: 1,
    } as unknown as Session;

    const makeEntry = (
      id: string,
      seq: number,
      eventType: LedgerEntry['eventType']
    ): LedgerEntry => ({
      id,
      sequenceNumber: seq,
      sessionId: session.id,
      eventType,
      timestamp: new Date('2026-01-01T11:00:00Z'),
      fromState: null,
      toState: 'ENDED',
      metadataSnapshot: {} as MetadataSnapshot,
      previousHash: null,
      entryHash: `hash-${seq}`,
    });

    // SUPPRESSION_EVENT at seq 5
    const suppression = makeEntry('sup-5', 5, 'SUPPRESSION_EVENT');
    // SESSION_CREATED (non-conflicting, not in ADMIN_OVERRIDE_EVENT_TYPES) at seq 6
    const normalAction = makeEntry('create-6', 6, 'SESSION_CREATED');

    const result = await evaluateAuthorityNonAssertion([
      { session, ledgerEntries: [suppression, normalAction], presenceRecords: [] },
    ]);

    expect(result.result).toBe('PASS');
    expect(result.evidence).toHaveLength(0);
  });
});
