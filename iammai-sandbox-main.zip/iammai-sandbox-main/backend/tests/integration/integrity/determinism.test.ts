/**
 * Determinism test: Same inputs must produce identical verification results.
 * @see specs/006-verification-witness
 */

import { describe, it, expect } from 'vitest';
import { verify } from '../../../src/integrity/verification-engine.js';
import { buildWitnessArtifact } from '../../../src/integrity/witness-emitter.js';
import { computeEntryHash } from '../../../src/integrity/hash.js';
import type { LedgerEntry, MetadataSnapshot, PresenceRecord } from '../../../src/integrity/types.js';
import type { Session } from '../../../src/lib/types.js';

const SESSION_ID = 'aaaaaaaa-bbbb-cccc-dddd-eeeeeeeeeeee';
const ADMIN_ID = '11111111-2222-3333-4444-555555555555';

function makeSnapshot(overrides: Partial<MetadataSnapshot> = {}): MetadataSnapshot {
  return {
    session_id: SESSION_ID,
    session_name: 'Determinism Test',
    state: 'CREATED',
    framework_status: 'OPEN',
    admin_id: ADMIN_ID,
    token_count: 0,
    user_count: 0,
    created_at: '2026-02-14T10:00:00.000Z',
    started_at: null,
    ended_at: null,
    context_descriptor: { topic: 'Determinism test' },
    environmental_constraints: { max_participants: 10 },
    ...overrides,
  };
}

function buildFixedLifecycle(): { session: Session; entries: LedgerEntry[] } {
  const snapshots = [
    makeSnapshot(),
    makeSnapshot({ state: 'ACTIVE', started_at: '2026-02-14T10:01:00.000Z' }),
    makeSnapshot({ state: 'ENDED', framework_status: 'CLOSED', started_at: '2026-02-14T10:01:00.000Z', ended_at: '2026-02-14T10:30:00.000Z' }),
  ];
  const eventTypes = ['SESSION_CREATED', 'SESSION_ACTIVATED', 'SESSION_CLOSED'] as const;
  const timestamps = [
    '2026-02-14T10:00:00.000Z',
    '2026-02-14T10:01:00.000Z',
    '2026-02-14T10:30:00.000Z',
  ];

  const entries: LedgerEntry[] = [];
  let previousHash: string | null = null;

  for (let i = 0; i < 3; i++) {
    const seq = i + 1;
    const hash = computeEntryHash(previousHash, seq, SESSION_ID, eventTypes[i], timestamps[i]!, snapshots[i]!);
    entries.push({
      id: `entry-${seq}`,
      sequenceNumber: seq,
      sessionId: SESSION_ID,
      eventType: eventTypes[i],
      timestamp: new Date(timestamps[i]!),
      fromState: i === 0 ? null : (['CREATED', 'ACTIVE'] as const)[i - 1],
      toState: snapshots[i]!.state,
      metadataSnapshot: snapshots[i]!,
      previousHash,
      entryHash: hash,
    });
    previousHash = hash;
  }

  const session: Session = {
    id: SESSION_ID,
    name: 'Determinism Test',
    state: 'ENDED',
    createdAt: new Date('2026-02-14T10:00:00.000Z'),
    startedAt: new Date('2026-02-14T10:01:00.000Z'),
    endedAt: new Date('2026-02-14T10:30:00.000Z'),
    tokenCount: 1,
    userCount: 1,
    adminId: ADMIN_ID,
    contextDescriptor: { topic: 'Determinism test' },
    environmentalConstraints: { max_participants: 10 },
  };

  return { session, entries };
}

function makePresenceRecords(): PresenceRecord[] {
  return [
    {
      id: 'presence-1',
      sessionId: SESSION_ID,
      role: 'CREATOR',
      presenceHash: 'hash-admin',
      attestationMethod: 'AUTH_EVENT',
      attested: true,
      finalized: true,
      createdAt: new Date('2026-02-14T10:00:00.000Z'),
      finalizedAt: new Date('2026-02-14T10:30:00.000Z'),
    },
    {
      id: 'presence-2',
      sessionId: SESSION_ID,
      role: 'PARTICIPANT',
      presenceHash: 'hash-participant',
      attestationMethod: 'JOIN_TOKEN',
      attested: true,
      finalized: true,
      createdAt: new Date('2026-02-14T10:02:00.000Z'),
      finalizedAt: new Date('2026-02-14T10:30:00.000Z'),
    },
  ];
}

describe('Verification determinism', () => {
  it('produces identical protocol results for identical inputs', () => {
    const { session, entries } = buildFixedLifecycle();
    const presenceRecords = makePresenceRecords();

    const result1 = verify(session, entries, undefined, presenceRecords);
    const result2 = verify(session, entries, undefined, presenceRecords);

    expect(result1.pass).toBe(result2.pass);
    expect(result1.protocolResults).toHaveLength(result2.protocolResults.length);

    for (let i = 0; i < result1.protocolResults.length; i++) {
      expect(result1.protocolResults[i]!.protocol).toBe(result2.protocolResults[i]!.protocol);
      expect(result1.protocolResults[i]!.result).toBe(result2.protocolResults[i]!.result);
      expect(result1.protocolResults[i]!.details).toBe(result2.protocolResults[i]!.details);
    }
  });

  it('produces identical witness artifacts (except event_id and timestamp_utc)', () => {
    const { session, entries } = buildFixedLifecycle();
    const presenceRecords = makePresenceRecords();

    const result1 = verify(session, entries, undefined, presenceRecords);
    const result2 = verify(session, entries, undefined, presenceRecords);

    const artifact1 = buildWitnessArtifact(result1, session);
    const artifact2 = buildWitnessArtifact(result2, session);

    // These should be identical
    expect(artifact1.artifact_type).toBe(artifact2.artifact_type);
    expect(artifact1.artifact_version).toBe(artifact2.artifact_version);
    expect(artifact1.system).toBe(artifact2.system);
    expect(artifact1.t_open).toBe(artifact2.t_open);
    expect(artifact1.t_close).toBe(artifact2.t_close);
    expect(artifact1.pass_fail).toBe(artifact2.pass_fail);
    expect(artifact1.protocols_evaluated).toEqual(artifact2.protocols_evaluated);
    expect(artifact1.protocol_results).toEqual(artifact2.protocol_results);
    expect(artifact1.suppression_triggered).toBe(artifact2.suppression_triggered);
    expect(artifact1.protocol_versions).toEqual(artifact2.protocol_versions);
    expect(artifact1.metadata).toEqual(artifact2.metadata);
    expect(artifact1.presence).toEqual(artifact2.presence);

    // event_id is unique per invocation (UUID)
    expect(artifact1.event_id).not.toBe(artifact2.event_id);
  });

  it('produces consistent results across multiple runs', () => {
    const { session, entries } = buildFixedLifecycle();
    const presenceRecords = makePresenceRecords();
    const results: boolean[] = [];

    for (let i = 0; i < 10; i++) {
      results.push(verify(session, entries, undefined, presenceRecords).pass);
    }

    expect(new Set(results).size).toBe(1);
  });

  it('produces different results for different inputs', () => {
    const { session, entries } = buildFixedLifecycle();
    const presenceRecords = makePresenceRecords();

    const validResult = verify(session, entries, undefined, presenceRecords);

    // Tamper with entries
    const tamperedEntries = [...entries];
    tamperedEntries[1] = {
      ...tamperedEntries[1]!,
      entryHash: 'aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa',
    };
    const invalidResult = verify(session, tamperedEntries);

    expect(validResult.pass).toBe(true);
    expect(invalidResult.pass).toBe(false);
  });
});
