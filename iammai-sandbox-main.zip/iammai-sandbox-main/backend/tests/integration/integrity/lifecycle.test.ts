/**
 * Integration test for full session lifecycle with ledger verification.
 * Requires PostgreSQL database.
 * @see specs/005-structural-foundation/spec.md US1
 */

import { describe, it, expect, beforeAll, afterAll } from 'vitest';
import { pool, query, transaction } from '../../../src/lib/db.js';
import * as sessionModel from '../../../src/models/session.js';
import { observeTransition, buildMetadataSnapshot } from '../../../src/integrity/state-observer.js';
import * as ledger from '../../../src/integrity/ledger.js';
import { validateHashChain } from '../../../src/integrity/hash.js';
import type { Session } from '../../../src/lib/types.js';

// Skip if no database available
const DB_URL = process.env.DATABASE_URL;
const describeWithDb = DB_URL ? describe : describe.skip;

describeWithDb('Session Lifecycle with Integrity Ledger', () => {
  let adminId: string;

  beforeAll(async () => {
    // Ensure a test admin exists
    const result = await query<{ id: string }>(
      `INSERT INTO admins (email, password_hash)
       VALUES ('test-integrity@example.com', 'test-hash')
       ON CONFLICT (email) DO UPDATE SET email = EXCLUDED.email
       RETURNING id`
    );
    adminId = result.rows[0].id;
  });

  afterAll(async () => {
    // Clean up test data
    await query('DELETE FROM integrity_ledger WHERE session_id IN (SELECT id FROM sessions WHERE admin_id = $1)', [adminId]);
    await query('DELETE FROM tokens WHERE session_id IN (SELECT id FROM sessions WHERE admin_id = $1)', [adminId]);
    await query('DELETE FROM sessions WHERE admin_id = $1', [adminId]);
    await query("DELETE FROM admins WHERE email = 'test-integrity@example.com'");
    await pool.end();
  });

  it('records 3 ledger entries for a full create → start → end lifecycle', async () => {
    // Create session
    const session = await sessionModel.create('Lifecycle Test', adminId, {
      topic: 'Integration test',
    }, {
      max_participants: 5,
    });

    // Record creation in ledger
    await transaction(async (client) => {
      await observeTransition(client, session, null, 'CREATED', 'SESSION_CREATED');
    });

    // Start session
    const started = await sessionModel.transitionState(session.id, 'CREATED', 'ACTIVE');
    expect(started).not.toBeNull();

    await transaction(async (client) => {
      await observeTransition(client, started!, 'CREATED', 'ACTIVE', 'SESSION_ACTIVATED');
    });

    // End session
    const ended = await sessionModel.transitionState(session.id, 'ACTIVE', 'ENDED');
    expect(ended).not.toBeNull();

    await transaction(async (client) => {
      await observeTransition(client, ended!, 'ACTIVE', 'ENDED', 'SESSION_CLOSED');
    });

    // Verify ledger entries
    const entries = await ledger.getEntriesBySession(session.id);
    expect(entries).toHaveLength(3);
    expect(entries[0].eventType).toBe('SESSION_CREATED');
    expect(entries[1].eventType).toBe('SESSION_ACTIVATED');
    expect(entries[2].eventType).toBe('SESSION_CLOSED');

    // Verify hash chain
    const validation = validateHashChain(entries);
    expect(validation.valid).toBe(true);
    expect(validation.totalEntries).toBe(3);

    // Verify no message content in any snapshot
    for (const entry of entries) {
      const snapshotStr = JSON.stringify(entry.metadataSnapshot);
      expect(snapshotStr).not.toContain('content');
      expect(snapshotStr).not.toContain('message');
      expect(snapshotStr).not.toContain('presenceHash');
      expect(snapshotStr).not.toContain('tokenHash');
    }
  });

  it('records TRANSITION_REJECTED for invalid backward transition', async () => {
    const session = await sessionModel.create('Rejection Test', adminId, {
      topic: 'Rejection test',
    }, {
      max_participants: 5,
    });

    // Create and start
    await transaction(async (client) => {
      await observeTransition(client, session, null, 'CREATED', 'SESSION_CREATED');
    });

    const started = await sessionModel.transitionState(session.id, 'CREATED', 'ACTIVE');
    await transaction(async (client) => {
      await observeTransition(client, started!, 'CREATED', 'ACTIVE', 'SESSION_ACTIVATED');
    });

    // End the session
    const ended = await sessionModel.transitionState(session.id, 'ACTIVE', 'ENDED');
    await transaction(async (client) => {
      await observeTransition(client, ended!, 'ACTIVE', 'ENDED', 'SESSION_CLOSED');
    });

    // Attempt backward transition — should fail
    const rejected = await sessionModel.transitionState(session.id, 'ENDED', 'ACTIVE');
    expect(rejected).toBeNull();

    // Record the rejection in ledger
    await transaction(async (client) => {
      await observeTransition(client, ended!, 'ENDED', 'ACTIVE', 'TRANSITION_REJECTED');
    });

    const entries = await ledger.getEntriesBySession(session.id);
    expect(entries).toHaveLength(4);
    expect(entries[3].eventType).toBe('TRANSITION_REJECTED');
    expect(entries[3].fromState).toBe('ENDED');
    expect(entries[3].toState).toBe('ACTIVE');
  });

  it('full hash chain validates across all session entries', async () => {
    // Validate the entire ledger (all sessions)
    const result = await ledger.validateChain();
    expect(result.valid).toBe(true);
    expect(result.totalEntries).toBeGreaterThan(0);
  });
});
