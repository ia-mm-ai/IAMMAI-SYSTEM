/**
 * Integration tests for ledger immutability.
 * Verifies that PostgreSQL triggers prevent UPDATE and DELETE on integrity_ledger.
 * Requires a running database — skips if DATABASE_URL is not set.
 * @see specs/005-structural-foundation/spec.md US2
 */

import { describe, it, expect, beforeAll, afterAll } from 'vitest';
import pg from 'pg';

const DATABASE_URL = process.env.DATABASE_URL;

// Skip entire suite if no database available
const describeWithDb = DATABASE_URL ? describe : describe.skip;

describeWithDb('Ledger immutability (PostgreSQL triggers)', () => {
  let pool: pg.Pool;
  let testEntryId: string;

  beforeAll(async () => {
    pool = new pg.Pool({ connectionString: DATABASE_URL });

    // Create a test session first (integrity_ledger has FK to sessions)
    const sessionResult = await pool.query(
      `INSERT INTO sessions (name, state, admin_id, context_descriptor, environmental_constraints)
       VALUES ('Immutability Test', 'CREATED', (SELECT id FROM admins LIMIT 1),
               '{"topic": "immutability test"}'::jsonb,
               '{"max_participants": 5}'::jsonb)
       RETURNING id`
    );
    const sessionId = sessionResult.rows[0].id;

    // Insert a test ledger entry directly
    const entryResult = await pool.query(
      `INSERT INTO integrity_ledger
         (sequence_number, session_id, event_type, timestamp, from_state, to_state,
          metadata_snapshot, previous_hash, entry_hash)
       VALUES (
         nextval('integrity_ledger_sequence_number_seq'),
         $1, 'SESSION_CREATED', NOW(), NULL, 'CREATED',
         '{"session_id":"test","session_name":"test","state":"CREATED","framework_status":"OPEN","admin_id":"test","token_count":0,"user_count":0,"created_at":"2026-01-01T00:00:00.000Z","started_at":null,"ended_at":null,"context_descriptor":{"topic":"test"},"environmental_constraints":{"max_participants":5}}'::jsonb,
         NULL,
         'abcdef1234567890abcdef1234567890abcdef1234567890abcdef1234567890'
       )
       RETURNING id`,
      [sessionId]
    );
    testEntryId = entryResult.rows[0].id;
  });

  afterAll(async () => {
    if (pool) {
      await pool.end();
    }
  });

  it('rejects UPDATE on integrity_ledger with trigger exception', async () => {
    await expect(
      pool.query(
        `UPDATE integrity_ledger SET to_state = 'TAMPERED' WHERE id = $1`,
        [testEntryId]
      )
    ).rejects.toThrow('Ledger entries cannot be updated');
  });

  it('rejects DELETE on integrity_ledger with trigger exception', async () => {
    await expect(
      pool.query(
        `DELETE FROM integrity_ledger WHERE id = $1`,
        [testEntryId]
      )
    ).rejects.toThrow('Ledger entries cannot be deleted');
  });

  it('allows INSERT (append-only is permitted)', async () => {
    // This should succeed — inserts are the only allowed mutation
    const result = await pool.query(
      `INSERT INTO integrity_ledger
         (sequence_number, session_id, event_type, timestamp, from_state, to_state,
          metadata_snapshot, previous_hash, entry_hash)
       SELECT
         nextval('integrity_ledger_sequence_number_seq'),
         session_id, 'SESSION_ACTIVATED', NOW(), 'CREATED', 'ACTIVE',
         metadata_snapshot,
         entry_hash,
         'fedcba0987654321fedcba0987654321fedcba0987654321fedcba0987654321'
       FROM integrity_ledger WHERE id = $1
       RETURNING id`,
      [testEntryId]
    );
    expect(result.rows).toHaveLength(1);
  });
});
