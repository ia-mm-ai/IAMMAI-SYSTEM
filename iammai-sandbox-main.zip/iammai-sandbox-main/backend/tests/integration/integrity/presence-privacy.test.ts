/**
 * Privacy validation tests for presence records.
 * Verifies no personal identity data in presence records or witness artifacts.
 * @see specs/007-presence-suppression/tasks.md T038
 * @see FR-016: Privacy boundary enforcement
 */

import { describe, it, expect, beforeAll, afterAll } from 'vitest';
import { pool, query, transaction } from '../../../src/lib/db.js';
import * as sessionModel from '../../../src/models/session.js';
import * as presenceTracker from '../../../src/integrity/presence-tracker.js';
import { observeTransition } from '../../../src/integrity/state-observer.js';
import { verify } from '../../../src/integrity/verification-engine.js';
import * as ledger from '../../../src/integrity/ledger.js';
import { buildWitnessArtifact } from '../../../src/integrity/witness-emitter.js';
import { derivePresenceHash, isValidPresenceHash } from '../../../src/services/presence.js';
import type { Session } from '../../../src/lib/types.js';

const DB_URL = process.env.DATABASE_URL;
const describeWithDb = DB_URL ? describe : describe.skip;

describeWithDb('Presence Privacy Validation', () => {
  let adminId: string;

  beforeAll(async () => {
    const result = await query<{ id: string }>(
      `INSERT INTO admins (email, password_hash)
       VALUES ('test-privacy-presence@example.com', 'test-hash')
       ON CONFLICT (email) DO UPDATE SET email = EXCLUDED.email
       RETURNING id`
    );
    adminId = result.rows[0].id;
  });

  afterAll(async () => {
    await query('DELETE FROM presence_records WHERE session_id IN (SELECT id FROM sessions WHERE admin_id = $1)', [adminId]);
    await query('DELETE FROM integrity_ledger WHERE session_id IN (SELECT id FROM sessions WHERE admin_id = $1)', [adminId]);
    await query('DELETE FROM tokens WHERE session_id IN (SELECT id FROM sessions WHERE admin_id = $1)', [adminId]);
    await query('DELETE FROM sessions WHERE admin_id = $1', [adminId]);
    await query("DELETE FROM admins WHERE email = 'test-privacy-presence@example.com'");
    await pool.end();
  });

  it('presence_records contain no personal identity data', async () => {
    const session = await sessionModel.create('Privacy Test', adminId, {
      topic: 'Privacy test',
    }, {
      max_participants: 5,
    });

    await transaction(async (client) => {
      await observeTransition(client, session, null, 'CREATED', 'SESSION_CREATED');
      await presenceTracker.attestPresence(client, session.id, 'CREATOR', derivePresenceHash(adminId), 'AUTH_EVENT');
    });

    const records = await presenceTracker.getPresenceRecords(session.id);
    expect(records).toHaveLength(1);

    const record = records[0]!;
    const json = JSON.stringify(record);

    // No names, emails, IPs
    expect(json).not.toContain('test-privacy-presence@example.com');
    expect(json).not.toContain('password');
    expect(json).not.toContain('127.0.0.1');
    expect(json).not.toContain('localhost');

    // Presence hash is 8-char hex
    expect(record.presenceHash).toHaveLength(8);
    expect(record.presenceHash).toMatch(/^[0-9a-f]{8}$/);
  });

  it('admin hash is derived from admin_id not from credentials', () => {
    const hash = derivePresenceHash(adminId);

    // Hash is valid 8-char hex
    expect(isValidPresenceHash(hash)).toBe(true);

    // Hash is NOT the admin_id itself
    expect(hash).not.toBe(adminId);

    // Hash is NOT an email or password
    expect(hash).not.toContain('@');
    expect(hash).not.toContain('test');
  });

  it('witness artifact contains only anonymous metadata', async () => {
    const session = await sessionModel.create('Witness Privacy Test', adminId, {
      topic: 'Witness privacy test',
    }, {
      max_participants: 5,
    });

    await transaction(async (client) => {
      await observeTransition(client, session, null, 'CREATED', 'SESSION_CREATED');
      await presenceTracker.attestPresence(client, session.id, 'CREATOR', derivePresenceHash(adminId), 'AUTH_EVENT');
    });

    const started = await sessionModel.transitionState(session.id, 'CREATED', 'ACTIVE');
    await transaction(async (client) => {
      await observeTransition(client, started!, 'CREATED', 'ACTIVE', 'SESSION_ACTIVATED');
    });

    await presenceTracker.attestPresence(null, session.id, 'PARTICIPANT', 'abcd1234', 'JOIN_TOKEN');

    const ended = await sessionModel.transitionState(session.id, 'ACTIVE', 'ENDED');
    await transaction(async (client) => {
      await observeTransition(client, ended!, 'ACTIVE', 'ENDED', 'SESSION_CLOSED');
      await presenceTracker.finalizePresence(client, session.id);
    });

    const records = await presenceTracker.getPresenceRecords(session.id);
    const entries = await ledger.getEntriesBySession(session.id);
    const result = verify(ended!, entries, undefined, records);

    const summary = await presenceTracker.getPresenceSummary(session.id);
    const witness = buildWitnessArtifact(result, ended!, summary);

    const witnessJson = JSON.stringify(witness);

    // No personal data in witness
    expect(witnessJson).not.toContain('test-privacy-presence@example.com');
    expect(witnessJson).not.toContain('password');
    expect(witnessJson).not.toContain('token');

    // Presence hashes are anonymous
    expect(witness.presence.admin.hash).toMatch(/^[0-9a-f]{8}$/);
    for (const p of witness.presence.participants) {
      expect(p.hash).toMatch(/^[0-9a-f]{8}$/);
    }
  });
});
