/**
 * Integration test for admin session lifecycle
 * @see specs/001-ephemeral-kernel/tasks.md#T037
 * Tests the complete flow: create -> start -> end
 */

import { describe, it, expect, beforeAll, afterAll } from 'vitest';
import request from 'supertest';
import type { Express } from 'express';
import { createApp } from '../../src/api/app.js';
import { closePool, query } from '../../src/lib/db.js';
import { kernelManager } from '../../src/kernel/manager.js';
import bcrypt from 'bcrypt';

describe('Admin Session Lifecycle Integration', () => {
  let app: Express;
  let authCookie: string;
  const testEmail = 'lifecycle-test@example.com';
  const testPassword = 'testPassword123!';
  let testAdminId: string;

  beforeAll(async () => {
    app = createApp();

    // Create test admin
    const passwordHash = await bcrypt.hash(testPassword, 10);
    const result = await query(
      `INSERT INTO admins (email, password_hash)
       VALUES ($1, $2)
       ON CONFLICT (email) DO UPDATE SET password_hash = $2
       RETURNING id`,
      [testEmail, passwordHash]
    );
    testAdminId = result.rows[0].id;

    // Login to get auth cookie
    const loginResponse = await request(app)
      .post('/api/v1/auth/login')
      .send({ email: testEmail, password: testPassword });

    const cookies = loginResponse.headers['set-cookie'];
    authCookie = Array.isArray(cookies) ? cookies[0] : cookies;
  });

  afterAll(async () => {
    await query('DELETE FROM admins WHERE id = $1', [testAdminId]);
    await closePool();
  });

  it('should complete full session lifecycle: create -> start -> end', async () => {
    // ========================================================================
    // Step 1: Create session
    // ========================================================================
    const createResponse = await request(app)
      .post('/api/v1/admin/sessions')
      .set('Cookie', authCookie)
      .send({ name: 'Lifecycle Test Session' })
      .expect(201);

    const sessionId = createResponse.body.id;

    expect(createResponse.body.state).toBe('CREATED');
    expect(createResponse.body.startedAt).toBeNull();
    expect(createResponse.body.endedAt).toBeNull();

    // Verify kernel does NOT exist yet
    expect(kernelManager.hasKernel(sessionId)).toBe(false);

    // ========================================================================
    // Step 2: Get session details (should show NOT_CREATED kernel status)
    // ========================================================================
    const detailResponse1 = await request(app)
      .get(`/api/v1/admin/sessions/${sessionId}`)
      .set('Cookie', authCookie)
      .expect(200);

    expect(detailResponse1.body.kernelStatus).toBe('NOT_CREATED');
    expect(detailResponse1.body.lifecycle).toHaveLength(1);
    expect(detailResponse1.body.lifecycle[0].event).toBe('CREATED');

    // ========================================================================
    // Step 3: Start session (CREATED -> ACTIVE)
    // ========================================================================
    const startResponse = await request(app)
      .post(`/api/v1/admin/sessions/${sessionId}/start`)
      .set('Cookie', authCookie)
      .expect(200);

    expect(startResponse.body.state).toBe('ACTIVE');
    expect(startResponse.body.startedAt).not.toBeNull();
    expect(startResponse.body.endedAt).toBeNull();

    // Verify kernel was created
    expect(kernelManager.hasKernel(sessionId)).toBe(true);

    // ========================================================================
    // Step 4: Get session details (should show ACTIVE kernel status)
    // ========================================================================
    const detailResponse2 = await request(app)
      .get(`/api/v1/admin/sessions/${sessionId}`)
      .set('Cookie', authCookie)
      .expect(200);

    expect(detailResponse2.body.kernelStatus).toBe('ACTIVE');
    expect(detailResponse2.body.lifecycle).toHaveLength(2);
    expect(detailResponse2.body.lifecycle[1].event).toBe('STARTED');

    // ========================================================================
    // Step 5: Simulate user activity (add conversations and messages)
    // ========================================================================
    const kernel = kernelManager.getKernel(sessionId);
    expect(kernel).toBeDefined();

    // Create conversations for multiple users
    kernelManager.getOrCreateConversation(sessionId, 'user1-hash', 'user1-presence');
    kernelManager.getOrCreateConversation(sessionId, 'user2-hash', 'user2-presence');

    // Add messages
    kernelManager.addMessage(sessionId, 'user1-hash', 'user', 'Hello AI!');
    kernelManager.addMessage(sessionId, 'user1-hash', 'assistant', 'Hello! How can I help?');
    kernelManager.addMessage(sessionId, 'user2-hash', 'user', 'Question from user 2');

    // Verify conversations exist
    expect(kernelManager.getTotalConversationCount()).toBeGreaterThanOrEqual(2);

    // ========================================================================
    // Step 6: End session (ACTIVE -> ENDED)
    // ========================================================================
    const endResponse = await request(app)
      .post(`/api/v1/admin/sessions/${sessionId}/end`)
      .set('Cookie', authCookie)
      .expect(200);

    expect(endResponse.body.state).toBe('ENDED');
    expect(endResponse.body.endedAt).not.toBeNull();

    // Verify kernel was dissolved (CRITICAL: all conversations destroyed)
    expect(kernelManager.hasKernel(sessionId)).toBe(false);
    expect(kernelManager.getConversation(sessionId, 'user1-hash')).toBeUndefined();
    expect(kernelManager.getConversation(sessionId, 'user2-hash')).toBeUndefined();
    expect(kernelManager.getConversationHistory(sessionId, 'user1-hash')).toEqual([]);

    // ========================================================================
    // Step 7: Get final session details (should show DISSOLVED kernel status)
    // ========================================================================
    const detailResponse3 = await request(app)
      .get(`/api/v1/admin/sessions/${sessionId}`)
      .set('Cookie', authCookie)
      .expect(200);

    expect(detailResponse3.body.kernelStatus).toBe('DISSOLVED');
    expect(detailResponse3.body.lifecycle).toHaveLength(3);
    expect(detailResponse3.body.lifecycle[2].event).toBe('ENDED');

    // ========================================================================
    // Step 8: Verify session appears in list with ENDED state
    // ========================================================================
    const listResponse = await request(app)
      .get('/api/v1/admin/sessions')
      .query({ state: 'ENDED' })
      .set('Cookie', authCookie)
      .expect(200);

    const foundSession = listResponse.body.sessions.find(
      (s: { id: string }) => s.id === sessionId
    );
    expect(foundSession).toBeDefined();
    expect(foundSession.state).toBe('ENDED');

    // ========================================================================
    // Cleanup
    // ========================================================================
    await query('DELETE FROM sessions WHERE id = $1', [sessionId]);
  });

  it('should prevent invalid state transitions', async () => {
    // Create a session
    const createResponse = await request(app)
      .post('/api/v1/admin/sessions')
      .set('Cookie', authCookie)
      .send({ name: 'Invalid Transition Test' })
      .expect(201);

    const sessionId = createResponse.body.id;

    try {
      // Try to end a CREATED session (should fail)
      await request(app)
        .post(`/api/v1/admin/sessions/${sessionId}/end`)
        .set('Cookie', authCookie)
        .expect(400);

      // Start the session
      await request(app)
        .post(`/api/v1/admin/sessions/${sessionId}/start`)
        .set('Cookie', authCookie)
        .expect(200);

      // Try to start again (should fail)
      await request(app)
        .post(`/api/v1/admin/sessions/${sessionId}/start`)
        .set('Cookie', authCookie)
        .expect(400);

      // End the session
      await request(app)
        .post(`/api/v1/admin/sessions/${sessionId}/end`)
        .set('Cookie', authCookie)
        .expect(200);

      // Try to start an ENDED session (should fail)
      await request(app)
        .post(`/api/v1/admin/sessions/${sessionId}/start`)
        .set('Cookie', authCookie)
        .expect(400);

      // Try to end again (should fail)
      await request(app)
        .post(`/api/v1/admin/sessions/${sessionId}/end`)
        .set('Cookie', authCookie)
        .expect(400);
    } finally {
      // Cleanup
      kernelManager.dissolveKernel(sessionId);
      await query('DELETE FROM sessions WHERE id = $1', [sessionId]);
    }
  });

  it('should track token and user counts', async () => {
    // Create and start a session
    const createResponse = await request(app)
      .post('/api/v1/admin/sessions')
      .set('Cookie', authCookie)
      .send({ name: 'Count Test Session' })
      .expect(201);

    const sessionId = createResponse.body.id;

    try {
      // Start the session
      await request(app)
        .post(`/api/v1/admin/sessions/${sessionId}/start`)
        .set('Cookie', authCookie)
        .expect(200);

      // Simulate token claims by incrementing count directly
      await query(
        'UPDATE sessions SET token_count = token_count + 3 WHERE id = $1',
        [sessionId]
      );

      // Simulate user joins
      await query(
        'UPDATE sessions SET user_count = user_count + 2 WHERE id = $1',
        [sessionId]
      );

      // Verify counts in session details
      const detailResponse = await request(app)
        .get(`/api/v1/admin/sessions/${sessionId}`)
        .set('Cookie', authCookie)
        .expect(200);

      expect(detailResponse.body.tokenCount).toBe(3);
      expect(detailResponse.body.userCount).toBe(2);
    } finally {
      // Cleanup
      kernelManager.dissolveKernel(sessionId);
      await query('DELETE FROM sessions WHERE id = $1', [sessionId]);
    }
  });
});
