/**
 * Integration test for token flow (claim -> join)
 * @see specs/001-ephemeral-kernel/tasks.md#T054
 * Tests the complete user flow: browse -> claim -> wait -> join
 */

import { describe, it, expect, beforeAll, afterAll } from 'vitest';
import request from 'supertest';
import type { Express } from 'express';
import { createApp } from '../../src/api/app.js';
import { query } from '../../src/lib/db.js';
import { kernelManager } from '../../src/kernel/manager.js';
import bcrypt from 'bcrypt';

describe('Token Flow Integration', () => {
  let app: Express;
  let authCookie: string;
  const testEmail = 'token-flow-test@example.com';
  const testPassword = 'testPassword123!';
  let testAdminId: string;

  beforeAll(async () => {
    app = createApp();

    // Create test admin for session management
    const passwordHash = await bcrypt.hash(testPassword, 10);
    const result = await query(
      `INSERT INTO admins (email, password_hash)
       VALUES ($1, $2)
       ON CONFLICT (email) DO UPDATE SET password_hash = $2
       RETURNING id`,
      [testEmail, passwordHash]
    );
    testAdminId = result.rows[0].id;

    // Login to get auth cookie
    const loginResponse = await request(app)
      .post('/api/v1/auth/login')
      .send({ email: testEmail, password: testPassword });

    const cookies = loginResponse.headers['set-cookie'];
    authCookie = Array.isArray(cookies) ? cookies[0] : cookies;
  });

  afterAll(async () => {
    await query('DELETE FROM admins WHERE id = $1', [testAdminId]);
  });

  it('should complete full token flow: browse -> claim -> join', async () => {
    // ========================================================================
    // Step 1: Admin creates a session
    // ========================================================================
    const createResponse = await request(app)
      .post('/api/v1/admin/sessions')
      .set('Cookie', authCookie)
      .send({ name: 'Token Flow Test Session' })
      .expect(201);

    const sessionId = createResponse.body.id;

    try {
      // ========================================================================
      // Step 2: User browses public sessions (sees CREATED session)
      // ========================================================================
      const browseResponse1 = await request(app)
        .get('/api/v1/sessions')
        .expect(200);

      const foundCreated = browseResponse1.body.sessions.find(
        (s: { id: string }) => s.id === sessionId
      );
      expect(foundCreated).toBeDefined();
      expect(foundCreated.state).toBe('CREATED');
      expect(foundCreated.canClaim).toBe(true);
      expect(foundCreated.canJoin).toBe(false);

      // ========================================================================
      // Step 3: User claims a token for the session
      // ========================================================================
      const claimResponse = await request(app)
        .post(`/api/v1/sessions/${sessionId}/claim`)
        .expect(201);

      const token = claimResponse.body.token;
      expect(token).toBeDefined();
      expect(token.length).toBeGreaterThanOrEqual(40);

      // Verify session token count increased
      const detailResponse1 = await request(app)
        .get(`/api/v1/admin/sessions/${sessionId}`)
        .set('Cookie', authCookie)
        .expect(200);
      expect(detailResponse1.body.tokenCount).toBe(1);

      // ========================================================================
      // Step 4: User tries to join before session starts (should fail)
      // ========================================================================
      await request(app)
        .post(`/api/v1/sessions/${sessionId}/join`)
        .send({ token })
        .expect(400);

      // ========================================================================
      // Step 5: Admin starts the session
      // ========================================================================
      await request(app)
        .post(`/api/v1/admin/sessions/${sessionId}/start`)
        .set('Cookie', authCookie)
        .expect(200);

      // ========================================================================
      // Step 6: User sees session is now ACTIVE in browse
      // ========================================================================
      const browseResponse2 = await request(app)
        .get('/api/v1/sessions')
        .expect(200);

      const foundActive = browseResponse2.body.sessions.find(
        (s: { id: string }) => s.id === sessionId
      );
      expect(foundActive).toBeDefined();
      expect(foundActive.state).toBe('ACTIVE');
      expect(foundActive.canClaim).toBe(false);
      expect(foundActive.canJoin).toBe(true);

      // ========================================================================
      // Step 7: User joins the session with claimed token
      // ========================================================================
      const joinResponse = await request(app)
        .post(`/api/v1/sessions/${sessionId}/join`)
        .send({ token })
        .expect(200);

      expect(joinResponse.body.presenceHash).toMatch(/^[0-9a-f]{8}$/);
      expect(joinResponse.body.kernelStatus).toBe('ACTIVE');
      expect(joinResponse.body.websocketUrl).toBeDefined();

      // Verify session user count increased
      const detailResponse2 = await request(app)
        .get(`/api/v1/admin/sessions/${sessionId}`)
        .set('Cookie', authCookie)
        .expect(200);
      expect(detailResponse2.body.userCount).toBe(1);

      // ========================================================================
      // Step 8: User can rejoin with same token (reconnection scenario)
      // ========================================================================
      const rejoinResponse = await request(app)
        .post(`/api/v1/sessions/${sessionId}/join`)
        .send({ token })
        .expect(200);

      // Same presence hash
      expect(rejoinResponse.body.presenceHash).toBe(joinResponse.body.presenceHash);

      // User count should NOT increase on rejoin
      const detailResponse3 = await request(app)
        .get(`/api/v1/admin/sessions/${sessionId}`)
        .set('Cookie', authCookie)
        .expect(200);
      expect(detailResponse3.body.userCount).toBe(1);

      // ========================================================================
      // Step 9: Admin ends session
      // ========================================================================
      await request(app)
        .post(`/api/v1/admin/sessions/${sessionId}/end`)
        .set('Cookie', authCookie)
        .expect(200);

      // ========================================================================
      // Step 10: User can no longer see session in browse (ENDED is hidden)
      // ========================================================================
      const browseResponse3 = await request(app)
        .get('/api/v1/sessions')
        .expect(200);

      const foundEnded = browseResponse3.body.sessions.find(
        (s: { id: string }) => s.id === sessionId
      );
      expect(foundEnded).toBeUndefined();

      // ========================================================================
      // Step 11: User cannot join ended session
      // ========================================================================
      await request(app)
        .post(`/api/v1/sessions/${sessionId}/join`)
        .send({ token })
        .expect(400);

    } finally {
      // Cleanup
      kernelManager.dissolveKernel(sessionId);
      await query('DELETE FROM tokens WHERE session_id = $1', [sessionId]);
      await query('DELETE FROM sessions WHERE id = $1', [sessionId]);
    }
  });

  it('should support multiple users claiming and joining', async () => {
    // Create and start session
    const createResponse = await request(app)
      .post('/api/v1/admin/sessions')
      .set('Cookie', authCookie)
      .send({ name: 'Multi-User Token Flow' })
      .expect(201);

    const sessionId = createResponse.body.id;

    try {
      // Multiple users claim tokens
      const tokens: string[] = [];
      for (let i = 0; i < 3; i++) {
        const claimResponse = await request(app)
          .post(`/api/v1/sessions/${sessionId}/claim`)
          .expect(201);
        tokens.push(claimResponse.body.token);
      }

      // Verify all tokens are unique
      const uniqueTokens = new Set(tokens);
      expect(uniqueTokens.size).toBe(3);

      // Verify token count
      const detailResponse1 = await request(app)
        .get(`/api/v1/admin/sessions/${sessionId}`)
        .set('Cookie', authCookie)
        .expect(200);
      expect(detailResponse1.body.tokenCount).toBe(3);

      // Start session
      await request(app)
        .post(`/api/v1/admin/sessions/${sessionId}/start`)
        .set('Cookie', authCookie)
        .expect(200);

      // All users join
      const presenceHashes: string[] = [];
      for (const token of tokens) {
        const joinResponse = await request(app)
          .post(`/api/v1/sessions/${sessionId}/join`)
          .send({ token })
          .expect(200);
        presenceHashes.push(joinResponse.body.presenceHash);
      }

      // All presence hashes should be unique (derived from different seeds)
      const uniqueHashes = new Set(presenceHashes);
      expect(uniqueHashes.size).toBe(3);

      // Verify user count
      const detailResponse2 = await request(app)
        .get(`/api/v1/admin/sessions/${sessionId}`)
        .set('Cookie', authCookie)
        .expect(200);
      expect(detailResponse2.body.userCount).toBe(3);

    } finally {
      // Cleanup
      kernelManager.dissolveKernel(sessionId);
      await query('DELETE FROM tokens WHERE session_id = $1', [sessionId]);
      await query('DELETE FROM sessions WHERE id = $1', [sessionId]);
    }
  });

  it('should enforce token isolation between sessions', async () => {
    // Create two sessions
    const create1 = await request(app)
      .post('/api/v1/admin/sessions')
      .set('Cookie', authCookie)
      .send({ name: 'Isolation Session 1' })
      .expect(201);

    const create2 = await request(app)
      .post('/api/v1/admin/sessions')
      .set('Cookie', authCookie)
      .send({ name: 'Isolation Session 2' })
      .expect(201);

    const sessionId1 = create1.body.id;
    const sessionId2 = create2.body.id;

    try {
      // Claim token from session 1
      const claim1 = await request(app)
        .post(`/api/v1/sessions/${sessionId1}/claim`)
        .expect(201);
      const token1 = claim1.body.token;

      // Claim token from session 2
      const claim2 = await request(app)
        .post(`/api/v1/sessions/${sessionId2}/claim`)
        .expect(201);
      const token2 = claim2.body.token;

      // Start both sessions
      await request(app)
        .post(`/api/v1/admin/sessions/${sessionId1}/start`)
        .set('Cookie', authCookie)
        .expect(200);

      await request(app)
        .post(`/api/v1/admin/sessions/${sessionId2}/start`)
        .set('Cookie', authCookie)
        .expect(200);

      // Token 1 should work for session 1
      await request(app)
        .post(`/api/v1/sessions/${sessionId1}/join`)
        .send({ token: token1 })
        .expect(200);

      // Token 1 should NOT work for session 2
      await request(app)
        .post(`/api/v1/sessions/${sessionId2}/join`)
        .send({ token: token1 })
        .expect(400);

      // Token 2 should work for session 2
      await request(app)
        .post(`/api/v1/sessions/${sessionId2}/join`)
        .send({ token: token2 })
        .expect(200);

      // Token 2 should NOT work for session 1
      await request(app)
        .post(`/api/v1/sessions/${sessionId1}/join`)
        .send({ token: token2 })
        .expect(400);

    } finally {
      // Cleanup
      kernelManager.dissolveKernel(sessionId1);
      kernelManager.dissolveKernel(sessionId2);
      await query('DELETE FROM tokens WHERE session_id = $1', [sessionId1]);
      await query('DELETE FROM tokens WHERE session_id = $1', [sessionId2]);
      await query('DELETE FROM sessions WHERE id = $1', [sessionId1]);
      await query('DELETE FROM sessions WHERE id = $1', [sessionId2]);
    }
  });
});
