/**
 * Integration Test: Reconnection with Same Token
 *
 * Tests FR-021: Users can reconnect with their token to resume conversations
 *
 * Given a user has an active conversation
 * When they disconnect and reconnect with the same token
 * Then they should receive their full conversation history
 */

import { describe, it, expect, beforeAll, afterAll, beforeEach } from 'vitest';
import WebSocket from 'ws';
import { Session } from '../../src/models/session';
import { Token as TokenModel } from '../../src/models/token';
import { kernelManager } from '../../src/kernel/manager';
import { generateToken, hashToken } from '../../src/services/token';
import { pool } from '../../src/lib/db';

describe('Integration: Reconnection with Same Token', () => {
  let sessionId: string;
  let token: string;
  let tokenHash: string;
  let wsUrl: string;

  beforeAll(async () => {
    // Start WebSocket server on test port
    wsUrl = process.env.WS_TEST_URL || 'ws://localhost:3001';
  });

  afterAll(async () => {
    await pool.end();
  });

  beforeEach(async () => {
    // Clean up database
    await pool.query('DELETE FROM tokens');
    await pool.query('DELETE FROM sessions');

    // Create an ACTIVE session
    const session = await Session.create('Reconnection Test Session');
    sessionId = session.id;
    await Session.transitionState(sessionId, 'ACTIVE');

    // Create kernel
    kernelManager.createKernel(sessionId);

    // Generate token
    token = generateToken();
    tokenHash = hashToken(token);

    // Claim and join token
    await TokenModel.create(sessionId, tokenHash);
    await TokenModel.markJoined(tokenHash);
  });

  it('should restore conversation history on reconnect with same token', async () => {
    return new Promise<void>(async (resolve, reject) => {
      let firstConnection: WebSocket;
      let secondConnection: WebSocket;

      try {
        // First connection: send a message
        firstConnection = new WebSocket(wsUrl, {
          headers: { 'Authorization': `Bearer ${token}` }
        });

        await new Promise<void>((connectResolve) => {
          firstConnection.on('open', () => connectResolve());
        });

        // Wait for CONNECTION_ACK
        await new Promise<void>((ackResolve) => {
          firstConnection.on('message', (data: Buffer) => {
            const msg = JSON.parse(data.toString());
            if (msg.type === 'CONNECTION_ACK') {
              ackResolve();
            }
          });
        });

        // Send a user message
        firstConnection.send(JSON.stringify({
          type: 'USER_MESSAGE',
          payload: { content: 'Hello, this is a test message' }
        }));

        // Wait for AI response to complete
        await new Promise<void>((responseResolve) => {
          firstConnection.on('message', (data: Buffer) => {
            const msg = JSON.parse(data.toString());
            if (msg.type === 'MESSAGE_COMPLETE') {
              responseResolve();
            }
          });
        });

        // Close first connection
        firstConnection.close();
        await new Promise<void>((closeResolve) => {
          firstConnection.on('close', () => closeResolve());
        });

        // Second connection: reconnect with same token
        secondConnection = new WebSocket(wsUrl, {
          headers: { 'Authorization': `Bearer ${token}` }
        });

        await new Promise<void>((connectResolve) => {
          secondConnection.on('open', () => connectResolve());
        });

        // Wait for CONNECTION_ACK with history
        secondConnection.on('message', (data: Buffer) => {
          const msg = JSON.parse(data.toString());

          if (msg.type === 'CONNECTION_ACK') {
            expect(msg.payload).toBeDefined();
            expect(msg.payload.conversationHistory).toBeDefined();
            expect(msg.payload.conversationHistory.length).toBeGreaterThanOrEqual(2);

            const userMsg = msg.payload.conversationHistory.find(
              (m: any) => m.role === 'user'
            );
            expect(userMsg).toBeDefined();
            expect(userMsg.content).toBe('Hello, this is a test message');

            const aiMsg = msg.payload.conversationHistory.find(
              (m: any) => m.role === 'assistant'
            );
            expect(aiMsg).toBeDefined();

            secondConnection.close();
            resolve();
          }
        });

        secondConnection.on('error', reject);

      } catch (error) {
        reject(error);
      }
    });
  });

  it('should allow sending new messages after reconnection', async () => {
    return new Promise<void>(async (resolve, reject) => {
      let ws: WebSocket;

      try {
        // First connection: send initial message
        ws = new WebSocket(wsUrl, {
          headers: { 'Authorization': `Bearer ${token}` }
        });

        await new Promise<void>((connectResolve) => {
          ws.on('open', () => connectResolve());
        });

        await new Promise<void>((ackResolve) => {
          ws.on('message', (data: Buffer) => {
            const msg = JSON.parse(data.toString());
            if (msg.type === 'CONNECTION_ACK') ackResolve();
          });
        });

        ws.send(JSON.stringify({
          type: 'USER_MESSAGE',
          payload: { content: 'First message' }
        }));

        await new Promise<void>((responseResolve) => {
          ws.on('message', (data: Buffer) => {
            const msg = JSON.parse(data.toString());
            if (msg.type === 'MESSAGE_COMPLETE') responseResolve();
          });
        });

        ws.close();
        await new Promise<void>((closeResolve) => {
          ws.on('close', () => closeResolve());
        });

        // Reconnect and send another message
        ws = new WebSocket(wsUrl, {
          headers: { 'Authorization': `Bearer ${token}` }
        });

        await new Promise<void>((connectResolve) => {
          ws.on('open', () => connectResolve());
        });

        await new Promise<void>((ackResolve) => {
          ws.on('message', (data: Buffer) => {
            const msg = JSON.parse(data.toString());
            if (msg.type === 'CONNECTION_ACK') ackResolve();
          });
        });

        // Send second message
        ws.send(JSON.stringify({
          type: 'USER_MESSAGE',
          payload: { content: 'Second message after reconnect' }
        }));

        ws.on('message', (data: Buffer) => {
          const msg = JSON.parse(data.toString());

          if (msg.type === 'MESSAGE_COMPLETE') {
            // Verify we got a response
            expect(msg.payload).toBeDefined();
            ws.close();
            resolve();
          }
        });

        ws.on('error', reject);

      } catch (error) {
        reject(error);
      }
    });
  });
});
