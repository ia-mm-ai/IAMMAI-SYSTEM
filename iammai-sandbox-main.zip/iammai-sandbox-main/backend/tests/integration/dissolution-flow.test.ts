/**
 * Integration test for dissolution flow
 * @see specs/001-ephemeral-kernel/tasks.md#T082
 *
 * NOTE: These tests should FAIL initially if broadcastDissolution is not implemented
 */

import { describe, it, expect, beforeEach } from 'vitest';
import { kernelManager } from '../../src/kernel/manager.js';

beforeEach(() => {
  // Clear all kernels between tests
  for (const sessionId of Array.from(kernelManager['kernels'].keys())) {
    kernelManager.dissolveKernel(sessionId);
  }
});

describe('Dissolution Flow Integration', () => {
  it('should complete full dissolution flow: end→broadcast→destroy', async () => {
    const sessionId = 'test-session-dissolution';

    // Create kernel with conversations
    kernelManager.createKernel(sessionId);
    const conv1 = kernelManager.getOrCreateConversation(sessionId, 'token-hash-1', 'presence-1');
    const conv2 = kernelManager.getOrCreateConversation(sessionId, 'token-hash-2', 'presence-2');

    kernelManager.addMessage(sessionId, 'token-hash-1', 'user', 'Hello');
    kernelManager.addMessage(sessionId, 'token-hash-2', 'user', 'Hi there');

    // Verify conversations exist
    expect(conv1?.messages).toHaveLength(1);
    expect(conv2?.messages).toHaveLength(1);

    // Dissolve kernel
    const dissolved = kernelManager.dissolveKernel(sessionId);
    expect(dissolved).toBe(true);

    // Verify kernel no longer exists
    const conv = kernelManager.getOrCreateConversation(sessionId, 'token-hash-1', 'presence-1');
    expect(conv).toBeNull();

    // Verify cannot get conversation history
    const history = kernelManager.getConversationHistory(sessionId, 'token-hash-1');
    expect(history).toEqual([]);
  });

  it('should prevent new conversations after dissolution', async () => {
    const sessionId = 'test-session-no-new-conv';

    kernelManager.createKernel(sessionId);
    kernelManager.dissolveKernel(sessionId);

    // Attempt to create conversation in dissolved kernel
    const conv = kernelManager.getOrCreateConversation(sessionId, 'new-token', 'new-presence');
    expect(conv).toBeNull();
  });

  it('should handle dissolution of kernel with no conversations', async () => {
    const sessionId = 'test-session-empty';

    kernelManager.createKernel(sessionId);

    // Dissolve immediately without any conversations
    const dissolved = kernelManager.dissolveKernel(sessionId);
    expect(dissolved).toBe(true);

    // Verify kernel is gone
    const conv = kernelManager.getOrCreateConversation(sessionId, 'any-token', 'any-presence');
    expect(conv).toBeNull();
  });

  it('should handle dissolution idempotently', async () => {
    const sessionId = 'test-session-idempotent';

    kernelManager.createKernel(sessionId);

    // First dissolution
    const first = kernelManager.dissolveKernel(sessionId);
    expect(first).toBe(true);

    // Second dissolution (already dissolved)
    const second = kernelManager.dissolveKernel(sessionId);
    expect(second).toBe(false);
  });

  it('should measure dissolution timing (<50ms requirement)', async () => {
    const sessionId = 'test-session-timing';

    kernelManager.createKernel(sessionId);

    // Create multiple conversations to test performance
    for (let i = 0; i < 10; i++) {
      const conv = kernelManager.getOrCreateConversation(sessionId, `token-${i}`, `presence-${i}`);
      // Add multiple messages
      for (let j = 0; j < 50; j++) {
        kernelManager.addMessage(
          sessionId,
          `token-${i}`,
          j % 2 === 0 ? 'user' : 'assistant',
          `Message ${j} from conversation ${i}`
        );
      }
    }

    // Measure dissolution time
    const start = performance.now();
    kernelManager.dissolveKernel(sessionId);
    const duration = performance.now() - start;

    // Constitution Principle IV: Dissolution must complete <50ms
    expect(duration).toBeLessThan(50);
  });

  it('should completely destroy conversation data on dissolution', async () => {
    const sessionId = 'test-session-data-destruction';
    const sensitiveContent = 'This is private user data that must be destroyed';

    kernelManager.createKernel(sessionId);
    kernelManager.getOrCreateConversation(sessionId, 'token-hash', 'presence-hash');
    kernelManager.addMessage(sessionId, 'token-hash', 'user', sensitiveContent);

    // Verify message exists
    const before = kernelManager.getConversationHistory(sessionId, 'token-hash');
    expect(before[0]?.content).toBe(sensitiveContent);

    // Dissolve kernel
    kernelManager.dissolveKernel(sessionId);

    // Verify data is completely inaccessible
    const after = kernelManager.getConversationHistory(sessionId, 'token-hash');
    expect(after).toEqual([]);

    // Verify kernel itself doesn't exist
    const kernel = kernelManager['kernels'].get(sessionId);
    expect(kernel).toBeUndefined();
  });

  it('should not affect other sessions when dissolving one kernel', async () => {
    const session1 = 'test-session-1';
    const session2 = 'test-session-2';

    // Create two kernels
    kernelManager.createKernel(session1);
    kernelManager.createKernel(session2);

    kernelManager.getOrCreateConversation(session1, 'token-1', 'presence-1');
    kernelManager.getOrCreateConversation(session2, 'token-2', 'presence-2');

    kernelManager.addMessage(session1, 'token-1', 'user', 'Session 1 message');
    kernelManager.addMessage(session2, 'token-2', 'user', 'Session 2 message');

    // Dissolve only session 1
    kernelManager.dissolveKernel(session1);

    // Verify session 1 is gone
    expect(kernelManager.getConversationHistory(session1, 'token-1')).toEqual([]);

    // Verify session 2 still exists
    const session2History = kernelManager.getConversationHistory(session2, 'token-2');
    expect(session2History).toHaveLength(1);
    expect(session2History[0].content).toBe('Session 2 message');
  });
});
