/**
 * Integration test for chat flow (send → stream → complete)
 * @see specs/001-ephemeral-kernel/tasks.md#T067
 *
 * NOTE: These tests should FAIL initially (TDD approach)
 */

import { describe, it, expect, beforeAll, afterAll } from 'vitest';
import request from 'supertest';
import { WebSocket } from 'ws';
import type { Express } from 'express';
import { createApp } from '../../src/api/app.js';
import { query } from '../../src/lib/db.js';
import bcrypt from 'bcrypt';
import { generateToken } from '../../src/services/token.js';
import { kernelManager } from '../../src/kernel/manager.js';

describe('Chat Flow Integration', () => {
  let app: Express;
  let testAdminId: string;
  let testSessionId: string;
  let testToken: string;
  let testTokenHash: string;
  let wsUrl: string;

  beforeAll(async () => {
    app = createApp();

    // Create test admin
    const passwordHash = await bcrypt.hash('testPassword123!', 10);
    const adminResult = await query(
      `INSERT INTO admins (email, password_hash)
       VALUES ($1, $2)
       ON CONFLICT (email) DO UPDATE SET password_hash = $2
       RETURNING id`,
      ['test-chat-flow@example.com', passwordHash]
    );
    testAdminId = adminResult.rows[0].id;

    // Create test session
    const sessionResult = await query(
      `INSERT INTO sessions (name, state, admin_id, started_at)
       VALUES ($1, $2, $3, NOW())
       RETURNING id`,
      ['Test Chat Flow Session', 'ACTIVE', testAdminId]
    );
    testSessionId = sessionResult.rows[0].id;

    // Generate and claim a token
    const tokenData = generateToken();
    testToken = tokenData.raw;
    testTokenHash = tokenData.hash;

    await query(
      `INSERT INTO tokens (session_id, token_hash, joined_at)
       VALUES ($1, $2, NOW())`,
      [testSessionId, testTokenHash]
    );

    // Create kernel for session
    kernelManager.createKernel(testSessionId);

    wsUrl = `ws://localhost:3000/ws/sessions/${testSessionId}?token=${testToken}`;
  });

  afterAll(async () => {
    // Clean up kernel
    kernelManager.dissolveKernel(testSessionId);

    // Clean up database
    await query('DELETE FROM tokens WHERE session_id = $1', [testSessionId]);
    await query('DELETE FROM sessions WHERE id = $1', [testSessionId]);
    await query('DELETE FROM admins WHERE id = $1', [testAdminId]);
  });

  it('should complete full chat flow: HTTP POST → WebSocket stream → complete', async () => {
    // Step 1: Connect to WebSocket
    const ws = new WebSocket(wsUrl);

    await new Promise<void>((resolve, reject) => {
      ws.on('message', (data) => {
        const message = JSON.parse(data.toString());
        if (message.type === 'CONNECTION_ACK') {
          resolve();
        }
      });
      ws.on('error', reject);
      setTimeout(() => reject(new Error('WebSocket connection timeout')), 5000);
    });

    // Step 2: Send message via HTTP POST
    const messageId = 'flow-test-' + Date.now();
    const httpResponse = await request(app)
      .post(`/api/v1/sessions/${testSessionId}/messages`)
      .set('Authorization', `Bearer ${testToken}`)
      .send({
        content: 'What is 2 + 2?',
        messageId,
      })
      .expect(202);

    expect(httpResponse.body).toHaveProperty('messageId', messageId);
    expect(httpResponse.body).toHaveProperty('status', 'ACCEPTED');

    // Step 3: Receive streamed response via WebSocket
    const messages: any[] = [];

    await new Promise<void>((resolve, reject) => {
      const timeout = setTimeout(() => {
        reject(new Error('Timeout waiting for MESSAGE_COMPLETE'));
      }, 20000);

      ws.on('message', (data) => {
        const message = JSON.parse(data.toString());

        if (message.type === 'MESSAGE_CHUNK' || message.type === 'MESSAGE_COMPLETE') {
          messages.push(message);

          if (message.type === 'MESSAGE_COMPLETE') {
            clearTimeout(timeout);
            resolve();
          }
        }
      });

      ws.on('error', (err) => {
        clearTimeout(timeout);
        reject(err);
      });
    });

    // Verify streaming chunks
    const chunks = messages.filter((m) => m.type === 'MESSAGE_CHUNK');
    expect(chunks.length).toBeGreaterThan(0);

    // Verify complete message
    const completeMessages = messages.filter((m) => m.type === 'MESSAGE_COMPLETE');
    expect(completeMessages.length).toBe(1);

    const completeMessage = completeMessages[0];
    expect(completeMessage.payload.content).toBeTruthy();
    expect(completeMessage.payload.role).toBe('assistant');

    ws.close();
  });

  it('should maintain conversation context across multiple messages', async () => {
    const ws = new WebSocket(wsUrl);

    await new Promise<void>((resolve, reject) => {
      ws.on('message', (data) => {
        const message = JSON.parse(data.toString());
        if (message.type === 'CONNECTION_ACK') {
          resolve();
        }
      });
      ws.on('error', reject);
      setTimeout(() => reject(new Error('Connection timeout')), 5000);
    });

    // First message: Establish context
    await request(app)
      .post(`/api/v1/sessions/${testSessionId}/messages`)
      .set('Authorization', `Bearer ${testToken}`)
      .send({
        content: 'My favorite color is blue.',
      })
      .expect(202);

    // Wait for first response to complete
    await new Promise<void>((resolve, reject) => {
      const timeout = setTimeout(() => reject(new Error('Timeout')), 20000);

      ws.on('message', (data) => {
        const message = JSON.parse(data.toString());
        if (message.type === 'MESSAGE_COMPLETE') {
          clearTimeout(timeout);
          resolve();
        }
      });
    });

    // Second message: Reference context
    await request(app)
      .post(`/api/v1/sessions/${testSessionId}/messages`)
      .set('Authorization', `Bearer ${testToken}`)
      .send({
        content: 'What is my favorite color?',
      })
      .expect(202);

    // Wait for second response
    let secondResponse = '';

    await new Promise<void>((resolve, reject) => {
      const timeout = setTimeout(() => reject(new Error('Timeout')), 20000);

      ws.on('message', (data) => {
        const message = JSON.parse(data.toString());
        if (message.type === 'MESSAGE_COMPLETE') {
          secondResponse = message.payload.content.toLowerCase();
          clearTimeout(timeout);
          resolve();
        }
      });
    });

    // AI should remember "blue" from context
    expect(secondResponse).toContain('blue');

    ws.close();
  });

  it('should handle multiple concurrent messages gracefully', async () => {
    const ws = new WebSocket(wsUrl);

    await new Promise<void>((resolve, reject) => {
      ws.on('message', (data) => {
        const message = JSON.parse(data.toString());
        if (message.type === 'CONNECTION_ACK') {
          resolve();
        }
      });
      ws.on('error', reject);
      setTimeout(() => reject(new Error('Connection timeout')), 5000);
    });

    // Send multiple messages rapidly
    const messagePromises = [
      request(app)
        .post(`/api/v1/sessions/${testSessionId}/messages`)
        .set('Authorization', `Bearer ${testToken}`)
        .send({ content: 'Message 1' }),

      request(app)
        .post(`/api/v1/sessions/${testSessionId}/messages`)
        .set('Authorization', `Bearer ${testToken}`)
        .send({ content: 'Message 2' }),

      request(app)
        .post(`/api/v1/sessions/${testSessionId}/messages`)
        .set('Authorization', `Bearer ${testToken}`)
        .send({ content: 'Message 3' }),
    ];

    // All should be accepted
    const responses = await Promise.all(messagePromises);
    responses.forEach((response) => {
      expect(response.status).toBe(202);
    });

    // Wait for all completions (3 MESSAGE_COMPLETE events)
    let completedCount = 0;

    await new Promise<void>((resolve, reject) => {
      const timeout = setTimeout(() => {
        reject(new Error('Timeout waiting for all completions'));
      }, 60000);

      ws.on('message', (data) => {
        const message = JSON.parse(data.toString());
        if (message.type === 'MESSAGE_COMPLETE') {
          completedCount++;
          if (completedCount === 3) {
            clearTimeout(timeout);
            resolve();
          }
        }
      });

      ws.on('error', (err) => {
        clearTimeout(timeout);
        reject(err);
      });
    });

    expect(completedCount).toBe(3);

    ws.close();
  });

  it('should isolate conversations between different tokens', async () => {
    // Create second token for same session
    const tokenData2 = generateToken();
    await query(
      `INSERT INTO tokens (session_id, token_hash, joined_at)
       VALUES ($1, $2, NOW())`,
      [testSessionId, tokenData2.hash]
    );

    // Connect both tokens
    const ws1 = new WebSocket(wsUrl);
    const ws2 = new WebSocket(
      `ws://localhost:3000/ws/sessions/${testSessionId}?token=${tokenData2.raw}`
    );

    await Promise.all([
      new Promise<void>((resolve, reject) => {
        ws1.on('message', (data) => {
          const message = JSON.parse(data.toString());
          if (message.type === 'CONNECTION_ACK') resolve();
        });
        ws1.on('error', reject);
        setTimeout(() => reject(new Error('WS1 timeout')), 5000);
      }),
      new Promise<void>((resolve, reject) => {
        ws2.on('message', (data) => {
          const message = JSON.parse(data.toString());
          if (message.type === 'CONNECTION_ACK') resolve();
        });
        ws2.on('error', reject);
        setTimeout(() => reject(new Error('WS2 timeout')), 5000);
      }),
    ]);

    // Token 1 sends message
    await request(app)
      .post(`/api/v1/sessions/${testSessionId}/messages`)
      .set('Authorization', `Bearer ${testToken}`)
      .send({ content: 'Token 1 message' })
      .expect(202);

    // Wait for token 1 response
    await new Promise<void>((resolve, reject) => {
      const timeout = setTimeout(() => reject(new Error('Timeout')), 20000);
      ws1.on('message', (data) => {
        const message = JSON.parse(data.toString());
        if (message.type === 'MESSAGE_COMPLETE') {
          clearTimeout(timeout);
          resolve();
        }
      });
    });

    // Token 2 sends message
    await request(app)
      .post(`/api/v1/sessions/${testSessionId}/messages`)
      .set('Authorization', `Bearer ${tokenData2.raw}`)
      .send({ content: 'What did I just say?' })
      .expect(202);

    // Token 2 should get response that doesn't know about token 1's message
    let token2Response = '';

    await new Promise<void>((resolve, reject) => {
      const timeout = setTimeout(() => reject(new Error('Timeout')), 20000);
      ws2.on('message', (data) => {
        const message = JSON.parse(data.toString());
        if (message.type === 'MESSAGE_COMPLETE') {
          token2Response = message.payload.content.toLowerCase();
          clearTimeout(timeout);
          resolve();
        }
      });
    });

    // Token 2's AI shouldn't know about "Token 1 message"
    // (It might say it doesn't know, or ask for clarification)
    expect(token2Response).not.toContain('token 1');

    ws1.close();
    ws2.close();

    // Clean up
    await query('DELETE FROM tokens WHERE token_hash = $1', [tokenData2.hash]);
  });

  it('should reject messages after session ends', async () => {
    // Create separate session for this test
    const sessionResult = await query(
      `INSERT INTO sessions (name, state, admin_id, started_at)
       VALUES ($1, $2, $3, NOW())
       RETURNING id`,
      ['Test End Session', 'ACTIVE', testAdminId]
    );
    const endSessionId = sessionResult.rows[0].id;

    const tokenData = generateToken();
    await query(
      `INSERT INTO tokens (session_id, token_hash, joined_at)
       VALUES ($1, $2, NOW())`,
      [endSessionId, tokenData.hash]
    );

    kernelManager.createKernel(endSessionId);

    // First message should work
    await request(app)
      .post(`/api/v1/sessions/${endSessionId}/messages`)
      .set('Authorization', `Bearer ${tokenData.raw}`)
      .send({ content: 'Before end' })
      .expect(202);

    // End session
    await query(
      `UPDATE sessions SET state = 'ENDED', ended_at = NOW() WHERE id = $1`,
      [endSessionId]
    );
    kernelManager.dissolveKernel(endSessionId);

    // Second message should fail
    const response = await request(app)
      .post(`/api/v1/sessions/${endSessionId}/messages`)
      .set('Authorization', `Bearer ${tokenData.raw}`)
      .send({ content: 'After end' });

    expect(response.status).toBe(400);

    // Clean up
    await query('DELETE FROM tokens WHERE session_id = $1', [endSessionId]);
    await query('DELETE FROM sessions WHERE id = $1', [endSessionId]);
  });
});
