/**
 * Integration test for session analytics (token/user counts)
 * @see specs/001-ephemeral-kernel/tasks.md#T098
 * @see specs/001-ephemeral-kernel/spec.md#FR-024, FR-025
 */

import { describe, it, expect, beforeAll, afterAll, afterEach } from 'vitest';
import request from 'supertest';
import type { Express } from 'express';
import { createApp } from '../../src/api/app.js';
import { closePool, query } from '../../src/lib/db.js';
import { kernelManager } from '../../src/kernel/manager.js';
import bcrypt from 'bcrypt';

describe('Session Analytics (Token and User Counts)', () => {
  let app: Express;
  let authCookie: string;
  const testEmail = 'test-analytics@example.com';
  const testPassword = 'testPassword123!';
  let testAdminId: string;
  const createdSessionIds: string[] = [];
  const claimedTokens: string[] = [];

  beforeAll(async () => {
    app = createApp();

    // Create test admin and login
    const passwordHash = await bcrypt.hash(testPassword, 10);
    const result = await query(
      `INSERT INTO admins (email, password_hash)
       VALUES ($1, $2)
       ON CONFLICT (email) DO UPDATE SET password_hash = $2
       RETURNING id`,
      [testEmail, passwordHash]
    );
    testAdminId = result.rows[0].id;

    // Login to get auth cookie
    const loginResponse = await request(app)
      .post('/api/v1/auth/login')
      .send({ email: testEmail, password: testPassword });

    const cookies = loginResponse.headers['set-cookie'];
    authCookie = Array.isArray(cookies) ? cookies[0] : cookies;
  });

  afterEach(async () => {
    // Clean up claimed tokens
    for (const token of claimedTokens) {
      await query('DELETE FROM tokens WHERE token_hash = $1', [token]);
    }
    claimedTokens.length = 0;

    // Clean up created sessions
    for (const sessionId of createdSessionIds) {
      // Dissolve any kernels
      kernelManager.dissolveKernel(sessionId);
      // Delete from database
      await query('DELETE FROM sessions WHERE id = $1', [sessionId]);
    }
    createdSessionIds.length = 0;
  });

  afterAll(async () => {
    await query('DELETE FROM admins WHERE id = $1', [testAdminId]);
    await closePool();
  });

  describe('FR-024: Token Count Tracking', () => {
    it('should increment token_count when users claim tokens for CREATED session', async () => {
      // Create a session
      const createResponse = await request(app)
        .post('/api/v1/admin/sessions')
        .set('Cookie', authCookie)
        .send({ name: 'Token Count Test Session' })
        .expect(201);

      const sessionId = createResponse.body.id;
      createdSessionIds.push(sessionId);

      // Verify initial token count is 0
      let detailsResponse = await request(app)
        .get(`/api/v1/admin/sessions/${sessionId}`)
        .set('Cookie', authCookie)
        .expect(200);

      expect(detailsResponse.body.tokenCount).toBe(0);

      // Claim first token
      const claim1Response = await request(app)
        .post(`/api/v1/sessions/${sessionId}/claim`)
        .expect(201);

      claimedTokens.push(claim1Response.body.token);

      // Verify token count incremented to 1
      detailsResponse = await request(app)
        .get(`/api/v1/admin/sessions/${sessionId}`)
        .set('Cookie', authCookie)
        .expect(200);

      expect(detailsResponse.body.tokenCount).toBe(1);

      // Claim second token
      const claim2Response = await request(app)
        .post(`/api/v1/sessions/${sessionId}/claim`)
        .expect(201);

      claimedTokens.push(claim2Response.body.token);

      // Verify token count incremented to 2
      detailsResponse = await request(app)
        .get(`/api/v1/admin/sessions/${sessionId}`)
        .set('Cookie', authCookie)
        .expect(200);

      expect(detailsResponse.body.tokenCount).toBe(2);
    });

    it('should display token count for CREATED sessions in session list', async () => {
      // Create a session and claim tokens
      const createResponse = await request(app)
        .post('/api/v1/admin/sessions')
        .set('Cookie', authCookie)
        .send({ name: 'Session List Token Count' })
        .expect(201);

      const sessionId = createResponse.body.id;
      createdSessionIds.push(sessionId);

      // Claim 3 tokens
      for (let i = 0; i < 3; i++) {
        const claimResponse = await request(app)
          .post(`/api/v1/sessions/${sessionId}/claim`)
          .expect(201);
        claimedTokens.push(claimResponse.body.token);
      }

      // Get session list
      const listResponse = await request(app)
        .get('/api/v1/admin/sessions')
        .set('Cookie', authCookie)
        .expect(200);

      const session = listResponse.body.sessions.find((s: any) => s.id === sessionId);
      expect(session).toBeDefined();
      expect(session.tokenCount).toBe(3);
    });
  });

  describe('FR-025: User Count Tracking', () => {
    it('should increment user_count when users join ACTIVE session', async () => {
      // Create and start a session
      const createResponse = await request(app)
        .post('/api/v1/admin/sessions')
        .set('Cookie', authCookie)
        .send({ name: 'User Count Test Session' })
        .expect(201);

      const sessionId = createResponse.body.id;
      createdSessionIds.push(sessionId);

      // Claim tokens for 3 users
      const tokens: string[] = [];
      for (let i = 0; i < 3; i++) {
        const claimResponse = await request(app)
          .post(`/api/v1/sessions/${sessionId}/claim`)
          .expect(201);
        tokens.push(claimResponse.body.token);
        claimedTokens.push(claimResponse.body.token);
      }

      // Start session
      await request(app)
        .post(`/api/v1/admin/sessions/${sessionId}/start`)
        .set('Cookie', authCookie)
        .expect(200);

      // Verify initial user count is 0
      let detailsResponse = await request(app)
        .get(`/api/v1/admin/sessions/${sessionId}`)
        .set('Cookie', authCookie)
        .expect(200);

      expect(detailsResponse.body.userCount).toBe(0);

      // First user joins
      await request(app)
        .post(`/api/v1/sessions/${sessionId}/join`)
        .send({ token: tokens[0] })
        .expect(200);

      // Verify user count incremented to 1
      detailsResponse = await request(app)
        .get(`/api/v1/admin/sessions/${sessionId}`)
        .set('Cookie', authCookie)
        .expect(200);

      expect(detailsResponse.body.userCount).toBe(1);

      // Second user joins
      await request(app)
        .post(`/api/v1/sessions/${sessionId}/join`)
        .send({ token: tokens[1] })
        .expect(200);

      // Verify user count incremented to 2
      detailsResponse = await request(app)
        .get(`/api/v1/admin/sessions/${sessionId}`)
        .set('Cookie', authCookie)
        .expect(200);

      expect(detailsResponse.body.userCount).toBe(2);

      // Third user joins
      await request(app)
        .post(`/api/v1/sessions/${sessionId}/join`)
        .send({ token: tokens[2] })
        .expect(200);

      // Verify user count incremented to 3
      detailsResponse = await request(app)
        .get(`/api/v1/admin/sessions/${sessionId}`)
        .set('Cookie', authCookie)
        .expect(200);

      expect(detailsResponse.body.userCount).toBe(3);
    });

    it('should not increment user_count on reconnection with same token', async () => {
      // Create and start a session
      const createResponse = await request(app)
        .post('/api/v1/admin/sessions')
        .set('Cookie', authCookie)
        .send({ name: 'Reconnection Count Test' })
        .expect(201);

      const sessionId = createResponse.body.id;
      createdSessionIds.push(sessionId);

      // Claim token
      const claimResponse = await request(app)
        .post(`/api/v1/sessions/${sessionId}/claim`)
        .expect(201);

      const token = claimResponse.body.token;
      claimedTokens.push(token);

      // Start session
      await request(app)
        .post(`/api/v1/admin/sessions/${sessionId}/start`)
        .set('Cookie', authCookie)
        .expect(200);

      // User joins first time
      await request(app)
        .post(`/api/v1/sessions/${sessionId}/join`)
        .send({ token })
        .expect(200);

      // Verify user count is 1
      let detailsResponse = await request(app)
        .get(`/api/v1/admin/sessions/${sessionId}`)
        .set('Cookie', authCookie)
        .expect(200);

      expect(detailsResponse.body.userCount).toBe(1);

      // User "reconnects" (joins again with same token)
      await request(app)
        .post(`/api/v1/sessions/${sessionId}/join`)
        .send({ token })
        .expect(200);

      // Verify user count is still 1 (not incremented)
      detailsResponse = await request(app)
        .get(`/api/v1/admin/sessions/${sessionId}`)
        .set('Cookie', authCookie)
        .expect(200);

      expect(detailsResponse.body.userCount).toBe(1);
    });

    it('should preserve user count after session ends', async () => {
      // Create, start, and have users join
      const createResponse = await request(app)
        .post('/api/v1/admin/sessions')
        .set('Cookie', authCookie)
        .send({ name: 'Ended Session User Count' })
        .expect(201);

      const sessionId = createResponse.body.id;
      createdSessionIds.push(sessionId);

      // Claim tokens and join
      const tokens: string[] = [];
      for (let i = 0; i < 2; i++) {
        const claimResponse = await request(app)
          .post(`/api/v1/sessions/${sessionId}/claim`)
          .expect(201);
        tokens.push(claimResponse.body.token);
        claimedTokens.push(claimResponse.body.token);
      }

      await request(app)
        .post(`/api/v1/admin/sessions/${sessionId}/start`)
        .set('Cookie', authCookie)
        .expect(200);

      // Both users join
      for (const token of tokens) {
        await request(app)
          .post(`/api/v1/sessions/${sessionId}/join`)
          .send({ token })
          .expect(200);
      }

      // Verify user count is 2
      let detailsResponse = await request(app)
        .get(`/api/v1/admin/sessions/${sessionId}`)
        .set('Cookie', authCookie)
        .expect(200);

      expect(detailsResponse.body.userCount).toBe(2);

      // End session
      await request(app)
        .post(`/api/v1/admin/sessions/${sessionId}/end`)
        .set('Cookie', authCookie)
        .expect(200);

      // Verify user count is still 2 after ending
      detailsResponse = await request(app)
        .get(`/api/v1/admin/sessions/${sessionId}`)
        .set('Cookie', authCookie)
        .expect(200);

      expect(detailsResponse.body.state).toBe('ENDED');
      expect(detailsResponse.body.userCount).toBe(2);
    });
  });

  describe('Combined Token and User Analytics', () => {
    it('should correctly track both token and user counts throughout session lifecycle', async () => {
      // Create session
      const createResponse = await request(app)
        .post('/api/v1/admin/sessions')
        .set('Cookie', authCookie)
        .send({ name: 'Full Lifecycle Analytics' })
        .expect(201);

      const sessionId = createResponse.body.id;
      createdSessionIds.push(sessionId);

      // CREATED state: 5 users claim tokens
      const tokens: string[] = [];
      for (let i = 0; i < 5; i++) {
        const claimResponse = await request(app)
          .post(`/api/v1/sessions/${sessionId}/claim`)
          .expect(201);
        tokens.push(claimResponse.body.token);
        claimedTokens.push(claimResponse.body.token);
      }

      let detailsResponse = await request(app)
        .get(`/api/v1/admin/sessions/${sessionId}`)
        .set('Cookie', authCookie)
        .expect(200);

      expect(detailsResponse.body.state).toBe('CREATED');
      expect(detailsResponse.body.tokenCount).toBe(5);
      expect(detailsResponse.body.userCount).toBe(0);

      // Start session -> ACTIVE state
      await request(app)
        .post(`/api/v1/admin/sessions/${sessionId}/start`)
        .set('Cookie', authCookie)
        .expect(200);

      // 3 out of 5 users join
      for (let i = 0; i < 3; i++) {
        await request(app)
          .post(`/api/v1/sessions/${sessionId}/join`)
          .send({ token: tokens[i] })
          .expect(200);
      }

      detailsResponse = await request(app)
        .get(`/api/v1/admin/sessions/${sessionId}`)
        .set('Cookie', authCookie)
        .expect(200);

      expect(detailsResponse.body.state).toBe('ACTIVE');
      expect(detailsResponse.body.tokenCount).toBe(5);
      expect(detailsResponse.body.userCount).toBe(3);

      // End session -> ENDED state
      await request(app)
        .post(`/api/v1/admin/sessions/${sessionId}/end`)
        .set('Cookie', authCookie)
        .expect(200);

      detailsResponse = await request(app)
        .get(`/api/v1/admin/sessions/${sessionId}`)
        .set('Cookie', authCookie)
        .expect(200);

      expect(detailsResponse.body.state).toBe('ENDED');
      expect(detailsResponse.body.tokenCount).toBe(5);
      expect(detailsResponse.body.userCount).toBe(3);
    });
  });
});
