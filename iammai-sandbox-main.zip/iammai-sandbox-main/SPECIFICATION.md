# IAMMAI Sandbox — System Specification

> **CANONICAL SOURCE OF TRUTH**
>
> This document is the single authoritative reference for what we are building.
> All discussions, decisions, and implementation work reference this specification.
>
> Last updated: 2026-01-24

---

## 1. What This System Is

A web application with two sides:

- **Admin side** — Creates and controls chatbot sessions
- **User side** — Joins sessions and chats with an AI

When a session ends, all conversations are destroyed completely and permanently.

---

## 2. Core Components

### 2.1 Token

An anonymous access pass.

- Grants access to one specific session
- Contains no user identity
- One token per user per session
- Includes a random seed used to derive presence
- Can be purchased while session is in CREATED state (queued)
- Becomes usable when admin starts the session

### 2.2 NFT

A lifecycle record for a session.

**What it tracks:**
- Session name
- Current state (CREATED, ACTIVE, or ENDED)
- When the session was created, started, and ended
- How many users joined (count only)

**What it does NOT track:**
- Conversation content
- User identities
- What was said

### 2.3 Kernel

An ephemeral presence container.

- Holds all private conversations for a session
- Exists only in memory
- Exists only while session is ACTIVE
- Contains isolated conversation spaces (one per token)
- **Dissolves completely when session ends** — all conversations destroyed

---

## 3. Session Lifecycle

### 3.1 States

| State | Kernel | What Users See |
|-------|--------|----------------|
| CREATED | Does not exist | Session visible in queue, can purchase token |
| ACTIVE | Exists | Session visible, can join (if token held) |
| ENDED | Dissolved | Session over, conversations gone |

### 3.2 Transitions

```
CREATED ──[Admin starts]──► ACTIVE ──[Admin ends]──► ENDED
```

- When admin starts: Kernel is created
- When admin ends: Kernel is dissolved (all conversations destroyed)
- Transitions are irreversible

---

## 4. Admin Capabilities

### 4.1 What Admin Can Do

- Create a new session (with a name)
- Start a session (makes it active, creates kernel)
- End a session (dissolves kernel, destroys all conversations)
- View list of all sessions
- View session states
- View user count per session
- Track kernel status changes for each session (created, active, dissolved)
- View kernel lifecycle history (timestamps of state transitions)

### 4.2 What Admin Cannot Do

- See conversation content
- See what users are saying
- See user identities
- Recover conversations after session ends

---

## 5. User Capabilities

### 5.1 What User Can Do

- Browse queued sessions (CREATED state)
- Browse active sessions (ACTIVE state)
- Purchase a token for a queued session
- Join an active session (requires token)
- Chat privately with the AI
- See kernel status (active or dissolved)
- See their presence hash (anonymous identifier)

### 5.2 What User Cannot Do

- See other users' conversations
- Know who else is in the session
- Export or download their conversation
- Access conversation after session ends
- Join a session without a token
- Chat in a session that is not active (kernel must exist)

---

## 6. Conversation Behavior

### 6.1 During Active Session

- User sends a message
- AI responds
- Messages are stored in the kernel (memory only)
- Each user has a private, isolated conversation
- Users cannot see each other's conversations

### 6.2 When Session Ends

- All conversations are destroyed immediately
- Users see "Kernel Dissolved"
- Users see "Your conversation is gone"
- No way to recover the conversation
- Only the NFT record remains (no content)

---

## 7. Privacy Model

### 7.1 Anonymity

- No user accounts
- No login required
- Tokens contain no identity
- Presence is represented by a hash, not a name

### 7.2 Isolation

- Each user's conversation is separate
- Users cannot see each other
- Admin cannot see any conversations

### 7.3 Ephemerality

- Conversations exist only in memory
- Nothing is saved to disk
- When session ends, everything is gone
- Cannot be recovered or reconstructed

---

## 8. User Interface Elements

### 8.1 Admin View

**Session List:**
- Shows all sessions with their state
- Shows user count for active/ended sessions
- Shows token purchase count for queued sessions
- Buttons to start or end sessions

**Session States Display:**
- CREATED — gray, waiting to start
- ACTIVE — green, live
- ENDED — red, finished

**Kernel Status Panel (per session):**
- Current kernel state (not created / active / dissolved)
- Lifecycle history with timestamps:
  - When session was created
  - When kernel was instantiated (session started)
  - When kernel was dissolved (session ended)

### 8.2 User View

**Session Browser:**
- Shows queued sessions (CREATED) — can purchase token
- Shows active sessions (ACTIVE) — can join if token held
- Purchase button for queued sessions
- Join button for active sessions (if user has token)

**Chat Interface:**
- Kernel status indicator (active/dissolved)
- Presence indicator (shows user's anonymous hash)
- Chat messages (user and assistant)
- Message input field

**Dissolution View:**
- Shown when session ends
- Kernel status: dissolved
- Message: "Your conversation is gone"

---

## 9. Kernel Visibility

The kernel must be visible to users:

**When Active:**
- Indicator shows: "● Kernel Active"
- User sees: "Your presence: [hash]"
- Chat is enabled

**When Dissolved:**
- Indicator shows: "○ Kernel Dissolved"
- User sees: "Your conversation is gone"
- Chat is disabled

---

## 10. Edge Cases

### 10.1 User Disconnects

- Conversation remains in kernel
- User can rejoin with same token
- Conversation continues

### 10.2 User Refreshes Browser

- Token is lost
- User must rejoin (gets new token)
- Previous conversation is orphaned in kernel

### 10.3 Session Ends While User is Chatting

- User immediately sees dissolution
- Current message (if any) is lost
- No warning before dissolution

---

## 11. What Remains After Session Ends

| Remains | Gone Forever |
|---------|--------------|
| NFT record exists | All conversations |
| Session name | All messages |
| Start/end timestamps | User presence |
| User count | Tokens |
| State = ENDED | Kernel |

---

## 12. Summary

**The system provides:**

1. **Sessions** — Chatbot instances controlled by admin
2. **Tokens** — Anonymous access for users
3. **NFT** — Record that session occurred (no content)
4. **Kernel** — Ephemeral container for conversations
5. **Dissolution** — Complete destruction when session ends

**The guarantee:**

When a session ends, all conversations are truly gone. Only the fact that a session occurred remains — never what happened inside.
