#!/bin/bash
# Railway Deployment Script for iammai-sandbox
# This script guides you through deploying the monorepo to Railway

set -e

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

echo -e "${BLUE}╔════════════════════════════════════════════════════════════════╗${NC}"
echo -e "${BLUE}║           Railway Deployment for iammai-sandbox                ║${NC}"
echo -e "${BLUE}╚════════════════════════════════════════════════════════════════╝${NC}"
echo ""

# Check if Railway CLI is installed
if ! command -v railway &> /dev/null; then
    echo -e "${RED}Error: Railway CLI is not installed.${NC}"
    echo "Install it with: npm install -g @railway/cli"
    echo "Or visit: https://docs.railway.app/develop/cli"
    exit 1
fi

# Check if logged in
if ! railway whoami &> /dev/null; then
    echo -e "${YELLOW}You need to login to Railway first.${NC}"
    railway login
fi

echo -e "${GREEN}✓ Railway CLI is installed and authenticated${NC}"
echo ""

# Generate secure credentials
JWT_SECRET=$(openssl rand -hex 32)
ADMIN_PASSWORD=$(openssl rand -base64 12 | tr -d '/+=' | head -c 16)

echo -e "${BLUE}Step 1: Initialize Railway Project${NC}"
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"

# Check if already linked to a project
if railway status &> /dev/null; then
    echo -e "${YELLOW}Already linked to a Railway project.${NC}"
    read -p "Continue with existing project? (y/n): " continue_existing
    if [[ "$continue_existing" != "y" ]]; then
        echo "Run 'railway unlink' first, then re-run this script."
        exit 0
    fi
else
    echo "Creating new Railway project..."
    railway init
fi

echo ""
echo -e "${BLUE}Step 2: Add PostgreSQL Database${NC}"
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo "Adding PostgreSQL database..."
railway add -d postgres || echo -e "${YELLOW}PostgreSQL may already exist${NC}"

echo ""
echo -e "${BLUE}Step 3: Get OpenAI API Key${NC}"
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━"
read -p "Enter your OpenAI API Key: " OPENAI_API_KEY

if [[ -z "$OPENAI_API_KEY" ]]; then
    echo -e "${RED}Error: OpenAI API Key is required${NC}"
    exit 1
fi

echo ""
echo -e "${BLUE}Step 4: Create Backend Service${NC}"
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"

echo "Creating backend service..."
railway add -s backend

echo "Linking to backend service..."
railway service backend

echo "Setting backend environment variables..."
railway variables set \
    NODE_ENV=production \
    PORT=3001 \
    JWT_SECRET="$JWT_SECRET" \
    OPENAI_API_KEY="$OPENAI_API_KEY" \
    ADMIN_EMAIL=admin@example.com \
    ADMIN_PASSWORD="$ADMIN_PASSWORD"

echo ""
echo -e "${YELLOW}⚠️  MANUAL STEP REQUIRED for backend:${NC}"
echo "   In the Railway dashboard, set the backend service source root to: backend/"
echo "   (Service → Settings → Source → Root Directory)"
echo "   This tells Railway to use backend/railway.toml and build with Dockerfile.backend"
echo ""
read -p "Press Enter once you've set the root directory in the dashboard..."

echo ""
echo -e "${BLUE}Step 5: Create Admin Frontend Service${NC}"
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"

railway add -s admin
railway service admin

railway variables set \
    NODE_ENV=production \
    PORT=3000 \
    RAILWAY_APP=admin

echo ""
echo -e "${BLUE}Step 6: Create User Frontend Service${NC}"
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"

railway add -s user
railway service user

railway variables set \
    NODE_ENV=production \
    PORT=3002 \
    RAILWAY_APP=user

echo ""
echo -e "${BLUE}Step 7: Deploy All Services${NC}"
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo "Deploying to Railway..."
railway up --detach

echo ""
echo -e "${BLUE}Step 8: Open Railway Dashboard${NC}"
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo "Opening Railway dashboard..."
railway open

echo ""
echo -e "${GREEN}╔════════════════════════════════════════════════════════════════╗${NC}"
echo -e "${GREEN}║                    DEPLOYMENT INITIATED!                       ║${NC}"
echo -e "${GREEN}╚════════════════════════════════════════════════════════════════╝${NC}"
echo ""
echo -e "${YELLOW}IMPORTANT: After deployment completes, you need to:${NC}"
echo ""
echo "1. Get the backend URL from Railway dashboard"
echo ""
echo "2. Update frontend services with API URLs:"
echo "   railway service admin"
echo "   railway variables set NEXT_PUBLIC_API_URL=https://<backend-url>"
echo "   railway variables set NEXT_PUBLIC_WS_URL=wss://<backend-url>"
echo ""
echo "   railway service user"
echo "   railway variables set NEXT_PUBLIC_API_URL=https://<backend-url>/api/v1"
echo "   railway variables set NEXT_PUBLIC_WS_URL=wss://<backend-url>"
echo ""
echo "3. Update backend CORS with frontend URLs:"
echo "   railway service backend"
echo "   railway variables set CORS_ORIGINS=https://<admin-url>,https://<user-url>"
echo ""
echo "4. Run database migrations:"
echo "   railway service backend"
echo "   railway run pnpm db:migrate"
echo "   railway run pnpm db:seed"
echo ""
echo -e "${GREEN}═══════════════════════════════════════════════════════════════════${NC}"
echo -e "${GREEN}Admin Credentials (SAVE THESE):${NC}"
echo -e "${GREEN}═══════════════════════════════════════════════════════════════════${NC}"
echo -e "Email:    ${BLUE}admin@example.com${NC}"
echo -e "Password: ${BLUE}${ADMIN_PASSWORD}${NC}"
echo ""
echo -e "${GREEN}JWT Secret: ${NC}${JWT_SECRET}"
echo ""
