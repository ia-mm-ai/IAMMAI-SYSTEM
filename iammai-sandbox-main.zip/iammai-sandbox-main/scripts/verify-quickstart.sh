#!/bin/bash

# Quickstart Verification Script
# Verifies the setup steps from quickstart.md
# See specs/001-ephemeral-kernel/tasks.md#T114

set -e

API_BASE="http://localhost:3001/api/v1"
COOKIE_FILE="/tmp/admin-cookies.txt"
TOKEN_FILE="/tmp/user-token.txt"
SESSION_ID_FILE="/tmp/session-id.txt"

echo "========================================="
echo "Quickstart Verification Script"
echo "========================================="
echo ""

# Check prerequisites
echo "1. Checking prerequisites..."

if ! command -v node &> /dev/null; then
    echo "❌ Node.js not found"
    exit 1
fi

NODE_VERSION=$(node --version)
echo "✓ Node.js: $NODE_VERSION"

if ! command -v pnpm &> /dev/null; then
    echo "❌ pnpm not found"
    exit 1
fi

PNPM_VERSION=$(pnpm --version)
echo "✓ pnpm: $PNPM_VERSION"

if ! command -v psql &> /dev/null; then
    echo "⚠️  psql not found (optional)"
else
    PSQL_VERSION=$(psql --version)
    echo "✓ PostgreSQL client: $PSQL_VERSION"
fi

echo ""

# Check environment
echo "2. Checking environment variables..."

if [ ! -f .env ]; then
    echo "❌ .env file not found"
    echo "   Run: cp .env.example .env"
    exit 1
fi

source .env 2>/dev/null || true

if [ -z "$DATABASE_URL" ]; then
    echo "❌ DATABASE_URL not set"
    exit 1
fi
echo "✓ DATABASE_URL is set"

if [ -z "$JWT_SECRET" ]; then
    echo "❌ JWT_SECRET not set"
    exit 1
fi
echo "✓ JWT_SECRET is set"

if [ -z "$ADMIN_EMAIL" ]; then
    echo "❌ ADMIN_EMAIL not set"
    exit 1
fi
echo "✓ ADMIN_EMAIL is set"

if [ -z "$ADMIN_PASSWORD" ]; then
    echo "❌ ADMIN_PASSWORD not set"
    exit 1
fi
echo "✓ ADMIN_PASSWORD is set"

echo ""

# Check if server is running
echo "3. Checking if server is running..."

if ! curl -s -o /dev/null -w "%{http_code}" "$API_BASE/health" &> /dev/null; then
    echo "❌ Server not responding at $API_BASE"
    echo "   Start the server with: pnpm dev"
    exit 1
fi

echo "✓ Server is running"
echo ""

# Test API endpoints
echo "4. Testing API endpoints..."

# Login
echo "   → POST /auth/login"
LOGIN_RESPONSE=$(curl -s -X POST "$API_BASE/auth/login" \
  -H "Content-Type: application/json" \
  -d "{\"email\": \"$ADMIN_EMAIL\", \"password\": \"$ADMIN_PASSWORD\"}" \
  -c "$COOKIE_FILE" \
  -w "\n%{http_code}")

HTTP_CODE=$(echo "$LOGIN_RESPONSE" | tail -n1)
RESPONSE_BODY=$(echo "$LOGIN_RESPONSE" | sed '$d')

if [ "$HTTP_CODE" != "200" ]; then
    echo "❌ Login failed (HTTP $HTTP_CODE)"
    echo "   Response: $RESPONSE_BODY"
    exit 1
fi

echo "✓ Admin login successful"

# Create session
echo "   → POST /admin/sessions"
CREATE_RESPONSE=$(curl -s -X POST "$API_BASE/admin/sessions" \
  -H "Content-Type: application/json" \
  -b "$COOKIE_FILE" \
  -d '{"name": "Quickstart Verification Session"}' \
  -w "\n%{http_code}")

HTTP_CODE=$(echo "$CREATE_RESPONSE" | tail -n1)
RESPONSE_BODY=$(echo "$CREATE_RESPONSE" | sed '$d')

if [ "$HTTP_CODE" != "201" ]; then
    echo "❌ Session creation failed (HTTP $HTTP_CODE)"
    echo "   Response: $RESPONSE_BODY"
    exit 1
fi

SESSION_ID=$(echo "$RESPONSE_BODY" | grep -o '"id":"[^"]*"' | cut -d'"' -f4)
echo "$SESSION_ID" > "$SESSION_ID_FILE"
echo "✓ Session created: $SESSION_ID"

# Claim token
echo "   → POST /sessions/$SESSION_ID/claim"
CLAIM_RESPONSE=$(curl -s -X POST "$API_BASE/sessions/$SESSION_ID/claim" \
  -w "\n%{http_code}")

HTTP_CODE=$(echo "$CLAIM_RESPONSE" | tail -n1)
RESPONSE_BODY=$(echo "$CLAIM_RESPONSE" | sed '$d')

if [ "$HTTP_CODE" != "201" ]; then
    echo "❌ Token claim failed (HTTP $HTTP_CODE)"
    echo "   Response: $RESPONSE_BODY"
    exit 1
fi

TOKEN=$(echo "$RESPONSE_BODY" | grep -o '"token":"[^"]*"' | cut -d'"' -f4)
echo "$TOKEN" > "$TOKEN_FILE"
echo "✓ Token claimed: ${TOKEN:0:20}..."

# Start session
echo "   → POST /admin/sessions/$SESSION_ID/start"
START_RESPONSE=$(curl -s -X POST "$API_BASE/admin/sessions/$SESSION_ID/start" \
  -b "$COOKIE_FILE" \
  -w "\n%{http_code}")

HTTP_CODE=$(echo "$START_RESPONSE" | tail -n1)

if [ "$HTTP_CODE" != "200" ]; then
    echo "❌ Session start failed (HTTP $HTTP_CODE)"
    exit 1
fi

echo "✓ Session started"

# Join session
echo "   → POST /sessions/$SESSION_ID/join"
JOIN_RESPONSE=$(curl -s -X POST "$API_BASE/sessions/$SESSION_ID/join" \
  -H "Content-Type: application/json" \
  -d "{\"token\": \"$TOKEN\"}" \
  -w "\n%{http_code}")

HTTP_CODE=$(echo "$JOIN_RESPONSE" | tail -n1)
RESPONSE_BODY=$(echo "$JOIN_RESPONSE" | sed '$d')

if [ "$HTTP_CODE" != "200" ]; then
    echo "❌ Session join failed (HTTP $HTTP_CODE)"
    echo "   Response: $RESPONSE_BODY"
    exit 1
fi

PRESENCE_HASH=$(echo "$RESPONSE_BODY" | grep -o '"presenceHash":"[^"]*"' | cut -d'"' -f4)
echo "✓ Session joined, presence hash: ${PRESENCE_HASH:0:20}..."

# Get session details (admin)
echo "   → GET /admin/sessions/$SESSION_ID"
DETAILS_RESPONSE=$(curl -s -X GET "$API_BASE/admin/sessions/$SESSION_ID" \
  -b "$COOKIE_FILE" \
  -w "\n%{http_code}")

HTTP_CODE=$(echo "$DETAILS_RESPONSE" | tail -n1)

if [ "$HTTP_CODE" != "200" ]; then
    echo "❌ Get session details failed (HTTP $HTTP_CODE)"
    exit 1
fi

echo "✓ Session details retrieved"

# End session
echo "   → POST /admin/sessions/$SESSION_ID/end"
END_RESPONSE=$(curl -s -X POST "$API_BASE/admin/sessions/$SESSION_ID/end" \
  -b "$COOKIE_FILE" \
  -w "\n%{http_code}")

HTTP_CODE=$(echo "$END_RESPONSE" | tail -n1)

if [ "$HTTP_CODE" != "200" ]; then
    echo "❌ Session end failed (HTTP $HTTP_CODE)"
    exit 1
fi

echo "✓ Session ended"

echo ""

# Cleanup
echo "5. Cleaning up..."
rm -f "$COOKIE_FILE" "$TOKEN_FILE" "$SESSION_ID_FILE"
echo "✓ Temporary files removed"

echo ""
echo "========================================="
echo "✅ All quickstart steps verified!"
echo "========================================="
echo ""
echo "Summary:"
echo "  ✓ Admin login"
echo "  ✓ Session creation"
echo "  ✓ Token claim"
echo "  ✓ Session start"
echo "  ✓ Session join"
echo "  ✓ Session details"
echo "  ✓ Session end"
echo ""
echo "The quickstart guide is accurate and working."
