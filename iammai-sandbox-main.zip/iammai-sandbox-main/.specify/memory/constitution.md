<!--
SYNC IMPACT REPORT
==================
Version change: 0.0.0 → 1.0.0 (MAJOR - initial ratification)
Modified principles: N/A (first version)
Added sections:
  - Principle I: Code Quality First
  - Principle II: Testing Standards
  - Principle III: User Experience Consistency
  - Principle IV: Performance Requirements
  - Principle V: Privacy & Ephemerality Enforcement
  - Section: Technical Decision Framework
  - Section: Implementation Quality Gates
  - Section: Governance
Templates requiring updates:
  ✅ .specify/templates/plan-template.md - Constitution Check section exists
  ✅ .specify/templates/spec-template.md - Requirements section supports principles
  ✅ .specify/templates/tasks-template.md - Quality gates align with principles
Follow-up TODOs: None
==================
-->

# IAMMAI Sandbox Constitution

## Core Principles

### I. Code Quality First

All code MUST meet these non-negotiable standards:

- **Type Safety**: TypeScript strict mode MUST be enabled; `any` types are prohibited except in explicitly justified edge cases
- **Code Organization**: Single responsibility principle for all modules; maximum 300 lines per file; maximum 50 lines per function
- **Naming Conventions**: Descriptive names that reveal intent; no abbreviations except industry-standard ones (API, URL, ID)
- **Error Handling**: All errors MUST be explicitly handled; no silent failures; errors MUST propagate with actionable context
- **Documentation**: Public APIs MUST have JSDoc comments; complex logic MUST have inline explanations
- **Dependencies**: External dependencies MUST be justified; prefer standard library where feasible; security audit required for new packages

**Rationale**: The ephemeral nature of conversations does not excuse poor code quality. Maintainable code ensures the privacy guarantees remain intact as the system evolves.

### II. Testing Standards

Testing is mandatory and follows these requirements:

- **Unit Tests**: All business logic MUST have unit tests with minimum 80% code coverage
- **Integration Tests**: API endpoints and service boundaries MUST have integration tests
- **Contract Tests**: All external interfaces (API, WebSocket) MUST have contract tests documenting expected behavior
- **Privacy Tests**: Explicit tests MUST verify that:
  - Kernel dissolution destroys all conversation data
  - Users cannot access other users' conversations
  - Admin cannot access conversation content
- **Test Organization**: Tests MUST be co-located with source or in parallel `tests/` directory mirroring source structure
- **Test Naming**: Tests MUST clearly describe the scenario: `given_when_then` or descriptive sentence format

**Rationale**: The privacy guarantees of this system are its core value proposition. Untested code cannot be trusted to maintain these guarantees.

### III. User Experience Consistency

User-facing interfaces MUST adhere to these standards:

- **State Visibility**: Session state (CREATED, ACTIVE, ENDED) and kernel status (active, dissolved) MUST always be visible to users
- **Feedback Immediacy**: All user actions MUST receive visual feedback within 100ms
- **Error Clarity**: Error messages MUST explain what happened and what the user can do next; no technical jargon
- **Dissolution Experience**: The kernel dissolution transition MUST be unmistakable and communicate finality
- **Loading States**: All async operations MUST show loading indicators; skeleton screens preferred over spinners for content
- **Accessibility**: WCAG 2.1 AA compliance is mandatory; all interactive elements MUST be keyboard accessible
- **Responsive Design**: UI MUST function correctly on viewports from 320px to 4K displays

**Rationale**: Users trust this system with private conversations. The interface MUST clearly communicate what state their data is in at all times.

### IV. Performance Requirements

Performance targets are mandatory constraints, not aspirational goals:

- **API Response Time**: P95 latency MUST be under 200ms for all synchronous operations
- **WebSocket Latency**: Message round-trip MUST be under 100ms under normal load
- **Time to Interactive**: Initial page load MUST reach interactive state within 3 seconds on 3G networks
- **Memory Efficiency**: Kernel MUST handle 100 concurrent users per session with less than 512MB memory overhead
- **Dissolution Speed**: Kernel dissolution MUST complete within 50ms; no lingering data
- **Startup Time**: Backend service MUST be ready to accept requests within 10 seconds of process start

**Rationale**: Performance directly impacts user trust. Slow systems feel unreliable, and in a system promising ephemeral privacy, perceived reliability is essential.

### V. Privacy & Ephemerality Enforcement

Privacy is the core product promise and MUST be architecturally enforced:

- **Memory-Only Storage**: Conversation data MUST never touch persistent storage (disk, database, logs)
- **No Logging of Content**: Log statements MUST NOT include message content, token values, or presence hashes
- **Dissolution Verification**: Kernel dissolution MUST be verifiable through memory inspection (development/testing)
- **Token Opacity**: Tokens MUST be cryptographically random with no embedded user information
- **Session Isolation**: Cross-session data access MUST be architecturally impossible, not just access-controlled
- **No Analytics on Content**: Analytics MUST be limited to aggregate counts and timing; never content-based

**Rationale**: Privacy guarantees are worthless if they depend on policy rather than architecture. The system MUST make privacy violations structurally impossible.

## Technical Decision Framework

All technical decisions MUST be evaluated against these criteria in order of priority:

1. **Privacy Preservation**: Does this decision maintain or strengthen privacy guarantees?
2. **User Trust**: Does this decision support or undermine user confidence in the system?
3. **Simplicity**: Is this the simplest solution that meets requirements?
4. **Testability**: Can the correctness of this decision be verified through automated tests?
5. **Performance**: Does this decision meet the performance requirements?
6. **Maintainability**: Can future developers understand and safely modify this code?

When trade-offs are necessary:
- Privacy MUST NOT be compromised for any other concern
- Performance MAY be traded for simplicity if within requirements
- Features MAY be descoped to maintain code quality
- Complexity MUST be justified with documented rationale

## Implementation Quality Gates

Every implementation MUST pass these gates before merge:

### Gate 1: Code Review
- [ ] All principles from Section I (Code Quality) are satisfied
- [ ] No `TODO` comments without linked issue
- [ ] No disabled linting rules without documented justification

### Gate 2: Testing
- [ ] Unit tests pass with required coverage
- [ ] Integration tests pass
- [ ] Privacy tests explicitly verify data isolation and dissolution

### Gate 3: Performance
- [ ] Performance requirements verified through benchmarks for affected paths
- [ ] No memory leaks introduced (verified through profiling for memory-sensitive changes)

### Gate 4: Privacy
- [ ] Code review by second developer confirms no privacy violations
- [ ] No persistent storage of conversation data
- [ ] No logging of sensitive content

### Gate 5: Documentation
- [ ] API changes documented
- [ ] Breaking changes clearly noted in commit message
- [ ] User-facing changes documented in release notes

## Governance

### Amendment Process

1. **Proposal**: Constitutional changes MUST be proposed via documented RFC
2. **Review Period**: Minimum 48-hour review period for all stakeholders
3. **Approval**: Changes require explicit approval from project maintainer(s)
4. **Migration**: Breaking changes MUST include migration plan for affected code
5. **Documentation**: All amendments MUST update this constitution with version increment

### Versioning Policy

This constitution follows semantic versioning:
- **MAJOR**: Removal or redefinition of principles; backward-incompatible governance changes
- **MINOR**: New principles or materially expanded guidance
- **PATCH**: Clarifications, wording improvements, non-semantic refinements

### Compliance Review

- All pull requests MUST reference constitution compliance in review checklist
- Quarterly audit of codebase against constitution principles
- Constitution violations in production code MUST be tracked and remediated

### Precedence

This constitution supersedes all other development practices. When conflicts arise:
1. Constitution principles take precedence
2. Document the conflict and resolution in the relevant PR
3. If a practice consistently conflicts, propose a constitutional amendment

**Version**: 1.0.0 | **Ratified**: 2026-01-24 | **Last Amended**: 2026-01-24
